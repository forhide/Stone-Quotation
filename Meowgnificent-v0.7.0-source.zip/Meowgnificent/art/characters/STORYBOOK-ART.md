# v0.6.0 HD pastel storybook cat

`storybook_actions.png` is an original generated high-resolution six-pose sheet. Meowmalade is a round orange wizard cat with very short legs, a large floppy lavender hat, simple sage patch and a small bell collar. Half-lidded neutral eyes give the cat a deadpan expression. Casting uses an open paw rather than a wand.

The six poses retain the existing gameplay presentation API: idle, preparation, casting, startled recoil, hurt and tucked roll. `storybook_expressions.png` supplies neutral, annoyed, sleepy and startled HUD portraits in four equal cells.

Both sheets have genuine transparent backgrounds. The active renderer uses linear filtering and smooth alpha contours; there is no logical pixel grid, UV quantization or pixel-snap shader. The immutable indexed mesh still provides GPU breathing, waddling, casting recoil and delayed hat motion without rebuilding CPU geometry. Original earlier artwork is retained as design history.

## v0.7.0 original-meme identity

`meme_actions.png` is an original image_gen edit referencing the existing generated `meowgnificent.png` and painted action sheet. Original output `/workspace/generated_images/exec-46a3721d-6ca8-409f-b1f4-85b397263136.png`,2026-10-23. Broad charcoal/navy star-and-crescent hat, round orange British-Shorthair face and open amber eyes, tiny ears, pink nose, black collar and dark bronze bell follow the user-supplied wizard-cat meme. The squat bare cat body stays visible. Six poses remain separate transparent atlas crops; portraits now crop this same sheet. The previous lavender/angry-eye design is retained in source history but excluded from runtime export.
