# Storybook equipment / v0.7.0

`storybook_equipment.png`: image_gen original transparent illustration atlas, 2026-10-23, original `/workspace/generated_images/exec-dd5300a8-35bc-4cbf-90ef-a22461f83f01.png`. All nine catalog IDs use individually bounded AtlasTexture regions in EquipmentArt; the same cached images are shared by inventory, shop, dropped gear and worn accessories. No icon is synthesized per frame. It contains three wands/books, three collars and three charms.

Wand/book floats beside the paw, collar replaces the neck accessory, and charm is a small hat pin. CatEquipmentVisual creates exactly three Sprite2D nodes and changes their textures on a real equipment change. The parent body supplies waddle/roll rotation; attachments follow casting direction and pause clock. All loose accessories tuck out of view during a roll, then return. No extra robe, armor or backpack covers the cat body. Existing stats, ownership and save rules remain unchanged.
