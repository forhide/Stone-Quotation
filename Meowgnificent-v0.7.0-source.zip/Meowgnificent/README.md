# Meowgnificent the wizard cat

**A very round cat. A very unreliable wizard.**

Godot 4.6.3로 만든 코미디 액션 로그라이트의 **v0.7.0 파스텔 스토리북 모험 프로토타입**입니다. 제대로 하려는 플레이어가 어설픈 고양이의 마법 사고를 수습하고 역이용하면서, 전리품과 상점 장비로 이번 원정을 버티고 영구 강화로 다음 도전을 준비합니다.

## v0.7.0 — 삽화·장비 외형·한국어

기본 UI와 대사는 한국어입니다. **설정 / F10**에서 한국어·영어를 바꾸면 메뉴·전투 안내·현재 대사에 즉시 반영하고 다음 실행에도 유지합니다. 대사 50장면을 자연스러운 말투와 통일한 이름으로 다듬었으며 영어 대사도 전 장면 제공합니다. [언어 구현과 저장](docs/LOCALIZATION.md)을 참고하세요.

중간 이야기의 단순 도형을 시험장·도서관·정원·대서고 HD 삽화로 교체하고, 캐릭터는 원본 밈의 넓은 검은 별무늬 모자·둥근 주황 얼굴·동그란 눈·검은 목줄과 방울에 가깝게 다듬었습니다. 여섯 전신 액션과 짧은 다리의 둥근 몸체를 유지합니다.

장비 9종에 개별 HD 아이콘을 추가해 가방·상점·전리품에 표시하고, 실제 착용 모습에도 반영합니다. 지팡이/책은 앞발 옆에, 목걸이는 목에, 장식은 모자에 나타납니다. 장착·교체·해제와 구르기 후 복원이 연결되며 새 원정에 이전 외형이 남지 않습니다. 변경 내역과 범위는 [v0.7.0 릴리스](docs/RELEASE-v0.7.0.md)에 기록합니다.

## 원정·상점·장비

원정은 `data/expedition.json`에 정의한 8구역으로 이어집니다. 첫 구역에서 전투를 익힌 뒤 적과 책장 배치가 다른 구역을 지나고, 두 상점에서 장비와 회복 음식을 구매하며, 마지막 보스전을 넘으면 완주합니다. 마지막에는 성공 주문을 예측하는 The Perfect Wizard와 싸웁니다. 실수·폭주·구르기·환경 사고와 광선 공격 뒤의 빈틈을 이용하세요.

| 구역 | 이름 | 구성 |
| --- | --- | --- |
| 1 | Detention | 튜토리얼 전투 |
| 2 | The Library | 전투 |
| 3 | The Forbidden Garden | 정예가 포함된 전투 |
| 4 | Pip’s Picnic | 상점 |
| 5 | The Failed Wizards | 전투 |
| 6 | The Ordered Promenade | 정예가 포함된 전투 |
| 7 | The Last Loose End | 상점 |
| 8 | The Grand Archive | The Perfect Wizard 보스전 |

적은 동전 **Crowns**, 장비와 회복 음식을 떨어뜨립니다. `I`로 가방을 열어 보유 장비의 능력치를 비교하고 지팡이·목걸이·부적 슬롯에 장착할 수 있습니다. 장비는 9종이며 가방에는 장착한 장비를 포함해 최대 18개를 보유합니다. 상점에서는 가까운 상인에게 `E`로 말을 걸고 Crowns로 장비나 회복 음식을 삽니다. 각 상품은 해당 상점에서 한 번 구매할 수 있습니다.

## 이번 원정과 영구 성장

| 구분 | 원정 안에서 이어지는 것 | 새 원정에서도 남는 것 |
| --- | --- | --- |
| 재화 | Crowns: 전리품 수집·상점 구매 | Starlight: 전투 구역 클리어 보상·영구 강화 구매 |
| 장비·능력 | 가방과 장착 장비, 현재 체력, 원정 진행 | 영구 강화 4종의 구매 단계 |
| 기록 | 현재 원정의 처치·수집 수 | 시도 수, 완주 수, 최고 클리어 구역 |

패배하거나 새 원정을 시작하면 Crowns와 가방/장착 장비, 현재 진행은 초기화됩니다. 구역 클리어 때 저장한 Starlight와 영구 강화는 남습니다. 시작·패배·완주 화면에서 `M`을 눌러 다음 네 가지 강화를 구매합니다.

- **Sturdier Whiskers**: 다음 원정들의 최대 체력 증가.
- **Hidden Coin Pouch**: 다음 원정들의 시작 Crowns 증가.
- **Moonbell Magnet**: 전리품 수집 범위 증가.
- **Hand-Me-Down Wand**: 다음 원정부터 기본 지팡이를 보유하고 시작.

영구 진행은 `user://progress-v1.json`에 자동 저장하며, 임시 파일을 쓴 뒤 교체하고 이전 유효 저장의 백업을 유지합니다. **진행 중인 원정을 종료 후 같은 구역에서 이어 하는 기능은 없습니다.** 저장 대상은 Starlight·영구 강화·기록입니다.

## 플레이

배포 ZIP을 압축 해제한 뒤 Windows는 `Meowgnificent.exe`, Linux는 `Meowgnificent.x86_64`, macOS는 `Meowgnificent the wizard cat.app`을 실행합니다. Godot 설치는 필요 없습니다. 소스는 Godot에서 `project.godot`를 열고 F5로 실행하거나 `./run.sh`를 사용합니다.

| 조작 | 동작 |
| --- | --- |
| WASD / 방향키 | 이동 |
| 마우스 + 클릭 / Space | 조준·화염구 (누르기 가능) |
| Shift + 이동 방향 | 몸통 구르기, 회피·적 충돌·책장 밀기 |
| Shift만 | 조준 방향으로 구르기 |
| I | 가방·장비 열기 / 닫기 |
| E | 가까운 상인과 대화 / 열린 출구로 이동 |
| Enter | 시작·대화 다음 페이지·정지 해제 / 구역 클리어 후 다음 구역 / 패배·완주 후 새 원정 |
| M | 시작·패배·완주 화면에서 영구 강화 열기 / 닫기 |
| 클릭 / 1~4 | 상점 상품·영구 강화 구매 |
| F10 / 설정 | 한국어·영어 선택 / 설정 열기·닫기 |
| Esc | 이야기 건너뛰기 / 일시정지·재개 / 열린 패널 닫기 |
| R | 현재 원정을 끝내고 시작 화면으로 돌아가기 |
| F1 / F2 / F3 | 다음 유효 주문 한 번을 성공 / 실수 / 폭주로 고정 |

이야기 화면에서는 `Enter`·`Space`로 다음 페이지를 보고 `Esc`로 건너뛸 수 있습니다. 전투 구역의 모든 적을 물리치면 출구가 열립니다. 전리품을 정리하고 `Enter`를 누르거나 출구 가까이에서 `E`를 누르면 다음 구역으로 갑니다. 상점은 구매를 마친 뒤 같은 방법으로 떠날 수 있습니다.

## 사고를 이용하는 전투

- 적의 `!`와 공격 경로를 보고 옆으로 피하거나 구르세요. 공격 방향은 예고 시 고정되며, 적을 때리면 준비 중인 공격이 끊깁니다.
- 촛불 슬라임은 가까이서 덮치고, 빗자루는 길게 돌진하고, 박쥐는 짧게 급강하합니다. 스치기만 해서는 피해를 입지 않습니다.
- 책장에 불을 쏘면 타오르다가 표시된 방향으로 넘어집니다. 고양이도 다칠 수 있습니다. 구르기나 적의 돌진으로도 책장을 넘어뜨릴 수 있습니다.
- 발밑 실수는 불을 만들고 놀란 고양이를 반대 방향으로 굴립니다. 그 몸통으로 적을 치거나 책장을 밀 수 있습니다. 옆/뒤로 나간 실수 주문도 적이나 책장에 맞습니다.
- 폭주 주문은 강하지만 고양이도 반동으로 밀립니다. 구르기는 잠깐 무적이며 회복 시간이 있습니다. 바닥 불은 피아 모두에게 위험합니다.

둥근 SD 고양이의 대기·시전 준비·발사·실수 반동·피격·구르기 전신 포즈와, 성공/실수/폭주 기본 확률 70/20/10을 이어갑니다. 사고는 `이런!`, 연기와 불꽃, 상황 문구로 표시합니다. 이번 업데이트에서 추가 주문이나 음식에 따른 Chonk 성장은 구현하지 않았습니다. 음식은 체력 회복용입니다.

## 그래픽·플랫폼

장소별 배경과 장식은 구역 입장 시 한 번 그려 캐시에 보관합니다. 적·책장·마법 효과는 공유 텍스처를 사용하며, 부드러운 SD 그림은 선형 필터로 표시합니다. 내부 렌더링은 1280×800입니다. [v0.5.0의 이전 측정](docs/RELEASE-v0.5.0.md)은 이번 버전이나 실제 사용자 Windows 하드웨어의 FPS를 뜻하지 않습니다. 이전 v0.6.0의 [동일 환경 비교](docs/qa/v060-performance/METHOD.md)에서는 튜토리얼 프레임 시간이 느려지고 효과 중첩 장면은 빨라지는 혼재된 결과가 나왔습니다. 실제 Windows PC의 전반적인 성능 향상을 단정하지 않습니다.

Mac은 macOS 11 이상 Apple Silicon을 기준으로 공식 Universal 템플릿을 사용합니다. Intel Mac 실기 검증은 대상이 아닙니다. 앱은 임시(ad-hoc) 서명 방식이며 Apple 개발자 인증서 서명·공증과 실제 Mac 실행 검증은 제공하지 않습니다. 첫 실행은 동봉 `PLAY-MACOS.txt`를 참고하세요.

## 개발·검증·배포

- `./test.sh`: Godot 기능·입력·사고 상호작용과 경제·영구 진행·원정 흐름 검사. 오류와 실패는 비정상 종료합니다.
- `./build.sh`: 필요한 공식 export template 확인, 검사, Windows/Linux/Web/macOS 내보내기.
- `python3 package.py`: 실행 파일·웹·소스 ZIP 및 SHA-256 목록 생성.
- `tests/desktop-smoke.py`: X11 입력과 화면 OCR을 이용한 실행 파일 검사. Wine을 이용한 Windows 검사는 실제 Windows PC 검증과 구분됩니다.
- `tests/story-web.cjs`: 이야기 건너뛰기 플래그 없이 실제 Web 오프닝·페이지 이동·건너뛰기 후 조작을 확인하는 별도 검사입니다.

소스 ZIP의 `docs/qa/`에는 현재 버전의 검증 증거만 포함합니다. 이전 버전의 증거는 해당 버전 소스 ZIP에 있습니다.

소스497개, Windows/Wine·Linux 각각23개, Web40개 검사가 통과했습니다. 실행 범위와 다운로드 검사 방식은 [QA 기록](docs/QA-v0.7.0.md)에 정리합니다. Windows/Wine과 실제 Windows PC 검증을 구분하고, Mac은 구조·권한·arm64·서명 해시만 확인합니다.

게임 소스는 `Stone-Quotation` 기존 앱과 분리되어 있습니다. 배포 ZIP은 해당 저장소의 전용 다운로드 브랜치를 사용하며 익명 임시 파일 호스트는 사용하지 않습니다. 아래 GitHub 전용 브랜치에서 v0.7.0 ZIP을 제공합니다. 패키지 무결성과 실제 게시 URL의 새 다운로드 검증은 배포 단계에서 별도로 수행합니다. 동봉 SHA-256 목록으로 파일을 비교할 수 있습니다.

- [Windows ZIP](https://github.com/forhide/Stone-Quotation/raw/refs/heads/meowgnificent-downloads-v0.7.0/Meowgnificent-v0.7.0-windows.zip)
- [macOS ZIP](https://github.com/forhide/Stone-Quotation/raw/refs/heads/meowgnificent-downloads-v0.7.0/Meowgnificent-v0.7.0-macos.zip)
- [Linux ZIP](https://github.com/forhide/Stone-Quotation/raw/refs/heads/meowgnificent-downloads-v0.7.0/Meowgnificent-v0.7.0-linux.zip)
- [Web ZIP](https://github.com/forhide/Stone-Quotation/raw/refs/heads/meowgnificent-downloads-v0.7.0/Meowgnificent-v0.7.0-web.zip)
- [소스 ZIP](https://github.com/forhide/Stone-Quotation/raw/refs/heads/meowgnificent-downloads-v0.7.0/Meowgnificent-v0.7.0-source.zip)

GPU 렌더링 성능 비교용 `tests/performance.gd`는 일반 `test.sh`에 포함하지 않습니다. 그래픽 디스플레이에서 `./run.sh --disable-vsync --max-fps 0 --script res://tests/performance.gd`로 실행하며, 30프레임 준비 후 180프레임을 측정합니다. `MEOW_PERF_OUTPUT`으로 JSON 경로를 지정할 수 있습니다.

## 구현 범위

고정된 8구역 순서, 세 가지 기본 적과 전용 보스, 화염구·구르기·책장 사고, 전리품·상점 두 곳·장비 9종·영구 강화 4종, 오프닝과 구역 이야기·결말을 구현한 프로토타입입니다. 절차형 맵 생성, 추가 사용 주문, 음식·Chonk 성장, 진행 중 원정 이어 하기는 아직 없습니다. 실제 3D나 물리 엔진 기반 책장 시뮬레이션이 아닌 2D 상태·충돌 판정 방식이며 효과음은 아직 없습니다.

`docs/design/`는 사용자 개발노트입니다. 노트 전체를 구현했다는 의미는 아닙니다. 아트 참고 기록은 [ART_REFERENCE](docs/ART_REFERENCE.md), 이전 버전 검사 기록은 [QA](docs/QA.md)와 각 버전 릴리스 문서에 있습니다.
실행 ZIP을 유지하고 문서가 포함된 소스 ZIP만 갱신하려면 `python3 package.py --source-only`를 사용합니다. 해당 옵션은 기존 네 플랫폼 ZIP의 무결성을 확인한 후 소스 ZIP과 체크섬 목록을 갱신합니다.
