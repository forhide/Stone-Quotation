class_name ArchiveBackdrop
extends Node2D

# HD Pastel Storybook 2D: each location has a full-resolution hand-drawn scene.
# Room caches this painter once per arrival; gameplay draws one background quad.
const STORAGE: Texture2D = preload("res://art/environments/hd_detention_storage.png")
const LIBRARY: Texture2D = preload("res://art/environments/hd_academy_library.png")
const GARDEN: Texture2D = preload("res://art/environments/hd_forbidden_garden.png")
const ARCHIVE: Texture2D = preload("res://art/environments/hd_grand_archive.png")
const THEMES := ["candlewick", "loose_ends", "sootbound", "kettle_quill", "restricted", "bellkeeper", "paper_moon", "final_exam"]
const PAPER := Color("fff4d7")
const PAPER_EDGE := Color("d7b886")
var stage_index := 0

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func configure(index: int) -> void:
	stage_index=clampi(index,0,THEMES.size()-1)
	queue_redraw()

func theme_id() -> String:
	return THEMES[stage_index]

func _location_art() -> Texture2D:
	match stage_index:
		0,6: return STORAGE
		1,4: return LIBRARY
		2,3,5: return GARDEN
		_: return ARCHIVE

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,800),PAPER)
	var washes := [Color.WHITE,Color.WHITE,Color("f4f0ff"),Color("fff5e9"),Color("f2f8ff"),Color("eaf8f8"),Color("fff2f7"),Color.WHITE]
	draw_texture_rect(_location_art(),Rect2(0,0,1280,800),false,washes[stage_index])
	# Variants are soft flat floor decorations, never additional obstacles.
	match stage_index:
		4: _reading_runners()
		3: _picnic_mat(Rect2(350,350,580,274),Color("daeadb"),Color("fff4dc"))
		5: _ordered_stepping_tiles()
		6: _picnic_mat(Rect2(270,338,740,304),Color("efd9e5"),Color("fff3dc"))
	# Light stationery framing follows the HUD. No pixel sampling or posterize.
	draw_rect(Rect2(0,0,1280,118),PAPER)
	draw_rect(Rect2(0,714,1280,86),PAPER)
	draw_rect(Rect2(0,114,1280,4),Color("e7cfa1"))
	draw_rect(Rect2(0,714,1280,4),Color("e7cfa1"))
	draw_line(Vector2(46,110),Vector2(1234,110),PAPER_EDGE,1,true)
	draw_line(Vector2(46,722),Vector2(1234,722),PAPER_EDGE,1,true)

func _rounded(rect: Rect2, fill: Color, outline: Color, radius: int, width := 1) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=outline
	style.set_border_width_all(width)
	style.set_corner_radius_all(radius)
	style.anti_aliasing=true
	draw_style_box(style,rect)

func _reading_runners() -> void:
	for x in [335.0,945.0]:
		var rect := Rect2(x-48,289,96,340)
		_rounded(rect.grow(3),Color(0.40,0.34,0.48,0.08),Color.TRANSPARENT,14)
		_rounded(rect,Color("d9cce4"),Color("b5a0bb"),12,2)
		_rounded(rect.grow(-7),Color(1,1,1,0.04),Color("efe0df"),7,1)
		for y in [319.0,459.0,599.0]:
			_flower_stamp(Vector2(x,y),12,Color("f7ecd7"))

func _ordered_stepping_tiles() -> void:
	# The Perfection influence makes garden paths unnaturally regular. These
	# are painted flush with the lawn; all remain walkable.
	for row in range(4):
		for col in range(6):
			var point := Vector2(286+col*119,303+row*86)
			_rounded(Rect2(point,Vector2(106,61)),Color("e6e8d5"),Color("c3d1bd"),14,1)
			draw_line(point+Vector2(15,8),point+Vector2(88,8),Color(1,1,0.9,0.45),1,true)

func _picnic_mat(rect: Rect2, base: Color, trim: Color) -> void:
	_rounded(rect.grow(4),Color(0.38,0.41,0.32,0.10),Color.TRANSPARENT,21)
	_rounded(rect,base,trim.darkened(0.13),18,2)
	_rounded(rect.grow(-8),Color(1,1,1,0.025),trim,12,2)
	# Quiet broad weave stripes keep this a soft illustrated picnic cloth,
	# rather than a pixel texture or a vivid checkered game board.
	for row in range(8):
		var at := rect.position+Vector2(16,16+row*(rect.size.y-32)/8.0)
		draw_line(at,Vector2(rect.end.x-16,at.y),Color(trim,0.16),11,true)
	for col in range(17):
		var at := rect.position+Vector2(18+col*(rect.size.x-36)/17.0,15)
		draw_line(at,Vector2(at.x,rect.end.y-15),Color(trim,0.13),9,true)
	for p in [rect.position+Vector2(29,28),Vector2(rect.end.x-29,rect.position.y+28),rect.end-Vector2(29,28),Vector2(rect.position.x+29,rect.end.y-28)]:
		_flower_stamp(p,12,trim)

func _flower_stamp(center: Vector2, radius: float, color: Color) -> void:
	for i in range(5):
		var petal := center+Vector2.from_angle(-PI/2+i*TAU/5)*radius*0.56
		draw_circle(petal,radius*0.40,color,true,-1,true)
	draw_circle(center,radius*0.22,color.darkened(0.15),true,-1,true)
