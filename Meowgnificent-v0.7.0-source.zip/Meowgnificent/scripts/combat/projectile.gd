class_name SpellProjectile
extends Node2D

signal impacted(point: Vector2, damage: int, radius: float, direction: Vector2)
var direction := Vector2.RIGHT
var speed := 540.0
var lifetime := 2.3
var damage := 20
var radius := 9.0
var explosion_radius := 0.0
var outcome := "success"
var room: Node2D
var bounds: Rect2
var age := 0.0
var spent := false

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func _physics_process(delta: float) -> void:
	if spent:
		return
	age += delta
	# Substeps prevent tunnelling through an enemy at low frame rates.
	var distance := speed * delta
	var steps := maxi(1,ceili(distance / 8.0))
	for i in range(steps):
		position += direction * distance / steps
		if not bounds.has_point(position):
			impact()
			return
		for shelf in room.props:
			if shelf.state!="fallen" and shelf.state!="falling" and position.distance_to(shelf.position)<radius+32:
				shelf.ignite(direction)
				impact()
				return
		for enemy in room.enemies:
			if is_instance_valid(enemy) and enemy.health.current > 0 and position.distance_to(enemy.position) <= radius + float(enemy.config.radius):
				if explosion_radius == 0.0:
					if enemy.has_method("take_spell_damage"): enemy.call("take_spell_damage",damage,direction,outcome)
					else: enemy.take_damage(damage,direction)
				impact()
				return
	if age >= lifetime:
		impact()
	queue_redraw()

func impact() -> void:
	if spent:
		return
	spent = true
	impacted.emit(position,damage,explosion_radius,direction)
	queue_free()

func _draw() -> void:
	# Baked curls, sparks and glow: one textured quad instead of a circle trail.
	var flutter := 1.0+sin(age*28.0)*0.055
	var size := radius/9.0
	draw_set_transform(Vector2(0,-20),direction.angle(),Vector2(size,size*flutter))
	if outcome=="miscast":
		draw_texture_rect(SpellArt.part("fizzle"),Rect2(-115.6,-23.2,136,47),false)
	else:
		draw_texture_rect(SpellArt.part("comet"),Rect2(-104.2,-30.1,128,56),false)
		if outcome=="overreaction":
			# The oversized spell carries an unstable rotating seal around its core.
			draw_set_transform(Vector2(0,-20),age*2.4,Vector2.ONE*size)
			draw_texture_rect(SpellArt.part("impact"),Rect2(-24,-24,48,48),false,Color(1,1,1,0.65))
	draw_set_transform(Vector2.ZERO)
