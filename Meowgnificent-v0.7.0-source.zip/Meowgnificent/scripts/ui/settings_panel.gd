class_name SettingsPanel
extends CanvasLayer

var room: Node
var is_open := false
var input_guard_until_msec := -1
var screen: Control
var choice: OptionButton
var message: Label
var previous_state := ""
var was_story_processing := false
var was_player_active := false
var previous_projectile_mode := 0
var previous_enemy_activity: Dictionary = {}

func _ready() -> void:
	layer=40
	process_mode=Node.PROCESS_MODE_ALWAYS
	screen=Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter=Control.MOUSE_FILTER_STOP
	add_child(screen)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color=Color(0.28,0.24,0.24,0.35)
	shade.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(shade)
	var panel := PanelContainer.new()
	panel.position=Vector2(370,238)
	panel.size=Vector2(540,320)
	var style := StyleBoxFlat.new()
	style.bg_color=Color("fff7e6")
	style.border_color=Color("bca38b")
	style.set_border_width_all(2)
	style.set_corner_radius_all(22)
	style.content_margin_left=30
	style.content_margin_right=30
	style.content_margin_top=24
	style.content_margin_bottom=24
	panel.add_theme_stylebox_override("panel",style)
	screen.add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation",18)
	panel.add_child(column)
	for caption in ["Settings","Language"]:
		var label := Label.new()
		label.text=caption
		label.add_theme_font_size_override("font_size",29 if caption=="Settings" else 17)
		label.add_theme_color_override("font_color",Color("654e45"))
		column.add_child(label)
	choice=OptionButton.new()
	choice.name="LanguageChoice"
	choice.custom_minimum_size=Vector2(0,46)
	choice.add_item("한국어",0)
	choice.add_item("English",1)
	choice.add_theme_font_size_override("font_size",19)
	choice.add_theme_color_override("font_color",Color("654e45"))
	choice.add_theme_color_override("font_hover_color",Color("654e45"))
	choice.add_theme_color_override("font_focus_color",Color("654e45"))
	choice.add_theme_color_override("font_pressed_color",Color("654e45"))
	var choice_style := StyleBoxFlat.new()
	choice_style.bg_color=Color("e4edda")
	choice_style.border_color=Color("a1b58e")
	choice_style.set_border_width_all(2)
	choice_style.set_corner_radius_all(10)
	choice_style.content_margin_left=14
	for state in ["normal","hover","pressed","focus"]: choice.add_theme_stylebox_override(state,choice_style)
	choice.item_selected.connect(func(index: int): GameLocale.set_language("ko" if index==0 else "en"))
	column.add_child(choice)
	message=Label.new()
	message.text="Changes apply immediately and are saved for your next visit."
	message.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	message.custom_minimum_size=Vector2(460,44)
	message.add_theme_font_size_override("font_size",15)
	message.add_theme_color_override("font_color",Color("7c6c60"))
	column.add_child(message)
	var close_button := Button.new()
	close_button.text="Return to game  /  ESC"
	close_button.custom_minimum_size=Vector2(0,44)
	close_button.add_theme_color_override("font_color",Color("654e45"))
	close_button.add_theme_color_override("font_hover_color",Color("654e45"))
	close_button.add_theme_color_override("font_focus_color",Color("654e45"))
	for state in ["normal","hover","pressed","focus"]: close_button.add_theme_stylebox_override(state,choice_style)
	close_button.pressed.connect(close)
	column.add_child(close_button)
	GameLocale.service().changed.connect(_language_changed)
	screen.hide()

func _language_changed(_locale: String) -> void:
	choice.select(0 if GameLocale.current=="ko" else 1)
	message.text="Settings could not be saved. Your choice still applies for this session." if GameLocale.save_error else "Changes apply immediately and are saved for your next visit."
	if room.panel.is_open: room.panel.refresh()
	if room.story_director.is_open: room.story_director.refresh_language()
	room.hud.refresh_language(previous_state)
	room.markers.queue_redraw()

func open() -> void:
	if is_open: return
	previous_state=room.state
	was_player_active=room.player.active
	previous_projectile_mode=room.projectiles.process_mode
	previous_enemy_activity.clear()
	for enemy in room.enemies:
		previous_enemy_activity[enemy.get_instance_id()]=enemy.active
		enemy.active=false
	was_story_processing=room.story_director.is_processing()
	room.story_director.set_process(false)
	room.player.active=false
	room.projectiles.process_mode=Node.PROCESS_MODE_DISABLED
	room.state="settings"
	is_open=true
	choice.select(0 if GameLocale.current=="ko" else 1)
	screen.show()
	choice.grab_focus()

func blocks_gameplay_input() -> bool:
	return is_open or Time.get_ticks_msec()<=input_guard_until_msec

func close() -> void:
	if not is_open: return
	is_open=false
	input_guard_until_msec=Time.get_ticks_msec()+80
	choice.get_popup().hide()
	screen.hide()
	room.state=previous_state
	room.player.active=was_player_active
	room.projectiles.process_mode=previous_projectile_mode
	for enemy in room.enemies:
		enemy.active=bool(previous_enemy_activity.get(enemy.get_instance_id(),false))
	room.story_director.set_process(was_story_processing)
	Input.action_release("cast")
	room.spells.input_blocked_until_release=true

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.is_pressed() and not event.is_echo():
		if event.keycode==KEY_F10:
			if is_open: close()
			else: open()
			get_viewport().set_input_as_handled()
			return
	if is_open and event is InputEventKey:
		# Let GUI navigation handle arrows/Enter; consume gameplay shortcuts.
		if event.is_pressed() and event.keycode==KEY_ESCAPE:
			close()
			get_viewport().set_input_as_handled()
		elif event.keycode not in [KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT,KEY_HOME,KEY_END,KEY_ENTER,KEY_KP_ENTER,KEY_TAB,KEY_SPACE]:
			get_viewport().set_input_as_handled()
