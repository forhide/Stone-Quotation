class_name WizardHUD
extends CanvasLayer

# Warm paper windows keep the pixel world bright and the small text readable.
const INK := Color("654e45")
const MUTED := Color("7c6c60")
const PAPER := Color("fff7e6")
const LINE := Color("c9ad91")
const SAGE := Color("567b62")

signal begin_requested
var room: Node2D
var health_label: Label
var health_bar: ProgressBar
var status_label: Label
var cooldown_label: Label
var roll_label: Label
var enemy_label: Label
var debug_label: Label
var overlay: PanelContainer
var overlay_title: Label
var overlay_body: Label
var play_button: Button
var incident_label: Label
var incident_time := 0.0
var outcome_time := 0.0
var outcome := ""
var portrait: CatPortrait
var menu_portrait: CatPortrait
var stage_label: Label
var room_label: Label
var wallet_label: Label
var inventory_button: Button
var legacy_button: Button
var sector_banner: SectorBanner
var route_nodes: Array[Label] = []
var observed_stage := -1
var observed_exit_open := false
var arrival_pending := true

func label_at(text: String, at: Vector2, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.position = at
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	add_child(label)
	return label

func panel_style(color: Color, border: Color, radius: int = 12) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	if radius>=12:
		style.shadow_color=Color(0.35,0.25,0.18,0.10)
		style.shadow_size=3
		style.shadow_offset=Vector2(0,2)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 20
	style.content_margin_bottom = 20
	return style

func _ready() -> void:
	var ink := INK
	var dim := MUTED
	# A soft paper header and a little mint purse tab, rather than metal panels.
	var header := Panel.new()
	header.position=Vector2(26,12)
	header.size=Vector2(1228,104)
	header.mouse_filter=Control.MOUSE_FILTER_IGNORE
	header.add_theme_stylebox_override("panel",panel_style(PAPER,Color("ddc7a9"),18))
	add_child(header)
	var purse := Panel.new()
	purse.position=Vector2(417,18)
	purse.size=Vector2(291,92)
	purse.mouse_filter=Control.MOUSE_FILTER_IGNORE
	purse.add_theme_stylebox_override("panel",panel_style(Color("e9f0df"),Color("c5d4b2"),12))
	add_child(purse)
	label_at("THE SCHOOL OF SMALL MAGICAL MISHAPS",Vector2(52,24),12,Color("806348"))
	label_at("Meowgnificent",Vector2(49,42),37,ink)
	label_at("Meowmalade / Arcana Academy",Vector2(52,88),15,dim)
	stage_label=label_at("",Vector2(950,22),16,Color("806348"))
	stage_label.size=Vector2(280,20)
	stage_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	room_label=label_at("",Vector2(750,49),21,ink)
	room_label.size=Vector2(480,32)
	room_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	enemy_label = label_at("",Vector2(980,88),14,dim)
	enemy_label.size=Vector2(250,20)
	enemy_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	var route := HBoxContainer.new()
	route.position=Vector2(750,88)
	route.mouse_filter=Control.MOUSE_FILTER_IGNORE
	route.add_theme_constant_override("separation",4)
	add_child(route)
	for index in range(room.stages.size()):
		var stop := Label.new()
		stop.custom_minimum_size=Vector2(23,20)
		stop.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		stop.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
		stop.mouse_filter=Control.MOUSE_FILTER_IGNORE
		stop.add_theme_font_size_override("font_size",11)
		stop.text="S" if str(room.stages[index].kind)=="shop" else str(index+1)
		stop.tooltip_text=GameLocale.text("Area %02d: %s") % [index+1,str(room.stages[index].name)]
		route.add_child(stop)
		route_nodes.append(stop)
	label_at("CROWNS  /  STARLIGHT",Vector2(433,26),11,Color("806348"))
	wallet_label=label_at("0  /  0",Vector2(433,44),23,ink)
	inventory_button=Button.new()
	inventory_button.position=Vector2(432,80)
	inventory_button.size=Vector2(260,28)
	var gear_style := panel_style(Color("d4e7c9"),Color("91aa85"),9)
	gear_style.content_margin_top=4
	gear_style.content_margin_bottom=4
	gear_style.content_margin_left=12
	gear_style.content_margin_right=12
	for button_state in ["normal","hover","pressed","disabled"]:
		inventory_button.add_theme_stylebox_override(button_state,gear_style)
	inventory_button.add_theme_font_size_override("font_size",12)
	inventory_button.add_theme_color_override("font_color",INK)
	inventory_button.add_theme_color_override("font_hover_color",INK)
	inventory_button.add_theme_color_override("font_pressed_color",INK)
	inventory_button.add_theme_color_override("font_disabled_color",Color("8c8e78"))
	inventory_button.pressed.connect(func(): room.open_inventory())
	add_child(inventory_button)
	var bottom := Panel.new()
	bottom.position = Vector2(45,718)
	bottom.size = Vector2(1190,66)
	bottom.add_theme_stylebox_override("panel",panel_style(PAPER,Color("c8b79d"),18))
	add_child(bottom)
	portrait = CatPortrait.new()
	portrait.position = Vector2(53,721)
	portrait.size = Vector2(62,59)
	add_child(portrait)
	health_label = label_at("",Vector2(125,726),14,ink)
	health_bar = ProgressBar.new()
	health_bar.position = Vector2(126,754)
	health_bar.size = Vector2(136,8)
	health_bar.show_percentage = false
	health_bar.add_theme_stylebox_override("background",panel_style(Color("e5d8c9"),Color("e5d8c9"),4))
	health_bar.add_theme_stylebox_override("fill",panel_style(Color("e3a28e"),Color("e3a28e"),4))
	for kind in ["background", "fill"]:
		var bar_style := health_bar.get_theme_stylebox(kind) as StyleBoxFlat
		bar_style.content_margin_left = 0
		bar_style.content_margin_right = 0
		bar_style.content_margin_top = 0
		bar_style.content_margin_bottom = 0
	add_child(health_bar)
	label_at("LMB / SPACE",Vector2(296,729),12,Color("806348"))
	cooldown_label = label_at("",Vector2(296,748),16,ink)
	roll_label=label_at("",Vector2(1010,763),12,Color("6f6857"))
	status_label = label_at("A very round cat. A very unreliable wizard.",Vector2(495,739),17,ink)
	incident_label = label_at("",Vector2(295,132),18,INK)
	incident_label.add_theme_color_override("font_shadow_color",Color("fff9ed"))
	incident_label.add_theme_constant_override("shadow_offset_x",1)
	incident_label.add_theme_constant_override("shadow_offset_y",1)
	incident_label.add_theme_color_override("font_outline_color",Color("fff9ed"))
	incident_label.add_theme_constant_override("outline_size",3)
	debug_label = label_at("",Vector2(820,697),11,dim)
	debug_label.hide()
	var controls_back := Panel.new()
	controls_back.position=Vector2(290,687)
	controls_back.size=Vector2(700,25)
	controls_back.mouse_filter=Control.MOUSE_FILTER_IGNORE
	controls_back.add_theme_stylebox_override("panel",panel_style(Color(1.0,0.97,0.89,0.94),Color("d6c3a8"),10))
	add_child(controls_back)
	label_at("WASD MOVE  ·  SHIFT ROLL  ·  I GEAR  ·  E INTERACT  ·  ESC PAUSE",Vector2(310,693),11,dim)
	overlay = PanelContainer.new()
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay.add_theme_stylebox_override("panel",panel_style(PAPER,Color("cba98c"),22))
	add_child(overlay)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",17)
	overlay.add_child(box)
	var eyebrow := Label.new()
	eyebrow.text = "A SMALL WIZARD. A BIG LITTLE ADVENTURE."
	eyebrow.add_theme_font_size_override("font_size",12)
	eyebrow.modulate = Color("806348")
	box.add_child(eyebrow)
	menu_portrait = CatPortrait.new()
	menu_portrait.custom_minimum_size = Vector2(100,100)
	box.add_child(menu_portrait)
	overlay_title = Label.new()
	overlay_title.add_theme_font_size_override("font_size",30)
	overlay_title.add_theme_color_override("font_color",INK)
	box.add_child(overlay_title)
	overlay_body = Label.new()
	overlay_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_body.custom_minimum_size = Vector2(470,85)
	overlay_body.add_theme_font_size_override("font_size",16)
	overlay_body.add_theme_color_override("font_color",MUTED)
	box.add_child(overlay_body)
	play_button = Button.new()
	play_button.custom_minimum_size = Vector2(0,46)
	play_button.add_theme_stylebox_override("normal",panel_style(Color("d7e9c8"),Color("8da67c"),12))
	play_button.add_theme_stylebox_override("hover",panel_style(Color("e5f0d7"),Color("779266"),12))
	play_button.add_theme_stylebox_override("pressed",panel_style(Color("bed5b3"),Color("779266"),12))
	play_button.add_theme_stylebox_override("focus",panel_style(Color(0,0,0,0),Color("9a8aaa"),12))
	play_button.add_theme_color_override("font_color",INK)
	play_button.add_theme_color_override("font_hover_color",INK)
	play_button.add_theme_color_override("font_pressed_color",INK)
	play_button.pressed.connect(func(): begin_requested.emit())
	box.add_child(play_button)
	legacy_button=Button.new()
	legacy_button.text="M  ·  Legacy studies"
	legacy_button.custom_minimum_size=Vector2(0,32)
	legacy_button.add_theme_color_override("font_color",Color("775d88"))
	legacy_button.add_theme_color_override("font_hover_color",Color("634878"))
	var legacy_style := panel_style(Color("eee4f4"),Color("bdabd0"),10)
	legacy_style.content_margin_top=4
	legacy_style.content_margin_bottom=4
	for button_state in ["normal","hover","pressed"]:
		legacy_button.add_theme_stylebox_override(button_state,legacy_style)
	legacy_button.pressed.connect(func(): room.open_legacy())
	box.add_child(legacy_button)
	show_overlay("A minor magical incident", "8 areas: little mishaps, two cozy shops, one final exam.\nEnemies drop Crowns and gear. I: equip. E: interact.\nStarlight and legacy studies survive defeat.", "Begin expedition   /   ENTER")
	overlay.position = Vector2(600,240)
	overlay.size = Vector2(550,315)
	var settings_button := Button.new()
	settings_button.text="Settings"
	settings_button.tooltip_text="F10"
	settings_button.position=Vector2(1100,686)
	settings_button.size=Vector2(154,27)
	settings_button.add_theme_font_size_override("font_size",13)
	settings_button.add_theme_color_override("font_color",INK)
	settings_button.add_theme_color_override("font_hover_color",INK)
	var settings_style := panel_style(Color("eee4f4"),Color("bdabd0"),8)
	settings_style.content_margin_top=3
	settings_style.content_margin_bottom=3
	settings_style.content_margin_left=12
	settings_style.content_margin_right=12
	for state in ["normal","hover","pressed","focus"]: settings_button.add_theme_stylebox_override(state,settings_style)
	settings_button.pressed.connect(func(): room.settings.open())
	add_child(settings_button)
	sector_banner=SectorBanner.new()
	add_child(sector_banner)

func update_route() -> void:
	for index in range(route_nodes.size()):
		var stop := route_nodes[index]
		var active: bool=index==room.run.stage_index
		var visited: bool=index<room.run.stage_index
		var shop := str(room.stages[index].kind)=="shop"
		stop.set_meta("active",active)
		stop.set_meta("visited",visited)
		stop.set_meta("shop",shop)
		var style := panel_style(Color("f1e8db"),Color("c7b49e"),6)
		style.content_margin_left=0
		style.content_margin_right=0
		style.content_margin_top=0
		style.content_margin_bottom=0
		if active:
			style.bg_color=Color("eed4a2")
			style.border_color=Color("b98e57")
		elif visited:
			style.bg_color=Color("d7e7cc")
			style.border_color=Color("9bb28c")
		stop.add_theme_stylebox_override("normal",style)
		stop.add_theme_color_override("font_color",INK if active else Color("526e53") if visited else Color("77685c"))

func sync_sector_notice(delta: float) -> void:
	var total: int=room.stages.size()
	if observed_stage!=room.run.stage_index:
		observed_stage=room.run.stage_index
		arrival_pending=true
		observed_exit_open=room.exit_open
		update_route()
	if room.state=="playing" and arrival_pending:
		sector_banner.announce_arrival(observed_stage,total,room.stage_def,room.enemies.size())
		arrival_pending=false
	elif room.state=="playing" and room.exit_open and not observed_exit_open and observed_stage+1<total:
		sector_banner.announce_clear(observed_stage,total,str(room.stages[observed_stage+1].name))
	observed_exit_open=room.exit_open
	sector_banner.tick(delta,room.state=="playing")

func show_overlay(title: String, body: String, button: String) -> void:
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay_title.text = title
	overlay_body.text = body
	play_button.text = button
	overlay.show()

func refresh_language(run_state: String) -> void:
	# Rebuild variable copy from game state, rather than translating a string
	# whose numbers and names have already been inserted in the old language.
	if run_state=="defeated":
		overlay_body.text=GameLocale.text("Reached area %d / 8. Crowns and gear belong to this expedition.\nYour %d Starlight and legacy studies are safe.\nM: legacy upgrades before the next attempt.") % [room.run.stage_index+1,room.profile.starlight]
	elif run_state=="cleared":
		overlay_body.text=GameLocale.text("All 8 areas cleared. %d foes, %d Crowns collected.\n%d Starlight remains for permanent legacy upgrades.\nM: legacy studies. ENTER: a fresh expedition.") % [room.run.enemies_defeated,room.run.collected_gold,room.profile.starlight]
	if is_instance_valid(sector_banner) and observed_stage>=0:
		var age := sector_banner.elapsed
		if sector_banner.mode=="arrival": sector_banner.announce_arrival(observed_stage,room.stages.size(),room.stage_def,room.enemies.size())
		elif observed_stage+1<room.stages.size(): sector_banner.announce_clear(observed_stage,room.stages.size(),str(room.stages[observed_stage+1].name))
		sector_banner.elapsed=age
	for index in range(route_nodes.size()):
		route_nodes[index].tooltip_text=GameLocale.text("Area %02d: %s") % [index+1,GameLocale.text(str(room.stages[index].name))]

func show_incident(message: String, color: Color) -> void:
	incident_label.text=GameLocale.text(message)
	incident_label.modulate=Color.WHITE
	incident_label.add_theme_color_override("font_color",color.lerp(INK,0.78))
	incident_time=2.7

func show_outcome(result: String) -> void:
	outcome = result
	outcome_time = 1.5

func _process(delta: float) -> void:
	if not is_instance_valid(room.player):
		return
	portrait.sync_state(room.state,outcome,outcome_time,room.player.invulnerability)
	menu_portrait.sync_state(room.state,outcome,outcome_time,room.player.invulnerability)
	health_label.text = GameLocale.text("VITALITY     %d / %d") % [room.player.health.current,room.player.health.maximum]
	stage_label.text=GameLocale.text("AREA %02d / %02d  ·  %s") % [room.run.stage_index+1,room.stages.size(),GameLocale.text(str(room.stage_def.kind).to_upper())]
	sync_sector_notice(delta)
	room_label.text=str(room.stage_def.name)
	wallet_label.text=GameLocale.text("%d  /  %d") % [room.run.gold,room.profile.starlight]
	inventory_button.text=GameLocale.text("I  ·  Equipment  %d / 18") % room.run.inventory.size()
	inventory_button.disabled=room.state!="playing"
	legacy_button.visible=room.state in ["intro","defeated","cleared","legacy"]
	health_bar.max_value = room.player.health.maximum
	health_bar.value = room.player.health.current
	roll_label.text=GameLocale.text("SHIFT ROLL / ")+GameLocale.text("RECOVERING" if room.player.roll_cooldown>0 else "READY")
	enemy_label.text = "PASSAGE OPEN  ·  ENTER" if room.exit_open else GameLocale.text("%02d foes  ·  passage locked") % room.enemies.size()
	cooldown_label.text = "Fireball  ·  READY" if room.spells.cooldown <= 0 else GameLocale.text("Fireball  ·  %.1fs") % room.spells.cooldown
	debug_label.text = GameLocale.text("F1 NEXT: SUCCESS   F2: MISCAST   F3: OVERREACTION   |   %s") % ("RANDOM" if room.spells.resolver.forced.is_empty() else room.spells.resolver.forced.to_upper())
	if room.state=="playing":
		outcome_time = maxf(0.0,outcome_time-delta)
		incident_time=maxf(0,incident_time-delta)
	incident_label.visible=incident_time>0 and room.state!="intro" and not sector_banner.visible
	incident_label.position.y=580 if str(room.stage_def.kind)=="shop" else 132
	if outcome_time > 0:
		status_label.text = {"success":"SUCCESS  /  Almost professional.","miscast":"MISCAST!  /  Improvise. Quickly.","overreaction":"OVERREACTION  /  A proportionate response."}.get(outcome,"")
		status_label.modulate = Color.WHITE
		status_label.add_theme_color_override("font_color",{"success":Color("4e7857"),"miscast":Color("ad5555"),"overreaction":Color("89608b")}.get(outcome,INK))
	else:
		status_label.text = "PASSAGE OPEN  /  ENTER to continue" if room.exit_open else "A very round cat. A very unreliable wizard."
		status_label.modulate = Color.WHITE
		status_label.add_theme_color_override("font_color",INK)
