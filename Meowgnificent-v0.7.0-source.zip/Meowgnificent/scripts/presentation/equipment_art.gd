class_name EquipmentArt
extends RefCounted

const SHEET: Texture2D = preload("res://art/equipment/storybook_equipment.png")
const RECTS := {
 "crooked_ash_wand":Rect2(53,20,350,463),
 "cinderfork_wand":Rect2(447,16,386,464),
 "apprentice_thesis":Rect2(866,76,369,375),
 "brass_bell_collar":Rect2(18,519,398,316),
 "velvet_bell_collar":Rect2(435,519,389,315),
 "nine_lives_collar":Rect2(839,519,404,324),
 "loose_feather":Rect2(24,844,391,396),
 "warm_sardine_charm":Rect2(433,903,375,307),
 "moonlit_yarn":Rect2(849,875,395,368)
}
static var _icons: Dictionary = {}

static func icon(id: String) -> Texture2D:
 if not RECTS.has(id): return null
 if not _icons.has(id):
  var texture := AtlasTexture.new()
  texture.atlas=SHEET
  texture.region=RECTS[id]
  texture.filter_clip=true
  _icons[id]=texture
 return _icons[id]

# Keep the original slim neckband and replace its pendant. The full collar
# remains visible in inventory; a large strap would obscure the cat's muzzle.
static func worn_icon(id: String) -> Texture2D:
 if not id.ends_with("_collar"): return icon(id)
 var key := "worn:"+id
 if not RECTS.has(id): return null
 if not _icons.has(key):
  var source: Rect2=RECTS[id]
  var texture := AtlasTexture.new()
  texture.atlas=SHEET
  texture.region={"brass_bell_collar":Rect2(148,686,145,145),"velvet_bell_collar":Rect2(552,692,151,145),"nine_lives_collar":Rect2(976,693,149,145)}[id]
  texture.filter_clip=true
  _icons[key]=texture
 return _icons[key]
