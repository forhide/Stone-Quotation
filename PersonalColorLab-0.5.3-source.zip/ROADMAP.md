# Roadmap

The current scope is an offline desktop application. Mobile development is not planned.

## V0.5.3 - RAW reading and style processing (implemented)

- Read sensor dimensions before unpacking; retain strict full AHD analysis/output and cooperative native-stage cancellation.
- Offer an explicit fast Bayer RAW preview with visible approximation/fallback state; final JPG and adaptive XMP settings use strict development.
- Remove duplicate full sensor development from RAW JPG export without changing its measurement preview; retain the existing JPEG decoder-assisted path.
- Precompute exposure/channel mappings and shared-grid curve segments; reuse mask coordinates while preserving pixels on the measured comparison fixtures.
- Guard decoded/measurement/thumbnail reuse by source content and RAW quality and semantic reuse by verified model identity; show unavailable recognition explicitly.
- Keep app/analysis0.5.3, historical snapshots through0.5.2, DB3, analysis/profile schema1 and DNA2/engine0.5.0. PERFORMANCE.md scopes measurements; VALIDATION.md records completed verification.

## V0.5.2 - Faster local processing and a refined photo studio

- Reuse circular color/chroma statistics and avoid expensive palette copies; retain the same analysis values, sample bounds and palette output on the measured inputs.
- Skip unchanged rendering transforms, prepare regional recipes once, and reuse hybrid component baselines/mask coordinates within bounded tiles. Restrict face-color conversion to supported bounds; retain pixel-exact benchmark results.
- Score-filter NanoDet candidates before box regression, skip empty-region filtering and avoid stacked mask tensors. Keep recognition model resolution/thresholds and the measured faster default thread policy.
- Share pair tone correction and batch reference fingerprints while preserving final actual-file verification. Cooperative reference cancellation keeps completed results.
- Add a photo-first studio with a right settings inspector, native-vector sliders/toggles, actual photo-based style tiles, direct wipe dragging, expandable subject/analysis details and a focused export footer.
- Clarify home build/apply routes, three source cards, current workflow steps and counted analysis actions. Preserve selection across language changes and offer folder changes without dropping explicit source choices.
- App/analysis0.5.2, unchanged SQLite3 and DNA2/engine0.5.0; prior analysis snapshots remain readable. PERFORMANCE.md records measured workload-specific timings; VALIDATION.md records release checks.

## V0.5.1 - Review fixes for style learning, rendering and recovery

- Correctly transfer pure monochrome intent from supported RAW/JPG or JPG/JPG comparisons and unanimously gray JPG references. Mixed-color, sepia, clipped and insufficient evidence remain conservative. Historical paired analyses need reanalysis to add the new evidence; reference snapshots already contain the needed appearance statistics.
- Preserve supported monochrome context/region recipes without removing color from unrelated regions. Share bounded preview measurements with full-resolution local rendering to keep component baselines consistent.
- Validate render options before recognition, honor cancellation at neutral/zero strength, preserve unchanged face pixels exactly, and skip unnecessary regional work.
- Encode exports in a private sibling file before publishing the new filename. Cancellation and ordinary failure remove this operation's partial files without replacing another output. Recheck the original after JPEG encoding; validate finite effective XMP values. Filesystems without hard links use an exclusive cancellable copy.
- Treat analysis cache failures as optional recovery, preserving valid results and correct counts. Reanalyze missing-model caches after model repair; validate cached semantic evidence and all model/license/manifest identities together.
- Clear stale photo/evidence on selection failures, preserve mix/composition/name state across language changes, scroll settings over child controls, and retain export locks during redraws and shortcuts.
- App and analysis algorithms0.5.1; SQLite3, analysis/profile schema1 and DNA2/engine0.5.0 remain compatible. Historical0.3/0.4/0.5.0 analysis snapshots stay readable. See VALIDATION.md for final tests, installed checks and platform limits.

## V0.5.0 - Embedded object recognition and a clearer style workspace

- Bundled checksum-verified local NanoDet COCO-80 object detection, PP-HumanSeg person segmentation and YuNet face detection (3,091,271 model bytes). Inference uses OpenCV DNN CPU; no API, token charge, runtime download, login or network client is added.
- Added object-derived context tags, region previews, optional face-color protection and adjustable region strength. Non-person objects use approximate boxes; faces use protection ellipses. These are not face identities or general instance segmentation.
- Learned reference region/context targets require three distinct supported image encodings; image pairs learn observed regional transforms in registered valid overlap. Reference lighting/content confounders remain. Unsupported/missing models withhold semantic evidence explicitly.
- Added visual tone/color fingerprint suggestions, one-click trials, reset, keyboard shortcuts and full-width wipe comparison. Settings move into a scrolling side panel while original/styled previews and exports stay visible; mixing/composition controls are grouped separately.
- JPG exports include local region/face effects. XMP exports remain approximate global presets and do not serialize Adobe semantic masks. Original bytes and GPS exclusion remain intact.
- Refined hybrid region changes to replace only the contributing component effect; stale preview results retain decoded/recognized inputs for the latest adjustment. Neutral/monochrome behavior and mask-tile skipping are verified.
- Style DNA schema2 / engine0.5.0 upgrades legacy0.4.0 schema1 recipes on read; SQLite remains3 and historical analysis profiles remain readable. New0.5 profiles/recipes require the new app.
- Real-model execution and region learning/application passed with network denied using external test-only photos. Tests and native-platform limits are recorded in VALIDATION.md.

## V0.4.0 - Style application, portable recipes and faster analysis

- Unified learned pair transforms, recorded XMP settings, finished-JPG references and bundled profiles into validated Style DNA (schema 1).
- Added a style workspace with original/edited previews, strength adjustment, two-style mixing, 12 derived film/cinema/artist profiles and saved recipes.
- Adapted reference targets to each input's tone distribution; optional low/mid/high-key subprofiles require three distinct supporting images. These are pixel-lighting groups, not semantic scene recognition.
- Added full-resolution JPEG copies with sRGB ICC and stripped EXIF/GPS, Lightroom-importable global XMP presets, and local style JSON import/export. Existing files are never overwritten.
- Composition remains color-only by default; users can show an aspect-ratio guide or explicitly crop an exported copy. No original is cropped.
- Added content-addressed, bounded SQLite analysis caching and pre-decode exact-duplicate exclusion; similar-image groups are review hints and remain included.
- Added analysis snapshot rename/delete, additive database schema 3, source preview reuse and deprecated Pillow API cleanup. Existing schema-0/1/2 data and 0.3.0 analysis snapshots remain readable; older apps cannot open schema 3.
- Corrected color-transform learning to subtract the observed tone transfer before measuring residual color. App/analysis versions are 0.4.0; analysis payload schema remains 1.
- Retained the embedded Mac component fix. Native Mac installation, Apple signing/notarization, semantic scene/local-mask models and exact Adobe rendering remain pending.

## V0.1 - Dataset analyzer (implemented)

- File classification, recursive scan and pair candidates
- Local SQLite library and English/Korean desktop UI

## V0.2 - JPEG comparison and desktop packaging (implemented)

- Similarity alignment, valid overlap, measured tone transfer and Lab/HSV/HSL changes
- Approximate exposure/WB/tint, separate confidence/provenance, source hashes and stale-cache detection
- Direct original/edited JPEG selection, previews, swap, reanalysis, readable summaries and technical detail
- Dark graphite/lime theme, aperture icon, readable point fonts and display scaling
- Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg with verified private runtimes
- Source/GUI/archive/native-smoke tooling; actual native release validation remains separate

## V0.3.0 - Three source routes and saved analysis styles (implemented)

- **RAW + JPG:** sensor decoding with rawpy/LibRaw, explicit camera-WB sRGB baseline and registered inferred changes
- **RAW + XMP:** namespace-whitelisted recorded global settings and RGB tone curves, with unsupported/missing-value limits
- **JPG references:** final-appearance tone/color/chroma/hue/palette metrics without requiring originals
- Reference aggregation with exact duplicate exclusion, equal image weights, dispersion, consistency, appearance outliers and sample-coverage limits
- Folder mode choice, reviewed inclusion/exclusion, manual companion selection, progress/cancellation and individual/collection results
- Named saved analysis snapshots and persistent reopening through additive database schema 2
- English/Korean strings, source preservation, hashes/provenance and bundled RAW dependencies
- Completed validation and artifact evidence are recorded in `VALIDATION.md`

## V0.3.1 - Mac installer component resolution (implemented)

- Correct the embedded component URL in Distribution
- Check selected package resolution and installation-data/identity completeness
- Record the reported M1 installation failure and keep native installation confirmation separate

## Next - Evaluation and application-ready profiles

- Evaluate real camera RAWs, varied sidecars and reference sets; calibrate confidence and failure boundaries
- Compare fast/full RAW color and fine-detail behavior across actual Bayer cameras, X-Trans and unusual CFA/geometry before expanding fast-preview eligibility
- Improve repeated-name pairing, near-duplicate detection and unsupported-camera guidance
- Extend XMP support without implying Adobe render equivalence
- Validate native Windows/macOS installation, GUI, DPI/Retina and monitor transitions; sign/notarize releases
- Evaluate the implemented shared Style DNA against real photographic edits and varied references
- Improve hue-band presentation and estimate sharpening/noise/grain behavior

## Later - Style engine and scene context

- Refine implemented adaptive style application with real-photo evaluation
- Extend the implemented 12-profile library and hybrid controls
- Extend implemented object-derived context tags to scene models covering sky, terrain and lighting.
- Extend person masks/box regions to precise non-person segmentation and subject-aware composition.
- Explicit user choice before geometry changes; no silent cropping

## V1.0 - Offline personal photo editor

- Verified Lightroom-compatible XMP export and refinement workflow
- Local model/update packs with mandatory CPU fallback
- Validated, signed offline desktop installers

V0.4.0 applies styles and exports approximate global XMP presets; native-device and Adobe interoperability evaluation remains required.
