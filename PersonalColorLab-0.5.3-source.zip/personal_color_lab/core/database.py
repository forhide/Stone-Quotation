"""Local library storage. Analysis payloads contain derived data, never GPS."""

import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .models import PhotoRecord, PairCandidate
from .schema_migrations import SCHEMA, SchemaMigrationError, migrate_schema


class AnalysisValidationError(ValueError):
    """An analysis is not a valid, finite, GPS-free JSON payload."""


class AnalysisDataError(ValueError):
    """A stored versioned analysis is corrupt or inconsistent."""


def _path_text(path: Path) -> str:
    value = str(Path(path))
    if value == '.' or '\x00' in value:
        raise AnalysisValidationError('Analysis paths must identify photo files.')
    return value


def _check_json_value(value) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise AnalysisValidationError('Analysis JSON keys must be strings.')
            normalized = ''.join(c for c in key.lower() if c.isalnum())
            if normalized.startswith('gps') or normalized in {
                'latitude', 'longitude', 'lat', 'lon', 'lng', 'geolocation',
            }:
                raise AnalysisValidationError('GPS metadata must not be persisted.')
            _check_json_value(item)
    elif isinstance(value, list):
        for item in value:
            _check_json_value(item)
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise AnalysisValidationError('Analysis numbers must be finite.')
    elif value is not None and not isinstance(value, (str, int, bool)):
        raise AnalysisValidationError('Analysis values must be JSON-native types.')


def _validate_analysis(original: str, edited: str, payload: dict) -> None:
    if not isinstance(payload, dict):
        raise AnalysisValidationError('Analysis payload must be a dictionary.')
    if original == edited:
        raise AnalysisValidationError('Original and edited paths must be different.')
    if payload.get('original_path') != original or payload.get('edited_path') != edited:
        raise AnalysisValidationError('Analysis source paths do not match the selected pair.')
    version = payload.get('schema_version')
    if (
        isinstance(version, bool) or not isinstance(version, int)
        or not 1 <= version <= 2**63 - 1
    ):
        raise AnalysisValidationError('Analysis schema_version must be a positive integer.')
    for field in ('algorithm_version', 'source_type'):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise AnalysisValidationError(f'Analysis {field} must be a nonempty string.')
    if not isinstance(payload.get('status'), str) or payload['status'] not in {
        'ok', 'alignment_failed', 'color_space_uncertain',
    }:
        raise AnalysisValidationError('Analysis status is unsupported.')
    for field in ('provenance', 'alignment', 'tone', 'color', 'lightroom_estimates'):
        if not isinstance(payload.get(field), dict):
            raise AnalysisValidationError(f'Analysis {field} must be a dictionary.')
    warnings = payload.get('warnings')
    if not isinstance(warnings, list) or any(not isinstance(item, str) for item in warnings):
        raise AnalysisValidationError('Analysis warnings must be a list of strings.')
    confidence = payload.get('confidence')
    if (
        isinstance(confidence, bool)
        or not isinstance(confidence, (int, float))
        or not 0 <= confidence <= 1
        or not math.isfinite(confidence)
    ):
        raise AnalysisValidationError('Analysis confidence must be between zero and one.')
    try:
        _check_json_value(payload)
    except RecursionError as exc:
        raise AnalysisValidationError('Analysis payload is cyclic or too deeply nested.') from exc
    _validate_semantic_if_present(payload)


def _reject_constant(value: str):
    raise ValueError(f'Non-finite JSON constant: {value}')


_SOURCE_MODES = {'raw_jpg', 'raw_xmp', 'reference_jpg'}
_SOURCE_BATCH_STATUSES = {'ok', 'partial', 'cancelled', 'failed'}
_SOURCE_RESULT_STATUSES = {
    'ok', 'alignment_failed', 'color_space_uncertain', 'analysis_failed',
    'no_supported_settings', 'error', 'duplicate', 'skipped',
}
_SOURCE_COUNT_FIELDS = {
    'total', 'processed', 'successful', 'failed', 'skipped', 'cancelled', 'duplicates',
}


def _profile_name(name: str) -> str:
    if not isinstance(name, str):
        raise AnalysisValidationError('Source profile name must be a string.')
    name = name.strip()
    if not name or len(name) > 120 or any(ord(character) < 32 for character in name):
        raise AnalysisValidationError('Source profile name must contain 1 to 120 characters.')
    return name


def _utc_timestamp(value, field: str) -> datetime:
    try:
        if not isinstance(value, str):
            raise ValueError('Timestamp is not text.')
        result = datetime.fromisoformat(value)
        if result.tzinfo is None or result.utcoffset() != timezone.utc.utcoffset(result):
            raise ValueError('Timestamp is not UTC.')
    except ValueError as exc:
        raise AnalysisValidationError(f'Source profile {field} must be a UTC timestamp.') from exc
    return result


def _check_source_metadata(value) -> None:
    """Persist extracted measurements, not the original metadata documents."""
    if isinstance(value, dict):
        for key, item in value.items():
            normalized = ''.join(character for character in key.lower() if character.isalnum())
            if normalized in {
                'exif', 'rawexif', 'exifmetadata', 'rawmetadata',
                'xml', 'rawxml', 'xmpxml', 'rawxmp', 'xmpdocument',
            }:
                raise AnalysisValidationError('Raw EXIF and XML metadata must not be persisted.')
            _check_source_metadata(item)
    elif isinstance(value, list):
        for item in value:
            _check_source_metadata(item)
    elif isinstance(value, str) and value.lstrip().startswith((
        '<?xml', '<?xpacket', '<x:xmpmeta', '<xmpmeta', '<rdf:RDF',
    )):
        raise AnalysisValidationError('Raw XML metadata must not be persisted.')


def _validate_semantic_if_present(payload):
    if 'semantic' not in payload:
        return
    from .scene_analysis import validate_semantic_report
    try:
        validate_semantic_report(payload['semantic'])
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        raise AnalysisValidationError('Invalid persisted semantic evidence.') from exc


def _validate_cached_payload(payload):
    """Treat cached records as untrusted; invalid records are disposable."""
    _check_json_value(payload)
    _check_source_metadata(payload)
    if not isinstance(payload, dict) or payload.get('status') != 'ok' or type(payload.get('schema_version')) is not int or payload['schema_version'] != 1:
        raise AnalysisValidationError('Invalid cached analysis header.')
    if payload.get('algorithm_version') != '0.5.3':
        raise AnalysisValidationError('Unsupported cached analysis version.')
    _validate_semantic_if_present(payload)
    fingerprints = payload.get('provenance', {}).get('input_fingerprints', {})
    if not isinstance(fingerprints, dict) or not fingerprints or any(not isinstance(v, str) or len(v) != 64 or any(c not in '0123456789abcdef' for c in v) for v in fingerprints.values()):
        raise AnalysisValidationError('Invalid cached fingerprints.')
    if payload.get('source_type') == 'reference_jpg':
        from .reference_analysis import _valid_reference
        if not _valid_reference(payload):
            raise AnalysisValidationError('Invalid reference cache.')
    elif payload.get('source_type') == 'raw_xmp':
        from .xmp_analysis import _NUMERIC, _BOOLS, _ENUMS, _CURVES
        parameters = payload.get('parameters')
        curves = payload.get('tone_curves')
        if not isinstance(parameters, dict) or not isinstance(curves, dict) or not (parameters or curves):
            raise AnalysisValidationError('Invalid XMP cache.')
        for name, value in parameters.items():
            if name in _NUMERIC:
                low, high, integer, _ = _NUMERIC[name]
                if isinstance(value, bool) or not isinstance(value, (float, int)) or not low <= value <= high or (integer and int(value) != value):
                    raise AnalysisValidationError('Invalid recorded parameter.')
            elif name in _BOOLS:
                if type(value) is not bool: raise AnalysisValidationError('Invalid boolean parameter.')
            elif name in _ENUMS:
                if value not in _ENUMS[name]: raise AnalysisValidationError('Invalid enum parameter.')
            else:
                raise AnalysisValidationError('Unknown recorded parameter.')
        for name, points in curves.items():
            if name not in _CURVES or not isinstance(points, list) or not 2 <= len(points) <= 256:
                raise AnalysisValidationError('Invalid recorded curve.')
            previous = -1
            for point in points:
                if not isinstance(point, list) or len(point) != 2 or any(type(v) is not int or not 0 <= v <= 255 for v in point) or point[0] <= previous:
                    raise AnalysisValidationError('Invalid curve coordinates.')
                previous = point[0]
    else:
        _validate_analysis(payload.get('original_path'), payload.get('edited_path'), payload)


def _validate_source_profile(payload: dict) -> None:
    if not isinstance(payload, dict):
        raise AnalysisValidationError('Source profile payload must be a dictionary.')
    try:
        _check_json_value(payload)
        _check_source_metadata(payload)
    except RecursionError as exc:
        raise AnalysisValidationError('Source profile payload is cyclic or too deeply nested.') from exc
    if type(payload.get('schema_version')) is not int or payload['schema_version'] != 1:
        raise AnalysisValidationError('Source profile schema_version is unsupported.')
    if payload.get('algorithm_version') not in {'0.3.0','0.4.0','0.5.0','0.5.1','0.5.2','0.5.3'}:
        raise AnalysisValidationError('Source profile algorithm_version is unsupported.')
    if not isinstance(payload.get('mode'), str) or payload['mode'] not in _SOURCE_MODES:
        raise AnalysisValidationError('Source profile mode is unsupported.')
    if not isinstance(payload.get('status'), str) or payload['status'] not in _SOURCE_BATCH_STATUSES:
        raise AnalysisValidationError('Source profile status is unsupported.')
    _utc_timestamp(payload.get('analyzed_at_utc'), 'analyzed_at_utc')
    provenance = payload.get('provenance')
    if not isinstance(provenance, dict) or provenance.get('originals_modified') is not False:
        raise AnalysisValidationError('Source profile must preserve original files.')
    results = payload.get('results')
    if not isinstance(results, list):
        raise AnalysisValidationError('Source profile results must be a list.')
    result_counts = dict.fromkeys(('successful', 'failed', 'skipped', 'duplicates'), 0)
    for result in results:
        if not isinstance(result, dict) or not isinstance(result.get('item'), dict):
            raise AnalysisValidationError('Source profile results must identify their source item.')
        status = result.get('status')
        if not isinstance(status, str) or status not in _SOURCE_RESULT_STATUSES:
            raise AnalysisValidationError('Source profile result status is unsupported.')
        item_payload = result.get('payload')
        if item_payload is not None and not isinstance(item_payload, dict):
            raise AnalysisValidationError('Source profile result payload must be a dictionary or null.')
        if item_payload is not None:
            _validate_semantic_if_present(item_payload)
        if status == 'ok':
            if not item_payload:
                raise AnalysisValidationError('Successful source profile results require an analysis.')
            result_counts['successful'] += 1
        elif status == 'duplicate':
            result_counts['duplicates'] += 1
        elif status == 'skipped':
            result_counts['skipped'] += 1
        else:
            result_counts['failed'] += 1
        if 'error_code' in result and not isinstance(result['error_code'], str):
            raise AnalysisValidationError('Source profile error_code must be a string.')
    summary = payload.get('summary')
    if not isinstance(summary, dict):
        raise AnalysisValidationError('Source profile summary must be a dictionary.')
    sample_count = summary.get('sample_count')
    if (
        type(sample_count) is not int or sample_count < 1
        or sample_count != result_counts['successful']
    ):
        raise AnalysisValidationError('Source profiles require at least one successful analysis sample.')
    counts = payload.get('counts')
    if not isinstance(counts, dict) or any(
        type(counts.get(field)) is not int or counts[field] < 0 for field in _SOURCE_COUNT_FIELDS
    ):
        raise AnalysisValidationError('Source profile counts must be nonnegative integers.')
    if (
        counts['processed'] != len(results)
        or counts['total'] != counts['processed'] + counts['cancelled']
        or counts['processed'] != sum(counts[field] for field in result_counts)
        or any(counts[field] != value for field, value in result_counts.items())
    ):
        raise AnalysisValidationError('Source profile counts disagree with the saved results.')
    expected_status = (
        'cancelled' if counts['cancelled'] else
        'partial' if counts['failed'] or counts['skipped'] else 'ok'
    )
    if payload['status'] != expected_status:
        raise AnalysisValidationError('Source profile status disagrees with the saved results.')


def _decode_source_profile(row: tuple) -> dict:
    profile_id, name, mode, encoded, created_at, updated_at = row
    try:
        if _profile_name(name) != name:
            raise ValueError('Stored profile name is not normalized.')
        created = _utc_timestamp(created_at, 'created_at_utc')
        updated = _utc_timestamp(updated_at, 'updated_at_utc')
        if updated < created:
            raise ValueError('Stored profile update precedes creation.')
        payload = json.loads(encoded, parse_constant=_reject_constant)
        _validate_source_profile(payload)
        if mode != payload['mode']:
            raise ValueError('Stored profile header differs from its payload.')
    except (TypeError, ValueError, RecursionError) as exc:
        raise AnalysisDataError(f'Stored source profile row {profile_id} is invalid.') from exc
    return {
        'id': profile_id, 'name': name, 'mode': mode,
        'created_at_utc': created_at, 'updated_at_utc': updated_at,
        'payload': payload,
    }


class LibraryDB:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        try:
            migrate_schema(self.conn)
        except Exception:
            self.conn.close()
            raise

    def replace_scan(self, records: list[PhotoRecord], pairs: list[PairCandidate]):
        with self.conn:
            for r in records:
                self.conn.execute('''
                    INSERT INTO photos(path,ext,kind,size_bytes,width,height,capture_time,camera,lens,fingerprint)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(path) DO UPDATE SET
                        ext=excluded.ext,kind=excluded.kind,size_bytes=excluded.size_bytes,
                        width=excluded.width,height=excluded.height,capture_time=excluded.capture_time,
                        camera=excluded.camera,lens=excluded.lens,fingerprint=excluded.fingerprint
                ''', (str(r.path), r.ext, r.kind, r.size_bytes, r.width, r.height, r.capture_time, r.camera, r.lens, r.fingerprint))
            for p in pairs:
                self.conn.execute('''
                    INSERT INTO pairs(original_path,edited_path,pair_type,confidence,reasons)
                    VALUES(?,?,?,?,?)
                    ON CONFLICT(original_path,edited_path,pair_type) DO UPDATE SET
                        confidence=excluded.confidence,reasons=excluded.reasons
                ''', (str(p.original), str(p.edited), p.pair_type, p.confidence, '; '.join(p.reasons)))

    def save_analysis(self, original_path: Path, edited_path: Path, payload: dict) -> int:
        """Persist one version per pair; repeating that version updates its row."""
        original, edited = _path_text(original_path), _path_text(edited_path)
        _validate_analysis(original, edited, payload)
        try:
            encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, sort_keys=True)
        except (TypeError, ValueError, RecursionError) as exc:
            raise AnalysisValidationError('Analysis could not be encoded as JSON.') from exc
        updated_at = datetime.now(timezone.utc).isoformat(timespec='microseconds')
        with self.conn:
            self.conn.execute('''
                INSERT INTO edit_analysis(
                    original_path, edited_path, source_type, confidence, payload_json,
                    schema_version, algorithm_version, status, updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(original_path, edited_path, schema_version, algorithm_version)
                WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
                DO UPDATE SET source_type=excluded.source_type,
                    confidence=excluded.confidence, payload_json=excluded.payload_json,
                    status=excluded.status, updated_at=excluded.updated_at
            ''', (
                original, edited, payload['source_type'], payload['confidence'], encoded,
                payload['schema_version'], payload['algorithm_version'], payload['status'],
                updated_at,
            ))
            row = self.conn.execute('''
                SELECT id FROM edit_analysis
                WHERE original_path=? AND edited_path=?
                    AND schema_version=? AND algorithm_version=?
            ''', (original, edited, payload['schema_version'], payload['algorithm_version'])).fetchone()
        return row[0]

    def get_analysis(self, original_path: Path, edited_path: Path) -> dict | None:
        """Return the latest saved versioned result, excluding legacy rows.

        Corruption raises AnalysisDataError rather than silently substituting an
        older result, which could misrepresent the selected photos' analysis.
        """
        original, edited = _path_text(original_path), _path_text(edited_path)
        row = self.conn.execute('''
            SELECT id, payload_json, schema_version, algorithm_version,
                status, source_type, confidence
            FROM edit_analysis
            WHERE original_path=? AND edited_path=?
                AND schema_version IS NOT NULL AND algorithm_version IS NOT NULL
            ORDER BY updated_at DESC, id DESC LIMIT 1
        ''', (original, edited)).fetchone()
        if row is None:
            return None
        try:
            payload = json.loads(row[1], parse_constant=_reject_constant)
            _validate_analysis(original, edited, payload)
            if (
                payload['schema_version'] != row[2]
                or payload['algorithm_version'] != row[3]
                or payload['status'] != row[4]
                or payload['source_type'] != row[5]
                or payload['confidence'] != row[6]
            ):
                raise ValueError('Stored analysis header differs from its payload.')
        except (TypeError, ValueError, RecursionError) as exc:
            raise AnalysisDataError(f'Stored analysis row {row[0]} is invalid.') from exc
        return payload

    def save_source_profile(self, name: str, payload: dict) -> int:
        """Save a named analysis snapshot; even identical names create new rows."""
        name = _profile_name(name)
        _validate_source_profile(payload)
        try:
            encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, sort_keys=True)
        except (TypeError, ValueError, RecursionError) as exc:
            raise AnalysisValidationError('Source profile could not be encoded as JSON.') from exc
        now = datetime.now(timezone.utc).isoformat(timespec='microseconds')
        with self.conn:
            cursor = self.conn.execute('''
                INSERT INTO source_profiles(name,mode,payload_json,created_at_utc,updated_at_utc)
                VALUES(?,?,?,?,?)
            ''', (name, payload['mode'], encoded, now, now))
        return cursor.lastrowid

    def list_source_profiles(self) -> list[dict]:
        """Return recent profile metadata, refusing corrupt stored snapshots."""
        rows = self.conn.execute('''
            SELECT id,name,mode,payload_json,created_at_utc,updated_at_utc
            FROM source_profiles ORDER BY updated_at_utc DESC,id DESC
        ''').fetchall()
        profiles = []
        for row in rows:
            profile = _decode_source_profile(row)
            del profile['payload']
            profiles.append(profile)
        return profiles

    def get_source_profile(self, profile_id: int) -> dict | None:
        """Load a saved snapshot with its metadata; never substitute an older row."""
        if type(profile_id) is not int or not 1 <= profile_id <= 2**63 - 1:
            raise AnalysisValidationError('Source profile id must be a positive integer.')
        row = self.conn.execute('''
            SELECT id,name,mode,payload_json,created_at_utc,updated_at_utc
            FROM source_profiles WHERE id=?
        ''', (profile_id,)).fetchone()
        return None if row is None else _decode_source_profile(row)

    def rename_source_profile(self, profile_id: int, name: str) -> bool:
        name = _profile_name(name)
        with self.conn:
            cursor = self.conn.execute('UPDATE source_profiles SET name=?,updated_at_utc=? WHERE id=?',
                (name, datetime.now(timezone.utc).isoformat(), profile_id))
        return cursor.rowcount > 0

    def delete_source_profile(self, profile_id: int) -> bool:
        with self.conn:
            cursor = self.conn.execute('DELETE FROM source_profiles WHERE id=?', (profile_id,))
        return cursor.rowcount > 0

    def get_cached_analysis(self, key: str) -> dict | None:
        row = self.conn.execute('SELECT payload_json FROM analysis_cache WHERE cache_key=?', (key,)).fetchone()
        if row is None:
            return None
        try:
            payload = json.loads(row[0], parse_constant=_reject_constant)
            _validate_cached_payload(payload)
        except (ValueError, TypeError, KeyError, AttributeError, RecursionError):
            with self.conn:
                self.conn.execute('DELETE FROM analysis_cache WHERE cache_key=?', (key,))
            return None
        with self.conn:
            self.conn.execute('UPDATE analysis_cache SET accessed_at_utc=? WHERE cache_key=?',
                              (datetime.now(timezone.utc).isoformat(), key))
        return payload

    def cache_analysis(self, key: str, payload: dict, limit: int = 2000) -> None:
        if not isinstance(key, str) or len(key) != 64 or any(c not in '0123456789abcdef' for c in key):
            raise AnalysisValidationError('Invalid analysis cache key.')
        if type(limit) is not int or not 1 <= limit <= 5000:
            raise AnalysisValidationError('Cache limit must be between 1 and 5000.')
        _validate_cached_payload(payload)
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False)
        if len(encoded.encode('utf-8')) > 2_000_000:
            return
        with self.conn:
            self.conn.execute('''INSERT INTO analysis_cache VALUES(?,?,?)
                ON CONFLICT(cache_key) DO UPDATE SET payload_json=excluded.payload_json,
                accessed_at_utc=excluded.accessed_at_utc''',
                (key, encoded, datetime.now(timezone.utc).isoformat()))
            self.conn.execute('''DELETE FROM analysis_cache WHERE cache_key IN
                (SELECT cache_key FROM analysis_cache ORDER BY accessed_at_utc DESC LIMIT -1 OFFSET ?)''', (limit,))

    def save_style_preset(self, name: str, dna: dict) -> int:
        from .style_dna import validate_dna
        name = _profile_name(name)
        dna=validate_dna(dna)
        _check_json_value(dna)
        now = datetime.now(timezone.utc).isoformat()
        with self.conn:
            cursor = self.conn.execute('INSERT INTO style_presets(name,dna_json,created_at_utc,updated_at_utc) VALUES(?,?,?,?)',
                (name, json.dumps(dna, ensure_ascii=False, allow_nan=False), now, now))
        return cursor.lastrowid

    def list_style_presets(self) -> list[dict]:
        return [dict(zip(('id', 'name'), row)) for row in self.conn.execute('SELECT id,name FROM style_presets ORDER BY updated_at_utc DESC,id DESC')]

    def get_style_preset(self, preset_id: int) -> dict | None:
        from .style_dna import validate_dna
        row = self.conn.execute('SELECT id,name,dna_json FROM style_presets WHERE id=?', (preset_id,)).fetchone()
        if row is None:
            return None
        try:
            dna = json.loads(row[2], parse_constant=_reject_constant)
            dna=validate_dna(dna)
        except (ValueError, TypeError, RecursionError) as exc:
            raise AnalysisDataError('Stored style parameters are invalid.') from exc
        return {'id': row[0], 'name': row[1], 'dna': dna}

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
