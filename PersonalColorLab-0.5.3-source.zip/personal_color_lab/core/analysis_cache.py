"""Content-addressed derived evidence; original photos are never cached/copied."""
import copy
import hashlib
import json


def cache_key(mode, fingerprints, algorithm_version='0.5.3'):
    return hashlib.sha256(json.dumps([mode, algorithm_version, 1, sorted(fingerprints.items())],
                                    separators=(',', ':')).encode()).hexdigest()


def relocate_payload(payload, original, edited, fingerprints):
    payload = copy.deepcopy(payload)
    payload['original_path'] = str(original)
    if edited is not None:
        payload['edited_path'] = str(edited)
    if payload.get('source_type') == 'raw_xmp':
        payload['source_paths'] = {'raw': str(original), 'xmp': str(edited)}
    payload['provenance']['input_fingerprints'] = dict(fingerprints)
    return payload
