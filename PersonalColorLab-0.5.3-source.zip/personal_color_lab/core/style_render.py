"""Bounded-memory CPU style rendering and source-preserving exports."""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import cv2
import numpy as np
from PIL import Image, ImageCms

from .alignment import _read_rgb
from .constants import RAW_EXTENSIONS, JPEG_EXTENSIONS
from .edit_reverse import file_fingerprint
from .style_dna import BANDS, GRID, ZONES, lighting_key, validate_dna

LUMA = np.array([.2126, .7152, .0722], dtype=np.float32)
HUE_CENTERS = np.array([0, 30, 60, 120, 180, 240, 285, 330], dtype=np.float32)


def _check_cancel(cancel_event):
    if cancel_event is not None and cancel_event.is_set():
        raise ValueError('Style operation cancelled.')


def _validate_render_options(strength, composition):
    if not isinstance(strength,(int,float)) or isinstance(strength,bool) or not math.isfinite(strength) or not 0<=strength<=1:
        raise ValueError('Style strength must be between zero and one.')
    if not isinstance(composition,str) or composition not in {'color_only','suggestions','apply_crop'}:
        raise ValueError('Invalid composition choice.')


def read_photo(path, max_dimension=1200, *, raw_quality='baseline', cancel_event=None, decode_metadata=None):
    if raw_quality not in ('baseline','interactive'):
        raise ValueError('Invalid RAW development quality.')
    _check_cancel(cancel_event)
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.suffix.lower() not in RAW_EXTENSIONS | JPEG_EXTENSIONS:
        raise ValueError('Choose a JPEG or supported RAW photo.')
    pixels, dimensions, warnings = _read_rgb(path, max_dimension, decode_metadata,
                                           raw_quality=raw_quality, cancel_event=cancel_event)
    _check_cancel(cancel_event)
    if 'icc_conversion_failed' in warnings:
        raise ValueError('The embedded color profile cannot be verified.')
    return pixels, dimensions


def _measure(pixels):
    # Statistics are bounded independently of full-resolution export size.
    h, w = pixels.shape[:2]
    preview = cv2.resize(pixels, (max(1, round(w * min(1, 1000/max(h,w)))), max(1, round(h * min(1, 1000/max(h,w))))), interpolation=cv2.INTER_AREA)
    rgb = preview.astype(np.float32)/255
    luma = rgb @ LUMA
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    zones = {}
    masks = {'shadows': luma < .25, 'midtones': (luma >= .25)&(luma < .75), 'highlights': luma >= .75}
    for zone, mask in masks.items():
        if mask.mean() > .02:
            zones[zone] = np.mean(lab[mask, 1:], axis=0).tolist()
    quantiles = np.quantile(luma, [.05,.25,.5,.75,.95]).tolist()
    neutral=(hsv[:,:,1]<.2)&(luma>.08)&(luma<.92)
    cast=np.median(lab[neutral,1:],axis=0).tolist() if neutral.mean()>=.02 else [0.,0.]
    return {'quantiles': quantiles, 'saturation': float(hsv[:,:,1].mean()), 'zones': zones,
            'lighting': lighting_key(quantiles[2]),'neutral_cast':cast,'neutral_cast_support':float(neutral.mean())}


def _effective(dna, measurement, scene_report=None):
    if dna['kind'] == 'hybrid':
        children = [(_effective(c['dna'], measurement, scene_report), c['weight']) for c in dna['components']]
        effective = copy.deepcopy(children[0][0])
        for key in ('tone_curve','lab_shift'):
            effective[key] = sum(np.array(d[key])*w for d,w in children).tolist()
        for channel in ('red','green','blue'):
            effective['channel_curves'][channel]=sum(np.array(d['channel_curves'][channel])*w for d,w in children).tolist()
        for key in ('exposure_ev','saturation_scale','vibrance','grain_amount'):
            effective[key] = sum(d[key]*w for d,w in children)
        for zone in ZONES:
            effective['zone_shifts'][zone] = sum(np.array(d['zone_shifts'][zone])*w for d,w in children).tolist()
        for band in BANDS:
            effective['hsl'][band] = {k:sum(d['hsl'][band][k]*w for d,w in children) for k in ('hue','saturation','lightness')}
        ratios = [(d['composition']['aspect_ratio'],w) for d,w in children if d['composition']['aspect_ratio']]
        effective['composition']['aspect_ratio'] = max(ratios,key=lambda p:p[1])[0] if ratios else None
        return effective
    effective = copy.deepcopy(dna)
    target = dna['scene_targets'].get(measurement['lighting'], dna['reference_target'])
    monochrome=dna['saturation_scale']==0
    profile=dna.get('semantic_profile',{})
    if scene_report and profile.get('bundle_id')==scene_report.get('bundle_id'):
        contexts=profile.get('contexts',{})
        supported=[(tag,contexts[tag]) for tag in scene_report['scene_tags'] if tag in contexts]
        if supported:
            context,chosen=max(supported,key=lambda c:c[1]['sample_count'])
            target=chosen['target']
            monochrome=monochrome or 'monochrome_context_'+context in dna['warnings']
    if target:
        # Limit distribution matching to protect a new scene from large shifts.
        x = np.array(measurement['quantiles'])
        y = np.array(target['quantiles'])
        unique, indices = np.unique(x, return_index=True)
        if len(unique) < 3:
            centre = float(x[2])
            desired = float(np.clip(y[2], centre-.2, centre+.2))
            curve = np.interp(GRID, [0, max(.001,min(.999,centre)),1], [0,desired,1])
        else:
            desired = np.clip(y, x-.2, x+.2)
            desired = np.clip(np.maximum.accumulate(desired), 0, 1)
            curve = np.interp(GRID, [0,*unique.tolist(),1], [0,*desired[indices].tolist(),1])
        effective['tone_curve'] = np.maximum.accumulate(np.clip(curve,0,1)).tolist()
        effective['saturation_scale'] = float(np.clip(target['saturation']/max(.08,measurement['saturation']),.65,1.4))
        for zone in ZONES:
            if zone in target['zones'] and zone in measurement['zones']:
                effective['zone_shifts'][zone] = np.clip((np.array(target['zones'][zone])-measurement['zones'][zone])*.5,-6,6).tolist()
        if monochrome:
            effective['saturation_scale']=0.0
            effective['lab_shift']=[0.,0.]
            effective['zone_shifts']={zone:[0.,0.] for zone in ZONES}
    return effective


def prepare_style(pixels, dna):
    dna=validate_dna(dna)
    measurement = _measure(pixels)
    return _effective(dna, measurement), measurement


def composition_box(width, height, aspect_ratio):
    if aspect_ratio is None:
        return None
    if width/height > aspect_ratio:
        new_width, new_height = round(height*aspect_ratio), height
    else:
        new_width, new_height = width, round(width/aspect_ratio)
    left, top = (width-new_width)//2, (height-new_height)//2
    return [left,top,left+new_width,top+new_height]


def _is_neutral_style(effective):
    return (np.array_equal(effective['tone_curve'],GRID) and all(np.array_equal(c,GRID) for c in effective['channel_curves'].values())
        and effective['exposure_ev']==0 and effective['saturation_scale']==1 and effective['vibrance']==0
        and effective['grain_amount']==0 and not any(effective['lab_shift'])
        and not any(any(v) for v in effective['zone_shifts'].values())
        and not any(any(v.values()) for v in effective['hsl'].values()))


def _render_plan(effective):
    """Resolve constant recipe work once, rather than once per sensor tile."""
    active_hsl=[(effective['hsl'][band],centre) for band,centre in zip(BANDS,HUE_CENTERS)
                if any(effective['hsl'][band].values())]
    identity_tone=np.array_equal(effective['tone_curve'],GRID)
    channels=[(index,effective['channel_curves'][channel]) for index,channel in enumerate(('red','green','blue'))
              if not np.array_equal(effective['channel_curves'][channel],GRID)]
    source_levels=np.arange(256,dtype=np.float32)/255
    exposure_lut=None
    if effective['exposure_ev']:
        linear=np.where(source_levels<=.04045,source_levels/12.92,((source_levels+.055)/1.055)**2.4)
        linear*=2**effective['exposure_ev']
        exposure_lut=np.where(linear<=.0031308,linear*12.92,1.055*np.maximum(linear,0)**(1/2.4)-.055)
    return {'neutral':_is_neutral_style(effective),
            'identity_tone':identity_tone,
            'tone_coefficients':_curve_coefficients(effective['tone_curve']),
            'channels':[(index,_curve_coefficients(curve)) for index,curve in channels],
            'channel_luts':({index:np.interp(source_levels,GRID,curve).astype(np.float32) for index,curve in channels}
                            if identity_tone and exposure_lut is None else {}),
            'exposure_lut':exposure_lut,
            'hsl':active_hsl,
            'hsv':effective['saturation_scale']!=1 or effective['vibrance']!=0 or bool(active_hsl),
            'lab_shift':np.array(effective['lab_shift'],dtype=np.float64),
            'zone_shifts':[(zone,np.array(effective['zone_shifts'][zone],dtype=np.float32)) for zone in ZONES
                           if any(effective['zone_shifts'][zone])],
            'lab':any(effective['lab_shift']) or any(any(shift) for shift in effective['zone_shifts'].values())}


def _curve_coefficients(curve):
    # DNA curves share an exact binary-spaced 33-point grid. Preserve the
    # double-precision slope arithmetic used by np.interp; avoid its per-pixel
    # search. The final zero slope makes the upper endpoint exact as well.
    values=np.asarray(curve,dtype=np.float64)
    return values,np.r_[np.diff(values)*32,0.]


def _curve_pixels(pixels,coefficients):
    values,slopes=coefficients
    bounded=np.clip(pixels,0,1)
    indices=(bounded*32).astype(np.int32)
    offsets=bounded-indices.astype(np.float32)/32
    return (values[indices]+slopes[indices]*offsets).astype(np.float32)


def _tile(pixels, effective, strength, row_offset, plan=None):
    plan=_render_plan(effective) if plan is None else plan
    if strength==0 or plan['neutral']:return pixels.copy()
    original = pixels.astype(np.float32)/255
    rgb = original
    if plan['exposure_lut'] is not None:
        # Every tile begins with uint8 source pixels. Demosaic/color decode is
        # already complete, so this256-entry table reproduces the original
        # sRGB exposure arithmetic exactly without sensor-size power arrays.
        rgb=plan['exposure_lut'][pixels]
    # With nonpositive exposure, an identity curve cannot clip over-range RGB.
    # Skip its interpolation and the identity channel curves exactly.
    if not plan['identity_tone'] or effective['exposure_ev']>0:
        luma = rgb @ LUMA
        fitted = _curve_pixels(luma,plan['tone_coefficients'])
        ratio = np.divide(fitted, luma, out=np.ones_like(fitted), where=luma>.0001)
        rgb = np.clip(rgb*ratio[:,:,None],0,1)
        # Lifted black curves remain meaningful without dividing zero-valued pixels.
        rgb += np.maximum(fitted-luma*ratio,0)[:,:,None]
        rgb = np.clip(rgb,0,1)
    if plan['channels'] and rgb is original:rgb=rgb.copy()
    for index,coefficients in plan['channels']:
        rgb[:,:,index]=(plan['channel_luts'][index][pixels[:,:,index]] if index in plan['channel_luts']
                        else _curve_pixels(rgb[:,:,index],coefficients))
    if plan['hsv']:
        hsv = cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV)
        sat = hsv[:,:,1].copy() if effective['vibrance'] or plan['hsl'] else None
        if effective['vibrance']:
            hsv[:,:,1] *= effective['saturation_scale']*(1+effective['vibrance']*(1-sat))
        else:
            hsv[:,:,1] *= effective['saturation_scale']
        if plan['hsl']:
            hue,chromatic=hsv[:,:,0].copy(),sat>.03
            for values,centre in plan['hsl']:
                distance = np.abs((hue-centre+180)%360-180)
                weight = np.maximum(0,1-distance/40)*chromatic
                hsv[:,:,0] += weight*values['hue']
                hsv[:,:,1] *= 1+weight*values['saturation']
                hsv[:,:,2] += weight*values['lightness']
            hsv[:,:,0] %= 360
        hsv[:,:,1:] = np.clip(hsv[:,:,1:],0,1)
        rgb = cv2.cvtColor(hsv,cv2.COLOR_HSV2RGB)
    if plan['lab']:
        lab = cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB)
        luma = np.clip(rgb @ LUMA,0,1)
        zone_weights = {'shadows':np.clip((.5-luma)*2,0,1), 'highlights':np.clip((luma-.5)*2,0,1)}
        zone_weights['midtones'] = 1-zone_weights['shadows']-zone_weights['highlights']
        color_shift = np.empty(lab[:,:,1:].shape,dtype=np.float64)
        color_shift[:]=plan['lab_shift']
        for zone,shift in plan['zone_shifts']:
            color_shift += zone_weights[zone][:,:,None]*shift
        lab[:,:,1:] += color_shift*np.sqrt(np.maximum(0,np.sin(np.pi*luma)))[:,:,None]
        rgb = cv2.cvtColor(lab,cv2.COLOR_LAB2RGB)
    if effective['grain_amount']:
        if rgb is original:rgb=rgb.copy()
        xx=np.arange(rgb.shape[1],dtype=np.uint64)[None,:]
        global_y=np.arange(row_offset,row_offset+rgb.shape[0],dtype=np.uint64)[:,None]
        noise = (((xx*374761393+global_y*668265263+1274126177)^((xx+global_y)*2246822519)) & 65535).astype(np.float32)/65535-.5
        rgb += noise[:,:,None]*effective['grain_amount']*3
    rgb = original+(np.clip(rgb,0,1)-original)*strength
    return np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)


def apply_pixels(pixels, effective, strength=1., composition='color_only', cancel_event=None):
    validate_dna(effective)
    _validate_render_options(strength,composition)
    _check_cancel(cancel_event)
    if pixels.dtype!=np.uint8 or pixels.ndim!=3 or pixels.shape[2]!=3:
        raise ValueError('Invalid source RGB image.')
    plan=_render_plan(effective);neutral=plan['neutral']
    output=pixels.copy() if strength==0 or neutral else np.empty_like(pixels)
    if strength and not neutral:
        rows=max(1,160_000//pixels.shape[1])
        for top in range(0,pixels.shape[0],rows):
            _check_cancel(cancel_event)
            output[top:top+rows]=_tile(pixels[top:top+rows],effective,strength,top,plan)
    _check_cancel(cancel_event)
    box=composition_box(pixels.shape[1],pixels.shape[0],effective['composition']['aspect_ratio'])
    if composition=='apply_crop' and box:
        output=output[box[1]:box[3],box[0]:box[2]].copy()
    return output,box


def _render_regions(original, effective, dna, strength, scene, object_strength, protect_faces, cancel_event, measurement=None):
    from .style_regions import recipes_for_scene,resized_mask_tile,protect_face_colors,mask_tile_coordinates
    from .scene_analysis import region_appearance
    if not isinstance(object_strength,(int,float)) or isinstance(object_strength,bool) or not math.isfinite(object_strength) or not 0<=object_strength<=1:
        raise ValueError('Invalid object-style strength')
    if type(protect_faces) is not bool:raise ValueError('Invalid face protection choice')
    rendered,_=apply_pixels(original,effective,strength,'color_only',cancel_event)
    if strength==0:return rendered
    recipes=recipes_for_scene(dna,scene['report'])
    face_active=protect_faces and bool(np.any(scene['masks']['face']>.1))
    if object_strength==0:recipes={}
    if not recipes and (not face_active or _is_neutral_style(effective)):return rendered
    appearance=region_appearance(original,scene) if recipes else {}
    recipes={region:values for region,values in recipes.items() if region in appearance}
    if not recipes and (not face_active or _is_neutral_style(effective)):return rendered
    # Export renders sensor-size pixels with the preview's adaptation. Use that
    # same measurement for component subtraction; remeasuring the full image
    # can otherwise add a global bias to a region that should replace it.
    whole_measurement=measurement if measurement is not None else _measure(original) if dna['kind']=='hybrid' else None
    components={id(source_dna):effective if source_dna is dna else _effective(source_dna,whole_measurement,scene['report'])
                for recipes_in_region in recipes.values() for _,_,source_dna in recipes_in_region}
    component_plans={key:_render_plan(component) for key,component in components.items()}
    prepared={}
    for region,region_recipes in recipes.items():
        prepared[region]=[]
        for recipe,weight,source_dna in region_recipes:
            local=copy.deepcopy(components[id(source_dna)])
            local['semantic_profile']={'bundle_id':None,'regions':{},'contexts':{}}
            local.update(tone_curve=recipe['tone_curve'],saturation_scale=recipe['saturation_scale'],lab_shift=recipe['lab_shift'],reference_target=recipe['target'],scene_targets={})
            local['zone_shifts']={z:[0.,0.] for z in ZONES}
            local['hsl']={b:{'hue':0.,'saturation':0.,'lightness':0.} for b in BANDS}
            local['exposure_ev']=0
            if recipe['target']:
                target=appearance[region]['target']
                local=_effective(local,dict(target,lighting=measurement_lighting(target)))
            prepared[region].append((local,_render_plan(local),weight,id(source_dna)))
    height,width=original.shape[:2];rows=max(1,160_000//width)
    for top in range(0,height,rows):
        _check_cancel(cancel_event)
        source=original[top:top+rows];global_tile=rendered[top:top+rows].astype(np.float32);tile=global_tile
        coordinates={}
        def mask_tile(region):
            mask=scene['masks'][region]
            if mask.shape not in coordinates:
                coordinates[mask.shape]=mask_tile_coordinates(mask.shape,width,height,top,len(source))
            return resized_mask_tile(mask,width,height,top,len(source),coordinates[mask.shape])
        # A component's global baseline is independent of the region mask.
        # Keep at most the bounded current tile per active hybrid component.
        baselines={}
        for region in ('background','plant','vehicle','animal','food','person','face'):
            if region not in recipes or region not in appearance or object_strength==0:continue
            mask=mask_tile(region)*object_strength
            if not np.any(mask>.001):continue
            delta=np.zeros_like(tile)
            for local,local_plan,weight,component_key in prepared[region]:
                if component_key not in baselines:
                    baselines[component_key]=(global_tile if component_key==id(dna) else
                        _tile(source,components[component_key],strength,top,component_plans[component_key]).astype(np.float32))
                local_pixels=_tile(source,local,strength,top,local_plan)
                delta+=(local_pixels.astype(np.float32)-baselines[component_key])*weight
            alpha=mask[:,:,None]
            tile=tile*(1-alpha)+np.clip(global_tile+delta,0,255)*alpha
        output=np.rint(np.clip(tile,0,255)).astype('uint8')
        if face_active:
            face_mask=mask_tile('face')
            if np.any(face_mask>.001):output=protect_face_colors(source,output,face_mask)
        rendered[top:top+rows]=output
    _check_cancel(cancel_event)
    return rendered


def measurement_lighting(target):
    return lighting_key(target['quantiles'][2])


def _recognition_scene(pixels,cancel_event=None,base_scene=None):
    """Reuse verified model evidence, or retain global styling if unavailable."""
    from .analysis_control import AnalysisCancelledError
    from .scene_analysis import analyze_scene
    from .semantic_models import bundle_id
    try:
        current_bundle=bundle_id()
        if base_scene is not None and base_scene['report']['bundle_id']==current_bundle:
            return base_scene
        return analyze_scene(pixels,cancel_event)
    except AnalysisCancelledError:
        raise
    except (cv2.error,OSError,ValueError):
        _check_cancel(cancel_event)
        return None


def render_preview(path,dna,strength=1.,composition='color_only',cancel_event=None,base=None,recognition=False,object_strength=.7,protect_faces=True,raw_quality='baseline'):
    dna=validate_dna(dna)
    _validate_render_options(strength,composition)
    _check_cancel(cancel_event)
    if type(recognition) is not bool:raise ValueError('Invalid recognition choice')
    if raw_quality not in ('baseline','interactive'):
        raise ValueError('Invalid RAW development quality.')
    path=Path(path).expanduser().resolve(strict=True)
    before=file_fingerprint(path)
    reusable=bool(base and base.get('source_fingerprint')==before
                  and base.get('raw_quality','baseline')==raw_quality)
    decode_metadata={}
    if reusable:
        original,dimensions=base['original'],base['original_dimensions']
        measurement=base['measurement']
        decode_metadata=base.get('raw_decode',{})
        effective=_effective(validate_dna(dna),measurement)
    else:
        original,dimensions=read_photo(path,raw_quality=raw_quality,cancel_event=cancel_event,
                                       decode_metadata=decode_metadata)
        effective,measurement=prepare_style(original,dna)
    scene=None
    if recognition:
        if not isinstance(object_strength,(int,float)) or isinstance(object_strength,bool) or not math.isfinite(object_strength) or not 0<=object_strength<=1:
            raise ValueError('Invalid object-style strength')
        if type(protect_faces) is not bool:raise ValueError('Invalid face protection choice')
        scene=_recognition_scene(original,cancel_event,base.get('scene') if reusable else None)
    if scene is not None:
        effective=_effective(dna,measurement,scene['report'])
        rendered=_render_regions(original,effective,dna,strength,scene,object_strength,protect_faces,cancel_event,measurement=measurement)
        box=composition_box(original.shape[1],original.shape[0],effective['composition']['aspect_ratio'])
        if composition=='apply_crop' and box:rendered=rendered[box[1]:box[3],box[0]:box[2]].copy()
    else:
        rendered,box=apply_pixels(original,effective,strength,composition,cancel_event)
    if file_fingerprint(path)!=before:
        raise ValueError('Input changed during style preview.')
    _check_cancel(cancel_event)
    def clipping(image):
        return float(np.mean(np.any((image<=1)|(image>=254),axis=2)))
    return {'original':original,'rendered':rendered,'effective':effective,'measurement':measurement,
            'source_fingerprint':before,'source_path':str(path),'original_dimensions':list(dimensions),'composition_box':box,
            'clipping_before':clipping(original),'clipping_after':clipping(rendered),
            'style_name':dna['name'],'strength':strength,'composition':composition,'scene':scene,
            'recognition':recognition,'object_strength':object_strength,'protect_faces':protect_faces,
            'raw_quality':raw_quality,
            'raw_decode':decode_metadata if path.suffix.lower() in RAW_EXTENSIONS else None,
            'recognition_unavailable':bool(recognition and scene is None)}


def _write_new(path,writer,cancel_event=None):
    from .export_files import write_new
    return write_new(path,writer,cancel_event)


def export_jpeg(source,destination,dna,strength=1.,composition='color_only',cancel_event=None,expected_fingerprint=None,recognition=False,object_strength=.7,protect_faces=True):
    _validate_render_options(strength,composition)
    _check_cancel(cancel_event)
    source=Path(source).expanduser().resolve(strict=True)
    destination=Path(destination).expanduser().absolute()
    if destination==source or destination.suffix.lower() not in JPEG_EXTENSIONS:
        raise ValueError('Export must be a new JPEG copy.')
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f'Export already exists: {destination}')
    before=file_fingerprint(source)
    if expected_fingerprint and before!=expected_fingerprint:
        raise ValueError('Input changed since preview; preview again.')
    dna=validate_dna(dna)
    if type(recognition) is not bool:raise ValueError('Invalid recognition choice')
    # The RAW baseline previously developed the whole sensor twice: once for
    # a bounded measurement preview and again for the output. Develop it once
    # and derive the identical INTER_AREA preview from those full RGB pixels.
    # JPEG keeps its decoder-assisted preview: replacing JPEG draft/Lanczos
    # resampling with an RGB resize would change its adaptive style target.
    if source.suffix.lower() in RAW_EXTENSIONS:
        full,dimensions=read_photo(source,max_dimension=1_000_000,cancel_event=cancel_event)
        height,width=full.shape[:2]
        factor=min(1.,1200/max(width,height))
        preview=(cv2.resize(full,(max(1,round(width*factor)),max(1,round(height*factor))),
                            interpolation=cv2.INTER_AREA) if factor<1 else full)
    else:
        preview,_=read_photo(source,cancel_event=cancel_event)
        full=None
    effective,measurement=prepare_style(preview,dna)
    scene=None
    if recognition:
        if not isinstance(object_strength,(int,float)) or isinstance(object_strength,bool) or not math.isfinite(object_strength) or not 0<=object_strength<=1:
            raise ValueError('Invalid object-style strength')
        if type(protect_faces) is not bool:raise ValueError('Invalid face protection choice')
        scene=_recognition_scene(preview,cancel_event)
        if scene is not None:effective=_effective(dna,measurement,scene['report'])
    if full is None:
        full,dimensions=read_photo(source,max_dimension=1_000_000,cancel_event=cancel_event)
    if scene is None:
        rendered,box=apply_pixels(full,effective,strength,composition,cancel_event)
    else:
        rendered=_render_regions(full,effective,dna,strength,scene,object_strength,protect_faces,cancel_event,measurement=measurement)
        box=composition_box(full.shape[1],full.shape[0],effective['composition']['aspect_ratio'])
        if composition=='apply_crop' and box:rendered=rendered[box[1]:box[3],box[0]:box[2]].copy()
    if file_fingerprint(source)!=before:
        raise ValueError('Input changed during export.')
    if cancel_event is not None and cancel_event.is_set():
        raise ValueError('Style operation cancelled.')
    recognition_unavailable=bool(recognition and scene is None)
    # Only rendered pixels are needed by the JPEG encoder. Release the full
    # sensor baseline and its preview before allocating the encoder's buffers.
    del full,preview,scene
    profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    def encode(stream):
        Image.fromarray(rendered).save(stream,format='JPEG',quality=95,subsampling=0,icc_profile=profile)
        _check_cancel(cancel_event)
        if file_fingerprint(source)!=before:
            raise ValueError('Input changed during export.')
    _write_new(destination,encode,cancel_event)
    return {'path':str(destination),'dimensions':[rendered.shape[1],rendered.shape[0]],'source_unchanged':True,'gps_exported':False,'composition_applied':bool(composition=='apply_crop' and box),
            'recognition_unavailable':recognition_unavailable}


def export_style_json(destination,dna,cancel_event=None):
    _check_cancel(cancel_event)
    dna=validate_dna(dna)
    encoded=json.dumps(dna,ensure_ascii=False,allow_nan=False,indent=2).encode('utf-8')
    return _write_new(destination,lambda stream:stream.write(encoded),cancel_event)


def export_xmp(destination,dna,effective,strength=1.,cancel_event=None):
    """Export a Lightroom-importable preset for the supported global subset.

    This is an approximate portable recipe, not a reproduction of our Lab/HSV
    renderer. Composition and unavailable local masks are never exported.
    """
    _check_cancel(cancel_event)
    dna=validate_dna(dna)
    effective=validate_dna(effective)
    if not isinstance(strength,(int,float)) or isinstance(strength,bool) or not 0<=strength<=1:
        raise ValueError('Invalid export strength.')
    import uuid
    rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#';crs='http://ns.adobe.com/camera-raw-settings/1.0/'
    ET.register_namespace('rdf',rdf);ET.register_namespace('crs',crs)
    root=ET.Element('{adobe:ns:meta/}xmpmeta')
    description=ET.SubElement(ET.SubElement(root,'{'+rdf+'}RDF'),'{'+rdf+'}Description')
    attrs={'PresetType':'Normal','UUID':uuid.uuid4().hex.upper(),'SupportsColor':'True','SupportsMonochrome':'True','SupportsHighDynamicRange':'False','SupportsNormalDynamicRange':'True','SupportsSceneReferred':'True','SupportsOutputReferred':'True','Version':'15.0','ProcessVersion':'11.0','HasSettings':'True','Exposure2012':f"{effective['exposure_ev']*strength:.4f}",'Saturation':str(round((effective['saturation_scale']-1)*100*strength)),'Vibrance':str(round(effective['vibrance']*100*strength)),'ToneCurveName2012':'Custom'}
    for band in BANDS:
        values=effective['hsl'][band]
        attrs['HueAdjustment'+band.title()]=str(round(np.clip(values['hue']/0.3*strength,-100,100)))
        attrs['SaturationAdjustment'+band.title()]=str(round(values['saturation']*100*strength))
        attrs['LuminanceAdjustment'+band.title()]=str(round(np.clip(values['lightness']*500*strength,-100,100)))
    for zone,label in (('shadows','Shadow'),('midtones','Midtone'),('highlights','Highlight')):
        a,b=np.array(effective['zone_shifts'][zone])+effective['lab_shift']
        color=np.array([[[60,a*3,b*3]]],dtype=np.float32)
        hue=float(cv2.cvtColor(cv2.cvtColor(color,cv2.COLOR_LAB2RGB),cv2.COLOR_RGB2HSV)[0,0,0])
        attrs['ColorGrade'+label+'Hue']=f'{hue:.3f}'
        attrs['ColorGrade'+label+'Sat']=str(round(min(100,math.hypot(a,b)*2*strength)))
    attrs['ColorGradeBlending']='50'
    attrs['GrainAmount']=str(round(min(100,effective['grain_amount']/.0002*strength)))
    attrs['ConvertToGrayscale']='True' if effective['saturation_scale']==0 and strength==1 else 'False'
    if dna['kind']=='recorded_xmp':
        # Absolute camera WB belongs to the supplied recipe, not a recovered
        # offset from the new image; interpolate from As Shot only at full use.
        for key in ('Temperature','Tint'):
            if key in dna['recorded_parameters'] and strength==1:
                attrs[key]=str(round(dna['recorded_parameters'][key]))
                attrs['WhiteBalance']='Custom'
    for key,value in attrs.items():description.set('{'+crs+'}'+key,value)
    name=ET.SubElement(description,'{'+crs+'}Name')
    alt=ET.SubElement(name,'{'+rdf+'}Alt')
    ET.SubElement(alt,'{'+rdf+'}li',{'{http://www.w3.org/XML/1998/namespace}lang':'x-default'}).text=dna['name']
    seq=ET.SubElement(ET.SubElement(description,'{'+crs+'}ToneCurvePV2012'),'{'+rdf+'}Seq')
    curve=GRID+(np.array(effective['tone_curve'])-GRID)*strength
    for x,y in zip(GRID,curve):ET.SubElement(seq,'{'+rdf+'}li').text=f'{round(x*255)}, {round(y*255)}'
    for channel in ('red','green','blue'):
        curve=GRID+(np.array(effective['channel_curves'][channel])-GRID)*strength
        seq=ET.SubElement(ET.SubElement(description,'{'+crs+'}ToneCurvePV2012'+channel.title()),'{'+rdf+'}Seq')
        for x,y in zip(GRID,curve):ET.SubElement(seq,'{'+rdf+'}li').text=f'{round(x*255)}, {round(y*255)}'
    encoded=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    return _write_new(destination,lambda stream:stream.write(encoded),cancel_event)
