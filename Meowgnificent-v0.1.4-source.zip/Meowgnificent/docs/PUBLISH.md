# 자체 실행 배포와 공개 게시

## 현재 상태 — v0.1.3 / Phase 1

Windows x86_64 실행 파일, Linux x86_64 실행 파일, 웹 빌드를 내보냈습니다. 네이티브 파일은 게임 데이터가 내장되어 있어 Godot 에디터나 별도 PCK 파일이 필요하지 않습니다. 직접 제공된 기본형 사진을 바탕으로 새 캐릭터 아트를 반영했습니다. 사용자가 배포 범위를 다운로드 가능한 실행 파일로 확정하여 공개 호스팅 업로드/게시를 진행하지 않습니다.

- Linux: 소스가 없는 별도 폴더에 실행 파일만 복사하여 120프레임 시작 검증 및 그래픽 창 렌더링 확인 완료.
- Web: 실제 Chromium에서 WebAssembly 시작, 자산 로드, 시작/이동/주문/정지 입력 및 렌더링 확인. 자바스크립트/콘솔 오류 없음.
- Windows: 공식 Windows 템플릿으로 내보내기 및 PE x86_64 형식 확인 완료. Wine 10 호환 환경에서 실제 EXE 화면 입력·전투·종료 9개 검사 통과. 실제 Windows PC 검증은 미실시. 코드 서명 없음.
- 소스 기능 검사: Godot에서 기본 28개 + 입력/일시정지/재시작 회귀 26개 통과.

## 실행 파일 받는 사람

각 플랫폼 ZIP을 **압축 해제한 뒤** 실행합니다. Windows는 `Meowgnificent.exe`, Linux는 `Meowgnificent.x86_64`입니다. Godot를 설치할 필요가 없습니다. Windows/Linux 배포본의 안내문을 참고하세요. Web ZIP은 정적 호스팅용이며 HTML을 file://로 직접 열어서는 실행되지 않습니다.

현재 게임은 키보드·마우스를 사용하는 PC용 프로토타입입니다. 휴대폰 전용 조작과 macOS 내보내기는 이번 배포에 포함하지 않았습니다.

## 재빌드

Godot **4.6.3**, Python **3.12+**, curl 및 rg가 필요합니다.

```bash
./build.sh
python3 package.py
```

`setup-exports.sh`가 공식 템플릿을 설치하고 SHA512를 검증합니다. 첫 설치는 약 1.2 GB를 다운로드합니다. 이미 설치된 템플릿이 검증되면 다시 다운로드하지 않습니다. `build.sh`는 기능 검사 후 Windows/Linux/Web release 빌드를 만듭니다. `package.py`는 상위 폴더에 플랫폼별 ZIP·소스 ZIP·SHA256 목록을 생성합니다. 게임과 엔진 라이선스/고지 파일을 동봉합니다.

## itch.io 게시 절차

계정과 게시할 게임 페이지가 필요합니다. `Meowgnificent-v0.1.3-web.zip`을 HTML 게임으로 올려 `This file will be played in the browser`를 켜세요. 권장 뷰포트는 1280×800입니다. Windows/Linux ZIP도 다운로드 항목으로 추가할 수 있습니다. 웹 빌드는 스레드를 사용하지 않아 cross-origin isolation 헤더 설정 없이 호스팅할 수 있습니다.

## GitHub 게시 절차

게임 전용 저장소와 GitHub API 쓰기/업로드 권한이 필요합니다. 기존 `Stone-Quotation`에는 게임을 게시하지 않습니다.

1. 소스를 새 게임 저장소에 커밋합니다. `.local`, `.godot`, `exports`는 제외합니다.
2. GitHub Release에 네이티브 ZIP과 SHA256 목록을 첨부합니다.
3. Web ZIP 내부 파일을 Pages의 게시 폴더 또는 Pages 배포 아티팩트로 업로드합니다. `.nojekyll`을 보존합니다.
4. 실제 공개 URL에서 시작·이동·주문을 다시 검증한 후 게시 완료로 기록합니다.

현재 Git HTTPS 읽기는 성공하지만 GitHub API 도메인은 네트워크 정책으로 차단되었습니다. `api.github.com` 추가 요구를 환경 설정 초안에 저장했으며, 초안 저장은 런타임 적용이나 게임 게시를 뜻하지 않습니다. 쓰기 권한은 별도 검증이 필요합니다. 인증 값은 채팅이나 저장소에 넣지 않습니다.

## 캐릭터 아트 상태

기본형 사진 기반의 새 고해상도 투명 캐릭터 아트를 적용했습니다. 구체적인 특징, 원본과의 차이, Instagram 계정의 접근 제한은 [ART_REFERENCE.md](ART_REFERENCE.md)에 기록했습니다. 계정의 직접 열람은 차단되어 있지만 사용자가 제공한 계정 캡처는 네 가지 표정 초상화의 기준으로 반영했습니다. 원계정 전체를 확인한 것은 아닙니다.
