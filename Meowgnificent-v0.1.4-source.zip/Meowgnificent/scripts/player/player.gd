class_name WizardCat
extends CharacterBody2D

signal hurt
var config: Dictionary
var health: CombatHealth
var bounds: Rect2
var aim := Vector2.RIGHT
var invulnerability := 0.0
var wobble := 0.0
var cast_pose := 0.0
var active := true
var presentation_scale := 1.0
var floor_point: Vector2:
	get: return position

func setup(settings: Dictionary, room_bounds: Rect2) -> void:
	config = settings
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	collision_layer = 1
	collision_mask = 0
	var shape := CircleShape2D.new()
	shape.radius = float(config.radius)
	var collider := CollisionShape2D.new()
	collider.shape = shape
	add_child(collider)

func _physics_process(delta: float) -> void:
	if not active:
		velocity = Vector2.ZERO
		queue_redraw()
		return
	invulnerability = maxf(0.0, invulnerability - delta)
	cast_pose = maxf(0.0, cast_pose - delta * 3.5)
	var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	var rate := float(config.acceleration) if direction != Vector2.ZERO else float(config.friction)
	velocity = velocity.move_toward(direction * float(config.speed), rate * delta)
	move_and_slide()
	var radius := float(config.radius)
	position = position.clamp(bounds.position + Vector2.ONE * radius, bounds.end - Vector2.ONE * radius)
	var mouse_direction := get_global_mouse_position() - global_position
	if mouse_direction.length_squared() > 4:
		aim = mouse_direction.normalized()
	wobble += delta * velocity.length() * 0.055
	queue_redraw()

func take_damage(amount: int, source: Vector2) -> void:
	if not active or invulnerability > 0.0:
		return
	if health.damage(amount):
		invulnerability = float(config.invulnerability)
		velocity += (position - source).normalized() * 180.0
		hurt.emit()

func _ready() -> void:
	add_child(WizardCatVisual.new())

func _draw() -> void:
	draw_set_transform(Vector2.ZERO)
	var shadow_size := Vector2(34,10)*presentation_scale
	var points := PackedVector2Array()
	for i in range(40):
		var a := TAU*i/40.0
		points.append(Vector2(0,9)+Vector2(cos(a),sin(a))*shadow_size)
	draw_colored_polygon(points,Color(0.025,0.025,0.04,0.45))
	modulate.a = 0.5 if invulnerability>0 and fmod(invulnerability,0.14)<0.07 else 1.0
	if active:
		var center := Vector2(0,-22)
		draw_arc(center,66,aim.angle()-0.09,aim.angle()+0.09,10,Color(0.9,0.85,0.7,0.55),1.5,true)
