class_name CandleSlime
extends Node2D

signal defeated(enemy: CandleSlime)
var config: Dictionary
var health: CombatHealth
var target: WizardCat
var bounds: Rect2
var cooldown := 0.0
var hit_flash := 0.0
var time := 0.0
var knockback := Vector2.ZERO
var active := true

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	config = settings
	target = player
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	health.died.connect(func(): defeated.emit(self); queue_free())
	time = position.x

func _physics_process(delta: float) -> void:
	if not active or not is_instance_valid(target) or not target.active:
		return
	time += delta
	cooldown = maxf(0, cooldown-delta)
	hit_flash = maxf(0,hit_flash-delta)
	if active and is_instance_valid(target) and target.active and health.current > 0:
		var direction := (target.position-position).normalized()
		position += (direction*float(config.speed)+knockback)*delta
		position = position.clamp(bounds.position+Vector2.ONE*20,bounds.end-Vector2.ONE*20)
		knockback = knockback.move_toward(Vector2.ZERO,delta*550)
		if position.distance_to(target.position) < float(config.radius) + float(target.config.radius) and cooldown <= 0:
			target.take_damage(int(config.contact_damage),position)
			cooldown = float(config.attack_cooldown)
	queue_redraw()

func take_damage(amount: int, direction: Vector2) -> void:
	if health.damage(amount):
		hit_flash = 0.15
		knockback = direction * 240.0

func _draw() -> void:
	draw_set_transform(Vector2(0,5),0,Vector2(1,0.35))
	draw_circle(Vector2.ZERO,25,Color(0,0,0,0.3))
	draw_set_transform(Vector2(0,-12),sin(time*4)*0.08,Vector2(1.15,0.85+sin(time*4)*0.08))
	draw_circle(Vector2.ZERO,21,Color("fff4d7") if hit_flash > 0 else Color("92bcac"))
	draw_circle(Vector2(-6,-4),3,Color("243c42"))
	draw_circle(Vector2(6,-4),3,Color("243c42"))
	draw_line(Vector2(-3,5),Vector2(3,5),Color("3b5f5d"),2)
	draw_set_transform(Vector2.ZERO)
	draw_style_box(_candle_style(),Rect2(-6,-47,12,23))
	draw_circle(Vector2(0,-53),8+sin(time*10),Color(1,0.65,0.28,0.18))
	draw_circle(Vector2(sin(time*5)*2,-53),4,Color("ffd88a"))
	if health.current < health.maximum:
		draw_line(Vector2(-20,-66),Vector2(20,-66),Color("283b43"),3)
		draw_line(Vector2(-20,-66),Vector2(-20+40*float(health.current)/health.maximum,-66),Color("c8e0b4"),3)

func _candle_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color("e6ce9b")
	style.set_corner_radius_all(3)
	return style
