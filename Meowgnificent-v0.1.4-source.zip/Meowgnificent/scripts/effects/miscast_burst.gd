class_name MiscastBurst
extends Node2D

var room: Node2D
var age := 0.0
const DURATION := 1.05

func _ready() -> void:
	z_index = 20

func _process(delta: float) -> void:
	if room.state != "playing":
		return
	age += delta
	if age >= DURATION:
		queue_free()
	queue_redraw()

func _draw() -> void:
	var fade := clampf((DURATION-age)/0.35,0.0,1.0)
	# Distinct grey smoke clouds rising around the cat's paws and belly.
	for i in range(9):
		var angle := TAU*i/9.0
		var p := Vector2.from_angle(angle)*(12+age*35)+Vector2(0,-27-age*24)
		var c := Color("565763") if i%2==0 else Color("96939d")
		c.a = fade*0.62
		draw_circle(p,8+age*13,c)
	# Crooked sparks immediately snap apart as the spell collapses.
	if age<0.4:
		for i in range(5):
			var d := Vector2.from_angle(TAU*i/5.0+0.3)
			var p := Vector2(0,-38)+d*(23+age*50)
			draw_polyline(PackedVector2Array([p,p+d*8+Vector2(4,-6),p+d*16]),Color(1,0.5,0.46,1-age/0.4),2,true)
	var center := Vector2(0,-105-age*12)
	var red := Color(1,0.38,0.34,fade)
	# Shape + explicit text also distinguish failure without relying on color.
	draw_circle(center,13,Color(0.12,0.10,0.15,fade*0.95))
	draw_line(center-Vector2(6,6),center+Vector2(6,6),red,4,true)
	draw_line(center+Vector2(-6,6),center+Vector2(6,-6),red,4,true)
	var font := ThemeDB.fallback_font
	var text := "FIZZLE!"
	var at := center+Vector2(-font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,20).x*0.5,-22)
	draw_string_outline(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,20,5,Color(0.08,0.07,0.10,fade))
	draw_string(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color(1,0.67,0.60,fade))
