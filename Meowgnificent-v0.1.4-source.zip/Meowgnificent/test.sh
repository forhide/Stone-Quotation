#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
CHECK_LOG="$(mktemp)"
trap 'rm -f "$CHECK_LOG"' EXIT
"$PROJECT_DIR/run.sh" --headless --editor --import --quit > "$CHECK_LOG" 2>&1
cat "$CHECK_LOG"
if rg -q 'SCRIPT ERROR:|ERROR:' "$CHECK_LOG"; then exit 1; fi
"$PROJECT_DIR/run.sh" --headless --script res://tests/smoke.gd > "$CHECK_LOG" 2>&1
cat "$CHECK_LOG"
if rg -q 'SCRIPT ERROR:|ERROR:' "$CHECK_LOG"; then exit 1; fi

"$PROJECT_DIR/run.sh" --headless --script res://tests/regression.gd > "$CHECK_LOG" 2>&1
cat "$CHECK_LOG"
if rg -q 'SCRIPT ERROR:|ERROR:' "$CHECK_LOG"; then exit 1; fi
