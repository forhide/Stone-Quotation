extends SceneTree

var checks := 0
var failures := 0

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + message)
	else:
		print("PASS: " + message)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var scene := load("res://scenes/main.tscn") as PackedScene
	var room = scene.instantiate()
	root.add_child(room)
	await process_frame
	check(room.state=="intro" and not room.player.active,"intro blocks combat")
	check(room.enemies.size()==5,"five enemies spawned")
	check(room.hud.overlay.visible,"start overlay visible")
	var portrait: CatPortrait = room.hud.portrait
	check(portrait.faces.size()==4 and portrait.faces[3].region.end==CatPortrait.SHEET.get_size(),"four expression atlas cells cover sheet")
	portrait.sync_state("playing","",0,0)
	check(portrait.expression=="neutral","idle uses deadpan portrait")
	portrait.sync_state("playing","miscast",1,0)
	check(portrait.expression=="annoyed","miscast uses annoyed portrait")
	portrait.sync_state("playing","overreaction",1,0)
	check(portrait.expression=="startled","overreaction uses startled portrait")
	portrait.sync_state("playing","success",1,0.4)
	check(portrait.expression=="startled","damage reaction takes precedence over successful cast")
	portrait.sync_state("paused","overreaction",1,0.4)
	check(portrait.expression=="sleepy","pause uses sleepy portrait over combat reactions")
	portrait.sync_state("defeated","miscast",1,0)
	check(portrait.expression=="sleepy","defeat uses resting portrait")
	portrait.sync_state("playing","miscast",0,0)
	check(portrait.expression=="neutral","expired reaction returns to deadpan")
	var resolver := SpellOutcomeResolver.new()
	resolver.rng.seed = 101
	var counts := {"success":0,"miscast":0,"overreaction":0}
	for i in range(10000):
		counts[resolver.resolve(room.balance.fireball)] += 1
	check(absi(counts.success-7000)<200 and absi(counts.miscast-2000)<200 and absi(counts.overreaction-1000)<150,"seeded 10,000-cast distribution follows 70/20/10")
	resolver.forced="miscast"
	check(resolver.resolve(room.balance.fireball)=="miscast" and resolver.forced.is_empty(),"debug override is consumed once")
	room.begin_or_restart()
	check(room.state=="playing" and room.player.active and not room.hud.overlay.visible,"start activates room")
	# Keep enemies stationary except during the chase/contact checks below.
	for enemy in room.enemies:
		enemy.active=false
	var start: Vector2 = room.player.position
	Input.action_press("move_right")
	for i in range(20): await physics_frame
	Input.action_release("move_right")
	check(room.player.position.x>start.x+20,"movement input accelerates cat")
	room.player.position = Vector2(1170,400)
	Input.action_press("move_right")
	for i in range(30): await physics_frame
	Input.action_release("move_right")
	check(room.player.position.x<=room.bounds.end.x-float(room.player.config.radius),"room boundary contains cat")
	room.player.velocity=Vector2.ZERO
	room.player.position=Vector2(500,420)
	var enemy: CandleSlime = room.enemies[0]
	enemy.position=Vector2(680,420)
	enemy.active=true
	var old_distance := enemy.position.distance_to(room.player.position)
	for i in range(15): await physics_frame
	check(enemy.position.distance_to(room.player.position)<old_distance,"enemy chases player")
	enemy.active=false
	enemy.position=Vector2(680,420)
	room.spells.resolver.forced="success"
	check(room.spells.cast(Vector2.RIGHT),"normal fireball emitted")
	check(not room.spells.cast(Vector2.RIGHT),"cooldown prevents immediate recast")
	for i in range(30): await physics_frame
	check(enemy.health.current==20,"projectile collision deals 20 damage")
	for child in room.projectiles.get_children(): child.queue_free()
	await process_frame
	room.spells.cooldown=0
	room.spells.resolver.forced="miscast"
	room.spells.resolver.rng.seed=9
	check(room.spells.cast(Vector2.RIGHT) and room.spells.last_outcome=="miscast","forced miscast executes")
	check(room.projectiles.get_child_count()>0 or room.effects.size()>0,"miscast produces projectile or area effect")
	for child in room.projectiles.get_children(): child.queue_free()
	await process_frame
	room.spells.cooldown=0
	enemy.position=Vector2(680,420)
	var second: CandleSlime = room.enemies[1]
	second.position=Vector2(690,470)
	room.spells.resolver.forced="overreaction"
	room.spells.cast(Vector2.RIGHT)
	for i in range(45): await physics_frame
	check(room.enemies.size()==3,"giant fireball applies explosion to multiple enemies")
	var contact: CandleSlime = room.enemies[0]
	contact.position=room.player.position+Vector2(10,0)
	contact.active=true
	for i in range(3): await physics_frame
	check(room.player.health.current==88,"contact deals configured damage")
	room.player.take_damage(12,contact.position)
	check(room.player.health.current==88,"invulnerability blocks repeated damage")
	room.set_running(false)
	var paused_position: Vector2=contact.position
	for i in range(5): await physics_frame
	check(contact.position==paused_position and not room.player.active,"pause freezes combat")
	room.set_running(true)
	room.player.invulnerability=0
	room.player.take_damage(999,Vector2.ZERO)
	check(room.state=="defeated" and room.hud.overlay.visible,"death ends study and displays retry")
	room.free()
	await process_frame
	room=scene.instantiate()
	root.add_child(room)
	await process_frame
	room.begin_or_restart()
	for foe in room.enemies.duplicate(): foe.take_damage(999,Vector2.RIGHT)
	check(room.state=="cleared" and room.hud.overlay.visible and not room.player.active,"last enemy triggers clear screen")
	room.free()
	print("RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
