class_name SectorBanner
extends PanelContainer

# A short, non-modal arrival card. It never captures movement or mouse input.
var mode := "arrival"
var stage_index := 0
var stage_total := 8
var elapsed := 0.0
var duration := 2.4
var title_label: Label
var name_label: Label
var detail_label: Label
var accent := Color("9e7950")
const REST_POSITION := Vector2(350,126)

func _ready() -> void:
	position=REST_POSITION
	size=Vector2(580,112)
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	z_index=30
	var style := StyleBoxFlat.new()
	style.bg_color=Color("fff8e8")
	style.border_color=accent
	style.border_width_left=7
	style.border_width_top=2
	style.border_width_right=2
	style.border_width_bottom=2
	style.set_corner_radius_all(16)
	style.shadow_color=Color(0.35,0.27,0.20,0.12)
	style.shadow_size=4
	style.shadow_offset=Vector2(0,3)
	style.content_margin_left=22
	style.content_margin_right=22
	style.content_margin_top=12
	style.content_margin_bottom=12
	add_theme_stylebox_override("panel",style)
	var box := VBoxContainer.new()
	box.mouse_filter=Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation",3)
	add_child(box)
	title_label=make_label(12,accent)
	name_label=make_label(26,Color("654e45"))
	detail_label=make_label(13,Color("7a6b5e"))
	box.add_child(title_label)
	box.add_child(name_label)
	box.add_child(detail_label)
	hide()

func make_label(font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size",font_size)
	label.add_theme_color_override("font_color",color)
	return label

func announce_arrival(index: int, total: int, definition: Dictionary, foes: int) -> void:
	mode="arrival"
	stage_index=index
	stage_total=total
	elapsed=0.0
	duration=2.4
	title_label.text="ENTERING AREA %02d / %02d" % [index+1,total]
	name_label.text=str(definition.name)
	match str(definition.kind):
		"shop":
			accent=Color("8c8153")
			detail_label.text="SHOP  ·  A safe stop. E: browse Nib's wares. ENTER: continue."
		"final":
			accent=Color("b47768")
			detail_label.text="FINAL EXAM  ·  Defeat all %d foes to complete the expedition." % foes
		"tutorial":
			accent=Color("9e7950")
			detail_label.text="TUTORIAL  ·  Defeat %d foes. The east passage opens when clear." % foes
		_:
			accent=Color("7b7fa3")
			detail_label.text="COMBAT  ·  Defeat %d foes, gather drops, then take the east passage." % foes
	apply_accent()
	show()

func announce_clear(index: int, total: int, next_name: String) -> void:
	mode="cleared"
	stage_index=index
	stage_total=total
	elapsed=0.0
	duration=3.2
	accent=Color("64866a")
	title_label.text="AREA %02d / %02d COMPLETE" % [index+1,total]
	name_label.text="PASSAGE OPEN"
	detail_label.text="Gather your drops. ENTER → %02d / %02d  ·  %s" % [index+2,total,next_name]
	apply_accent()
	show()

func apply_accent() -> void:
	var style := get_theme_stylebox("panel") as StyleBoxFlat
	style.border_color=accent
	title_label.add_theme_color_override("font_color",accent)
	modulate.a=0.0
	position=REST_POSITION+Vector2(0,-10)

func tick(delta: float, playing: bool) -> void:
	if not playing or elapsed>=duration:
		hide()
		return
	show()
	elapsed=minf(elapsed+delta,duration)
	var enter := clampf(elapsed/0.18,0.0,1.0)
	var leave := clampf((duration-elapsed)/0.35,0.0,1.0)
	modulate.a=minf(enter,leave)
	position=REST_POSITION+Vector2(0,-10.0*(1.0-enter))
