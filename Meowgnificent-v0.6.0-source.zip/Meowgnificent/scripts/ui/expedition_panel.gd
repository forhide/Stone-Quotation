class_name ExpeditionPanel
extends CanvasLayer

const INK := Color("654e45")
const MUTED := Color("7c6c60")
const GOLD := Color("806348")
const SLOT_NAMES := {"wand":"WAND", "collar":"COLLAR", "charm":"CHARM"}
const STAT_NAMES := {
	"max_hp_bonus":"Max vitality", "speed_bonus":"Move speed",
	"spell_damage_bonus":"Spell damage", "spell_cooldown_multiplier":"Spell recovery",
	"roll_damage_bonus":"Roll damage", "roll_cooldown_multiplier":"Roll recovery",
	"pickup_radius_bonus":"Pickup reach"
}

var room: Node2D
var mode := "inventory"
var is_open := false
var screen: Control
var heading: Label
var subtitle: Label
var gold_label: Label
var content: VBoxContainer
var notice: Label
var close_button: Button
var purchase_buttons: Array[Button] = []
var feedback := ""
var feedback_color := MUTED

func _ready() -> void:
	layer=20
	screen=Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter=Control.MOUSE_FILTER_STOP
	add_child(screen)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color=Color(0.90,0.87,0.75,0.68)
	shade.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(shade)
	var panel := PanelContainer.new()
	panel.position=Vector2(110,72)
	panel.size=Vector2(1060,656)
	panel.add_theme_stylebox_override("panel",_style(Color("fff7e6"),Color("c3a286"),22,25))
	screen.add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation",13)
	panel.add_child(column)
	var eyebrow := _label("THE CANDLEWICK EXPEDITION",12,GOLD)
	column.add_child(eyebrow)
	var header := HBoxContainer.new()
	column.add_child(header)
	heading=_label("Traveling possessions",30,INK)
	heading.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	header.add_child(heading)
	gold_label=_label("",23,GOLD)
	header.add_child(gold_label)
	subtitle=_label("",14,MUTED)
	column.add_child(subtitle)
	var rule := HSeparator.new()
	rule.add_theme_stylebox_override("separator",_style(Color("dfcfb5"),Color("dfcfb5"),0,0))
	column.add_child(rule)
	content=VBoxContainer.new()
	content.custom_minimum_size=Vector2(0,423)
	content.size_flags_vertical=Control.SIZE_EXPAND_FILL
	column.add_child(content)
	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation",18)
	column.add_child(footer)
	notice=_label("",13,MUTED)
	notice.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	notice.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	footer.add_child(notice)
	close_button=_button("Return to the archives  /  ESC",false)
	close_button.custom_minimum_size=Vector2(295,42)
	close_button.pressed.connect(_request_close)
	footer.add_child(close_button)
	screen.hide()

func open_inventory() -> void:
	mode="inventory"
	_open()

func open_shop() -> void:
	mode="shop"
	_open()

func open_meta() -> void:
	mode="meta"
	_open()

func _open() -> void:
	is_open=true
	feedback=""
	feedback_color=MUTED
	screen.show()
	refresh()
	close_button.grab_focus()

func close() -> void:
	is_open=false
	if is_instance_valid(screen): screen.hide()

func refresh() -> void:
	if not is_instance_valid(content) or not is_instance_valid(room): return
	for child in content.get_children():
		content.remove_child(child)
		child.queue_free()
	purchase_buttons.clear()
	gold_label.text="%d  STARLIGHT" % room.profile.starlight if mode=="meta" else "%d  CROWNS" % room.run.gold
	if mode=="meta":
		heading.text="Legacy Study"
		subtitle.text="Retained after defeat. Your studies strengthen the next expedition.\n%d expeditions  ·  %d clears  ·  Furthest sector %d" % [room.profile.attempts,room.profile.wins,room.profile.best_sector]
		_build_meta()
	elif mode=="shop":
		heading.text="The merchant's alcove"
		subtitle.text="Spend your finds before the next fight. Purchases stay with this expedition."
		_build_shop()
	else:
		heading.text="Traveling possessions"
		subtitle.text="Choose one wand, collar and charm. Found gear waits in your bag until you equip it."
		_build_inventory()
	var hint := "I or ESC return  ·  Equipment changes apply immediately"
	if mode=="shop": hint="1–4 purchase  ·  ESC return"
	elif mode=="meta": hint="1–4 study  ·  M or ESC return  ·  Applies to the next expedition"
	notice.text=feedback if not feedback.is_empty() else hint
	notice.modulate=feedback_color if not feedback.is_empty() else MUTED

func _build_inventory() -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",22)
	row.size_flags_vertical=Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var equipped := VBoxContainer.new()
	equipped.custom_minimum_size=Vector2(302,0)
	equipped.add_theme_constant_override("separation",10)
	row.add_child(equipped)
	equipped.add_child(_label("EQUIPPED  /  3 SLOTS",12,GOLD))
	for slot in ["wand","collar","charm"]:
		equipped.add_child(_equipped_card(slot))
	var bag := VBoxContainer.new()
	bag.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	bag.add_theme_constant_override("separation",10)
	row.add_child(bag)
	bag.add_child(_label("SATCHEL  /  %d OF 18" % room.run.inventory.size(),12,GOLD))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(0,385)
	scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	bag.add_child(scroll)
	var items := VBoxContainer.new()
	items.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	items.add_theme_constant_override("separation",9)
	scroll.add_child(items)
	if room.run.inventory.is_empty():
		var empty := _card(Color("fffaef"),Color("ccb99e"),20)
		items.add_child(empty)
		var text := _label("A little room for magnificent things.\n\nDefeated enemies may drop equipment.\nWalk over it to put it in your satchel.",17,MUTED)
		text.custom_minimum_size=Vector2(0,140)
		text.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		empty.add_child(text)
	else:
		for item_id in room.run.inventory:
			items.add_child(_bag_card(str(item_id)))

func _equipped_card(slot: String) -> PanelContainer:
	var id := str(room.run.equipment.get(slot,""))
	var item: Dictionary=room.run.item_info(id)
	var card := _card(Color("f0f3e4"),Color("b6bf9b"),13)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",5)
	card.add_child(box)
	box.add_child(_label(str(SLOT_NAMES[slot]),11,GOLD))
	var name_label := _label(str(item.get("name","Nothing equipped")),17,_rarity_color(str(item.get("rarity","common"))))
	name_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(name_label)
	var desc := _label(_stats_text(item.get("stats",{})) if not id.is_empty() else "An opportunity for improvement.",12,MUTED)
	desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(desc)
	if not id.is_empty():
		var remove := _button("Put away",true)
		remove.custom_minimum_size=Vector2(0,28)
		remove.pressed.connect(_unequip.bind(slot))
		box.add_child(remove)
	return card

func _bag_card(id: String) -> PanelContainer:
	var item: Dictionary=room.run.item_info(id)
	var slot := str(item.get("slot",""))
	var equipped_id := str(room.run.equipment.get(slot,""))
	var wearing := id==equipped_id
	var rarity := str(item.get("rarity","common"))
	var card := _card(Color("e2edd7") if wearing else Color("fffaef"),_rarity_color(rarity).lightened(0.32),13)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",13)
	card.add_child(row)
	var text := VBoxContainer.new()
	text.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	text.add_theme_constant_override("separation",4)
	row.add_child(text)
	text.add_child(_label("%s  /  %s" % [rarity.to_upper(),str(SLOT_NAMES.get(slot,slot))],10,_rarity_color(rarity)))
	var name_label := _label(str(item.get("name",id)),18,INK)
	name_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	text.add_child(name_label)
	var desc := _label(str(item.get("description","")),13,MUTED)
	desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	text.add_child(desc)
	if not wearing:
		var delta := _label(_comparison_text(item,equipped_id),12,Color("6b795e"))
		delta.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		text.add_child(delta)
	var button := _button("Equipped" if wearing else "Equip",wearing)
	button.custom_minimum_size=Vector2(100,38)
	button.size_flags_vertical=Control.SIZE_SHRINK_CENTER
	button.disabled=wearing or slot.is_empty()
	button.pressed.connect(_equip.bind(id))
	row.add_child(button)
	return card

func _build_shop() -> void:
	var grid := GridContainer.new()
	grid.columns=2
	grid.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	grid.size_flags_vertical=Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation",16)
	grid.add_theme_constant_override("v_separation",14)
	content.add_child(grid)
	for index in range(room.shop_offers.size()):
		grid.add_child(_offer_card(index,room.shop_offers[index]))
	if room.shop_offers.is_empty():
		content.add_child(_label("The merchant has packed up. Perhaps farther into the archives.",18,MUTED))

func _build_meta() -> void:
	var grid := GridContainer.new()
	grid.columns=2
	grid.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	grid.size_flags_vertical=Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation",16)
	grid.add_theme_constant_override("v_separation",14)
	content.add_child(grid)
	var offers: Array=room.profile.upgrade_offers()
	for index in range(offers.size()):
		var offer: Dictionary=offers[index]
		grid.add_child(_upgrade_card(index,offer))

func _upgrade_card(index: int, offer: Dictionary) -> PanelContainer:
	var id := str(offer.get("id",""))
	var level := int(offer.get("level",0))
	var limit := int(offer.get("max_level",1))
	var cost := int(offer.get("cost",0))
	var capped := level>=limit
	var affordable: bool=room.profile.starlight>=cost
	var card := _card(Color("f3eaf7"),Color("baa6c6"),17)
	card.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	card.size_flags_vertical=Control.SIZE_EXPAND_FILL
	card.custom_minimum_size=Vector2(0,202)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",7)
	card.add_child(box)
	box.add_child(_label("%02d  /  PERMANENT STUDY  /  %d OF %d" % [index+1,level,limit],11,Color("80618e")))
	var name_label := _label(str(offer.get("name",id)),21,INK)
	name_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(name_label)
	var desc := _label(str(offer.get("description","")),14,MUTED)
	desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	desc.size_flags_vertical=Control.SIZE_EXPAND_FILL
	box.add_child(desc)
	var level_hint := _label("Fully studied. Kept for every new expedition." if capped else "Next rank: %d / %d  ·  Takes effect on the next expedition." % [level+1,limit],12,Color("6b795e"))
	level_hint.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(level_hint)
	var caption := "Fully studied" if capped else "Study  /  %d starlight" % cost
	if not capped and not affordable: caption="Need %d starlight  /  Cost %d" % [cost-room.profile.starlight,cost]
	var button := _button(caption,capped)
	button.custom_minimum_size=Vector2(0,38)
	button.disabled=capped or not affordable
	button.pressed.connect(buy_upgrade.bind(id))
	box.add_child(button)
	purchase_buttons.append(button)
	return card

func _offer_card(index: int, offer: Dictionary) -> PanelContainer:
	var id := str(offer.get("id",""))
	var healing := str(offer.get("kind","gear"))=="heal"
	var item: Dictionary=room.run.item_info(id)
	var rarity := "provisions" if healing else str(item.get("rarity","common"))
	var card := _card(Color("f0f3e4"),_rarity_color(rarity).lightened(0.32),17)
	card.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	card.size_flags_vertical=Control.SIZE_EXPAND_FILL
	card.custom_minimum_size=Vector2(0,202)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",7)
	card.add_child(box)
	box.add_child(_label("%02d  /  %s" % [index+1,rarity.to_upper()],11,_rarity_color(rarity)))
	var name_label := _label("Sardine tin" if healing else str(item.get("name",id)),21,INK)
	name_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(name_label)
	var description := _label("Restore 35 vitality. A practical purchase for an impractical wizard." if healing else str(item.get("description","")),14,MUTED)
	description.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	description.size_flags_vertical=Control.SIZE_EXPAND_FILL
	box.add_child(description)
	if not healing:
		var current := str(room.run.equipment.get(str(item.get("slot","")),""))
		var comparison := _label(_comparison_text(item,current),12,Color("6b795e"))
		comparison.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		box.add_child(comparison)
	var price := int(offer.get("price",0))
	var sold := bool(offer.get("sold",false))
	var full_health: bool=healing and room.player.health.current>=room.player.health.maximum
	var affordable: bool=room.run.gold>=price
	var caption := "Bought" if sold else ("Vitality full" if full_health else ("Buy  /  %d crowns" % price))
	if not sold and not full_health and not affordable: caption="Need %d crowns  /  Price %d" % [price-room.run.gold,price]
	var button := _button(caption,sold)
	button.custom_minimum_size=Vector2(0,38)
	button.disabled=sold or full_health or not affordable
	button.pressed.connect(buy_offer.bind(index))
	box.add_child(button)
	purchase_buttons.append(button)
	return card

func buy_offer(index: int) -> void:
	if not is_open or mode!="shop" or index<0 or index>=room.shop_offers.size(): return
	var result: Dictionary=room.purchase_offer(index)
	if bool(result.get("ok",false)):
		var id := str(result.get("item_id",""))
		feedback="Vitality restored. Ready for more questionable magic." if int(result.get("heal",0))>0 else "%s is in your satchel. Open I to equip it." % str(room.run.item_info(id).get("name","Your purchase"))
		feedback_color=Color("4e7857")
	else:
		feedback=str(result.get("reason","The merchant cannot make that trade."))
		feedback_color=Color("ab5c51")
	refresh()

func buy_upgrade_at(index: int) -> void:
	if not is_open or mode!="meta": return
	var offers: Array=room.profile.upgrade_offers()
	if index>=0 and index<offers.size():
		buy_upgrade(str(offers[index].get("id","")))

func buy_upgrade(id: String) -> void:
	if not is_open or mode!="meta": return
	var result: Dictionary=room.purchase_upgrade(id)
	var ok := bool(result.get("ok",false))
	feedback="Study recorded. Your next expedition inherits it." if ok else str(result.get("reason","This study is not available yet."))
	feedback_color=Color("4e7857") if ok else Color("ab5c51")
	refresh()

func _equip(id: String) -> void:
	var ok: bool=room.equip_gear(id)
	feedback=("Equipped %s." % str(room.run.item_info(id).get("name",id))) if ok else "That item cannot be equipped."
	feedback_color=Color("4e7857") if ok else Color("ab5c51")
	refresh()

func _unequip(slot: String) -> void:
	var ok: bool=room.unequip_gear(slot)
	feedback="Put away. It stays safe in your satchel." if ok else "That slot is already empty."
	feedback_color=MUTED
	refresh()

func _request_close() -> void:
	room.close_panel()

func _stats_text(stats: Dictionary) -> String:
	var parts: Array[String]=[]
	for key in STAT_NAMES:
		if not stats.has(key): continue
		var amount := float(stats[key])
		if str(key).ends_with("_multiplier"):
			if is_equal_approx(amount,1.0): continue
			parts.append("%s %+.0f%%" % [STAT_NAMES[key],(amount-1)*100])
		elif not is_zero_approx(amount):
			parts.append("%s %+.0f" % [STAT_NAMES[key],amount])
	return "  ·  ".join(parts)

func _comparison_text(item: Dictionary, equipped_id: String) -> String:
	var old: Dictionary=room.run.item_info(equipped_id)
	var old_stats: Dictionary=old.get("stats",{})
	var new_stats: Dictionary=item.get("stats",{})
	var differences: Dictionary={}
	for key in STAT_NAMES:
		if str(key).ends_with("_multiplier"):
			var previous := float(old_stats.get(key,1.0))
			differences[key]=float(new_stats.get(key,1.0))/maxf(0.01,previous)
		else:
			differences[key]=float(new_stats.get(key,0.0))-float(old_stats.get(key,0.0))
	var delta := _stats_text(differences)
	return "Same bonuses as equipped." if delta.is_empty() else "vs equipped: "+delta

func _rarity_color(rarity: String) -> Color:
	return {"common":Color("5d785b"),"rare":Color("547c99"),"epic":Color("8a659d"),"provisions":Color("977438")}.get(rarity,GOLD)

func _label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text=text
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	return label

func _style(fill: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left=margin
	style.content_margin_right=margin
	style.content_margin_top=margin
	style.content_margin_bottom=margin
	return style

func _card(fill: Color, border: Color, margin: int) -> PanelContainer:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel",_style(fill,border,14,margin))
	return card

func _button(text: String, quiet: bool) -> Button:
	var button := Button.new()
	button.text=text
	button.add_theme_font_size_override("font_size",14)
	for color_state in ["font_color","font_hover_color","font_pressed_color","font_focus_color"]:
		button.add_theme_color_override(color_state,INK)
	button.add_theme_color_override("font_disabled_color",Color("9b9081"))
	button.add_theme_color_override("font_hover_color",INK)
	button.add_theme_color_override("font_pressed_color",INK)
	button.add_theme_stylebox_override("normal",_style(Color("eee5f3") if quiet else Color("d9e9cd"),Color("bea9cc") if quiet else Color("91aa7d"),11,8))
	button.add_theme_stylebox_override("hover",_style(Color("f6eef9") if quiet else Color("e6f1da"),Color("a88bb8") if quiet else Color("799b68"),11,8))
	button.add_theme_stylebox_override("pressed",_style(Color("c9dcb9"),Color("799b68"),11,8))
	button.add_theme_stylebox_override("disabled",_style(Color("e9e4db"),Color("c7bba9"),11,8))
	button.add_theme_stylebox_override("focus",_style(Color(0,0,0,0),Color("a88bb8"),11,0))
	return button
