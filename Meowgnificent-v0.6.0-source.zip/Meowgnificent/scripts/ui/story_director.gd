class_name StoryDirector
extends CanvasLayer

# Narrative UI is independent of combat. The room pauses its actors before
# opening a sequence and resumes from the completion callback. close() cancels;
# skip() and advance() on the last page complete exactly once.
signal sequence_started(kind: String, chapter: int)
signal sequence_finished(kind: String, chapter: int)
signal page_changed(index: int, total: int)

const STORY_PATH := "res://data/story.json"
const INK := Color("654e45")
const MUTED := Color("7c6c60")
const PAPER := Color("fff7e6")
const EDGE := Color("bda286")
var room: Node
var story: Dictionary = {}
var is_open := false
var mode := ""
var chapter_index := -1
var pages: Array = []
var page_index := 0
var elapsed := 0.0
var auto_advance := true
var last_completed_sequence := ""
var screen: Control
var stage: StoryStage
var speaker_label: Label
var body_label: Label
var chapter_label: Label
var page_label: Label
var next_button: Button
var skip_button: Button
var _completion := Callable()

func _ready() -> void:
	layer=22
	process_mode=Node.PROCESS_MODE_ALWAYS
	var loaded: Variant=JSON.parse_string(FileAccess.get_file_as_string(STORY_PATH))
	if loaded is Dictionary:
		story=loaded
	else:
		push_error("Story data could not be read.")
	screen=Control.new()
	var story_theme := Theme.new()
	story_theme.default_font=preload("res://art/fonts/MeowStorySans-Regular.otf")
	screen.theme=story_theme
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter=Control.MOUSE_FILTER_STOP
	add_child(screen)
	var backdrop := ColorRect.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.color=Color("f5ecd8")
	backdrop.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(backdrop)
	chapter_label=_label("",28,INK,Vector2(78,47),Vector2(980,48))
	_label("ARCANA ACADEMY  ·  THE MISADVENTURES OF MEOWMALADE",12,Color("806348"),Vector2(80,27),Vector2(900,22))
	var frame := Panel.new()
	frame.position=Vector2(74,111)
	frame.size=Vector2(1132,397)
	frame.mouse_filter=Control.MOUSE_FILTER_IGNORE
	frame.add_theme_stylebox_override("panel",_style(Color("e8efdc"),EDGE,24,0))
	screen.add_child(frame)
	stage=StoryStage.new()
	stage.position=Vector2(75,112)
	stage.size=Vector2(1130,395)
	stage.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(stage)
	var dialogue := Panel.new()
	dialogue.position=Vector2(74,528)
	dialogue.size=Vector2(1132,196)
	dialogue.mouse_filter=Control.MOUSE_FILTER_IGNORE
	dialogue.add_theme_stylebox_override("panel",_style(PAPER,EDGE,22,0))
	screen.add_child(dialogue)
	speaker_label=_label("",15,Color("806348"),Vector2(101,548),Vector2(1050,25))
	body_label=_label("",23,INK,Vector2(101,582),Vector2(1050,91))
	body_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	page_label=_label("",13,MUTED,Vector2(80,746),Vector2(950,24))
	next_button=_button("Next page",Vector2(1034,666),Vector2(148,40),Color("d7e8c9"))
	next_button.pressed.connect(advance)
	skip_button=_button("Skip story",Vector2(1060,39),Vector2(146,39),Color("eee3f2"))
	skip_button.pressed.connect(skip)
	screen.hide()
	set_process(false)

func _label(text: String, font_size: int, color: Color, position_: Vector2, size_: Vector2) -> Label:
	var label := Label.new()
	label.text=text
	label.position=position_
	label.size=size_
	label.add_theme_font_size_override("font_size",font_size)
	label.add_theme_color_override("font_color",color)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(label)
	return label

func _style(fill: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left=margin
	style.content_margin_right=margin
	style.content_margin_top=margin
	style.content_margin_bottom=margin
	return style

func _button(caption: String, at: Vector2, size_: Vector2, fill: Color) -> Button:
	var button := Button.new()
	button.text=caption
	button.position=at
	button.size=size_
	button.add_theme_font_size_override("font_size",15)
	for key in ["font_color","font_hover_color","font_pressed_color"]:
		button.add_theme_color_override(key,INK)
	button.add_theme_stylebox_override("normal",_style(fill,Color("a79983"),11,6))
	button.add_theme_stylebox_override("hover",_style(fill.lightened(0.12),Color("8e9b7f"),11,6))
	button.add_theme_stylebox_override("pressed",_style(fill.darkened(0.06),Color("8e9b7f"),11,6))
	button.add_theme_stylebox_override("focus",_style(Color(0,0,0,0),Color("a88bb8"),11,0))
	screen.add_child(button)
	return button

func play_opening(done: Callable) -> void:
	_play("opening",-1,"A minor magical incident",story.get("opening",[]),true,done)

func show_chapter(index: int, done: Callable) -> void:
	var chapters: Array=story.get("chapters",[])
	if index<0 or index>=chapters.size():
		if done.is_valid(): done.call_deferred()
		return
	var definition: Dictionary=chapters[index]
	_play("chapter",index,str(definition.get("title","A new chapter")),definition.get("beats",[]),false,done)

func play_ending(done: Callable) -> void:
	_play("ending",-1,"An unexpected correct answer",story.get("ending",[]),true,done)

func _play(kind: String, chapter: int, title: String, sequence: Array, autoplay: bool, done: Callable) -> void:
	close()
	mode=kind
	chapter_index=chapter
	pages=sequence.duplicate(true)
	_completion=done
	page_index=0
	elapsed=0.0
	auto_advance=autoplay
	chapter_label.text=title
	if pages.is_empty():
		_finish()
		return
	is_open=true
	screen.show()
	set_process(true)
	_show_page()
	sequence_started.emit(mode,chapter_index)

func _show_page() -> void:
	if page_index<0 or page_index>=pages.size(): return
	var page: Dictionary=pages[page_index]
	elapsed=0.0
	speaker_label.text=str(page.get("speaker",""))
	body_label.text=str(page.get("text",""))
	stage.set_scene(str(page.get("visual","academy")))
	page_label.text="%02d / %02d  ·  ENTER / SPACE: next page  ·  ESC: skip story" % [page_index+1,pages.size()]
	var last := page_index==pages.size()-1
	next_button.text=("Begin detention" if mode=="opening" else "Continue") if last else "Next page"
	if mode=="ending" and last: next_button.text="The end"
	page_changed.emit(page_index,pages.size())

func advance() -> void:
	if not is_open: return
	if page_index>=pages.size()-1:
		_finish()
	else:
		page_index+=1
		_show_page()

func skip() -> void:
	if is_open: _finish()

func close() -> void:
	is_open=false
	_completion=Callable()
	if is_instance_valid(screen): screen.hide()
	set_process(false)

func _finish() -> void:
	var done := _completion
	var finished_mode := mode
	var finished_chapter := chapter_index
	last_completed_sequence=finished_mode
	close()
	# GUI clicks and Space are also cast bindings. Clear their held action before
	# returning to the room; its callback also blocks casts until input releases.
	if InputMap.has_action("cast"): Input.action_release("cast")
	sequence_finished.emit(finished_mode,finished_chapter)
	if done.is_valid(): done.call_deferred()

func _input(event: InputEvent) -> void:
	if not is_open: return
	if event is InputEventKey:
		get_viewport().set_input_as_handled()
		if not event.is_pressed() or event.is_echo(): return
		match event.keycode:
			KEY_ESCAPE: skip()
			KEY_ENTER,KEY_KP_ENTER,KEY_SPACE: advance()

func _process(delta: float) -> void:
	if not is_open: return
	elapsed+=delta
	stage.time=elapsed
	stage.queue_redraw()
	if auto_advance:
		var page: Dictionary=pages[page_index]
		if elapsed>=float(page.get("duration",4.0)): advance()

class StoryStage extends Control:
	var visual := "academy"
	var time := 0.0
	var hero: TextureRect
	var hero_frames: Array[AtlasTexture] = []
	const HERO_SHEET: Texture2D = preload("res://art/characters/storybook_actions.png")
	const BROWN := Color("755a48")
	const CREAM := Color("fff8e8")

	func _ready() -> void:
		hero=TextureRect.new()
		hero.position=Vector2(430,88)
		hero.size=Vector2(270,270)
		hero.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		hero.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		hero.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
		hero.mouse_filter=Control.MOUSE_FILTER_IGNORE
		for rectangle in WizardCatVisual.POSE_RECTS:
			var frame := AtlasTexture.new()
			frame.atlas=HERO_SHEET
			frame.region=Rect2(rectangle)
			frame.filter_clip=true
			hero_frames.append(frame)
		hero.texture=hero_frames[0]
		add_child(hero)

	func set_scene(value: String) -> void:
		visual=value
		time=0.0
		if is_instance_valid(hero):
			hero.visible=not visual in ["grades","grimoire","library","garden","pip","moss","bloop","friends","truth","archive","analysis","examiner","report","end"]
			hero.texture=hero_frames[1] if visual=="fire" else hero_frames[0]
			hero.position=Vector2(155,190) if visual=="boom" else Vector2(430,88)
			hero.size=Vector2(145,173) if visual=="boom" else Vector2(270,270)
		queue_redraw()

	func _text(text: String, at: Vector2, font_size: int=22, color: Color=BROWN) -> void:
		var font := ThemeDB.fallback_font
		var width := font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x
		draw_string(font,at-Vector2(width*0.5,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,color)

	func _ellipse(at: Vector2, radius: Vector2, color: Color) -> void:
		draw_set_transform(at,0,radius)
		draw_circle(Vector2.ZERO,1,color)
		draw_set_transform(Vector2.ZERO)

	func _draw() -> void:
		# Storybook miniatures: soft shapes and a few props, without particle scenes.
		for i in range(7):
			var at := Vector2(110+i*155,347+sin(i*1.7)*10)
			_ellipse(at,Vector2(83,23),Color("cdddb9"))
		if visual in ["grimoire","truth","archive","analysis","examiner"]:
			_book(Vector2(565,205),1.3)
			if visual=="analysis":
				_text("POWER: EXTREME    CONTROL: 3%",Vector2(565,70),19)
				_text("PREDICTABILITY: 0%    …ERROR",Vector2(565,345),24,Color("9d6871"))
			elif visual=="truth": _text("COMPLETE SAFETY. COMPLETE CONTROL.",Vector2(565,350),19)
			elif visual=="examiner":
				_text("ONE PERFECT ANSWER",Vector2(565,350),24,Color("89749d"))
			return
		if visual in ["grades","report"]:
			_report(visual=="report")
			return
		if visual in ["pip","moss","bloop","friends"]:
			if visual in ["pip","friends"]: _chicken(Vector2(300 if visual=="friends" else 565,220))
			if visual in ["moss","friends"]: _vines(Vector2(565,225))
			if visual in ["bloop","friends"]: _potion(Vector2(830 if visual=="friends" else 565,220))
			if visual=="friends":
				_text("PIP",Vector2(300,340),20)
				_text("MOSS",Vector2(565,340),20)
				_text("BLOOP",Vector2(830,340),20)
			return
		if visual=="garden":
			for i in range(6):
				var point := Vector2(185+i*155,220+(i%2)*35)
				_mushroom(point)
			_text("Nothing grows like this.",Vector2(565,350),24)
			return
		if visual=="library":
			for i in range(5): _book(Vector2(185+i*190,190+sin(time*1.5)*5),0.48)
			_text("PERFECT SPACING. PERFECTLY STRANGE.",Vector2(565,350),20)
			return
		if visual=="end":
			_text("MEOWGNIFICENT",Vector2(565,190),56)
			_text("THE END",Vector2(565,255),25,Color("917796"))
			return
		_arch(Vector2(137,150))
		_arch(Vector2(993,150))
		_ellipse(Vector2(565,345),Vector2(90,17),Color(0.35,0.39,0.29,0.15))
		if visual in ["academy","fire","reverse","detention"]: _target(Vector2(890,236))
		if visual=="detention":
			_text("DETENTION",Vector2(255,125),27)
			for i in range(3): _broom(Vector2(245+i*70,275+sin(time*4+i)*4))
		if visual in ["fire","reverse"]:
			var progress := clampf(time/1.8,0.0,1.0)
			var at := Vector2(635,232).lerp(Vector2(851,232),progress)
			if visual=="reverse": at=Vector2(851,232).lerp(Vector2(315,255),progress)
			_spark(at,1.0)
		if visual=="candle":
			draw_style_box(_box(Color("ffe5ac"),BROWN,9),Rect2(778,253,37,69))
			_spark(Vector2(797,244),0.65)
		if visual=="boom":
			var burst_radius := 110+sin(minf(time,0.6)*PI/1.2)*32
			for i in range(7):
				var at := Vector2(565,211)+Vector2.from_angle(TAU*i/7)*burst_radius*0.62
				draw_circle(at,burst_radius*0.48,Color("f3cea0"))
			_text("BOOOOOOM!",Vector2(565,237),54,Color("a56759"))
		if visual=="title":
			_text("MEOWGNIFICENT",Vector2(565,64),42)
			_text("the wizard cat",Vector2(565,375),20)

	func _box(fill: Color,border: Color,radius: int) -> StyleBoxFlat:
		var box := StyleBoxFlat.new()
		box.bg_color=fill
		box.border_color=border
		box.set_border_width_all(2)
		box.set_corner_radius_all(radius)
		return box

	func _arch(at: Vector2) -> void:
		draw_style_box(_box(Color("ede1bd"),Color("c0ac86"),26),Rect2(at-Vector2(42,95),Vector2(84,248)))
		draw_style_box(_box(Color("c4d6bd"),Color("b1bd9e"),20),Rect2(at-Vector2(22,66),Vector2(44,213)))
		for i in range(3): draw_line(at+Vector2(-41,-18+i*52),at+Vector2(41,-18+i*52),Color("c0ac86"),2)
		_spark(at+Vector2(0,-114),0.55)

	func _target(at: Vector2) -> void:
		draw_line(at+Vector2(0,43),at+Vector2(-22,98),BROWN,9,true)
		draw_line(at+Vector2(0,43),at+Vector2(22,98),BROWN,9,true)
		for i in range(4): draw_circle(at,47-i*11,Color("f5dfbf") if i%2==0 else Color("d99785"))

	func _spark(at: Vector2, scale_: float) -> void:
		draw_circle(at,17*scale_,Color("f8d897"))
		draw_circle(at+Vector2(1,-4)*scale_,10*scale_,Color("fff7cc"))
		for i in range(4):
			var direction := Vector2.from_angle(TAU*i/4+time*0.25)
			draw_line(at+direction*21*scale_,at+direction*27*scale_,Color("dfa96c"),2,true)

	func _book(at: Vector2, scale_: float) -> void:
		draw_set_transform(at,0,Vector2.ONE*scale_)
		var left := PackedVector2Array([Vector2(-110,-68),Vector2(-7,-48),Vector2(-7,80),Vector2(-110,55)])
		var right := PackedVector2Array([Vector2(7,-48),Vector2(110,-68),Vector2(110,55),Vector2(7,80)])
		draw_colored_polygon(left,CREAM)
		draw_colored_polygon(right,Color("f0dfb4"))
		for polygon in [left,right]:
			var edge: PackedVector2Array=polygon.duplicate()
			edge.append(polygon[0])
			draw_polyline(edge,Color("92759e"),5,true)
		for i in range(5):
			draw_line(Vector2(-92,-42+i*18),Vector2(-23,-28+i*18),Color("b8a98d"),2,true)
			draw_line(Vector2(23,-28+i*18),Vector2(92,-42+i*18),Color("b8a98d"),2,true)
		draw_set_transform(Vector2.ZERO)

	func _report(ending: bool) -> void:
		draw_style_box(_box(CREAM,Color("bda286"),18),Rect2(270,27,590,345))
		_text("MEOWMALADE’S ACADEMIC RECORD",Vector2(565,68),22)
		var subjects := ["Elemental Magic","Teleportation","Summoning","Potion Making","Magical Control","World Saving" if ending else "Destruction"]
		var marks := ["D","F","F","C-","F","A+" if ending else "S+"]
		for i in range(subjects.size()):
			var y := 109+i*32
			draw_string(ThemeDB.fallback_font,Vector2(304,y),subjects[i],HORIZONTAL_ALIGNMENT_LEFT,-1,20,BROWN)
			draw_string(ThemeDB.fallback_font,Vector2(782,y),marks[i],HORIZONTAL_ALIGNMENT_LEFT,-1,22,Color("8e728e") if i==5 else BROWN)
		if ending: _text("OVERALL: MEOWGNIFICENT",Vector2(565,348),21,Color("8e728e"))

	func _chicken(at: Vector2) -> void:
		_ellipse(at+Vector2(0,50),Vector2(62,11),Color(0.35,0.39,0.29,0.14))
		_ellipse(at+Vector2(0,7),Vector2(58,43),CREAM)
		draw_circle(at+Vector2(30,-30),32,Color("fff5d9"))
		draw_circle(at+Vector2(36,-37),3,BROWN)
		draw_colored_polygon(PackedVector2Array([at+Vector2(57,-28),at+Vector2(79,-22),at+Vector2(57,-17)]),Color("e8b06d"))
		for i in range(3): draw_circle(at+Vector2(15+i*12,-64),8,Color("df9a8d"))
		for side in [-1,1]: draw_line(at+Vector2(side*17,41),at+Vector2(side*20,62),Color("d9a65e"),5,true)
		_text("One dragon, apparently.",at+Vector2(0,102),19)

	func _vines(at: Vector2) -> void:
		draw_style_box(_box(Color("d8c2a6"),BROWN,14),Rect2(at+Vector2(-40,-62),Vector2(80,115)))
		for side in [-1,1]:
			var points := PackedVector2Array()
			for i in range(20): points.append(at+Vector2(side*45+sin(i*0.45+time)*17,74-i*9))
			draw_polyline(points,Color("79a179"),7,true)
			for i in range(5):
				var point := at+Vector2(side*45+sin(i*1.8+time)*17,44-i*32)
				_ellipse(point+Vector2(side*11,-2),Vector2(17,8),Color("a1bd84"))
		_text("Sleeves included.",at+Vector2(0,102),19)

	func _potion(at: Vector2) -> void:
		draw_style_box(_box(Color("eadbf0"),Color("a88ab8"),12),Rect2(at+Vector2(-17,-85),Vector2(34,65)))
		draw_circle(at+Vector2(0,14),58,Color("d7c3e3"))
		draw_arc(at+Vector2(0,14),58,0,TAU,48,Color("a88ab8"),3,true)
		draw_circle(at+Vector2(-19,-3),11,Color("f5e8f5"))
		_spark(at+Vector2(33,-70),0.5)
		_text("Almost a potion.",at+Vector2(0,102),19)

	func _mushroom(at: Vector2) -> void:
		draw_style_box(_box(Color("f4e2c2"),Color("bba48a"),8),Rect2(at+Vector2(-13,-3),Vector2(26,68)))
		_ellipse(at,Vector2(51,30),Color("c9a9c6"))
		for side in [-1,1]: draw_circle(at+Vector2(side*22,-6),8,Color("f5e4e9"))

	func _broom(at: Vector2) -> void:
		draw_line(at+Vector2(0,-63),at+Vector2(0,25),BROWN,7,true)
		draw_colored_polygon(PackedVector2Array([at+Vector2(-13,4),at+Vector2(13,4),at+Vector2(25,49),at+Vector2(-25,49)]),Color("dfbf87"))
		for side in [-1,0,1]: draw_line(at+Vector2(side*5,11),at+Vector2(side*15,44),Color("ba986b"),2,true)
