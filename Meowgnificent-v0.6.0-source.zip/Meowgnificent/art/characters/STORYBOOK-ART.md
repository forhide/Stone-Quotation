# v0.6.0 HD pastel storybook cat

`storybook_actions.png` is an original generated high-resolution six-pose sheet. Meowmalade is a round orange wizard cat with very short legs, a large floppy lavender hat, simple sage patch and a small bell collar. Half-lidded neutral eyes give the cat a deadpan expression. Casting uses an open paw rather than a wand.

The six poses retain the existing gameplay presentation API: idle, preparation, casting, startled recoil, hurt and tucked roll. `storybook_expressions.png` supplies neutral, annoyed, sleepy and startled HUD portraits in four equal cells.

Both sheets have genuine transparent backgrounds. The active renderer uses linear filtering and smooth alpha contours; there is no logical pixel grid, UV quantization or pixel-snap shader. The immutable indexed mesh still provides GPU breathing, waddling, casting recoil and delayed hat motion without rebuilding CPU geometry. Original earlier artwork is retained as design history.
