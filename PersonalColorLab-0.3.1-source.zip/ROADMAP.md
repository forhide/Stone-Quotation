# Roadmap

The current scope is an offline desktop application. Mobile development is not planned.

## V0.1 - Dataset analyzer (implemented)

- File classification, recursive scan and pair candidates
- Local SQLite library and English/Korean desktop UI

## V0.2 - JPEG comparison and desktop packaging (implemented)

- Similarity alignment, valid overlap, measured tone transfer and Lab/HSV/HSL changes
- Approximate exposure/WB/tint, separate confidence/provenance, source hashes and stale-cache detection
- Direct original/edited JPEG selection, previews, swap, reanalysis, readable summaries and technical detail
- Dark graphite/lime theme, aperture icon, readable point fonts and display scaling
- Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg with verified private runtimes
- Source/GUI/archive/native-smoke tooling; actual native release validation remains separate

## V0.3.0 - Three source routes and saved analysis styles (implemented)

- **RAW + JPG:** sensor decoding with rawpy/LibRaw, explicit camera-WB sRGB baseline and registered inferred changes
- **RAW + XMP:** namespace-whitelisted recorded global settings and RGB tone curves, with unsupported/missing-value limits
- **JPG references:** final-appearance tone/color/chroma/hue/palette metrics without requiring originals
- Reference aggregation with exact duplicate exclusion, equal image weights, dispersion, consistency, appearance outliers and sample-coverage limits
- Folder mode choice, reviewed inclusion/exclusion, manual companion selection, progress/cancellation and individual/collection results
- Named saved analysis snapshots and persistent reopening through additive database schema 2
- English/Korean strings, source preservation, hashes/provenance and bundled RAW dependencies
- Completed validation and artifact evidence are recorded in `VALIDATION.md`

## V0.3.1 - Mac installer component resolution (implemented)

- Correct the embedded component URL in Distribution
- Check selected package resolution and installation-data/identity completeness
- Record the reported M1 installation failure and keep native installation confirmation separate

## Next - Evaluation and application-ready profiles

- Evaluate real camera RAWs, varied sidecars and reference sets; calibrate confidence and failure boundaries
- Improve repeated-name pairing, near-duplicate detection and unsupported-camera guidance
- Extend XMP support without implying Adobe render equivalence
- Validate native Windows/macOS installation, GUI, DPI/Retina and monitor transitions; sign/notarize releases
- Develop shared application-ready Style DNA from mode-specific evidence, with missing/uncertain dimensions explicit
- Improve hue-band presentation and estimate sharpening/noise/grain behavior

## Later - Style engine and scene context

- Adaptive non-destructive application to new photos with previews and safety/clipping checks
- Strength controls, hybrid mixing and derived local film/cinema/artist libraries
- Multilabel semantic scene coverage and scene-specific profile deltas
- Local regions, local-adjustment inference and composition suggestions
- Explicit user choice before geometry changes; no silent cropping

## V1.0 - Offline personal photo editor

- Verified Lightroom-compatible XMP export and refinement workflow
- Local model/update packs with mandatory CPU fallback
- Validated, signed offline desktop installers

Saving an analysis style in V0.3.0 does not yet apply it to a new image or generate XMP output.
