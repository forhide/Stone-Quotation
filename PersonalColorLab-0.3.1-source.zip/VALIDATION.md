# V0.3.1 macOS installation-data lookup repair

## Reported problem and packaging defect

The user reported an M1 Mac installer failure after bypassing Gatekeeper: installation data could not be found/verified. The exact dialog and macOS version were unavailable. Inspection of the delivered Apple Silicon product shows Distribution's component URL was `application.pkg`, a bare external-relative lookup, while the component is embedded in the XAR. The corrected URL is `#application.pkg`.

The original V0.3.0 file passed byte/mode/BOM checks but fails the new independent resolver with: `must use an embedded fragment URL, not 'application.pkg'`. Archive extraction alone did not validate Installer's component selection. This is a confirmed packaging defect; the user's exact native failure still needs confirmation on their machine.

## Current checks

**411 passed, 0 failed, 0 errors, 0 skipped**, in 25.94 seconds on Linux/Python 3.13.5/Tcl-Tk 8.6.16. The 32 existing Pillow deprecation warnings remain. Twenty new regressions check both Mac targets, embedded resolution, undefined choices, external/bare URLs, encoded traversal, missing/empty installation members, conflicting identity/version and escaping symlinks. Existing analysis, database and desktop coverage is retained.

```bash
PERSONAL_COLOR_LAB_BSDTAR=/workspace/.tools/pcl-packaging/archive/usr/bin/bsdtar \
FONTCONFIG_FILE=/workspace/.tools/personal-color-lab-fonts.conf \
PERSONAL_COLOR_LAB_XVFB=/workspace/.tools/personal-color-lab-xvfb/usr/bin/Xvfb \
.venv-desktop/bin/python tools/run_gui_tests.py -x -q \
  --junitxml=/tmp/pcl-v031-final-tests.xml
```

`tools/package_references.py` resolves the selected components inside the expanded product, requires PackageInfo/Bom/Payload and compares Distribution/component identifiers and versions. `tools/verify_mac_payload.py` runs those checks before comparing every payload byte, mode, link and BOM entry. The builder now emits the embedded fragment for native Apple and cross-host build paths.

App version is 0.3.1; algorithm 0.3.0, analysis payload 1 and database 2 stay compatible. Only the affected Mac installers were rebuilt. The existing verified Windows V0.3.0 delivery is retained.

Actual Apple Installer execution, successful installation on the user's M1, native GUI/Retina validation, signing and notarization remain unverified. This repair does not remove Gatekeeper's unsigned-publisher warning. Apple Silicon requires macOS 13 or later; Intel requires macOS 14 or later.

## Corrected macOS artifacts

- `PersonalColorLab-0.3.1-macos-arm64.pkg`: 85,709,365 bytes; 2,426 payload entries.
- `PersonalColorLab-0.3.1-macos-x64.pkg`: 67,049,279 bytes; 2,335 payload entries.

Both final products pass embedded-reference resolution, selected-component identity/version and required PackageInfo/Bom/Payload checks, followed by full XAR/CPIO byte/mode/link/BOM comparisons. SHA-256 sidecars match final bytes. Per-target JSON and current JUnit accompany the corrected delivery.

## Earlier V0.3.0 evidence

# V0.3.0 three-source extraction and saved-profile validation

## Current source and desktop result

**391 passed, 0 failed, 0 errors, 0 skipped**, in 26.42 seconds on Linux/Python 3.13.5/Tcl-Tk 8.6.16. The 32 retained warnings are the existing Pillow `getdata()` deprecation. The complete run includes 13 actual RAW-decoder tests, 39 XMP tests, 34 final-JPG appearance tests, 14 folder/pipeline integration tests, 77 saved-profile tests, 39 existing database tests, and 50 actual desktop cases. Prior geometric, tonal, color, localization, display, archive and data-preservation coverage remains included.

```bash
cd /workspace/Personal-Color-Lab
PERSONAL_COLOR_LAB_BSDTAR=/workspace/.tools/pcl-packaging/archive/usr/bin/bsdtar \
FONTCONFIG_FILE=/workspace/.tools/personal-color-lab-fonts.conf \
PERSONAL_COLOR_LAB_XVFB=/workspace/.tools/personal-color-lab-xvfb/usr/bin/Xvfb \
.venv-desktop/bin/python tools/run_gui_tests.py -x -q \
  --junitxml=/tmp/pcl-v030-final-tests.xml
```

The three routes are implemented and connected to the desktop:

- **RAW + edited JPG:** rawpy 0.25.1 / LibRaw 0.21.4 decodes real sensor pixels from a generated CFA DNG, including orientation. The documented camera-WB/sRGB baseline disables automatic brightness and automatic white balance. Registration is required before comparing tone/color and approximate EV/WB tendencies; a geometric failure withholds estimates. This baseline is an explicit rendering choice, not recovered Lightroom history or a camera JPEG. Corrupt/unsupported RAWs are rejected without substituting an embedded preview. Decode is limited to 120 megapixels and the analysis preview to 1400 pixels.
- **RAW + XMP:** namespace-aware whitelist parsing reads recorded global settings, HSL/grading controls and master/RGB tone curves. Attribute/element/sequence forms, finite/range validation, unsupported values, conflicting values and settings-free sidecars are exercised. DTD/entities and oversized XML are rejected, including UTF-16/32 markup. GPS, raw EXIF, complete XML, personal identity metadata and nested local-mask controls are not retained. Masks, custom profiles and unsupported adjustments remain explicit limitations. Recorded values do not establish identical Lightroom rendering or verify sidecar association.
- **JPG references:** real JPEGs produce luminance quantiles/clipping, contrast, HSV saturation, Lab/chroma, tonal-zone casts, hue-band support and a deterministic dominant palette. Aggregation uses per-image medians/MAD and equal image weights, removes exact SHA-256 duplicates, and reports appearance consistency/limited coverage and conservative outliers. ICC failure withholds color evidence. Final appearance includes lighting and subject content; it does not reconstruct original edit sliders or semantic scene labels.

Folder discovery handles same-folder preference, RAW-extension XMP sidecars, duplicate names, ambiguous matches, missing partners, recursive selection and explicit manual pairing. Per-file failures keep successful results. Cancellation retains completed work and counts unprocessed inputs. Original content hashes stay unchanged and Python network access is denied in end-to-end analysis/GUI checks.

Desktop checks exercise **Choose folder → mode → review/include/exclude/manual match → Analyze → inspect results → name/save → reopen saved styles** in English and Korean. Initial auto-mode selection, save on first completion, stale-result invalidation on mode changes, partial XMP warnings, palette cards, missing-RAW recovery, failures, cancellation and closing during a worker are included. Existing JPEG comparison, cached reopening and scan behavior remain covered. Minimum-size main/inspector/source screens are checked at 100%, 150% and 200% synthetic densities. File lists shrink before hiding result details; the main empty-state decoration yields space to instructions on small viewports. Actual Korean windows for all three routes were captured and visually inspected using synthetic fixtures.

Database schema 2 adds named source-profile snapshots atomically, preserving all prior schema-0/schema-1 rows. Save/close/reopen, Unicode names, separate snapshots with duplicate names, failed transaction rollback, corrupt records, mismatched counts, nonfinite values and GPS/raw-metadata exclusion are tested. App/algorithm versions are 0.3.0; analysis/profile payload schema remains 1. Both locales have 396 matching nonempty messages.

The installed diagnostic now exercises actual RAW decoding and all three discovery/analysis/profile routes with temporary synthetic data, without touching a user's library. A separate full GUI smoke also passed on Linux with Python sockets denied, including the new routes, named profiles and fresh-window reopening. The final native artifacts are verified separately below.

## Release scope and limits

This release extracts and saves evidence/appearance profiles. Applying a saved style to a new image, adaptive editing, semantic scene models and XMP output are future features. Synthetic CFA DNG exercises the actual decoder; it is not an evaluation of every camera model or real-photo dataset. Actual native Windows/macOS installation, Retina appearance, monitor transitions, signing and Apple notarization remain unverified. Large display scales need sufficient usable desktop space. All installers are unsigned development builds.

## Final V0.3.0 installers

All three final installers include the private verified runtime, four locked native wheels and retained rawpy/LibRaw licenses. SHA-256 sidecars match the final artifact bytes.

- `PersonalColorLab-0.3.0-windows-x64-setup.exe`: 51,078,369 bytes.
- `PersonalColorLab-0.3.0-macos-arm64.pkg`: 85,709,359 bytes; 2,426 payload entries.
- `PersonalColorLab-0.3.0-macos-x64.pkg`: 67,049,283 bytes; 2,335 payload entries.

The final Windows installer passed Wine 10 silent installation and reinstallation, installed-launcher diagnostics (version 0.3.0), actual installed Tk GUI workflows and data-preserving uninstall. The bundled diagnostic exercised real CFA DNG decoding and all three discovery/analysis/profile routes. Installed GUI checks used the folder-picker action, automatic/visible mode selection, JPEG palette/tendencies, RAW/JPG inference, recorded RAW/XMP settings, named profile save and fresh-window reopening. Existing manual JPEG comparisons, cache/scan/database/Korean/swap/source hashes passed with Python network access denied. DPI awareness was 2, body font 11 points and small font 10 points. User-data and unrelated-file sentinels survived removal. Wine-only UCRT is not shipped. This is Windows binary execution under Wine on Linux.

Both final macOS packages passed independent complete XAR/CPIO byte, permission, directory, internal-symlink, BOM-path/mode/ownership and PackageInfo-count comparisons against their staging trees. CPU-matching private native libraries and licenses are included. No Apple Installer or Mach-O interpreter was executed.

Current JUnit, installed Windows self-test/GUI evidence, per-target reports, hashes and actual synthetic desktop captures accompany the delivery. Native-device release limits remain as stated above.

## Earlier V0.2.2 evidence

# V0.2.2 text rendering and installer validation

## Current source and display results

**194 passed, 0 failed, 0 errors, 0 skipped** on Linux/Python 3.13.5/Tcl-Tk 8.6.16, in 16.30 seconds (2026-10-07 UTC). The complete run includes 70 UI/localization cases and nine focused display-initialization cases. English and Korean main/inspector layouts are exercised at 100%, 150%, and 200% synthetic display densities. Existing analysis, cache, database migration, original-file preservation, recovery and worker/window-lifetime checks remain included.

```bash
cd /workspace/Personal-Color-Lab
PERSONAL_COLOR_LAB_BSDTAR=/workspace/.tools/pcl-packaging/archive/usr/bin/bsdtar \
FONTCONFIG_FILE=/workspace/.tools/personal-color-lab-fonts.conf \
PERSONAL_COLOR_LAB_XVFB=/workspace/.tools/personal-color-lab-xvfb/usr/bin/Xvfb \
.venv-desktop/bin/python tools/run_gui_tests.py -x -q \
  --junitxml=/tmp/pcl-v022-final-tests.xml
```

Windows DPI awareness is initialized in the actual Python process before constructing Tk. API tests cover per-monitor-v2 setup, older fallbacks, unavailable APIs, and respect for a host's existing DPI configuration. Initial window DPI sets Tk's point-font scale; spacing, canvas coordinates, window dimensions and rows scale with the display. Fonts retain positive point sizes instead of being rasterized or multiplied twice. Small text is 10 points and detailed measurements use 11 points, with stronger secondary contrast. macOS keeps native system-font selection and Cocoa logical sizing; the bundled Tk 9 Retina path and `NSHighResolutionCapable` remain enabled without a forced extra 2x scale.

Actual running Korean Tk windows were captured and visually inspected under separate 96-DPI and 192-DPI Xvfb displays. The measured densities were 95.96 and 192.15 DPI; the same 10-point small font rendered with 19px and 37px line metrics. The inspector rendered at 1160×900 and 2322×1801 pixels respectively, with summary cards, readable paths and a measured curve visible. These PNGs are native captures, not enlarged copies, and contain only synthetic photo fixtures. Linux rendering does not establish native macOS Retina appearance.

Visible English/Korean UI checks confirm that the old Offline Only badge and repeated privacy/original-file notices are absent. Meaningful confidence, uncertainty, inferred provenance and recovery guidance remain. Both locale files contain 188 matching keys. App version is 0.2.2; analysis algorithm 0.2.0 and database/payload schema 1 are unchanged.

The 32 non-failing warnings are the existing Pillow `getdata()` deprecation exercised by the expanded cases; warnings were retained. A run with skipped display/archive cases does not replace this complete result.

## Rebuilt V0.2.2 installers

All three installers were rebuilt from the verified retained private CPython/native-wheel inputs. Installer SHA-256 sidecars match the final bytes.

- Windows x64: `PersonalColorLab-0.2.2-windows-x64-setup.exe`, 50,415,403 bytes.
- Apple Silicon: `PersonalColorLab-0.2.2-macos-arm64.pkg`, 84,662,162 bytes, minimum macOS 13; 2,402 payload entries.
- Intel Mac: `PersonalColorLab-0.2.2-macos-x64.pkg`, 65,906,245 bytes, minimum macOS 14; 2,311 payload entries.

The final Windows binary passed Wine 10 silent installation, repeat installation, installed-launcher self-test with app version 0.2.2 and a report path containing spaces, and the actual installed Tk GUI. The GUI diagnostic reported Win32 windowing, Windows DPI awareness **2** (per-monitor aware), logical DPI 96.08, body font 11 points and small font 10 points. Direct pair selection, cached reopening, default summaries, measured curves, scan, local database/cache, Korean switching, direction swap and unchanged synthetic source hashes passed with Python network access denied. Uninstall preserved both a user-data sentinel and an unrelated file in the install directory. The test-only Wine UCRT setup described below was not added to the installer. This is Windows binary execution under Wine on Linux.

Independent libarchive extraction checks passed for both macOS packages: all XAR/CPIO file bytes, modes, internal symlinks, complete BOM paths/modes/root-admin ownership and PackageInfo counts match staging. Mac packages contain architecture-matching private runtimes and the new display/theme/localization code. Linux cannot execute Apple Installer or the Mach-O application.

Actual native Windows/macOS installation, Retina appearance, monitor transitions, native CI, signing and Apple notarization remain unverified. Large display scales require enough usable screen space; synthetic density layout tests do not establish fit on every physical monitor. These are unsigned development installers. Per-target JSON reports, installed Windows self-test evidence, JUnit XML and actual screenshots accompany the download delivery.

## Earlier V0.2.1 evidence

# V0.2.1 UI/UX and installer validation

## Current source and desktop results

**175 passed, 0 failed, 0 errors, 0 skipped** on Linux/Python 3.13.5/Tcl-Tk 8.6.16, in 13.86 seconds (2026-10-07). The run includes 60 UI/localization checks, including 21 actual Tk desktop cases. This adds 31 cases to the earlier 144-test installer milestone without removing earlier analysis, persistence or packaging coverage.

```bash
cd /workspace/Personal-Color-Lab
PERSONAL_COLOR_LAB_BSDTAR=/workspace/.tools/pcl-packaging/archive/usr/bin/bsdtar \
FONTCONFIG_FILE=/workspace/.tools/personal-color-lab-fonts.conf \
PERSONAL_COLOR_LAB_XVFB=/workspace/.tools/personal-color-lab-xvfb/usr/bin/Xvfb \
.venv-desktop/bin/python tools/run_gui_tests.py -x -q \
  --junitxml=/tmp/pcl-v021-final-tests.xml
```

Direct comparison tests choose arbitrary JPEG filenames in different folders, without scanning. They exercise canceling either picker, missing/non-JPEG/same-file rejection, original hashes, local persistence, current-session deduplication, cached reopening and localized manual-selection labels. The menu displays English/한국어 and persists en/ko. English and Korean layout tests check visible main actions and empty guidance at 1060×720 and inspector summary values at 940×740. Existing worker/close tests continue to pass.

Summary tests distinguish measured brightness, approximate exposure, color evidence and verified shared area, and use only the engine's measured monotone tone-transfer points. Missing/invalid evidence never creates a zero-valued or synthetic measurement. Failed alignment, unreadable ICC profiles, stale caches and errors withhold summary values/curves and provide recovery steps. Algorithm version remains 0.2.0; app version is 0.2.1, with unchanged payload/database schema 1.

Actual running English/Korean Tk windows were captured and visually inspected at default and minimum sizes. The default 1160×900 inspector has a 143px tone graph; the small-window view keeps the summary cards visible and shows a compact curve. Preview images remain contained with their aspect ratios. Screenshots use synthetic fixtures only. Bundled PNG/ICO/ICNS aperture icons require no runtime download or extra dependency.

The 20 non-failing warnings are from the existing scanner's Pillow getdata usage exercised by more flows; they are not suppressed. Without a display, the 21 desktop cases are explicitly skipped; such a run does not replace this full result.

## Rebuilt V0.2.1 installers

All three installers were rebuilt from the verified retained private CPython/Pillow/NumPy/OpenCV inputs. SHA-256 sidecars were checked against the final installer bytes. App/launcher/setup icons are included.

- Windows x64: PersonalColorLab-0.2.1-windows-x64-setup.exe, 50,417,114 bytes.
- Apple Silicon: PersonalColorLab-0.2.1-macos-arm64.pkg, 84,660,919 bytes, minimum macOS 13; 2,401 payload entries.
- Intel Mac: PersonalColorLab-0.2.1-macos-x64.pkg, 65,904,763 bytes, minimum macOS 14; 2,310 payload entries.

Independent libarchive extraction checks passed for both macOS packages: complete file bytes, permissions, directories, symlinks, BOM paths/modes/root-admin ownership, and PackageInfo counts match staging. Extracted Info.plist versions and CPU/minimum-OS Distribution metadata are correct. Icons, new theme/manual-comparison code and English/Korean resources match the source; both locales contain 191 keys. No Mach-O interpreter or native macOS installer was executed.

The final Windows 0.2.1 binary passed Wine 10 integration: silent installation, repeat installation, the installed launcher self-test (app version 0.2.1, report path containing spaces), and the actual installed Tk GUI. The GUI flow uses direct photo selection without scanning, current-session cached reopening, default summaries and a measured curve, then folder scanning, local DB/cache, Korean switching, direction swap and unchanged synthetic source hashes. Python socket access is denied during this flow. Uninstall preserved both a user-data sentinel and an unrelated file in the install folder. The test-only Wine UCRT setup remains as described in the earlier record. This is Windows binary execution under Wine on Linux, not native Windows verification. Current per-target JSON and fresh JUnit evidence are supplied with the delivery files.

Actual native Windows/macOS installation and GUI execution, native CI, code signing and Apple notarization remain pending. These are unsigned development installers. The delivery branch contains installer downloads and supporting material; the source project's native CI has not been published or run through that branch.

## Earlier V0.2.0 evidence

# V0.2.0 validation and installer evidence

## Current installer milestone

**144 passed, 0 failed, 0 errors, 0 skipped** on Linux/Python 3.13.5/Tcl-Tk 8.6.16, in 11.40 seconds. This includes seven real GUI flows, 11 new package-diagnostic/resource checks and 14 new packaging-integrity checks. Independent libarchive checks validate XAR/CPIO bytes, executable permissions, Unicode paths and internal symlinks. BOM tests explicitly include hidden native libraries; wheel tests reject unsafe paths and wrong CPU/ABI tags.

```bash
cd /workspace/Personal-Color-Lab
PERSONAL_COLOR_LAB_BSDTAR=/workspace/.tools/pcl-packaging/archive/usr/bin/bsdtar \
FONTCONFIG_FILE=/workspace/.tools/personal-color-lab-fonts.conf \
PERSONAL_COLOR_LAB_XVFB=/workspace/.tools/personal-color-lab-xvfb/usr/bin/Xvfb \
.venv-desktop/bin/python tools/run_gui_tests.py -q \
  --junitxml=/tmp/pcl-installer-final-tests.xml
```

Without a display, seven GUI checks are explicitly skipped. Without bsdtar, two independent archive checks are skipped. Cross-host BOM list tests require POSIX cksum. Keep these outcomes distinct from the complete run. The updated cloud install script was executed successfully and pip check reports no broken requirements.

### Windows artifact

PersonalColorLab-0.2.0-windows-x64-setup.exe was compiled with NSIS 3.11 amd64 Unicode stubs. It bundles private CPython 3.13.16/Tcl-Tk 8.6.15, Pillow 12.3.0, NumPy 2.3.5, OpenCV wheel 4.14.0.94, translations and license notices. No administrator elevation, Python installation or runtime downloads are required; pip/ensurepip and build downloaders are excluded.

**Wine 10 integration passed on the final artifact:** silent install, repeat installation, installed launcher --self-test with a report path containing spaces, actual installed GUI scan/inspect/previews/analysis/SQLite/cache/Korean/direction swap, synthetic original hashes, uninstall, retained user-data sentinel and an unrelated file in the install directory. Only that unrelated file remained after uninstall. This is Windows binary execution under Wine on Linux, not native Windows validation.

The installed diagnostic reports Python 3.13.16, Pillow 12.3.0, NumPy 2.3.5, cv2 4.14.0, SQLite 3.53.1 and Tcl 8.6.15 with successful synthetic analysis and temporary DB persistence. cv2.__version__ omits the wheel build suffix. Python network access is blocked during the installed GUI flow.

Wine's bundled ucrtbase lacks NumPy's crealf export. The test-only Wine prefix therefore uses Microsoft's Windows SDK 10.0.28000.2705 UCRT, verified against NuGet's catalog SHA-512 and size. This SDK runtime is not included in the installer; native Windows supplies its UCRT. Provenance is retained at /workspace/.tools/pcl-packaging/ucrt-origin.json. The helper /workspace/scratch/pcl_wine_validate.py starts/stops its own Xvfb. Installation testing also caught a stale language-registry lookup error flag; ClearErrors now scopes failure detection to actual extraction. Final reinstall passed.

### macOS artifacts

- PersonalColorLab-0.2.0-macos-arm64.pkg: Apple Silicon, minimum macOS 13, 2,395 payload entries.
- PersonalColorLab-0.2.0-macos-x64.pkg: Intel, minimum macOS 14, 2,304 payload entries.

Both are actual unsigned flat installer files containing /Applications/Personal Color Lab.app with private architecture-matching Python/Tcl-Tk and native wheels. Minimum OS versions follow wheel tags. Mach-O interpreter dependencies use Apple system frameworks and @executable_path/../lib rather than an external Python installation.

**Independent checks passed for both final packages:** libarchive unpacked XAR/CPIO; every file SHA-256, permission, directory and internal symlink matches staging. Complete BOM paths, modes, root/admin ownership and counts agree with payload and PackageInfo, including hidden .dylibs. Official runtime/PyPI wheel HTTPS and pinned SHA-256 checks remain enabled and all native/wheel license notices are retained.

The bomutils directory scanner skips dotfiles. The cross-builder now uses its supported mkbom -i format with a complete explicit file list and POSIX cksum, rather than omitting essential .dylibs. The local lsbom reader at upstream revision c247002e2f49878bab32dd0fcf805810ae0992cb had a reversed Paths predicate causing a crash; its condition was restored to the original name == "Paths" implementation. The generator is unmodified. This reader correction is retained in /workspace/.tools/pcl-packaging/bomutils. Native macOS builds use Apple's pkgbuild/productbuild instead.

tools/verify_mac_payload.py independently verifies a cross-built package against staging; use --bsdtar /workspace/.tools/pcl-packaging/archive/usr/bin/bsdtar and --lsbom /workspace/.tools/pcl-packaging/bomutils/build/bin/lsbom in this prepared instance. Per-artifact JSON reports and SHA256SUMS are delivered beside the installers.

### Native release limits

Actual native Windows/macOS installer and GUI execution remain unverified. Linux cannot execute Apple Installer or Mach-O apps. The manual .github/workflows/installers.yml rebuilds and tests all three targets using native installation, installed diagnostics, GUI flows and data-preserving removal; it has not run because this ZIP-derived project has no Git remote. Stone-Quotation's remote was not repurposed.

All delivered installers are unsigned development builds. Windows signing, Apple signing/notarization and native release CI remain pending. No credentials are required for local unsigned builds. See INSTALLERS.md for installation and rebuild instructions. Real-photo calibration, RAW/XMP/style application and fresh-cloud restoration remain outside the completed milestone.

## Earlier analysis milestone

Validated on Linux on 2026-10-07 with the user-supplied V0.1 baseline preserved separately.

### Prior source results

- **119 passed, 0 failed, 0 errors, 0 skipped** on Python 3.13.5 / Tcl-Tk 8.6.16 (8.78 seconds).
- The same 119 tests passed on Python 3.12.14 / Tcl-Tk 9.0.4 (8.46 seconds).
- Seven tests exercised actual Tk windows through a local Xvfb, including scan, inspection, SQLite persistence, cached reload, direction swap, English/Korean switching, stale/corrupt cache recovery, worker failure, and window lifetime/closure during a worker.
- Synthetic tests exercised crop, resize, rotation, exposure, luminance zones, Lab/HSV/HSL shifts, confidence/unknown evidence, rejected pairs, invalid ICC profiles, input hashes, GPS exclusion, and V0.1 migration/transaction rollback.
- One end-to-end analysis check rejects every Python socket request; analysis and SQLite persistence complete without network access.
- `pip check` reports no broken dependencies. The exact runtime/development dependency files were installed into a fresh environment and repeated successfully.
- Original image SHA-256 bytes remain unchanged during analysis and inspection. The existing Stone-Quotation repository remains unchanged.

There are 12 non-failing warnings from the pre-existing scanner's Pillow `getdata()` usage, which Pillow plans to remove in version 14. The lock pins Pillow 12.3.0. These warnings were retained, not suppressed.

## Reproduce the full desktop run in the prepared cloud machine

```bash
cd /workspace/Personal-Color-Lab
FONTCONFIG_FILE=/workspace/.tools/personal-color-lab-fonts.conf \
PERSONAL_COLOR_LAB_XVFB=/workspace/.tools/personal-color-lab-xvfb/usr/bin/Xvfb \
.venv-desktop/bin/python tools/run_gui_tests.py -q
```

The cloud's default Python/Tk 9 build lacks TrueType/CJK rendering. The prepared desktop environment uses the already installed system Python 3.13/Tk 8.6, existing Noto CJK fonts, and a writable local Fontconfig cache. English and Korean inspector screenshots were rendered and visually inspected successfully. This is environment selection, not a change to the app's translation strings. The Xvfb package was downloaded through a signature-verified Debian repository and extracted locally; no system packages or signature/TLS verification were modified.

On a normal desktop, follow README.md's venv/lockfile instructions, then run `python -m pytest` with a working display. On headless Linux, `python tools/run_gui_tests.py -q` requires Xvfb in PATH or `PERSONAL_COLOR_LAB_XVFB`. Without a display, the seven desktop tests are explicitly skipped; that is not a substitute for the complete run above.

## Limits

These earlier results validate synthetic photo pairs and Linux source execution. The installer milestone above adds separate artifacts and verification. Real user photo datasets, calibrated confidence, native Windows/macOS releases, RAW decoding, complete XMP parsing/export, style learning/application, publication and fresh-task restoration remain unverified or unimplemented. The source ZIP is a development handoff; the separate .exe/.pkg files are installers. Untagged JPGs assume sRGB; unreadable embedded profiles withhold photometric estimates.
