# Codex Handoff - Personal Color Lab

## Current state

V0.3.1 repairs the macOS Distribution component URL (`#application.pkg`) and adds installation-data resolution checks. V0.3.0 archive-only validation did not catch the external-relative lookup reported on M1. Native Apple Installer confirmation remains pending; Windows delivery remains V0.3.0.

The extraction desktop implements three requested analysis routes: **RAW + edited JPG**, **RAW + XMP**, and **finished/reference JPGs alone**. This is a desktop product; mobile development is outside the current scope. Choose folder now continues into review, analysis, collection/individual results, naming and persistent saved-profile reopening. Do not describe RAW decoding or JPG-only color tendencies as unimplemented.

The original JPEG before/after inspector remains available through **Compare two photos**, including arbitrary names/folders, labeled previews, swap/reanalysis, measured tone transfer, summary cards and detailed evidence. Directly chosen pairs are deduplicated in the current session; that table is not restored as recent history after restarting. Named source profiles are persistent and separate from that session table.

## Source contracts

| Mode | Evidence | Limits |
| --- | --- | --- |
| `raw_jpg` | Sensor RAW developed with rawpy/LibRaw, then registered tone/color changes against the edited JPG | Fixed comparison baseline, not Lightroom defaults or exact sliders; modest similarity geometry only |
| `raw_xmp` | Supported recorded global Camera Raw settings and RGB curves from the supplied XMP | Association is caller-selected; no Adobe rendering, local masks or custom-profile reconstruction; absent values stay unknown |
| `reference_jpg` | Final rendered appearance and collection tendencies | Includes scene/lighting/camera effects; no edit history, recovered WB/exposure sliders or semantic scene labels |

RAW development pins rawpy 0.25.1 / LibRaw 0.21.4, requests camera WB (records daylight fallback if unavailable), disables automatic brightness and uses explicit sRGB/gamma/AHD settings. It reads sensor data, never substitutes an embedded preview, rejects unsupported/corrupt inputs and limits decode size to 120 megapixels. Runtime decoding can allocate full sensor buffers before bounded analysis resizing; it is not a streaming decoder.

Reference analysis uses bounded, EXIF-oriented, color-managed JPEG pixels. It measures luminance/contrast/clipping, saturation, Lab/chroma, shadow/midtone/highlight color, hue bands and a deterministic representative palette. Aggregate values use equal-image-weighted medians and median absolute deviation; palette weights also treat each unique image equally. SHA-256 byte duplicates contribute once. Heuristic consistency and sample-count warnings do not establish scene coverage; appearance outliers are flagged only with enough distinct samples and remain included. A single usable image remains a valid reference with limited collection evidence.

XMP parsing is namespace-specific, whitelisted, size/depth bounded and rejects DTD/entity declarations. Numeric ranges and curve points are validated. Unsupported or invalid settings are not invented, nested masks are not mistaken for global adjustments, and raw XMP/GPS metadata is not persisted. A recorded-value confidence of 1 means the parsed value was recorded, not that the sidecar belongs to the RAW or produces equivalent pixels.

## Current modules and APIs

- `core/raw_decode.py`: `decode_raw(path, max_dimension=1400)` returns bounded RGB, oriented original size and safe decoder provenance.
- `core/edit_reverse.py`: `analyze_pair(original_path, edited_path)` accepts JPEG/JPEG or RAW/JPEG. Results distinguish `inferred_jpg_pair` and `inferred_raw_pair`. Status is `ok`, `alignment_failed` or `color_space_uncertain`; unreadable/changing files raise. Geometry failure or color uncertainty withholds photometric estimates.
- `core/alignment.py`, `tone_analysis.py`, `color_analysis.py`: bounded reading, similarity registration, valid overlap, tone/Lab/HSV/HSL and approximate exposure/WB/tint evidence.
- `core/xmp_analysis.py`: `analyze_raw_xmp(raw_path, xmp_path)` returns supported recorded settings/curves, units, safe metadata, warnings and hashes. Status is `ok` or `no_supported_settings`; RAW rendering is not performed.
- `core/reference_analysis.py`: `analyze_reference(path)` returns appearance or explicit color uncertainty; `aggregate_references(payloads)` validates compatible evidence and returns an appearance summary, dispersion, palette, consistency, outliers and limitations.
- `core/source_workflow.py`: `discover_inputs(folder, mode, recursive=True)` proposes ready/ambiguous/unmatched rows; `analyze_inputs(items, mode, progress=None, cancel_event=None)` processes selected rows with failures isolated and cancellation between files; `summarize_results(mode, results)` retains mode-specific meaning.
- `core/database.py`: `save_analysis` / `get_analysis` handle pair comparisons; `save_source_profile(name, payload)`, `list_source_profiles()` and `get_source_profile(id)` handle named snapshots. Same-name saves create new records, not silent replacement.
- `core/schema_migrations.py`: additive schema 2, preserving existing data and rejecting unknown newer schemas.
- `ui/source_workflow.py`: review/include/exclude, manual companion resolution, progress/cancel, results and persistent profiles, with worker queues and UI-thread widget ownership.
- `ui/app.py`: folder extraction entry point, saved styles, existing direct JPEG selection and optional candidate scanning.
- `ui/pair_inspector.py`: pair previews, summaries, details, cache checks, background analysis and recovery guidance.
- `ui/theme.py` / `display.py`: shared fonts/colors/styles and pre-Tk Windows DPI initialization.

App version is 0.3.1 and algorithm version is 0.3.0; analysis payload schema is 1 and database schema is 2. Existing library rows/settings survive migration. Older algorithm comparison records remain stored but need reanalysis for a current comparison. Source snapshots reopen as historical analysis without automatic source-file refresh. All stored data is finite, validated and GPS-free. Source hashes detect changing analysis inputs; hashing alone does not verify pairing semantics.

## Confidence and privacy

Keep pairing, geometric alignment, registered tone/color evidence and individual estimate confidence distinct. Exposure EV and WB/tint are approximate and can be confounded by clipping, sparse neutral pixels, camera processing or local edits. Confidence and collection consistency are heuristic scores, not calibrated probabilities.

The application is fully offline after installation: no HTTP runtime clients, external AI/API, telemetry, accounts, remote configuration or uploads. Original photos remain read-only. English is default and Korean is selectable; UI strings stay in external locale resources. Future models must run locally with a CPU fallback. Do not persist raw EXIF/XMP or GPS metadata.

## Display, packaging and validation

The graphite/lime interface retains the V0.2.2 readable point fonts, native macOS system family, Windows DPI setup before Tk, scaled layout spacing and aperture icon. Respect an already-configured Windows process. macOS uses Cocoa logical units and existing `NSHighResolutionCapable`/Tk Retina support; do not force 2x. Actual native DPI/Retina and dynamic monitor transitions remain unverified. Large text/display scales can need a larger viewport. Removed repetitive privacy labels should not return; retain useful analysis warnings.

Source requirements: Python 3.11+, Tkinter, Pillow, NumPy, headless OpenCV and rawpy/LibRaw. Install `requirements-dev.lock`, run `python -m pytest`, or use `python tools/run_gui_tests.py -q` with local Xvfb for GUI coverage. `PERSONAL_COLOR_LAB_XVFB` and `PERSONAL_COLOR_LAB_BSDTAR` can point to locally prepared validation tools. `PERSONAL_COLOR_LAB_DATA_DIR` isolates local test data. Final counts and artifact evidence belong in `VALIDATION.md`, after execution.

Private verified CPython 3.13.16/Tcl-Tk and native wheels/licenses are bundled in Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg. Build tools alone access the network; installed apps do not need Python/pip/downloads. Native smoke tools and manual CI are included, but native host/display execution, signing and notarization remain pending. Wine and archive structure checks do not establish native readiness. The authorized download-only branches in `forhide/Stone-Quotation` host delivery files separately from main. This extracted project folder has no Git remote; the download branch is not the application's source/CI repository.

## Next milestones

Completed source profiles are an extraction foundation. Applying a style to a new photo, strength controls, hybrid mixing, built-in film/cinema/artist profiles, application-ready shared Style DNA, semantic scene coverage, local-region inference, composition suggestions and Lightroom XMP export remain unimplemented. Do not present a saved analysis profile as an executable preset.

Prioritize real-camera/sidecar/reference datasets, unsupported-format behavior, pairing ambiguities, confidence calibration and native packaging/display checks. Extend XMP support with explicit boundaries; retain missing-value semantics. Near-duplicate analysis and scene-specific subprofiles require separate implementation. Future composition changes must offer Color only, suggestions or explicit automatic application, and never modify originals. Bundled profiles may contain derived parameters, not copied source photographs or frames.

Read `AGENTS.md` and `OFFLINE_ARCHITECTURE.md` before architecture changes. Update development context, changelog, roadmap, TODO and validation evidence after each meaningful milestone.
