# TODO

## Implemented - V0.3.1 Mac packaging repair

- [x] Use an embedded fragment URL for the component package.
- [x] Validate product references, required installation data and component identity/version before archive bytes.
- [x] Add regressions rejecting the previous external-relative reference.
- [ ] Confirm the corrected installer with Apple Installer on native M1 hardware.

## Implemented - V0.3.0

- [x] Continue Choose folder into RAW + JPG / RAW + XMP / JPG reference modes.
- [x] Review discovered files, exclude entries and resolve missing or ambiguous companions manually.
- [x] Decode RAW sensor data locally with rawpy/LibRaw and a recorded fixed camera-WB sRGB baseline.
- [x] Reuse registered tone/color analysis for RAW + edited JPG and label estimates as inferred.
- [x] Parse supported namespace-whitelisted global XMP parameters and RGB curves with bounds and safe XML handling.
- [x] Preserve missing/unsupported XMP semantics and separate recorded settings from rendered appearance.
- [x] Measure final JPG luminance/contrast/clipping, saturation, Lab/chroma, tonal zones, hue bands and palette.
- [x] Aggregate unique references with equal image weights, dispersion, consistency, sample limitations and appearance outliers.
- [x] Keep flagged outliers included until the user excludes them; deduplicate exact content only.
- [x] Add progress, per-file recovery and cancellation between files with completed results retained.
- [x] Show collection and individual results; save named analysis snapshots and reopen after app restart.
- [x] Add database schema 2 while preserving existing rows/settings; keep payload schema 1.
- [x] Update app/algorithm to 0.3.0 and include the RAW dependency in locked runtime/installer inputs.
- [x] Keep English/Korean resources, original preservation, GPS exclusion and local CPU execution.
- [x] Preserve the existing JPEG comparison workflow, summaries, curves, readability and display scaling.

## Implemented foundations

- [x] Modest crop/resize/rotation alignment with valid overlap and failure abstention.
- [x] Withhold photometric measurements for unreadable ICC profiles; keep inspectable geometry.
- [x] Separate inferred estimates, registration evidence, confidence and source hashes.
- [x] Cache/persist JPEG comparisons with stale-source and algorithm checks.
- [x] Provide private-runtime Windows x64 and macOS Apple Silicon/Intel installer tooling and diagnostics.
- [x] Provide pinned dependency files, synthetic analysis fixtures and a local-Xvfb GUI test runner.

## Validation and refinement

- [ ] Complete real-camera RAW, diverse XMP and reference-photo evaluation; calibrate heuristic confidence.
- [ ] Improve filename ambiguity, visual pairing, unsupported-camera guidance and near-duplicate detection.
- [ ] Expand alignment coverage without fabricating general perspective/local-edit support.
- [ ] Improve hue-band presentation and investigate sharpening/noise/grain inference.
- [ ] Extend supported XMP properties with explicit missing-value and rendering limits.
- [ ] Run native installer CI on Windows x64, macOS Apple Silicon and macOS Intel.
- [ ] Verify actual Windows DPI and macOS Retina/monitor transitions and usable viewport limits.
- [ ] Sign Windows releases and sign/notarize macOS releases.

Completed automated runs and artifact checks are recorded in `VALIDATION.md`; checklist items above do not substitute for that evidence.

## Future style application

- [ ] Build shared application-ready Style DNA while preserving each source's evidence and uncertainty.
- [ ] Apply saved styles to new images with strength controls and before/after previews.
- [ ] Add derived built-in film/cinema/artist profiles and Hybrid Style mixing.
- [ ] Add semantic multilabel scene coverage and scene-specific profile deltas.
- [ ] Add local-region inference, composition scoring and user-approved crop suggestions.
- [ ] Export and verify non-destructive Lightroom-compatible XMP.
- [ ] Provide local model packs with mandatory CPU fallback.

V0.3.0 saves analysis styles; it does not yet apply edits or export XMP. All future work preserves offline execution, source bytes, GPS exclusion and selectable English/Korean. Mobile development remains outside scope.
