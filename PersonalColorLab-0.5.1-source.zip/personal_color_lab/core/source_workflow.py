"""Discover, analyze and summarize the three local photographic input modes.

Discovery proposes filename relationships; it never treats a filename as proof
of an edit. Ambiguous candidates need the user's selection. Analyses own their
input-content checks, and a failed file does not discard the rest of a batch.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import time
from pathlib import Path
from statistics import median

from .constants import JPEG_EXTENSIONS, RAW_EXTENSIONS, XMP_EXTENSIONS
from .edit_reverse import analyze_pair, file_fingerprint
from .analysis_cache import cache_key, relocate_payload
from .reference_analysis import analyze_reference, aggregate_references
from .scanner import normalized_stem
from .xmp_analysis import analyze_raw_xmp

MODES = ('raw_jpg', 'raw_xmp', 'reference_jpg')
ALGORITHM_VERSION = '0.5.1'


def _mode(mode):
    if mode not in MODES:
        raise ValueError('Unknown source analysis mode.')
    return mode


def _stem(path):
    # Lightroom also writes DSC0001.NEF.xmp sidecars.
    if path.suffix.lower() == '.xmp' and Path(path.stem).suffix.lower() in RAW_EXTENSIONS:
        path = Path(path.stem)
    return normalized_stem(path).casefold()


def _item(mode, original, edited=None, status='ready', reason='filename_match', candidates=None):
    identity = f'{mode}\0{original}\0{edited or ""}'
    return {
        'id': hashlib.sha256(identity.encode('utf-8')).hexdigest()[:20],
        'source_type': mode, 'original_path': str(original),
        'edited_path': str(edited) if edited else None,
        'status': status, 'reason': reason,
        'candidates': [str(path) for path in (candidates or [])],
    }


def discover_inputs(folder, mode, recursive=True):
    """Return ready, ambiguous and unmatched rows without decoding images."""
    _mode(mode)
    folder = Path(folder).expanduser().resolve(strict=True)
    if not folder.is_dir():
        raise ValueError('Choose an existing folder.')
    extensions = RAW_EXTENSIONS | JPEG_EXTENSIONS | XMP_EXTENSIONS
    iterator = folder.rglob('*') if recursive else folder.glob('*')
    paths = sorted({p.resolve() for p in iterator if p.is_file() and p.suffix.lower() in extensions},
                   key=lambda p: (str(p).casefold(), str(p)))
    raws = [p for p in paths if p.suffix.lower() in RAW_EXTENSIONS]
    jpgs = [p for p in paths if p.suffix.lower() in JPEG_EXTENSIONS]
    xmps = [p for p in paths if p.suffix.lower() in XMP_EXTENSIONS]
    counts = {'total_files': len(paths), 'raw': len(raws), 'jpg': len(jpgs), 'xmp': len(xmps)}
    if mode == 'reference_jpg':
        items = [_item(mode, p, reason='reference_photo') for p in jpgs]
    else:
        targets = jpgs if mode == 'raw_jpg' else xmps
        by_name = defaultdict(list)
        for target in targets:
            by_name[_stem(target)].append(target)
        proposed = {}
        reverse = defaultdict(list)
        for raw in raws:
            candidates = by_name.get(_stem(raw), [])
            local = [p for p in candidates if p.parent == raw.parent]
            proposed[raw] = local or candidates
            for target in proposed[raw]:
                reverse[target].append(raw)
        items, referenced = [], set()
        for raw in raws:
            candidates = proposed[raw]
            referenced.update(candidates)
            if len(candidates) == 1 and len(reverse[candidates[0]]) == 1:
                items.append(_item(mode, raw, candidates[0]))
            elif candidates:
                items.append(_item(mode, raw, status='ambiguous', reason='multiple_matches', candidates=candidates))
            else:
                items.append(_item(mode, raw, status='unmatched', reason='missing_edited'))
        for target in targets:
            if target not in referenced:
                items.append(_item(mode, target, status='unmatched', reason='missing_raw'))
    for state in ('ready', 'ambiguous', 'unmatched'):
        counts[state] = sum(row['status'] == state for row in items)
    return {'mode': mode, 'folder': str(folder), 'items': items, 'counts': counts}


def _finite_median(values):
    values = [float(v) for v in values if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)]
    return float(median(values)) if values else None


def summarize_results(mode, results):
    """Keep final appearance, inferred changes and recorded settings separate."""
    _mode(mode)
    payloads = [r['payload'] for r in results if r['status'] == 'ok' and isinstance(r.get('payload'), dict)]
    if mode == 'reference_jpg':
        summary = aggregate_references(payloads)
        summary['input_count'] = len(results)
        summary['duplicate_count'] = sum(r['status'] == 'duplicate' for r in results)
        summary['excluded_count'] = len(results) - summary['sample_count'] - summary['duplicate_count']
        if summary['duplicate_count']:
            summary['warnings'].append('reference_duplicates_ignored')
        if summary['excluded_count']:
            summary['warnings'].append('reference_invalid_or_uncertain_excluded')
        summary['warnings'] = list(dict.fromkeys(summary['warnings']))
        return summary
    summary = {'source_type': mode, 'sample_count': len(payloads), 'input_count': len(results),
               'excluded_count': len(results) - len(payloads)}
    if mode == 'raw_jpg':
        summary.update({
            'exposure_ev_median': _finite_median(p.get('tone', {}).get('estimated_exposure_ev') for p in payloads),
            'brightness_delta_median': _finite_median(p.get('tone', {}).get('mean_luminance_delta') for p in payloads),
            'contrast_delta_median': _finite_median(p.get('tone', {}).get('contrast_delta') for p in payloads),
            'temperature_counts': dict(Counter(p.get('lightroom_estimates', {}).get('white_balance_direction', 'uncertain') for p in payloads)),
            'tint_counts': dict(Counter(p.get('lightroom_estimates', {}).get('tint_direction', 'uncertain') for p in payloads)),
            'warnings': ['raw_baseline_interpretation', 'lightroom_values_approximate'],
        })
    else:
        values = defaultdict(list)
        for payload in payloads:
            for name, value in payload.get('parameters', {}).items():
                values[name].append(value)
        parameters = {}
        for name, entries in sorted(values.items()):
            if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in entries):
                parameters[name] = {'median': _finite_median(entries), 'min': min(entries), 'max': max(entries), 'count': len(entries)}
            else:
                parameters[name] = {'values': list(dict.fromkeys(entries)), 'count': len(entries)}
        process_versions = sorted({str(p.get('metadata', {}).get('ProcessVersion')) for p in payloads if p.get('metadata', {}).get('ProcessVersion') is not None})
        warnings = ['xmp_settings_not_rendered']
        warnings.extend(w for p in payloads for w in p.get('warnings', []) if w in {
            'xmp_local_adjustments_not_extracted', 'xmp_custom_profile_not_rendered',
            'xmp_unsupported_settings_ignored', 'xmp_invalid_values_ignored',
            'xmp_conflicting_settings_ignored',
        })
        if len(process_versions) > 1:
            warnings.append('mixed_xmp_process_versions')
        summary.update({'parameters': parameters, 'process_versions': process_versions,
                        'tone_curve_count': sum(bool(p.get('tone_curves')) for p in payloads), 'warnings': list(dict.fromkeys(warnings))})
    return summary


def _paths_for_item(item, mode):
    if item.get('source_type') != mode:
        raise ValueError('Selected input type does not match the analysis mode.')
    original = Path(item['original_path']).expanduser().resolve(strict=True)
    if not original.is_file():
        raise ValueError('Input photo is not a file.')
    if mode == 'reference_jpg':
        if original.suffix.lower() not in JPEG_EXTENSIONS:
            raise ValueError('Reference mode requires a JPEG photo.')
        return original, None
    edited = Path(item['edited_path']).expanduser().resolve(strict=True)
    expected = JPEG_EXTENSIONS if mode == 'raw_jpg' else XMP_EXTENSIONS
    if original.suffix.lower() not in RAW_EXTENSIONS or edited.suffix.lower() not in expected or not edited.is_file():
        raise ValueError('The selected files do not match this RAW input mode.')
    if original.samefile(edited):
        raise ValueError('The two input files must be different.')
    return original, edited


def analyze_inputs(items, mode, progress=None, cancel_event=None, cache=None):
    """Analyze selected rows serially in a worker; cancellation is between files.

    Returns completed results even when another photo fails or the user cancels.
    No SQLite connections, GUI objects, source writes or network access occur.
    """
    _mode(mode)
    items = list(items)
    started = time.perf_counter()
    results, seen = [], set()
    cached = avoided = cache_errors = 0
    current_bundle = None
    if mode != 'raw_xmp' and cache is not None:
        from .semantic_models import bundle_id, ModelUnavailableError
        try:
            current_bundle = bundle_id()
        except ModelUnavailableError:
            # Cached global measurements remain useful without recognition.
            # Once repaired, available models below invalidate unavailable or
            # differently versioned semantic evidence and retry recognition.
            pass
    counts = dict.fromkeys(('total', 'processed', 'successful', 'failed', 'skipped', 'cancelled', 'duplicates'), 0)
    counts['total'] = len(items)
    for item in items:
        if cancel_event is not None and cancel_event.is_set():
            counts['cancelled'] = len(items) - counts['processed']
            break
        if item.get('status') != 'ready':
            result = {'item': dict(item), 'status': 'skipped', 'payload': None, 'error_code': item.get('reason', 'not_ready')}
            counts['skipped'] += 1
        else:
            try:
                original, edited = _paths_for_item(item, mode)
                fingerprints = {'original': file_fingerprint(original)}
                if edited is not None:
                    fingerprints['edited'] = file_fingerprint(edited)
                identity = tuple(sorted(fingerprints.items()))
                if identity in seen:
                    result = {'item': dict(item), 'status': 'duplicate', 'payload': None, 'error_code': 'duplicate_content'}
                    counts['duplicates'] += 1
                    avoided += 1
                    results.append(result)
                    counts['processed'] += 1
                    if progress:
                        progress(counts['processed'], counts['total'], original.name)
                    continue
                key = cache_key(mode, fingerprints)
                payload = None
                if cache is not None:
                    try:
                        payload = cache.get_cached_analysis(key)
                    except Exception:
                        cache_errors += 1
                if payload is not None:
                    expected_type = 'inferred_raw_pair' if mode == 'raw_jpg' else mode
                    if (payload.get('algorithm_version') != ALGORITHM_VERSION or payload.get('schema_version') != 1
                            or payload.get('source_type') != expected_type
                            or payload.get('provenance', {}).get('input_fingerprints') != fingerprints):
                        payload = None
                    elif current_bundle is not None and (
                            payload.get('semantic', {}).get('status') != 'ok'
                            or payload['semantic'].get('bundle_id') != current_bundle):
                        payload = None
                    else:
                        payload = relocate_payload(payload, original, edited, fingerprints)
                from_cache = payload is not None
                if from_cache:
                    cached += 1
                elif mode == 'reference_jpg':
                    payload = analyze_reference(original)
                elif mode == 'raw_xmp':
                    payload = analyze_raw_xmp(original, edited)
                else:
                    payload = analyze_pair(original, edited)
                # Fresh engines already verify hashes before and after decoding.
                # Cached results must perform their own final identity check.
                after = dict(fingerprints)
                if from_cache:
                    after['original'] = file_fingerprint(original)
                    if edited is not None:
                        after['edited'] = file_fingerprint(edited)
                if after != fingerprints or payload.get('provenance', {}).get('input_fingerprints') != fingerprints:
                    raise ValueError('Input changed during batch analysis; retry with stable files.')
                status = payload['status']
                result = {'item': dict(item), 'status': status, 'payload': payload}
                fingerprints = payload.get('provenance', {}).get('input_fingerprints', {})
                identity = tuple(sorted(fingerprints.items()))
                if status == 'ok' and identity and identity in seen:
                    result.update(status='duplicate', payload=None, error_code='duplicate_content')
                    counts['duplicates'] += 1
                elif status == 'ok':
                    if identity:
                        seen.add(identity)
                    counts['successful'] += 1
                    if cache is not None:
                        try:
                            cache.cache_analysis(key, payload)
                        except Exception:
                            # Optional acceleration must never discard valid
                            # evidence or count a successful photo as a failure.
                            cache_errors += 1
                else:
                    counts['failed'] += 1
            except Exception as exc:
                result = {'item': dict(item), 'status': 'error', 'payload': None,
                          'error_code': 'analysis_error', 'error_detail': str(exc)}
                counts['failed'] += 1
        results.append(result)
        counts['processed'] += 1
        if progress:
            progress(counts['processed'], counts['total'], Path(item.get('original_path', '')).name)
    status = ('cancelled' if counts['cancelled'] else
              'failed' if not counts['successful'] else
              'partial' if counts['failed'] or counts['skipped'] else 'ok')
    batch = {'schema_version': 1, 'algorithm_version': ALGORITHM_VERSION, 'mode': mode, 'status': status,
             'analyzed_at_utc': datetime.now(timezone.utc).isoformat(), 'results': results,
             'summary': summarize_results(mode, results), 'counts': counts,
             'performance': {'cache_hits': cached, 'avoided_duplicate_decodes': avoided,
                             'cache_errors': cache_errors,
                             'elapsed_seconds': time.perf_counter() - started},
             'provenance': {'originals_modified': False, 'aggregation': 'equal_per_unique_input',
                            'exact_edit_parameters': mode == 'raw_xmp'}}
    json.dumps(batch, allow_nan=False)
    return batch
