# TODO

## V0.5.1 - Review fixes for style learning, rendering and recovery

- Correctly transfer pure monochrome intent from supported RAW/JPG or JPG/JPG comparisons and unanimously gray JPG references. Mixed-color, sepia, clipped and insufficient evidence remain conservative. Historical paired analyses need reanalysis to add the new evidence; reference snapshots already contain the needed appearance statistics.
- Preserve supported monochrome context/region recipes without removing color from unrelated regions. Share bounded preview measurements with full-resolution local rendering to keep component baselines consistent.
- Validate render options before recognition, honor cancellation at neutral/zero strength, preserve unchanged face pixels exactly, and skip unnecessary regional work.
- Encode exports in a private sibling file before publishing the new filename. Cancellation and ordinary failure remove this operation's partial files without replacing another output. Recheck the original after JPEG encoding; validate finite effective XMP values. Filesystems without hard links use an exclusive cancellable copy.
- Treat analysis cache failures as optional recovery, preserving valid results and correct counts. Reanalyze missing-model caches after model repair; validate cached semantic evidence and all model/license/manifest identities together.
- Clear stale photo/evidence on selection failures, preserve mix/composition/name state across language changes, scroll settings over child controls, and retain export locks during redraws and shortcuts.
- App and analysis algorithms0.5.1; SQLite3, analysis/profile schema1 and DNA2/engine0.5.0 remain compatible. Historical0.3/0.4/0.5.0 analysis snapshots stay readable. See VALIDATION.md for final tests, installed checks and platform limits.

## V0.5.0 - Embedded object recognition and a clearer style workspace

- Bundled checksum-verified local NanoDet COCO-80 object detection, PP-HumanSeg person segmentation and YuNet face detection (3,091,271 model bytes). Inference uses OpenCV DNN CPU; no API, token charge, runtime download, login or network client is added.
- Added object-derived context tags, region previews, optional face-color protection and adjustable region strength. Non-person objects use approximate boxes; faces use protection ellipses. These are not face identities or general instance segmentation.
- Learned reference region/context targets require three distinct supported image encodings; image pairs learn observed regional transforms in registered valid overlap. Reference lighting/content confounders remain. Unsupported/missing models withhold semantic evidence explicitly.
- Added visual tone/color fingerprint suggestions, one-click trials, reset, keyboard shortcuts and full-width wipe comparison. Settings move into a scrolling side panel while original/styled previews and exports stay visible; mixing/composition controls are grouped separately.
- JPG exports include local region/face effects. XMP exports remain approximate global presets and do not serialize Adobe semantic masks. Original bytes and GPS exclusion remain intact.
- Refined hybrid region changes to replace only the contributing component effect; stale preview results retain decoded/recognized inputs for the latest adjustment. Neutral/monochrome behavior and mask-tile skipping are verified.
- Style DNA schema2 / engine0.5.0 upgrades legacy0.4.0 schema1 recipes on read; SQLite remains3 and historical analysis profiles remain readable. New0.5 profiles/recipes require the new app.
- Real-model execution and region learning/application passed with network denied using external test-only photos. Tests and native-platform limits are recorded in VALIDATION.md.

## V0.4.0 - Style application, portable recipes and faster analysis

- Unified learned pair transforms, recorded XMP settings, finished-JPG references and bundled profiles into validated Style DNA (schema 1).
- Added a style workspace with original/edited previews, strength adjustment, two-style mixing, 12 derived film/cinema/artist profiles and saved recipes.
- Adapted reference targets to each input's tone distribution; optional low/mid/high-key subprofiles require three distinct supporting images. These are pixel-lighting groups, not semantic scene recognition.
- Added full-resolution JPEG copies with sRGB ICC and stripped EXIF/GPS, Lightroom-importable global XMP presets, and local style JSON import/export. Existing files are never overwritten.
- Composition remains color-only by default; users can show an aspect-ratio guide or explicitly crop an exported copy. No original is cropped.
- Added content-addressed, bounded SQLite analysis caching and pre-decode exact-duplicate exclusion; similar-image groups are review hints and remain included.
- Added analysis snapshot rename/delete, additive database schema 3, source preview reuse and deprecated Pillow API cleanup. Existing schema-0/1/2 data and 0.3.0 analysis snapshots remain readable; older apps cannot open schema 3.
- Corrected color-transform learning to subtract the observed tone transfer before measuring residual color. App/analysis versions are 0.4.0; analysis payload schema remains 1.
- Retained the embedded Mac component fix. Native Mac installation, Apple signing/notarization, semantic scene/local-mask models and exact Adobe rendering remain pending.

## Implemented - V0.3.1 Mac packaging repair

- [x] Use an embedded fragment URL for the component package.
- [x] Validate product references, required installation data and component identity/version before archive bytes.
- [x] Add regressions rejecting the previous external-relative reference.
- [ ] Confirm the corrected installer with Apple Installer on native M1 hardware.

## Implemented - V0.3.0

- [x] Continue Choose folder into RAW + JPG / RAW + XMP / JPG reference modes.
- [x] Review discovered files, exclude entries and resolve missing or ambiguous companions manually.
- [x] Decode RAW sensor data locally with rawpy/LibRaw and a recorded fixed camera-WB sRGB baseline.
- [x] Reuse registered tone/color analysis for RAW + edited JPG and label estimates as inferred.
- [x] Parse supported namespace-whitelisted global XMP parameters and RGB curves with bounds and safe XML handling.
- [x] Preserve missing/unsupported XMP semantics and separate recorded settings from rendered appearance.
- [x] Measure final JPG luminance/contrast/clipping, saturation, Lab/chroma, tonal zones, hue bands and palette.
- [x] Aggregate unique references with equal image weights, dispersion, consistency, sample limitations and appearance outliers.
- [x] Keep flagged outliers included until the user excludes them; deduplicate exact content only.
- [x] Add progress, per-file recovery and cancellation between files with completed results retained.
- [x] Show collection and individual results; save named analysis snapshots and reopen after app restart.
- [x] Add database schema 2 while preserving existing rows/settings; keep payload schema 1.
- [x] Update app/algorithm to 0.3.0 and include the RAW dependency in locked runtime/installer inputs.
- [x] Keep English/Korean resources, original preservation, GPS exclusion and local CPU execution.
- [x] Preserve the existing JPEG comparison workflow, summaries, curves, readability and display scaling.

## Implemented foundations

- [x] Modest crop/resize/rotation alignment with valid overlap and failure abstention.
- [x] Withhold photometric measurements for unreadable ICC profiles; keep inspectable geometry.
- [x] Separate inferred estimates, registration evidence, confidence and source hashes.
- [x] Cache/persist JPEG comparisons with stale-source and algorithm checks.
- [x] Provide private-runtime Windows x64 and macOS Apple Silicon/Intel installer tooling and diagnostics.
- [x] Provide pinned dependency files, synthetic analysis fixtures and a local-Xvfb GUI test runner.

## Validation and refinement

- [ ] Complete real-camera RAW, diverse XMP and reference-photo evaluation; calibrate heuristic confidence.
- [ ] Improve filename ambiguity, visual pairing, unsupported-camera guidance and near-duplicate detection.
- [ ] Expand alignment coverage without fabricating general perspective/local-edit support.
- [ ] Improve hue-band presentation and investigate sharpening/noise/grain inference.
- [ ] Extend supported XMP properties with explicit missing-value and rendering limits.
- [ ] Run native installer CI on Windows x64, macOS Apple Silicon and macOS Intel.
- [ ] Verify actual Windows DPI and macOS Retina/monitor transitions and usable viewport limits.
- [ ] Sign Windows releases and sign/notarize macOS releases.

Completed automated runs and artifact checks are recorded in `VALIDATION.md`; checklist items above do not substitute for that evidence.

## Style application and remaining work

- [x] Build shared application-ready Style DNA while preserving each source's evidence and uncertainty.
- [x] Apply saved styles to new images with strength controls and before/after previews.
- [x] Add derived built-in film/cinema/artist profiles and Hybrid Style mixing.
- [ ] Add semantic multilabel scene coverage and scene-specific profile deltas.
- [ ] Add local-region inference, composition scoring and user-approved crop suggestions.
- [x] Export non-destructive global XMP presets and validate round-trip supported settings.
- [ ] Evaluate preset import and appearance in actual Lightroom versions.
- [ ] Provide local model packs with mandatory CPU fallback.

V0.4.0 applies learned styles and exports JPG copies, global XMP presets and style JSON. All future work preserves offline execution, source bytes, GPS exclusion and selectable English/Korean. Mobile development remains outside scope.
