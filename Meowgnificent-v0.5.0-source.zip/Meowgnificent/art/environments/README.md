# Archive environments

`candlewick_archive.png` supplies the painted library shell. `archive_floor_materials.png` is an original generated four-material atlas added in v0.5.0: blue slate, charred stone, walnut planks and aged marble. `scripts/effects/archive_backdrop.gd` combines these with room-specific rugs, wards, banners, windows and other floor/perimeter detail.

All eight themes paint into one reusable 1280×800 SubViewport texture on arrival. The viewport is UPDATE_ONCE; combat frames draw its single cached sprite. The walkable room bounds and interactive shelf collisions are defined independently of decorative floor art.
