# Archive familiars artwork

`archive_familiars.png` is an original generated transparent sprite sheet made for Meowgnificent v0.5.0. It supplies painted wax, patinated steel, straw, fur, and leather details for the existing candle, broom, and bat enemies. Sprite regions and anchor coordinates are defined in `scripts/ai/candle_slime.gd`.

The single atlas is imported once and shared by every enemy across areas. Bodies and mirrored bat wings remain independent sprite parts, so existing animation and gameplay hitboxes are preserved. The small gold crown is a static vector silhouette marker for elite enemies.
