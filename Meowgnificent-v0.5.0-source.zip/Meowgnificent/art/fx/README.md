# Spell artwork

`painted_spell_fx.png` is an original generated transparent atlas for v0.5.0. It contains golden comet fire, an impact seal, a subdued red/gray fizzle and rising violet-gray smoke. `scripts/effects/spell_art.gd` defines clipped AtlasTexture regions shared across projectiles, impact feedback and miscasts. `roll_dust.svg` supplies the compact roll dust trail.

Baked light and smoke use textured quads, without runtime particle emitters, dynamic lights or postprocessing. The failure mark and WHOOPS text remain separate, so the miscast is identifiable through shape and text. Collision, damage and lifetime are independent of sprite artwork.
