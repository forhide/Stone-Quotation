class_name SpellArt
extends RefCounted

# Original painted fire, glyph and smoke share a single imported atlas.
const ATLAS: Texture2D = preload("res://art/fx/painted_spell_fx.png")
static var parts: Dictionary = {}

static func part(kind: String) -> Texture2D:
 if parts.has(kind): return parts[kind]
 var region := AtlasTexture.new()
 region.atlas=ATLAS
 match kind:
  "impact": region.region=Rect2(860,0,600,548)
  "fizzle": region.region=Rect2(30,650,750,260)
  "smoke": region.region=Rect2(820,555,670,469)
  _: region.region=Rect2(0,120,800,350)
 region.filter_clip=true
 parts[kind]=region
 return region
