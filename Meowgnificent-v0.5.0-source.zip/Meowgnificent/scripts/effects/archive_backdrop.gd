class_name ArchiveBackdrop
extends Node2D

# The painter is rendered into one 1280 x 800 cache by the room. None of the
# masonry, grain, inlays or lanterns below is rebuilt during combat.
const ROOM_ART: Texture2D = preload("res://art/environments/candlewick_archive.png")
const FLOOR_MATERIALS: Texture2D = preload("res://art/environments/archive_floor_materials.png")
const THEMES := ["candlewick", "loose_ends", "sootbound", "kettle_quill", "restricted", "bellkeeper", "paper_moon", "final_exam"]
const FLOOR := Rect2(105,170,1070,513)
var stage_index := 0
var _materials: Array[AtlasTexture] = []

func configure(index: int) -> void:
	stage_index = clampi(index,0,THEMES.size()-1)
	queue_redraw()

func theme_id() -> String:
	return THEMES[stage_index]

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,800),Color("0c111b"))
	var washes := [Color("ffffff"),Color("aabbdc"),Color("bc8770"),Color("f5d3a5"),Color("afa1cf"),Color("96c8c0"),Color("aaa2d0"),Color("ead49b")]
	draw_texture_rect(ROOM_ART,Rect2(20,54,1240,744),false,washes[stage_index])
	match stage_index:
		0: _candlewick()
		1: _loose_ends()
		2: _sootbound()
		3: _kettle_quill()
		4: _restricted()
		5: _bellkeeper()
		6: _paper_moon()
		7: _final_exam()
	# A soft inner frame embeds overlays in the painted masonry. All are baked.
	for i in range(8):
		var inset := float(i*3)
		draw_rect(Rect2(103+inset,165+inset,1074-inset*2,521-inset*2),Color(0.025,0.035,0.055,(8-i)*0.013),false,3)
	draw_rect(Rect2(0,0,1280,118),Color("0c111b"))
	draw_rect(Rect2(0,714,1280,86),Color("0c111b"))
	draw_line(Vector2(76,118),Vector2(1204,118),Color(0.68,0.52,0.31,0.32),1,true)
	draw_line(Vector2(76,712),Vector2(1204,712),Color(0.68,0.52,0.31,0.25),1,true)

func _candlewick() -> void:
	# Preserve the familiar painted tutorial. Loose folios and restrained brass
	# ornament give its quiet study a different identity from the later halls.
	for p in [Vector2(193,218),Vector2(1080,611),Vector2(183,615)]:
		_folio(p,Color("b7a17b"),-0.18 if p.x<400 else 0.25)
	for p in [Vector2(240,191),Vector2(1038,191)]:
		_inlaid_star(p,19,Color(0.74,0.58,0.30,0.36),8)
	_banner(Vector2(204,137),Color("293a48"),Color("bb985b"),0)
	_banner(Vector2(1070,137),Color("293a48"),Color("bb985b"),0)

func _loose_ends() -> void:
	# Long indigo runners turn this into a vaulted aisle. The stone remains
	# textured; projected window light and aisle borders change its architecture.
	_material(0,FLOOR,Color("9aaac8"))
	draw_rect(FLOOR,Color(0.06,0.12,0.22,0.14))
	for x in [302.0,640.0,978.0]:
		_rug(Rect2(x-66,184,132,477),Color("202e49"),Color("81919d"),0)
		for y in [236.0,420.0,603.0]:
			_inlaid_star(Vector2(x,y),22,Color(0.52,0.67,0.78,0.38),4)
	for x in [170.0,494.0,818.0]:
		_window_light(Vector2(x,177),Color(0.47,0.67,0.93,0.09),Vector2(104,225))
		_window(Vector2(x+38,142),Color("6b91b3"))
	for p in [Vector2(178,580),Vector2(1101,252),Vector2(489,219)]:
		_folio(p,Color("c0bfad"),0.15)

func _sootbound() -> void:
	# Charred gallery slabs, irregular ash deposits and fine ember-filled cracks.
	_material(1,FLOOR,Color("c7b4aa"))
	draw_rect(FLOOR,Color(0.105,0.065,0.065,0.20))
	for i in range(32):
		var p := Vector2(140+fmod(i*197.0,970),196+fmod(i*113.0,455))
		var radius := 15.0+fmod(i*13.0,31)
		_ellipse(p,Vector2(radius*1.6,radius*0.55),Color(0.018,0.018,0.024,0.21))
	for i in range(8):
		var p := Vector2(172+i*139,206+fmod(i*107.0,379))
		var points := PackedVector2Array([p,p+Vector2(29,-12),p+Vector2(57,8),p+Vector2(80,-4),p+Vector2(116,17)])
		draw_polyline(points,Color(0.015,0.009,0.012,0.8),5,true)
		draw_polyline(points,Color(0.82,0.31,0.10,0.32),1,true)
		for j in range(3):
			draw_circle(p+Vector2(15+j*30,-6+j%2*15),1.4,Color(0.91,0.44,0.18,0.43))
	for x in [247.0,511.0,775.0,1039.0]:
		_portrait(Vector2(x,143),Color("4b2429"))
	for p in [Vector2(188,237),Vector2(1087,616)]:
		_brazier(p,Color("e49952"))
	_inlaid_star(Vector2(640,431),142,Color(0.58,0.30,0.20,0.17),7)

func _kettle_quill() -> void:
	_wood_floor(Color("513b2e"),Color("8b6745"))
	_rug(Rect2(365,342,550,288),Color("354d47"),Color("c4a56c"),1)
	for p in [Vector2(194,246),Vector2(1093,605)]:
		_folio(p,Color("d3bb91"),-0.12)
	# A flat brass tea-service seal under the stall, not a physical obstacle.
	_ellipse(Vector2(640,317),Vector2(133,55),Color(0.03,0.025,0.02,0.42))
	_ellipse(Vector2(640,315),Vector2(125,50),Color(0.64,0.47,0.25,0.22))
	for x in [218.0,1062.0]:
		_banner(Vector2(x,139),Color("384c3a"),Color("d0ad6a"),1)
		_lantern(Vector2(x,173),Color("ffd49a"))
	for i in range(5):
		var p := Vector2(214+i*214,657)
		draw_line(p-Vector2(35,0),p+Vector2(35,0),Color(0.71,0.52,0.29,0.36),1,true)
		_inlaid_star(p,9,Color(0.78,0.63,0.36,0.45),4)

func _restricted() -> void:
	_material(3,FLOOR,Color("746b88"))
	draw_rect(FLOOR,Color(0.12,0.065,0.19,0.22))
	# Polished violet checker inlays, each with bevel and subtle stone grain.
	for row in range(7):
		for col in range(15):
			var r := Rect2(112+col*71,181+row*71,68,68)
			if (row+col)%2==0:
				draw_rect(r,Color(0.28,0.23,0.36,0.19))
			draw_line(r.position,r.position+Vector2(r.size.x,0),Color(0.53,0.45,0.60,0.14),1,true)
			draw_line(r.position,r.position+Vector2(0,r.size.y),Color(0.01,0.01,0.03,0.45),1,true)
	_ward(Vector2(640,430),160,Color(0.67,0.53,0.83,0.28),4)
	_ward(Vector2(640,430),123,Color(0.80,0.65,0.48,0.30),4)
	for x in [240.0,1040.0]:
		_window(Vector2(x,143),Color("aa87c4"))
		_window_light(Vector2(x-50,179),Color(0.70,0.44,0.88,0.09),Vector2(163,186))
		_banner(Vector2(x+125 if x<500 else x-125,141),Color("41304e"),Color("bb9dca"),2)
	for p in [Vector2(184,242),Vector2(1088,612)]:
		_folio(p,Color("a89cbe"),0.2)

func _bellkeeper() -> void:
	_material(0,FLOOR,Color("84aaa5"))
	draw_rect(FLOOR,Color(0.025,0.13,0.14,0.14))
	# Grated ornamental channels flank a broad stone causeway. Their narrow
	# metal covers are traversable, just like the surrounding room floor.
	for x in [109.0,1129.0]:
		draw_rect(Rect2(x,180,42,491),Color("153638"))
		for i in range(35):
			var y := 185+i*14
			draw_line(Vector2(x+6,y),Vector2(x+34,y+4),Color(0.30,0.67,0.63,0.20),1,true)
			draw_line(Vector2(x,y+8),Vector2(x+42,y+8),Color(0.26,0.35,0.31,0.75),2,true)
		for dx in [0,42]:
			draw_line(Vector2(x+dx,177),Vector2(x+dx,674),Color(0.44,0.59,0.51,0.45),3,true)
	for y in range(194,670,66):
		draw_rect(Rect2(233,y,814,60),Color(0.25,0.34,0.32,0.10))
		draw_line(Vector2(234,y+60),Vector2(1046,y+60),Color(0.02,0.06,0.07,0.70),2,true)
		draw_line(Vector2(234,y+2),Vector2(1046,y+2),Color(0.47,0.58,0.51,0.14),1,true)
	for p in [Vector2(640,267),Vector2(640,571)]:
		_ward(p,53,Color(0.53,0.76,0.66,0.25),6)
		_bell(p,Color(0.61,0.70,0.49,0.39),0.8)
	for x in [246.0,510.0,774.0,1038.0]:
		_banner(Vector2(x,137),Color("193e3c"),Color("8ba795"),3)

func _paper_moon() -> void:
	# Night market: richly woven star carpet, scalloped awning, paper lanterns.
	# The dark cloth veils the familiar book-wall silhouette around the stall.
	draw_rect(FLOOR,Color(0.11,0.065,0.20,0.67))
	_rug(Rect2(215,204,850,462),Color("3c3357"),Color("c6a6a0"),2)
	for col in range(11):
		for row in range(5):
			var p := Vector2(260+col*76,245+row*86)
			_inlaid_star(p,7 if (col+row)%2 else 11,Color(0.76,0.66,0.77,0.19),4)
	for i in range(11):
		var x := 119.0+i*104
		draw_polygon(PackedVector2Array([Vector2(x,127),Vector2(x+104,127),Vector2(x+104,161),Vector2(x+52,184),Vector2(x,161)]),PackedColorArray([Color("302a49") if i%2 else Color("5a4359")]))
		draw_polyline(PackedVector2Array([Vector2(x,161),Vector2(x+52,184),Vector2(x+104,161)]),Color("a28891"),1,true)
	for x in [228.0,432.0,848.0,1052.0]:
		draw_line(Vector2(x,129),Vector2(x,176),Color("5d536b"),1,true)
		_lantern(Vector2(x,191),Color("e9c5e0"))
	_moon(Vector2(640,215),30,Color(0.89,0.84,0.73,0.45))
	for p in [Vector2(171,606),Vector2(1114,606)]:
		_folio(p,Color("b9a3ba"),0.15)

func _final_exam() -> void:
	_material(3,FLOOR,Color("a79674"))
	draw_rect(FLOOR,Color(0.19,0.13,0.065,0.13))
	# Marble borders and an imposing, complete examination seal.
	for x in [143.0,1087.0]:
		draw_rect(Rect2(x,188,51,471),Color(0.67,0.57,0.36,0.18))
		for y in range(204,650,40):
			draw_line(Vector2(x+5,y),Vector2(x+46,y+14),Color(0.30,0.25,0.20,0.45),2,true)
	for rad in [183.0,174.0,136.0,127.0]:
		draw_arc(Vector2(640,428),rad,0,TAU,112,Color(0.83,0.66,0.34,0.39),1.5,true)
	_ward(Vector2(640,428),166,Color(0.89,0.72,0.41,0.36),8)
	_inlaid_star(Vector2(640,428),115,Color(0.88,0.68,0.32,0.31),8)
	for i in range(16):
		var p := Vector2(640,428)+Vector2.from_angle(i*TAU/16)*155
		_rune(p,10,Color(0.88,0.70,0.39,0.52),i)
	for x in [230.0,500.0,780.0,1050.0]:
		_banner(Vector2(x,137),Color("4b3430"),Color("d6b575"),4)
		_brazier(Vector2(x,191),Color("f3cf91"))
	for p in [Vector2(208,620),Vector2(1072,620)]:
		_inlaid_star(p,24,Color(0.81,0.63,0.33,0.39),8)

func _wood_floor(_base: Color, _grain: Color) -> void:
	# Real painted knots, sweeping grain and chipped plank joins replace the
	# flat procedural boards. Atlas regions are clipped to avoid edge bleed.
	_material(2,FLOOR,Color("cbb29c"))
	draw_rect(FLOOR,Color(0.06,0.035,0.025,0.10))

func _material(index: int, rect: Rect2, color: Color) -> void:
	if _materials.is_empty():
		var cell := FLOOR_MATERIALS.get_size()*0.5
		for i in range(4):
			var region := AtlasTexture.new()
			region.atlas=FLOOR_MATERIALS
			region.region=Rect2(Vector2((i%2)*cell.x,floori(i/2.0)*cell.y)+Vector2(2,2),cell-Vector2(4,4))
			region.filter_clip=true
			_materials.append(region)
	draw_texture_rect(_materials[index],rect,false,color)

func _rug(rect: Rect2, fill: Color, border: Color, style: int) -> void:
	draw_rect(rect.grow(7),Color(0.015,0.018,0.025,0.40))
	draw_rect(rect,fill)
	# Fine warp-and-weft and flecks of worn dye are static cloth detail, baked
	# into the same one-quad background as all architecture.
	for y in range(int(rect.position.y+1),int(rect.end.y-1),3):
		draw_line(Vector2(rect.position.x+1,y),Vector2(rect.end.x-1,y),Color(0.84,0.78,0.67,0.035 if y%2 else 0.065),1)
	for x in range(int(rect.position.x+2),int(rect.end.x-1),4):
		draw_line(Vector2(x,rect.position.y+1),Vector2(x,rect.end.y-1),Color(0.015,0.02,0.035,0.09),1)
	for i in range(170):
		var p := rect.position+Vector2(17+fmod(i*73.0,rect.size.x-34),17+fmod(i*41.0,rect.size.y-34))
		draw_line(p,p+Vector2(2.5,0),Color(border,0.055),1)
	draw_rect(rect.grow(-5),Color(border,0.64),false,2)
	draw_rect(rect.grow(-13),Color(border,0.27),false,1)
	for y in range(int(rect.position.y+24),int(rect.end.y-18),16):
		for side in [rect.position.x+8,rect.end.x-8]:
			draw_line(Vector2(side-2,y-4),Vector2(side+2,y+4),Color(border,0.40),1,true)
	for x in range(int(rect.position.x+10),int(rect.end.x-8),8):
		draw_line(Vector2(x,rect.position.y-5),Vector2(x+1,rect.position.y),Color(border,0.38),1,true)
		draw_line(Vector2(x,rect.end.y),Vector2(x-1,rect.end.y+5),Color(border,0.38),1,true)
	if style==1:
		var center := rect.get_center()
		for radius in [49.0,80.0,105.0]:
			_ellipse(center,Vector2(radius*1.75,radius),Color(border,0.20),false)
		_inlaid_star(center,41,Color(border,0.40),6)
	elif style==2:
		for p in [rect.position+Vector2(35,35),rect.end-Vector2(35,35),Vector2(rect.end.x-35,rect.position.y+35),Vector2(rect.position.x+35,rect.end.y-35)]:
			_inlaid_star(p,20,Color(border,0.55),8)

func _ward(center: Vector2, radius: float, color: Color, sides: int) -> void:
	draw_arc(center,radius,0,TAU,80,color,1,true)
	var polygon := PackedVector2Array()
	for i in range(sides+1):
		polygon.append(center+Vector2.from_angle(-PI/2+i*TAU/sides)*radius)
	draw_polyline(polygon,color,1.5,true)
	for i in range(sides):
		var p := center+Vector2.from_angle(-PI/2+i*TAU/sides)*(radius-12)
		_rune(p,7,color,i)

func _inlaid_star(center: Vector2, radius: float, color: Color, points: int) -> void:
	var polygon := PackedVector2Array()
	for i in range(points*2+1):
		polygon.append(center+Vector2.from_angle(-PI/2+i*PI/points)*(radius if i%2==0 else radius*0.30))
	draw_polyline(polygon,color,1,true)
	draw_circle(center,2,color)

func _ellipse(center: Vector2, radii: Vector2, color: Color, filled := true) -> void:
	draw_set_transform(center,0,radii)
	if filled:
		draw_circle(Vector2.ZERO,1,color)
	else:
		draw_arc(Vector2.ZERO,1,0,TAU,64,color,0.018,true)
	draw_set_transform(Vector2.ZERO)

func _rune(center: Vector2, size: float, color: Color, variant: int) -> void:
	var points := PackedVector2Array([center+Vector2(-size*0.5,size*0.5),center+Vector2(0,-size),center+Vector2(size*0.5,size*0.5)])
	draw_polyline(points,color,1,true)
	draw_line(center+Vector2(-size*0.6,0),center+Vector2(size*0.6,0),color,1,true)
	if variant%2==0:
		draw_line(center,center+Vector2(0,size),color,1,true)

func _folio(center: Vector2, color: Color, angle: float) -> void:
	draw_set_transform(center,angle)
	draw_rect(Rect2(-17,-11,36,25),Color(0.01,0.01,0.02,0.45))
	draw_rect(Rect2(-18,-13,34,23),color.darkened(0.35))
	draw_rect(Rect2(-15,-14,30,22),color)
	draw_line(Vector2(0,-13),Vector2(0,7),color.darkened(0.5),1,true)
	for i in range(4):
		draw_line(Vector2(-11,-9+i*4),Vector2(-4,-9+i*4),color.darkened(0.30),1,true)
		draw_line(Vector2(4,-9+i*4),Vector2(11,-9+i*4),color.darkened(0.30),1,true)
	draw_set_transform(Vector2.ZERO)

func _banner(center: Vector2, cloth: Color, edge: Color, motif: int) -> void:
	draw_line(center+Vector2(-21,-8),center+Vector2(21,-8),Color("100e18"),4,true)
	draw_polygon(PackedVector2Array([center+Vector2(-18,-7),center+Vector2(18,-7),center+Vector2(18,37),center+Vector2(0,49),center+Vector2(-18,37)]),PackedColorArray([cloth]))
	draw_polyline(PackedVector2Array([center+Vector2(-16,-5),center+Vector2(-16,35),center+Vector2(0,46),center+Vector2(16,35),center+Vector2(16,-5)]),Color(edge,0.6),1,true)
	draw_line(center+Vector2(-9,-4),center+Vector2(-9,33),Color(1,1,1,0.06),2,true)
	if motif==3:
		_bell(center+Vector2(0,17),Color(edge,0.7),0.52)
	elif motif==1:
		_folio(center+Vector2(0,17),edge.darkened(0.18),0)
	else:
		_inlaid_star(center+Vector2(0,17),11,Color(edge,0.75),6 if motif==2 else 8)

func _window(center: Vector2, glass: Color) -> void:
	draw_rect(Rect2(center-Vector2(27,14),Vector2(54,56)),Color("101826"))
	for row in range(3):
		for col in range(3):
			draw_rect(Rect2(center+Vector2(-22+col*15,-9+row*16),Vector2(13,14)),Color(glass,0.40+row*0.11))
	draw_rect(Rect2(center-Vector2(28,15),Vector2(56,58)),Color("665f59"),false,3)
	draw_line(center+Vector2(-30,44),center+Vector2(30,44),Color("b7b19d"),2,true)

func _window_light(start: Vector2, color: Color, extent: Vector2) -> void:
	var p := PackedVector2Array([start,start+Vector2(56,0),start+extent+Vector2(63,0),start+extent])
	draw_polygon(p,PackedColorArray([color,color,Color(color,0),Color(color,0)]))
	for i in [0.33,0.66]:
		draw_line(start+Vector2(56*i,0),start+extent+Vector2(63*i,0),Color(0.03,0.04,0.08,0.12),3,true)

func _portrait(center: Vector2, canvas: Color) -> void:
	var r := Rect2(center-Vector2(29,14),Vector2(58,63))
	draw_rect(r.grow(3),Color("171011"))
	draw_rect(r,Color("9e7141"))
	draw_rect(r.grow(-3),Color("382920"))
	draw_rect(r.grow(-7),canvas)
	_ellipse(center+Vector2(0,20),Vector2(13,18),Color("352c2d"))
	draw_circle(center+Vector2(0,5),9,Color("7b6055"))
	draw_arc(center+Vector2(0,2),11,PI,TAU,14,Color("b49971"),2,true)
	draw_line(center+Vector2(-10,35),center+Vector2(10,35),Color("785237"),1,true)

func _lantern(center: Vector2, light: Color) -> void:
	for i in range(5,0,-1):
		_ellipse(center,Vector2(10+i*5,12+i*5),Color(light,0.013))
	_ellipse(center,Vector2(12,16),light.darkened(0.15))
	_ellipse(center,Vector2(7,14),light)
	for dx in [-5.0,0.0,5.0]:
		draw_line(center+Vector2(dx,-14),center+Vector2(dx,14),Color(0.45,0.30,0.29,0.3),1,true)
	draw_line(center+Vector2(-8,-15),center+Vector2(8,-15),Color("65515d"),3,true)
	draw_line(center+Vector2(-8,15),center+Vector2(8,15),Color("65515d"),3,true)
	draw_line(center+Vector2(0,18),center+Vector2(0,26),Color("c5a495"),1,true)

func _brazier(center: Vector2, light: Color) -> void:
	for i in range(5,0,-1):
		_ellipse(center-Vector2(0,8),Vector2(14+i*8,8+i*4),Color(light,0.015))
	draw_circle(center,13,Color("15191e"))
	draw_arc(center,12,0,TAU,24,Color("9f7c4a"),3,true)
	for i in range(3):
		var p := center+Vector2((i-1)*6,-4)
		draw_polygon(PackedVector2Array([p+Vector2(-5,1),p+Vector2(-2,-12-i%2*5),p+Vector2(1,-6),p+Vector2(5,1)]),PackedColorArray([light]))

func _bell(center: Vector2, color: Color, factor: float) -> void:
	draw_set_transform(center,0,Vector2.ONE*factor)
	draw_polyline(PackedVector2Array([Vector2(-13,12),Vector2(-9,7),Vector2(-8,-8),Vector2(-4,-14),Vector2(4,-14),Vector2(8,-8),Vector2(9,7),Vector2(13,12),Vector2(-13,12)]),color,1.5,true)
	draw_circle(Vector2(0,16),3,color)
	draw_arc(Vector2(0,-16),3,PI,TAU,12,color,1.5,true)
	draw_set_transform(Vector2.ZERO)

func _moon(center: Vector2, radius: float, color: Color) -> void:
	# Two equal circles separated by half a radius meet at these exact
	# endpoints. Following their left arcs in opposite directions creates a
	# simple crescent polygon (approximate arc endpoints can self-intersect).
	var polygon := PackedVector2Array()
	var outer_angle := acos(0.25)
	var inner_angle := acos(-0.25)
	for i in range(33):
		polygon.append(center+Vector2.from_angle(outer_angle+i*(TAU-outer_angle*2)/32)*radius)
	for i in range(31,0,-1):
		polygon.append(center+Vector2(radius*0.5,0)+Vector2.from_angle(inner_angle+i*(TAU-inner_angle*2)/32)*radius)
	draw_colored_polygon(polygon,color)
