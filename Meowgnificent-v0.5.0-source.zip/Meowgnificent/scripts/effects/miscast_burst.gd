class_name MiscastBurst
extends Node2D

var room: Node2D
var age := 0.0
const DURATION := 1.05

func _ready() -> void:
	z_index = 20

func _process(delta: float) -> void:
	if room.state != "playing":
		return
	age += delta
	if age >= DURATION:
		queue_free()
	queue_redraw()

func _draw() -> void:
	var fade := clampf((DURATION-age)/0.35,0.0,1.0)
	# One layered smoke sprite, with crooked red sparks baked into the image.
	var spread := 0.68+age*0.48
	draw_set_transform(Vector2(0,-22-age*21),sin(age*6)*0.035,Vector2.ONE*spread)
	draw_texture_rect(SpellArt.part("smoke"),Rect2(-112,-127,224,157),false,Color(1,1,1,fade))
	draw_set_transform(Vector2.ZERO)
	var center := Vector2(0,-105-age*12)
	var red := Color(1,0.38,0.34,fade)
	# Shape + explicit text also distinguish failure without relying on color.
	draw_circle(center,13,Color(0.12,0.10,0.15,fade*0.95))
	draw_line(center-Vector2(6,6),center+Vector2(6,6),red,4,true)
	draw_line(center+Vector2(-6,6),center+Vector2(6,-6),red,4,true)
	var font := ThemeDB.fallback_font
	var text := "WHOOPS!"
	var at := center+Vector2(-font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,20).x*0.5,-22)
	draw_string_outline(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,20,5,Color(0.08,0.07,0.10,fade))
	draw_string(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color(1,0.67,0.60,fade))
