class_name WizardHUD
extends CanvasLayer

signal begin_requested
var room: Node2D
var health_label: Label
var health_bar: ProgressBar
var status_label: Label
var cooldown_label: Label
var roll_label: Label
var enemy_label: Label
var debug_label: Label
var overlay: PanelContainer
var overlay_title: Label
var overlay_body: Label
var play_button: Button
var incident_label: Label
var incident_time := 0.0
var outcome_time := 0.0
var outcome := ""
var portrait: CatPortrait
var menu_portrait: CatPortrait
var stage_label: Label
var room_label: Label
var wallet_label: Label
var inventory_button: Button
var legacy_button: Button
var sector_banner: SectorBanner
var route_nodes: Array[Label] = []
var observed_stage := -1
var observed_exit_open := false
var arrival_pending := true

func label_at(text: String, at: Vector2, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.position = at
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	add_child(label)
	return label

func panel_style(color: Color, border: Color, radius: int = 12) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 20
	style.content_margin_bottom = 20
	return style

func _ready() -> void:
	var ink := Color("ede3cc")
	var dim := Color("9098ad")
	label_at("THE DEPARTMENT OF UNSTABLE MAGIC",Vector2(52,24),12,Color("c4a46d"))
	label_at("Meowgnificent",Vector2(49,42),37,ink)
	label_at("the wizard cat",Vector2(52,88),15,dim)
	stage_label=label_at("",Vector2(950,22),16,Color("dfbf84"))
	stage_label.size=Vector2(280,20)
	stage_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	room_label=label_at("",Vector2(750,49),21,ink)
	room_label.size=Vector2(480,32)
	room_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	enemy_label = label_at("",Vector2(980,88),14,dim)
	enemy_label.size=Vector2(250,20)
	enemy_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	var route := HBoxContainer.new()
	route.position=Vector2(750,88)
	route.mouse_filter=Control.MOUSE_FILTER_IGNORE
	route.add_theme_constant_override("separation",4)
	add_child(route)
	for index in range(room.stages.size()):
		var stop := Label.new()
		stop.custom_minimum_size=Vector2(23,20)
		stop.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		stop.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
		stop.mouse_filter=Control.MOUSE_FILTER_IGNORE
		stop.add_theme_font_size_override("font_size",11)
		stop.text="S" if str(room.stages[index].kind)=="shop" else str(index+1)
		stop.tooltip_text="Area %02d: %s" % [index+1,str(room.stages[index].name)]
		route.add_child(stop)
		route_nodes.append(stop)
	label_at("CROWNS  /  STARLIGHT",Vector2(433,26),11,Color("c4a46d"))
	wallet_label=label_at("0  /  0",Vector2(433,44),23,ink)
	inventory_button=Button.new()
	inventory_button.position=Vector2(432,80)
	inventory_button.size=Vector2(260,28)
	var gear_style := panel_style(Color("171f30"),Color("64563f"),6)
	gear_style.content_margin_top=4
	gear_style.content_margin_bottom=4
	gear_style.content_margin_left=12
	gear_style.content_margin_right=12
	for button_state in ["normal","hover","pressed","disabled"]:
		inventory_button.add_theme_stylebox_override(button_state,gear_style)
	inventory_button.add_theme_font_size_override("font_size",12)
	inventory_button.pressed.connect(func(): room.open_inventory())
	add_child(inventory_button)
	var bottom := Panel.new()
	bottom.position = Vector2(45,718)
	bottom.size = Vector2(1190,66)
	bottom.add_theme_stylebox_override("panel",panel_style(Color("151c2b"),Color("364050")))
	add_child(bottom)
	portrait = CatPortrait.new()
	portrait.position = Vector2(53,721)
	portrait.size = Vector2(62,59)
	add_child(portrait)
	health_label = label_at("",Vector2(125,726),14,ink)
	health_bar = ProgressBar.new()
	health_bar.position = Vector2(126,754)
	health_bar.size = Vector2(136,8)
	health_bar.show_percentage = false
	health_bar.add_theme_stylebox_override("background",panel_style(Color("313144"),Color("313144"),4))
	health_bar.add_theme_stylebox_override("fill",panel_style(Color("d99a82"),Color("d99a82"),4))
	for kind in ["background", "fill"]:
		var bar_style := health_bar.get_theme_stylebox(kind) as StyleBoxFlat
		bar_style.content_margin_left = 0
		bar_style.content_margin_right = 0
		bar_style.content_margin_top = 0
		bar_style.content_margin_bottom = 0
	add_child(health_bar)
	label_at("LMB / SPACE",Vector2(296,729),12,Color("c4a46d"))
	cooldown_label = label_at("",Vector2(296,748),16,ink)
	roll_label=label_at("",Vector2(1010,763),12,Color("d7c49e"))
	status_label = label_at("A very round cat. A very unreliable wizard.",Vector2(495,739),17,ink)
	incident_label = label_at("",Vector2(295,132),18,Color("ffcc99"))
	incident_label.add_theme_color_override("font_shadow_color",Color("10131c"))
	incident_label.add_theme_constant_override("shadow_offset_x",2)
	incident_label.add_theme_constant_override("shadow_offset_y",2)
	debug_label = label_at("",Vector2(820,697),11,dim)
	label_at("WASD MOVE  ·  SHIFT ROLL  ·  I GEAR  ·  E INTERACT  ·  ESC PAUSE",Vector2(310,693),11,dim)
	overlay = PanelContainer.new()
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay.add_theme_stylebox_override("panel",panel_style(Color("171f30"),Color("c4a46d"),18))
	add_child(overlay)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",17)
	overlay.add_child(box)
	var eyebrow := Label.new()
	eyebrow.text = "A PRACTICAL EXAM IN QUESTIONABLE MAGIC"
	eyebrow.add_theme_font_size_override("font_size",12)
	eyebrow.modulate = Color("c4a46d")
	box.add_child(eyebrow)
	menu_portrait = CatPortrait.new()
	menu_portrait.custom_minimum_size = Vector2(100,100)
	box.add_child(menu_portrait)
	overlay_title = Label.new()
	overlay_title.add_theme_font_size_override("font_size",30)
	box.add_child(overlay_title)
	overlay_body = Label.new()
	overlay_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_body.custom_minimum_size = Vector2(470,85)
	overlay_body.add_theme_font_size_override("font_size",16)
	overlay_body.modulate = Color("bac2d2")
	box.add_child(overlay_body)
	play_button = Button.new()
	play_button.custom_minimum_size = Vector2(0,46)
	play_button.add_theme_stylebox_override("normal",panel_style(Color("68533c"),Color("bf9e66"),8))
	play_button.add_theme_stylebox_override("hover",panel_style(Color("876a48"),Color("e2c184"),8))
	play_button.add_theme_color_override("font_color",Color("fff1d2"))
	play_button.pressed.connect(func(): begin_requested.emit())
	box.add_child(play_button)
	legacy_button=Button.new()
	legacy_button.text="M  ·  Legacy studies"
	legacy_button.custom_minimum_size=Vector2(0,32)
	legacy_button.add_theme_color_override("font_color",Color("c8b7ea"))
	legacy_button.pressed.connect(func(): room.open_legacy())
	box.add_child(legacy_button)
	show_overlay("A minor magical incident", "8 areas: a tutorial, dangerous archives, two shops, one final exam.\nEnemies drop Crowns and gear. I: equip. E: interact.\nStarlight and legacy studies survive defeat.", "Begin expedition   /   ENTER")
	overlay.position = Vector2(600,240)
	overlay.size = Vector2(550,315)
	sector_banner=SectorBanner.new()
	add_child(sector_banner)

func update_route() -> void:
	for index in range(route_nodes.size()):
		var stop := route_nodes[index]
		var active: bool=index==room.run.stage_index
		var visited: bool=index<room.run.stage_index
		var shop := str(room.stages[index].kind)=="shop"
		stop.set_meta("active",active)
		stop.set_meta("visited",visited)
		stop.set_meta("shop",shop)
		var style := panel_style(Color("17212e"),Color("354254"),3)
		style.content_margin_left=0
		style.content_margin_right=0
		style.content_margin_top=0
		style.content_margin_bottom=0
		if active:
			style.bg_color=Color("cfb27c")
			style.border_color=Color("ffdda0")
		elif visited:
			style.bg_color=Color("29453f")
			style.border_color=Color("6e9a87")
		stop.add_theme_stylebox_override("normal",style)
		stop.add_theme_color_override("font_color",Color("17202b") if active else Color("9ab6a7") if visited else Color("8c97a9"))

func sync_sector_notice(delta: float) -> void:
	var total: int=room.stages.size()
	if observed_stage!=room.run.stage_index:
		observed_stage=room.run.stage_index
		arrival_pending=true
		observed_exit_open=room.exit_open
		update_route()
	if room.state=="playing" and arrival_pending:
		sector_banner.announce_arrival(observed_stage,total,room.stage_def,room.enemies.size())
		arrival_pending=false
	elif room.state=="playing" and room.exit_open and not observed_exit_open and observed_stage+1<total:
		sector_banner.announce_clear(observed_stage,total,str(room.stages[observed_stage+1].name))
	observed_exit_open=room.exit_open
	sector_banner.tick(delta,room.state=="playing")

func show_overlay(title: String, body: String, button: String) -> void:
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay_title.text = title
	overlay_body.text = body
	play_button.text = button
	overlay.show()

func show_incident(message: String, color: Color) -> void:
	incident_label.text=message
	incident_label.modulate=color
	incident_time=2.7

func show_outcome(result: String) -> void:
	outcome = result
	outcome_time = 1.5

func _process(delta: float) -> void:
	if not is_instance_valid(room.player):
		return
	portrait.sync_state(room.state,outcome,outcome_time,room.player.invulnerability)
	menu_portrait.sync_state(room.state,outcome,outcome_time,room.player.invulnerability)
	health_label.text = "VITALITY     %d / %d" % [room.player.health.current,room.player.health.maximum]
	stage_label.text="AREA %02d / %02d  ·  %s" % [room.run.stage_index+1,room.stages.size(),str(room.stage_def.kind).to_upper()]
	sync_sector_notice(delta)
	room_label.text=str(room.stage_def.name)
	wallet_label.text="%d  /  %d" % [room.run.gold,room.profile.starlight]
	inventory_button.text="I  ·  Equipment  %d / 18" % room.run.inventory.size()
	inventory_button.disabled=room.state!="playing"
	legacy_button.visible=room.state in ["intro","defeated","cleared","legacy"]
	health_bar.max_value = room.player.health.maximum
	health_bar.value = room.player.health.current
	roll_label.text="SHIFT ROLL / "+("RECOVERING" if room.player.roll_cooldown>0 else "READY")
	enemy_label.text = "PASSAGE OPEN  ·  ENTER" if room.exit_open else "%02d foes  ·  passage locked" % room.enemies.size()
	cooldown_label.text = "Fireball  ·  READY" if room.spells.cooldown <= 0 else "Fireball  ·  %.1fs" % room.spells.cooldown
	debug_label.text = "F1 NEXT: SUCCESS   F2: MISCAST   F3: OVERREACTION   |   %s" % ("RANDOM" if room.spells.resolver.forced.is_empty() else room.spells.resolver.forced.to_upper())
	if room.state=="playing":
		outcome_time = maxf(0.0,outcome_time-delta)
		incident_time=maxf(0,incident_time-delta)
	incident_label.visible=incident_time>0 and room.state!="intro"
	incident_label.position.y=580 if str(room.stage_def.kind)=="shop" else 132
	if outcome_time > 0:
		status_label.text = {"success":"SUCCESS  /  Almost professional.","miscast":"MISCAST!  /  Improvise. Quickly.","overreaction":"OVERREACTION  /  A proportionate response."}.get(outcome,"")
		status_label.modulate = {"success":Color("b5d6c0"),"miscast":Color("ff8278"),"overreaction":Color("ffcd84")}.get(outcome,Color.WHITE)
	else:
		status_label.text = "PASSAGE OPEN  /  ENTER to continue" if room.exit_open else "A very round cat. A very unreliable wizard."
		status_label.modulate = Color.WHITE
