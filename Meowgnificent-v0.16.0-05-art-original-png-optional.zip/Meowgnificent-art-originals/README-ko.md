# 선택 자료: 변환 전 PNG

이 7개는 현재 Godot `.res`와 대응하는 변환 전 원본입니다. 실행에는 필요하지 않고, 현재 HD 리소스보다 해상도가 낮습니다. 현재 사용 중인 다른 PNG 아트는 필수 02~04 ZIP에 들어 있습니다. 실행 프로젝트에 덮어쓰지 말고 참고용으로 별도 보관하세요. 기존 픽셀은 변경하지 않았습니다.

# 그래픽 파일 지도

01~04를 복원하면 현재 실행용 아트가 모두 갖춰집니다. 현재 PNG·SVG·폰트·효과음과 `.import`는 원본 바이트 그대로 들어 있습니다. 아틀라스 잘라 쓰기는 `scripts/presentation/`와 `scripts/player/`가 담당합니다.

| 묶음 | 포함 범위 |
| --- | --- |
| Meowgnificent-v0.16.0-02-art-characters.zip | 고양이·NPC·적·보스 |
| Meowgnificent-v0.16.0-03-art-world-story.zip | 배경·이야기·소품 |
| Meowgnificent-v0.16.0-04-art-equipment-fx-ui.zip | 장비·FX·UI·폰트·효과음 |

## HD 리소스와 선택 원본 PNG

`.res`는 Godot에서 읽는 실제 텍스처 소스이며 `.godot/` 가져오기 캐시와 다릅니다. 아래 PNG는 과거의 변환 전 그림입니다. 크기·아틀라스 좌표·알파·팔레트를 확인한 뒤 실제 리소스 생성/연결까지 수정해야 게임에 반영됩니다. 자동 교체하지 마세요.

| 현재 실행 파일 | 현재 크기 | 05의 참고 PNG | 참고 크기 |
| --- | --- | --- | --- |
| `art/hd/pastel_meme_actions.res` | 3072×2048 | `art/characters/pastel_meme_actions.png` | 1536×1024 |
| `art/hd/animal_cast.res` | 3072×2048 | `art/npc/animal_cast.png` | 1536×1024 |
| `art/hd/perfect_grimoire.res` | 2508×2508 | `art/grimoire/perfect_grimoire.png` | 1254×1254 |
| `art/hd/hd_academy_library.res` | 3840×2560 | `art/environments/hd_academy_library.png` | 1536×1024 |
| `art/hd/hd_basement_storeroom.res` | 3840×2560 | `art/environments/hd_basement_storeroom.png` | 1536×1024 |
| `art/hd/hd_forbidden_garden.res` | 3840×2560 | `art/environments/hd_forbidden_garden.png` | 1536×1024 |
| `art/hd/hd_grand_archive.res` | 3840×2560 | `art/environments/hd_grand_archive.png` | 1536×1024 |

새 장비 48점은 `art/equipment/journey_weapons.png`, `journey_trinkets.png`에 있습니다. 고양이 보행은 `art/characters/meme_walk.png`와 `scripts/player/grounded_gait.gd`를 확인하세요. 폰트·엔진 라이선스는 `docs/`와 `art/fonts/`에 보존했습니다. 생성 아트 출처는 `docs/ART_REFERENCE.md`와 각 아트 폴더 README에 있습니다.

