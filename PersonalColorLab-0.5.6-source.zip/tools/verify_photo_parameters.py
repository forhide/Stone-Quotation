"""Execute photographic parameter learning/rendering using generated local inputs.

No external images, network, Adobe software, or hidden runtime dependency is
required. These controlled fixtures verify parameter wiring and non-destructive
contracts; they do not establish aesthetic quality or Adobe pixel equivalence.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
from io import BytesIO
import json
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import xml.etree.ElementTree as ET

if '--installed' not in sys.argv:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cv2
import numpy as np
from PIL import Image, ImageCms

from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core import alignment
from personal_color_lab.core.detail_recipe import neutral_detail_profile
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.reference_analysis import analyze_reference
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.spatial_render import apply_details
from personal_color_lab.core.source_workflow import analyze_inputs, discover_inputs
from personal_color_lab.core.style_dna import (blend_styles, dna_from_batch,
                                               dna_from_pair, identity_dna,
                                               load_style_file, validate_dna)
from personal_color_lab.core.style_render import (apply_pixels, export_jpeg,
                                                  export_style_json, export_xmp,
                                                  prepare_style, render_preview,
                                                  _render_regions)
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.xmp_analysis import analyze_raw_xmp

_LUMA = np.array([.2126, .7152, .0722], np.float32)
_CRS = '{http://ns.adobe.com/camera-raw-settings/1.0/}'


def denied(*args, **kwargs):
    raise AssertionError('Photographic parameter processing attempted network access.')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture(seed=31):
    """Separate spatial scales, chromatic structure, and a noisy flat patch."""
    y, x = np.mgrid[:480, :640]
    light = (.48 + .10 * np.sin(x / 31) + .075 * np.sin(y / 23)
             + .06 * np.sin((x + y) / 5.5) + .045 * np.sin(x / .8))
    rgb = np.stack([light + .07 * np.sin(y / 71),
                    light - .04 * np.sin(x / 73),
                    light + .05 * np.cos((x + y) / 47)], axis=2)
    rng = np.random.default_rng(seed)
    rgb[330:470, 15:235] = .49 + rng.normal(0, .025, (140, 220, 3))
    return np.rint(np.clip(rgb, .08, .92) * 255).astype('uint8')


def write_xmp(path, parameters):
    attrs = ' '.join(f'crs:{key}="{value}"' for key, value in parameters.items())
    path.write_text('<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
                    'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
                    + attrs + '/>', encoding='utf-8')


def recorded_style(root, raw, parameters, name):
    sidecar = root / (name + '.xmp')
    write_xmp(sidecar, parameters)
    payload = analyze_raw_xmp(raw, sidecar)
    assert payload['status'] == 'ok', payload
    dna = dna_from_batch({'mode': 'raw_xmp', 'results': [{'status': 'ok', 'payload': payload}]}, name)
    return dna, payload, sidecar


def mean_change(a, b):
    return float(np.mean(np.abs(a.astype(float) - b.astype(float))))


def settings(path):
    root = ET.fromstring(path.read_bytes())
    return {key[len(_CRS):]: value for element in root.iter()
            for key, value in element.attrib.items() if key.startswith(_CRS)}


def run_checks(root):
    start = time.monotonic()
    checks = []
    tracked = {}
    raw = write_test_dng(root / 'controlled.dng', width=640, height=480)
    pixels = fixture()
    source = root / 'controlled.jpg'
    Image.fromarray(pixels).save(source, quality=100, subsampling=0)
    tracked.update({raw: sha(raw), source: sha(source)})
    source_pixels = np.array(Image.open(source).convert('RGB'))
    learned = {}

    for name, adobe, amount, control in (
        ('clarity', 'Clarity2012', 65, 'clarity'),
        ('texture', 'Texture', 65, 'texture'),
        ('sharpening', 'Sharpness', 110, 'sharpening'),
        ('luminance_noise_reduction', 'LuminanceSmoothing', 90, 'denoise_luma'),
        ('color_noise_reduction', 'ColorNoiseReduction', 90, 'denoise_color'),
    ):
        dna, payload, sidecar = recorded_style(root, raw, {adobe: amount}, name)
        tracked[sidecar] = sha(sidecar)
        effective, _ = prepare_style(source_pixels, dna)
        rendered, _ = apply_pixels(source_pixels, effective)
        observed = dna['detail_profile']['support'][control]
        assert observed['basis'] == 'recorded' and observed['confidence'] == 1
        difference = mean_change(rendered, source_pixels)
        assert difference > .01, (name, difference)
        assert payload['parameters'][adobe] == amount
        assert payload['provenance']['raw_decoded'] is False
        assert payload['provenance']['scene_baseline']['decoded'] is True
        assert np.array_equal(source_pixels, np.array(Image.open(source)))
        checks.append({'check': 'recorded_' + name + '_changes_pixels',
                       'mean_absolute_rgb_change': round(difference, 5),
                       'support': observed, 'adobe_pixel_equivalence': False})
        learned[name] = dna

    for name, adobe, amount in (('contrast', 'Contrast2012', 65),
                                ('saturation', 'Saturation', -45),
                                ('vibrance', 'Vibrance', 55)):
        dna, _, sidecar = recorded_style(root, raw, {adobe: amount}, name)
        tracked[sidecar] = sha(sidecar)
        rendered = apply_pixels(source_pixels, prepare_style(source_pixels, dna)[0])[0]
        difference = mean_change(rendered, source_pixels)
        assert difference > .1, (name, difference)
        if name == 'contrast':
            assert np.std(rendered.astype(float) @ _LUMA) > np.std(source_pixels.astype(float) @ _LUMA)
        elif name == 'saturation':
            assert cv2.cvtColor(rendered.astype(np.float32) / 255, cv2.COLOR_RGB2HSV)[:, :, 1].mean() < cv2.cvtColor(source_pixels.astype(np.float32) / 255, cv2.COLOR_RGB2HSV)[:, :, 1].mean()
        checks.append({'check': 'recorded_' + name + '_changes_pixels',
                       'mean_absolute_rgb_change': round(difference, 5)})

    parameters = {'Clarity2012': 42, 'Texture': -28, 'Sharpness': 66,
                  'SharpenRadius': 1.7, 'SharpenEdgeMasking': 38,
                  'LuminanceSmoothing': 29, 'ColorNoiseReduction': 34,
                  'Contrast2012': 18, 'Saturation': -12, 'Vibrance': 22,
                  'Dehaze': 31, 'ParametricDarks': -16}
    combined, _, sidecar = recorded_style(root, raw, parameters, 'combined')
    tracked[sidecar] = sha(sidecar)
    preview = render_preview(source, combined, scene_override=[])
    support = preview['parameter_support']
    assert {'Clarity2012', 'Texture', 'Sharpness', 'ColorNoiseReduction', 'Contrast2012', 'Saturation'} <= set(support['pixel_applied'])
    assert {'Dehaze', 'ParametricDarks'} <= set(support['xmp_only'])
    assert not set(support['pixel_applied']) & set(support['xmp_only'])
    portable = root / 'combined-preset.xmp'
    export_xmp(portable, combined, preview['effective'])
    exported_settings = settings(portable)
    for name in ('Clarity2012', 'Texture', 'Sharpness', 'SharpenRadius',
                 'SharpenEdgeMasking', 'LuminanceSmoothing', 'ColorNoiseReduction', 'Dehaze', 'ParametricDarks'):
        assert float(exported_settings[name]) == parameters[name], (name, exported_settings.get(name))
    checks.append({'check': 'supported_pixels_and_recorded_xmp_only_are_explicit',
                   'pixel_applied': support['pixel_applied'], 'xmp_only': support['xmp_only'],
                   'detail_and_recorded_only_sidecar_values_retained': True,
                   'approximate_renderer': support['approximate_renderer']})

    output = root / 'rendered-copy.jpg'
    exported = export_jpeg(source, output, combined,
                           expected_fingerprint=preview['source_fingerprint'], scene_override=[])
    expected_stream = BytesIO()
    icc = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    Image.fromarray(preview['rendered']).save(expected_stream, format='JPEG', quality=95,
                                             subsampling=0, icc_profile=icc)
    with Image.open(output) as image, Image.open(BytesIO(expected_stream.getvalue())) as expected:
        assert np.array_equal(np.array(image), np.array(expected))
        assert image.info.get('icc_profile') and not image.getexif()
    assert exported['source_unchanged'] and exported['parameter_support'] == support
    style_json = root / 'controlled-style.json'
    export_style_json(style_json, combined)
    assert load_style_file(style_json) == combined
    assert 'original_path' not in style_json.read_text() and 'GPS' not in portable.read_text()
    checks.append({'check': 'preview_jpeg_and_portable_style_agree',
                   'jpeg_pixels_match_preview_after_same_encoding': True,
                   'profile_roundtrip': True, 'source_exif_exported': False})

    zero = render_preview(source, combined, strength=0, base=preview, scene_override=[])
    assert np.array_equal(zero['rendered'], zero['original'])
    zero_xmp = root / 'zero.xmp'
    export_xmp(zero_xmp, combined, preview['effective'], 0)
    zero_settings = settings(zero_xmp)
    assert all(float(zero_settings[name]) == 0 for name in ('Clarity2012', 'Texture', 'Sharpness', 'LuminanceSmoothing', 'ColorNoiseReduction', 'Dehaze'))
    checks.append({'check': 'zero_strength_is_pixel_identity', 'xmp_effect_amounts_zero': True})

    hybrid = blend_styles([learned['clarity'], learned['texture']], [.25, .75], 'Controlled hybrid')
    effective, _ = prepare_style(source_pixels, hybrid)
    assert abs(effective['detail_profile']['controls']['clarity'] - .65 * .25) < 1e-12
    assert abs(effective['detail_profile']['controls']['texture'] - .65 * .75) < 1e-12
    assert effective['recorded_parameters'] == {}
    rendered = apply_pixels(source_pixels, effective)[0]
    assert np.array_equal(rendered, apply_details(source_pixels, effective['detail_profile']))
    checks.append({'check': 'hybrid_mixes_detail_recipe_once',
                   'clarity': effective['detail_profile']['controls']['clarity'],
                   'texture': effective['detail_profile']['controls']['texture'],
                   'component_absolute_xmp_settings_not_reused': True})

    pair_folder = root / 'raw-jpg-spatial'
    pair_folder.mkdir()
    pair_raw = pair_folder / 'observed.dng'
    pair_raw.write_bytes(raw.read_bytes())
    tracked[pair_raw] = sha(pair_raw)
    raw_pixels, _, _ = decode_raw(pair_raw)
    y = raw_pixels.astype(np.float32) / 255 @ _LUMA
    # An independently generated multiscale edit, not the production renderer.
    blurred = [cv2.GaussianBlur(y, (0, 0), sigma * 640 / 1024,
                                borderType=cv2.BORDER_REFLECT_101) for sigma in (1, 3, 12)]
    delta = .45 * .65 * (blurred[1] - blurred[2]) + .30 * .65 * (blurred[0] - blurred[1])
    edited_pixels = np.rint(np.clip(raw_pixels.astype(float) + 255 * delta[:, :, None], 0, 255)).astype('uint8')
    edited = pair_folder / 'observed.jpg'
    Image.fromarray(edited_pixels).save(edited, quality=100, subsampling=0)
    tracked[edited] = sha(edited)
    original_decoder = alignment.decode_raw
    decode_count = []
    def counted_decode(*args, **kwargs):
        decode_count.append(kwargs.get('quality'))
        return original_decoder(*args, **kwargs)
    alignment.decode_raw = counted_decode
    try:
        pair_batch = analyze_inputs(discover_inputs(pair_folder, 'raw_jpg')['items'], 'raw_jpg')
    finally:
        alignment.decode_raw = original_decoder
    assert pair_batch['counts']['successful'] == 1 and len(decode_count) == 1
    pair = pair_batch['results'][0]['payload']
    assert pair['status'] == 'ok' and pair['detail']['kind'] == 'paired', pair
    inferred = dna_from_pair(pair, 'Observed details')
    for name in ('clarity', 'texture'):
        assert pair['detail']['controls'][name]['direction'] == 'higher'
        assert inferred['detail_profile']['support'][name]['basis'] == 'inferred'
        assert inferred['detail_profile']['controls'][name] > .3
    assert inferred['detail_profile']['support']['sharpening']['basis'] == 'unavailable'
    inferred_preview = render_preview(pair_raw, inferred, scene_override=[])
    before_error = mean_change(inferred_preview['original'], edited_pixels)
    after_error = mean_change(inferred_preview['rendered'], edited_pixels)
    detail_only = identity_dna('Observed spatial component')
    detail_only['detail_profile'] = copy.deepcopy(inferred['detail_profile'])
    component_render = apply_pixels(inferred_preview['original'], detail_only)[0]
    component_error = mean_change(component_render, edited_pixels)
    assert component_error < before_error, (before_error, component_error)
    color_only = copy.deepcopy(inferred_preview['effective'])
    color_only['detail_profile'] = neutral_detail_profile()
    color_component_error = mean_change(apply_pixels(inferred_preview['original'], color_only)[0], edited_pixels)
    assert after_error < min(before_error, color_component_error), (before_error, after_error, color_component_error)
    assert 'global_tone_transfer' in pair['tone']
    checks.append({'check': 'raw_jpg_learns_observed_local_contrast_and_texture',
                   'controls': pair['detail']['controls'],
                   'actual_folder_workflow': True, 'raw_decodes_during_analysis': len(decode_count),
                   'rgb_error_before': round(before_error, 5), 'rgb_error_after': round(after_error, 5),
                   'isolated_spatial_component_error': round(component_error, 5),
                   'isolated_color_component_error': round(color_component_error, 5),
                   'global_tone_transfer_separately_recorded': 'global_tone_transfer' in pair['tone'],
                   'joint_tone_spatial_fit': pair['tone'].get('decomposition'),
                   'fixture_detail_color_behavior': 'additive_equal_rgb_luma_change_also_changes_chroma',
                   'full_recipe_pixel_match_guaranteed': False,
                   'fine_detail_unavailable_when_not_proven': True,
                   'exact_adobe_sliders_recovered': False})

    preserving_folder = root / 'raw-jpg-hue-preserving-spatial'
    preserving_folder.mkdir()
    preserving_raw = preserving_folder / 'preserving.dng'
    preserving_raw.write_bytes(raw.read_bytes())
    tracked[preserving_raw] = sha(preserving_raw)
    rgb = raw_pixels.astype(np.float32) / 255
    y = rgb @ _LUMA
    desired = np.clip(y + delta, 0, 1)
    preserving_pixels = np.rint(np.clip(rgb * (desired / np.maximum(y, .0001))[:, :, None], 0, 1) * 255).astype('uint8')
    preserving_edited = preserving_folder / 'preserving.jpg'
    Image.fromarray(preserving_pixels).save(preserving_edited, quality=100, subsampling=0)
    tracked[preserving_edited] = sha(preserving_edited)
    decode_count.clear()
    alignment.decode_raw = counted_decode
    try:
        preserving_batch = analyze_inputs(discover_inputs(preserving_folder, 'raw_jpg')['items'], 'raw_jpg')
    finally:
        alignment.decode_raw = original_decoder
    assert preserving_batch['counts']['successful'] == 1 and len(decode_count) == 1
    preserving_pair = preserving_batch['results'][0]['payload']
    preserving_dna = dna_from_batch(preserving_batch, 'Hue-preserving observed details')
    preserving_preview = render_preview(preserving_raw, preserving_dna, scene_override=[])
    preserving_before = mean_change(preserving_preview['original'], preserving_pixels)
    preserving_after = mean_change(preserving_preview['rendered'], preserving_pixels)
    preserving_color = copy.deepcopy(preserving_preview['effective'])
    preserving_color['detail_profile'] = neutral_detail_profile()
    preserving_color_error = mean_change(apply_pixels(preserving_preview['original'], preserving_color)[0], preserving_pixels)
    preserving_detail = identity_dna('Hue-preserving spatial component')
    preserving_detail['detail_profile'] = copy.deepcopy(preserving_dna['detail_profile'])
    preserving_detail_error = mean_change(apply_pixels(preserving_preview['original'], preserving_detail)[0], preserving_pixels)
    assert preserving_after < min(preserving_before, preserving_color_error), (preserving_before, preserving_after, preserving_color_error)
    assert 'global_tone_transfer' in preserving_pair['tone']
    assert preserving_detail_error < preserving_before
    assert all(preserving_pair['detail']['controls'][name]['direction'] == 'higher' for name in ('clarity', 'texture'))
    checks.append({'check': 'raw_jpg_hue_preserving_spatial_recipe_improves_controlled_match',
                   'actual_folder_workflow': True, 'raw_decodes_during_analysis': len(decode_count),
                   'controls': preserving_pair['detail']['controls'],
                   'rgb_error_before': round(preserving_before, 5), 'rgb_error_after': round(preserving_after, 5),
                   'isolated_color_component_error': round(preserving_color_error, 5),
                   'global_tone_transfer_separately_recorded': 'global_tone_transfer' in preserving_pair['tone'],
                   'joint_tone_spatial_fit': preserving_pair['tone'].get('decomposition'),
                   'isolated_spatial_component_error': round(preserving_detail_error, 5),
                   'fixture_detail_color_behavior': 'independent_hue_preserving_luma_ratio',
                   'adobe_pixel_equivalence': False})

    color_folder = root / 'raw-jpg-color-and-spatial'
    color_folder.mkdir()
    color_raw = color_folder / 'color.dng'
    color_raw.write_bytes(raw.read_bytes())
    tracked[color_raw] = sha(color_raw)
    rgb = raw_pixels.astype(np.float32) / 255
    y = rgb @ _LUMA
    contrasted = np.clip(.5 + (y - .5) * 1.15, 0, 1)
    rgb = np.clip(rgb * (contrasted / np.maximum(y, .0001))[:, :, None], 0, 1)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    hsv[:, :, 1] *= .78 * (1 + .18 * (1 - hsv[:, :, 1]))
    rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    y = rgb @ _LUMA
    blurred = [cv2.GaussianBlur(y, (0, 0), sigma * 640 / 1024,
                                borderType=cv2.BORDER_REFLECT_101) for sigma in (1, 3, 12)]
    delta = .45 * .65 * (blurred[1] - blurred[2]) + .30 * .65 * (blurred[0] - blurred[1])
    color_edited = color_folder / 'color.jpg'
    Image.fromarray(np.rint(np.clip(rgb + delta[:, :, None], 0, 1) * 255).astype('uint8')).save(color_edited, quality=100, subsampling=0)
    tracked[color_edited] = sha(color_edited)
    decode_count.clear()
    alignment.decode_raw = counted_decode
    try:
        color_batch = analyze_inputs(discover_inputs(color_folder, 'raw_jpg')['items'], 'raw_jpg')
    finally:
        alignment.decode_raw = original_decoder
    assert color_batch['counts']['successful'] == 1 and len(decode_count) == 1
    color_pair = color_batch['results'][0]['payload']
    saturation = color_pair['residual_color']['saturation_model']
    assert saturation['status'] == 'ok' and .68 < saturation['gain'] < .9
    assert saturation['confidence'] > .6 and saturation['vibrance_confidence'] > .6
    assert .03 < saturation['vibrance'] < .3
    assert color_pair['tone']['contrast_delta'] > .02
    assert color_pair['detail']['controls']['clarity']['direction'] == 'higher'
    assert color_batch['summary']['color_stats']['saturation_gain']['sample_count'] == 1
    combined_inferred = dna_from_batch(color_batch, 'Combined observed edit')
    assert abs(combined_inferred['saturation_scale'] - saturation['gain']) < 1e-12
    assert abs(combined_inferred['vibrance'] - saturation['vibrance']) < 1e-12
    checks.append({'check': 'raw_jpg_separates_contrast_saturation_vibrance_and_local_contrast',
                   'actual_folder_workflow': True, 'raw_decodes_during_analysis': len(decode_count),
                   'observed_contrast_delta': color_pair['tone']['contrast_delta'],
                   'saturation_model': saturation,
                   'spatial_controls': color_pair['detail']['controls'],
                   'unsupported_fine_or_confounded_detail_is_withheld': True})

    # Regression for global/spatial identifiability: a high-contrast global
    # curve must survive decomposition, and local detail must not be counted
    # once in that curve and again in the spatial renderer. Both edits below
    # are generated independently from the production render implementation.
    for fixture_name, with_spatial in (('global-contrast', False),
                                       ('strong-monotone-only', False),
                                       ('strong-monotone-and-spatial', True)):
        folder = root / ('raw-jpg-' + fixture_name)
        folder.mkdir()
        fixture_raw = folder / 'independent.dng'
        fixture_raw.write_bytes(raw.read_bytes())
        tracked[fixture_raw] = sha(fixture_raw)
        baseline_rgb = raw_pixels.astype(np.float32) / 255
        baseline_y = baseline_rgb @ _LUMA
        if fixture_name.startswith('strong-monotone'):
            desired_y = baseline_y + .10 * np.sin(2 * np.pi * (baseline_y - .5))
        else:
            desired_y = np.clip(.5 + 1.32 * (baseline_y - .5), 0, 1)
        global_rgb = np.clip(baseline_rgb *
            (desired_y / np.maximum(baseline_y, .0001))[:, :, None], 0, 1)
        expected_global_pixels = np.rint(global_rgb * 255).astype('uint8')
        edited_rgb = global_rgb
        if with_spatial:
            global_y = global_rgb @ _LUMA
            independent_blurs = [cv2.GaussianBlur(
                global_y, (0, 0), sigma * 640 / 1024,
                borderType=cv2.BORDER_REFLECT_101) for sigma in (1, 3, 12)]
            spatial_delta = (.45 * .65 * (independent_blurs[1] - independent_blurs[2])
                             + .30 * .65 * (independent_blurs[0] - independent_blurs[1]))
            spatial_y = np.clip(global_y + spatial_delta, 0, 1)
            edited_rgb = np.clip(global_rgb *
                (spatial_y / np.maximum(global_y, .0001))[:, :, None], 0, 1)
        truth = np.rint(edited_rgb * 255).astype('uint8')
        fixture_jpg = folder / 'independent.jpg'
        Image.fromarray(truth).save(fixture_jpg, quality=100, subsampling=0)
        tracked[fixture_jpg] = sha(fixture_jpg)
        decode_count.clear()
        alignment.decode_raw = counted_decode
        try:
            batch = analyze_inputs(discover_inputs(folder, 'raw_jpg')['items'], 'raw_jpg')
        finally:
            alignment.decode_raw = original_decoder
        assert batch['counts']['successful'] == 1 and len(decode_count) == 1
        payload = batch['results'][0]['payload']
        dna = dna_from_batch(batch, 'Independent ' + fixture_name)
        preview = render_preview(fixture_raw, dna, scene_override=[])
        color_effective = copy.deepcopy(preview['effective'])
        color_effective['detail_profile'] = neutral_detail_profile()
        color_pixels = apply_pixels(preview['original'], color_effective)[0]
        before_error = mean_change(preview['original'], truth)
        full_error = mean_change(preview['rendered'], truth)
        color_error = mean_change(color_pixels, truth)
        curve_deviation = float(np.max(np.abs(np.array(dna['tone_curve']) - np.linspace(0, 1, 33))))
        assert curve_deviation > .035, (fixture_name, curve_deviation)
        assert full_error < before_error * .6, (fixture_name, before_error, full_error)
        spatial_controls = payload['detail']['controls']
        if with_spatial:
            assert full_error < color_error, (fixture_name, color_error, full_error)
            assert all(spatial_controls[name]['direction'] == 'higher' for name in ('clarity', 'texture'))
            assert 'global_tone_transfer' in payload['tone']
        else:
            for name in ('clarity', 'texture'):
                observed = spatial_controls[name]
                assert observed['estimate'] is None or abs(observed['estimate']) < .1, observed
        check_name = ('raw_jpg_strong_monotone_tone_and_spatial_recipe_improves_combined_match' if with_spatial
                      else 'raw_jpg_nonlinear_global_tone_is_retained_without_false_spatial_edit'
                      if fixture_name == 'strong-monotone-only'
                      else 'raw_jpg_global_contrast_is_retained_without_false_spatial_edit')
        truth_generation = ('independent_monotone_sine_curve_then_multiscale_hue_preserving_luma' if with_spatial
                            else 'independent_hue_preserving_monotone_sine_curve'
                            if fixture_name == 'strong-monotone-only'
                            else 'independent_hue_preserving_contrast_1_32')
        checks.append({'check': check_name,
                       'actual_folder_workflow': True,
                       'raw_decodes_during_analysis': len(decode_count),
                       'truth_generation': truth_generation,
                       'spatial_controls': spatial_controls,
                       'tone_curve_max_identity_deviation': round(curve_deviation, 6),
                       'rgb_error_before': round(before_error, 5),
                       'rgb_error_after': round(full_error, 5),
                       'isolated_color_component_error': round(color_error, 5),
                       'isolated_global_truth_error': round(mean_change(color_pixels, expected_global_pixels), 5),
                       'global_tone_transfer_separately_recorded': 'global_tone_transfer' in payload['tone'],
                       'joint_tone_spatial_fit': payload['tone'].get('decomposition'),
                       'exact_adobe_sliders_recovered': False})

    references = []
    for index in range(3):
        path = root / f'reference-{index}.jpg'
        variant = np.roll(source_pixels, index * 17, axis=1)
        Image.fromarray(variant).save(path, quality=100, subsampling=0)
        tracked[path] = sha(path)
        references.append(analyze_reference(path))
    reference = dna_from_batch({'mode': 'reference_jpg', 'results': [
        {'status': 'ok', 'payload': payload} for payload in references]}, 'Final appearance')
    detail = reference['detail_profile']
    assert detail['target'] is not None
    assert all(detail['support'][name]['basis'] == 'appearance' for name in ('clarity', 'texture'))
    assert all(detail['support'][name]['basis'] == 'unavailable' for name in ('sharpening', 'denoise_luma', 'denoise_color'))
    assert all(payload['detail']['kind'] == 'appearance' and 'controls' not in payload['detail'] for payload in references)
    checks.append({'check': 'jpg_only_learns_final_detail_appearance',
                   'unique_reference_inputs': 3, 'target': detail['target'],
                   'native_sharpening_or_noise_history_claimed': False,
                   'support_confidence': detail['support']['clarity']['confidence']})

    masks = {region: np.zeros(source_pixels.shape[:2], np.float32) for region in REGIONS}
    scene = {'report': {'bundle_id': 'a' * 64, 'scene_tags': []}, 'masks': masks}
    regional = _render_regions(source_pixels, effective, hybrid, 1, scene, .7, False, None)
    assert np.array_equal(regional, rendered)
    neutral_effective = copy.deepcopy(effective)
    neutral_effective['detail_profile'] = neutral_detail_profile()
    neutral_regional = _render_regions(source_pixels, neutral_effective, hybrid, 1, scene, .7, False, None)
    assert np.array_equal(regional, apply_details(neutral_regional, effective['detail_profile']))
    checks.append({'check': 'regional_path_does_not_double_apply_details',
                   'global_and_region_paths_pixel_identical_without_region_recipe': True})

    cancelled = threading.Event()
    cancelled.set()
    destination = root / 'cancelled.jpg'
    try:
        export_jpeg(source, destination, combined, cancel_event=cancelled)
    except ValueError as exc:
        assert 'cancelled' in str(exc).lower()
    else:
        raise AssertionError('A cancelled export was written.')
    assert not destination.exists()
    assert all(sha(path) == before for path, before in tracked.items())
    checks.append({'check': 'cancelled_export_and_immutable_originals',
                   'hashes_unchanged': len(tracked), 'cancelled_destination_created': False})

    return {'ok': True, 'app_version': APP_VERSION, 'runtime_network': 'denied',
            'backend': 'numpy_opencv_cpu', 'dna_schema_version': combined['schema_version'],
            'scene_profile_schema_version': combined['scene_profile']['schema_version'],
            'fixture_source': 'locally_generated_synthetic_raw_and_rgb',
            'fixtures_redistributed': False, 'temporary_files_removed': True,
            'seconds': round(time.monotonic() - start, 4), 'checks': checks,
            'limits': 'Controlled fixtures verify offline learning, parameter wiring, copies and sidecars. '
                      'Spatial filtering and portable presets approximate the observed controls; they do not '
                      'reproduce Adobe pixels, establish broad photographic quality, or recover native '
                      'sharpening/noise history from a final JPEG. Dehaze and other xmp_only controls are '
                      'retained for sidecars and do not alter this application\'s rendered pixels. '
                      'Supported spatial bands are separated from the observed global tone curve to '
                      'avoid applying the same contrast twice. Equal-RGB additive detail also changes '
                      'chroma; full/color/spatial errors against independent synthetic edits are reported '
                      'without promising a full pixel match on other photographic scenes.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installed', action='store_true')
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    socket.socket = denied
    socket.create_connection = denied
    with tempfile.TemporaryDirectory(prefix='pcl-parameter-diagnostic-') as directory:
        result = run_checks(Path(directory))
    result['execution'] = 'installed_runtime' if args.installed else 'source_runtime'
    result['python_isolated'] = bool(sys.flags.isolated)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(result, allow_nan=False))


if __name__ == '__main__':
    main()
