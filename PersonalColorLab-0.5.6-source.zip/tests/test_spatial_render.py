"""Observed spatial effects, bounded native tiles and non-destructive rendering."""
import copy
import threading

import cv2
import numpy as np
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.detail_analysis import detail_bands
from personal_color_lab.core.detail_recipe import learn_detail_profile, neutral_detail_profile
from personal_color_lab.core import spatial_render as render


def profile(**parameters):
    return learn_detail_profile([{'parameters': parameters}], 'raw_xmp')


def textured(width=801, height=613):
    rng=np.random.default_rng(872)
    yy,xx=np.indices((height,width))
    base=.46+.13*np.sin(xx/31)+.09*np.cos(yy/19)+.04*np.sin(xx/4)*np.cos(yy/6)
    rgb=np.stack((base+.03,base,base-.03),axis=2)
    rgb+=rng.normal(0,.016,rgb.shape)
    return np.rint(np.clip(rgb,0,1)*255).astype('uint8')


def energy(pixels):
    y=(pixels.astype(np.float32)/255)@render.LUMA
    return [float(np.sqrt(np.mean(band**2))) for band in detail_bands(y)]


def test_neutral_and_strength_zero_preserve_exact_pixels_without_aliasing():
    pixels=textured(87,63);before=pixels.copy()
    for recipe,strength in ((neutral_detail_profile(),1),(profile(Clarity2012=75,Texture=-50,Sharpness=100),0)):
        output=render.apply_details(pixels,recipe,strength)
        assert np.array_equal(output,before) and output is not pixels
        output[:]=0
        assert np.array_equal(pixels,before)


@pytest.mark.parametrize('control,index',[('Clarity2012',2),('Texture',1)])
def test_positive_and_negative_controls_change_the_corresponding_spatial_energy(control,index):
    pixels=textured(512,384);baseline=energy(pixels)[index]
    lower=render.apply_details(pixels,profile(**{control:-75}))
    higher=render.apply_details(pixels,profile(**{control:75}))
    assert energy(lower)[index]<baseline<energy(higher)[index]
    assert abs(float(np.mean(higher))-float(np.mean(pixels)))<1


def test_luma_reduction_suppresses_flat_noise_and_preserves_an_object_edge():
    rng=np.random.default_rng(34)
    source=np.full((256,512),90.,dtype=np.float32);source[:,256:]=180
    source=np.clip(source+rng.normal(0,10,source.shape),0,255).astype('uint8')
    pixels=np.repeat(source[:,:,None],3,axis=2)
    output=render.apply_details(pixels,profile(LuminanceSmoothing=100))
    assert output[30:220,30:210,0].std()<source[30:220,30:210].std()*.8
    assert abs(float(output[:,260:270,0].mean())-float(source[:,260:270].mean()))<2
    assert float(output[:,256:260,0].mean())-float(output[:,252:256,0].mean())>65
    half=render.apply_details(pixels,profile(LuminanceSmoothing=100),.5)
    full_difference=np.mean(abs(output.astype(float)-pixels))
    assert np.mean(abs(half.astype(float)-pixels))==pytest.approx(full_difference*.5,abs=.3)


def test_color_noise_reduction_reduces_chroma_without_removing_luma_edges():
    rng=np.random.default_rng(30);base=np.full((192,256,3),.45,np.float32)
    base[:,128:]+=.2;base+=rng.normal(0,.04,base.shape)
    source=np.rint(np.clip(base,0,1)*255).astype('uint8')
    output=render.apply_details(source,profile(ColorNoiseReduction=100))
    def chroma(a):
        lab=cv2.cvtColor(a.astype(np.float32)/255,cv2.COLOR_RGB2LAB)
        return float(np.std(lab[20:170,20:100,1:]))
    assert chroma(output)<chroma(source)*.85
    assert abs(float(output[:,:120].mean())-float(source[:,:120].mean()))<1


def test_sharpening_is_observable_and_masking_avoids_amplifying_flat_noise():
    source=textured(512,384)
    plain=render.apply_details(source,profile(Sharpness=120,SharpenRadius=1.5))
    masked=render.apply_details(source,profile(Sharpness=120,SharpenRadius=1.5,SharpenEdgeMasking=90))
    assert energy(plain)[0]>energy(source)[0]
    assert np.mean(abs(masked.astype(float)-source))<np.mean(abs(plain.astype(float)-source))


@pytest.mark.parametrize('dimensions',[(801,613),(383,1105)])
@pytest.mark.parametrize('parameters',[
    {'Clarity2012':65,'Texture':-30},
    {'Sharpness':120,'SharpenRadius':3,'LuminanceSmoothing':70,'ColorNoiseReduction':60,'SharpenEdgeMasking':40},
])
def test_tiled_filters_match_one_tile_across_landscape_and_portrait_boundaries(monkeypatch,dimensions,parameters):
    source=textured(*dimensions);recipe=profile(**parameters)
    tiled=render.apply_details(source,recipe,.7)
    monkeypatch.setattr(render,'_TILE',4096)
    one_tile=render.apply_details(source,recipe,.7)
    difference=abs(tiled.astype(np.int16)-one_tile.astype(np.int16))
    assert difference.max()<=1 and float(difference.mean())<.001


def test_native_filters_have_bounded_inputs_and_cancellation_between_tiles(monkeypatch):
    source=textured(1300,700);recipe=profile(Sharpness=100,SharpenRadius=3,ColorNoiseReduction=80)
    event=threading.Event();original=render.cv2.GaussianBlur;shapes=[]
    def bounded(array,*args,**kwargs):
        shapes.append(array.shape[:2])
        result=original(array,*args,**kwargs)
        if len(shapes)==7:event.set()
        return result
    monkeypatch.setattr(render.cv2,'GaussianBlur',bounded)
    with pytest.raises(AnalysisCancelledError):render.apply_details(source,recipe,cancel_event=event)
    assert shapes and max(max(shape) for shape in shapes)<700


def test_reference_adaptation_is_weak_content_guarded_and_keeps_provenance():
    recipe=neutral_detail_profile();recipe['target']={'local_contrast':.06,'texture_energy':.03}
    for name in ('clarity','texture'):
        recipe['support'][name]={'sample_count':3,'confidence':.25,'basis':'appearance'}
    before=copy.deepcopy(recipe)
    measurement={'quantiles':[.1,.5,.9],'detail':{'local_contrast':.02,'texture_energy':.01,'edge_fraction':.2,'flat_fraction':.2}}
    adapted=render.adapt_detail_target(recipe,measurement,{'quantiles':[.1,.5,.9]})
    assert adapted['controls']['clarity']==pytest.approx(.1) and adapted['controls']['texture']==pytest.approx(.1)
    assert adapted['support']==recipe['support'] and recipe==before
    assert all(adapted['controls'][key]==0 for key in ('sharpening','denoise_luma','denoise_color'))
    measurement['detail']['flat_fraction']=.99
    assert render.adapt_detail_target(recipe,measurement)==recipe


@pytest.mark.parametrize('strength',[True,-.1,1.1,float('nan')])
def test_invalid_strength_is_rejected(strength):
    with pytest.raises(ValueError):render.apply_details(textured(17,13),strength=strength)


def test_precancel_prevents_even_neutral_work():
    event=threading.Event();event.set()
    with pytest.raises(AnalysisCancelledError):render.apply_details(textured(17,13),cancel_event=event)
