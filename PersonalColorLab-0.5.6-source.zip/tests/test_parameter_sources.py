"""Spatial/color evidence keeps its source identity in all three workflows."""
import copy
import hashlib
import json
import socket
import threading

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core import alignment, detail_analysis, edit_reverse
from personal_color_lab.core import photo_scene, raw_decode, reference_analysis, source_workflow
from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.detail_analysis import detail_bands
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.source_workflow import analyze_inputs, discover_inputs, summarize_results
from personal_color_lab.core.synthetic_raw import write_test_dng


@pytest.fixture(autouse=True)
def deny_network(monkeypatch):
    def rejected(*args, **kwargs):
        raise AssertionError('Source analysis cannot use network access.')
    monkeypatch.setattr(socket, 'socket', rejected)


def _hashes(paths):
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def _detail_pair(tmp_path, amount=.65):
    raw = write_test_dng(tmp_path / 'scene.dng', width=640, height=480)
    pixels, _, _ = decode_raw(raw)
    luma = (pixels.astype(np.float32) / 255) @ np.array([.2126, .7152, .0722], np.float32)
    fine, medium, coarse = detail_bands(luma)
    delta = .45 * amount * coarse + .30 * amount * medium
    edited = np.clip(pixels.astype(np.float32) + 255 * delta[:, :, None], 0, 255).astype(np.uint8)
    jpg = tmp_path / 'scene_edit.jpg'
    Image.fromarray(edited).save(jpg, quality=100, subsampling=0)
    return raw, jpg


def _reference(tmp_path, soft=False):
    y, x = np.mgrid[:512, :512]
    luma = (.5 + .1 * np.sin(x / 37) + .1 * np.sin(y / 29)
            + .075 * np.sin((x + y) / 12) + .07 * np.sin(x / 1.7) + .06 * np.sin(y / 2.1))
    rgb = np.repeat(np.rint(luma * 255).astype(np.uint8)[:, :, None], 3, axis=2)
    if soft:
        rgb = cv2.GaussianBlur(rgb, (0, 0), 3)
    path = tmp_path / ('soft.jpg' if soft else 'detailed.jpg')
    Image.fromarray(rgb).save(path, quality=100, subsampling=0)
    return path


@pytest.mark.parametrize('amount,direction,labels', [(-.65, 'lower', ['portrait']), (.65, 'higher', ['landscape'])])
def test_raw_pair_detects_detail_groups_reusing_one_registered_baseline(tmp_path, monkeypatch, amount, direction, labels):
    raw, jpg = _detail_pair(tmp_path, amount)
    before = _hashes([raw, jpg])
    native_decode, native_details = alignment.decode_raw, edit_reverse.analyze_details
    decodes, observations = [], []

    def decode(*args, **kwargs):
        decodes.append(kwargs)
        return native_decode(*args, **kwargs)

    def details(original, edited, mask, **kwargs):
        observations.append((original.shape, edited.shape, kwargs))
        assert kwargs['tone_corrected'].shape == original.shape
        assert kwargs['alignment']['success'] is True
        return native_details(original, edited, mask, **kwargs)

    monkeypatch.setattr(alignment, 'decode_raw', decode)
    monkeypatch.setattr(edit_reverse, 'analyze_details', details)
    items = discover_inputs(tmp_path, 'raw_jpg')['items']
    items[0]['scene_override'] = labels
    result = analyze_inputs(items, 'raw_jpg')
    assert result['status'] == 'ok'
    payload = result['results'][0]['payload']
    assert payload['algorithm_version'] == result['algorithm_version'] == '0.5.6'
    assert len(decodes) == len(observations) == 1
    assert payload['photo_scene']['labels'] == labels
    for name in ('clarity', 'texture'):
        observation = payload['detail']['controls'][name]
        assert observation['direction'] == direction and observation['confidence'] > .8
        summary = result['summary']['detail_stats']['controls'][name]
        assert summary['sample_count'] == 1 and summary['unknown_count'] == 0
        assert summary['median'] == observation['estimate']
    # A preview cannot prove fine sharpening/noise history when the evidence
    # gates are insufficient; no synthesized neutral value enters the median.
    assert payload['detail']['controls']['sharpening']['estimate'] is None
    assert result['summary']['detail_stats']['controls']['sharpening']['median'] is None
    assert _hashes([raw, jpg]) == before
    json.dumps(result, allow_nan=False)


def test_reference_detail_uses_one_existing_decode_and_retains_appearance_only(tmp_path, monkeypatch):
    sharp, soft = _reference(tmp_path), _reference(tmp_path, soft=True)
    before = _hashes([sharp, soft])
    read = reference_analysis._read_rgb
    decoded = []

    def read_once(*args, **kwargs):
        decoded.append(args[0])
        return read(*args, **kwargs)

    monkeypatch.setattr(reference_analysis, '_read_rgb', read_once)
    first, second = (reference_analysis.analyze_reference(path) for path in (sharp, soft))
    assert len(decoded) == 2
    assert first['detail']['kind'] == second['detail']['kind'] == 'appearance'
    assert 'controls' not in first['detail'] and 'lightroom_estimates' not in first
    assert first['detail']['appearance']['texture_energy'] > second['detail']['appearance']['texture_energy'] * 1.4
    report = reference_analysis.aggregate_references([first, second, copy.deepcopy(first)])
    assert report['sample_count'] == report['detail_stats']['measured_count'] == 2
    assert report['duplicate_count'] == 1 and 'controls' not in report['detail_stats']
    assert report['detail_stats']['appearance']['fine_energy']['sample_count'] == 2
    assert _hashes([sharp, soft]) == before


def test_raw_xmp_keeps_exact_diverse_controls_without_fake_pixel_detail(tmp_path, monkeypatch):
    raw = write_test_dng(tmp_path / 'scene.dng')
    sidecar = tmp_path / 'scene.xmp'
    sidecar.write_text(
        '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
        'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
        'crs:Clarity2012="-35" crs:Texture="20" crs:Saturation="-12" '
        'crs:Vibrance="23" crs:Contrast2012="31" crs:Sharpness="62" '
        'crs:LuminanceSmoothing="16"/>', encoding='utf-8')
    before = _hashes([raw, sidecar])
    native = raw_decode.decode_raw
    decodes = []

    def decode(*args, **kwargs):
        decodes.append((args, kwargs))
        return native(*args, **kwargs)

    monkeypatch.setattr(raw_decode, 'decode_raw', decode)
    result = analyze_inputs(discover_inputs(tmp_path, 'raw_xmp')['items'], 'raw_xmp')
    payload = result['results'][0]['payload']
    assert result['status'] == 'ok' and len(decodes) == 1
    assert payload['parameters'] == {'Clarity2012': -35, 'Texture': 20, 'Saturation': -12,
                                     'Vibrance': 23, 'Contrast2012': 31, 'Sharpness': 62,
                                     'LuminanceSmoothing': 16}
    assert payload['provenance']['raw_decoded'] is False
    assert payload['provenance']['scene_baseline']['decoded'] is True
    assert payload['provenance']['scene_baseline']['xmp_settings_rendered'] is False
    assert 'detail' not in payload and 'detail_stats' not in result['summary']
    assert result['summary']['parameters']['Clarity2012']['median'] == -35
    assert _hashes([raw, sidecar]) == before


def test_reference_legacy_missing_detail_stays_usable_and_unknown(tmp_path):
    current = reference_analysis.analyze_reference(_reference(tmp_path))
    legacy = copy.deepcopy(current)
    legacy['algorithm_version'] = '0.5.5'
    legacy.pop('detail')
    report = reference_analysis.aggregate_references([legacy])
    assert report['sample_count'] == 1 and report['detail_stats']['measured_count'] == 0
    assert report['detail_stats']['appearance']['texture_energy'] == {
        'median': None, 'dispersion': None, 'sample_count': 0, 'unknown_count': 1}
    invalid = copy.deepcopy(current)
    invalid['detail']['appearance']['texture_energy'] = float('nan')
    mixed = reference_analysis.aggregate_references([invalid, legacy])
    assert mixed['sample_count'] == 1 and mixed['excluded_count'] == 1


def test_color_and_detail_summary_excludes_conflicting_edits_of_one_original(tmp_path):
    raw, jpg = _detail_pair(tmp_path)
    first = edit_reverse.analyze_pair(raw, jpg)
    first['residual_color']['saturation_model'] = {
        'status': 'ok', 'gain': .9, 'vibrance': -.25, 'confidence': .8,
        'vibrance_confidence': .7, 'sample_count': 1000}
    conflict = copy.deepcopy(first)
    conflict['provenance']['input_fingerprints']['edited'] = 'a' * 64
    independent = copy.deepcopy(first)
    independent['provenance']['input_fingerprints']['original'] = 'b' * 64
    independent['residual_color']['saturation_model']['gain'] = 1.25
    results = [{'status': 'ok', 'item': {}, 'payload': p} for p in [first, conflict, independent]]
    summary = summarize_results('raw_jpg', results)
    assert summary['sample_count'] == 3  # Existing processed-file count.
    assert summary['detail_stats']['sample_count'] == summary['color_stats']['sample_count'] == 1
    assert summary['color_stats']['saturation_gain']['median'] == 1.25
    assert summary['color_stats']['excluded_edit_conflict_count'] == 2
    assert summary['color_stats']['vibrance']['sample_count'] == 1
    missing = copy.deepcopy(independent)
    missing.pop('detail')
    missing['residual_color'].pop('saturation_model')
    unknown = summarize_results('raw_jpg', [{'status': 'ok', 'item': {}, 'payload': missing}])
    assert unknown['color_stats']['vibrance']['median'] is None
    assert unknown['detail_stats']['controls']['clarity']['median'] is None


def test_detail_cancellation_retains_completed_photos_only(tmp_path, monkeypatch):
    raw, jpg = _detail_pair(tmp_path)
    original = discover_inputs(tmp_path, 'raw_jpg')['items'][0]
    other_raw, other_jpg = tmp_path / 'other.dng', tmp_path / 'other.jpg'
    other_raw.write_bytes(raw.read_bytes() + b'separate-local-identity')
    other_jpg.write_bytes(jpg.read_bytes())
    other = copy.deepcopy(original)
    other.update(id='other', original_path=str(other_raw), edited_path=str(other_jpg))
    event = threading.Event()
    native = edit_reverse.analyze_details
    calls = []

    def cancel_second(*args, **kwargs):
        calls.append(None)
        if len(calls) == 2:
            event.set()
        return native(*args, **kwargs)

    monkeypatch.setattr(edit_reverse, 'analyze_details', cancel_second)
    batch = analyze_inputs([original, other], 'raw_jpg', cancel_event=event)
    assert batch['status'] == 'cancelled' and len(calls) == 2
    assert batch['counts']['successful'] == 1 and batch['counts']['cancelled'] == 1
    assert len(batch['results']) == 1 and batch['results'][0]['payload']['detail']['status'] == 'ok'


def test_color_summary_circular_hue_median_preserves_red_direction():
    samples = []
    for angle in (179., -179.):
        samples.append({'residual_color': {'hue_bands': {'red': {
            'hue_delta_degrees': angle, 'sample_count': 256, 'confidence': .8}}}})
    report = source_workflow.summarize_color_evidence(samples)
    assert abs(report['hue_bands']['red']['hue_delta_degrees']['median']) >= 179
    assert report['vibrance']['median'] is None and report['vibrance']['unknown_count'] == 2


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
def test_parameter_evidence_survives_cache_and_manual_scene_review_without_redecode(tmp_path, monkeypatch, mode):
    if mode == 'raw_jpg':
        _detail_pair(tmp_path)
    elif mode == 'reference_jpg':
        _reference(tmp_path)
    else:
        write_test_dng(tmp_path / 'scene.dng')
        (tmp_path / 'scene.xmp').write_text(
            '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
            'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" crs:Clarity2012="23"/>',
            encoding='utf-8')

    class Cache:
        def __init__(self):
            self.entries = {}

        def get_cached_analysis(self, key):
            return self.entries.get(key)

        def cache_analysis(self, key, payload):
            self.entries[key] = copy.deepcopy(payload)

    items, cache = discover_inputs(tmp_path, mode)['items'], Cache()
    first = analyze_inputs(items, mode, cache=cache)
    assert first['status'] == 'ok' and len(cache.entries) == 1
    stored = copy.deepcopy(cache.entries)
    name = {'raw_jpg': 'analyze_pair', 'raw_xmp': 'analyze_raw_xmp',
            'reference_jpg': 'analyze_reference'}[mode]
    monkeypatch.setattr(source_workflow, name,
                        lambda *args, **kwargs: pytest.fail('A reviewed cached photo must not be decoded again.'))
    items[0]['scene_override'] = ['portrait']
    reviewed = analyze_inputs(items, mode, cache=cache)
    assert reviewed['status'] == 'ok' and reviewed['performance']['cache_hits'] == 1
    payload = reviewed['results'][0]['payload']
    assert payload['photo_scene']['labels'] == ['portrait']
    if mode == 'raw_xmp':
        assert payload['parameters']['Clarity2012'] == 23 and 'detail' not in payload
    else:
        assert payload['detail'] == first['results'][0]['payload']['detail']
        assert reviewed['summary']['detail_stats'] == first['summary']['detail_stats']
    assert cache.entries == stored
