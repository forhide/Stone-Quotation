"""Observed spatial edits, confounders and portable offline evidence."""
from copy import deepcopy
from io import BytesIO
import json
import socket
import threading

import cv2
import numpy as np
from PIL import Image, ImageFilter
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.detail_analysis import (
    MAX_DIMENSION, analyze_details, detail_bands, measure_detail_appearance,
    validate_detail_report,
)


def _scene(size=512):
    yy, xx = np.mgrid[:size, :size].astype(np.float32)
    y = (.5 + .1 * np.sin(xx / 37) + .1 * np.sin(yy / 29)
         + .075 * np.sin((xx + yy) / 12) + .07 * np.sin(xx / 1.7)
         + .06 * np.sin(yy / 2.1))
    return np.rint(y[:, :, None] * 255).clip(0, 255).astype(np.uint8).repeat(3, 2)


def _mask(rgb):
    return np.ones(rgb.shape[:2], dtype=bool)


def _local_change(rgb, amount):
    # An independently generated broad unsharp/softening edit, rather than
    # calling the implementation's detail_bands to manufacture its answer.
    blurred = cv2.GaussianBlur(rgb, (0, 0), max(rgb.shape[:2]) / 1024 * 12)
    return np.rint(rgb.astype(float) + amount * (rgb.astype(float) - blurred)).clip(0, 255).astype(np.uint8)


def _same_geometry(size):
    return {"success": True, "original_size": [size, size], "edited_size": [size, size],
            "scale": 1., "rotation_degrees": 0., "matrix": np.eye(3).tolist(),
            "diagnostics": {"structural_correlation": 1.}}


def _structural_scene():
    """Non-periodic, varied edge structure with recoverable fine support."""
    rng = np.random.default_rng(13)
    size = 1024
    gray = cv2.GaussianBlur(rng.integers(45, 210, (size, size), dtype=np.uint8), (0, 0), 1)
    rgb = gray[:, :, None].repeat(3, 2)
    for _ in range(1500):
        point = tuple(rng.integers(16, size - 16, 2).tolist())
        cv2.circle(rgb, point, int(rng.integers(2, 14)), (int(rng.integers(35, 220)),) * 3, -1, cv2.LINE_AA)
    return rgb


def test_identity_is_neutral_non_destructive_finite_and_network_independent(monkeypatch):
    rgb = _scene()
    before = rgb.copy()
    mask = _mask(rgb)
    def deny(*args, **kwargs):
        raise AssertionError("Detail analysis must remain offline")
    monkeypatch.setattr(socket, "socket", deny)
    report = analyze_details(rgb, rgb.copy(), mask, tone_corrected=rgb)
    assert report["status"] == "ok"
    for name in ("clarity", "texture"):
        assert report["controls"][name]["direction"] == "neutral"
        assert abs(report["controls"][name]["estimate"]) < .001
    assert report["controls"]["denoise_luma"]["estimate"] is None
    np.testing.assert_array_equal(rgb, before)
    assert mask.all()
    json.dumps(report, allow_nan=False)
    assert validate_detail_report(report) == report


@pytest.mark.parametrize("amount,direction", [(-.35, "lower"), (.35, "higher")])
def test_broad_local_contrast_and_texture_changes_are_measured(amount, direction):
    rgb = _scene()
    edited = _local_change(rgb, amount)
    assert abs(float(edited.mean() - rgb.mean())) < 1
    report = analyze_details(rgb, edited, _mask(rgb), tone_corrected=rgb)
    for name in ("clarity", "texture"):
        assert report["controls"][name]["direction"] == direction
        assert report["controls"][name]["confidence"] >= .35
    # Normalized implementation gains are observations, not Adobe points.
    assert not {"parameters", "Clarity2012", "Texture"} & report.keys()


@pytest.mark.parametrize("edit", ["exposure", "white_balance"])
def test_global_tone_and_color_changes_do_not_become_detail_styles(edit):
    rgb = _scene()
    change = rgb.astype(float) * 1.1 + 8 if edit == "exposure" else rgb.astype(float) + [8, 0, -7]
    edited = np.rint(change).clip(0, 255).astype(np.uint8)
    report = analyze_details(rgb, edited, _mask(rgb))
    for name in ("clarity", "texture"):
        assert report["controls"][name]["direction"] == "neutral"
        assert abs(report["controls"][name]["estimate"]) < .025
    assert "detail_global_tone_removed" in report["warnings"]


def test_actual_blur_and_unsharp_have_opposite_supported_detail_tendencies():
    rgb = _structural_scene()
    blur = np.asarray(Image.fromarray(rgb).filter(ImageFilter.GaussianBlur(radius=.5)))
    sharp = np.asarray(Image.fromarray(rgb).filter(ImageFilter.UnsharpMask(radius=1, percent=80, threshold=0)))
    low = analyze_details(rgb, blur, _mask(rgb), tone_corrected=rgb)
    high = analyze_details(rgb, sharp, _mask(rgb), tone_corrected=rgb)
    assert low["controls"]["sharpening"]["direction"] == "lower"
    assert high["controls"]["sharpening"]["direction"] == "higher"
    assert min(low["controls"]["sharpening"]["confidence"], high["controls"]["sharpening"]["confidence"]) >= .65
    assert low["controls"]["texture"]["direction"] != "higher"
    assert high["controls"]["texture"]["direction"] != "lower"


def test_demonstrated_flat_noise_smoothing_can_learn_positive_luma_denoise():
    rgb = _scene()
    rgb[:, :192] = 128
    noisy = np.rint(rgb.astype(float) + np.random.default_rng(13).normal(0, 5, (512, 512, 1))).clip(0, 255).astype(np.uint8)
    smooth = cv2.GaussianBlur(noisy, (0, 0), .7)
    report = analyze_details(noisy, smooth, _mask(rgb), tone_corrected=noisy)
    assert report["controls"]["denoise_luma"]["direction"] == "higher"
    assert 0 < report["controls"]["denoise_luma"]["estimate"] <= 1
    assert report["controls"]["denoise_luma"]["confidence"] >= .35


def test_actual_jpeg_recompression_does_not_become_a_crisper_texture_style():
    rgb = _scene(1024)
    rgb[:, :300] = 128
    def encoded(pixels, quality):
        stream = BytesIO()
        Image.fromarray(pixels).save(stream, format="JPEG", quality=quality, subsampling=0)
        stream.seek(0)
        with Image.open(stream) as image:
            return np.asarray(image.convert("RGB"))
    original = encoded(rgb, 98)
    edited = encoded(original, 80)
    report = analyze_details(original, edited, _mask(original))
    assert "detail_jpeg_artifact_uncertainty" in report["warnings"]
    assert report["controls"]["texture"]["estimate"] is None
    assert report["controls"]["sharpening"]["estimate"] is None
    assert report["controls"]["denoise_luma"]["estimate"] is None


def test_added_flat_region_noise_is_an_observation_not_an_edit_intent():
    rgb = _scene()
    rgb[:, :192] = 128
    edited = rgb.copy()
    noise = np.random.default_rng(13).normal(0, 5, (512, 192, 1))
    edited[:, :192] = np.rint(rgb[:, :192].astype(float) + noise).clip(0, 255).astype(np.uint8)
    report = analyze_details(rgb, edited, _mask(rgb), tone_corrected=rgb)
    assert report["appearance"]["flat_noise_mad"] > .001
    assert report["controls"]["sharpening"]["estimate"] is None
    assert report["controls"]["denoise_luma"]["estimate"] is None
    assert "detail_noise_change_unidentified" in report["warnings"]
    for name in ("clarity", "texture"):
        assert report["controls"][name]["direction"] in {"neutral", "uncertain"}


def test_periodic_discontinuities_in_flat_regions_flag_compression_confounder():
    rgb = _scene()
    rgb[:, :192] = 128
    edited = rgb.copy()
    block = ((np.arange(192) // 8) % 2 * 4 - 2).astype(np.int16)
    edited[:, :192] = (rgb[:, :192].astype(np.int16) + block[None, :, None]).astype(np.uint8)
    report = analyze_details(rgb, edited, _mask(rgb), tone_corrected=rgb)
    assert "detail_jpeg_artifact_uncertainty" in report["warnings"]
    assert report["controls"]["sharpening"]["estimate"] is None
    assert report["controls"]["denoise_luma"]["estimate"] is None


@pytest.mark.parametrize("change", ["resize", "rotate", "fractional_warp", "raw"])
def test_fine_detail_is_withheld_when_geometry_or_raw_sampling_can_explain_it(change):
    rgb = _scene(1024)
    alignment = _same_geometry(1024)
    if change == "resize":
        alignment["original_size"] = [2048, 2048]
        alignment["scale"] = .5
    elif change == "rotate":
        alignment["rotation_degrees"] = 1
    elif change == "fractional_warp":
        alignment["matrix"][0][2] = .5
    else:
        alignment["original_decode"] = {"decoder": "libraw", "original_dimensions": [9504, 6336]}
    report = analyze_details(rgb, _local_change(rgb, .2), _mask(rgb), tone_corrected=rgb, alignment=alignment)
    assert report["controls"]["clarity"]["direction"] == "higher"
    assert report["controls"]["sharpening"] == {"estimate": None, "confidence": 0., "direction": "uncertain"}
    assert report["controls"]["denoise_luma"]["estimate"] is None
    assert "detail_fine_resampling_uncertain" in report["warnings"]


def test_residual_subpixel_shift_is_detected_without_trusting_metadata():
    rgb = _scene(1024)
    edited = cv2.warpAffine(rgb, np.array([[1, 0, .5], [0, 1, 0]], dtype=float), (1024, 1024))
    report = analyze_details(rgb, edited, _mask(rgb), tone_corrected=rgb, alignment=_same_geometry(1024))
    assert report["controls"]["sharpening"]["estimate"] is None
    assert "detail_fine_resampling_uncertain" in report["warnings"]


def test_invalid_overlap_and_unregistered_inputs_have_no_learnable_controls():
    rgb = _scene()
    empty = analyze_details(rgb, _local_change(rgb, .2), np.zeros(rgb.shape[:2], dtype=bool))
    failed = analyze_details(rgb, _local_change(rgb, .2), _mask(rgb), alignment={"success": False})
    for report in (empty, failed):
        assert report["status"] == "insufficient"
        assert all(v["estimate"] is None for v in report["controls"].values())
    assert "detail_alignment_uncertain" in failed["warnings"]


def test_overlap_mask_excludes_foreign_content_and_filter_boundary():
    rgb = _scene()
    edited = rgb.copy()
    edited[:, :256] = 255
    mask = _mask(rgb)
    mask[:, :256] = False
    report = analyze_details(rgb, edited, mask, tone_corrected=rgb)
    for name in ("clarity", "texture"):
        assert report["controls"][name]["direction"] == "neutral"
    assert report["appearance"]["local_contrast"] is not None


def test_reference_appearance_describes_content_without_inventing_controls():
    rgb = _scene()
    softer = np.asarray(Image.fromarray(rgb).filter(ImageFilter.GaussianBlur(radius=1)))
    full, soft = measure_detail_appearance(rgb), measure_detail_appearance(softer)
    flat = measure_detail_appearance(np.full((64, 64, 3), 128, dtype=np.uint8))
    assert "controls" not in full
    assert full["kind"] == "appearance"
    assert full["appearance"]["fine_energy"] > soft["appearance"]["fine_energy"]
    assert flat["appearance"]["local_contrast"] == pytest.approx(0, abs=1e-7)
    assert flat["appearance"]["edge_fraction"] == 0
    assert flat["appearance"]["flat_fraction"] == 1
    assert "detail_content_confounders" in full["warnings"]
    assert "detail_flat_noise_not_edit_intent" in full["warnings"]


def test_resource_bounding_cancellation_and_bad_input_contracts():
    rgb = np.full((1200, 1600, 3), 128, dtype=np.uint8)
    report = measure_detail_appearance(rgb)
    assert report["analysis_dimensions"] == [MAX_DIMENSION, 768]
    event = threading.Event()
    event.set()
    with pytest.raises(AnalysisCancelledError):
        measure_detail_appearance(rgb, cancel_event=event)
    with pytest.raises(AnalysisCancelledError):
        analyze_details(rgb, rgb, _mask(rgb), cancel_event=event)
    with pytest.raises(ValueError, match="uint8"):
        measure_detail_appearance(rgb.astype(float))
    with pytest.raises(ValueError, match="same-size"):
        analyze_details(rgb, rgb[:100], _mask(rgb))
    with pytest.raises(ValueError, match="boolean"):
        analyze_details(rgb, rgb, _mask(rgb).astype(np.uint8))
    with pytest.raises(ValueError, match="finite normalized"):
        detail_bands(np.full((16, 16), np.nan))


@pytest.mark.parametrize("mutation", ["extra", "nan", "bool", "range", "confidence", "direction", "warnings", "status"])
def test_report_validation_rejects_invented_private_and_nonfinite_evidence(mutation):
    report = analyze_details(_scene(), _scene(), _mask(_scene()), tone_corrected=_scene())
    original = deepcopy(report)
    restored = validate_detail_report(report)
    restored["warnings"].append("detail_color_confounders")
    assert report == original
    if mutation == "extra":
        report["gps"] = {"latitude": 1}
    elif mutation == "nan":
        report["appearance"]["texture_energy"] = float("nan")
    elif mutation == "bool":
        report["controls"]["clarity"]["estimate"] = True
    elif mutation == "range":
        report["appearance"]["flat_fraction"] = 1.1
    elif mutation == "confidence":
        report["controls"]["denoise_luma"]["confidence"] = .5
    elif mutation == "direction":
        report["controls"]["clarity"]["direction"] = "higher"
    elif mutation == "warnings":
        report["warnings"].append("private arbitrary text")
    else:
        report["status"] = "insufficient"
    with pytest.raises(ValueError):
        validate_detail_report(report)
