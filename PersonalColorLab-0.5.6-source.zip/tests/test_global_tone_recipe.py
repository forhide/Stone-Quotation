"""Observed local contrast must not also become the applied global curve."""
import copy

import numpy as np
import pytest

from personal_color_lab.core.style_dna import dna_from_batch
from personal_color_lab.core.tone_analysis import analyze_tone, validate_global_tone_evidence


def evidence():
    original=np.repeat(np.linspace(15,240,256,dtype=np.uint8)[None,:,None],96,axis=0)
    original=np.repeat(original,3,axis=2)
    edited=np.rint(np.clip((original.astype(float)-127)*1.18+127,0,255)).astype('uint8')
    mask=np.ones(original.shape[:2],bool)
    tone=analyze_tone(original,edited,mask)
    tone['global_tone_transfer']=analyze_tone(original,original,mask)['tone_transfer']
    tone['decomposition']={'schema_version':1,'iterations':2,'confidence':.9,'method':'iterative_luma_band_subtraction'}
    return tone


def test_recipe_uses_separated_global_curve_and_preserves_observed_contrast():
    tone=evidence();before=copy.deepcopy(tone)
    payload={'status':'ok','confidence':1,'tone':tone}
    dna=dna_from_batch({'mode':'raw_jpg','results':[{'status':'ok','payload':payload}]},'Separated')
    assert np.allclose(dna['tone_curve'],np.linspace(0,1,33),atol=1e-12)
    assert tone==before and tone['contrast_delta']>.1
    payload=copy.deepcopy(payload);payload['tone'].pop('global_tone_transfer');payload['tone'].pop('decomposition')
    legacy=dna_from_batch({'mode':'raw_jpg','results':[{'status':'ok','payload':payload}]},'Observed')
    assert np.max(abs(np.array(legacy['tone_curve'])-np.linspace(0,1,33)))>.03


@pytest.mark.parametrize('corruption',['private','unordered','unsupported_method','missing_curve','private_support','duplicate_input'])
def test_global_recipe_rejects_untrusted_or_inconsistent_evidence(corruption):
    tone=evidence()
    if corruption=='private':tone['global_tone_transfer'][0]['photo']='/private.jpg'
    elif corruption=='unordered':tone['global_tone_transfer'][0]['output']=1
    elif corruption=='unsupported_method':tone['decomposition']['method']='arbitrary free text'
    elif corruption=='missing_curve':tone.pop('global_tone_transfer')
    elif corruption=='private_support':tone['decomposition']['photo']='/private.jpg'
    elif corruption=='duplicate_input':tone['global_tone_transfer'][1]['input']=tone['global_tone_transfer'][0]['input']
    with pytest.raises(ValueError):validate_global_tone_evidence(tone)
