"""Evidence-aware detail learning, scene adaptation and legacy portability."""
import copy
import hashlib
import xml.etree.ElementTree as ET

import numpy as np
import pytest

from personal_color_lab.core.detail_recipe import (
    CONTROL_DEFAULTS, CONTROL_RANGES, neutral_detail_profile,
    validate_detail_profile, learn_detail_profile, mix_detail_profiles,
    blend_detail_profiles,
)
from personal_color_lab.core.photo_scene import unknown_photo_scene, with_scene_override
from personal_color_lab.core.reference_analysis import _appearance, ALGORITHM_VERSION
from personal_color_lab.core.scene_styles import adapt_scene_style
from personal_color_lab.core.style_dna import identity_dna, dna_from_batch, validate_dna, blend_styles
from personal_color_lab.core.xmp_analysis import _read_settings


def _hash(value):
    return hashlib.sha256(str(value).encode()).hexdigest()


def _detail(kind='paired', clarity=.2, texture=.3, confidence=.9, energy=.05):
    result = {'schema_version': 1, 'kind': kind, 'status': 'ok',
              'analysis_dimensions': [128, 96], 'warnings': [],
              'appearance': {'local_contrast': energy, 'texture_energy': energy / 2,
                             'fine_energy': .01, 'flat_noise_mad': .001,
                             'flat_fraction': .25, 'edge_fraction': .1}}
    if kind == 'paired':
        estimates = {'clarity': clarity, 'texture': texture, 'sharpening': .15, 'denoise_luma': .2}
        result['controls'] = {name: {'estimate': value, 'confidence': confidence,
            'direction': 'higher' if value > .025 else 'lower' if value < -.025 else 'neutral'}
            for name, value in estimates.items()}
    return result


def _payload(index, *, params=None, detail=None):
    result = {'status': 'ok', 'confidence': 1.0, 'provenance': {'input_fingerprints':
              {'original': _hash(index), 'edited': _hash(('edited', index))}}}
    if params is not None:
        result['parameters'] = params
    if detail is not None:
        result['detail'] = detail
    return result


def test_xmp_actual_whitelisted_sliders_map_and_missing_metadata_stays_unknown():
    root = ET.fromstring('<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
        'xmlns:c="http://ns.adobe.com/camera-raw-settings/1.0/" c:Clarity="-80" c:Clarity2012="45" '
        'c:Texture="-35" c:Sharpness="120" c:SharpenRadius="1.8" c:SharpenEdgeMasking="70" '
        'c:LuminanceSmoothing="25" c:ColorNoiseReduction="40"/>')
    params, *_ = _read_settings(root)
    learned = learn_detail_profile([_payload(1, params=params)], 'raw_xmp')
    assert learned['controls'] == {'clarity': .45, 'texture': -.35, 'sharpening': 1.2,
        'sharp_radius': 1.8, 'sharp_mask': .7, 'denoise_luma': .25, 'denoise_color': .4}
    assert all(item == {'sample_count': 1, 'confidence': 1., 'basis': 'recorded'}
               for item in learned['support'].values())
    partial = learn_detail_profile([_payload(1, params={'Clarity2012': 0})], 'raw_xmp')
    assert partial['support']['clarity']['basis'] == 'recorded'
    assert partial['support']['texture'] == neutral_detail_profile()['support']['texture']
    assert partial['controls']['texture'] == 0
    assert partial['target'] is None


def test_per_control_metadata_support_counts_observed_values_not_missing_zeroes():
    profile = learn_detail_profile([_payload(1, params={'Clarity': 60}),
        _payload(2, params={'Texture': -40}), _payload(3, params={})], 'raw_xmp')
    assert profile['controls']['clarity'] == .6 and profile['controls']['texture'] == -.4
    assert profile['support']['clarity']['sample_count'] == 1
    assert profile['support']['texture']['sample_count'] == 1
    assert profile['support']['sharpening']['basis'] == 'unavailable'


def test_duplicate_originals_and_conflicting_edits_do_not_inflate_detail_support():
    first = _payload(1, params={'Texture': 50})
    duplicate = copy.deepcopy(first)
    learned = learn_detail_profile([first, duplicate], 'raw_xmp')
    assert learned['support']['texture']['sample_count'] == 1
    duplicate['provenance']['input_fingerprints']['edited'] = _hash('different-edit')
    assert learn_detail_profile([first, duplicate], 'raw_xmp') == neutral_detail_profile()


def test_paired_confidence_thresholds_preserve_unknown_fine_detail_and_never_add_noise():
    uncertain = _detail(confidence=.5)
    uncertain['controls']['denoise_luma'] = {'estimate': -.4, 'confidence': .9, 'direction': 'lower'}
    learned = learn_detail_profile([_payload(1, detail=uncertain)], 'raw_jpg')
    assert learned['controls']['clarity'] == .2 and learned['controls']['texture'] == .3
    assert learned['support']['clarity']['basis'] == 'inferred'
    assert learned['support']['sharpening']['basis'] == 'unavailable'
    assert learned['support']['denoise_luma']['basis'] == 'unavailable'
    fine = learn_detail_profile([_payload(2, detail=_detail(confidence=.8))], 'jpg_jpg')
    assert fine['controls']['sharpening'] == .15 and fine['controls']['denoise_luma'] == .2
    assert fine['support']['denoise_color']['basis'] == 'unavailable'
    weak = learn_detail_profile([_payload(3, detail=_detail(confidence=.34))], 'raw_jpg')
    assert weak == neutral_detail_profile()


def test_reference_target_needs_three_distinct_structured_images_and_never_recovers_noise():
    records = [_payload(i, detail=_detail('appearance', energy=.02 + i * .01)) for i in range(3)]
    assert learn_detail_profile(records[:2], 'reference_jpg') == neutral_detail_profile()
    assert learn_detail_profile([records[0]] * 3, 'reference_jpg') == neutral_detail_profile()
    result = learn_detail_profile(records, 'reference_jpg')
    assert result['controls'] == CONTROL_DEFAULTS
    assert result['target'] == {'local_contrast': .03, 'texture_energy': .015}
    assert result['support']['clarity'] == {'sample_count': 3, 'confidence': .25, 'basis': 'appearance'}
    assert result['support']['sharpening']['basis'] == 'unavailable'
    assert result['support']['denoise_luma']['basis'] == 'unavailable'
    records[2]['detail']['appearance']['edge_fraction'] = 0
    assert learn_detail_profile(records, 'reference_jpg') == neutral_detail_profile()


@pytest.mark.parametrize('mode', ['raw_xmp', 'raw_jpg', 'reference_jpg'])
def test_all_three_source_routes_learn_distinct_category_detail_around_global_profile(mode):
    records = []
    for index in range(6):
        night = index < 3
        payload = _payload(index)
        if mode == 'raw_xmp':
            payload['parameters'] = {'Clarity2012': -40 if night else 60, 'Texture': -30 if night else 70}
        elif mode == 'raw_jpg':
            payload['detail'] = _detail(clarity=-.4 if night else .6, texture=-.3 if night else .7)
        else:
            pixels = np.random.default_rng(index).integers(30, 210, (40, 60, 3), dtype=np.uint8)
            payload.update(source_type='reference_jpg', schema_version=1,
                algorithm_version=ALGORITHM_VERSION, original_path=f'/test/{index}.jpg',
                appearance=_appearance(pixels), detail=_detail('appearance', energy=.02 if night else .08))
            payload['provenance'].update(pixel_count=2400, perceptual_hash=_hash(('perceptual', index)))
        records.append({'status': 'ok', 'payload': payload, 'scene_override': ['night'] if night else ['day']})
    dna = dna_from_batch({'mode': mode, 'results': records}, 'Category detail')
    assert dna['schema_version'] == 4 and dna['engine_version'] == '0.5.6'
    assert dna['scene_profile']['schema_version'] == 2
    common = dna['detail_profile']
    day, _ = adapt_scene_style(dna, {}, with_scene_override(unknown_photo_scene('legacy_analysis'), ['day']))
    night, _ = adapt_scene_style(dna, {}, with_scene_override(unknown_photo_scene('legacy_analysis'), ['night']))
    if mode == 'reference_jpg':
        assert night['detail_profile']['target']['local_contrast'] < common['target']['local_contrast'] < day['detail_profile']['target']['local_contrast']
    else:
        assert night['detail_profile']['controls']['clarity'] < common['controls']['clarity'] < day['detail_profile']['controls']['clarity']
        assert night['detail_profile']['controls']['texture'] < common['controls']['texture'] < day['detail_profile']['controls']['texture']
    assert validate_dna(day) == day and validate_dna(night) == night


def _legacy(dna, version):
    result = copy.deepcopy(dna)
    result.pop('detail_profile')
    result['schema_version'] = version
    result['engine_version'] = {1: '0.4.0', 2: '0.5.0', 3: '0.5.5'}[version]
    if version < 3:
        result.pop('scene_profile')
    else:
        result['scene_profile']['schema_version'] = 1
        for category in result['scene_profile']['categories'].values():
            category['recipe'].pop('detail_profile')
    if version == 1:
        result.pop('semantic_profile')
    result['components'] = [{'weight': item['weight'], 'dna': _legacy(item['dna'], version)}
                            for item in result['components']]
    return result


@pytest.mark.parametrize('version', [1, 2, 3])
def test_legacy_profiles_and_nested_hybrids_upgrade_neutrally_without_mutation(version):
    first = identity_dna('First')
    first.update(exposure_ev=.25, saturation_scale=.8)
    first['tone_curve'][16] = .51
    first['recorded_parameters'] = {'Clarity2012': 70, 'Sharpness': 90}
    second = identity_dna('Second')
    second['zone_shifts']['shadows'] = [1., 2.]
    nested = blend_styles([blend_styles([first, second], [.3, .7]), second], [.4, .6])
    old = _legacy(nested, version)
    before = copy.deepcopy(old)
    upgraded = validate_dna(old)
    assert old == before
    assert upgraded['detail_profile'] == neutral_detail_profile()
    assert upgraded['components'][0]['dna']['components'][0]['dna']['detail_profile'] == neutral_detail_profile()
    assert upgraded['components'][0]['dna']['components'][0]['dna']['recorded_parameters'] == first['recorded_parameters']
    assert upgraded['components'][0]['dna']['components'][0]['dna']['tone_curve'] == first['tone_curve']
    assert upgraded['components'][0]['dna']['components'][0]['dna']['saturation_scale'] == .8


def test_legacy_scene_recipes_upgrade_neutrally_preserving_supported_categories():
    records = [{'status': 'ok', 'payload': _payload(i, params={'Clarity2012': 50}), 'scene_override': ['night']}
               for i in range(3)]
    new = dna_from_batch({'mode': 'raw_xmp', 'results': records}, 'Old scenes')
    old = _legacy(new, 3)
    before = copy.deepcopy(old)
    upgraded = validate_dna(old)
    assert old == before
    assert upgraded['detail_profile'] == neutral_detail_profile()
    assert upgraded['scene_profile']['categories']['night']['recipe']['detail_profile'] == neutral_detail_profile()
    assert upgraded['scene_profile']['categories']['night']['sample_count'] == 3
    assert upgraded['scene_profile']['categories']['night']['recipe']['recorded_parameters']['Clarity2012'] == 50
    old['scene_profile']['categories']['night']['recipe']['private_photo'] = '/private.jpg'
    with pytest.raises(ValueError):
        validate_dna(old)


@pytest.mark.parametrize('version', [1, 2, 3])
def test_legacy_recorded_unrendered_detail_keeps_the_exact_previous_color_output(version):
    from personal_color_lab.core.style_render import apply_pixels, prepare_style
    expected = identity_dna('Previous rendering')
    expected.update(exposure_ev=.25, saturation_scale=.9, vibrance=.2)
    expected['lab_shift'] = [1., -2.]
    expected['recorded_parameters'] = {'Clarity2012': 80, 'Texture': 60,
                                       'Sharpness': 100, 'LuminanceSmoothing': 50}
    old = _legacy(expected, version)
    pixels = np.random.default_rng(882).integers(10, 230, (91, 137, 3), dtype=np.uint8)
    baseline = apply_pixels(pixels, prepare_style(pixels, expected)[0], .8)[0]
    upgraded = apply_pixels(pixels, prepare_style(pixels, old)[0], .8)[0]
    assert np.array_equal(upgraded, baseline)
    assert validate_dna(old)['detail_profile'] == neutral_detail_profile()


def test_scene_and_hybrid_detail_mixtures_are_bounded_nonmutating_and_evidence_aware():
    first = learn_detail_profile([_payload(1, params={'Clarity2012': 80, 'Sharpness': 100})], 'raw_xmp')
    second = learn_detail_profile([_payload(2, params={'Clarity2012': -60})], 'raw_xmp')
    before = copy.deepcopy(first)
    mixed = mix_detail_profiles(first, [(second, .4)])
    assert mixed['controls']['clarity'] == pytest.approx(.24)
    assert mixed['controls']['sharpening'] == pytest.approx(.6)
    assert mixed['support']['sharpening']['confidence'] == pytest.approx(.6)
    assert first == before
    assert blend_detail_profiles([(first, 1), (second, 0)]) == first
    with pytest.raises(ValueError):
        mix_detail_profiles(first, [(second, 1.1)])
    with pytest.raises(ValueError):
        mix_detail_profiles(first, [(second, True)])


@pytest.mark.parametrize('control', list(CONTROL_RANGES))
def test_invalid_detail_values_and_private_fields_are_rejected(control):
    profile = neutral_detail_profile()
    profile['controls'][control] = float('nan')
    with pytest.raises(ValueError):
        validate_detail_profile(profile)
    profile = neutral_detail_profile()
    profile['support'][control]['photo_path'] = '/private/photo.jpg'
    with pytest.raises(ValueError):
        validate_detail_profile(profile)


def test_paired_saturation_gain_vibrance_and_supported_residual_do_not_duplicate_global_fit():
    payload = _payload(1)
    payload['color'] = {'hsv': {'saturation_delta': .2}, 'saturation_model': {
        'status': 'ok', 'gain': 1.4, 'vibrance': .3, 'confidence': .9, 'vibrance_confidence': .8},
        'hue_bands': {'red': {'confidence': .9, 'saturation_delta': .2,
                             'saturation_residual': .01, 'saturation_residual_confidence': .9}}}
    dna = dna_from_batch({'mode': 'raw_jpg', 'results': [{'status': 'ok', 'payload': payload}]}, 'Fit')
    assert dna['saturation_scale'] == 1.4 and dna['vibrance'] == .3
    assert dna['hsl']['red']['saturation'] == .01
    payload['color']['hue_bands']['red']['saturation_residual_confidence'] = .2
    dna = dna_from_batch({'mode': 'raw_jpg', 'results': [{'status': 'ok', 'payload': payload}]}, 'Weak residual')
    assert dna['hsl']['red']['saturation'] == 0
    payload['color'].pop('saturation_model')
    dna = dna_from_batch({'mode': 'raw_jpg', 'results': [{'status': 'ok', 'payload': payload}]}, 'Legacy fit')
    assert dna['saturation_scale'] == pytest.approx(1.3)
    assert dna['vibrance'] == 0 and dna['hsl']['red']['saturation'] == .2
