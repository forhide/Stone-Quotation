"""Observed color controls separate global HSV behavior from hue residuals."""

import copy
import json

import cv2
import numpy as np
import pytest

from personal_color_lab.core.color_analysis import analyze_color


def _rgb(hsv):
    return np.rint(np.clip(cv2.cvtColor(hsv.astype(np.float32), cv2.COLOR_HSV2RGB), 0, 1) * 255).astype(np.uint8)


def _source(size=96, saturation=None):
    # Cover every hue and a wide range of saturation at nonclipped luminance.
    x, y = np.meshgrid(np.arange(size), np.arange(size))
    result = np.empty((size, size, 3), np.float32)
    result[..., 0] = (x * 360 / size) % 360
    result[..., 1] = .1 + .78 * y / (size - 1) if saturation is None else saturation
    result[..., 2] = .72
    return result


def _change(source, gain, vibrance=0):
    result = source.copy()
    s = result[..., 1]
    result[..., 1] = np.clip(s * gain * (1 + vibrance * (1 - s)), 0, 1)
    return result


def _report(source, edited, mask=None):
    original_rgb, edited_rgb = _rgb(source), _rgb(edited)
    before = (original_rgb.copy(), edited_rgb.copy())
    report = analyze_color(original_rgb, edited_rgb,
                           np.ones(source.shape[:2], bool) if mask is None else mask)
    np.testing.assert_array_equal(original_rgb, before[0])
    np.testing.assert_array_equal(edited_rgb, before[1])
    json.dumps(report, allow_nan=False)
    return report


@pytest.mark.parametrize("gain,vibrance", [(1., 0.), (.55, 0.), (1.3, 0.),
                                            (.85, .6), (1.1, -.5), (.6, -1.)])
def test_known_global_gain_and_vibrance_are_separated(gain, vibrance):
    source = _source()
    report = _report(source, _change(source, gain, vibrance))
    model = report["saturation_model"]
    assert model["schema_version"] == 1 and model["status"] == "ok"
    assert model["gain"] == pytest.approx(gain, abs=.025)
    assert model["vibrance"] == pytest.approx(vibrance, abs=.04)
    assert model["confidence"] > .65
    assert model["vibrance_confidence"] > .6
    assert all(abs(band["saturation_residual"]) < .012 for band in report["hue_bands"].values())


def test_same_mean_saturation_change_does_not_make_gain_and_vibrance_identical():
    source = _source()
    increased = _change(source, 1., .5)
    fitted_vibrance = _report(source, increased)["saturation_model"]
    mean_ratio = float(np.mean(increased[..., 1]) / np.mean(source[..., 1]))
    fitted_gain = _report(source, _change(source, mean_ratio))["saturation_model"]
    assert fitted_vibrance["gain"] == pytest.approx(1., abs=.02)
    assert fitted_vibrance["vibrance"] == pytest.approx(.5, abs=.04)
    assert fitted_gain["gain"] > 1.1
    assert fitted_gain["vibrance"] == pytest.approx(0., abs=.04)


def test_single_saturation_can_support_gain_but_cannot_identify_vibrance():
    source = _source(saturation=.4)
    model = _report(source, _change(source, .7, .5))["saturation_model"]
    assert model["status"] == "ok"
    assert model["gain"] == pytest.approx(.7 * (1 + .5 * (1 - .4)), abs=.015)
    assert model["vibrance"] is None and model["vibrance_confidence"] == 0
    assert "saturation_model_vibrance_insufficient_variation" in model["limitations"]


def test_noise_and_local_color_outliers_do_not_define_the_global_operation():
    rng = np.random.default_rng(97)
    source = _source()
    edited = _change(source, .9, .45)
    edited[..., 1] = np.clip(edited[..., 1] + rng.normal(0, .004, edited.shape[:2]), 0, 1)
    outliers = rng.random(edited.shape[:2]) < .18
    edited[..., 1][outliers] = rng.uniform(.05, .92, int(outliers.sum()))
    model = _report(source, edited)["saturation_model"]
    assert model["gain"] == pytest.approx(.9, abs=.035)
    assert model["vibrance"] == pytest.approx(.45, abs=.06)
    assert .5 < model["confidence"] < .9
    assert "saturation_model_inconsistent_local_color" in model["limitations"]


def test_per_band_residual_removes_global_gain_before_learning_local_saturation():
    source = _source(128)
    edited = _change(source, .75, .3)
    green = (source[..., 0] >= 75) & (source[..., 0] < 165)
    edited[..., 1][green] += .08
    report = _report(source, edited)
    model = report["saturation_model"]
    assert model["gain"] == pytest.approx(.75, abs=.04)
    assert model["vibrance"] == pytest.approx(.3, abs=.09)
    assert report["hue_bands"]["green"]["saturation_residual"] == pytest.approx(.08, abs=.015)
    for name, band in report["hue_bands"].items():
        if name != "green":
            assert abs(band["saturation_residual"]) < .015
    # Historical measurements still describe the complete observed HLS shift.
    assert report["hue_bands"]["red"]["saturation_delta"] < -.03


@pytest.mark.parametrize("kind", ["achromatic", "black", "source_clipped", "target_clipped"])
def test_unsupported_pixels_never_invent_a_global_color_operation(kind):
    source = _source()
    edited = _change(source, .8, .5)
    if kind == "achromatic":
        source[..., 1] = 0
    elif kind == "black":
        source[..., 2] = .02
    elif kind == "source_clipped":
        source[..., 2] = 1
    else:
        edited[..., 2] = 1
    report = _report(source, edited)
    model = report["saturation_model"]
    assert model["status"] == "insufficient"
    assert model["gain"] is None and model["vibrance"] is None
    assert model["confidence"] == 0
    assert all(band["saturation_residual"] is None for band in report["hue_bands"].values())


def test_complete_desaturation_identifies_zero_gain_without_vibrance_or_b_and_w_claim():
    source = _source()
    report = _report(source, _change(source, 0))
    model = report["saturation_model"]
    assert model["gain"] == 0
    assert model["vibrance"] is None and model["vibrance_confidence"] == 0
    assert report["achromatic_evidence"]["edited_achromatic_fraction"] == 1
    assert "saturation_model_vibrance_unobservable_desaturation" in model["limitations"]


def test_small_or_masked_support_is_insufficient_and_inputs_stay_unchanged():
    source = _source(32)
    edited = _change(source, .75, .5)
    saved = copy.deepcopy((source, edited))
    mask = np.zeros((32, 32), bool)
    mask[:2, :16] = True
    report = _report(source, edited, mask)
    assert report["saturation_model"]["sample_count"] == 32
    assert report["saturation_model"]["status"] == "insufficient"
    np.testing.assert_array_equal(source, saved[0])
    np.testing.assert_array_equal(edited, saved[1])
    empty = _report(source, edited, np.zeros_like(mask))
    assert empty["saturation_model"]["status"] == "insufficient"
    assert empty["saturation_model"]["sample_count"] == 0


def test_overlap_excludes_the_unrelated_saturation_change():
    source = _source()
    edited = _change(source, .85, -.4)
    edited[:48, :, 1] = .9
    mask = np.ones((96, 96), bool)
    mask[:48] = False
    model = _report(source, edited, mask)["saturation_model"]
    assert model["gain"] == pytest.approx(.85, abs=.03)
    assert model["vibrance"] == pytest.approx(-.4, abs=.06)


def test_large_overlap_has_bounded_fitting_and_finite_supported_result():
    source = _source(400)
    report = _report(source, _change(source, .9, .25))
    assert report["sample_count"] == 100_000
    model = report["saturation_model"]
    assert 512 <= model["sample_count"] <= 100_000
    assert model["gain"] == pytest.approx(.9, abs=.025)
    assert model["vibrance"] == pytest.approx(.25, abs=.04)


def test_out_of_range_gain_is_bounded_and_declared_in_evidence():
    source = _source(saturation=.2)
    model = _report(source, _change(source, 3))["saturation_model"]
    assert model["gain"] == 2
    assert model["vibrance"] is None
    assert "saturation_model_gain_bounded" in model["limitations"]
    assert model["confidence"] < .2
