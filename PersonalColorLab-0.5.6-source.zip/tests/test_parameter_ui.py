"""Evidence remains usable without inventing missing edit history."""
import copy
import os

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.i18n import I18N
from personal_color_lab.ui.parameter_evidence import (
    batch_parameter_cards, detail_control_card, effective_parameter_lines,
    parameter_evidence_lines, source_parameter_cards,
)
from test_source_workflow_ui import desktop, _pump, _inputs, _open, _analyze
from test_style_workspace_ui import ready

gui = pytest.mark.skipif(os.name != 'nt' and not os.environ.get('DISPLAY'), reason='Requires desktop display or Xvfb')


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_recorded_neutral_is_distinct_from_unrecorded_detail(language):
    i18n = I18N(language)
    payload = {'parameters': {'Contrast2012': 24, 'Saturation': -12, 'Clarity2012': 0, 'Texture': 17}}
    cards = source_parameter_cards(i18n, payload, 'raw_xmp')
    assert cards['contrast']['value'] == '24'
    assert cards['saturation']['value'] == '-12'
    assert cards['clarity']['value'] == '0'
    assert cards['clarity']['basis'] == 'recorded'
    assert cards['temperature']['basis'] == 'unavailable'
    assert cards['temperature']['value'] == i18n.t('summary_not_measured')


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_reference_detail_describes_appearance_without_claiming_slider_history(language):
    i18n = I18N(language)
    payload = {'detail': {'kind': 'appearance', 'appearance': {'local_contrast': .12, 'texture_energy': .03, 'fine_energy': .006, 'flat_noise_mad': None}}}
    before = copy.deepcopy(payload)
    cards = source_parameter_cards(i18n, payload, 'reference_jpg')
    assert cards['clarity']['basis'] == 'appearance'
    assert cards['texture']['basis'] == 'appearance'
    assert '0.120' in cards['clarity']['value']
    lines = parameter_evidence_lines(i18n, payload, 'reference_jpg')
    assert i18n.t('parameter_reference_detail_notice') in lines
    assert payload == before


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_old_analysis_missing_detail_is_unmeasured_and_reanalysis_is_explained(language):
    i18n = I18N(language)
    payload = {'status': 'ok', 'tone': {'contrast_delta': .13}, 'color': {'hsv': {'saturation_delta': -.08}}}
    cards = source_parameter_cards(i18n, payload, 'raw_jpg')
    assert cards['contrast']['value'] == i18n.t('direction_higher')
    assert cards['saturation']['value'] == i18n.t('direction_lower')
    assert cards['clarity']['value'] == i18n.t('summary_not_measured')
    assert i18n.t('parameter_legacy_detail_notice') in parameter_evidence_lines(i18n, payload, 'raw_jpg')
    batch = {'mode': 'raw_jpg', 'results': [{'status': 'ok', 'payload': payload}]}
    assert batch_parameter_cards(i18n, batch)['clarity']['value'] == i18n.t('summary_not_measured')


@pytest.mark.parametrize('value', [None, True, float('nan'), float('inf'), 2.0])
def test_uncertain_detail_never_acquires_a_fake_zero(value):
    i18n = I18N('en')
    card = detail_control_card(i18n, {'kind': 'paired', 'controls': {'clarity': {'estimate': value, 'confidence': .8, 'direction': 'higher'}}}, 'clarity')
    assert card['value'] == i18n.t('direction_uncertain')
    assert '0.00' not in card['note']


def test_paired_batch_uses_unique_source_stats_and_does_not_double_count_edited_duplicates():
    i18n = I18N('en')
    batch = {'mode': 'raw_jpg', 'summary': {
        'detail_stats': {'kind': 'paired', 'controls': {'clarity': {'median': .3, 'confidence_median': .76, 'sample_count': 3}}},
        'color_stats': {'saturation_gain': {'median': 1.18, 'confidence_median': .91, 'sample_count': 3}},
    }, 'results': [{'status': 'ok', 'payload': {'detail': {'kind': 'paired', 'controls': {'clarity': {'estimate': -.9, 'confidence': .1}}}}}]}
    cards = batch_parameter_cards(i18n, batch)
    assert cards['clarity']['value'] == i18n.t('direction_higher')
    assert '+0.30' in cards['clarity']['note']
    assert cards['saturation']['value'] == '1.18×'


def test_excluded_conflicting_edits_cannot_reappear_in_the_batch_parameter_card():
    i18n=I18N('en')
    batch={'mode':'raw_jpg','summary':{'detail_stats':{'kind':'paired','controls':{'clarity':{'median':None,'confidence_median':None,'sample_count':0}}}},
           'results':[{'status':'ok','payload':{'detail':{'kind':'paired','controls':{'clarity':{'estimate':.8,'confidence':.9,'direction':'higher'}}}}}]}
    card=batch_parameter_cards(i18n,batch)['clarity']
    assert card['value']==i18n.t('direction_uncertain')
    assert '+0.80' not in card['note']


@pytest.mark.parametrize('language',['en','ko'])
def test_unrendered_recorded_parameters_are_visible_in_the_actual_recipe_panel(language):
    i18n=I18N(language)
    lines=effective_parameter_lines(i18n,{},.7,{'xmp_only':['Dehaze','ParametricDarks'],'pixel_applied':['Clarity2012']})
    expected=i18n.t('parameter_xmp_only',names=', '.join(i18n.t('source_param_'+key) if 'source_param_'+key in i18n.messages else key for key in ('Dehaze','ParametricDarks')))
    assert expected in lines
    assert 'source_param_' not in '\n'.join(lines)


def test_color_noise_reduction_is_unmeasured_when_pair_analysis_does_not_estimate_it():
    i18n=I18N('en')
    card=detail_control_card(i18n,{'kind':'paired','controls':{'clarity':{'estimate':0.,'confidence':.9,'direction':'neutral'}}},'denoise_color')
    assert card['value']==i18n.t('summary_not_measured')
    assert card['basis']=='unavailable'


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_effective_recipe_reports_current_strength_hsl_and_inferred_support(language):
    i18n = I18N(language)
    effective = {'tone_curve': np.linspace(0, 1, 17).tolist(), 'saturation_scale': 1.3, 'vibrance': .2,
                 'hsl': {'red': {'hue': 8, 'saturation': .1, 'lightness': -.03}},
                 'detail_profile': {'controls': {'clarity': .4, 'texture': 0, 'sharpening': .2},
                                    'support': {'clarity': {'basis': 'inferred'}, 'texture': {'basis': 'recorded'}}},
                 'recorded_parameters': {'Dehaze': 15}}
    lines = effective_parameter_lines(i18n, effective, .5)
    text = '\n'.join(lines)
    assert '1.15×' in text
    assert '+20.0%' in text
    assert '+4.0' in text
    assert i18n.t('parameter_basis_recorded') in text
    assert i18n.t('parameter_basis_inferred') in text
    assert i18n.t('parameter_unlearned_neutral') in text
    assert i18n.t('parameter_dehaze_xmp_only') in text


@gui
@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
@pytest.mark.parametrize('language', ['en', 'ko'])
@pytest.mark.parametrize('desktop', [1, 1.5, 2], indirect=True)
def test_folder_overview_exposes_parameter_evidence_in_each_input_mode(desktop, mode, language):
    app, root = desktop
    app.lang.set(language); app.change_language()
    window = _open(app, _inputs(root / mode, mode), mode)
    _analyze(app, window)
    width,height=window.minsize();window.geometry(f'{width}x{height}');app.update()
    assert window.cards_frame.winfo_ismapped()
    assert set(window.cards) == {'brightness', 'temperature', 'contrast', 'saturation', 'clarity', 'texture'}
    if mode == 'raw_xmp':
        assert window.cards['contrast'].cget('text') == '12'
        assert window.card_notes['contrast'].cget('text') == app.i18n.t('parameter_basis_recorded_compact')
    elif mode == 'reference_jpg':
        assert window.card_notes['contrast'].cget('text') == app.i18n.t('parameter_basis_appearance_compact')
    for widget in (window.result_tree,window.details,window.save_btn,window.apply_btn,*window.cards.values()):
        assert widget.winfo_ismapped()
        assert widget.winfo_rooty()+widget.winfo_height()<=window.winfo_rooty()+window.winfo_height()
    window.close()
    assert not window.card_notes


@gui
@pytest.mark.parametrize('desktop', [1, 1.5, 2], indirect=True)
@pytest.mark.parametrize('language', ['en', 'ko'])
def test_applied_parameter_panel_preserves_photo_and_export_space(desktop, monkeypatch, language):
    app, root = desktop
    app.lang.set(language); app.change_language()
    path = root / 'photo.jpg'
    Image.fromarray(np.random.default_rng(54).integers(20, 230, (120, 180, 3), dtype='uint8')).save(path)
    window = app.open_style_workspace()
    window.source = path; window._schedule_preview(); _pump(app, lambda: ready(window))
    width, height = window.minsize(); window.geometry(f'{width}x{height}'); app.update()
    assert window.parameters_frame.winfo_ismapped()
    text = window.parameters_text.get('1.0', 'end')
    for label in ('parameter_contrast', 'parameter_saturation', 'parameter_clarity', 'parameter_texture'):
        assert app.i18n.t(label) in text
    for widget in (window.preview_stage, window.jpeg_btn, window.xmp_btn):
        assert widget.winfo_rooty() + widget.winfo_height() <= window.winfo_rooty() + window.winfo_height()
    generation = window._generation
    window.parameters_btn.invoke(); app.update()
    assert not window.parameters_frame.winfo_ismapped()
    window.parameters_btn.invoke(); app.update()
    assert window.parameters_frame.winfo_ismapped()
    assert window._generation == generation
    window.close()
    assert window.parameters_text is None
