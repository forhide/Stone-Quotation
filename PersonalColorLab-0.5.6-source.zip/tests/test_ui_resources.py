"""Localization, cache validity, and worker safety without a graphical display."""

import ast
import json
import queue
import string
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

import pytest

from personal_color_lab.core.constants import DATA_DIR_ENV, DATA_DIR_NAME, app_data_dir
from personal_color_lab.core.edit_reverse import ALGORITHM_VERSION
from personal_color_lab.core.i18n import I18N
from personal_color_lab.core.settings import load_settings, save_settings, settings_path
from personal_color_lab.ui.app import App
from personal_color_lab.ui.pair_inspector import PairInspector, analysis_summary, analysis_text, cache_is_current, file_sha256


ROOT = Path(__file__).resolve().parents[1] / 'personal_color_lab'


def _locale(language):
    return json.loads((ROOT / 'locales' / f'{language}.json').read_text(encoding='utf-8'))


def _placeholders(text):
    return {name for _, name, _, _ in string.Formatter().parse(text) if name is not None}


def test_locale_keys_and_format_arguments_match():
    en, ko = _locale('en'), _locale('ko')
    assert en.keys() == ko.keys()
    for key in en:
        assert _placeholders(en[key]) == _placeholders(ko[key]), key
        assert isinstance(en[key], str) and en[key]
        assert isinstance(ko[key], str) and ko[key]


def test_literal_ui_translation_keys_exist():
    messages = _locale('en')
    for path in (ROOT / 'ui').glob('*.py'):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call) or not node.args:
                continue
            translated = (
                isinstance(node.func, ast.Name) and node.func.id == 't'
                or isinstance(node.func, ast.Attribute) and node.func.attr == 't'
            )
            if translated and isinstance(node.args[0], ast.Constant):
                assert node.args[0].value in messages, (path.name, node.args[0].value)


def test_data_directory_override_keeps_home_and_settings_local(tmp_path, monkeypatch):
    previous_home = __import__('os').environ.get('HOME')
    target = tmp_path / 'local-state'
    monkeypatch.setenv(DATA_DIR_ENV, str(target))
    assert app_data_dir() == target
    assert load_settings() == {'language': 'en'}
    save_settings({'language': 'ko'})
    assert settings_path() == target / 'settings.json'
    assert load_settings()['language'] == 'ko'
    assert __import__('os').environ.get('HOME') == previous_home
    save_settings({'language': 'unsupported'})
    assert load_settings()['language'] == 'en'


def test_default_data_directory_stays_in_user_home(tmp_path, monkeypatch):
    monkeypatch.delenv(DATA_DIR_ENV, raising=False)
    monkeypatch.setattr(Path, 'home', classmethod(lambda cls: tmp_path))
    assert app_data_dir() == tmp_path / DATA_DIR_NAME


def _payload():
    return {
        'status': 'ok', 'schema_version': 1, 'algorithm_version': ALGORITHM_VERSION,
        'provenance': {'input_fingerprints': {'original': 'original-sha', 'edited': 'edited-sha'}},
        'alignment': {'success': True, 'confidence': 0.8, 'overlap_fraction': 0.75},
        'confidence': 0.8,
        'tone': {'mean_luminance_delta': 0.1, 'zones': {}, 'estimated_exposure_ev': None},
        'color': {'lab': {'delta_l': 1.2, 'delta_a': None}, 'wb_tint': {'temperature_direction': 'uncertain', 'tint_direction': 'uncertain', 'confidence': 0.0}},
        'lightroom_estimates': {'approximate': True, 'exposure_ev': None, 'contrast_direction': 'higher'},
        'warnings': ['inferred_transform', 'future_unknown_warning'],
    }


def test_cache_requires_both_sha256_fingerprints_and_version():
    payload = _payload()
    assert cache_is_current(payload, 'original-sha', 'edited-sha')
    assert not cache_is_current(payload, 'different-sha', 'edited-sha')
    assert not cache_is_current(payload, 'edited-sha', 'original-sha')
    older = deepcopy(payload)
    older['algorithm_version'] = '0.1.0'
    assert not cache_is_current(older, 'original-sha', 'edited-sha')
    malformed = deepcopy(payload)
    malformed['provenance'] = None
    assert not cache_is_current(malformed, 'original-sha', 'edited-sha')
    failed = deepcopy(payload)
    failed['status'] = 'alignment_failed'
    assert cache_is_current(failed, 'original-sha', 'edited-sha')


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_analysis_text_exposes_uncertainty_and_hides_failed_alignment_estimates(language):
    i18n = I18N(language)
    payload = _payload()
    text = analysis_text(i18n, payload)
    assert i18n.t('approximate_notice') in text
    assert i18n.t('not_available') in text
    assert i18n.t('direction_uncertain') in text
    assert i18n.t('warning_inferred_transform') in text
    assert 'future_unknown_warning' not in text
    payload['status'] = 'alignment_failed'
    payload['alignment']['success'] = False
    payload['tone']['mean_luminance_delta'] = 987654.0
    payload['color']['lab']['delta_l'] = 456789.0
    failed_text = analysis_text(i18n, payload)
    assert i18n.t('alignment_failed_notice') in failed_text
    assert '987654' not in failed_text and '456789' not in failed_text
    assert i18n.t('observed_color') not in failed_text
    assert i18n.t('approximate_sliders') not in failed_text


def test_file_hash_is_non_destructive(tmp_path):
    photo = tmp_path / 'original.jpg'
    data = bytes(range(256)) * 20
    photo.write_bytes(data)
    before = photo.stat().st_mtime_ns
    assert len(file_sha256(photo)) == 64
    assert photo.read_bytes() == data
    assert photo.stat().st_mtime_ns == before


def test_scan_failure_queues_exception_and_finishes_without_tk(tmp_path, monkeypatch):
    import personal_color_lab.ui.app as app_module

    def failing_scan(*args):
        raise ValueError('fixture-local-read-failure')

    monkeypatch.setattr(app_module, 'scan_folder', failing_scan)
    dummy = SimpleNamespace(_events=queue.Queue())
    App._scan_worker(dummy, tmp_path, True, tmp_path / 'library.db')
    assert dummy._events.get_nowait() == ('error', 'fixture-local-read-failure')
    assert dummy._events.get_nowait() == ('finished',)


def test_inspector_unreadable_photo_queues_failure_without_tk(tmp_path):
    original, edited = tmp_path / 'broken.jpg', tmp_path / 'missing.jpg'
    original.write_bytes(b'not-a-photo')
    dummy = SimpleNamespace(_events=queue.Queue())
    PairInspector._worker(dummy, original, edited, tmp_path / 'library.db', False)
    assert dummy._events.get_nowait()[0] == 'error'
    assert dummy._events.get_nowait() == ('finished',)


def _worker_fixture(tmp_path):
    from PIL import Image
    original, edited = tmp_path / 'scene_original.jpg', tmp_path / 'scene_edit.jpg'
    Image.new('RGB', (160, 120), (100, 120, 140)).save(original)
    Image.new('RGB', (160, 120), (140, 145, 150)).save(edited)
    payload = _payload()
    payload['provenance']['input_fingerprints'] = {'original': file_sha256(original), 'edited': file_sha256(edited)}
    return original, edited, payload


def test_force_reanalysis_skips_corrupt_cache_and_persists_failure(tmp_path, monkeypatch):
    import personal_color_lab.ui.pair_inspector as inspector_module
    from personal_color_lab.core import edit_reverse

    original, edited, payload = _worker_fixture(tmp_path)
    payload['status'] = 'alignment_failed'
    payload['alignment']['success'] = False
    saved, closed = [], []

    class FakeDB:
        def __init__(self, path):
            pass

        def get_analysis(self, *args):
            raise ValueError('corrupt-cache-must-not-be-read')

        def save_analysis(self, source, result, evidence):
            saved.append((source, result, evidence))

        def close(self):
            closed.append(True)

    monkeypatch.setattr(inspector_module, 'LibraryDB', FakeDB)
    monkeypatch.setattr(edit_reverse, 'analyze_pair', lambda source, result: payload)
    dummy = SimpleNamespace(_events=queue.Queue())
    PairInspector._worker(dummy, original, edited, tmp_path / 'library.db', True)
    events = list(dummy._events.queue)
    assert events[0][0] == 'previews'
    assert events[-2] == ('result', payload, False)
    assert events[-1] == ('finished',)
    assert saved == [(original, edited, payload)]
    assert closed == [True]


@pytest.mark.parametrize('changed', [False, True])
def test_cache_reuse_verifies_files_without_analyzing_stale_evidence(tmp_path, monkeypatch, changed):
    import personal_color_lab.ui.pair_inspector as inspector_module
    from personal_color_lab.core import edit_reverse

    original, edited, payload = _worker_fixture(tmp_path)
    if changed:
        payload['provenance']['input_fingerprints']['edited'] = 'old-content'

    class FakeDB:
        def __init__(self, path):
            pass

        def get_analysis(self, *args):
            return payload

        def save_analysis(self, *args):
            pytest.fail('A cached or stale result must not be resaved')

        def close(self):
            pass

    def unexpected_analysis(*args):
        pytest.fail('Cache handling should not implicitly start reanalysis')

    monkeypatch.setattr(inspector_module, 'LibraryDB', FakeDB)
    monkeypatch.setattr(edit_reverse, 'analyze_pair', unexpected_analysis)
    dummy = SimpleNamespace(_events=queue.Queue())
    PairInspector._worker(dummy, original, edited, tmp_path / 'library.db', False)
    events = list(dummy._events.queue)
    assert events[-2] == ('stale',) if changed else events[-2] == ('result', payload, True)
    assert events[-1] == ('finished',)


def test_large_preview_is_bounded_and_exif_oriented_without_changes(tmp_path):
    from PIL import Image
    from personal_color_lab.ui.pair_inspector import load_preview

    original = tmp_path / 'large.jpg'
    exif = Image.Exif()
    exif[274] = 6
    Image.new('RGB', (3200, 2000), (128, 100, 70)).save(original, exif=exif)
    before = file_sha256(original)
    preview, profile_failed = load_preview(original)
    assert preview.width <= 480 and preview.height <= 290
    assert preview.width < preview.height
    assert not profile_failed
    assert file_sha256(original) == before


@pytest.mark.parametrize('path, malformed', [
    (('tone', 'zones'), ['bad_nested_type']),
    (('color', 'lab'), ['bad_nested_type']),
    (('color', 'wb_tint'), 'bad_nested_type'),
    (('lightroom_estimates',), ['bad_nested_type']),
    (('tone', 'zones', 'shadows'), 'bad_nested_type'),
])
def test_malformed_nested_cache_is_rejected_and_renderer_does_not_raise(path, malformed):
    payload = _payload()
    target = payload
    for name in path[:-1]:
        target = target[name]
    target[path[-1]] = malformed
    assert not cache_is_current(payload, 'original-sha', 'edited-sha')
    text = analysis_text(I18N('en'), payload)
    assert I18N('en').t('approximate_notice') in text


def test_invalid_queued_payload_does_not_stop_polling_or_disable_retry():
    payload = _payload()
    payload['tone']['zones'] = ['bad_nested_type']
    events = queue.Queue()
    events.put(('result', payload, True))
    events.put(('finished',))
    states, details, busy_states, scheduled = [], [], [], []
    dummy = SimpleNamespace(
        _closed=False, _events=events, payload=None, i18n=I18N('en'),
        state=SimpleNamespace(set=states.append), _set_details=details.append,
        _set_busy=busy_states.append,
        after=lambda delay, callback: scheduled.append((delay, callback)) or 'poll-again',
    )
    dummy._poll = lambda: None
    dummy._handle_event = lambda event: PairInspector._handle_event(dummy, event)
    PairInspector._poll(dummy)
    assert dummy.payload is None
    assert dummy._state_key == 'analysis_error'
    assert I18N('en').t('analysis_result_invalid') in details
    assert busy_states[-1] is False
    assert dummy._poll_id == 'poll-again'
    assert len(scheduled) == 1
    assert events.empty()


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_uncertain_color_space_cache_and_notice_withhold_edit_estimates(language):
    payload = _payload()
    payload['status'] = 'color_space_uncertain'
    payload['tone']['mean_luminance_delta'] = 987654.0
    payload['warnings'] = ['icc_conversion_failed', 'color_space_uncertain']
    i18n = I18N(language)
    assert cache_is_current(payload, 'original-sha', 'edited-sha')
    text = analysis_text(i18n, payload)
    assert i18n.t('color_space_uncertain_notice') in text
    assert i18n.t('warning_color_space_uncertain') in text
    assert i18n.t('alignment_failed_notice') not in text
    assert i18n.t('observed_tone') not in text
    assert '987654' not in text


@pytest.mark.parametrize('language', ['en', 'ko'])
@pytest.mark.parametrize('delta, direction', [
    (0.03, 'summary_brighter'),
    (-0.03, 'summary_darker'),
    (0.001, 'summary_similar_brightness'),
])
def test_simple_summary_explains_observed_brightness_and_shared_coverage(language, delta, direction):
    i18n = I18N(language)
    payload = _payload()
    payload['tone']['mean_luminance_delta'] = delta
    summary = analysis_summary(i18n, payload)
    assert summary['state'] == 'ok'
    assert len(summary['cards']) == 7
    by_key = {card['key']: card for card in summary['cards']}
    brightness, color, coverage = (by_key[key] for key in ('brightness', 'temperature', 'geometry'))
    assert brightness['value'] == i18n.t(direction)
    assert brightness['note'].splitlines()[0] == i18n.t('summary_brightness_points', delta=f'{delta * 100:+.1f}')
    assert i18n.t('summary_ev_unavailable') in brightness['note']
    assert i18n.t('direction_uncertain') in color['value']
    assert i18n.t('summary_evidence_limited') in color['note']
    assert coverage['value'] == i18n.t('summary_coverage', percent='75')


@pytest.mark.parametrize('language', ['en', 'ko'])
@pytest.mark.parametrize('status', ['alignment_failed', 'color_space_uncertain'])
def test_simple_summary_withholds_all_values_and_curve_for_unusable_analysis(language, status):
    i18n = I18N(language)
    payload = _payload()
    payload['status'] = status
    payload['tone']['mean_luminance_delta'] = 987654.0
    payload['tone']['tone_transfer'] = [
        {'input': 0.1, 'output': 0.2, 'count': 50},
        {'input': 0.8, 'output': 0.9, 'count': 50},
    ]
    summary = analysis_summary(i18n, payload)
    assert summary['state'] == status
    assert all(card['value'] == i18n.t('summary_not_measured') for card in summary['cards'])
    assert '987654' not in str(summary)
    assert not summary['curve_available']
    assert summary['curve'] == []


def test_simple_summary_renders_only_the_measured_monotone_curve():
    payload = _payload()
    payload['tone']['tone_transfer'] = [
        {'input': 0.1, 'output': 0.2, 'count': 50},
        {'input': 0.5, 'output': 0.55, 'count': 80},
        {'input': 0.8, 'output': 0.9, 'count': 50},
    ]
    summary = analysis_summary(I18N('en'), payload)
    assert summary['curve_available']
    assert summary['curve'] == [(0.1, 0.2), (0.5, 0.55), (0.8, 0.9)]


@pytest.mark.parametrize('bad_point', [
    {'input': float('nan'), 'output': 0.7, 'count': 20},
    {'input': 0.5, 'output': float('inf'), 'count': 20},
    {'input': 1.2, 'output': 0.7, 'count': 20},
    {'input': 0.2, 'output': 0.7, 'count': 20},
    {'input': 0.5, 'output': 0.1, 'count': 20},
    {'input': 0.5, 'output': 0.7, 'count': 0},
])
def test_simple_summary_does_not_invent_a_curve_from_invalid_samples(bad_point):
    payload = _payload()
    payload['tone']['tone_transfer'] = [
        {'input': 0.2, 'output': 0.3, 'count': 50},
        bad_point,
        {'input': 0.8, 'output': 0.9, 'count': 50},
    ]
    summary = analysis_summary(I18N('en'), payload)
    assert not summary['curve_available']
    assert summary['curve'] == []
