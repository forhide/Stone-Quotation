"""New parameter evidence survives storage; corrupt cache/profile data is rejected."""
import copy

import numpy as np
import pytest
from PIL import Image

from personal_color_lab.core.database import AnalysisValidationError, LibraryDB
from personal_color_lab.core.edit_reverse import analyze_pair


@pytest.fixture(scope='module')
def actual_pair(tmp_path_factory):
    root=tmp_path_factory.mktemp('actual-parameter-pair')
    rng=np.random.default_rng(883)
    small=rng.integers(30,215,(24,32,3),dtype=np.uint8)
    source=np.array(Image.fromarray(small).resize((320,240),Image.Resampling.BICUBIC))
    original=root/'original.jpg';edited=root/'edited.jpg'
    Image.fromarray(source).save(original,quality=99,subsampling=0)
    Image.fromarray(np.clip(source.astype(float)*1.06+[2,0,-2],0,255).astype('uint8')).save(edited,quality=99,subsampling=0)
    payload=analyze_pair(original,edited)
    assert payload['status']=='ok' and payload['detail']['kind']=='paired'
    return original,edited,payload


def test_new_parameter_observations_roundtrip_without_mutation(tmp_path,actual_pair):
    original,edited,payload=actual_pair;before=copy.deepcopy(payload)
    with LibraryDB(tmp_path/'library.db') as db:
        db.save_analysis(original,edited,payload)
        assert db.get_analysis(original,edited)==before and payload==before
    with LibraryDB(tmp_path/'library.db') as db:
        assert db.get_analysis(original,edited)==before


@pytest.mark.parametrize('corruption',[
    'detail_private','detail_wrong_source','detail_estimate_nan','detail_unknown_warning',
    'sat_private','sat_limit_free_text','sat_no_gain','sat_too_many_samples',
    'sat_boolean_confidence','sat_unobserved_vibrance','sat_unsupported_zero',
    'residual_out_of_range','residual_missing_confidence','color_container',
    'global_private','global_nonmonotone','global_too_many_samples','global_boolean_confidence',
    'global_missing_support','global_invalid_iterations',
])
def test_invalid_evidence_does_not_persist_any_row(tmp_path,actual_pair,corruption):
    original,edited,payload=actual_pair;payload=copy.deepcopy(payload)
    model=payload['color']['saturation_model']
    if corruption.startswith('global_'):
        payload['tone']['global_tone_transfer']=copy.deepcopy(payload['tone']['tone_transfer'])
        payload['tone']['decomposition']={'schema_version':1,'iterations':2,'confidence':.8,'method':'iterative_luma_band_subtraction'}
    if corruption=='detail_private':payload['detail']['photo_path']='/private/library.jpg'
    elif corruption=='detail_wrong_source':payload['detail']['kind']='appearance'
    elif corruption=='detail_estimate_nan':payload['detail']['controls']['clarity']['estimate']=float('nan')
    elif corruption=='detail_unknown_warning':payload['detail']['warnings']=['/private/photo.jpg']
    elif corruption=='sat_private':model['photo_path']='/private/photo.jpg'
    elif corruption=='sat_limit_free_text':model['limitations']=['saturation_model_/private/photo.jpg']
    elif corruption=='sat_no_gain':model['gain']=None
    elif corruption=='sat_too_many_samples':model['sample_count']=payload['color']['sample_count']+1
    elif corruption=='sat_boolean_confidence':model['confidence']=True
    elif corruption=='sat_unobserved_vibrance':model.update(vibrance=None,vibrance_confidence=.5)
    elif corruption=='sat_unsupported_zero':model.update(status='insufficient',gain=0)
    elif corruption=='residual_out_of_range':payload['color']['hue_bands']['red']['saturation_residual']=1.1
    elif corruption=='residual_missing_confidence':payload['color']['hue_bands']['red'].pop('saturation_residual_confidence')
    elif corruption=='color_container':payload['residual_color']=['invalid']
    elif corruption=='global_private':payload['tone']['global_tone_transfer'][0]['path']='/private/photo.jpg'
    elif corruption=='global_nonmonotone':payload['tone']['global_tone_transfer'][0]['output']=1
    elif corruption=='global_too_many_samples':payload['tone']['global_tone_transfer'][0]['count']=100_000
    elif corruption=='global_boolean_confidence':payload['tone']['decomposition']['confidence']=True
    elif corruption=='global_missing_support':payload['tone'].pop('decomposition')
    elif corruption=='global_invalid_iterations':payload['tone']['decomposition']['iterations']=4
    with LibraryDB(tmp_path/'library.db') as db:
        with pytest.raises(AnalysisValidationError):db.save_analysis(original,edited,payload)
        assert db.conn.execute('SELECT count(*) FROM edit_analysis').fetchone()[0]==0


def test_old_measurement_without_new_fields_remains_readable(tmp_path,actual_pair):
    original,edited,payload=actual_pair;payload=copy.deepcopy(payload)
    payload.pop('detail');payload['algorithm_version']='0.5.5'
    for name in ('color','residual_color'):
        if name not in payload:continue
        payload[name].pop('saturation_model',None)
        for band in payload[name].get('hue_bands',{}).values():
            band.pop('saturation_residual',None);band.pop('saturation_residual_confidence',None)
    with LibraryDB(tmp_path/'library.db') as db:
        db.save_analysis(original,edited,payload)
        assert db.get_analysis(original,edited)==payload
