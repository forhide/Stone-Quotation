"""Independent pointwise/spatial edits must not be learned twice."""
from copy import deepcopy
import json
import socket
import threading

import cv2
import numpy as np
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.detail_analysis import analyze_details, validate_detail_report
from personal_color_lab.core.parameter_decomposition import decompose_parameters
from personal_color_lab.core.tone_analysis import (analyze_tone, tone_corrected_rgb,
                                                 validate_global_tone_evidence)

_LUMA = np.array([.2126, .7152, .0722], np.float32)


def scene(size=512):
    yy, xx = np.mgrid[:size, :size].astype(np.float32)
    y = (.5 + .1 * np.sin(xx / 37) + .1 * np.sin(yy / 29)
         + .075 * np.sin((xx + yy) / 12) + .07 * np.sin(xx / 1.7)
         + .06 * np.sin(yy / 2.1))
    return np.rint(y[:, :, None] * 255).clip(0, 255).astype(np.uint8).repeat(3, 2)


def edited_independently(rgb, global_kind="identity", spatial_amount=.65):
    values = rgb.astype(np.float32) / 255
    y = values @ _LUMA
    desired = (np.clip(.5 + (y - .5) * 1.32, 0, 1) if global_kind == "contrast" else
               y + .1 * np.sin(2 * np.pi * (y - .5)) if global_kind == "curve" else y)
    global_pixels = np.rint(np.clip(values * (desired / np.maximum(y, .0001))[:, :, None], 0, 1) * 255).astype(np.uint8)
    # This fixture deliberately does not call production detail_bands or the
    # style renderer. Independent filters establish the editing operation.
    blurred = [cv2.GaussianBlur(desired, (0, 0), sigma * max(y.shape) / 1024,
                                borderType=cv2.BORDER_REFLECT_101) for sigma in (1, 3, 12)]
    delta = spatial_amount * (.45 * (blurred[1] - blurred[2]) + .30 * (blurred[0] - blurred[1]))
    final_y = np.clip(desired + delta, 0, 1)
    edited = np.rint(np.clip(values * (final_y / np.maximum(y, .0001))[:, :, None], 0, 1) * 255).astype(np.uint8)
    return edited, global_pixels


def evidence(rgb, edited, mask=None):
    mask = np.ones(rgb.shape[:2], dtype=bool) if mask is None else mask
    tone = analyze_tone(rgb, edited, mask)
    corrected = tone_corrected_rgb(rgb, tone["tone_transfer"])
    detail = analyze_details(rgb, edited, mask, tone_corrected=corrected)
    return mask, tone, corrected, detail


def fit(rgb, edited, mask=None, **kwargs):
    mask, tone, corrected, detail = evidence(rgb, edited, mask)
    return decompose_parameters(rgb, edited, mask, tone=tone, tone_corrected=corrected,
                                detail=detail, **kwargs), (mask, tone, corrected, detail)


def mae(a, b):
    return float(np.mean(np.abs(a.astype(float) - b.astype(float))))


@pytest.mark.parametrize("amount", [-.65, .65])
def test_local_edit_is_removed_from_global_curve_without_losing_local_evidence(amount):
    rgb = scene()
    edited, global_pixels = edited_independently(rgb, spatial_amount=amount)
    result, (_, observed, initial, detail) = fit(rgb, edited)
    assert result is not None
    assert mae(result["tone_corrected"], global_pixels) < mae(initial, global_pixels) * .5
    assert mae(result["tone_corrected"], global_pixels) < .2
    for name in ("clarity", "texture"):
        assert result["detail"]["controls"][name]["estimate"] == pytest.approx(amount, abs=.08)
    assert observed["tone_transfer"] != result["global_tone_transfer"]
    assert validate_global_tone_evidence({**observed, **{key: result[key] for key in ("global_tone_transfer", "decomposition")}}) == result["global_tone_transfer"]
    validate_detail_report(result["detail"])


@pytest.mark.parametrize("global_kind", ["contrast", "curve"])
def test_real_global_contrast_or_monotone_curve_survives_separation(global_kind):
    rgb = scene()
    edited, true_global = edited_independently(rgb, global_kind)
    result, (_, _, initial, _) = fit(rgb, edited)
    assert result is not None
    assert mae(result["tone_corrected"], true_global) < mae(initial, true_global)
    assert mae(result["tone_corrected"], true_global) < .65
    assert mae(result["tone_corrected"], rgb) > 8
    for name in ("clarity", "texture"):
        assert result["detail"]["controls"][name]["estimate"] == pytest.approx(.65, abs=.08)
    curve = result["global_tone_transfer"]
    assert max(abs(point["input"] - point["output"]) for point in curve) > .06


@pytest.mark.parametrize("global_kind", ["contrast", "curve"])
def test_pointwise_global_change_does_not_become_a_texture_instruction(global_kind):
    rgb = scene()
    edited, _ = edited_independently(rgb, global_kind, 0)
    result, (_, tone, corrected, detail) = fit(rgb, edited)
    chosen = result["detail"] if result is not None else detail
    for name in ("clarity", "texture"):
        assert abs(chosen["controls"][name]["estimate"] or 0) < .025
    if result is not None:
        # The derived result may remove a nonlinear-curvature confounder; the
        # actual observed global curve must remain available unchanged.
        assert result["global_tone_transfer"] == tone["tone_transfer"]
        np.testing.assert_array_equal(result["tone_corrected"], corrected)


@pytest.mark.parametrize("reason", ["confidence", "alignment", "clipping", "sparse"])
def test_uncertain_evidence_abstains_without_mutating_inputs(reason):
    rgb = scene()
    edited, _ = edited_independently(rgb)
    mask, tone, corrected, detail = evidence(rgb, edited)
    alignment = None
    if reason == "confidence":
        for control in detail["controls"].values():
            control["confidence"] = min(.64, control["confidence"])
    elif reason == "alignment":
        alignment = {"success": False}
    elif reason == "clipping":
        tone["clipping"]["edited"]["white_fraction"] = .051
    else:
        mask[:] = False
        mask[100:105, 100:105] = True
    before = (rgb.copy(), edited.copy(), mask.copy(), deepcopy(tone), deepcopy(detail))
    assert decompose_parameters(rgb, edited, mask, tone=tone, tone_corrected=corrected,
                                detail=detail, alignment=alignment) is None
    np.testing.assert_array_equal(rgb, before[0])
    np.testing.assert_array_equal(edited, before[1])
    np.testing.assert_array_equal(mask, before[2])
    assert tone == before[3] and detail == before[4]


def test_invalid_warp_border_does_not_change_the_common_photograph_recipe():
    rgb = scene()
    edited, _ = edited_independently(rgb)
    mask = np.ones(rgb.shape[:2], dtype=bool)
    mask[:, :80] = False
    reference, _ = fit(rgb, edited, mask)
    outside_rgb, outside_edit = rgb.copy(), edited.copy()
    outside_rgb[:, :80] = 0
    outside_edit[:, :80] = 255
    altered, _ = fit(outside_rgb, outside_edit, mask)
    assert reference is not None and altered is not None
    for name in ("clarity", "texture"):
        assert altered["detail"]["controls"][name]["estimate"] == pytest.approx(reference["detail"]["controls"][name]["estimate"], abs=.035)
    a = tone_corrected_rgb(rgb, reference["global_tone_transfer"])
    b = tone_corrected_rgb(rgb, altered["global_tone_transfer"])
    assert mae(a[:, 140:], b[:, 140:]) < .15


def test_analysis_is_offline_bounded_and_never_redevelops_raw(monkeypatch):
    from personal_color_lab.core import parameter_decomposition, raw_decode
    rgb = cv2.resize(scene(), (1200, 1100), interpolation=cv2.INTER_LINEAR)
    edited, _ = edited_independently(rgb)
    mask, tone, corrected, detail = evidence(rgb, edited)
    def deny(*args, **kwargs):
        raise AssertionError("Joint parameter fitting only uses existing registered pixels")
    monkeypatch.setattr(socket, "socket", deny)
    monkeypatch.setattr(raw_decode, "decode_raw", deny)
    original_analyze = parameter_decomposition.analyze_tone
    sizes = []
    def bounded_analyze(a, b, m):
        assert max(a.shape[:2]) <= 1024
        sizes.append(a.shape)
        return original_analyze(a, b, m)
    monkeypatch.setattr(parameter_decomposition, "analyze_tone", bounded_analyze)
    before = (rgb.copy(), edited.copy(), deepcopy(tone), deepcopy(detail))
    result = decompose_parameters(rgb, edited, mask, tone=tone, tone_corrected=corrected, detail=detail)
    assert result is not None and 1 <= len(sizes) <= 3
    assert result["tone_corrected"].shape == rgb.shape
    np.testing.assert_array_equal(rgb, before[0])
    np.testing.assert_array_equal(edited, before[1])
    assert tone == before[2] and detail == before[3]
    json.dumps({key: value for key, value in result.items() if key != "tone_corrected"}, allow_nan=False)


@pytest.mark.parametrize("after_checks", [0, 5])
def test_cancellation_preempts_or_interrupts_tiled_regression(after_checks):
    rgb = scene()
    edited, _ = edited_independently(rgb)
    mask, tone, corrected, detail = evidence(rgb, edited)
    class Cancellation:
        checks = 0
        def is_set(self):
            self.checks += 1
            return self.checks > after_checks
    with pytest.raises(AnalysisCancelledError):
        decompose_parameters(rgb, edited, mask, tone=tone, tone_corrected=corrected,
                             detail=detail, cancel_event=Cancellation())
