"""Real local model forwards, bounded masks and independent region recipes."""
import copy
import hashlib
import json
import shutil
import socket
import numpy as np
import pytest
from PIL import Image
from personal_color_lab.core import semantic_models,scene_analysis
from personal_color_lab.core.semantic_models import verify_models,ModelUnavailableError
from personal_color_lab.core.scene_analysis import analyze_scene,region_appearance,decode_objects
from personal_color_lab.core.style_regions import profile_empty,learn_profile,resized_mask_tile,protect_face_colors
from personal_color_lab.core.style_dna import identity_dna,validate_dna,load_style_file,builtin_styles
from personal_color_lab.core.style_render import render_preview,export_jpeg,_render_regions


def blank():return np.full((120,180,3),128,dtype='uint8')


def test_models_have_official_pinned_bytes_and_cpu_inference_is_network_free(monkeypatch):
    def denied(*a,**kw):pytest.fail('Local inference attempted network access')
    monkeypatch.setattr(socket,'socket',denied);monkeypatch.setattr(socket,'create_connection',denied)
    manifest=verify_models();assert len(manifest['models'])==3
    result=analyze_scene(blank());report=result['report']
    assert report['backend']=='opencv_dnn_cpu' and not report['objects'] and not report['faces']
    assert report['scene_tags']==[] and report['region_fractions']['person']==0
    for mask in result['masks'].values():
        assert mask.shape==(120,180) and np.isfinite(mask).all() and mask.min()>=0 and mask.max()<=1
    # Exercise PP-HumanSeg even for a scene with no detected person.
    output=semantic_models.infer('humanseg',np.zeros((1,3,192,192),np.float32))
    assert output.shape==(1,2,192,192) and np.isfinite(output).all()


def test_model_tampering_or_missing_license_is_rejected(tmp_path):
    root=tmp_path/'models';shutil.copytree(semantic_models.MODEL_ROOT,root)
    model=root/'nanodet.onnx';data=bytearray(model.read_bytes());data[-1]^=1;model.write_bytes(data)
    with pytest.raises(ModelUnavailableError):verify_models(root)
    shutil.copyfile(semantic_models.MODEL_ROOT/'nanodet.onnx',model)
    (root/'yunet-LICENSE.txt').unlink()
    with pytest.raises(ModelUnavailableError):verify_models(root)


def fake_outputs():
    outputs=[]
    for stride in (8,16,32):
        n=(416//stride)**2
        outputs.extend([np.zeros((1,n,80),np.float32),np.zeros((1,n,32),np.float32)])
    return outputs


def test_model_decoder_class_aware_boxes_and_invalid_outputs():
    outputs=fake_outputs();outputs[0][0,100,0]=.9;outputs[0][0,100,53]=.88
    outputs[0][0,101,53]=.92
    boxes=decode_objects(outputs)
    assert {b['class_code'] for b in boxes}=={'person','pizza'}
    assert all(0<=v<=1 for box in boxes for v in box['box'])
    assert all(len(box['box'])==4 for box in boxes)
    with pytest.raises(ValueError):decode_objects(outputs[:4])
    outputs[0][0,0,0]=np.nan
    with pytest.raises(ValueError):decode_objects(outputs)


def test_reference_regions_require_three_distinct_supported_inputs():
    target={'quantiles':[.1,.3,.5,.7,.9],'saturation':.45,'zones':{'midtones':[1,2]}}
    base={'semantic':{'status':'ok','bundle_id':'a'*64,'region_appearance':{'food':{'target':target,'fraction':.3}},'scene_tags':['food']},'appearance':{},'provenance':{'input_fingerprints':{'original':'b'*64}}}
    assert learn_profile([base]*3,'reference_jpg',lambda a:target)['regions']=={}
    samples=[]
    for i in range(3):
        item=copy.deepcopy(base);item['provenance']['input_fingerprints']['original']=f'{i:064x}';samples.append(item)
    profile=learn_profile(samples,'reference_jpg',lambda a:target)
    assert profile['regions']['food']['sample_count']==3
    assert profile['contexts']['food']['sample_count']==3
    dna=identity_dna();dna['semantic_profile']=profile;assert validate_dna(dna)==dna
    bad=copy.deepcopy(dna);bad['semantic_profile']['regions']['food']['target']['quantiles'][0]=99
    with pytest.raises(ValueError):validate_dna(bad)


def test_legacy_style_json_upgrades_without_changing_original(tmp_path):
    dna=identity_dna();legacy=copy.deepcopy(dna);legacy.pop('semantic_profile');legacy.pop('scene_profile');legacy.pop('detail_profile');legacy.update(schema_version=1,engine_version='0.4.0')
    path=tmp_path/'legacy.json';path.write_text(json.dumps(legacy));before=path.read_bytes()
    current=load_style_file(path)
    assert current['schema_version']==4 and current['semantic_profile']==profile_empty()
    assert path.read_bytes()==before and legacy['schema_version']==1


def scene_mask(region='food'):
    masks={r:np.zeros((120,180),np.float32) for r in scene_analysis.REGIONS}
    masks[region][:,:80]=1;masks['background']=1-masks[region]
    return {'report':{'bundle_id':'a'*64,'scene_tags':['food'],'objects':[],'faces':[]},'masks':masks}


def test_region_adjustment_changes_only_supported_pixels_and_can_be_disabled():
    pixels=blank();dna=identity_dna();dna['semantic_profile']={'bundle_id':'a'*64,'contexts':{},'regions':{'food':{'sample_count':1,'evidence':'observed_transform','target':None,'tone_curve':np.clip(np.linspace(0,1,33)+.1,0,1).tolist(),'saturation_scale':1.,'lab_shift':[0,0]}}}
    rendered=_render_regions(pixels,identity_dna(),dna,1.,scene_mask(),1.,False,None)
    assert rendered[:,:70].mean()>pixels[:,:70].mean()+10
    assert np.array_equal(rendered[:,100:],pixels[:,100:])
    disabled=_render_regions(pixels,identity_dna(),dna,1.,scene_mask(),0.,False,None)
    assert np.array_equal(disabled,pixels)
    unknown=scene_mask();unknown['report']['bundle_id']='b'*64
    assert np.array_equal(_render_regions(pixels,identity_dna(),dna,1.,unknown,1.,False,None),pixels)


def test_face_protection_reduces_chroma_shift_preserving_styled_tone():
    import cv2
    original=np.full((20,30,3),[170,135,115],dtype='uint8');styled=np.full_like(original,[130,150,165])
    output=protect_face_colors(original,styled,np.ones((20,30),np.float32))
    lab=lambda p:cv2.cvtColor(p.astype(np.float32)/255,cv2.COLOR_RGB2LAB)
    a,b,c=map(lab,(original,styled,output))
    assert np.linalg.norm(c[:,:,1:]-a[:,:,1:])<np.linalg.norm(b[:,:,1:]-a[:,:,1:])*.5
    assert np.abs(c[:,:,0]-b[:,:,0]).mean()<.5


def test_tiled_mask_resize_matches_full_resolution_sampling():
    import cv2
    mask=np.random.default_rng(3).random((60,90),dtype=np.float32)
    pieces=[resized_mask_tile(mask,270,180,y,min(40,180-y)) for y in range(0,180,40)]
    tiled=np.concatenate(pieces)
    full=cv2.resize(mask,(270,180),interpolation=cv2.INTER_LINEAR)
    assert np.abs(tiled-full).mean()<.004


def test_preview_reuses_recognition_and_jpeg_export_is_a_new_copy(tmp_path,monkeypatch):
    source=tmp_path/'source.jpg';Image.fromarray(blank()).save(source)
    style=builtin_styles()[0];before=hashlib.sha256(source.read_bytes()).hexdigest()
    preview=render_preview(source,style,recognition=True)
    assert preview['recognition'] is True and preview['scene'] is not None
    analyze=scene_analysis.analyze_scene
    monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *a,**kw:pytest.fail('Recognized a cached photograph again'))
    repeated=render_preview(source,style,.5,base=preview,recognition=True)
    assert repeated['scene'] is preview['scene']
    monkeypatch.setattr(scene_analysis,'analyze_scene',analyze)
    output=tmp_path/'copy.jpg';export_jpeg(source,output,style,recognition=True)
    with Image.open(output) as image:
        assert image.size==(180,120) and hashlib.sha256(source.read_bytes()).hexdigest()==before
    assert render_preview(source,style,0,recognition=True)['rendered'].tobytes()==preview['original'].tobytes()


def test_face_protection_keeps_monochrome_and_style_saturation():
    import cv2
    original=np.full((20,30,3),[180,130,100],dtype='uint8');styled=np.full_like(original,120)
    output=protect_face_colors(original,styled,np.ones((20,30),np.float32))
    assert np.max(output.max(axis=2)-output.min(axis=2))<=1
    tinted=np.full_like(original,[130,150,165]);protected=protect_face_colors(original,tinted,np.ones((20,30),np.float32))
    lab=lambda p:cv2.cvtColor(p.astype(np.float32)/255,cv2.COLOR_RGB2LAB)
    assert abs(np.linalg.norm(lab(protected)[0,0,1:])-np.linalg.norm(lab(tinted)[0,0,1:]))<.6


def test_hybrid_region_replaces_only_its_own_component_effect():
    from personal_color_lab.core.style_dna import blend_styles
    from personal_color_lab.core.style_render import _effective,_measure,_tile,apply_pixels
    pixels=blank();first=identity_dna()
    recipe={'sample_count':1,'evidence':'observed_transform','target':None,'tone_curve':np.clip(np.linspace(0,1,33)+.1,0,1).tolist(),'saturation_scale':1.,'lab_shift':[0,0]}
    first['semantic_profile']={'bundle_id':'a'*64,'regions':{'food':recipe},'contexts':{}}
    second=identity_dna();second['lab_shift']=[6,-4]
    hybrid=blend_styles([first,second],[.25,.75]);effective=_effective(hybrid,_measure(pixels))
    global_pixels=apply_pixels(pixels,effective)[0]
    rendered=_render_regions(pixels,effective,hybrid,1.,scene_mask(),1.,False,None)
    local=identity_dna();local['tone_curve']=recipe['tone_curve']
    delta=(_tile(pixels,local,1.,0).astype(float)-pixels.astype(float))*.25
    expected=np.rint(np.clip(global_pixels.astype(float)+delta,0,255)).astype('uint8')
    assert np.max(np.abs(rendered[:,:70].astype(int)-expected[:,:70].astype(int)))<=1
    assert np.array_equal(rendered[:,100:],global_pixels[:,100:])
