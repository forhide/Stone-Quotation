"""Bounded local contrast, texture and detail effects on a non-destructive copy.

Clarity/texture use the same relative Gaussian bands as observed analysis.
Sharpening and noise reduction are edge-aware approximations, not Adobe pixel
reproduction. Every native filter works on a bounded tile with a real halo.
"""
import copy
import math
import cv2
import numpy as np
from .analysis_control import check_cancel
from .detail_recipe import neutral_detail_profile,validate_detail_profile

LUMA=np.array([.2126,.7152,.0722],np.float32)
_EFFECTS=('clarity','texture','sharpening','denoise_luma','denoise_color')
_TILE=384


def detail_is_neutral(profile):
    return not any(profile['controls'][key] for key in _EFFECTS)


def adapt_detail_target(profile,measurement,reference_target=None):
    """Match final appearance weakly; never infer native sharpening/noise."""
    result=copy.deepcopy(profile);target=profile['target']
    observed=measurement.get('detail') or {}
    if target is None:return result
    if observed.get('edge_fraction',0)<.005 or observed.get('flat_fraction',1)>.98:return result
    source_span=max(.05,measurement['quantiles'][-1]-measurement['quantiles'][0])
    target_span=max(.05,reference_target['quantiles'][-1]-reference_target['quantiles'][0]) if reference_target else source_span
    for control,metric,gain in [('clarity','local_contrast',.45),('texture','texture_energy',.30)]:
        current=observed.get(metric)
        if not isinstance(current,(int,float)) or current<.001:continue
        ratio=(target[metric]/target_span)/(current/source_span)
        support=profile['support'][control]['confidence']
        delta=float(np.clip((ratio-1)/gain,-.4,.4))*min(.35,support)
        result['controls'][control]=float(np.clip(result['controls'][control]+delta,-1,1))
    return validate_detail_profile(result)


def _edge_weight(y,sigma,threshold):
    smooth=cv2.GaussianBlur(y,(0,0),max(.35,sigma),borderType=cv2.BORDER_REFLECT_101)
    gx=cv2.Sobel(smooth,cv2.CV_32F,1,0,ksize=3)/8
    gy=cv2.Sobel(smooth,cv2.CV_32F,0,1,ksize=3)/8
    gradient=cv2.magnitude(gx,gy)
    return np.clip(gradient/max(.0005,threshold),0,1)


def _field_tile(field,width,height,left,top,tile_width,tile_height):
    if field.shape==(height,width):return field[top:top+tile_height,left:left+tile_width]
    x=(np.arange(left,left+tile_width,dtype=np.float32)+.5)*field.shape[1]/width-.5
    y=(np.arange(top,top+tile_height,dtype=np.float32)+.5)*field.shape[0]/height-.5
    return cv2.remap(field,np.broadcast_to(x,(tile_height,tile_width)).copy(),np.broadcast_to(y[:,None],(tile_height,tile_width)).copy(),cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)


def apply_details(pixels,profile=None,strength=1.,cancel_event=None):
    """Return uint8 RGB, preserving source bytes and tile-boundary continuity."""
    profile=validate_detail_profile(profile if profile is not None else neutral_detail_profile())
    if not isinstance(pixels,np.ndarray) or pixels.dtype!=np.uint8 or pixels.ndim!=3 or pixels.shape[2]!=3 or min(pixels.shape[:2])<1:raise ValueError('Invalid detail source RGB.')
    if isinstance(strength,bool) or not isinstance(strength,(float,int)) or not math.isfinite(strength) or not 0<=strength<=1:raise ValueError('Invalid detail strength.')
    check_cancel(cancel_event)
    if not strength or detail_is_neutral(profile):return pixels.copy()
    controls=profile['controls'];height,width=pixels.shape[:2];scale=max(width,height)/1024
    field=None
    if controls['clarity'] or controls['texture']:
        from .detail_analysis import detail_bands
        factor=min(1.,1024/max(width,height));size=(max(1,round(width*factor)),max(1,round(height*factor)))
        anchor=pixels if size==(width,height) else cv2.resize(pixels,size,interpolation=cv2.INTER_AREA)
        _,medium,coarse=detail_bands((anchor.astype(np.float32)/255)@LUMA)
        field=coarse*(controls['clarity']*.45)+medium*(controls['texture']*.30)
        check_cancel(cancel_event)
    sigma=min(24.,max(.35,controls['sharp_radius']*scale))
    noise_sigma=min(24.,max(.8,scale))
    # Estimate structural edges at a smoother scale than individual noise.
    # Otherwise noisy flat areas protect themselves from noise reduction.
    noise_edge_sigma=min(24.,max(1.,noise_sigma*1.5))
    native=bool(controls['sharpening'] or controls['denoise_luma'] or controls['denoise_color'])
    # The filters are sequential: chroma -> luma -> sharpening. Their
    # supports add; a halo of just the largest radius leaves visible seams
    # when noise reduction and sharpening are enabled together.
    support=(noise_edge_sigma if controls['denoise_color'] else 0)+(noise_edge_sigma if controls['denoise_luma'] else 0)+(sigma if controls['sharpening'] else 0)
    halo=math.ceil(4*support)+3 if native else 0
    result=np.empty_like(pixels)
    for top in range(0,height,_TILE):
        for left in range(0,width,_TILE):
            check_cancel(cancel_event)
            bottom=min(height,top+_TILE);right=min(width,left+_TILE)
            y0=max(0,top-halo);y1=min(height,bottom+halo);x0=max(0,left-halo);x1=min(width,right+halo)
            rgb=pixels[y0:y1,x0:x1].astype(np.float32)/255.
            y=rgb@LUMA
            if controls['denoise_color']:
                lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB)
                flat=1-_edge_weight(y,noise_edge_sigma,.025)
                amount=controls['denoise_color']*strength*.85*flat
                for channel in (1,2):
                    smooth=cv2.GaussianBlur(lab[:,:,channel],(0,0),noise_sigma,borderType=cv2.BORDER_REFLECT_101)
                    lab[:,:,channel]+=amount*(smooth-lab[:,:,channel])
                rgb=cv2.cvtColor(lab,cv2.COLOR_LAB2RGB);y=rgb@LUMA
            delta=np.zeros_like(y)
            if controls['denoise_luma']:
                smooth=cv2.GaussianBlur(y,(0,0),noise_sigma,borderType=cv2.BORDER_REFLECT_101)
                flat=1-_edge_weight(y,noise_edge_sigma,.025)
                delta+=(smooth-y)*flat*controls['denoise_luma']*.85
            if controls['sharpening']:
                base=np.clip(y+delta,0,1)
                smooth=cv2.GaussianBlur(base,(0,0),sigma,borderType=cv2.BORDER_REFLECT_101)
                mask=_edge_weight(base,max(.35,sigma*.5),.002+controls['sharp_mask']*.04) if controls['sharp_mask'] else 1.
                # Bound overshoot to avoid turning sensor/JPEG extremes into halos.
                residual=np.clip(base-smooth,-.08,.08)
                delta+=residual*mask*controls['sharpening']*.35
            cy=slice(top-y0,bottom-y0);cx=slice(left-x0,right-x0)
            rgb=rgb[cy,cx];y=y[cy,cx];delta=delta[cy,cx]
            if field is not None:delta=delta+_field_tile(field,width,height,left,top,right-left,bottom-top)
            desired=np.clip(y+delta*strength,0,1)
            ratio=np.divide(desired,y,out=np.ones_like(y),where=y>.0001)
            corrected=rgb*ratio[:,:,None]+np.maximum(desired-y*ratio,0)[:,:,None]
            result[top:bottom,left:right]=np.rint(np.clip(corrected,0,1)*255).astype('uint8')
    check_cancel(cancel_event)
    return result


_DETAIL_XMP={'Clarity2012':'clarity','Clarity':'clarity','Texture':'texture','Sharpness':'sharpening','SharpenRadius':'sharp_radius','SharpenEdgeMasking':'sharp_mask','LuminanceSmoothing':'denoise_luma','ColorNoiseReduction':'denoise_color'}
_COLOR_XMP={'Exposure2012','Contrast2012','Saturation','Vibrance','Temperature','Tint','Shadows2012','Highlights2012','Whites2012','Blacks2012','GrainAmount'}
_COLOR_XMP.update(prefix+band.title() for prefix in ('HueAdjustment','SaturationAdjustment','LuminanceAdjustment') for band in ('red','orange','yellow','green','aqua','blue','purple','magenta'))
_COLOR_XMP.update('ColorGrade'+zone+suffix for zone in ('Shadow','Midtone','Highlight') for suffix in ('Hue','Sat'))
_COLOR_XMP.update('SplitToning'+zone+suffix for zone in ('Shadow','Highlight') for suffix in ('Hue','Saturation'))
# All remaining numeric photographic controls are recorded/XMP-only. Never
# pass through crop, geometry or fabricated camera/lens settings.
_GEOMETRY_WORDS=('Crop','Lens','Distortion','Perspective','Upright','Defringe')


def parameter_support(effective):
    recorded=effective.get('recorded_parameters',{})
    profile=effective.get('detail_profile',neutral_detail_profile())
    applied=[];xmp_only=[]
    for name in recorded:
        if name in _COLOR_XMP or name in _DETAIL_XMP and profile['support'][_DETAIL_XMP[name]]['basis']!='unavailable':applied.append(name)
        elif not any(word in name for word in _GEOMETRY_WORDS):xmp_only.append(name)
    return {'schema_version':1,'pixel_applied':sorted(applied),'xmp_only':sorted(xmp_only),'approximate_renderer':True}


def detail_xmp_attributes(effective,strength,*,allow_recorded_only=False):
    profile=effective.get('detail_profile',neutral_detail_profile());controls=profile['controls'];attrs={}
    mapping={'clarity':('Clarity2012',100),'texture':('Texture',100),'sharpening':('Sharpness',100),'sharp_radius':('SharpenRadius',1),'sharp_mask':('SharpenEdgeMasking',100),'denoise_luma':('LuminanceSmoothing',100),'denoise_color':('ColorNoiseReduction',100)}
    for name,(key,scale) in mapping.items():
        if profile['support'][name]['basis']=='unavailable':continue
        value=controls[name]*scale*(1 if name in ('sharp_radius','sharp_mask') else strength)
        attrs[key]=f'{value:.4f}' if name=='sharp_radius' else str(round(value))
    if allow_recorded_only:
        from .xmp_analysis import _NUMERIC
        for name in parameter_support(effective)['xmp_only']:
            if name in _NUMERIC and not name.startswith('Crop'):
                value=effective['recorded_parameters'][name]
                # Shape/detail selectors retain their units; strengths scale.
                shaped=name in {'GrainSize','GrainFrequency','ParametricShadowSplit','ParametricMidtoneSplit','ParametricHighlightSplit','LuminanceNoiseReductionDetail','LuminanceNoiseReductionContrast','ColorNoiseReductionDetail','ColorNoiseReductionSmoothness','SharpenDetail'}
                value=value if shaped else value*strength
                attrs[name]=str(round(value)) if _NUMERIC[name][2] else f'{value:.4f}'
    return attrs
