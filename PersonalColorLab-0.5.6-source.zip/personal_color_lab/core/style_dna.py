"""One bounded style representation for measured, reference and built-in looks.

DNA is an application recipe, not proof of recovered Lightroom sliders. A
reference target adapts to the new image's measured lighting distribution.
"""
from __future__ import annotations

import copy
import json
import math
from statistics import median
import numpy as np

ENGINE_VERSION = '0.5.6'
BANDS = ('red', 'orange', 'yellow', 'green', 'aqua', 'blue', 'purple', 'magenta')
ZONES = ('shadows', 'midtones', 'highlights')
GRID = np.linspace(0, 1, 33)


def identity_dna(name='Neutral', kind='builtin', category='film'):
    from .scene_styles import empty_scene_profile
    from .detail_recipe import neutral_detail_profile
    return {'schema_version': 4, 'engine_version': ENGINE_VERSION, 'name': name,
            'kind': kind, 'category': category, 'tone_curve': GRID.tolist(),
            'channel_curves': {c: GRID.tolist() for c in ('red', 'green', 'blue')},
            'exposure_ev': 0.0, 'saturation_scale': 1.0, 'vibrance': 0.0,
            'lab_shift': [0.0, 0.0], 'zone_shifts': {z: [0.0, 0.0] for z in ZONES},
            'hsl': {b: {'hue': 0.0, 'saturation': 0.0, 'lightness': 0.0} for b in BANDS},
            'grain_amount': 0.0, 'reference_target': None, 'scene_targets': {},
            'composition': {'aspect_ratio': None}, 'recorded_parameters': {},
            'semantic_profile': {'bundle_id':None,'regions':{},'contexts':{}},
            'scene_profile': empty_scene_profile(),
            'detail_profile': neutral_detail_profile(),
            'components': [], 'warnings': [], 'sample_count': 0, 'confidence': 1.0}


def _number(value, low, high):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and low <= value <= high


def _target_valid(target):
    return (isinstance(target, dict) and set(target) == {'quantiles', 'saturation', 'zones'}
            and isinstance(target['quantiles'], list) and len(target['quantiles']) == 5
            and all(_number(x, 0, 1) for x in target['quantiles'])
            and target['quantiles'] == sorted(target['quantiles'])
            and _number(target['saturation'], 0, 1)
            and isinstance(target['zones'], dict) and set(target['zones']) <= set(ZONES)
            and all(isinstance(x, list) and len(x) == 2 and all(_number(v, -128, 128) for v in x) for x in target['zones'].values()))


def _validate_dna(dna, _depth=0):
    if _depth > 3 or not isinstance(dna, dict) or set(dna) != set(identity_dna()):
        raise ValueError('Invalid style schema or unsupported fields.')
    if type(dna['schema_version']) is not int or dna['schema_version'] != 4 or dna['engine_version'] != ENGINE_VERSION:
        raise ValueError('Unsupported style version.')
    if not isinstance(dna['name'], str) or not 1 <= len(dna['name'].strip()) <= 120:
        raise ValueError('A style needs a name of 1–120 characters.')
    if dna['kind'] not in {'builtin', 'reference', 'transform', 'recorded_xmp', 'hybrid'} or dna['category'] not in {'film', 'cinema', 'artist', 'my_style', 'reference', 'hybrid'}:
        raise ValueError('Unsupported style source/category.')
    curve = dna['tone_curve']
    if not isinstance(curve, list) or len(curve) != 33 or not all(_number(v, 0, 1) for v in curve) or curve != sorted(curve):
        raise ValueError('Style tone curve must be finite and monotone.')
    if not isinstance(dna['channel_curves'], dict) or set(dna['channel_curves']) != {'red','green','blue'}:
        raise ValueError('Invalid RGB curves.')
    for curve in dna['channel_curves'].values():
        if not isinstance(curve,list) or len(curve)!=33 or not all(_number(v,0,1) for v in curve) or curve!=sorted(curve):
            raise ValueError('Invalid RGB curve values.')
    for name, low, high in (('exposure_ev', -3, 3), ('saturation_scale', 0, 2), ('vibrance', -1, 1), ('grain_amount', 0, .04), ('confidence', 0, 1)):
        if not _number(dna[name], low, high):
            raise ValueError('Style control is outside its supported range.')
    for shift in [dna['lab_shift'], *dna['zone_shifts'].values()]:
        if not isinstance(shift, list) or len(shift) != 2 or not all(_number(v, -12, 12) for v in shift):
            raise ValueError('Invalid style color shift.')
    if set(dna['zone_shifts']) != set(ZONES) or set(dna['hsl']) != set(BANDS):
        raise ValueError('Invalid style color zones.')
    for values in dna['hsl'].values():
        if not isinstance(values, dict) or set(values) != {'hue', 'saturation', 'lightness'} or not _number(values['hue'], -45, 45) or not _number(values['saturation'], -1, 1) or not _number(values['lightness'], -.3, .3):
            raise ValueError('Invalid hue-band style control.')
    if dna['reference_target'] is not None and not _target_valid(dna['reference_target']):
        raise ValueError('Invalid reference appearance target.')
    if not isinstance(dna['scene_targets'], dict) or set(dna['scene_targets']) - {'low_key', 'mid_key', 'high_key'} or not all(_target_valid(v) for v in dna['scene_targets'].values()):
        raise ValueError('Invalid measured-lighting style targets.')
    ratio = dna['composition'].get('aspect_ratio') if isinstance(dna['composition'], dict) else False
    if not isinstance(dna['composition'], dict) or set(dna['composition']) != {'aspect_ratio'} or ratio is not None and not _number(ratio, .5, 3):
        raise ValueError('Invalid composition suggestion.')
    from .xmp_analysis import _NUMERIC
    if not isinstance(dna['recorded_parameters'], dict):
        raise ValueError('Invalid recorded controls.')
    for key, value in dna['recorded_parameters'].items():
        if key not in _NUMERIC or key.startswith('Crop') or not _number(value, *_NUMERIC[key][:2]):
            raise ValueError('Unsupported recorded style control.')
    if type(dna['sample_count']) is not int or dna['sample_count'] < 0 or not isinstance(dna['warnings'], list) or len(dna['warnings']) > 40 or any(not isinstance(w, str) or len(w) > 100 for w in dna['warnings']):
        raise ValueError('Invalid style provenance.')
    if not isinstance(dna['components'], list) or len(dna['components']) > 8:
        raise ValueError('Invalid style blend.')
    for component in dna['components']:
        if not isinstance(component, dict) or set(component) != {'weight', 'dna'} or not _number(component['weight'], 0, 1):
            raise ValueError('Invalid blend weight.')
        validate_dna(component['dna'], _depth + 1)
    if dna['kind'] == 'hybrid' and (not dna['components'] or not math.isclose(sum(c['weight'] for c in dna['components']), 1)):
        raise ValueError('Hybrid weights must sum to one.')
    if dna['kind'] != 'hybrid' and dna['components']:
        raise ValueError('Only hybrid styles may contain components.')
    from .style_regions import validate_profile
    validate_profile(dna['semantic_profile'],_target_valid,_number)
    from .scene_styles import validate_scene_profile
    validate_scene_profile(dna['scene_profile'],_target_valid,_number)
    from .detail_recipe import validate_detail_profile
    validate_detail_profile(dna['detail_profile'])
    json.dumps(dna, allow_nan=False)
    return dna


def validate_dna(dna, _depth=0):
    try:
        if isinstance(dna,dict) and type(dna.get('schema_version')) is int and (
                dna['schema_version'],dna.get('engine_version')) in {(1,'0.4.0'),(2,'0.5.0'),(3,'0.5.5')}:
            legacy=dna['schema_version']
            missing={'detail_profile'}|({'scene_profile'} if legacy<3 else set())|({'semantic_profile'} if legacy==1 else set())
            if set(dna)!=set(identity_dna())-missing:raise ValueError('Invalid legacy style schema')
            from .scene_styles import empty_scene_profile, upgrade_scene_profile
            from .detail_recipe import neutral_detail_profile
            dna=copy.deepcopy(dna);dna.update(schema_version=4,engine_version=ENGINE_VERSION,detail_profile=neutral_detail_profile())
            dna['scene_profile']=(empty_scene_profile() if legacy<3 else upgrade_scene_profile(dna['scene_profile'],_target_valid,_number))
            if legacy==1:dna['semantic_profile']={'bundle_id':None,'regions':{},'contexts':{}}
            dna['components']=[{'weight':c['weight'],'dna':validate_dna(c['dna'],_depth+1)} for c in dna['components']]
        return _validate_dna(dna, _depth)
    except (TypeError, KeyError, AttributeError, RecursionError) as exc:
        raise ValueError('Invalid style data.') from exc


def _clip(value, low, high):
    return float(np.clip(value, low, high)) if _number(value, -1e8, 1e8) else 0.0


def _appearance_target(appearance):
    q = appearance['luminance']['quantiles']
    return {'quantiles': [float(q[k]) for k in ('p05', 'p25', 'p50', 'p75', 'p95')],
            'saturation': float(appearance['saturation']['mean']),
            'zones': {z: [v['mean_a'], v['mean_b']] for z, v in appearance['tonal_zones'].items()
                      if v.get('support_fraction', 0) > .02 and v.get('mean_a') is not None and v.get('mean_b') is not None}}


def _reference_monochrome(payload):
    appearance=payload.get('appearance',{})
    saturation=appearance.get('saturation',{}).get('mean')
    chroma=appearance.get('chroma',{}).get('quantiles',{}).get('p95')
    pixels=payload.get('provenance',{}).get('pixel_count')
    return (type(pixels) is int and pixels>=256 and _number(saturation,0,.008)
            and _number(chroma,0,1.5))


def _pair_monochrome(payload):
    evidence=payload.get('color',{}).get('achromatic_evidence',{})
    return (type(evidence.get('sample_count')) is int and evidence['sample_count']>=256
            and _number(evidence.get('original_chromatic_fraction'),.05,1)
            and _number(evidence.get('edited_achromatic_fraction'),.99,1))


def _observed_curve(payload):
    tone=payload.get('tone', {})
    from .tone_analysis import validate_global_tone_evidence
    joint_curve=validate_global_tone_evidence(tone)
    points = joint_curve if joint_curve is not None else tone.get('tone_transfer', [])
    points = [(p.get('input'), p.get('output')) for p in points if _number(p.get('input'), 0, 1) and _number(p.get('output'), 0, 1)]
    if len(points) < 2:
        return None
    points = sorted(points)
    return np.maximum.accumulate(np.interp(GRID, [0, *[p[0] for p in points], 1], [0, *[p[1] for p in points], 1])).tolist()


def _dna_from_batch_global(batch, name):
    payloads = [r['payload'] for r in batch.get('results', []) if r.get('status') == 'ok' and isinstance(r.get('payload'), dict)]
    if not payloads:
        raise ValueError('No valid source evidence is available for a style.')
    mode = batch.get('mode')
    dna = identity_dna(name, 'reference' if mode == 'reference_jpg' else 'recorded_xmp' if mode == 'raw_xmp' else 'transform',
                       'reference' if mode == 'reference_jpg' else 'my_style')
    dna['sample_count'] = len(payloads)
    dna['confidence'] = _clip(median(p.get('confidence', 0) for p in payloads), 0, 1)
    dna['warnings'] = ['style_application_approximate']
    if mode == 'reference_jpg':
        from .reference_analysis import aggregate_references
        summary = aggregate_references(payloads)
        if summary['status'] != 'ok':
            raise ValueError('Reference measurements are unavailable.')
        dna['reference_target'] = _appearance_target(summary['appearance'])
        dna['sample_count'] = summary['sample_count']
        dna['confidence'] = summary['confidence']
        # The median of a mixed dataset may be gray. Only unanimous supported
        # appearance evidence enables a global monochrome recipe.
        if all(_reference_monochrome(p) for p in payloads):
            dna['saturation_scale']=0.0
        dna['warnings'].extend(['reference_content_and_lighting_confounders'])
        if summary['sample_count'] < 5:
            dna['warnings'].append('reference_low_coverage')
        for key in ('low_key', 'mid_key', 'high_key'):
            subset = [p for p in payloads if lighting_key(p['appearance']['luminance']['quantiles']['p50']) == key]
            if len(subset) >= 3:
                group=aggregate_references(subset)
                if group['sample_count']>=3:
                    dna['scene_targets'][key] = _appearance_target(group['appearance'])
    elif mode == 'raw_xmp':
        # Rebuilding a reviewed scene subset must use its own observed settings,
        # never the original batch's global medians.
        controls = _xmp_controls(payloads)
        from .xmp_analysis import _NUMERIC
        params = {key: value['median'] for key, value in controls.items() if key in _NUMERIC and not key.startswith('Crop') and isinstance(value, dict) and _number(value.get('median'), *_NUMERIC[key][:2])}
        dna['recorded_parameters'] = params
        dna['exposure_ev'] = _clip(params.get('Exposure2012', params.get('Exposure', 0)), -3, 3)
        contrast = params.get('Contrast2012', params.get('Contrast', 0)) / 100
        curve = np.clip(GRID + contrast * (GRID - .5) * 4 * GRID * (1 - GRID) * .35, 0, 1)
        curve += params.get('Shadows2012', 0) / 100 * .12 * (1 - GRID)**2 * GRID
        curve += params.get('Highlights2012', 0) / 100 * .12 * GRID**2 * (1 - GRID)
        curve += params.get('Blacks2012', 0) / 100 * .035 * (1 - GRID)**3
        curve += params.get('Whites2012', 0) / 100 * .035 * GRID**3
        curves = []
        for p in payloads:
            points = p.get('tone_curves', {}).get('ToneCurvePV2012', p.get('tone_curves', {}).get('ToneCurve'))
            if points:
                curves.append(np.interp(GRID, np.array(points)[:, 0]/255, np.array(points)[:, 1]/255))
        if curves:
            curve = np.interp(curve, GRID, np.median(curves, axis=0))
        dna['tone_curve'] = np.maximum.accumulate(np.clip(curve, 0, 1)).tolist()
        for channel in ('red','green','blue'):
            curves=[]
            for p in payloads:
                points=p.get('tone_curves',{}).get('ToneCurvePV2012'+channel.title(),p.get('tone_curves',{}).get('ToneCurve'+channel.title()))
                if points:
                    curves.append(np.interp(GRID,np.array(points)[:,0]/255,np.array(points)[:,1]/255))
            if curves:
                dna['channel_curves'][channel]=np.maximum.accumulate(np.median(curves,axis=0)).tolist()
        dna['saturation_scale'] = _clip(1 + params.get('Saturation', 0)/100, 0, 2)
        monochrome=all(p.get('parameters',{}).get('ConvertToGrayscale') is True for p in payloads)
        if monochrome:dna['saturation_scale']=0.0
        dna['vibrance'] = _clip(params.get('Vibrance', 0)/100, -1, 1)
        if 'Temperature' in params:
            dna['lab_shift'][1] = _clip(math.log(params['Temperature']/6500) * 8, -6, 6)
        dna['lab_shift'][0] = _clip(params.get('Tint', 0)/20, -6, 6)
        if monochrome:dna['lab_shift']=[0.0,0.0]
        for band in BANDS:
            suffix = band.title()
            dna['hsl'][band] = {'hue': _clip(params.get('HueAdjustment'+suffix, 0)*.3, -45, 45),
                'saturation': _clip(params.get('SaturationAdjustment'+suffix, 0)/100, -1, 1),
                'lightness': _clip(params.get('LuminanceAdjustment'+suffix, 0)/500, -.3, .3)}
        for zone, label in (('shadows', 'Shadow'), ('midtones', 'Midtone'), ('highlights', 'Highlight')):
            hue = params.get('ColorGrade'+label+'Hue', params.get('SplitToning'+label+'Hue', 0))
            saturation = params.get('ColorGrade'+label+'Sat', params.get('SplitToning'+label+'Saturation', 0))
            dna['zone_shifts'][zone] = [math.cos(math.radians(hue))*saturation*.08, math.sin(math.radians(hue))*saturation*.08]
        dna['grain_amount'] = _clip(params.get('GrainAmount', 0)*.0002, 0, .04)
        dna['warnings'].append('xmp_render_equivalence_unverified')
    else:
        curves = [c for p in payloads if (c := _observed_curve(p)) is not None]
        if curves:
            dna['tone_curve'] = np.median(curves, axis=0).tolist()
        else:
            dna['exposure_ev'] = _clip(median(p.get('tone', {}).get('estimated_exposure_ev') or 0 for p in payloads), -3, 3)
        for index, key in enumerate(('delta_a', 'delta_b')):
            dna['lab_shift'][index] = _clip(median((p.get('residual_color') or p.get('color', {})).get('lab', {}).get(key) or 0 for p in payloads), -8, 8)
        saturation_models = [(p.get('residual_color') or p.get('color', {})).get('saturation_model', {}) for p in payloads]
        gains = [model['gain'] for model in saturation_models
                 if model.get('status') == 'ok' and _number(model.get('gain'), 0, 2)
                 and _number(model.get('confidence'), .35, 1)]
        vibrances = [model['vibrance'] for model in saturation_models
                     if model.get('status') == 'ok' and _number(model.get('vibrance'), -1, 1)
                     and _number(model.get('gain'), 0, 2) and _number(model.get('confidence'), .35, 1)
                     and _number(model.get('vibrance_confidence'), .35, 1)]
        dna['saturation_scale'] = (_clip(median(gains), 0, 2) if gains else
            _clip(1 + median((p.get('residual_color') or p.get('color', {})).get('hsv', {}).get('saturation_delta') or 0 for p in payloads)*1.5, .3, 1.8))
        if gains and vibrances:
            dna['vibrance'] = _clip(median(vibrances), -1, 1)
        for band in BANDS:
            values=[]
            for p in payloads:
                color=p.get('residual_color') or p.get('color',{})
                value=dict(color.get('hue_bands',{}).get(band,{}))
                if not p.get('residual_color') and value.get('lightness_delta') is not None:
                    value['lightness_delta']-=color.get('hsl',{}).get('lightness_delta') or 0
                model=color.get('saturation_model',{})
                if (model.get('status')=='ok' and _number(model.get('gain'),0,2)
                        and _number(model.get('confidence'),.35,1)):
                    # A global gain/vibrance already explains this portion of
                    # the change. Only a supported remainder belongs to HSL.
                    value['_saturation_control']=(value.get('saturation_residual')
                        if _number(value.get('saturation_residual'),-1,1)
                        and _number(value.get('saturation_residual_confidence'),.35,1) else 0)
                else:
                    value['_saturation_control']=value.get('saturation_delta')
                values.append(value)
            supported = [v for v in values if v.get('confidence', 0) >= .35]
            if supported:
                dna['hsl'][band] = {'hue': _clip(median(v.get('hue_delta_degrees') or 0 for v in supported), -30, 30),
                    'saturation': _clip(median(v.get('_saturation_control') or 0 for v in supported), -.6, .6),
                    'lightness': _clip(median(v.get('lightness_delta') or 0 for v in supported), -.15, .15)}
        dna['warnings'].append('inferred_transform')
        if all(_pair_monochrome(p) for p in payloads):
            dna['saturation_scale']=0.0
            dna['lab_shift']=[0.0,0.0]
        aspects=[]
        for p in payloads:
            edited=p.get('alignment',{}).get('edited_size',[])
            original=p.get('alignment',{}).get('original_size',[])
            if len(edited)==len(original)==2 and all(_number(v,1,1_000_000) for v in [*edited,*original]):
                ratio=edited[0]/edited[1]
                if .5<=ratio<=3 and abs(ratio-original[0]/original[1])>.1:aspects.append(ratio)
        if len(aspects)>=3 and np.std(aspects)<.05:
            dna['composition']['aspect_ratio']=float(median(aspects))
    from .detail_recipe import learn_detail_profile
    dna['detail_profile']=learn_detail_profile(payloads,mode)
    from .style_regions import learn_profile
    dna['semantic_profile']=learn_profile(payloads,mode,_appearance_target)
    if mode=='reference_jpg':
        # Keep context support separate from the global recipe: a supported
        # all-gray food subset can coexist with colorful portrait references.
        for context in dna['semantic_profile']['contexts']:
            subset=[p for p in payloads if p.get('semantic',{}).get('status')=='ok'
                    and p['semantic'].get('bundle_id')==dna['semantic_profile']['bundle_id']
                    and context in p['semantic'].get('scene_tags',[])]
            if subset and all(_reference_monochrome(p) for p in subset):
                dna['warnings'].append('monochrome_context_'+context)
    return validate_dna(dna)


def _xmp_controls(payloads):
    from .xmp_analysis import _NUMERIC
    controls={}
    for key,bounds in _NUMERIC.items():
        if key.startswith('Crop'):continue
        values=[p.get('parameters',{}).get(key) for p in payloads]
        supported=[value for value in values if _number(value,*bounds[:2])]
        if supported:controls[key]={'median':float(median(supported))}
    return controls


def dna_from_batch(batch, name):
    """Build the common recipe and distinct, reviewable whole-photo categories."""
    dna=_dna_from_batch_global(batch,name)
    from .scene_styles import learn_scene_profile
    dna['scene_profile']=learn_scene_profile(batch,_dna_from_batch_global)
    return validate_dna(dna)


def dna_from_pair(payload, name):
    if payload.get('status') != 'ok':
        raise ValueError('A successful comparison is required.')
    return dna_from_batch({'mode': 'jpg_jpg', 'results': [{'status': 'ok', 'payload': payload}]}, name)


def lighting_key(median_luma):
    return 'low_key' if median_luma < .35 else 'high_key' if median_luma > .7 else 'mid_key'


def blend_styles(styles, weights, name='Hybrid'):
    if not styles or len(styles) != len(weights) or len(styles) > 8 or not all(_number(w, 0, 1) for w in weights) or sum(weights) <= 0:
        raise ValueError('A style blend needs positive, matching weights.')
    styles=[validate_dna(style) for style in styles]
    dna = identity_dna(name, 'hybrid', 'hybrid')
    total = sum(weights)
    dna['components'] = [{'weight': w/total, 'dna': copy.deepcopy(style)} for w, style in zip(weights, styles) if w]
    dna['confidence'] = sum(w/total*s['confidence'] for w,s in zip(weights,styles))
    dna['warnings'] = ['style_application_approximate']
    return validate_dna(dna)


def builtin_styles():
    recipes = [
        ('warm_negative','film',.035,.96,.9,[1.0,3.0],[-1,-1],[1,2],.006,None),
        ('soft_pastel','film',.05,.94,.72,[.5,1.5],[0,1],[1,1],.003,None),
        ('vivid_slide','film',0,1,1.18,[0,0],[-1,-2],[0,1],0,None),
        ('silver_mono','film',.015,.99,0,[0,0],[0,0],[0,0],.007,None),
        ('teal_amber','cinema',.018,.97,.92,[0,0],[-3,-5],[3,5],0,2.39),
        ('quiet_cinema','cinema',.04,.96,.68,[1,0],[-1,-3],[2,2],0,1.85),
        ('night_neon','cinema',.01,.98,1.12,[2,-2],[-2,-4],[3,1],0,2.39),
        ('warm_story','cinema',.025,.98,.88,[1,3],[-1,0],[2,4],0,1.85),
        ('luminous','artist',.035,1,.83,[0,2],[0,1],[1,2],0,None),
        ('muted_city','artist',.025,.97,.7,[-1,-1],[-2,-3],[0,1],0,None),
        ('graphic_color','artist',0,1,1.15,[1,0],[0,-1],[1,1],0,None),
        ('soft_portrait','artist',.02,.98,.82,[1,1],[0,0],[1,2],0,None),
    ]
    result = []
    for key,category,black,white,saturation,shift,shadow,highlight,grain,ratio in recipes:
        dna = identity_dna(key, 'builtin', category)
        dna.update(tone_curve=(black+(white-black)*GRID).tolist(), saturation_scale=saturation,
                   lab_shift=shift, grain_amount=grain, composition={'aspect_ratio':ratio})
        dna['zone_shifts'].update(shadows=shadow, highlights=highlight)
        result.append(validate_dna(dna))
    return result


def load_style_file(path):
    from pathlib import Path
    path = Path(path)
    if path.stat().st_size > 2_000_000:
        raise ValueError('Style file is too large.')
    try:
        dna = json.loads(path.read_text(encoding='utf-8'), parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite style value')))
        return validate_dna(dna)
    except (RecursionError, TypeError, KeyError) as exc:
        raise ValueError('Invalid style file.') from exc
