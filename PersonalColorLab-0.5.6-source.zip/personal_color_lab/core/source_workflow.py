"""Discover, analyze and summarize the three local photographic input modes.

Discovery proposes filename relationships; it never treats a filename as proof
of an edit. Ambiguous candidates need the user's selection. Analyses own their
input-content checks, and a failed file does not discard the rest of a batch.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import time
from pathlib import Path
from statistics import median

from .constants import JPEG_EXTENSIONS, RAW_EXTENSIONS, XMP_EXTENSIONS
from .edit_reverse import analyze_pair, file_fingerprint
from .analysis_cache import cache_key, relocate_payload
from .analysis_control import AnalysisCancelledError, check_cancel
from .reference_analysis import analyze_reference, aggregate_references, summarize_detail_evidence
from .scanner import normalized_stem
from .xmp_analysis import analyze_raw_xmp

MODES = ('raw_jpg', 'raw_xmp', 'reference_jpg')
ALGORITHM_VERSION = '0.5.6'


def _mode(mode):
    if mode not in MODES:
        raise ValueError('Unknown source analysis mode.')
    return mode


def _stem(path):
    # Lightroom also writes DSC0001.NEF.xmp sidecars.
    if path.suffix.lower() == '.xmp' and Path(path.stem).suffix.lower() in RAW_EXTENSIONS:
        path = Path(path.stem)
    return normalized_stem(path).casefold()


def _item(mode, original, edited=None, status='ready', reason='filename_match', candidates=None):
    identity = f'{mode}\0{original}\0{edited or ""}'
    return {
        'id': hashlib.sha256(identity.encode('utf-8')).hexdigest()[:20],
        'source_type': mode, 'original_path': str(original),
        'edited_path': str(edited) if edited else None,
        'status': status, 'reason': reason,
        'candidates': [str(path) for path in (candidates or [])],
        'scene_override': None,
    }


def discover_inputs(folder, mode, recursive=True):
    """Return ready, ambiguous and unmatched rows without decoding images."""
    _mode(mode)
    folder = Path(folder).expanduser().resolve(strict=True)
    if not folder.is_dir():
        raise ValueError('Choose an existing folder.')
    extensions = RAW_EXTENSIONS | JPEG_EXTENSIONS | XMP_EXTENSIONS
    iterator = folder.rglob('*') if recursive else folder.glob('*')
    paths = sorted({p.resolve() for p in iterator if p.is_file() and p.suffix.lower() in extensions},
                   key=lambda p: (str(p).casefold(), str(p)))
    raws = [p for p in paths if p.suffix.lower() in RAW_EXTENSIONS]
    jpgs = [p for p in paths if p.suffix.lower() in JPEG_EXTENSIONS]
    xmps = [p for p in paths if p.suffix.lower() in XMP_EXTENSIONS]
    counts = {'total_files': len(paths), 'raw': len(raws), 'jpg': len(jpgs), 'xmp': len(xmps)}
    if mode == 'reference_jpg':
        items = [_item(mode, p, reason='reference_photo') for p in jpgs]
    else:
        targets = jpgs if mode == 'raw_jpg' else xmps
        by_name = defaultdict(list)
        for target in targets:
            by_name[_stem(target)].append(target)
        proposed = {}
        reverse = defaultdict(list)
        for raw in raws:
            candidates = by_name.get(_stem(raw), [])
            local = [p for p in candidates if p.parent == raw.parent]
            proposed[raw] = local or candidates
            for target in proposed[raw]:
                reverse[target].append(raw)
        items, referenced = [], set()
        for raw in raws:
            candidates = proposed[raw]
            referenced.update(candidates)
            if len(candidates) == 1 and len(reverse[candidates[0]]) == 1:
                items.append(_item(mode, raw, candidates[0]))
            elif candidates:
                items.append(_item(mode, raw, status='ambiguous', reason='multiple_matches', candidates=candidates))
            else:
                items.append(_item(mode, raw, status='unmatched', reason='missing_edited'))
        for target in targets:
            if target not in referenced:
                items.append(_item(mode, target, status='unmatched', reason='missing_raw'))
    for state in ('ready', 'ambiguous', 'unmatched'):
        counts[state] = sum(row['status'] == state for row in items)
    return {'mode': mode, 'folder': str(folder), 'items': items, 'counts': counts}


def _finite_median(values):
    values = [float(v) for v in values if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)]
    return float(median(values)) if values else None


def _independent_transform_payloads(payloads):
    """Keep one edit per original, excluding ambiguous edits of the same photo."""
    groups = defaultdict(list)
    unknown = []
    for payload in payloads:
        fingerprint = payload.get('provenance', {}).get('input_fingerprints', {}).get('original')
        if isinstance(fingerprint, str) and len(fingerprint) == 64:
            groups[fingerprint].append(payload)
        else:
            # Legacy summaries without identity still retain their observed
            # values; they cannot establish independent category support.
            unknown.append(payload)
    eligible, conflicts, duplicates = [], 0, 0
    for group in groups.values():
        edited = {payload.get('provenance', {}).get('input_fingerprints', {}).get('edited')
                  for payload in group} - {None}
        if len(edited) > 1:
            conflicts += len(group)
        else:
            eligible.append(group[0])
            duplicates += len(group) - 1
    return eligible + unknown, {'input_count': len(payloads),
                               'excluded_edit_conflict_count': conflicts,
                               'duplicate_count': duplicates,
                               'unverified_identity_count': len(unknown)}


def _observed_stat(values, count, *, circular=False):
    supported = [(float(value), float(confidence)) for value, confidence in values
                 if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
                 and isinstance(confidence, (int, float)) and not isinstance(confidence, bool)
                 and math.isfinite(confidence) and 0 <= confidence <= 1]
    median_value = _finite_median(value for value, _ in supported)
    if circular and supported:
        angles = [value for value, _ in supported]
        # A circular median keeps red shifts near +180/-180 together.
        median_value = min(angles, key=lambda candidate: sum(
            abs((value - candidate + 180) % 360 - 180) for value in angles))
    return {'median': median_value,
            'confidence_median': _finite_median(confidence for _, confidence in supported),
            'sample_count': len(supported), 'unknown_count': count - len(supported)}


def summarize_color_evidence(payloads):
    """Summarize residual color transforms, never rendered brightness proxies."""
    from .color_analysis import _HUE_BANDS
    colors = [payload.get('residual_color') or payload.get('color', {}) for payload in payloads]
    count = len(colors)
    models = [color.get('saturation_model', {}) for color in colors]
    result = {'schema_version': 1, 'sample_count': count,
              'saturation_gain': _observed_stat([
                  (model.get('gain'), model.get('confidence')) if model.get('status') == 'ok' else (None, None)
                  for model in models], count),
              'vibrance': _observed_stat([
                  (model.get('vibrance'), model.get('vibrance_confidence')) if model.get('status') == 'ok' else (None, None)
                  for model in models], count),
              'hue_bands': {}}
    for band in _HUE_BANDS:
        entries = [color.get('hue_bands', {}).get(band, {}) for color in colors]
        result['hue_bands'][band] = {}
        for name in ('hue_delta_degrees', 'saturation_residual', 'lightness_delta'):
            confidence_key = 'saturation_residual_confidence' if name == 'saturation_residual' else 'confidence'
            result['hue_bands'][band][name] = _observed_stat([
                (entry.get(name), entry.get(confidence_key)) if entry.get('sample_count', 0) > 0 else (None, None)
                for entry in entries], count, circular=name == 'hue_delta_degrees')
    return result


def _scene_fingerprint(result):
    payload = result.get('payload')
    if isinstance(payload, dict):
        fingerprint = payload.get('provenance', {}).get('input_fingerprints', {}).get('original')
        if fingerprint is not None:
            return fingerprint
    return result.get('item', {}).get('scene_original_fingerprint')


def summarize_scene_results(results):
    """Count category support once per original photo, across all input modes.

    Time-of-day labels are classifier evidence or explicit user assignments.
    Rendered brightness bins are deliberately not converted into scene labels.
    Reviewed photo counts remain visible; style support excludes conflicting
    edits of one original and never treats those edits as independent photos.
    """
    groups, categories = defaultdict(list), {}
    for result in results:
        payload = result.get('payload')
        if result.get('status') != 'ok' or not isinstance(payload, dict):
            continue
        fingerprint = payload.get('provenance', {}).get('input_fingerprints', {}).get('original')
        if not isinstance(fingerprint, str):
            continue
        groups[fingerprint].append(result)
    classified = manual = eligible = conflicts = 0
    for group in groups.values():
        result = group[0]
        payload = result['payload']
        edited = {row['payload'].get('provenance', {}).get('input_fingerprints', {}).get('edited')
                  for row in group} - {None}
        has_edit_conflict = len(edited) > 1
        eligible += int(not has_edit_conflict)
        conflicts += int(has_edit_conflict)
        report = payload.get('photo_scene', {})
        labels = report.get('labels', []) if isinstance(report, dict) else []
        is_manual = result.get('item', {}).get('scene_override') is not None
        manual += int(is_manual)
        classified += int(bool(labels))
        for label in labels:
            entry = categories.setdefault(label, {'sample_count': 0, 'style_sample_count': 0, 'automatic_count': 0,
                                                  'manual_count': 0, 'underrepresented': True})
            entry['sample_count'] += 1
            entry['style_sample_count'] += int(not has_edit_conflict)
            entry['manual_count' if is_manual else 'automatic_count'] += 1
            entry['underrepresented'] = entry['style_sample_count'] < 3
    return {'schema_version': 1, 'sample_count': len(groups), 'classified_count': classified,
            'unclassified_count': len(groups) - classified, 'manual_count': manual,
            'style_eligible_count': eligible, 'excluded_edit_conflict_count': conflicts,
            'categories': dict(sorted(categories.items()))}


def set_scene_override(batch, item_id, labels):
    """Return a copied snapshot with a reviewed scene assignment.

    ``None`` restores automatic evidence; an empty list explicitly leaves the
    photo unclassified. No decoding, recognition, database write or cache
    mutation occurs. The source item and derived payload remain consistent.
    """
    from .photo_scene import validate_scene_override, with_scene_override, unknown_photo_scene
    if not isinstance(batch, dict) or batch.get('mode') not in MODES:
        raise ValueError('Invalid source batch.')
    if not isinstance(item_id, str) or not item_id:
        raise ValueError('Invalid source item identity.')
    normalized = validate_scene_override(labels)
    output = copy.deepcopy(batch)
    matched = [result for result in output.get('results', []) if result.get('item', {}).get('id') == item_id]
    if not matched:
        raise ValueError('Source item was not found in this batch.')
    original_fingerprints = {_scene_fingerprint(result) for result in matched} - {None}
    for result in output.get('results', []):
        item = result.get('item', {})
        payload = result.get('payload')
        fingerprint = _scene_fingerprint(result)
        if item.get('id') != item_id and fingerprint not in original_fingerprints:
            continue
        item['scene_override'] = copy.deepcopy(normalized)
        item.pop('scene_status', None)
        item.pop('scene_requested_override', None)
        if result.get('error_code') == 'scene_manual_assignment_conflict':
            result.pop('error_code')
        if isinstance(payload, dict):
            report = payload.get('photo_scene')
            if report is None:
                report = unknown_photo_scene('insufficient_image_evidence')
            report = copy.deepcopy(report)
            report['warnings'] = [warning for warning in report.get('warnings', [])
                                  if warning != 'scene_manual_assignment_conflict']
            payload['photo_scene'] = with_scene_override(report, normalized)
    output['summary'] = summarize_results(output['mode'], output['results'])
    json.dumps(output, allow_nan=False)
    return output


def _review_shared_scene_assignments(results):
    """Keep a scene assignment attached to the photo, not its edit sidecar."""
    from .photo_scene import with_scene_override
    groups = defaultdict(list)
    for result in results:
        payload = result.get('payload')
        if result.get('status') in {'ok', 'duplicate'}:
            fingerprint = _scene_fingerprint(result)
            if isinstance(fingerprint, str):
                groups[fingerprint].append(result)
    for group in groups.values():
        edited = {result['payload'].get('provenance', {}).get('input_fingerprints', {}).get('edited')
                  for result in group if isinstance(result.get('payload'), dict)} - {None}
        if len(edited) > 1:
            for result in group:
                result['item']['scene_edit_status'] = 'needs_edit_review'
        explicit = {tuple(result['item']['scene_override']) for result in group
                    if result['item'].get('scene_override') is not None}
        if not explicit:
            continue
        conflict = len(explicit) > 1
        assignment = [] if conflict else list(next(iter(explicit)))
        for result in group:
            item = result['item']
            if conflict:
                item['scene_requested_override'] = item.get('scene_override')
                item['scene_status'] = 'needs_scene_review'
                result['error_code'] = 'scene_manual_assignment_conflict'
            item['scene_override'] = list(assignment)
            if isinstance(result.get('payload'), dict):
                report = with_scene_override(result['payload']['photo_scene'], assignment)
                if conflict:
                    report['warnings'] = list(dict.fromkeys([
                        *report.get('warnings', [])[:7], 'scene_manual_assignment_conflict']))
                result['payload']['photo_scene'] = report


def summarize_results(mode, results):
    """Keep final appearance, inferred changes and recorded settings separate."""
    _mode(mode)
    payloads = [r['payload'] for r in results if r['status'] == 'ok' and isinstance(r.get('payload'), dict)]
    if mode == 'reference_jpg':
        summary = aggregate_references(payloads)
        summary['input_count'] = len(results)
        summary['duplicate_count'] = sum(r['status'] == 'duplicate' for r in results)
        summary['excluded_count'] = len(results) - summary['sample_count'] - summary['duplicate_count']
        if summary['duplicate_count']:
            summary['warnings'].append('reference_duplicates_ignored')
        if summary['excluded_count']:
            summary['warnings'].append('reference_invalid_or_uncertain_excluded')
        summary['warnings'] = list(dict.fromkeys(summary['warnings']))
        summary['scene_stats'] = summarize_scene_results(results)
        summary['provenance']['scene_coverage_assessed'] = any('photo_scene' in payload for payload in payloads)
        _scene_summary_warnings(summary, results)
        return summary
    summary = {'source_type': mode, 'sample_count': len(payloads), 'input_count': len(results),
               'excluded_count': len(results) - len(payloads)}
    if mode == 'raw_jpg':
        independent, identity_counts = _independent_transform_payloads(payloads)
        detail_stats = summarize_detail_evidence(independent, kind='paired')
        color_stats = summarize_color_evidence(independent)
        detail_stats.update(identity_counts)
        color_stats.update(identity_counts)
        summary.update({
            'exposure_ev_median': _finite_median(p.get('tone', {}).get('estimated_exposure_ev') for p in payloads),
            'brightness_delta_median': _finite_median(p.get('tone', {}).get('mean_luminance_delta') for p in payloads),
            'contrast_delta_median': _finite_median(p.get('tone', {}).get('contrast_delta') for p in payloads),
            'temperature_counts': dict(Counter(p.get('lightroom_estimates', {}).get('white_balance_direction', 'uncertain') for p in payloads)),
            'tint_counts': dict(Counter(p.get('lightroom_estimates', {}).get('tint_direction', 'uncertain') for p in payloads)),
            'residual_saturation_delta_median': _finite_median(
                p.get('residual_color', {}).get('hsv', {}).get('saturation_delta') for p in independent),
            'detail_stats': detail_stats,
            'color_stats': color_stats,
            'warnings': ['raw_baseline_interpretation', 'lightroom_values_approximate'],
        })
    else:
        values = defaultdict(list)
        for payload in payloads:
            for name, value in payload.get('parameters', {}).items():
                values[name].append(value)
        parameters = {}
        for name, entries in sorted(values.items()):
            if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in entries):
                parameters[name] = {'median': _finite_median(entries), 'min': min(entries), 'max': max(entries), 'count': len(entries)}
            else:
                parameters[name] = {'values': list(dict.fromkeys(entries)), 'count': len(entries)}
        process_versions = sorted({str(p.get('metadata', {}).get('ProcessVersion')) for p in payloads if p.get('metadata', {}).get('ProcessVersion') is not None})
        warnings = ['xmp_settings_not_rendered']
        warnings.extend(w for p in payloads for w in p.get('warnings', []) if w in {
            'xmp_local_adjustments_not_extracted', 'xmp_custom_profile_not_rendered',
            'xmp_unsupported_settings_ignored', 'xmp_invalid_values_ignored',
            'xmp_conflicting_settings_ignored',
            'xmp_scene_uses_unedited_raw', 'scene_raw_unavailable',
        })
        if len(process_versions) > 1:
            warnings.append('mixed_xmp_process_versions')
        summary.update({'parameters': parameters, 'process_versions': process_versions,
                        'tone_curve_count': sum(bool(p.get('tone_curves')) for p in payloads), 'warnings': list(dict.fromkeys(warnings))})
    summary['scene_stats'] = summarize_scene_results(results)
    _scene_summary_warnings(summary, results)
    return summary


def _scene_summary_warnings(summary, results):
    if summary['scene_stats']['excluded_edit_conflict_count']:
        summary['warnings'].append('scene_edit_evidence_conflict')
    if any(result.get('item', {}).get('scene_status') == 'needs_scene_review' for result in results):
        summary['warnings'].append('scene_manual_assignment_conflict')
    summary['warnings'] = list(dict.fromkeys(summary['warnings']))


def _paths_for_item(item, mode):
    if item.get('source_type') != mode:
        raise ValueError('Selected input type does not match the analysis mode.')
    original = Path(item['original_path']).expanduser().resolve(strict=True)
    if not original.is_file():
        raise ValueError('Input photo is not a file.')
    if mode == 'reference_jpg':
        if original.suffix.lower() not in JPEG_EXTENSIONS:
            raise ValueError('Reference mode requires a JPEG photo.')
        return original, None
    edited = Path(item['edited_path']).expanduser().resolve(strict=True)
    expected = JPEG_EXTENSIONS if mode == 'raw_jpg' else XMP_EXTENSIONS
    if original.suffix.lower() not in RAW_EXTENSIONS or edited.suffix.lower() not in expected or not edited.is_file():
        raise ValueError('The selected files do not match this RAW input mode.')
    if original.samefile(edited):
        raise ValueError('The two input files must be different.')
    return original, edited


def analyze_inputs(items, mode, progress=None, cancel_event=None, cache=None):
    """Analyze rows serially, retaining only completed evidence when cancelled.

    Returns completed results even when another photo fails or the user cancels.
    No SQLite connections, GUI objects, source writes or network access occur.
    """
    _mode(mode)
    items = list(items)
    started = time.perf_counter()
    results, seen = [], set()
    cached = avoided = cache_errors = 0
    current_bundle = None
    from .photo_scene import classifier_bundle_id, MODEL_VERSION as SCENE_MODEL_VERSION
    try:
        current_classifier = classifier_bundle_id()
    except Exception:
        current_classifier = None
    if mode != 'raw_xmp' and cache is not None:
        from .semantic_models import bundle_id, ModelUnavailableError
        try:
            current_bundle = bundle_id()
        except ModelUnavailableError:
            # Cached global measurements remain useful without recognition.
            # Once repaired, available models below invalidate unavailable or
            # differently versioned semantic evidence and retry recognition.
            pass
    counts = dict.fromkeys(('total', 'processed', 'successful', 'failed', 'skipped', 'cancelled', 'duplicates'), 0)
    counts['total'] = len(items)
    for item in items:
        if cancel_event is not None and cancel_event.is_set():
            counts['cancelled'] = len(items) - counts['processed']
            break
        if item.get('status') != 'ready':
            result = {'item': dict(item), 'status': 'skipped', 'payload': None, 'error_code': item.get('reason', 'not_ready')}
            counts['skipped'] += 1
        else:
            try:
                from .photo_scene import validate_scene_override
                override = validate_scene_override(item.get('scene_override'))
                original, edited = _paths_for_item(item, mode)
                fingerprints = {'original': file_fingerprint(original)}
                if edited is not None:
                    fingerprints['edited'] = file_fingerprint(edited)
                check_cancel(cancel_event)
                identity = tuple(sorted(fingerprints.items()))
                if identity in seen:
                    result = {'item': dict(item), 'status': 'duplicate', 'payload': None, 'error_code': 'duplicate_content'}
                    result['item']['scene_override'] = override
                    result['item']['scene_original_fingerprint'] = fingerprints['original']
                    counts['duplicates'] += 1
                    avoided += 1
                    results.append(result)
                    counts['processed'] += 1
                    if progress:
                        progress(counts['processed'], counts['total'], original.name)
                    continue
                key = cache_key(mode, fingerprints)
                payload = None
                if cache is not None:
                    try:
                        payload = cache.get_cached_analysis(key)
                    except Exception:
                        cache_errors += 1
                if payload is not None:
                    expected_type = 'inferred_raw_pair' if mode == 'raw_jpg' else mode
                    if (payload.get('algorithm_version') != ALGORITHM_VERSION or payload.get('schema_version') != 1
                            or payload.get('source_type') != expected_type
                            or payload.get('provenance', {}).get('input_fingerprints') != fingerprints):
                        payload = None
                    elif current_bundle is not None and (
                            payload.get('semantic', {}).get('status') != 'ok'
                            or payload['semantic'].get('bundle_id') != current_bundle):
                        payload = None
                    elif (not isinstance(payload.get('photo_scene'), dict)
                          or payload['photo_scene'].get('source') != 'automatic'
                          or payload['photo_scene'].get('model_version') != SCENE_MODEL_VERSION
                          or payload.get('provenance', {}).get('scene_classifier_identity') != current_classifier
                          or (payload['photo_scene'].get('bundle_id') is not None
                              and payload['photo_scene'].get('bundle_id') != current_classifier)):
                        payload = None
                    else:
                        payload = relocate_payload(payload, original, edited, fingerprints)
                from_cache = payload is not None
                if from_cache:
                    cached += 1
                elif mode == 'reference_jpg':
                    payload = analyze_reference(original, expected_fingerprint=fingerprints['original'],
                                                cancel_event=cancel_event)
                elif mode == 'raw_xmp':
                    xmp_options = {'cancel_event': cancel_event} if cancel_event is not None else {}
                    payload = analyze_raw_xmp(original, edited, **xmp_options)
                else:
                    pair_options={'cancel_event':cancel_event} if cancel_event is not None else {}
                    payload = analyze_pair(original, edited,**pair_options)
                if not from_cache:
                    payload['provenance']['scene_classifier_identity'] = current_classifier
                if 'detail' in payload:
                    from .detail_analysis import validate_detail_report
                    detail = validate_detail_report(payload['detail'])
                    expected_kind = 'appearance' if mode == 'reference_jpg' else 'paired'
                    if mode == 'raw_xmp' or detail['kind'] != expected_kind:
                        raise ValueError('Detail evidence does not match the input mode.')
                # Fresh engines already verify hashes before and after decoding.
                # Cached results must perform their own final identity check.
                after = dict(fingerprints)
                if from_cache:
                    after['original'] = file_fingerprint(original)
                    if edited is not None:
                        after['edited'] = file_fingerprint(edited)
                if after != fingerprints or payload.get('provenance', {}).get('input_fingerprints') != fingerprints:
                    raise ValueError('Input changed during batch analysis; retry with stable files.')
                from .photo_scene import with_scene_override
                # File/model evidence remains automatic in the shared cache;
                # user review belongs only to this copied batch snapshot.
                automatic_payload = payload
                reviewed_payload = copy.deepcopy(payload)
                reviewed_payload['photo_scene'] = with_scene_override(payload['photo_scene'], override)
                status = payload['status']
                result = {'item': copy.deepcopy(item), 'status': status, 'payload': reviewed_payload}
                result['item']['scene_override'] = override
                result['item']['scene_original_fingerprint'] = fingerprints['original']
                fingerprints = payload.get('provenance', {}).get('input_fingerprints', {})
                identity = tuple(sorted(fingerprints.items()))
                if status == 'ok' and identity and identity in seen:
                    result.update(status='duplicate', payload=None, error_code='duplicate_content')
                    counts['duplicates'] += 1
                elif status == 'ok':
                    if identity:
                        seen.add(identity)
                    counts['successful'] += 1
                    if cache is not None:
                        try:
                            cache.cache_analysis(key, automatic_payload)
                        except Exception:
                            # Optional acceleration must never discard valid
                            # evidence or count a successful photo as a failure.
                            cache_errors += 1
                else:
                    counts['failed'] += 1
            except AnalysisCancelledError:
                counts['cancelled'] = len(items) - counts['processed']
                break
            except Exception as exc:
                result = {'item': dict(item), 'status': 'error', 'payload': None,
                          'error_code': 'analysis_error', 'error_detail': str(exc)}
                counts['failed'] += 1
        results.append(result)
        counts['processed'] += 1
        if progress:
            progress(counts['processed'], counts['total'], Path(item.get('original_path', '')).name)
    status = ('cancelled' if counts['cancelled'] else
              'failed' if not counts['successful'] else
              'partial' if counts['failed'] or counts['skipped'] else 'ok')
    _review_shared_scene_assignments(results)
    batch = {'schema_version': 1, 'algorithm_version': ALGORITHM_VERSION, 'mode': mode, 'status': status,
             'analyzed_at_utc': datetime.now(timezone.utc).isoformat(), 'results': results,
             'summary': summarize_results(mode, results), 'counts': counts,
             'performance': {'cache_hits': cached, 'avoided_duplicate_decodes': avoided,
                             'cache_errors': cache_errors,
                             'elapsed_seconds': time.perf_counter() - started},
             'provenance': {'originals_modified': False, 'aggregation': 'equal_per_unique_input',
                            'exact_edit_parameters': mode == 'raw_xmp'}}
    json.dumps(batch, allow_nan=False)
    return batch
