"""Separate a supported spatial edit from the observed global tone curve.

A conditional tone curve alone absorbs some local-contrast changes. Reusing
that curve and the measured spatial edit would apply the same evidence twice.
This bounded alternating fit removes only well-supported clarity/texture
bands before estimating the pointwise curve. The original observations stay
intact; the result is a derived rendering recipe, never recovered Adobe data.
"""
from __future__ import annotations

from copy import deepcopy

import cv2
import numpy as np

from .analysis_control import check_cancel
from .detail_analysis import MAX_DIMENSION, analyze_details, detail_bands, _robust_fit
from .tone_analysis import analyze_tone, tone_corrected_rgb

_LUMA = np.array([.2126, .7152, .0722], np.float32)
_METHOD = "iterative_luma_band_subtraction"
_MIN_CONFIDENCE = .65
_TILE_SAMPLES = 4096
_FIT_SAMPLES = 20_000


def _supported(report, *, include_neutral=False):
    if not isinstance(report, dict) or report.get("status") != "ok":
        return {}
    if "detail_alignment_uncertain" in report.get("warnings", []):
        return {}
    controls = report.get("controls", {})
    return {name: float(values["estimate"])
            for name in ("clarity", "texture")
            if isinstance(values := controls.get(name), dict)
            and values.get("estimate") is not None
            and float(values.get("confidence", 0)) >= _MIN_CONFIDENCE
            and (include_neutral or abs(float(values["estimate"])) > .025)}


def _luma(rgb):
    return (rgb.astype(np.float32) / 255) @ _LUMA


def _change_luma(rgb, desired):
    values = rgb.astype(np.float32) / 255
    y = values @ _LUMA
    ratio = np.divide(desired, y, out=np.ones_like(y), where=y > .0001)
    corrected = values * ratio[:, :, None]
    corrected += np.maximum(desired - y * ratio, 0)[:, :, None]
    return np.rint(np.clip(corrected, 0, 1) * 255).astype(np.uint8)


def _condition_on_tone(original, edited, baseline, mask, report, names, cancel_event=None):
    """Do not mistake curvature between tone knots for a spatial operation.

    The detail estimator intentionally has few nuisance columns. For this
    joint fit, a smooth pointwise polynomial additionally explains nonlinear
    tone curvature. Spatial coefficients must remain consistent across tiles.
    Existing evidence gates supply the upper confidence bound; this helper
    cannot promote a withheld measurement into a reusable editing operation.
    """
    y, target, source_y = _luma(baseline), _luma(edited), _luma(original)
    radius = max(1, int(np.ceil(36 * max(y.shape) / MAX_DIMENSION)))
    valid = cv2.erode(mask.astype(np.uint8), np.ones((2 * radius + 1,) * 2, np.uint8),
                      borderType=cv2.BORDER_CONSTANT, borderValue=0).astype(bool)
    valid &= (y > .025) & (y < .975) & (target > .025) & (target < .975)
    bands = detail_bands(y)
    rgb = original.astype(np.float32) / 255
    polynomials = np.polynomial.legendre.legvander(2 * source_y - 1, 5).astype(np.float32)
    features = np.dstack([*bands, *[polynomials[:, :, j] for j in range(1, 6)],
                          y, rgb[:, :, 0] - rgb[:, :, 1],
                          rgb[:, :, 2] - rgb[:, :, 1], np.ones_like(y)])
    h, w = y.shape
    fitted_tiles = []
    for row in range(4):
        for col in range(4):
            check_cancel(cancel_event)
            region = (slice(row * h // 4, (row + 1) * h // 4),
                      slice(col * w // 4, (col + 1) * w // 4))
            selected = valid[region]
            if selected.sum() < 256:
                continue
            tile_indices = np.flatnonzero(selected)
            if tile_indices.size > _TILE_SAMPLES:
                tile_indices = tile_indices[np.linspace(0, len(tile_indices) - 1, _TILE_SAMPLES, dtype=np.int64)]
            values = features[region].reshape(-1, features.shape[-1])[tile_indices]
            if float(np.std(values[:, 2])) < .002:
                continue
            coefficients, _ = _robust_fit(values.astype(float), (target - y)[region].ravel()[tile_indices].astype(float))
            fitted_tiles.append(coefficients[:3])
    if len(fitted_tiles) < 3:
        return None
    indices = np.flatnonzero(valid)
    if indices.size > _FIT_SAMPLES:
        indices = indices[np.linspace(0, len(indices) - 1, _FIT_SAMPLES, dtype=np.int64)]
    _, residual = _robust_fit(features.reshape(-1, features.shape[-1])[indices].astype(float),
                              (target - y).ravel()[indices].astype(float))
    floor = max(1 / 1024, 1.4826 * float(np.median(np.abs(residual - np.median(residual)))))
    refined = deepcopy(report)
    for name, index, normalizer in (("clarity", 2, .45), ("texture", 1, .30)):
        if name not in names:
            continue
        values = np.asarray(fitted_tiles)[:, index]
        beta = float(np.median(values))
        signal = float(np.std(bands[index][valid]))
        if abs(beta) * signal < floor:
            beta = 0.
        agreement = float(np.mean(np.abs(values - beta) <= max(.06, abs(beta) * .5)))
        if agreement < .75:
            return None
        estimate = float(np.clip(beta / normalizer, -1, 1))
        control = refined["controls"][name]
        control["estimate"] = estimate
        control["confidence"] = min(control["confidence"], agreement)
        control["direction"] = "higher" if estimate > .025 else "lower" if estimate < -.025 else "neutral"
    return refined


def decompose_parameters(original, edited, mask, *, tone, tone_corrected,
                         detail, alignment=None, cancel_event=None):
    """Return a derived global curve/detail baseline, or abstain with ``None``.

    Work is restricted to the existing registered RGB buffers and at most a
    1024-pixel long edge. At most three alternating fits run. No decoder or file
    access occurs. Bad alignment, significant clipping and uncertain spatial
    evidence leave the existing measurements and rendering recipe untouched.
    """
    check_cancel(cancel_event)
    supported = _supported(detail)
    if not supported:
        return None
    if alignment is not None and (alignment.get("success") is not True
            or "alignment_unreliable" in alignment.get("warnings", [])):
        return None
    clipping = tone.get("clipping", {}).get("edited", {})
    if sum(float(clipping.get(key) or 0) for key in ("black_fraction", "white_fraction")) > .05:
        return None
    # Input shape/type validation is shared with the tone analyzer. In
    # particular, invalid masks must not silently turn into full-image fits.
    if (not isinstance(original, np.ndarray) or original.dtype != np.uint8
            or original.ndim != 3 or original.shape[-1] != 3
            or not isinstance(edited, np.ndarray) or edited.dtype != np.uint8
            or original.shape != edited.shape
            or not isinstance(tone_corrected, np.ndarray)
            or tone_corrected.dtype != np.uint8 or tone_corrected.shape != original.shape
            or not isinstance(mask, np.ndarray) or mask.dtype != np.bool_
            or mask.shape != original.shape[:2]):
        raise ValueError("Parameter decomposition requires registered uint8 RGB pixels and a boolean mask.")
    factor = min(1., MAX_DIMENSION / max(original.shape[:2]))
    size = max(1, round(original.shape[1] * factor)), max(1, round(original.shape[0] * factor))
    def bounded(rgb):
        return rgb.copy() if (rgb.shape[1], rgb.shape[0]) == size else cv2.resize(rgb, size, interpolation=cv2.INTER_AREA)
    first, last, baseline = bounded(original), bounded(edited), bounded(tone_corrected)
    valid = (mask.copy() if mask.shape == first.shape[:2] else
             cv2.resize(mask.astype(np.float32), size, interpolation=cv2.INTER_AREA) >= .999)
    # A warp can leave arbitrary RGB outside the common photograph. Gaussian
    # bands spread those pixels into the comparison; exclude their complete
    # filter context from the curve refit as well as from detail inference.
    # Natural photograph borders remain valid and use reflected filtering.
    fit_mask = valid
    if not valid.all():
        radius = max(1, int(np.ceil(48 * max(first.shape[:2]) / MAX_DIMENSION)))
        fit_mask = cv2.erode(valid.astype(np.uint8), np.ones((2 * radius + 1,) * 2, np.uint8),
                            borderType=cv2.BORDER_CONSTANT, borderValue=1).astype(bool)
    if int(fit_mask.sum()) < 1024:
        return None
    target = _luma(last)
    current_detail = _condition_on_tone(first, last, baseline, valid, detail, supported, cancel_event)
    if current_detail is None:
        return None
    if not _supported(current_detail):
        return {"global_tone_transfer": deepcopy(tone["tone_transfer"]), "detail": current_detail,
                "tone_corrected": tone_corrected.copy(),
                "decomposition": {"schema_version": 1, "iterations": 1,
                                  "confidence": min(detail["controls"][name]["confidence"] for name in supported),
                                  "method": _METHOD}}
    curve = None
    iterations = 0
    confidence = min(detail["controls"][name]["confidence"] for name in supported)
    for iteration in range(3):
        check_cancel(cancel_event)
        controls = _supported(current_detail, include_neutral=True)
        # A later uncertain fit must never silently erase a previously proven
        # band, nor substitute a global curve for that withheld spatial edit.
        if not all(name in controls for name in supported):
            break
        bands = detail_bands(_luma(baseline))
        delta = (bands[2] * (.45 * controls.get("clarity", 0.))
                 + bands[1] * (.30 * controls.get("texture", 0.)))
        reconstructed = _change_luma(last, np.clip(target - delta, 0, 1))
        check_cancel(cancel_event)
        fitted = analyze_tone(first, reconstructed, fit_mask)
        candidate_curve = fitted["tone_transfer"]
        if len(candidate_curve) < 3:
            break
        candidate_baseline = tone_corrected_rgb(first, candidate_curve)
        candidate_detail = analyze_details(
            first, last, valid, tone_corrected=candidate_baseline,
            alignment=alignment, cancel_event=cancel_event)
        candidate_detail = _condition_on_tone(first, last, candidate_baseline, valid, candidate_detail, supported, cancel_event)
        if candidate_detail is None:
            break
        if not all(name in _supported(candidate_detail, include_neutral=True) for name in supported):
            break
        change = float(np.mean(np.abs(candidate_baseline.astype(float) - baseline.astype(float))))
        baseline, current_detail, curve = candidate_baseline, candidate_detail, candidate_curve
        iterations = iteration + 1
        confidence = min(confidence, *(candidate_detail["controls"][name]["confidence"] for name in supported))
        if change < .05:
            break
    if curve is None:
        return None
    check_cancel(cancel_event)
    return {"global_tone_transfer": deepcopy(curve), "detail": current_detail,
            "tone_corrected": tone_corrected_rgb(original, curve),
            "decomposition": {"schema_version": 1, "iterations": iterations,
                              "confidence": float(confidence), "method": _METHOD}}
