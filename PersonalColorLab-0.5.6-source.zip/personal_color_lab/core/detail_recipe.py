"""Bounded, portable detail controls with explicit evidence support.

Recorded sliders, inferred transforms and final JPEG appearance have different
meanings. Missing metadata is never an observed zero. Reference appearance is
a weak structural target; it cannot recover sharpening or noise sliders.
"""
from __future__ import annotations

import copy
import math
from statistics import median

CONTROL_RANGES = {
    'clarity': (-1.0, 1.0), 'texture': (-1.0, 1.0),
    'sharpening': (0.0, 1.5), 'sharp_radius': (.5, 3.0),
    'sharp_mask': (0.0, 1.0), 'denoise_luma': (0.0, 1.0),
    'denoise_color': (0.0, 1.0),
}
CONTROL_DEFAULTS = {name: 1.0 if name == 'sharp_radius' else 0.0 for name in CONTROL_RANGES}
_BASES = {'recorded', 'inferred', 'appearance', 'unavailable'}
_HEX = set('0123456789abcdef')


def neutral_detail_profile():
    return {'controls': dict(CONTROL_DEFAULTS), 'target': None,
            'support': {name: {'sample_count': 0, 'confidence': 0.0, 'basis': 'unavailable'}
                        for name in CONTROL_RANGES}}


def _number(value, low, high):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and low <= value <= high)


def validate_detail_profile(profile):
    """Validate without mutating or accepting private/free-text provenance."""
    if not isinstance(profile, dict) or set(profile) != {'controls', 'target', 'support'}:
        raise ValueError('Invalid detail profile fields.')
    controls, support = profile['controls'], profile['support']
    if (not isinstance(controls, dict) or set(controls) != set(CONTROL_RANGES)
            or not isinstance(support, dict) or set(support) != set(CONTROL_RANGES)):
        raise ValueError('Invalid detail control fields.')
    for name, bounds in CONTROL_RANGES.items():
        if not _number(controls[name], *bounds):
            raise ValueError('Detail control is outside its supported range.')
        evidence = support[name]
        if (not isinstance(evidence, dict) or set(evidence) != {'sample_count', 'confidence', 'basis'}
                or type(evidence['sample_count']) is not int or not 0 <= evidence['sample_count'] <= 1_000_000
                or not _number(evidence['confidence'], 0, 1)
                or not isinstance(evidence['basis'], str) or evidence['basis'] not in _BASES):
            raise ValueError('Invalid detail support.')
        if evidence['basis'] == 'unavailable':
            if evidence['sample_count'] or evidence['confidence'] or controls[name] != CONTROL_DEFAULTS[name]:
                raise ValueError('Unavailable detail evidence must stay neutral.')
        elif evidence['sample_count'] < 1 or evidence['confidence'] <= 0:
            raise ValueError('Detail evidence needs measured support.')
        if evidence['basis'] == 'appearance' and name not in {'clarity', 'texture'}:
            raise ValueError('Appearance cannot recover sharpening or noise sliders.')
    target = profile['target']
    if target is not None:
        if (not isinstance(target, dict) or set(target) != {'local_contrast', 'texture_energy'}
                or any(not _number(value, 0, 1) for value in target.values())
                or any(support[name]['basis'] != 'appearance' or support[name]['sample_count'] < 3
                       for name in ('clarity', 'texture'))):
            raise ValueError('Invalid supported detail appearance target.')
    elif any(value['basis'] == 'appearance' for value in support.values()):
        raise ValueError('Appearance support needs its structural target.')
    return profile


def _unique_payloads(payloads, *, require_hash=False):
    grouped, unhashed = {}, []
    for payload in payloads:
        if not isinstance(payload, dict):
            continue
        original = payload.get('provenance', {}).get('input_fingerprints', {}).get('original')
        if not isinstance(original, str) or len(original) != 64 or set(original) - _HEX:
            if not require_hash:
                unhashed.append(payload)
            continue
        grouped.setdefault(original, []).append(payload)
    unique = list(unhashed)
    for group in grouped.values():
        edits = {payload.get('provenance', {}).get('input_fingerprints', {}).get('edited') for payload in group}
        if len(edits) == 1:
            unique.append(group[0])
    return unique


def _supported(profile, name, values, confidence, basis):
    if not values:
        return
    low, high = CONTROL_RANGES[name]
    profile['controls'][name] = float(min(high, max(low, median(values))))
    profile['support'][name] = {'sample_count': len(values), 'confidence': float(median(confidence)), 'basis': basis}


def learn_detail_profile(payloads, mode):
    """Learn observed values conservatively, keeping unknown controls neutral."""
    result = neutral_detail_profile()
    unique = _unique_payloads(payloads, require_hash=mode == 'reference_jpg')
    from .detail_analysis import validate_detail_report
    for payload in unique:
        if 'detail' in payload:
            validate_detail_report(payload['detail'])
    if mode == 'raw_xmp':
        mapping = {'clarity': (('Clarity2012', 'Clarity'), 100), 'texture': (('Texture',), 100),
                   'sharpening': (('Sharpness',), 100), 'sharp_radius': (('SharpenRadius',), 1),
                   'sharp_mask': (('SharpenEdgeMasking',), 100),
                   'denoise_luma': (('LuminanceSmoothing',), 100),
                   'denoise_color': (('ColorNoiseReduction',), 100)}
        for name, (aliases, scale) in mapping.items():
            values = []
            for payload in unique:
                params = payload.get('parameters', {})
                for alias in aliases:
                    if alias in params:
                        value = params[alias]
                        if _number(value, CONTROL_RANGES[name][0] * scale, CONTROL_RANGES[name][1] * scale):
                            values.append(float(value) / scale)
                        break
            _supported(result, name, values, [1.0] * len(values), 'recorded')
    elif mode == 'reference_jpg':
        appearances = []
        for payload in unique:
            detail = payload.get('detail', {})
            value = detail.get('appearance', {})
            if (detail.get('kind') == 'appearance' and detail.get('status') == 'ok'
                    and all(_number(value.get(key), 0, 1) for key in ('local_contrast', 'texture_energy'))
                    and _number(value.get('edge_fraction'), .005, 1)
                    and _number(value.get('flat_fraction'), 0, .98)):
                appearances.append(value)
        if len(appearances) >= 3:
            result['target'] = {name: float(median(item[name] for item in appearances))
                                for name in ('local_contrast', 'texture_energy')}
            for name in ('clarity', 'texture'):
                result['support'][name] = {'sample_count': len(appearances), 'confidence': .25, 'basis': 'appearance'}
    else:
        for name in ('clarity', 'texture', 'sharpening', 'denoise_luma'):
            values, confidences = [], []
            for payload in unique:
                detail = payload.get('detail', {})
                observed = detail.get('controls', {}).get(name, {})
                threshold = .65 if name == 'sharpening' else .35
                estimate, confidence = observed.get('estimate'), observed.get('confidence')
                if (detail.get('kind') == 'paired' and detail.get('status') in {'ok', 'uncertain'}
                        and _number(estimate, -1, 1)
                        and _number(confidence, threshold, 1)):
                    # Negative denoise/sharpen measurements do not ask the
                    # application to invent noise or reconstruct lost detail.
                    if name in ('sharpening', 'denoise_luma') and estimate < 0:
                        continue
                    values.append(float(estimate))
                    confidences.append(float(confidence))
            _supported(result, name, values, confidences, 'inferred')
    return validate_detail_profile(result)


def mix_detail_profiles(base, weighted):
    """Mix scene deltas under the caller's existing axis/total budgets."""
    validate_detail_profile(base)
    result = copy.deepcopy(base)
    supported = []
    for profile, weight in weighted:
        if not _number(weight, 0, 1):
            raise ValueError('Invalid detail mixture weights.')
        if weight > 0:
            supported.append((validate_detail_profile(profile), float(weight)))
    total = sum(weight for _, weight in supported)
    if total > 1 + 1e-10 or any(not _number(weight, 0, 1) for _, weight in supported):
        raise ValueError('Invalid detail mixture weights.')
    participants = [(base, max(0.0, 1 - total)), *supported]
    for name, bounds in CONTROL_RANGES.items():
        result['controls'][name] = float(min(bounds[1], max(bounds[0], base['controls'][name]
            + sum((profile['controls'][name] - base['controls'][name]) * weight for profile, weight in supported))))
        evidence = [(profile['support'][name], weight) for profile, weight in participants
                    if weight > 1e-12 and profile['support'][name]['basis'] != 'unavailable']
        if evidence:
            bases = {entry['basis'] for entry, _ in evidence}
            # A blended support count is descriptive, never independent photo
            # evidence. Deltas do not promote it into a learned category.
            result['support'][name] = {
                'sample_count': max(entry['sample_count'] for entry, _ in evidence),
                'confidence': min(1., sum(entry['confidence'] * weight for entry, weight in evidence)),
                'basis': next(iter(bases)) if len(bases) == 1 else 'inferred',
            }
        else:
            result['controls'][name] = CONTROL_DEFAULTS[name]
            result['support'][name] = copy.deepcopy(neutral_detail_profile()['support'][name])
    targets = [(profile['target'], weight) for profile, weight in participants if profile['target'] is not None and weight > 1e-12]
    if targets and all(result['support'][name]['basis'] == 'appearance' for name in ('clarity', 'texture')):
        weight_sum = sum(weight for _, weight in targets)
        result['target'] = {name: float(sum(target[name] * weight for target, weight in targets) / weight_sum)
                            for name in ('local_contrast', 'texture_energy')}
    else:
        result['target'] = None
        for name in ('clarity', 'texture'):
            if result['support'][name]['basis'] == 'appearance':
                result['support'][name]['basis'] = 'inferred'
    return validate_detail_profile(result)


def blend_detail_profiles(weighted):
    """Mix already adapted hybrid components with the normalized style weights."""
    return mix_detail_profiles(neutral_detail_profile(), weighted)
