"""Bounded observations of photographic detail, without recovering Adobe sliders.

Paired evidence describes the registered, rendered analysis preview. The same
Gaussian bands are available to the style renderer. Fine detail is withheld
when resampling or uncertain geometry can explain its apparent change.
Reference-only observations include subject, focus and compression; they never
establish an editing operation or an intention to add noise.
"""
from __future__ import annotations

from copy import deepcopy
import math

import cv2
import numpy as np

from .analysis_control import check_cancel

DETAIL_SCHEMA_VERSION = 1
MAX_DIMENSION = 1024
MAX_SAMPLES = 100_000
CONTROL_NAMES = ("clarity", "texture", "sharpening", "denoise_luma")
APPEARANCE_NAMES = ("local_contrast", "texture_energy", "fine_energy",
                    "flat_noise_mad", "flat_fraction", "edge_fraction")
WARNING_CODES = frozenset({
    "detail_analysis_resolution", "detail_global_tone_removed",
    "detail_content_confounders", "detail_fine_resampling_uncertain",
    "detail_alignment_uncertain", "detail_insufficient_support",
    "detail_flat_noise_not_edit_intent", "detail_jpeg_artifact_uncertainty",
    "detail_color_confounders", "detail_inconsistent_evidence",
    "detail_clipping_excluded", "detail_no_recoverable_fine_detail",
    "detail_noise_change_unidentified",
})
_LUMA = np.array([.2126, .7152, .0722], dtype=np.float32)


def _finite(value, low, high):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and low <= value <= high)


def validate_detail_report(report):
    """Validate portable evidence strictly and return an independent copy."""
    if not isinstance(report, dict):
        raise ValueError("Invalid detail report.")
    kind = report.get("kind")
    keys = {"schema_version", "kind", "status", "analysis_dimensions", "appearance", "warnings"}
    if kind == "paired":
        keys.add("controls")
    if (kind not in {"paired", "appearance"} or set(report) != keys
            or type(report.get("schema_version")) is not int
            or report["schema_version"] != DETAIL_SCHEMA_VERSION
            or report.get("status") not in {"ok", "insufficient", "uncertain"}):
        raise ValueError("Invalid detail report schema.")
    dimensions = report["analysis_dimensions"]
    if (not isinstance(dimensions, list) or len(dimensions) != 2
            or any(type(v) is not int or not 1 <= v <= MAX_DIMENSION for v in dimensions)):
        raise ValueError("Invalid detail analysis dimensions.")
    appearance = report["appearance"]
    if (not isinstance(appearance, dict) or set(appearance) != set(APPEARANCE_NAMES)
            or any(v is not None and not _finite(v, 0, 1) for v in appearance.values())
            or not _finite(appearance["flat_fraction"], 0, 1)
            or not _finite(appearance["edge_fraction"], 0, 1)):
        raise ValueError("Invalid detail appearance.")
    warnings = report["warnings"]
    if (not isinstance(warnings, list) or len(warnings) > len(WARNING_CODES)
            or any(not isinstance(v, str) or v not in WARNING_CODES for v in warnings)
            or len(set(warnings)) != len(warnings)):
        raise ValueError("Invalid detail warnings.")
    if kind == "paired":
        controls = report["controls"]
        if not isinstance(controls, dict) or set(controls) != set(CONTROL_NAMES):
            raise ValueError("Invalid detail controls.")
        for values in controls.values():
            if (not isinstance(values, dict) or set(values) != {"estimate", "confidence", "direction"}
                    or not _finite(values["confidence"], 0, 1)
                    or values["estimate"] is not None and not _finite(values["estimate"], -1, 1)
                    or values["direction"] not in {"higher", "lower", "neutral", "uncertain"}):
                raise ValueError("Invalid detail control evidence.")
            if values["estimate"] is None:
                if values["confidence"] != 0 or values["direction"] != "uncertain":
                    raise ValueError("Missing detail evidence must remain uncertain.")
            else:
                expected = ("higher" if values["estimate"] > .025 else
                            "lower" if values["estimate"] < -.025 else "neutral")
                if values["direction"] != expected:
                    raise ValueError("Detail direction contradicts its observation.")
        if report["status"] != "ok" and any(v["estimate"] is not None for v in controls.values()):
            raise ValueError("Unsupported detail reports cannot contain learned controls.")
    return deepcopy(report)


def detail_bands(luma):
    """Return fine, medium, coarse rendered-luma bands at relative image scale.

    Gaussian standard deviations are 1, 3 and 12 pixels at a 1024-pixel long
    edge. No image resizing happens here, so the renderer can use the same
    relative bands at export resolution. The returned arrays are float32.
    """
    values = np.asarray(luma)
    if (values.ndim != 2 or not np.issubdtype(values.dtype, np.number)
            or not np.isfinite(values).all() or values.size == 0
            or values.min() < 0 or values.max() > 1):
        raise ValueError("Expected finite normalized 2D luminance.")
    values = values.astype(np.float32, copy=False)
    scale = max(values.shape) / MAX_DIMENSION
    blurred = [cv2.GaussianBlur(values, (0, 0), sigma * scale,
                               borderType=cv2.BORDER_REFLECT_101)
               for sigma in (1., 3., 12.)]
    return values - blurred[0], blurred[0] - blurred[1], blurred[1] - blurred[2]


def _rgb(value):
    if (not isinstance(value, np.ndarray) or value.dtype != np.uint8
            or value.ndim != 3 or value.shape[2] != 3 or min(value.shape[:2]) < 1):
        raise ValueError("Expected uint8 RGB pixels with shape (H, W, 3).")
    return value


def _resize_rgb(rgb, size):
    return (rgb.copy() if (rgb.shape[1], rgb.shape[0]) == size else
            cv2.resize(rgb, size, interpolation=cv2.INTER_AREA))


def _bounded_size(rgb):
    factor = min(1., MAX_DIMENSION / max(rgb.shape[:2]))
    return max(1, round(rgb.shape[1] * factor)), max(1, round(rgb.shape[0] * factor))


def _unknown_controls():
    return {name: {"estimate": None, "confidence": 0., "direction": "uncertain"}
            for name in CONTROL_NAMES}


def _report(kind, size):
    result = {"schema_version": DETAIL_SCHEMA_VERSION, "kind": kind,
              "status": "insufficient", "analysis_dimensions": list(size),
              "appearance": {name: (0. if name.endswith("fraction") else None)
                             for name in APPEARANCE_NAMES},
              "warnings": ["detail_analysis_resolution"]}
    if kind == "paired":
        result["controls"] = _unknown_controls()
    return result


def _mad(values):
    return float(np.median(np.abs(values - np.median(values)))) if values.size else None


def _luma(rgb):
    return (rgb.astype(np.float32) / 255.) @ _LUMA


def _interior(mask, shape):
    radius = max(1, math.ceil(3 * 12 * max(shape) / MAX_DIMENSION))
    return cv2.erode(mask.astype(np.uint8), np.ones((2 * radius + 1,) * 2, np.uint8),
                     borderType=cv2.BORDER_CONSTANT, borderValue=0).astype(bool)


def _structure_masks(y, valid):
    scale = max(y.shape) / MAX_DIMENSION
    smooth = cv2.GaussianBlur(y, (0, 0), max(.4, 3 * scale))
    gx = cv2.Sobel(smooth, cv2.CV_32F, 1, 0, ksize=3) / 8
    gy = cv2.Sobel(smooth, cv2.CV_32F, 0, 1, ksize=3) / 8
    gradient = cv2.magnitude(gx, gy)
    wide = cv2.GaussianBlur(y, (0, 0), max(.4, 6 * scale))
    variance = np.maximum(cv2.GaussianBlur(y * y, (0, 0), max(.4, 6 * scale)) - wide * wide, 0)
    flat = valid & (gradient < .0025) & (variance < .025 ** 2)
    edges = valid & (gradient >= .004)
    return flat, edges


def _energy(values, valid):
    samples = np.abs(values[valid])
    if samples.size < 32:
        return None
    bound = float(np.quantile(samples, .99))
    return float(np.clip(np.sqrt(np.mean(np.minimum(samples, bound) ** 2)), 0, 1))


def _block_artifact_likely(y, flat, *, residual=False):
    """Conservative periodic discontinuity check inside otherwise flat areas.

    Decoder subsampling can turn JPEG's 8-pixel grid into 4 or 2 pixels. This
    is only a confounder flag, never an identification of compression quality.
    Texture edges are excluded by the common source-flat mask.
    """
    if int(flat.sum()) < 2048:
        return False
    for axis in (0, 1):
        change = np.abs(np.diff(y, axis=axis))
        eligible = ((flat[1:] & flat[:-1]) if axis == 0 else (flat[:, 1:] & flat[:, :-1]))
        positions = np.arange(1, y.shape[axis])
        for period in (2, 4, 8):
            boundary = positions % period == 0
            selected = eligible & (boundary[:, None] if axis == 0 else boundary[None, :])
            others = eligible & (~boundary[:, None] if axis == 0 else ~boundary[None, :])
            if int(selected.sum()) < 512 or int(others.sum()) < 1024:
                continue
            high, low = float(change[selected].mean()), float(change[others].mean())
            minimum, ratio, gap = ((.0005, 1.2, .00015) if residual else (.0015, 1.6, .001))
            if high > max(minimum, low * ratio) and high - low > gap:
                return True
    return False


def _appearance(y, valid, bands=None):
    bands = detail_bands(y) if bands is None else bands
    flat, edge = _structure_masks(y, valid)
    count = int(valid.sum())
    return {"local_contrast": _energy(bands[2], valid),
            "texture_energy": _energy(bands[1], valid),
            "fine_energy": _energy(bands[0], valid),
            "flat_noise_mad": _mad(bands[0][flat]) if int(flat.sum()) >= 64 else None,
            "flat_fraction": float(flat.sum() / count) if count else 0.,
            "edge_fraction": float(edge.sum() / count) if count else 0.}, flat, edge


def measure_detail_appearance(rgb, *, cancel_event=None):
    """Observe final-image spatial structure; never infer an editing history."""
    check_cancel(cancel_event)
    rgb = _rgb(rgb)
    size = _bounded_size(rgb)
    y = _luma(_resize_rgb(rgb, size))
    report = _report("appearance", size)
    valid = _interior(np.ones(y.shape, dtype=bool), y.shape) & (y > .025) & (y < .975)
    check_cancel(cancel_event)
    report["appearance"], flat, _ = _appearance(y, valid)
    report["warnings"].extend(["detail_content_confounders", "detail_flat_noise_not_edit_intent"])
    if _block_artifact_likely(y, flat):
        report["warnings"].append("detail_jpeg_artifact_uncertainty")
    if int(valid.sum()) >= 256:
        report["status"] = "ok"
    else:
        report["warnings"].append("detail_insufficient_support")
    check_cancel(cancel_event)
    return validate_detail_report(report)


def _correlation(a, b):
    if len(a) < 64:
        return 0.
    a, b = a.astype(np.float64), b.astype(np.float64)
    a -= a.mean()
    b -= b.mean()
    norm = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.clip(np.dot(a, b) / norm, -1, 1)) if norm > 1e-12 else 0.


def _robust_fit(x, target):
    """Small regularized regression with bounded Huber reweighting."""
    spread = x.std(axis=0)
    active = spread > 1e-6
    active[-1] = True  # The final column is the intercept.
    scale = np.where(spread > 1e-6, spread, 1.)
    matrix = x[:, active] / scale[active]
    weight = np.ones(len(target), dtype=np.float64)
    coefficients = np.zeros(matrix.shape[1], dtype=np.float64)
    for _ in range(3):
        gram = matrix.T @ (matrix * weight[:, None])
        ridge = np.eye(len(gram)) * max(1., float(weight.sum())) * 1e-8
        coefficients = np.linalg.solve(gram + ridge, matrix.T @ (target * weight))
        residual = target - matrix @ coefficients
        sigma = max(1 / 1024, 1.4826 * float(np.median(np.abs(residual - np.median(residual)))))
        weight = np.minimum(1., 1.5 * sigma / np.maximum(np.abs(residual), 1e-8))
    output = np.zeros(x.shape[1], dtype=np.float64)
    output[active] = coefficients / scale[active]
    return output, residual


def _same_sampling(alignment):
    if alignment is None:
        return True
    if not isinstance(alignment, dict) or alignment.get("success") is not True:
        return False
    if "original_decode" in alignment:
        # Sensor demosaicing and native-pixel sharpness are not observed here.
        return False
    original, edited = alignment.get("original_size"), alignment.get("edited_size")
    if original and edited and original != edited:
        return False
    rotation = alignment.get("rotation_degrees", 0)
    scale = alignment.get("scale", 1)
    if not _finite(rotation, -.05, .05) or not _finite(scale, .999, 1.001):
        return False
    matrix = alignment.get("matrix")
    if matrix is not None:
        try:
            matrix = np.asarray(matrix, dtype=np.float64)
            if matrix.shape != (3, 3) or not np.isfinite(matrix).all():
                return False
            if np.max(np.abs(matrix[:2, :2] - np.eye(2))) > .0005:
                return False
            if np.max(np.abs(matrix[:2, 2] - np.rint(matrix[:2, 2]))) > .05:
                return False
        except (TypeError, ValueError):
            return False
    diagnostics = alignment.get("diagnostics") or {}
    if not isinstance(diagnostics, dict):
        return False
    error = diagnostics.get("median_reprojection_error")
    return error is None or _finite(error, 0, .25)


def _phase_displacement(source, target, valid):
    """Verify residual translation on separated, fully valid structural tiles."""
    h, w = source.shape
    shifts = []
    for row in range(4):
        for col in range(4):
            top, bottom = row * h // 4, (row + 1) * h // 4
            left, right = col * w // 4, (col + 1) * w // 4
            support = valid[top:bottom, left:right]
            if min(support.shape) < 24 or float(support.mean()) < .9:
                continue
            a, b = source[top:bottom, left:right], target[top:bottom, left:right]
            if a.std() < .008 or b.std() < .008:
                continue
            window = cv2.createHanningWindow((a.shape[1], a.shape[0]), cv2.CV_32F)
            displacement, response = cv2.phaseCorrelate(
                (a - a.mean()).astype(np.float32), (b - b.mean()).astype(np.float32), window)
            if math.isfinite(response) and response >= .2 and all(math.isfinite(v) for v in displacement):
                shifts.append(float(math.hypot(*displacement)))
    return float(np.median(shifts)) if len(shifts) >= 3 else None


def _control(estimate, confidence):
    value = float(np.clip(estimate, -1, 1))
    return {"estimate": value, "confidence": float(np.clip(confidence, 0, 1)),
            "direction": "higher" if value > .025 else "lower" if value < -.025 else "neutral"}


def analyze_details(original_rgb, edited_rgb, mask, *, tone_corrected=None,
                    alignment=None, cancel_event=None):
    """Measure local-contrast/detail differences with separate evidence gates.

    Estimates are normalized renderer-band gains, not Lightroom values:
    clarity = coarse gain / .45, texture = medium gain / .30, sharpening =
    fine gain / .35. Denoise is positive flat-patch smoothing only; unexplained
    added noise never becomes a learned instruction to amplify noise.
    """
    check_cancel(cancel_event)
    original, edited = _rgb(original_rgb), _rgb(edited_rgb)
    if original.shape != edited.shape:
        raise ValueError("Detail analysis requires registered same-size RGB pixels.")
    if not isinstance(mask, np.ndarray) or mask.dtype != np.bool_ or mask.shape != original.shape[:2]:
        raise ValueError("Expected boolean registered overlap mask.")
    if tone_corrected is not None and _rgb(tone_corrected).shape != original.shape:
        raise ValueError("Tone-corrected baseline must match the registered pixels.")
    if alignment is not None and not isinstance(alignment, dict):
        raise ValueError("Alignment evidence must be a mapping or absent.")
    size = _bounded_size(original)
    report = _report("paired", size)
    if isinstance(alignment, dict) and (alignment.get("success") is not True
            or "alignment_unreliable" in alignment.get("warnings", [])):
        report["warnings"].extend(["detail_alignment_uncertain", "detail_insufficient_support"])
        return validate_detail_report(report)
    first, last = _resize_rgb(original, size), _resize_rgb(edited, size)
    support = cv2.resize(mask.astype(np.float32), size, interpolation=cv2.INTER_AREA) >= .999
    if tone_corrected is None:
        from .tone_analysis import analyze_tone, tone_corrected_rgb
        baseline = tone_corrected_rgb(first, analyze_tone(first, last, support)["tone_transfer"])
    else:
        baseline = _resize_rgb(tone_corrected, size)
    y, target = _luma(baseline), _luma(last)
    unclipped = (y > .025) & (y < .975) & (target > .025) & (target < .975)
    valid = _interior(support, y.shape) & unclipped
    report["warnings"].extend(["detail_global_tone_removed", "detail_flat_noise_not_edit_intent"])
    if np.any(support & ~unclipped):
        report["warnings"].append("detail_clipping_excluded")
    check_cancel(cancel_event)
    source_bands, target_bands = detail_bands(y), detail_bands(target)
    report["appearance"], _, _ = _appearance(target, valid, target_bands)
    count = int(valid.sum())
    if count < 512:
        report["warnings"].append("detail_insufficient_support")
        return validate_detail_report(report)
    flat, edges = _structure_masks(y, valid)
    block_artifacts = (_block_artifact_likely(y, flat) or _block_artifact_likely(target, flat)
                       # Recompression can add mid-frequency structure only
                       # around existing edges, leaving flat patches clean.
                       # Check periodic discontinuities in the paired residual
                       # as an additional uncertainty signal, not a JPEG label.
                       or _block_artifact_likely(.5 + .5 * (target - y), valid, residual=True))
    if block_artifacts:
        report["warnings"].append("detail_jpeg_artifact_uncertainty")
    # Global tone/color predictors keep casts and curves out of band gains.
    # Retain both original and fitted-baseline luma. A quantized 32-bin global
    # tone fit can itself alter fine structure; the original-luma nuisance
    # explains a pointwise exposure/contrast change without calling it texture.
    rgb = first.astype(np.float32) / 255.
    original_luma = rgb @ _LUMA
    features = np.stack((*source_bands, y, original_luma, rgb[:, :, 0] - rgb[:, :, 1],
                         rgb[:, :, 2] - rgb[:, :, 1], np.ones_like(y)), axis=-1)
    indices = np.flatnonzero(valid)
    if indices.size > MAX_SAMPLES:
        indices = indices[np.linspace(0, indices.size - 1, MAX_SAMPLES, dtype=np.int64)]
    coefficients, residual = _robust_fit(features.reshape(-1, 8)[indices].astype(np.float64),
                                        (target - y).ravel()[indices].astype(np.float64))
    residual_floor = max(1 / 1024, 1.4826 * (_mad(residual) or 0.))
    check_cancel(cancel_event)
    h, w = y.shape
    tile_coefficients = []
    for row in range(4):
        for col in range(4):
            check_cancel(cancel_event)
            region = (slice(row * h // 4, (row + 1) * h // 4),
                      slice(col * w // 4, (col + 1) * w // 4))
            tile_mask = valid[region]
            if int(tile_mask.sum()) < 256:
                continue
            tile_features = features[region][tile_mask].astype(np.float64)
            if float(np.std(tile_features[:, 2])) < .002:
                continue
            fitted, _ = _robust_fit(tile_features, (target[region] - y[region])[tile_mask].astype(np.float64))
            tile_coefficients.append(fitted[:3])
    tiles = np.asarray(tile_coefficients, dtype=np.float64)
    displacement = _phase_displacement(cv2.GaussianBlur(y, (0, 0), .8),
                                        cv2.GaussianBlur(target, (0, 0), .8), valid)
    fine_safe = (_same_sampling(alignment) and displacement is not None
                 and displacement <= .2 and not block_artifacts)
    if not fine_safe:
        report["warnings"].append("detail_fine_resampling_uncertain")
    if displacement is not None and displacement > .65:
        report["warnings"].append("detail_alignment_uncertain")
    if len(tiles) < 3:
        report["warnings"].append("detail_insufficient_support")
        report["status"] = "uncertain"
        return validate_detail_report(report)
    confidence_values = []
    for band_index, name, normalizer, threshold in (
            (2, "clarity", .45, .78), (1, "texture", .30, .85), (0, "sharpening", .35, .94)):
        signal = float(np.std(source_bands[band_index][valid]))
        correlation = _correlation(source_bands[band_index][valid], target_bands[band_index][valid])
        original_band = source_bands[band_index][valid].astype(np.float64)
        edited_band = target_bands[band_index][valid].astype(np.float64)
        centered = original_band - original_band.mean()
        actual_gain = float(np.dot(centered, edited_band - edited_band.mean())
                            / max(1e-12, float(np.dot(centered, centered))) - 1.)
        values = tiles[:, band_index]
        beta = float(np.median(values))
        spread = float(np.median(np.abs(values - beta)))
        # At eight-bit preview precision, a small fitted coefficient can merely
        # describe quantization introduced by the global tone fit. Do not turn
        # a sub-residual change into a reusable texture/sharpness instruction.
        if abs(beta) * signal < residual_floor:
            beta = 0.
        agreement = float(np.mean(np.abs(values - beta) <= max(.06, abs(beta) * .5)))
        confidence = (min(1., len(tiles) / 8) * min(1., signal / .008)
                      * max(0., correlation) * agreement / (1 + spread * 8))
        if name == "sharpening":
            edge_support = float(edges.sum() / max(1, valid.sum()))
            confidence *= min(1., edge_support / .08)
        # Very inconsistent local edits and misregistration do not define a
        # reusable global detail transform. Fine-band noise cannot qualify.
        eligible = (signal >= .0008 and correlation >= threshold and confidence >= .35
                    and (displacement is None or displacement <= .65)
                    and (name != "sharpening" or fine_safe and confidence >= .65)
                    and (name != "texture" or not block_artifacts)
                    # Overlapping Gaussian bases can need compensating gains.
                    # A compensating boost must not become an independent
                    # learned texture/sharpness operation after another band
                    # was withheld. Contradictory observable energy abstains.
                    and not (beta * actual_gain < 0 and abs(actual_gain) > .02))
        if eligible:
            report["controls"][name] = _control(beta / normalizer, confidence)
            confidence_values.append(confidence)
        elif name == "sharpening":
            if "detail_no_recoverable_fine_detail" not in report["warnings"]:
                report["warnings"].append("detail_no_recoverable_fine_detail")
        else:
            if "detail_inconsistent_evidence" not in report["warnings"]:
                report["warnings"].append("detail_inconsistent_evidence")
    check_cancel(cancel_event)
    flat_count = int(flat.sum())
    if flat_count >= 1024:
        before_noise, after_noise = _mad(source_bands[0][flat]), _mad(target_bands[0][flat])
        if (before_noise is not None and after_noise is not None and before_noise > .0015
                and fine_safe and after_noise / before_noise < .7
                and _correlation(source_bands[1][edges], target_bands[1][edges]) > .9
                and int(edges.sum()) >= 256):
            confidence = min(.8, .7 * min(1., flat_count / 4096) * min(1., before_noise / .005))
            report["controls"]["denoise_luma"] = _control(1 - after_noise / before_noise, confidence)
            confidence_values.append(confidence)
        elif after_noise is not None and before_noise is not None and after_noise > max(.001, before_noise * 1.5):
            report["warnings"].append("detail_noise_change_unidentified")
    report["status"] = "ok" if confidence_values else "uncertain"
    check_cancel(cancel_event)
    return validate_detail_report(report)
