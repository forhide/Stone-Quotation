"""Localized parameter evidence from stored measurements, never photo decoding.

Recorded slider settings, inferred image changes and final appearance are kept
distinct. Missing measurements never acquire a neutral (zero) value in the UI.
"""
from __future__ import annotations

import math
import statistics


OVERVIEW_PARAMETERS = ('brightness', 'temperature', 'contrast', 'saturation', 'clarity', 'texture')
DETAIL_CONTROLS = ('clarity', 'texture', 'sharpening', 'denoise_luma', 'denoise_color')
_RECORDED_NAMES = {
    'brightness': ('Exposure2012', 'Exposure'),
    'temperature': ('Temperature',),
    'contrast': ('Contrast2012', 'Contrast'),
    'saturation': ('Saturation',),
    'clarity': ('Clarity2012', 'Clarity'),
    'texture': ('Texture',),
    'sharpening': ('Sharpness',),
    'denoise_luma': ('LuminanceSmoothing',),
    'denoise_color': ('ColorNoiseReduction',),
}


def _map(value):
    return value if isinstance(value, dict) else {}


def _finite(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        return float(value) if math.isfinite(value) else None
    except (OverflowError, ValueError):
        return None


def _empty(i18n, key):
    return {'key': key, 'label': i18n.t('parameter_' + key),
            'value': i18n.t('summary_not_measured'), 'note': '', 'basis': 'unavailable'}


def _direction(i18n, value, threshold=.005):
    key = 'higher' if value > threshold else 'lower' if value < -threshold else 'neutral'
    return i18n.t('direction_' + key)


def _recorded(i18n, parameters, key):
    for name in _RECORDED_NAMES.get(key, ()):
        value = _finite(parameters.get(name))
        if value is not None:
            unit = ' EV' if key == 'brightness' else ' K' if key == 'temperature' else ''
            text = f'{value:+.2f}' if key == 'brightness' else f'{value:g}'
            return {'key': key, 'label': i18n.t('parameter_' + key), 'value': text + unit,
                    'note': i18n.t('parameter_basis_recorded'), 'basis': 'recorded'}
    return None


def detail_control_card(i18n, detail, key):
    card = _empty(i18n, key)
    detail = _map(detail)
    if detail.get('kind') == 'appearance':
        return card
    controls = _map(detail.get('controls'))
    if key not in controls:
        return card
    control = _map(controls.get(key))
    estimate = _finite(control.get('estimate'))
    confidence = _finite(control.get('confidence'))
    if estimate is None or not -1 <= estimate <= 1 or confidence is None or not 0 <= confidence <= 1:
        if detail.get('kind') == 'paired':
            card.update(value=i18n.t('direction_uncertain'), note=i18n.t('parameter_insufficient_detail'), basis='inferred')
        return card
    direction = control.get('direction')
    if direction not in {'higher', 'lower', 'neutral', 'uncertain'}:
        direction = 'uncertain'
    card.update(value=i18n.t('direction_' + direction), basis='inferred',
                note=i18n.t('parameter_inferred_note', value=f'{estimate:+.2f}', confidence=round(confidence * 100)))
    return card


def source_parameter_cards(i18n, payload, mode):
    """Six bounded overview cards, preserving the input's evidence type."""
    payload = _map(payload)
    parameters = _map(payload.get('parameters'))
    cards = {key: _empty(i18n, key) for key in OVERVIEW_PARAMETERS}
    if mode == 'raw_xmp':
        for key in cards:
            cards[key] = _recorded(i18n, parameters, key) or cards[key]
        return cards
    if mode == 'reference_jpg':
        appearance = _map(payload.get('appearance'))
        tendencies = _map(payload.get('tendencies')) or _map(appearance.get('tendencies'))
        for key in ('brightness', 'temperature', 'contrast', 'saturation'):
            if isinstance(tendencies.get(key), str):
                code = 'source_' + tendencies[key]
                if code in i18n.messages:
                    cards[key].update(value=i18n.t(code), note=i18n.t('parameter_basis_appearance'), basis='appearance')
                    compact = {'high': 'bright', 'low': 'dark', 'mid': 'balanced', 'bright': 'bright', 'dark': 'dark', 'balanced': 'balanced'}
                    if key == 'brightness' and tendencies[key] in compact:
                        cards[key]['compact_value']=i18n.t('parameter_appearance_' + compact[tendencies[key]])
        detail = _map(payload.get('detail'))
        metrics = _map(detail.get('appearance'))
        for key, metric in (('clarity', 'local_contrast'), ('texture', 'texture_energy')):
            value = _finite(metrics.get(metric))
            if value is not None and 0 <= value <= 1:
                cards[key].update(value=i18n.t('parameter_appearance_value', value=f'{value:.3f}'), metric=value,
                                  note=i18n.t('parameter_content_dependent'), basis='appearance')
        return cards

    if payload.get('status', 'ok') != 'ok':
        return cards
    tone, color = _map(payload.get('tone')), _map(payload.get('color'))
    for key, value in (
        ('brightness', tone.get('mean_luminance_delta')),
        ('contrast', tone.get('contrast_delta')),
        ('saturation', _map(color.get('hsv')).get('saturation_delta')),
    ):
        number = _finite(value)
        if number is not None and -1 <= number <= 1:
            cards[key].update(value=_direction(i18n, number), basis='inferred',
                              note=i18n.t('parameter_observed_delta', value=f'{number * 100:+.1f}'))
    wb = _map(color.get('wb_tint'))
    direction = wb.get('temperature_direction')
    if direction in {'warmer', 'cooler', 'warm', 'cool', 'neutral', 'unchanged', 'uncertain'}:
        code = {'warm': 'warmer', 'cool': 'cooler', 'unchanged': 'neutral'}.get(direction, direction)
        cards['temperature'].update(value=i18n.t('direction_' + code), note=i18n.t('parameter_basis_inferred'), basis='inferred')
    for key in ('clarity', 'texture'):
        cards[key] = detail_control_card(i18n, payload.get('detail'), key)
    model = _map(_map(payload.get('residual_color')).get('saturation_model'))
    gain, confidence = _finite(model.get('gain')), _finite(model.get('confidence'))
    if model.get('status') == 'ok' and gain is not None and 0 <= gain <= 2 and confidence is not None and 0 <= confidence <= 1:
        cards['saturation'].update(value=f'{gain:.2f}×', basis='inferred',
                                   note=i18n.t('parameter_saturation_fit_note', confidence=round(confidence * 100)))
    return cards


def batch_parameter_cards(i18n, batch):
    """Aggregate measured values only; unavailable files cannot vote for zero."""
    batch = _map(batch)
    mode, summary = batch.get('mode'), _map(batch.get('summary'))
    if mode == 'raw_xmp':
        parameters = {name: values.get('median') for name, values in _map(summary.get('parameters')).items()
                      if isinstance(values, dict) and _finite(values.get('median')) is not None}
        return source_parameter_cards(i18n, {'parameters': parameters}, mode)
    if mode == 'reference_jpg':
        report = dict(summary)
        detail_metrics = {}
        for metric in ('local_contrast', 'texture_energy'):
            metric_stats = _map(_map(_map(summary.get('detail_stats')).get('appearance')).get(metric))
            summary_value = _finite(metric_stats.get('median'))
            values = [_finite(_map(_map(_map(row.get('payload')).get('detail')).get('appearance')).get(metric))
                      for row in batch.get('results', []) if isinstance(row, dict) and row.get('status') == 'ok']
            values = [value for value in values if value is not None]
            if summary_value is not None or values:
                detail_metrics[metric] = summary_value if summary_value is not None else statistics.median(values)
        report['detail'] = {'kind': 'appearance', 'appearance': detail_metrics}
        return source_parameter_cards(i18n, report, mode)
    rows = [_map(row.get('payload')) for row in batch.get('results', [])
            if isinstance(row, dict) and row.get('status') == 'ok']
    report = {'status': 'ok', 'tone': {}, 'color': {'hsv': {}, 'wb_tint': {}}, 'detail': {'kind': 'paired', 'controls': {}}}
    for section, sub, field in (('tone', None, 'mean_luminance_delta'), ('tone', None, 'contrast_delta'),
                                ('color', 'hsv', 'saturation_delta')):
        values = [_finite((_map(row.get(section)) if sub is None else _map(_map(row.get(section)).get(sub))).get(field)) for row in rows]
        values = [value for value in values if value is not None]
        if values:
            target = report[section] if sub is None else report[section][sub]
            target[field] = statistics.median(values)
    detail_stats = _map(summary.get('detail_stats'))
    if not any(_map(row.get('detail')).get('kind') == 'paired' for row in rows) and detail_stats.get('kind') != 'paired':
        report.pop('detail')
    for key in ('clarity', 'texture'):
        controls = [_map(_map(_map(row.get('detail')).get('controls')).get(key)) for row in rows]
        supported = [(estimate, confidence) for control in controls
                     if (estimate := _finite(control.get('estimate'))) is not None
                     and (confidence := _finite(control.get('confidence'))) is not None
                     and -1 <= estimate <= 1 and 0 <= confidence <= 1]
        stats = _map(_map(detail_stats.get('controls')).get(key))
        if 'detail' in report and (stats or any(key in _map(_map(row.get('detail')).get('controls')) for row in rows)):
            report['detail']['controls'][key] = {'estimate': None, 'confidence': 0., 'direction': 'uncertain'}
        stat_estimate, stat_confidence = _finite(stats.get('median')), _finite(stats.get('confidence_median'))
        if stats:
            # The core excludes multiple incompatible edits of one original.
            # An empty authoritative aggregate must not fall back to those rows.
            supported = ([(stat_estimate, stat_confidence)]
                         if stat_estimate is not None and stat_confidence is not None
                         and -1 <= stat_estimate <= 1 and 0 <= stat_confidence <= 1 else [])
        if supported and 'detail' in report:
            estimate = statistics.median(value for value, _ in supported)
            confidence = statistics.median(value for _, value in supported)
            report['detail']['controls'][key] = {'estimate': estimate, 'confidence': statistics.median(value for _, value in supported),
                                                 'direction': 'uncertain' if confidence < .35 else 'higher' if estimate > .01 else 'lower' if estimate < -.01 else 'neutral'}
    temperature_counts = _map(summary.get('temperature_counts'))
    if temperature_counts:
        valid = [(key, value) for key, value in temperature_counts.items() if type(value) is int and value > 0]
        if valid:
            report['color']['wb_tint']['temperature_direction'] = max(valid, key=lambda item: item[1])[0]
    gain_stats = _map(_map(summary.get('color_stats')).get('saturation_gain'))
    gain, confidence = _finite(gain_stats.get('median')), _finite(gain_stats.get('confidence_median'))
    if gain is not None and confidence is not None:
        report['residual_color'] = {'saturation_model': {'status': 'ok', 'gain': gain, 'confidence': confidence}}
    return source_parameter_cards(i18n, report, mode)


def parameter_evidence_lines(i18n, payload, mode):
    """Detail provenance belongs alongside color evidence, not a hidden guess."""
    t = i18n.t
    detail = _map(_map(payload).get('detail'))
    lines = ['', t('parameter_detail_heading')]
    if mode == 'raw_xmp':
        for key in DETAIL_CONTROLS:
            card = _recorded(i18n, _map(payload.get('parameters')), key) or _empty(i18n, key)
            lines.append(t('metric_line', label=card['label'], value=card['value'] + (' · ' + card['note'] if card['note'] else '')))
        return lines
    if detail.get('kind') == 'appearance':
        lines.append(t('parameter_reference_detail_notice'))
        for key in ('local_contrast', 'texture_energy', 'fine_energy', 'flat_noise_mad'):
            value = _finite(_map(detail.get('appearance')).get(key))
            lines.append(t('metric_line', label=t('parameter_metric_' + key), value=f'{value:.4f}' if value is not None else t('summary_not_measured')))
        return lines
    lines.append(t('parameter_inferred_detail_notice') if detail.get('kind') == 'paired' else t('parameter_legacy_detail_notice'))
    for key in DETAIL_CONTROLS:
        card = detail_control_card(i18n, detail, key)
        lines.append(t('metric_line', label=card['label'], value=card['value'] + (' · ' + card['note'] if card['note'] else '')))
    model = _map(_map(_map(payload).get('residual_color')).get('saturation_model'))
    if model:
        lines.extend(['', t('parameter_color_fit_heading')])
        for key, label in (('gain', 'parameter_saturation'), ('vibrance', 'parameter_vibrance')):
            value = _finite(model.get(key)) if model.get('status') == 'ok' else None
            rendered = f'{value:.2f}×' if value is not None and key == 'gain' else f'{value * 100:+.1f}%' if value is not None else t('summary_not_measured')
            confidence = _finite(model.get('vibrance_confidence' if key == 'vibrance' else 'confidence'))
            if value is not None and confidence is not None and 0 <= confidence <= 1:
                rendered += ' · ' + t('parameter_fit_confidence', confidence=round(confidence * 100))
            lines.append(t('metric_line', label=t(label), value=rendered))
    residual = _map(_map(payload).get('residual_color'))
    bands = _map(_map(residual or _map(payload).get('color')).get('hue_bands'))
    if bands:
        lines.extend(['', t('parameter_hsl_heading')])
        for band, values in bands.items():
            values = _map(values)
            count = values.get('sample_count')
            if type(count) is not int or count <= 0:
                continue
            saturation_key = 'saturation_residual' if residual and 'saturation_residual' in values else 'saturation_delta'
            values_out = [_finite(values.get(key)) for key in ('hue_delta_degrees', saturation_key, 'lightness_delta')]
            if all(value is not None for value in values_out):
                hue, saturation, lightness = values_out
                lines.append(t('parameter_hsl_line', band=t('channel_' + band), hue=f'{hue:+.1f}', saturation=f'{saturation * 100:+.1f}', lightness=f'{lightness * 100:+.1f}'))
    return lines


def effective_parameter_lines(i18n, effective, strength=1., parameter_support=None):
    """Describe the actual adapted recipe at the currently selected strength."""
    t = i18n.t
    effective = _map(effective)
    amount = _finite(strength)
    amount = max(0., min(1., amount)) if amount is not None else 0.
    curve = effective.get('tone_curve')
    lines = []
    if isinstance(curve, list) and len(curve) >= 3 and all(_finite(value) is not None for value in curve):
        def sample(position):
            index = position * (len(curve) - 1)
            lower = int(index)
            return curve[lower] * (1 - (index - lower)) + curve[min(lower + 1, len(curve) - 1)] * (index - lower)
        delta = ((sample(.75) - sample(.25)) - .5) * amount
        lines.append(t('parameter_effect_line', label=t('parameter_contrast'), value=_direction(i18n, delta) + f' ({delta:+.3f})'))
    saturation = _finite(effective.get('saturation_scale'))
    vibrance = _finite(effective.get('vibrance'))
    lines.append(t('parameter_effect_line', label=t('parameter_saturation'), value=f'{((saturation - 1) * amount + 1):.2f}×' if saturation is not None else t('summary_not_measured')))
    lines.append(t('parameter_effect_line', label=t('parameter_vibrance'), value=f'{vibrance * amount * 100:+.1f}%' if vibrance is not None else t('summary_not_measured')))
    active_hsl = []
    for band, values in _map(effective.get('hsl')).items():
        values = _map(values)
        hue, saturation_delta, lightness = [_finite(values.get(key)) for key in ('hue', 'saturation', 'lightness')]
        if all(value is not None for value in (hue, saturation_delta, lightness)) and any(abs(value * amount) > .0001 for value in (hue, saturation_delta, lightness)):
            active_hsl.append(t('parameter_hsl_line', band=t('channel_' + band), hue=f'{hue * amount:+.1f}', saturation=f'{saturation_delta * amount * 100:+.1f}', lightness=f'{lightness * amount * 100:+.1f}'))
    lines.append(t('parameter_hsl_heading') + ': ' + (t('parameter_hsl_active', count=len(active_hsl)) if active_hsl else t('direction_neutral')))
    profile = _map(effective.get('detail_profile'))
    controls, support = _map(profile.get('controls')), _map(profile.get('support'))
    for key in DETAIL_CONTROLS:
        value = _finite(controls.get(key))
        evidence = _map(support.get(key))
        basis = evidence.get('basis', 'unavailable')
        supported = basis in {'recorded', 'inferred', 'appearance'}
        if not supported and (value is None or value == 0):
            text = t('parameter_unlearned_neutral')
        elif value is None:
            text = t('summary_not_measured')
        else:
            text = f'{value * amount * 100:+.1f}%' if key in {'clarity', 'texture'} else f'{value * amount * 100:.1f}%'
            if supported:
                text += ' · ' + t('parameter_basis_' + basis)
        lines.append(t('parameter_effect_line', label=t('parameter_' + key), value=text))
        if key == 'sharpening' and value is not None and value * amount > 0:
            radius, mask = _finite(controls.get('sharp_radius')), _finite(controls.get('sharp_mask'))
            if radius is not None and mask is not None:
                lines.append(t('parameter_sharpen_shape', radius=f'{radius:.2f}', mask=round(mask * 100)))
    lines.extend(active_hsl)
    grain = _finite(effective.get('grain_amount'))
    if grain is not None:
        lines.append(t('parameter_effect_line', label=t('parameter_grain'), value=f'{grain * amount * 100:.1f}%'))
    exposure = _finite(effective.get('exposure_ev'))
    if exposure is not None:
        lines.append(t('parameter_effect_line', label=t('parameter_brightness'), value=f'{exposure * amount:+.2f} EV'))
    recorded = _map(effective.get('recorded_parameters'))
    dehaze = _finite(recorded.get('Dehaze'))
    only_xmp = _map(parameter_support).get('xmp_only')
    only_xmp = [name for name in only_xmp if isinstance(name, str)] if isinstance(only_xmp, list) else []
    if only_xmp:
        names = [t('source_param_' + name) if 'source_param_' + name in i18n.messages else name for name in only_xmp]
        lines.append(t('parameter_xmp_only', names=', '.join(names)))
    elif dehaze is not None and dehaze != 0:
        lines.append(t('parameter_dehaze_xmp_only'))
    lines.append(t('parameter_effect_units_notice'))
    return lines


def batch_parameter_evidence_lines(i18n, batch):
    """Expose support for additional color and spatial controls in a batch."""
    t = i18n.t
    summary = _map(_map(batch).get('summary'))
    detail = _map(summary.get('detail_stats'))
    lines = []
    if detail:
        lines.extend(['', t('parameter_detail_heading')])
        if detail.get('kind') == 'appearance':
            lines.append(t('parameter_reference_detail_notice'))
            for key in ('local_contrast', 'texture_energy', 'fine_energy', 'flat_noise_mad'):
                stats = _map(_map(detail.get('appearance')).get(key))
                value = _finite(stats.get('median'))
                lines.append(t('metric_line', label=t('parameter_metric_' + key), value=f'{value:.4f}' if value is not None else t('summary_not_measured')))
        else:
            lines.append(t('parameter_inferred_detail_notice'))
            for key in ('clarity', 'texture', 'sharpening', 'denoise_luma'):
                stats = _map(_map(detail.get('controls')).get(key))
                value, confidence = _finite(stats.get('median')), _finite(stats.get('confidence_median'))
                count = stats.get('sample_count')
                if value is None or confidence is None or type(count) is not int or count < 1:
                    text = t('summary_not_measured')
                else:
                    text = t('parameter_inferred_support', value=f'{value:+.2f}', confidence=round(confidence * 100), count=count)
                lines.append(t('metric_line', label=t('parameter_' + key), value=text))
    color = _map(summary.get('color_stats'))
    if color:
        lines.extend(['', t('parameter_color_fit_heading')])
        for key, label in (('saturation_gain', 'parameter_saturation'), ('vibrance', 'parameter_vibrance')):
            stats = _map(color.get(key))
            value, confidence = _finite(stats.get('median')), _finite(stats.get('confidence_median'))
            text = f'{value:.2f}×' if value is not None and key == 'saturation_gain' else f'{value * 100:+.1f}%' if value is not None else t('summary_not_measured')
            if value is not None and confidence is not None and 0 <= confidence <= 1:
                text += ' · ' + t('parameter_fit_confidence', confidence=round(confidence * 100))
            lines.append(t('metric_line', label=t(label), value=text))
        for band, values in _map(color.get('hue_bands')).items():
            values = _map(values)
            hue, saturation, lightness = [_finite(_map(values.get(key)).get('median')) for key in ('hue_delta_degrees', 'saturation_residual', 'lightness_delta')]
            if all(value is not None for value in (hue, saturation, lightness)):
                lines.append(t('parameter_hsl_line', band=t('channel_' + band), hue=f'{hue:+.1f}', saturation=f'{saturation * 100:+.1f}', lightness=f'{lightness * 100:+.1f}'))
    return lines
