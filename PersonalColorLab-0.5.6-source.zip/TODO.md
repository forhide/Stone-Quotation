# TODO

## V0.5.6 - Parameter evidence and spatial styling

- [x] Expose contrast, saturation, clarity and texture in analysis overviews and effective parameter evidence in the style workspace.
- [x] Distinguish recorded values, inferred transforms, final appearance and unmeasured controls; never present missing evidence as a recovered zero.
- [x] Fit paired saturation gain/vibrance robustly and use hue-band residuals to avoid duplicating global saturation.
- [x] Measure multiscale structural pair changes from existing aligned/tone-corrected pixels and suppress uncertain fine-detail/alignment/resampling evidence.
- [x] Separate global tone from spatial changes with independent global-only/nonlinear/combined RAW+JPG regressions; preserve observed evidence separately from the applied curve. Final source/installed release results are recorded in VALIDATION.md.
- [x] Support recorded XMP clarity/texture/sharpening/luminance-color noise controls in approximate local preview/JPG rendering.
- [x] Learn conservative local-contrast/texture targets from at least three distinct supported JPG references without fabricating sharpening/noise/grain history.
- [x] Carry supported detail controls through common/category profiles and hybrids; retain bounded filtering, cancellation, one RAW export development and source protection.
- [x] Disclose recorded numeric XMP-only settings, allow safe recorded-XMP passthrough and exclude unsupported component metadata from hybrid presets.
- [x] Add strict DNA4/engine0.5.6, scene-profile2 and detail-evidence validation with neutral nonmutating legacy adapters; retain DB3 and existing runtime dependencies/models.

Final regression counts and source/installed parameter diagnostics, installer inventories and download checks must be recorded in VALIDATION.md after completion. Historical results do not establish these checks.

## Implemented - V0.5.5 scene-aware learning and application

- [x] Local TinyCLIP visual categories with 21 multilabel attributes, uncertainty/abstention and manual review.
- [x] All three source routes, original-scene classification, XMP preservation, shared-original assignments and unique eligible support.
- [x] Common style plus bounded category deltas, minimum3 eligible originals, hybrid isolation and conservative monochrome.
- [x] Bilingual review/coverage/applied-category UI, cached scene changes and category-aware photo tiles.
- [x] DNA3 strict storage/import, nonmutating legacy rendering adapters, 2MiB JSON, original/GPS safety.

Broad photo-category accuracy, RAW near-duplicate diversity, native OS/camera evaluation, sky/terrain masks and signing/notarization remain pending. Release results are recorded in VALIDATION.md.

## Implemented - V0.5.4 RAW camera/lens correction

- [x] Read bounded offline equipment metadata; exclude GPS, serials, owners, dates and numeric-ID guesses while retaining valid RAW development on metadata errors.
- [x] Include unchanged, checksum-verified official Lensfun XML and CC BY-SA 3.0 attribution, plus pinned pure-Python ExifRead3.5.1.
- [x] Match exact camera/lens/focal/calibration geometry and support rectilinear poly3/poly5/PTLens radial distortion with bounded inverse maps and reported edge-fit zoom.
- [x] Add default RAW-workspace correction, an off control, detected status and filterable photo-specific manual camera/lens/focal choices without replacing autodetected evidence.
- [x] Preserve Sony A7CR/FE16–35 GM II identity; show missing GM II calibration rather than using GM I coefficients or inventing data.
- [x] Correct before resizing, measuring and recognizing regions; use one full-quality RAW development and matching corrected AREA measurement/mask geometry for JPG export.
- [x] Include correction mode/manual selection/calibration identity in reuse checks; retain optional fast-preview quality boundaries.
- [x] Keep learning optics off, geometry outside Style DNA and Lensfun/Adobe lens-profile geometry outside global XMP; guard uncertain embedded DNG instructions.
- [x] Keep app/analysis0.5.4, earlier snapshots through0.5.3, DB3, analysis/profile schema1 and DNA2/engine0.5.0. Release results belong in VALIDATION.md.

## Implemented - V0.5.3 RAW and style processing

- [x] Check RAW header dimensions before sensor unpacking and retain explicit invalid/120MP limits.
- [x] Preserve strict full AHD analysis/export by default, correct all EXIF axis swaps and check cancellation around native stages.
- [x] Add an explicit fast Bayer sensor preview, safe CFA/geometry/size fallback, quality provenance and a visible color/detail approximation notice.
- [x] Develop RAW once for final JPG export and derive its identical bounded measurement preview; retain JPEG draft/ICC behavior.
- [x] Recompute strict adaptive XMP settings after fast RAW preview instead of exporting approximate-preview measurements.
- [x] Precompute exposure/channel tables and tone-grid segments and reuse mask coordinates; compare output pixels on the measured rendering fixtures.
- [x] Guard source/quality/model reuse and preserve global styling with an unavailable-recognition notice.
- [x] Retain offline execution, original bytes, GPS exclusion, prior0.5.2 snapshots, DB3 and DNA2/engine0.5.0 with app/analysis0.5.3.

Final release counts and installer results belong in VALIDATION.md; synthetic benchmark equivalence does not establish native-camera or native-OS performance.

## V0.5.2 - Faster local processing and a refined photo studio

- Reuse circular color/chroma statistics and avoid expensive palette copies; retain the same analysis values, sample bounds and palette output on the measured inputs.
- Skip unchanged rendering transforms, prepare regional recipes once, and reuse hybrid component baselines/mask coordinates within bounded tiles. Restrict face-color conversion to supported bounds; retain pixel-exact benchmark results.
- Score-filter NanoDet candidates before box regression, skip empty-region filtering and avoid stacked mask tensors. Keep recognition model resolution/thresholds and the measured faster default thread policy.
- Share pair tone correction and batch reference fingerprints while preserving final actual-file verification. Cooperative reference cancellation keeps completed results.
- Add a photo-first studio with a right settings inspector, native-vector sliders/toggles, actual photo-based style tiles, direct wipe dragging, expandable subject/analysis details and a focused export footer.
- Clarify home build/apply routes, three source cards, current workflow steps and counted analysis actions. Preserve selection across language changes and offer folder changes without dropping explicit source choices.
- App/analysis0.5.2, unchanged SQLite3 and DNA2/engine0.5.0; prior analysis snapshots remain readable. PERFORMANCE.md records measured workload-specific timings; VALIDATION.md records release checks.

## V0.5.1 - Review fixes for style learning, rendering and recovery

- Correctly transfer pure monochrome intent from supported RAW/JPG or JPG/JPG comparisons and unanimously gray JPG references. Mixed-color, sepia, clipped and insufficient evidence remain conservative. Historical paired analyses need reanalysis to add the new evidence; reference snapshots already contain the needed appearance statistics.
- Preserve supported monochrome context/region recipes without removing color from unrelated regions. Share bounded preview measurements with full-resolution local rendering to keep component baselines consistent.
- Validate render options before recognition, honor cancellation at neutral/zero strength, preserve unchanged face pixels exactly, and skip unnecessary regional work.
- Encode exports in a private sibling file before publishing the new filename. Cancellation and ordinary failure remove this operation's partial files without replacing another output. Recheck the original after JPEG encoding; validate finite effective XMP values. Filesystems without hard links use an exclusive cancellable copy.
- Treat analysis cache failures as optional recovery, preserving valid results and correct counts. Reanalyze missing-model caches after model repair; validate cached semantic evidence and all model/license/manifest identities together.
- Clear stale photo/evidence on selection failures, preserve mix/composition/name state across language changes, scroll settings over child controls, and retain export locks during redraws and shortcuts.
- App and analysis algorithms0.5.1; SQLite3, analysis/profile schema1 and DNA2/engine0.5.0 remain compatible. Historical0.3/0.4/0.5.0 analysis snapshots stay readable. See VALIDATION.md for final tests, installed checks and platform limits.

## V0.5.0 - Embedded object recognition and a clearer style workspace

- Bundled checksum-verified local NanoDet COCO-80 object detection, PP-HumanSeg person segmentation and YuNet face detection (3,091,271 model bytes). Inference uses OpenCV DNN CPU; no API, token charge, runtime download, login or network client is added.
- Added object-derived context tags, region previews, optional face-color protection and adjustable region strength. Non-person objects use approximate boxes; faces use protection ellipses. These are not face identities or general instance segmentation.
- Learned reference region/context targets require three distinct supported image encodings; image pairs learn observed regional transforms in registered valid overlap. Reference lighting/content confounders remain. Unsupported/missing models withhold semantic evidence explicitly.
- Added visual tone/color fingerprint suggestions, one-click trials, reset, keyboard shortcuts and full-width wipe comparison. Settings move into a scrolling side panel while original/styled previews and exports stay visible; mixing/composition controls are grouped separately.
- JPG exports include local region/face effects. XMP exports remain approximate global presets and do not serialize Adobe semantic masks. Original bytes and GPS exclusion remain intact.
- Refined hybrid region changes to replace only the contributing component effect; stale preview results retain decoded/recognized inputs for the latest adjustment. Neutral/monochrome behavior and mask-tile skipping are verified.
- Style DNA schema2 / engine0.5.0 upgrades legacy0.4.0 schema1 recipes on read; SQLite remains3 and historical analysis profiles remain readable. New0.5 profiles/recipes require the new app.
- Real-model execution and region learning/application passed with network denied using external test-only photos. Tests and native-platform limits are recorded in VALIDATION.md.

## V0.4.0 - Style application, portable recipes and faster analysis

- Unified learned pair transforms, recorded XMP settings, finished-JPG references and bundled profiles into validated Style DNA (schema 1).
- Added a style workspace with original/edited previews, strength adjustment, two-style mixing, 12 derived film/cinema/artist profiles and saved recipes.
- Adapted reference targets to each input's tone distribution; optional low/mid/high-key subprofiles require three distinct supporting images. These are pixel-lighting groups, not semantic scene recognition.
- Added full-resolution JPEG copies with sRGB ICC and stripped EXIF/GPS, Lightroom-importable global XMP presets, and local style JSON import/export. Existing files are never overwritten.
- Composition remains color-only by default; users can show an aspect-ratio guide or explicitly crop an exported copy. No original is cropped.
- Added content-addressed, bounded SQLite analysis caching and pre-decode exact-duplicate exclusion; similar-image groups are review hints and remain included.
- Added analysis snapshot rename/delete, additive database schema 3, source preview reuse and deprecated Pillow API cleanup. Existing schema-0/1/2 data and 0.3.0 analysis snapshots remain readable; older apps cannot open schema 3.
- Corrected color-transform learning to subtract the observed tone transfer before measuring residual color. App/analysis versions are 0.4.0; analysis payload schema remains 1.
- Retained the embedded Mac component fix. Native Mac installation, Apple signing/notarization, semantic scene/local-mask models and exact Adobe rendering remain pending.

## Implemented - V0.3.1 Mac packaging repair

- [x] Use an embedded fragment URL for the component package.
- [x] Validate product references, required installation data and component identity/version before archive bytes.
- [x] Add regressions rejecting the previous external-relative reference.
- [ ] Confirm the corrected installer with Apple Installer on native M1 hardware.

## Implemented - V0.3.0

- [x] Continue Choose folder into RAW + JPG / RAW + XMP / JPG reference modes.
- [x] Review discovered files, exclude entries and resolve missing or ambiguous companions manually.
- [x] Decode RAW sensor data locally with rawpy/LibRaw and a recorded fixed camera-WB sRGB baseline.
- [x] Reuse registered tone/color analysis for RAW + edited JPG and label estimates as inferred.
- [x] Parse supported namespace-whitelisted global XMP parameters and RGB curves with bounds and safe XML handling.
- [x] Preserve missing/unsupported XMP semantics and separate recorded settings from rendered appearance.
- [x] Measure final JPG luminance/contrast/clipping, saturation, Lab/chroma, tonal zones, hue bands and palette.
- [x] Aggregate unique references with equal image weights, dispersion, consistency, sample limitations and appearance outliers.
- [x] Keep flagged outliers included until the user excludes them; deduplicate exact content only.
- [x] Add progress, per-file recovery and cancellation between files with completed results retained.
- [x] Show collection and individual results; save named analysis snapshots and reopen after app restart.
- [x] Add database schema 2 while preserving existing rows/settings; keep payload schema 1.
- [x] Update app/algorithm to 0.3.0 and include the RAW dependency in locked runtime/installer inputs.
- [x] Keep English/Korean resources, original preservation, GPS exclusion and local CPU execution.
- [x] Preserve the existing JPEG comparison workflow, summaries, curves, readability and display scaling.

## Implemented foundations

- [x] Modest crop/resize/rotation alignment with valid overlap and failure abstention.
- [x] Withhold photometric measurements for unreadable ICC profiles; keep inspectable geometry.
- [x] Separate inferred estimates, registration evidence, confidence and source hashes.
- [x] Cache/persist JPEG comparisons with stale-source and algorithm checks.
- [x] Provide private-runtime Windows x64 and macOS Apple Silicon/Intel installer tooling and diagnostics.
- [x] Provide pinned dependency files, synthetic analysis fixtures and a local-Xvfb GUI test runner.

## Validation and refinement

- [ ] Complete real-camera RAW, diverse XMP and reference-photo evaluation; calibrate heuristic confidence.
- [ ] Evaluate fast/full RAW color and fine-detail differences on real camera CFA/compression/layouts before extending fast-preview eligibility.
- [ ] Verify metadata and lens correction on actual RAWs, including Sony A7CR; add FE16–35 GM II only with a reliable exact optical calibration.
- [ ] Detect and validate in-camera APS-C/digital crop sensor geometry before applying full-sensor calibrations to those modes.
- [ ] Evaluate separate TCA, vignetting, fisheye and genuine Adobe lens-profile support without guessed data or fabricated XMP identities.
- [ ] Improve filename ambiguity, visual pairing, unsupported-camera guidance and near-duplicate detection.
- [ ] Expand alignment coverage without fabricating general perspective/local-edit support.
- [ ] Evaluate saturation/vibrance and hue-band residuals on real edits with local masks, clipping and sparse colors.
- [ ] Calibrate local-contrast/texture appearance targets on diverse photos without confusing content, focus or lighting with style.
- [ ] Refine implemented fine-detail/noise inference across real RAW resampling; investigate grain intent without treating arbitrary noise as a recorded edit.
- [ ] Extend supported XMP properties with explicit missing-value and rendering limits.
- [ ] Run native installer CI on Windows x64, macOS Apple Silicon and macOS Intel.
- [ ] Verify actual Windows DPI and macOS Retina/monitor transitions and usable viewport limits.
- [ ] Sign Windows releases and sign/notarize macOS releases.

Completed automated runs and artifact checks are recorded in `VALIDATION.md`; checklist items above do not substitute for that evidence.

## Style application and remaining work

- [x] Build shared application-ready Style DNA while preserving each source's evidence and uncertainty.
- [x] Apply saved styles to new images with strength controls and before/after previews.
- [x] Add derived built-in film/cinema/artist profiles and Hybrid Style mixing.
- [x] Add semantic multilabel scene coverage and scene-specific profile deltas.
- [ ] Extend implemented regional styling to precise non-person masks and local-edit reconstruction, composition scoring and user-approved crop suggestions.
- [x] Export non-destructive global XMP presets and validate round-trip supported settings.
- [ ] Evaluate preset import and appearance in actual Lightroom versions.
- [ ] Provide local model packs with mandatory CPU fallback.

V0.4.0 applies learned styles and exports JPG copies, global XMP presets and style JSON. All future work preserves offline execution, source bytes, GPS exclusion and selectable English/Korean. Mobile development remains outside scope.
