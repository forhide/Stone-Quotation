# Personal Color Lab V0.5.6

A desktop application that learns photographic editing preferences from **RAW + edited JPG**, **RAW + XMP**, or **finished JPGs alone**, including different tendencies for day, night, portraits, landscapes, food and other scenes. Choose a folder, review the photos and their scenes, analyze and save a style, then apply it to a new JPG/RAW with before/after previews, adjustable strength and safe exports. All processing runs locally; original photos remain unchanged.

## Read and apply more than brightness

V0.5.6 brings contrast, saturation, vibrance, hue-band changes, clarity and texture into the analysis overview. The style workspace also shows the effective parameters and their evidence: **recorded settings**, **inferred changes**, **final appearance**, or **unmeasured**. An unmeasured control stays unknown; a neutral fallback is not evidence of a recorded zero.

RAW + XMP learns supported recorded clarity, texture, sharpening amount/radius/masking and luminance/color noise reduction. These controls now affect the app's previews and exported JPG copies through local, approximate filters. RAW + JPG and JPG pairs estimate structural changes after registration and removal of the global tone transform; uncertain alignment, resampling, clipping and inadequate detail suppress unsupported estimates. Saturation and vibrance are fitted together where the observed colors support both, and hue-band residuals avoid applying the global saturation change twice.

Finished JPGs describe visible local contrast and texture, including their subjects, focus, lighting, resizing and compression. At least three distinct supported references can supply a conservative appearance target. JPG-only analysis does not recover clarity, sharpening, noise-reduction or grain sliders from an editing history. Fine detail lost by downsizing cannot be reconstructed from a bounded analysis preview.

The renderer approximates Lightroom-style controls; it does not reproduce Adobe pixels. Recorded numeric controls without a pixel implementation, such as Dehaze, camera calibration and parametric tone controls, are identified as **XMP-only**. Supported safe numeric settings can be retained in an XMP preset from a recorded-XMP style, but they do not silently affect the app's JPG. No new runtime dependency, model or API is required.

## Apply and export a style

Click **Apply style** in the sidebar or on an analysis result. Choose a new JPG/RAW, select a learned style or one of 12 bundled profiles, and adjust strength. Optionally mix a second style. The original and styled previews update side by side. Export a new full-resolution JPG, an approximate Lightroom-importable global XMP preset, or a portable style JSON. Save recipes locally to reuse them. Composition defaults to color-only; optional aspect-ratio guides/cropping affect copies only.

RAW uses full-quality AHD development by default. You can explicitly enable **Fast RAW preview** for a quicker, approximate view of supported large RGB Bayer sensors. Its badge identifies the active mode; unsupported CFA layouts, unusual geometry and small photos retain full-quality development. Color and fine details can differ from the final result. JPG exports always use the full-quality baseline, and XMP export prepares adaptive settings from that baseline with the current scene and optical selections. The fast view develops sensor pixels and does not substitute an embedded camera JPEG.

## RAW camera and lens correction

V0.5.4 reads camera make/model, lens make/model, focal length and aperture from supported RAW headers. In the style workspace, **Lens distortion correction** is enabled by default and applies a verified local profile only when the camera, lens, focal length and calibration geometry match uniquely. Missing or uncertain information keeps the developed RAW unchanged and displays the reason. Turn the control off to inspect the uncorrected development.

Use **Choose camera & lens…** to search the local camera/lens lists and select the exact equipment. Enter the actual focal length in millimeters when it is missing, or leave it blank to use the RAW metadata. Manual selection applies to the current photo, preserves the detected metadata, and does not create calibration data. **Use auto detection** returns to the detected equipment.

**Sony A7CR / FE 16–35mm F2.8 GM II:** the bundled database contains the camera, but this pinned official database has no GM II distortion calibration. The lens can be identified or selected manually; correction remains unavailable. The app never substitutes the first-generation GM profile for GM II.

Supported corrections use Lensfun's rectilinear poly3, poly5 or PTLens radial models. Correction follows full-quality or optional half-size sensor development and precedes resizing, color measurement and region recognition; final JPGs use one full-quality RAW development and matching corrected coordinates. Output dimensions stay the same, while fitting valid edges can narrow the field of view; the reported edge zoom makes this visible. Originals are untouched. RAW + edited JPG learning retains its previous optical-correction-off baseline, and geometry is not stored in Style DNA.

The local bundle retains 56 official [Lensfun database](https://github.com/lensfun/lensfun/tree/43f9e001ab66c4fcdd4f400463f13b72f94b2288/data/db) XML files and their CC BY-SA 3.0 attribution, pinned to commit `43f9e001ab66c4fcdd4f400463f13b72f94b2288`. Its 1,057 camera entries, 1,571 lens entries and 6,458 distortion calibration points are inventory counts, not a claim that every entry is supported. Chromatic aberration, vignetting, fisheye correction and Adobe LCP profiles are not implemented. DNGs with embedded opcode instructions are conservatively left without an additional warp when geometry/application state is uncertain. The current geometry assumes the camera's full physical sensor; in-camera APS-C/digital crop modes are not automatically identified or calibrated, so keep correction off for those inputs until verified. Actual camera and native M1 validation remains pending.

Lens correction affects previews and new JPGs. **XMP exports supported global settings only**; it contains no Lensfun warp, Adobe lens-profile identity or local object masks. The installed app includes the equipment reader and calibration data and performs no runtime downloads.

## Style processing and prior improvements

Repeated folder analysis reuses valid content-hash results and skips exact duplicates before decoding. Similar photos remain included and are flagged for review. Saved analysis snapshots can be renamed/deleted without changing photos.

Reference photos describe final appearance including lighting; XMP presets cover supported global controls and do not exactly reproduce Adobe rendering. Embedded ONNX models recognize 80 COCO object classes, segment people and detect faces. These region models are separate from the V0.5.5 photo-scene classifier. Learned regional targets, optional face protection and mask previews let you review local effects. Sky/terrain pixel segmentation and Adobe local-mask export remain future work.

Supported pure monochrome references and original/edited pairs now preserve black-and-white intent when applied to a new photo. Mixed-color or sepia references retain their color. Reanalyze historical paired inputs to add the new monochrome evidence. V0.5.1 also improves cache recovery, cancellation, export staging and workspace state preservation.

V0.5.2 adds photo-based style previews, a larger comparison stage, right-side controls, native-vector sliders/toggles, direct wipe dragging and expandable details. Build/apply entry cards and source steps clarify what to do next. Local processing removes repeated calculations without reducing resolution or model thresholds; [PERFORMANCE.md](PERFORMANCE.md) records measured timings and their limits.

V0.5.3 reads RAW dimensions before unpacking sensor data, checks cancellation between native processing stages, and removes the second full RAW development from JPG export. Full-quality analysis and exports retain the fixed AHD baseline. Style rendering precomputes source-level mappings and curve segments and reuses mask coordinates; the measured regression fixtures retain the same output pixels. Preview reuse checks source content, RAW quality and model identity. Missing recognition models retain global styling with an explicit notice. Timings and synthetic RAW quality differences are scoped in [PERFORMANCE.md](PERFORMANCE.md); native camera and operating-system calibration remains pending.

## Choose a folder and continue

1. Click **Choose folder**. The extraction window opens and scans the folder; the subfolder option controls recursive scanning.
2. Select **RAW + JPG**, **RAW + XMP**, or **JPG references**. Check the proposed files before analyzing. A JPG-only folder uses the reference route without asking for an original.
3. In **Review files**, exclude photos you do not want. Use **Choose matching file** for missing or ambiguous RAW companions, including files with different names or folders. Filename matches are suggestions, not proof of a correct pair. Select a photo and use **Review scene…** to assign known attributes now, or leave it on automatic detection.
4. Click **Analyze selected files**. Progress identifies the current file. **Cancel** stops at the next supported processing checkpoint and keeps completed results; a failed file does not discard other results.
5. Read the **Style summary**, parameter evidence, **Scene coverage** and individual results. Correct automatic estimates with **Review scene…**; completed measurements are reused when you change a scene. **Use automatic detection** restores the estimate. Leaving all attributes unspecified explicitly uses the common style.
6. Enter a **Style name** and click **Save style**. Reopen it through **Saved styles**, including after restarting the app. Category learning needs at least three eligible, distinct original photos per category; fewer photos still build a common style.
7. Click **Apply style**, choose a new photo and review its automatic scene or select it manually. Check the before/after view, effective parameter evidence and the scene tendencies actually used, adjust strength, then export a new JPG or an approximate global XMP preset. Scene-specific and region changes appear in the JPG; XMP has no semantic masks or Lensfun geometry.


| Input | What is extracted | Meaning of the result |
| --- | --- | --- |
| RAW + edited JPG | Registered tone/color changes, tone transfer, saturation/vibrance fit, hue-band residuals and supported multiscale detail changes | Inferred changes relative to the app's fixed RAW development baseline; unsupported fine-detail estimates remain unknown |
| RAW + XMP | Supported recorded global parameters and RGB tone curves, including clarity, texture, sharpening and noise controls | Values actually present in the selected sidecar; missing values stay unknown, and pixel-applied versus XMP-only settings are distinguished |
| Finished/reference JPGs | Brightness, contrast, saturation, Lab/chroma, tonal zones, hue bands, palette, local-contrast/texture appearance and collection tendencies | Final visible appearance, including subject, focus, lighting and camera rendering; supported structural targets need at least three distinct photos |

For JPG collections, each unique file contributes equal weight. Byte-identical duplicates contribute once. The result records dispersion, heuristic consistency, sample limitations and appearance outliers; outliers remain included until you exclude them and analyze again. Reference category strength also considers perceptual diversity where fingerprints are available. RAW routes use distinct original-file hashes rather than claiming near-duplicate detection.

**Compare two photos** remains available for original/edited JPEG pairs, without matching filenames or folders. Confirm the labeled previews and direction, then read **Changes at a glance** or **Detailed measurements**. The inspector shows brightness, WB/tint, contrast, saturation, clarity, texture and shared geometry, together with a measured brightness-mapping curve and local saved-analysis lookup. Current-session direct selections are deduplicated and labeled **Chosen by you**.

English is the default UI language; Korean is selectable. The dark graphite/lime interface retains readable point-sized fonts and display scaling. Windows configures DPI awareness before opening Tk; macOS uses native system fonts and the bundled Tk Retina path. Actual native display and monitor-transition validation remains pending; large display scales may need more usable desktop space.

## Scene-specific styles

The bundled Microsoft TinyCLIP image encoder estimates **21 attributes across five axes** from photo content. It runs on CPU through OpenCV, with precomputed prompt vectors and verified local assets; inference needs no Torch, API, internet connection or token payment. Its weight-only INT8 image model is about 8.6 MB and carries the upstream MIT license. The existing object/person/face models remain separate.

| Axis | Supported attributes |
| --- | --- |
| Time | Day, golden hour, blue hour, night |
| Environment | Indoor, outdoor |
| Subject | Portrait, landscape, city/street, architecture, food, still life, animals |
| Lighting | Natural light, warm artificial light, neon, mixed light |
| Exposure | Low light, backlit, high dynamic range, strong highlights |

A photo can be both a night portrait and an outdoor scene. Time and environment accept at most one choice each; the remaining attributes can overlap. Automatic labels describe visible cues, not a verified capture time, and their scores are estimates rather than calibrated probabilities. The classifier can leave attributes unknown. Review uncertain labels before learning or applying a style.

RAW + JPG classification uses the full original scene in a bounded RAW development, rather than the edited JPG's brightness or a cropped registration overlap. RAW + XMP reads the original through a bounded 1024-pixel baseline development for scene evidence only: recorded XMP settings and their confidence remain unchanged. A RAW scene-decode failure does not discard readable XMP parameters; manual classification remains available. JPG-only classification uses the finished image, so edits, subject colors and original lighting can influence its labels and learned appearance.

Learning combines the common style with conservative category differences, rather than building a separate preset for every label combination. Each category needs at least three eligible unique original hashes. Multiple edits of the same original are not independent samples; conflicting edited results are withheld from category learning, and conflicting manual labels require review. Category strength is reduced for sparse, uncertain or insufficiently diverse evidence. Overlapping attributes share bounded weight, and an unsupported or unspecified scene falls back to the common style. Three files alone do not establish a reliable photographic preference.

You can review scenes before analysis, revise completed or saved analysis entries without decoding the photos again, and override the scene of the current application photo. Manual choices preserve the automatic evidence. Older saved analyses have no automatic scene evidence until reanalyzed; assigning labels manually can make existing valid measurements usable for category learning. Saving retains your reviewed assignments. This scene learning is separate from local object masks, lens calibration and face protection.

## Install or run from source

For installation without Python, use Windows x64 setup.exe or the macOS Apple Silicon/Intel .pkg. See [INSTALLERS.md](INSTALLERS.md) for requirements, checksums, rebuilding and validation limits.

Source development requires Python 3.11+ with Tkinter, Pillow, NumPy, headless OpenCV, rawpy/LibRaw and ExifRead. On Linux, install the distribution's `python3-tk` package if needed. A desktop display is required for the GUI; no web server, mobile SDK or GPU is needed.

```bash
python -m venv .venv
```

Activate with `source .venv/bin/activate` on macOS/Linux or `.venv\Scripts\Activate.ps1` in Windows PowerShell.

```bash
python -m pip install -r requirements.lock
python run_app.py
```

Dependency installation can use the network. The installed application does not use accounts, APIs, telemetry or uploads. `requirements.lock` pins five runtime dependencies, including rawpy 0.25.1 with LibRaw 0.21.4 and the pure-Python ExifRead 3.5.1 equipment reader; `requirements.txt` retains ranges for deliberate updates. Installer builds verify the separate object/face model, photo-scene model and Lensfun XML/license inventories.

## Development checks

```bash
python -m pip install -r requirements-dev.lock
python -m pytest
```

For the full suite including GUI checks on headless Linux, use a local Xvfb:

```bash
python tools/run_gui_tests.py -q
# If Xvfb is not in PATH:
PERSONAL_COLOR_LAB_XVFB=/path/to/Xvfb python tools/run_gui_tests.py -q
```

The runner downloads nothing and uses an existing display when available. Archive checks need `bsdtar` in PATH or `PERSONAL_COLOR_LAB_BSDTAR`; they are explicitly skipped without it. Tests cover analysis, source preservation, migrations, persistence and desktop flows. [VALIDATION.md](VALIDATION.md) records completed runs and their platform limits; it is the authority for final test counts and artifact verification.

The separate parameter diagnostic creates temporary synthetic RGB/RAW inputs, denies network access, exercises analysis/style application and exports, and preserves source hashes:

```bash
python tools/verify_photo_parameters.py --report /tmp/pcl-photo-parameters.json
```

It verifies supported parameter wiring and offline behavior, not Adobe pixel equivalence or photographic quality across real camera libraries.

The retained V0.5.3 Linux source checkpoint completed **678 tests with no failures, errors or skips**, with warnings treated as errors. Completed release checks belong in [VALIDATION.md](VALIDATION.md); prior counts do not establish V0.5.6 results. Generated RAW/equipment fixtures and package checks do not establish camera-specific calibration or native Windows/macOS installation.

## Local data and upgrades

The default local files are `~/.personal_color_lab/library.db` and `~/.personal_color_lab/settings.json`. Set `PERSONAL_COLOR_LAB_DATA_DIR` to use another directory.

The database stores paths, allowed non-location metadata, derived measurements, source hashes, confidence/provenance and saved analysis snapshots. It does not copy the photo library or persist GPS coordinates. The equipment reader returns a bounded camera/lens whitelist, excluding serial numbers, owners, dates and complete EXIF dictionaries. V0.5.6 retains database schema 3 introduced in V0.4.0 and preserves schema-0/1/2 rows and settings. App/analysis versions are 0.5.6; analysis/profile payloads remain 1. Style DNA is schema 4/engine 0.5.6; its detail profile and scene-profile schema 2 carry supported spatial controls and their evidence. Legacy DNA 1/engine 0.4.0, DNA 2/engine 0.5.0 and DNA 3/engine 0.5.5 are validated and upgraded in memory without modifying supplied data. Their existing rendering remains active, with neutral new detail controls; DNA 3 retains its supported scene recipes. Reanalyze historical inputs and save a new style to learn the new parameters. New analysis profiles and DNA 4 recipes require V0.5.6. Portable style JSON imports are limited to 2 MiB. Earlier source snapshots through V0.5.5 remain readable. Apps predating database schema 3 cannot open it; back up the data folder before downgrading. Earlier comparison records are retained, but old algorithm results require reanalysis for a current comparison.

## Analysis boundaries

- RAW analysis and final exports use full AHD sensor development through rawpy/LibRaw, camera white balance when available, explicit sRGB output and disabled automatic brightness. The optional fast display is an approximate half-size Bayer development. Neither mode substitutes an embedded JPEG or reproduces Lightroom defaults. Unsupported or corrupt RAW files fail explicitly; supported camera coverage follows LibRaw. Header dimensions above 120 megapixels are rejected before sensor unpacking. Cancellation is cooperative at checkpoints; an active native LibRaw call must finish before it can stop.
- Equipment EXIF support is separate from pixel decoding: TIFF-family RAW headers, adapted ORF/RW2 layouts, RAF embedded EXIF and Canon CR3 CMT1/CMT2 are read within bounds. A numeric/encrypted MakerNote lens ID without a trustworthy textual lens model remains unknown. Calibration availability can differ from camera decoding support; metadata errors do not prevent otherwise valid RAW development.
- Pair registration supports modest crop, resize and rotation. General perspective changes, strong warps and local edits are outside this milestone. Unreliable alignment suppresses tone/color estimates.
- JPEG analysis honors EXIF orientation and valid local ICC-to-sRGB conversion. Untagged input is treated as sRGB. Unreadable profiles produce explicit color uncertainty instead of unverified color measurements.
- XMP parsing accepts a bounded whitelist of global Camera Raw settings and curves. Local masks, unsupported properties and unavailable custom profiles are not reproduced. The RAW/sidecar association must be checked by the user; a filename or file hash cannot prove that the sidecar belongs to the photo. Recorded values do not establish equivalent rendered pixels.
- A warm JPG appearance is not a recovered white-balance value. Lighting, subject color and camera processing can explain apparent tendencies. Reference confidence/consistency and comparison confidence are heuristics, not calibrated probabilities.
- Spatial analysis is bounded to 1024 pixels on the long edge. Resizing, shifts, JPEG artifacts and sensor noise can conceal or mimic sharpening/noise changes; uncertain fine-detail controls remain unmeasured. Reference local contrast and texture are weak final-appearance targets, with no automatic recovery of sharpening, denoise or grain settings.
- Recorded Dehaze, camera calibration, parametric tone and other identified XMP-only numeric controls do not affect JPG pixels. Their safe sidecar passthrough is restricted to recorded-XMP styles; hybrid styles do not copy one component's unsupported settings as though they described the entire mix.
- Exact duplicates are excluded before decoding. Similar-image hints remain included for review. New scene-aware styles use the common profile plus supported multilabel category differences; older styles retain their legacy brightness/context behavior. Uncertain automatic labels and sparse category evidence retain a common-style fallback. Whole-photo scene classification does not provide sky/terrain pixel masks.

Style application, embedded object/person/face recognition, supported regional learning, strength/hybrid mixing, built-in profiles and approximate global XMP presets are implemented. Sky/terrain segmentation, precise non-person masks and Adobe local-mask export remain future work. Mobile development is outside the current scope. See [ROADMAP.md](ROADMAP.md) and [TODO.md](TODO.md).
