extends SceneTree

# Exercise the real user-start and route callbacks with story enabled. Existing
# combat suites deliberately skip narration; this suite must not inherit that.
var checks := 0
var failures := 0
var room
var original_skip := ""
var original_profile := ""
var had_skip := false
var had_profile := false
var had_seen := false
var original_seen: Variant
var profile_path := ""

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, description: String) -> void:
	checks+=1
	if ok: print("PASS: "+description)
	else:
		failures+=1
		push_error("FAIL: "+description)

func frames(count: int=3) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.physical_keycode=code
	event.pressed=true
	Input.parse_input_event(event)
	event=event.duplicate()
	event.pressed=false
	Input.parse_input_event(event)

func freeze_foes() -> void:
	for enemy in room.enemies: enemy.active=false
	room.player.invulnerability=1000

func clear_fight_fixture() -> void:
	# Defeat fixtures through the public health component. Boss combat rules are
	# verified by grimoire.gd; this suite tests actual route/narrative callbacks.
	for enemy in room.enemies.duplicate(): enemy.health.damage(99999)

func run() -> void:
	had_skip=OS.has_environment("MEOW_SKIP_STORY")
	original_skip=OS.get_environment("MEOW_SKIP_STORY")
	had_profile=OS.has_environment("MEOW_PROFILE_PATH")
	original_profile=OS.get_environment("MEOW_PROFILE_PATH")
	had_seen=root.has_meta("meow_opening_seen")
	original_seen=root.get_meta("meow_opening_seen",false)
	root.remove_meta("meow_opening_seen")
	OS.set_environment("MEOW_SKIP_STORY","0")
	profile_path="/tmp/meow-story-%d-%d.json" % [OS.get_process_id(),Time.get_ticks_usec()]
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames()
	room=current_scene
	check(room.story_enabled() and room.state=="intro","narrative suite explicitly enables the real user story path")
	var director: StoryDirector=room.story_director
	check(director.story.get("hero","")=="Meowmalade" and director.story.get("school","")=="Arcana Academy","runtime story identifies Meowmalade and Arcana Academy")
	check(director.story.get("chapters",[]).size()==8,"all eight expedition areas have authored runtime story pages")
	var copy: Dictionary=director.story
	var opening_copy := ""
	for page: Dictionary in copy.opening: opening_copy+=str(page.text)+" "+str(page.text_en)+"\n"
	check(opening_copy.contains("지하 창고") and opening_copy.contains("basement storeroom") and not opening_copy.contains("별관"),"original underground detention is restored in both story languages")
	check(ArchiveBackdrop.STORAGE.resource_path.ends_with("hd_basement_storeroom.res"),"detention and the last basement rest use the authored cellar artwork instead of sunny windows")
	var cause_and_effect := str(copy.chapters[0].beats[1].text)+str(copy.chapters[1].beats[3].text)
	check(cause_and_effect.contains("원인") and cause_and_effect.contains("보랏빛") and cause_and_effect.contains("따라"),"the cat follows the source of the disturbance from detention to the library")
	check(str(copy.chapters[1].beats[3].text).contains("같은 높이") and str(copy.chapters[1].beats[3].text).contains("떠") and str(copy.chapters[2].beats[0].text).contains("버섯"),"original floating books and unnatural mushroom pattern remain actual story events")
	var bloop: Dictionary=copy.chapters[4].beats[1]
	check(str(bloop.text).contains("모르겠어") and str(bloop.text_en).contains("no idea") and not str(bloop.text).contains("매번 똑같"),"Bloop's explosions remain unpredictable rather than contradicting the core premise")
	check(str(copy.chapters[5].beats[0].text).contains("기록") and str(copy.chapters[5].beats[0].text).contains("도시") and str(copy.chapters[5].beats[1].text).contains("선택"),"the discovered city-accident record explains why the Grimoire removes choice")
	var landmarks_match := true
	var painter := ArchiveBackdrop.new()
	for index in range(8):
		painter.configure(index)
		landmarks_match=landmarks_match and PackedStringArray(copy.chapters[index].landmarks)==painter.narrative_landmarks()
	check(landmarks_match,"each chapter's concrete story landmarks are rendered by its actual stage painter")
	var books := painter.floating_book_positions()
	var book_spacing := true
	for index in range(1,books.size()): book_spacing=book_spacing and books[index]-books[index-1]==Vector2(91,0)
	check(books.size()==8 and book_spacing,"library book formation visibly shares height and exact spacing")
	var mushrooms := painter.mushroom_positions()
	var mushroom_grid := true
	for row in range(3):
		for column in range(6): mushroom_grid=mushroom_grid and mushrooms[row*6+column]==Vector2(350+column*104,320+row*63)
	check(mushrooms.size()==18 and mushroom_grid,"garden mushrooms are painted in the original regular grid rather than ordinary flowerpot rows")
	painter.free()
	room.request_begin()
	await frames(2)
	check(room.state=="story" and director.is_open and director.mode=="opening","user start opens the actual animated opening before combat")
	check(not room.player.active and room.profile.attempts==0,"opening leaves combat inactive and does not begin the run early")
	check(director.screen.visible and director.speaker_label.text=="ARCANA ACADEMY","opening renders the academy dialogue window")
	check(director.stage.hero.texture!=null and director.stage.hero.texture_filter==CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS,"cutscene uses the actual smooth full-body storybook hero artwork")
	check(director.stage.location_backdrop.show_behind_parent,"shared room illustration stays behind the story report cards, analysis panel and spell effects")
	var first_page: int=director.page_index
	director.elapsed=float(director.pages[first_page].duration)-0.001
	await frames(2)
	check(director.page_index==first_page+1,"opening advances timed illustrated beats automatically")
	director.auto_advance=false
	var before_enter: int=director.page_index
	key(KEY_ENTER)
	await frames(2)
	check(director.page_index==before_enter+1 and room.state=="story","Enter advances one story page without starting gameplay behind it")
	var before_space: int=director.page_index
	key(KEY_SPACE)
	await frames(2)
	check(director.page_index==before_space+1 and not room.spells.pending and room.projectiles.get_child_count()==0,"Space advances narration without firing a spell")
	key(KEY_I)
	await frames(2)
	check(not room.panel.is_open and room.state=="story","story input capture prevents opening inventory underneath dialogue")
	var restored_page: int=director.page_index
	var detention_matches := true
	for opening_page in range(11,14):
		director.page_index=opening_page
		director._show_page()
		detention_matches=detention_matches and director.stage.location_index==0 and director.stage.location_backdrop._location_art()==room.backdrop_painter._location_art()
	check(detention_matches,"opening detention pages preview the actual basement storeroom instead of the examination hall")
	director.page_index=restored_page
	director._show_page()
	key(KEY_ESCAPE)
	await frames(4)
	check(not director.is_open and room.state=="playing" and room.profile.attempts==1,"Escape skips opening into exactly one real expedition")
	check(not room.spells.pending and room.projectiles.get_child_count()==0,"returning from story does not leak a held cast input")
	freeze_foes()
	var speakers: Dictionary={}
	for next_index in range(1,8):
		if not room.exit_open: clear_fight_fixture()
		await frames(2)
		check(room.exit_open,"route area %02d can be completed before its next story chapter" % next_index)
		var accepted: bool=room.advance_sector()
		await frames(2)
		check(accepted and room.run.stage_index==next_index and room.state=="story","actual route advance opens story for area %02d" % (next_index+1))
		director=room.story_director
		check(director.is_open and director.mode=="chapter" and director.chapter_index==next_index,"area %02d selects its matching authored chapter" % (next_index+1))
		check(not room.player.active and not room.advance_sector(),"chapter %02d pauses combat and rejects an accidental second route advance" % (next_index+1))
		for page in director.pages: speakers[str(page.speaker)]=true
		var chapter_matches := true
		for preview_page in range(director.pages.size()):
			director.page_index=preview_page
			director._show_page()
			var preview: ArchiveBackdrop=director.stage.location_backdrop
			chapter_matches=chapter_matches and director.stage.location_index==next_index and (preview.visible or director.stage.exam_flashback) and not preview.include_frame and preview.theme_id()==room.backdrop_painter.theme_id() and preview._location_art()==room.backdrop_painter._location_art()
		check(chapter_matches,"every dialogue pose in chapter %02d retains the playable room artwork and floor decorations" % (next_index+1))
		director.page_index=0
		director._show_page()
		if next_index==3:
			key(KEY_ESCAPE)
			await frames(3)
			check(room.state=="playing" and room.run.stage_index==3,"skipping Pip’s chapter resumes its shop rather than advancing again")
		else:
			while director.is_open: director.advance()
			await frames(3)
			check(room.state=="playing" and room.run.stage_index==next_index,"finishing chapter %02d resumes the same area" % (next_index+1))
		freeze_foes()
	check(speakers.has("PIP") and speakers.has("MOSS") and speakers.has("BLOOP"),"the playable route actually presents Pip, Moss and Bloop dialogue")
	check(speakers.has("THE PERFECT GRIMOIRE"),"the Grimoire’s control-and-prediction conflict is present in route dialogue")
	clear_fight_fixture()
	await frames(3)
	director=room.story_director
	check(room.state=="story" and director.is_open and director.mode=="ending","final victory opens the authored ending before the result overlay")
	check(room.profile.wins==1 and not room.player.active,"victory is saved while the ending remains paused")
	var report_seen := false
	var deadpan_seen := false
	var final_boom_seen := false
	var last_visual := ""
	var ending_locations_match := true
	while director.is_open:
		var page: Dictionary=director.pages[director.page_index]
		ending_locations_match=ending_locations_match and director.stage.location_index==(7 if director.page_index<6 else -1)
		last_visual=str(page.visual)
		if last_visual=="report":
			report_seen=true
			check(director.stage.visual=="report" and director.body_label.text.contains("World Saving") and director.body_label.text.contains("A+"),"ending displays the actual World Saving A+ report card")
		if report_seen and str(page.speaker)=="MEOWMALADE" and str(page.text)=="…": deadpan_seen=true
		if report_seen and deadpan_seen and last_visual=="boom": final_boom_seen=true
		director.advance()
	await frames(4)
	check(report_seen and deadpan_seen and final_boom_seen and last_visual=="end","ending reaches the report, deadpan reaction, final BOOM and end page")
	check(ending_locations_match,"ending stays in the actual Grand Archive until the explicit return to the academy")
	check(room.state=="cleared" and room.hud.overlay.visible and not director.is_open,"ending completion restores the real victory result screen")
	var callbacks := [0]
	director.play_opening(func(): callbacks[0]+=1)
	director.skip()
	director.skip()
	director.advance()
	await frames(2)
	check(callbacks[0]==1,"skip and repeated advance complete a sequence callback exactly once")
	director.play_opening(func(): callbacks[0]+=1)
	director.close()
	director.skip()
	await frames(2)
	check(callbacks[0]==1 and not director.is_open,"close cancels narration without invoking its completion callback")
	room.begin_or_restart()
	await frames(4)
	room=current_scene
	room.request_begin()
	await frames(3)
	check(room.state=="playing" and not room.story_director.is_open,"a later expedition skips the already-seen opening in the same application")
	await finish()

func finish() -> void:
	if is_instance_valid(current_scene): current_scene.queue_free()
	await frames(2)
	for suffix: String in ["",".tmp",".bak"]:
		var path: String=profile_path+suffix
		if FileAccess.file_exists(path): DirAccess.remove_absolute(path)
	if had_skip: OS.set_environment("MEOW_SKIP_STORY",original_skip)
	else: OS.unset_environment("MEOW_SKIP_STORY")
	if had_profile: OS.set_environment("MEOW_PROFILE_PATH",original_profile)
	else: OS.unset_environment("MEOW_PROFILE_PATH")
	if had_seen: root.set_meta("meow_opening_seen",original_seen)
	else: root.remove_meta("meow_opening_seen")
	print("STORY RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
