class_name SpellProjectile
extends Node2D

signal impacted(point: Vector2, damage: int, radius: float, direction: Vector2)
var direction := Vector2.RIGHT
var speed := 540.0
var lifetime := 2.3
var damage := 20
var radius := 9.0
var explosion_radius := 0.0
var outcome := "success"
var element := "fire"
var room: Node2D
var bounds: Rect2
var age := 0.0
var previous_age := 0.0
var spent := false
var flame_material: ShaderMaterial
var flame_mode := -1
var hit_ids: Array[int] = []
var maximum_hits := 1
var push_multiplier := 1.0
const FIRE_SURFACE: Texture2D = SpellArt.FIREBALL
const FIRE_SHADER: Shader = preload("res://scripts/effects/fireball.gdshader")
const FIRE_SCALE := 0.046
const FIRE_RECT := Rect2(-SpellArt.FIRE_CORE*FIRE_SCALE,SpellArt.FIRE_SIZE*FIRE_SCALE)
# Authored smooth silhouettes at combat scale; the paths are reused, rather
# than allocating a texture or particle emitter for every cast.
static var DROP := PackedVector2Array([Vector2(16.00,0.00),Vector2(12.48,-1.18),Vector2(9.52,-2.86),Vector2(6.95,-4.78),Vector2(4.58,-6.69),Vector2(2.25,-8.37),Vector2(-0.22,-9.55),Vector2(-3.00,-10.00),Vector2(-7.46,-8.94),Vector2(-10.55,-6.21),Vector2(-12.21,-2.44),Vector2(-12.42,1.71),Vector2(-11.15,5.60),Vector2(-8.35,8.58),Vector2(-4.00,10.00),Vector2(-0.85,9.87),Vector2(1.89,8.80),Vector2(4.40,7.11),Vector2(6.87,5.09),Vector2(9.50,3.03),Vector2(12.48,1.24),Vector2(16.00,0.00)])
static var ICE := PackedVector2Array([Vector2(17,0),Vector2(3,-9),Vector2(-10,-6),Vector2(-14,0),Vector2(-10,6),Vector2(3,9),Vector2(17,0)])
static var STONE := PackedVector2Array([Vector2(-14,-2),Vector2(-9,-11),Vector2(4,-12),Vector2(13,-5),Vector2(15,4),Vector2(7,11),Vector2(-7,10),Vector2(-14,4),Vector2(-14,-2)])
static var LEAF := PackedVector2Array([Vector2(17.00,0.00),Vector2(11.50,-4.83),Vector2(5.58,-8.13),Vector2(-0.32,-9.87),Vector2(-5.76,-9.97),Vector2(-10.32,-8.40),Vector2(-13.54,-5.09),Vector2(-15.00,0.00),Vector2(-12.44,5.30),Vector2(-8.48,8.48),Vector2(-3.56,9.76),Vector2(1.89,9.34),Vector2(7.42,7.43),Vector2(12.60,4.25),Vector2(17.00,0.00)])
static var SPARK := PackedVector2Array([Vector2(18,-3),Vector2(3,-4),Vector2(8,-11),Vector2(-14,-1),Vector2(-1,1),Vector2(-7,11),Vector2(18,-3)])

func configure_magic(id: String) -> void:
 element=str(BasicMagic.definition(id).id)
 var magic := BasicMagic.definition(element)
 speed*=float(magic.speed)
 radius*=float(magic.size)
 push_multiplier=float(magic.push)
 maximum_hits=2 if element=="wind" else 1

func _ready() -> void:
 texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
 reset_physics_interpolation()
 if element=="fire":
  flame_material=ShaderMaterial.new()
  flame_material.shader=FIRE_SHADER
  material=flame_material

func _physics_process(delta: float) -> void:
 if spent: return
 previous_age=age
 age+=delta
 if element=="leaf": _steer_leaf(delta)
 # Substeps prevent tunnelling through an enemy at low frame rates.
 var distance := speed*delta
 var steps := maxi(1,ceili(distance/8.0))
 # Defeat callbacks remove entries synchronously. One guarded snapshot for the
 # complete sweep is sufficient; defeated/freed handles are skipped below.
 # Copying this array for every8px substep caused avoidable cast-time churn.
 var collision_enemies: Array=room.enemies.duplicate()
 for i in range(steps):
  position+=direction*distance/steps
  if not bounds.has_point(position):
   impact()
   return
  for shelf in room.props:
   if is_instance_valid(shelf) and shelf.state!="fallen" and shelf.state!="falling" and position.distance_squared_to(shelf.position)<(radius+32)*(radius+32):
    if shelf.has_method("receive_magic"): shelf.receive_magic(element,direction,outcome)
    elif element=="fire": shelf.ignite(direction)
    else: shelf.topple(direction)
    impact()
    return
  for enemy in collision_enemies:
   if not is_instance_valid(enemy) or enemy.health.current<=0 or hit_ids.has(enemy.get_instance_id()): continue
   var hit_radius := radius+float(enemy.config.radius)
   if position.distance_squared_to(enemy.position)>hit_radius*hit_radius: continue
   if explosion_radius==0.0:
    _hit_enemy(enemy)
    hit_ids.append(enemy.get_instance_id())
    if hit_ids.size()<maximum_hits:
     _impact_art()
     continue
   impact()
   return
 if age>=lifetime: impact()
 queue_redraw()

func _process(_delta: float) -> void:
 # Transform interpolation moves the projectile between physics ticks; redraw
 # also keeps its local flame/leaf rotation on that same visual clock.
 if not spent: queue_redraw()

func presentation_age() -> float:
 if can_process() and is_physics_interpolated_and_enabled():
  return lerpf(previous_age,age,Engine.get_physics_interpolation_fraction())
 return age

func _steer_leaf(delta: float) -> void:
 var nearest: Node2D
 var nearest_distance_squared := 170.0*170.0
 for enemy in room.enemies:
  if not is_instance_valid(enemy) or enemy.health.current<=0: continue
  var offset: Vector2=enemy.position-position
  var distance_squared := offset.length_squared()
  if distance_squared<nearest_distance_squared and offset.normalized().dot(direction)>0.15:
   nearest=enemy
   nearest_distance_squared=distance_squared
 if nearest!=null:
  var turn := direction.angle_to((nearest.position-position).normalized())
  direction=direction.rotated(clampf(turn,-delta*1.6,delta*1.6)).normalized()

func _hit_enemy(enemy: Node2D) -> void:
 var before: int=enemy.health.current
 if enemy.has_method("take_spell_damage"): enemy.call("take_spell_damage",damage,direction,outcome)
 else: enemy.take_damage(damage,direction)
 if not is_instance_valid(enemy) or enemy.health.current>=before: return
 # A shielded boss never receives a free slow/push through its counterspell.
 enemy.knockback*=push_multiplier
 if element=="ice" and is_instance_valid(room.skills): room.skills.apply_status(enemy,0.85,0.56,false)
 if element=="water":
  for neighbor in room.enemies.duplicate():
   if not is_instance_valid(neighbor) or neighbor==enemy or neighbor.health.current<=0: continue
   if position.distance_to(neighbor.position)>48+float(neighbor.config.radius): continue
   var splash_direction: Vector2=(neighbor.position-position).normalized()
   if neighbor.has_method("take_spell_damage"): neighbor.call("take_spell_damage",maxi(1,roundi(damage*0.35)),splash_direction,outcome)
   else: neighbor.take_damage(maxi(1,roundi(damage*0.35)),splash_direction)

func _impact_art() -> void:
 if element=="fire" or not is_instance_valid(room): return
 var art := BasicMagicImpact.new()
 art.element=element
 art.position=position
 art.size=clampf(radius/9.0,0.7,2.6)
 room.projectiles.add_child(art)

func impact() -> void:
 if spent: return
 spent=true
 _impact_art()
 impacted.emit(position,damage,explosion_radius,direction)
 queue_free()

func _outline_shape(points: PackedVector2Array, fill: Color, outline: Color) -> void:
 draw_colored_polygon(points,fill)
 draw_polyline(points,outline,1.7,true)

func _draw() -> void:
 var size := radius/9.0
 var draw_age := presentation_age()
 if element=="fire":
  var next_mode := 1 if outcome=="miscast" else 2 if outcome=="overreaction" else 0
  if flame_mode!=next_mode:
   flame_material.set_shader_parameter("outcome_mode",next_mode)
   flame_mode=next_mode
  flame_material.set_shader_parameter("age",draw_age)
  draw_set_transform(Vector2(0,-20),direction.angle(),Vector2.ONE*size)
  draw_texture_rect(FIRE_SURFACE,FIRE_RECT,false)
  draw_set_transform(Vector2.ZERO)
  return
 var ink := BasicMagic.color(element)
 var outline := ink.darkened(0.28)
 var cream := Color("fff9e8")
 var flutter := sin(draw_age*17)*0.07 if element in ["water","leaf"] else 0.0
 draw_set_transform(Vector2(0,-20),direction.angle()+flutter,Vector2.ONE*size)
 # Two short motion strokes visually separate magic from thrown food.
 var trail := ink
 trail.a=0.48
 draw_line(Vector2(-26,-4),Vector2(-17,-3),trail,2.3,true)
 draw_line(Vector2(-31,4),Vector2(-19,4),trail,1.8,true)
 match element:
  "water":
   _outline_shape(DROP,ink,outline)
   draw_arc(Vector2(-3,-1),5,3.5,5.6,7,cream,2,true)
   draw_circle(Vector2(-20,7+sin(draw_age*18)*2),2.4,ink)
  "ice":
   _outline_shape(ICE,ink,outline)
   draw_colored_polygon(PackedVector2Array([Vector2(17,0),Vector2(3,-9),Vector2(-5,-2)]),Color("e5f5fa"))
   draw_line(Vector2(-11,0),Vector2(15,0),Color("f7ffff"),1.3,true)
   draw_line(Vector2(-22,-8),Vector2(-22,-2),cream,1.4,true)
   draw_line(Vector2(-25,-5),Vector2(-19,-5),cream,1.4,true)
  "wind":
   draw_arc(Vector2.ZERO,12,-0.6+draw_age*5,4.7+draw_age*5,19,outline,4.1,true)
   draw_arc(Vector2.ZERO,12,-0.6+draw_age*5,4.7+draw_age*5,19,ink,2.6,true)
   draw_arc(Vector2(3,0),5,0.6-draw_age*6,5.2-draw_age*6,12,cream,2,true)
   draw_line(Vector2(-19,-7),Vector2(-7,-7),ink,2.3,true)
  "stone":
   draw_set_transform(Vector2(0,-20),direction.angle()+draw_age*3.2,Vector2.ONE*size)
   _outline_shape(STONE,ink,outline)
   draw_colored_polygon(PackedVector2Array([Vector2(-8,-6),Vector2(3,-8),Vector2(8,-3),Vector2(-4,-1)]),Color("ede1cf"))
   draw_line(Vector2(3,7),Vector2(9,3),outline,1.6,true)
  "leaf":
   _outline_shape(LEAF,ink,outline)
   draw_line(Vector2(-11,0),Vector2(15,0),Color("f3f1c4"),1.7,true)
   draw_line(Vector2(-2,0),Vector2(3,-6),Color("f3f1c4"),1.3,true)
   draw_line(Vector2(2,0),Vector2(7,5),Color("f3f1c4"),1.3,true)
  "lightning":
   _outline_shape(SPARK,ink,outline)
   draw_line(Vector2(-3,-1),Vector2(11,-2),cream,1.7,true)
   draw_circle(Vector2(-21,sin(draw_age*30)*5),2.1,cream)
 draw_set_transform(Vector2.ZERO)
