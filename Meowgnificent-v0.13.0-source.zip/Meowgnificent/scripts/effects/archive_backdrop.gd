class_name ArchiveBackdrop
extends Node2D

# HD Pastel Storybook 2D: each location has a full-resolution hand-drawn scene.
# Room caches this painter once per arrival; gameplay draws one background quad.
const STORAGE: Texture2D = preload("res://art/hd/hd_basement_storeroom.res")
const LIBRARY: Texture2D = preload("res://art/hd/hd_academy_library.res")
const GARDEN: Texture2D = preload("res://art/hd/hd_forbidden_garden.res")
const ARCHIVE: Texture2D = preload("res://art/hd/hd_grand_archive.res")
const LIVING_REAGENTS: Texture2D = preload("res://art/enemies/living_reagents.png")
const THEMES := ["candlewick", "loose_ends", "sootbound", "kettle_quill", "restricted", "bellkeeper", "paper_moon", "final_exam"]
const STORY_LANDMARKS := [
	["basement", "violet_control_seal"],
	["synchronized_books", "violet_control_seal"],
	["equal_height_plants", "mushroom_grid", "violet_control_seal"],
	["picnic", "chicken"],
	["reading_room", "unruly_vines"],
	["ordered_tiles", "city_memorial"],
	["basement", "pink_picnic"],
	["archive_tome", "analysis_seal"]
]
const PAPER := Color("fff4d7")
const PAPER_EDGE := Color("d7b886")
var stage_index := 0
# Cutscenes reuse this exact environment painter without the gameplay HUD mat.
var include_frame := true

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func configure(index: int) -> void:
	stage_index=clampi(index,0,THEMES.size()-1)
	queue_redraw()

func theme_id() -> String:
	return THEMES[stage_index]

func narrative_landmarks() -> PackedStringArray:
	return PackedStringArray(STORY_LANDMARKS[stage_index])

func floating_book_positions() -> PackedVector2Array:
	var result := PackedVector2Array()
	for column in range(8): result.append(Vector2(336+column*91,254))
	return result

func mushroom_positions() -> PackedVector2Array:
	var result := PackedVector2Array()
	for row in range(3):
		for column in range(6): result.append(Vector2(350+column*104,320+row*63))
	return result

func _location_art() -> Texture2D:
	match stage_index:
		0,6: return STORAGE
		1,4: return LIBRARY
		2,3,5: return GARDEN
		_: return ARCHIVE

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,800),PAPER)
	var washes := [Color.WHITE,Color.WHITE,Color("f4f0ff"),Color("fff5e9"),Color("f2f8ff"),Color("eaf8f8"),Color("fff2f7"),Color.WHITE]
	draw_texture_rect(_location_art(),Rect2(0,0,1280,800),false,washes[stage_index])
	# Variants are soft flat floor decorations, never additional obstacles.
	match stage_index:
		0:
			for point in [Vector2(730,295),Vector2(850,390),Vector2(1030,490)]: _control_seal(point,17,0.18)
		1:
			_synchronized_books()
			for point in [Vector2(250,380),Vector2(615,520),Vector2(1005,625)]: _control_seal(point,17,0.15)
		2:
			_perfect_garden()
			_control_seal(Vector2(640,455),34,0.14)
		3:
			_picnic_mat(Rect2(350,350,580,274),Color("daeadb"),Color("fff4dc"))
			_chicken(Vector2(950,363))
		4:
			_reading_runners()
			_escaped_vines()
		5:
			_ordered_stepping_tiles()
			_reagent_beds(true)
			_city_memorial()
		6: _picnic_mat(Rect2(270,338,740,304),Color("efd9e5"),Color("fff3dc"))
		7: _control_seal(Vector2(640,202),35,0.23)
	if not include_frame: return
	# Light stationery framing follows the HUD. No pixel sampling or posterize.
	draw_rect(Rect2(0,0,1280,118),PAPER)
	draw_rect(Rect2(0,714,1280,86),PAPER)
	draw_rect(Rect2(0,114,1280,4),Color("e7cfa1"))
	draw_rect(Rect2(0,714,1280,4),Color("e7cfa1"))
	draw_line(Vector2(46,110),Vector2(1234,110),PAPER_EDGE,1,true)
	draw_line(Vector2(46,722),Vector2(1234,722),PAPER_EDGE,1,true)

func _rounded(rect: Rect2, fill: Color, outline: Color, radius: int, width := 1) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=outline
	style.set_border_width_all(width)
	style.set_corner_radius_all(radius)
	style.anti_aliasing=true
	draw_style_box(style,rect)

func _reading_runners() -> void:
	for x in [335.0,945.0]:
		var rect := Rect2(x-48,289,96,340)
		_rounded(rect.grow(3),Color(0.40,0.34,0.48,0.08),Color.TRANSPARENT,14)
		_rounded(rect,Color("d9cce4"),Color("b5a0bb"),12,2)
		_rounded(rect.grow(-7),Color(1,1,1,0.04),Color("efe0df"),7,1)
		for y in [319.0,459.0,599.0]:
			_flower_stamp(Vector2(x,y),12,Color("f7ecd7"))

func _ordered_stepping_tiles() -> void:
	# The Perfection influence makes garden paths unnaturally regular. These
	# are painted flush with the lawn; all remain walkable.
	for row in range(4):
		for col in range(6):
			var point := Vector2(286+col*119,303+row*86)
			_rounded(Rect2(point,Vector2(106,61)),Color("e6e8d5"),Color("c3d1bd"),14,1)
			draw_line(point+Vector2(15,8),point+Vector2(88,8),Color(1,1,0.9,0.45),1,true)

func _picnic_mat(rect: Rect2, base: Color, trim: Color) -> void:
	_rounded(rect.grow(4),Color(0.38,0.41,0.32,0.10),Color.TRANSPARENT,21)
	_rounded(rect,base,trim.darkened(0.13),18,2)
	_rounded(rect.grow(-8),Color(1,1,1,0.025),trim,12,2)
	# Quiet broad weave stripes keep this a soft illustrated picnic cloth,
	# rather than a pixel texture or a vivid checkered game board.
	for row in range(8):
		var at := rect.position+Vector2(16,16+row*(rect.size.y-32)/8.0)
		draw_line(at,Vector2(rect.end.x-16,at.y),Color(trim,0.16),11,true)
	for col in range(17):
		var at := rect.position+Vector2(18+col*(rect.size.x-36)/17.0,15)
		draw_line(at,Vector2(at.x,rect.end.y-15),Color(trim,0.13),9,true)
	for p in [rect.position+Vector2(29,28),Vector2(rect.end.x-29,rect.position.y+28),rect.end-Vector2(29,28),Vector2(rect.position.x+29,rect.end.y-28)]:
		_flower_stamp(p,12,trim)

func _flower_stamp(center: Vector2, radius: float, color: Color) -> void:
	for i in range(5):
		var petal := center+Vector2.from_angle(-PI/2+i*TAU/5)*radius*0.56
		draw_circle(petal,radius*0.40,color,true,-1,true)
	draw_circle(center,radius*0.22,color.darkened(0.15),true,-1,true)

func _shadow(center: Vector2, size: Vector2) -> void:
	draw_set_transform(center,0,size)
	draw_circle(Vector2.ZERO,1,Color(0.40,0.35,0.45,0.10),true,-1,true)
	draw_set_transform(Vector2.ZERO)

func _control_seal(center: Vector2, radius: float, opacity: float) -> void:
	# Quiet, permanent floor inscriptions are visually separate from coral
	# attack warnings. Their repeated form is the trail the story follows.
	var ink := Color(0.58,0.46,0.70,opacity)
	draw_set_transform(center,0,Vector2(1,0.44))
	draw_circle(Vector2.ZERO,radius,Color(ink,opacity*0.20),true,-1,true)
	draw_arc(Vector2.ZERO,radius,0,TAU,32,ink,1.5,true)
	var points := PackedVector2Array()
	for i in range(7): points.append(Vector2.from_angle(-PI/2+i*TAU/6)*radius*0.72)
	draw_polyline(points,ink,1.5,true)
	for i in range(3):
		var at := Vector2.from_angle(i*TAU/3)*radius*0.57
		draw_line(at,-at,ink,1,true)
	draw_set_transform(Vector2.ZERO)

func live_book_positions() -> PackedVector2Array:
	var points := PackedVector2Array()
	for column in range(6): points.append(Vector2(470+112*column,310))
	return points

func live_mushroom_positions(promenade: bool=false) -> PackedVector2Array:
	var points := PackedVector2Array()
	for row in range(2):
		for column in range(3): points.append(Vector2(560+200*column,350+200*row) if promenade else Vector2(565+180*column,340+180*row))
	return points

func _synchronized_books() -> void:
	if include_frame:
		# The six matching books are live actors. Only their patrol marks are
		# baked into the floor; the enemies can leave, attack and be defeated.
		for point in live_book_positions():
			_control_seal(point,21,0.20)
		return
	for point in floating_book_positions():
		_shadow(point+Vector2(0,27),Vector2(21,4.8))
		draw_set_transform(point,-0.07,Vector2.ONE)
		draw_colored_polygon(PackedVector2Array([Vector2(-21,-4),Vector2(-2,0),Vector2(-2,14),Vector2(-22,9)]),Color("c8b1db"))
		draw_colored_polygon(PackedVector2Array([Vector2(-2,0),Vector2(20,-6),Vector2(22,8),Vector2(-2,14)]),Color("bba6d3"))
		draw_colored_polygon(PackedVector2Array([Vector2(-20,-7),Vector2(-2,-2),Vector2(-2,10),Vector2(-20,5)]),Color("fff1cf"))
		draw_colored_polygon(PackedVector2Array([Vector2(-2,-2),Vector2(18,-9),Vector2(20,4),Vector2(-2,10)]),Color("fff7df"))
		for offset in [0,4]:
			draw_line(Vector2(-17,-2+offset),Vector2(-5,1+offset),Color("cdbca2"),1,true)
			draw_line(Vector2(2,0+offset),Vector2(15,-4+offset),Color("cdbca2"),1,true)
		draw_line(Vector2(-2,-2),Vector2(-2,11),Color("af8fbb"),1.5,true)
		draw_set_transform(Vector2.ZERO)

func _reagent_beds(promenade: bool=false) -> void:
	for point in live_mushroom_positions(promenade):
		_rounded(Rect2(point+Vector2(-43,-23),Vector2(86,46)),Color("d2c3a3"),Color("a9b392"),15,2)
		_rounded(Rect2(point+Vector2(-36,-17),Vector2(72,33)),Color("b9b698"),Color("e6d4ad"),11,1)
		for side in [-1,1]:
			var p := point+Vector2(side*29,2)
			draw_circle(p,3.0,Color("d4cfad"),true,-1,true)
		_control_seal(point+Vector2(0,4),26,0.23)
	# The same evenly spaced crops have left their beds and now block the path.

func _perfect_garden() -> void:
	if include_frame:
		_reagent_beds()
		for column in range(6):
			var point := Vector2(350+column*104,210)
			draw_line(point,point+Vector2(0,-20),Color("8ca789"),3,true)
			for side in [-1,1]: draw_circle(point+Vector2(side*7,-12),5.5,Color("b2c79b"),true,-1,true)
			draw_circle(point+Vector2(0,-24),7.5,Color("d6d4af"),true,-1,true)
		return
	# Equal height, equal spacing: the original storyboard's disturbance is
	# visible in the actual room, not merely described over ordinary flowers.
	for point in mushroom_positions():
		_shadow(point+Vector2(0,5),Vector2(16,3.4))
		_rounded(Rect2(point+Vector2(-4,-13),Vector2(8,17)),Color("fff0cf"),Color("c7b79d"),3,1)
		draw_circle(point+Vector2(0,-14),15,Color("b9c9c2"),true,-1,true)
		draw_colored_polygon(PackedVector2Array([point+Vector2(-16,-13),point+Vector2(16,-13),point+Vector2(13,-7),point+Vector2(-13,-7)]),Color("cbded4"))
		draw_arc(point+Vector2(0,-14),15,PI,TAU,16,Color("8fa9a3"),1.3,true)
		for spot in [Vector2(-7,-19),Vector2(4,-22),Vector2(8,-15)]: draw_circle(point+spot,2.3,Color("f6f0d6"),true,-1,true)
	for column in range(6):
		var stem := Vector2(350+column*104,210)
		draw_line(stem,stem+Vector2(0,-20),Color("8ca789"),3,true)
		for side in [-1.0,1.0]:
			draw_circle(stem+Vector2(side*7,-12),5.5,Color("b2c79b"),true,-1,true)
		draw_circle(stem+Vector2(0,-24),7.5,Color("d6d4af"),true,-1,true)

func _escaped_vines() -> void:
	for anchor in [Vector2(320,368),Vector2(925,346)]:
		var path := PackedVector2Array()
		for step in range(23): path.append(anchor+Vector2(sin(step*0.72)*14,step*11))
		draw_polyline(path,Color("8da58a"),4,true)
		draw_polyline(path,Color("b4c9a6"),2,true)
		for step in range(2,21,3):
			var point := path[step]
			for side in [-1.0,1.0]:
				draw_colored_polygon(PackedVector2Array([point,point+Vector2(side*13,-11),point+Vector2(side*15,-4),point+Vector2(side*6,3)]),Color("b0c5a4"))

func _city_memorial() -> void:
	var rect := Rect2(528,165,224,92)
	_rounded(rect.grow(4),Color("b6b8ac"),Color("c4c6b7"),12,2)
	_rounded(rect,Color("e8e7d3"),Color("b9baa5"),9,1)
	for column in range(7):
		var height := float([19,33,24,42,29,36,18][column])
		var at := Vector2(552+column*25,237)
		draw_rect(Rect2(at-Vector2(0,height),Vector2(17,height)),Color("bcb9b0"))
		draw_line(at-Vector2(-3,height),at-Vector2(-12,height),Color("d5d0b9"),2,true)
	_control_seal(Vector2(641,189),25,0.45)

func _chicken(center: Vector2) -> void:
	_shadow(center+Vector2(0,20),Vector2(22,4.5))
	for offset in [Vector2(18,-4),Vector2(24,-11),Vector2(19,-16)]: draw_circle(center+offset,8,Color("f5e6c6"),true,-1,true)
	draw_circle(center+Vector2(0,0),20,Color("fff3d9"),true,-1,true)
	draw_circle(center+Vector2(-13,-15),12,Color("fff5dd"),true,-1,true)
	draw_arc(center+Vector2(3,0),10,-0.2,2.1,12,Color("ddc8a8"),1.3,true)
	for x in [-19,-12,-5]: draw_circle(center+Vector2(x,-27),4.5,Color("dc9993"),true,-1,true)
	draw_colored_polygon(PackedVector2Array([center+Vector2(-24,-15),center+Vector2(-32,-11),center+Vector2(-23,-9)]),Color("dfb171"))
	draw_circle(center+Vector2(-17,-17),1.9,Color("796451"),true,-1,true)
	for x in [-6,6]: draw_line(center+Vector2(x,16),center+Vector2(x,23),Color("cc9d68"),2,true)
