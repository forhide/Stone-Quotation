"""Read-only file verification; no downloads or installation."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'handoff/FILES.json').read_text())
errors=[]
for row in data['files']:
 p=root/row['path']
 if not p.is_file(): errors.append('MISSING '+row['path']+' (from '+row['archive']+')')
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']: errors.append('CHANGED '+row['path'])
if errors:
 print('\n'.join(errors));sys.exit(1)
print('PASS:',len(data['files']),'baseline files; all',data['runtime_input_count'],'released runtime inputs match.')
