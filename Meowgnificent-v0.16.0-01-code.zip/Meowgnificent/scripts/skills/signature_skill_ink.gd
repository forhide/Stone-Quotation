class_name SignatureSkillInk
extends RefCounted

# Large, readable material silhouettes with bounded reusable paths. No particle
# emitters, screen flashes, dynamic textures or per-frame scene allocations.
const KINDS := ["fire_meteor","chain_lightning","tidal_surge","frost_nova","cyclone","stone_quake","verdant_grove","metal_bloom"]
const COLORS := {"fire_meteor":Color("efad78"),"chain_lightning":Color("ead785"),"tidal_surge":Color("85c9dc"),"frost_nova":Color("a4d8e8"),"cyclone":Color("add7c4"),"stone_quake":Color("c4ae91"),"verdant_grove":Color("9ac187"),"metal_bloom":Color("b5bddb")}
const CREAM := Color("fff6dd")
static var _path := PackedVector2Array()
static var _branch := PackedVector2Array()
static var _polygon := PackedVector2Array()

static func draw(c: Node2D, kind: String, age: float, duration: float, delay: float, radius: float, direction: Vector2, outcome: String) -> void:
 var ink: Color=COLORS[kind]
 var post := maxf(0.0,age-delay)
 var t := clampf(post/maxf(duration,0.01),0.0,1.0)
 var fade := 1.0-smoothstep(0.58,1.0,t)
 var ready := clampf(age/maxf(delay,0.01),0.0,1.0)
 if age<delay:
  # A friendly mint/lavender seal fills before release; enemy tells stay coral.
  c.draw_circle(Vector2.ZERO,radius,Color(ink,0.035+ready*0.04),true,-1,true)
  c.draw_arc(Vector2.ZERO,radius,0,TAU,48,Color(ink,0.24+ready*0.42),2.2,true)
  c.draw_arc(Vector2.ZERO,radius*0.86,-PI/2,-PI/2+ready*TAU,40,Color(CREAM,0.62),3.0,true)
  for i in range(4):
   var at := Vector2.from_angle(i*TAU/4+0.25)*radius
   _spark(c,at,5+ready*3,Color(ink,0.8))
  if kind=="fire_meteor":
   var landing := Vector2(62,-235)*(1.0-ready)
   _path.resize(9)
   for i in range(9):
    var u := float(i)/8
    _path[i]=landing+Vector2(38,-110)*u+Vector2(sin(u*4+age*9)*7,0)
   c.draw_polyline(_path,Color(ink,0.48),13,true)
   c.draw_polyline(_path,Color(CREAM,0.7),5,true)
   ElementalFlightInk.draw(c,"fire",landing+Vector2(0,-18),Vector2(-0.25,1),age,3.1,outcome)
  return
 match kind:
  "fire_meteor":
   var bloom := 0.35+sin(minf(t*2,1)*PI/2)*0.65
   c.draw_circle(Vector2.ZERO,radius*bloom,Color(ink,fade*0.12),true,-1,true)
   c.draw_arc(Vector2.ZERO,radius*(0.35+t*0.85),0,TAU,44,Color(ink,fade*0.8),4.3*(1-t)+0.7,true)
   for i in range(7):
    var a := i*TAU/7
    var at := Vector2.from_angle(a)*radius*bloom*0.34+Vector2(0,-27-post*13)
    c.draw_circle(at,radius*0.19*(1-t*0.4),Color(ink,fade*0.75),true,-1,true)
   ElementalFlightInk.draw(c,"fire",Vector2(0,-28),Vector2.ZERO,age,3.8*(1-t*0.55),outcome)
   for i in range(6):
    var a := i*TAU/6+0.23
    var at := Vector2.from_angle(a)*radius*(0.42+t*0.65)+Vector2(0,-22-post*14)
    _spark(c,at,(7-i%2*2)*(1-t),Color(CREAM,fade))
  "chain_lightning":
   # Connections are drawn from actual acquired contact points separately.
   c.draw_arc(Vector2(0,-18),27+t*17,0,TAU,24,Color(ink,fade*0.7),2.0,true)
   for i in range(3):
    var a := i*TAU/3+age*4
    _spark(c,Vector2.from_angle(a)*(24+t*12)+Vector2(0,-18),7*(1-t*0.5),Color(CREAM,fade))
  "tidal_surge":
   var forward := direction.normalized()
   var side := forward.orthogonal()
   _path.resize(27)
   for i in range(27):
    var u := float(i)/26*2-1
    _path[i]=side*u*radius+forward*(1-u*u)*31+Vector2(0,-19-9*sin(age*7+i*0.18))
   c.draw_polyline(_path,Color("609fb9",fade*0.7),26,true)
   c.draw_polyline(_path,Color(ink,fade*0.95),20,true)
   c.draw_polyline(_path,Color("d3eef0",fade),7,true)
   for i in range(7):
    var index := i*4
    var at := _path[index]
    c.draw_circle(at,7.5,Color(CREAM,fade*0.85),true,-1,true)
    c.draw_arc(at-forward*15,10,age*2+i,age*2+i+4.6,15,Color(ink,fade*0.8),2,true)
  "frost_nova":
   var growth := smoothstep(0,0.28,t)
   c.draw_circle(Vector2.ZERO,radius,Color(ink,fade*0.08),true,-1,true)
   c.draw_arc(Vector2.ZERO,radius*growth,0,TAU,48,Color(CREAM,fade*0.85),3,true)
   for i in range(8):
    var a := i*TAU/8
    var at := Vector2.from_angle(a)*radius*(0.36+growth*0.42)
    c.draw_line(Vector2.ZERO,at,Color(ink,fade*0.72),2.0,true)
    _crystal(c,at,15+growth*13,a+PI/2,Color(ink,fade))
   _spark(c,Vector2(0,-24),32*(0.5+growth*0.5),Color(CREAM,fade))
  "cyclone":
   var growth := minf(1,post*5)
   c.draw_circle(Vector2.ZERO,radius,Color(ink,fade*0.055),true,-1,true)
   for tier in range(4):
    var r := radius*(0.65-tier*0.115)*growth
    var base := Vector2(0,-tier*29-9)
    _path.resize(29)
    for i in range(29):
     var a := float(i)/28*TAU*0.9+age*(4.0-tier*0.35)+tier
     _path[i]=base+Vector2(cos(a)*r,sin(a)*r*0.32)
    c.draw_polyline(_path,Color(ink,fade*0.76),8-tier,true)
    c.draw_polyline(_path,Color(CREAM,fade*0.84),2.0,true)
   for i in range(5):
    var a := age*4+i*TAU/5
    _spark(c,Vector2(cos(a)*radius*0.62,sin(a)*radius*0.25-45),5,Color(ink,fade))
  "stone_quake":
   for pulse in range(3):
    var phase := clampf((post-pulse*0.28)/0.46,0,1)
    if post<pulse*0.28: continue
    var reach := radius*(0.48+pulse*0.26)*phase
    c.draw_arc(Vector2.ZERO,reach,0,TAU,36,Color(ink,(1-phase)*0.82),5*(1-phase)+1,true)
   for i in range(8):
    var a := i*TAU/8+0.12
    var at := Vector2.from_angle(a)*radius*0.68
    var height := sin(minf(post*5,PI))*13
    _rock(c,at-Vector2(0,height),11+i%3*3,Color(ink,fade))
    c.draw_line(at,at+Vector2.from_angle(a)*radius*0.15,Color("a08e78",fade*0.6),2.1,true)
  "verdant_grove":
   c.draw_circle(Vector2.ZERO,radius,Color(ink,fade*0.075),true,-1,true)
   c.draw_arc(Vector2.ZERO,radius,0,TAU,40,Color(ink,fade*0.48),2.0,true)
   var growth := smoothstep(0,0.28,t)
   for i in range(8):
    var a := i*TAU/8
    var base := Vector2.from_angle(a)*radius*0.64
    _path.resize(20)
    for j in range(20):
     var u := float(j)/19
     _path[j]=base+Vector2(sin(u*TAU*0.85+age*1.4+i)*18*u,-u*72*growth)
    c.draw_polyline(_path,Color("6c996f",fade*0.9),6.0,true)
    c.draw_polyline(_path,Color("d5e7b0",fade),2.1,true)
    _spark(c,_path[19],5+sin(age*4+i),Color(CREAM,fade*0.75))
  "metal_bloom":
   c.draw_circle(Vector2.ZERO,radius,Color(ink,fade*0.08),true,-1,true)
   c.draw_arc(Vector2.ZERO,radius*(0.5+minf(post*2,1)*0.5),0,TAU,40,Color(CREAM,fade*0.8),2.4,true)
   for i in range(10):
    var a := i*TAU/10+0.18
    var growth := smoothstep(i%2*0.15,i%2*0.15+0.2,post)
    var base := Vector2.from_angle(a)*radius*(0.42+i%2*0.28)
    _crystal(c,base-Vector2(0,22*growth),32*growth,a*0.12,Color(ink,fade))
   for i in range(4):
    var a := i*TAU/4+post*0.3
    _spark(c,Vector2.from_angle(a)*radius*0.82-Vector2(0,25),7,Color(CREAM,fade))
 c.draw_set_transform(Vector2.ZERO)

static func draw_chain(c: Node2D, points: PackedVector2Array, age: float, duration: float, outcome: String) -> void:
 if points.size()<2: return
 var fade := 1.0-smoothstep(maxf(0.0,duration-0.3),duration,age)
 var ink := Color("e8d081") if outcome!="miscast" else Color("c9b6dc")
 for segment in range(1,points.size()):
  var start := points[segment-1]+Vector2(0,-20)
  var finish := points[segment]+Vector2(0,-20)
  var side := (finish-start).normalized().orthogonal()
  _path.resize(12)
  for i in range(12):
   var t := float(i)/11
   _path[i]=start.lerp(finish,t)+side*sin(t*PI)*(sin(i*7.1+age*43)*9+sin(i*3.3-age*27)*4)
  c.draw_polyline(_path,Color(ink,fade*0.2),13,true)
  c.draw_polyline(_path,Color(ink,fade*0.95),5.1,true)
  c.draw_polyline(_path,Color(CREAM,fade),2.1,true)
  _spark(c,finish,11,Color(CREAM,fade))
 c.draw_set_transform(Vector2.ZERO)

static func _spark(c: Node2D, at: Vector2, size: float, color: Color) -> void:
 c.draw_line(at-Vector2(size,0),at+Vector2(size,0),color,2.1,true)
 c.draw_line(at-Vector2(0,size),at+Vector2(0,size),color,2.1,true)

static func _crystal(c: Node2D, at: Vector2, size: float, angle: float, color: Color) -> void:
 if size<0.01: return
 c.draw_set_transform(at,angle,Vector2.ONE)
 _polygon=PackedVector2Array([Vector2(0,-size),Vector2(size*0.27,-size*0.23),Vector2(size*0.17,size*0.24),Vector2(-size*0.18,size*0.24),Vector2(-size*0.28,-size*0.2)])
 c.draw_colored_polygon(_polygon,color)
 c.draw_line(Vector2(0,-size),Vector2(0,size*0.22),Color(CREAM,color.a),1.6,true)
 c.draw_set_transform(Vector2.ZERO)

static func _rock(c: Node2D, at: Vector2, size: float, color: Color) -> void:
 _polygon=PackedVector2Array([Vector2(-1,-0.2),Vector2(-0.5,-0.8),Vector2(0.35,-0.9),Vector2(1,-0.2),Vector2(0.75,0.55),Vector2(-0.65,0.65)])
 for i in range(_polygon.size()): _polygon[i]=at+_polygon[i]*size
 c.draw_colored_polygon(_polygon,color)
 c.draw_line(at+Vector2(-size*0.3,-size*0.5),at+Vector2(size*0.35,-size*0.55),Color(CREAM,color.a*0.8),2.0,true)
