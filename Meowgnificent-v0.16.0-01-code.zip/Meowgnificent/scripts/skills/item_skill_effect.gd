class_name ItemSkillEffect
extends Node2D

# Bounded, short-lived skill actors share one draw node per effect. They live
# under the room's projectile root, so menus and room changes pause/clear them.
var controller: Node
var kind := "spark"
var element := ""
var cosmetic_only := false
var pulse_index := 0
var chain_complete := false
var chain_last := Vector2.ZERO
var chain_tail := 0.0
const SIGNATURE_KINDS := ["fire_meteor","chain_lightning","tidal_surge","frost_nova","cyclone","stone_quake","verdant_grove","metal_bloom"]
var direction := Vector2.RIGHT
var origin := Vector2.ZERO
var target := Vector2.ZERO
var radius := 55.0
var damage := 0
var duration := 0.5
var delay := 0.0
var speed := 390.0
var outcome := "success"
var age := 0.0
var triggered := false
var next_tick := 0.6
var hit_times: Dictionary = {}
var points: PackedVector2Array = PackedVector2Array()

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	reset_physics_interpolation()

func _process(_delta: float) -> void:
	if is_instance_valid(controller) and (controller.is_combat_active() or cosmetic_only): queue_redraw()

func _physics_process(delta: float) -> void:
	if not is_instance_valid(controller) or not is_instance_valid(controller.room):
		queue_free()
		return
	if cosmetic_only:
		if controller.room.state in ["transition","cleared","defeated","intro"]:
			queue_free()
			return
		if controller.room.state=="playing" and controller.player.active:
			age+=delta
			if age>=delay+duration: queue_free()
			queue_redraw()
		return
	if not controller.is_combat_active():
		if controller.room.exit_open or controller.room.state in ["transition","cleared","defeated","intro"]: queue_free()
		return
	var before := age
	age+=delta
	if kind in SIGNATURE_KINDS:
		_tick_signature(delta,before)
		if age>=duration+delay and not (kind=="chain_lightning" and not chain_complete): queue_free()
		queue_redraw()
		return
	match kind:
		"pages":
			# A miscast sends the footnotes circling an empty patch behind the
			# caster instead of protecting their feet. The pages still hit foes.
			position=controller.player.position+(direction*85.0 if outcome=="miscast" else Vector2.ZERO)
			for enemy in controller.room.enemies.duplicate():
				if not is_instance_valid(enemy) or enemy.health.current<=0: continue
				var id: int=enemy.get_instance_id()
				if age-float(hit_times.get(id,-10.0))<0.5: continue
				for i in range(6):
					var page := position+Vector2.from_angle(age*3.3+i*TAU/6.0)*radius
					if page.distance_to(enemy.position)<=19.0+float(enemy.config.radius):
						controller.hit_enemy(enemy,damage,(enemy.position-position).normalized(),outcome,element)
						hit_times[id]=age
						break
		"bubble":
			position=controller.player.position
		"chicken":
			var travel := speed*delta
			var steps := maxi(1,ceili(travel/9.0))
			for step in range(steps):
				position+=direction*travel/steps
				if not controller.room.bounds.has_point(position):
					queue_free()
					return
				for enemy in controller.room.enemies.duplicate():
					if not is_instance_valid(enemy) or enemy.health.current<=0: continue
					var id: int=enemy.get_instance_id()
					if not hit_times.has(id) and position.distance_to(enemy.position)<=radius+float(enemy.config.radius):
						controller.hit_enemy(enemy,damage,direction,outcome,element)
						hit_times[id]=age
		"vine":
			if age>=next_tick:
				next_tick+=0.6
				controller.hit_area(position,damage,radius,outcome,"",0.0,element)
		"potion":
			position=origin.lerp(target,clampf(age/duration,0.0,1.0))
			if age>=duration and not triggered:
				triggered=true
				controller.hit_area(target,damage,radius,outcome,"",0.0,element)
				controller.visual("potion_pop",target,radius,0.55,outcome)
		"thunder","meteor":
			if age>=delay and not triggered:
				triggered=true
				controller.hit_area(position,damage,radius,outcome,"",0.0,element)
	if age>=duration+delay: queue_free()
	queue_redraw()

func _ellipse(at: Vector2, extent: Vector2, color: Color) -> void:
	draw_set_transform(at,0,extent)
	draw_circle(Vector2.ZERO,1,color,true,-1,true)
	draw_set_transform(Vector2.ZERO)

func _draw() -> void:
	var drawing_age := age
	if ProjectSettings.get_setting("physics/common/physics_interpolation",false) and is_instance_valid(controller) and controller.is_combat_active():
		drawing_age=maxf(0,age-(1.0-Engine.get_physics_interpolation_fraction())/float(Engine.physics_ticks_per_second))
	SkillEffectInk.draw_effect(self,kind,drawing_age,duration,delay,radius,direction,outcome)
	if kind=="chain_lightning": SignatureSkillInk.draw_chain(self,points,maxf(0,drawing_age-delay),duration,outcome)

func presentation_snapshot() -> Dictionary:
	return {"kind":kind,"signature":SkillEffectInk.signature(kind),"draw_command_budget":SkillEffectInk.max_draw_commands(kind),"age":age,"duration":duration,"outcome":outcome}

func is_cosmetic_tail() -> bool:
	return cosmetic_only

func finish_as_cosmetic() -> bool:
	if cosmetic_only: return true
	if kind not in SIGNATURE_KINDS or not triggered: return false
	cosmetic_only=true
	damage=0
	chain_complete=true
	# Keep an impact legible, with a strictly bounded tail after a final blow.
	duration=maxf(0.0,age-delay)+0.35
	return true

func _tick_signature(delta: float, before: float) -> void:
	if age<delay: return
	var active_delta := maxf(0.0,age-maxf(before,delay))
	var post := age-delay
	match kind:
		"fire_meteor":
			if not triggered:
				triggered=true
				controller.hit_area(position,damage,radius,outcome,"",0.0,element)
		"chain_lightning":
			while not chain_complete and post>=pulse_index*0.105:
				_chain_hop()
				if not controller.is_combat_active(): break
		"tidal_surge":
			triggered=true
			var start := position
			position=(position+direction*speed*active_delta).clamp(controller.room.bounds.position,controller.room.bounds.end)
			for enemy in controller.room.enemies.duplicate():
				if not is_instance_valid(enemy) or enemy.health.current<=0 or hit_times.has(enemy.get_instance_id()): continue
				var contact := Geometry2D.get_closest_point_to_segment(enemy.position,start,position)
				if contact.distance_to(enemy.position)>radius+float(enemy.config.radius): continue
				hit_times[enemy.get_instance_id()]=age
				if controller.hit_enemy(enemy,damage,direction,outcome,element): enemy.knockback+=direction*125.0
		"frost_nova":
			if not triggered:
				triggered=true
				controller.hit_area(position,damage,radius,outcome,"slow",2.4,element)
		"cyclone":
			triggered=true
			position=(position+direction*speed*active_delta).clamp(controller.room.bounds.position,controller.room.bounds.end)
			while pulse_index<3 and post>=pulse_index*0.52:
				pulse_index+=1
				for enemy in controller.room.enemies.duplicate():
					if not is_instance_valid(enemy) or enemy.health.current<=0 or enemy.position.distance_to(position)>radius+float(enemy.config.radius): continue
					if controller.hit_enemy(enemy,damage,(position-enemy.position).normalized(),outcome,element): enemy.knockback=(position-enemy.position).normalized()*120
				if not controller.is_combat_active(): break
		"stone_quake":
			triggered=true
			while pulse_index<3 and post>=pulse_index*0.28:
				var reach := radius*(0.48+pulse_index*0.26)
				pulse_index+=1
				controller.hit_area(position,damage,reach,outcome,"",0.0,element)
				if not controller.is_combat_active(): break
		"verdant_grove":
			triggered=true
			while pulse_index<4 and post>=pulse_index*0.56:
				pulse_index+=1
				controller.hit_area(position,damage,radius,outcome,"root",0.7,element)
				if not controller.is_combat_active(): break
		"metal_bloom":
			triggered=true
			while pulse_index<2 and post>=pulse_index*0.30:
				pulse_index+=1
				controller.hit_area(position,damage,radius*(0.72 if pulse_index==1 else 1.0),outcome,"",0.0,element)
				if not controller.is_combat_active(): break

func _chain_hop() -> void:
	var from := origin if pulse_index==0 else chain_last
	var nearest: Node2D
	var best := INF
	for enemy in controller.room.enemies:
		if not is_instance_valid(enemy) or enemy.health.current<=0 or hit_times.has(enemy.get_instance_id()): continue
		var offset: Vector2=enemy.position-from
		if offset.length()>(speed if pulse_index==0 else radius)+float(enemy.config.radius): continue
		if pulse_index==0 and offset.length()>45 and offset.normalized().dot(direction)<0.12: continue
		# Start at the first reachable foe in the aiming cone; choosing the
		# far endpoint can make a connected row chain backward and dead-end.
		var distance: float=offset.length_squared()
		if distance<best:
			best=distance
			nearest=enemy
	if nearest==null:
		if points.is_empty(): points=PackedVector2Array([Vector2.ZERO,direction*minf(speed,115.0)])
		chain_complete=true
		triggered=true
		duration=maxf(duration,age-delay+0.35)
		return
	chain_last=nearest.position
	if points.is_empty(): points.append(from-position)
	points.append(chain_last-position)
	hit_times[nearest.get_instance_id()]=age
	pulse_index+=1
	triggered=true
	controller.hit_enemy(nearest,damage,direction if pulse_index==1 else (chain_last-from).normalized(),outcome,element)
	if pulse_index>=5:
		chain_complete=true
		duration=maxf(duration,age-delay+0.35)
