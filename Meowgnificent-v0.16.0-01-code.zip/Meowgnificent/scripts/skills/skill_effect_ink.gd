class_name SkillEffectInk
extends RefCounted

# Reusable hand-drawn silhouettes. These are skill illustrations, not the
# primary projectile/failure atlas. Cached paths keep the small effects bounded.
const CREAM := Color("fff5ce")
const INK := Color("977b85")
const GOLD := Color("efc879")
const CORAL := Color("e9a58e")
const LILAC := Color("b8a3d4")
const SKY := Color("a6d8e9")
const MINT := Color("b4d4b0")
static var STAR := _radial(5,0.46)
static var TWINKLE := _radial(4,0.26)
static var CRYSTAL := PackedVector2Array([Vector2(0,-1),Vector2(0.48,-0.22),Vector2(0.32,0.66),Vector2(0,1),Vector2(-0.32,0.66),Vector2(-0.48,-0.22),Vector2(0,-1)])
static var LEAF := PackedVector2Array([Vector2(-1,0),Vector2(-0.65,-0.65),Vector2(0.05,-0.8),Vector2(1,0),Vector2(0.1,0.72),Vector2(-0.68,0.6),Vector2(-1,0)])
static var BOLT := PackedVector2Array([Vector2(-0.12,-1),Vector2(-0.5,-0.52),Vector2(0.09,-0.53),Vector2(-0.23,0.05),Vector2(0.2,-0.03),Vector2(0.03,0.36)])
static var BOTTLE := PackedVector2Array([Vector2(-0.25,-1),Vector2(0.25,-1),Vector2(0.25,-0.52),Vector2(0.7,-0.22),Vector2(0.83,0.25),Vector2(0.6,0.78),Vector2(0,0.97),Vector2(-0.6,0.78),Vector2(-0.83,0.25),Vector2(-0.7,-0.22),Vector2(-0.25,-0.52),Vector2(-0.25,-1)])
static var CURL := _curl()
static var SWASH := _swash()
static var SECTOR := _sector()
static var SPIRAL := _spiral()
static var PAPER := _paper_path()
static var BEAK := PackedVector2Array([Vector2(19,-34),Vector2(27,-30),Vector2(19,-27)])

static func signature(kind: String) -> String:
 if kind in SignatureSkillInk.KINDS: return "elemental_signature_"+kind
 return {"spark":"five_point_star_blossom","ring":"spiraling_hearth_embers","pages":"six_orbiting_paper_sigils","bubble":"pearl_paw_shield","bubble_wrong":"wrong_place_bubble_pop","chicken":"feather_ribbon_chicken_charge","vine":"curling_garden_roots","potion":"arcing_corked_bottle","potion_pop":"six_petal_potion_bloom","thunder":"cloud_and_sugar_lightning","meteor":"doodle_comet_landing","frost":"five_crystal_whisker_cone","blink":"pawprint_portal","fan":"five_ember_fan"}.get(kind,"storybook_skill")

static func max_draw_commands(kind: String) -> int:
 if kind in SignatureSkillInk.KINDS: return 72
 # Upper bound of primitive drawing calls (transform setup excluded), including
 # overreaction's four sparkle accents. GPU batching is measured separately.
 return {"spark":28,"ring":38,"pages":38,"bubble":26,"bubble_wrong":29,"chicken":46,"vine":42,"potion":23,"potion_pop":31,"thunder":31,"meteor":27,"frost":36,"blink":29,"fan":29}.get(kind,18)

static func draw_effect(c: Node2D, kind: String, age: float, duration: float, delay: float, radius: float, direction: Vector2, outcome: String) -> void:
 if kind in SignatureSkillInk.KINDS:
  SignatureSkillInk.draw(c,kind,age,duration,delay,radius,direction,outcome)
  return
 var progress := clampf(age/maxf(duration,0.01),0.0,1.0)
 var post := maxf(0,age-delay)
 var fade := 1.0-clampf(post/maxf(duration,0.01),0.0,1.0)
 var enter := minf(1,age/0.11)
 var ink := LILAC if outcome=="miscast" else GOLD
 var turn := sin(age*17)*0.075 if outcome=="miscast" else 0.0
 match kind:
  "spark":
   var bloom := (0.4+0.6*minf(1,age/0.10))*(1+sin(progress*PI)*0.10)
   _ellipse(c,Vector2(0,-17),Vector2(radius*0.9,radius*0.62),Color(ink,fade*0.10))
   _star(c,Vector2(0,-20),radius*0.57*bloom,-0.10+turn,Color(ink,fade),Color(INK,fade),2.0)
   _star(c,Vector2(0,-20),radius*0.31*bloom,-0.10+turn,Color(CREAM,fade),Color.TRANSPARENT)
   for i in range(3):
    var a := -PI/2+i*TAU/3+progress*0.75
    var at := Vector2.from_angle(a)*radius*(0.46+progress*0.46)+Vector2(0,-20)
    _star(c,at,radius*(0.13-i*0.015)*(0.6+enter*0.4),a+age*0.5,Color([SKY,MINT,CORAL][i],fade),Color(INK,fade*0.75),1.1)
  "ring":
   var reach := radius*(0.44+0.56*sin(minf(1,progress*1.7)*PI/2))
   _ellipse(c,Vector2.ZERO,Vector2(reach,reach*0.48),Color(CORAL,fade*0.11))
   _path(c,SPIRAL,Vector2(0,-8),age*0.55,Vector2(reach,reach*0.48),Color(CORAL,fade*0.8),3)
   _path(c,SPIRAL,Vector2(0,-8),age*0.55+PI,Vector2(reach*0.82,reach*0.39),Color(CREAM,fade),1.8)
   for i in range(7):
    var a := i*TAU/7+age*0.4
    var at := Vector2(cos(a)*reach,sin(a)*reach*0.48-10)
    _leaf(c,at,7+4*sin(progress*PI),a-PI/2,Color(CORAL,fade),Color(INK,fade*0.55))
  "pages":
   var alpha := minf(enter,fade*4)
   _ring(c,Vector2(0,-7),Vector2(radius,radius),Color(LILAC,alpha*0.23),1.4)
   for i in range(6):
    var at := Vector2.from_angle(age*3.3+i*TAU/6)*radius+Vector2(0,-18)
    c.draw_set_transform(at,age*0.6+i,Vector2.ONE)
    c.draw_colored_polygon(PAPER,Color(CREAM,alpha))
    c.draw_polyline(PAPER,Color(LILAC,alpha),1.3,true)
    c.draw_line(Vector2(-6,7),Vector2(6,7),Color(LILAC,alpha),1.4,true)
    c.draw_set_transform(Vector2.ZERO)
    _twinkle(c,at,5,age*0.6+i,Color(LILAC,alpha))
  "bubble","bubble_wrong":
   var pop := kind=="bubble_wrong"
   var breathe := 1+sin(age*3.2)*0.012
   var extent := Vector2(radius*0.78,radius)*breathe
   var center := Vector2(0,-63 if not pop else -18)
   if pop: extent*=Vector2(1+sin(progress*PI)*0.25,1-progress*0.35)
   var alpha := minf(enter,fade*3)
   _ellipse(c,center,extent,Color(SKY,alpha*0.12))
   _ring(c,center,extent,Color(LILAC,alpha*0.85),2.6)
   _ring(c,center,extent*0.91,Color(CREAM,alpha*0.85),1.1)
   _arc(c,center,extent*0.81,-2.6,-1.9,Color(CREAM,alpha),3.0)
   _paw(c,center+Vector2(-extent.x*0.34,-extent.y*0.35),10,Color(CREAM,alpha*0.78))
   for i in range(3):
    var at := center+Vector2(cos(age+i*2.1)*extent.x,sin(age+i*2.1)*extent.y)
    _twinkle(c,at,4.5,age*0.5,Color(CREAM,alpha))
  "chicken":
   _path(c,SWASH,Vector2(0,-15),direction.angle(),Vector2(60,10),Color(CREAM,0.55),2.4)
   _ellipse(c,Vector2(0,4),Vector2(21,5),Color(INK,0.12))
   _chicken(c,age,direction)
  "vine":
   var alpha := minf(enter,fade*4)
   _ellipse(c,Vector2.ZERO,Vector2(radius,radius*0.48),Color(MINT,alpha*0.14))
   _ring(c,Vector2.ZERO,Vector2(radius*0.92,radius*0.44),Color(MINT.darkened(0.13),alpha*0.45),1.6)
   for i in range(7):
    var a := i*TAU/7
    var at := Vector2.from_angle(a)*radius*0.68
    var scale_ := Vector2(17,26)*(0.72+enter*0.28)
    _path(c,CURL,at,-0.15+sin(age*2+i)*0.12,scale_,Color(MINT.darkened(0.13),alpha),2.6)
    _leaf(c,at+Vector2(9,-19),9,0.3+sin(age*2+i)*0.12,Color(MINT,alpha),Color(INK,alpha*0.5))
   _twinkle(c,Vector2(0,-11),13,age*0.5,Color(CREAM,alpha))
  "potion":
   var height := sin(progress*PI)*80
   _ellipse(c,Vector2(0,3),Vector2(13,3.6),Color(INK,0.13))
   _bottle(c,Vector2(0,-height-20),progress*TAU,17,outcome)
  "potion_pop":
   var bloom := 0.28+progress*0.75
   _ellipse(c,Vector2.ZERO,Vector2(radius*bloom,radius*bloom*0.46),Color(LILAC,fade*0.14))
   for i in range(6):
    var a := i*TAU/6+turn
    var at := Vector2.from_angle(a)*radius*bloom*0.5+Vector2(0,-17)
    _ellipse(c,at,Vector2.ONE*radius*bloom*0.31,Color([LILAC,SKY,MINT][i%3],fade*0.72))
   _twinkle(c,Vector2(0,-17),radius*0.3*(0.5+enter*0.5),turn,Color(CREAM,fade))
   for i in range(3):
    var at := Vector2.from_angle(i*TAU/3+1.0)*radius*(0.65+progress*0.35)+Vector2(0,-25-progress*14)
    _ring(c,at,Vector2.ONE*(5-progress*2),Color(LILAC,fade),1.5)
  "thunder","meteor":
   if age<delay:
    var approach := clampf(age/maxf(delay,0.01),0,1)
    _ring(c,Vector2.ZERO,Vector2(radius,radius*0.52),Color(GOLD,0.23+approach*0.2),1.5)
    _twinkle(c,Vector2.ZERO,10+approach*5,0,Color(GOLD,0.62))
    if kind=="meteor":
     var h := 135*pow(1-approach,1.45)
     _path(c,SWASH,Vector2(-10,-h-25),-PI/2,Vector2(43,12),Color(SKY,0.6),3)
     _star(c,Vector2(0,-h-20),17,0.3+approach*1.7,LILAC,INK,1.6)
     _star(c,Vector2(0,-h-20),9,0.3+approach*1.7,CREAM,Color.TRANSPARENT)
   elif kind=="thunder":
    _ellipse(c,Vector2(-11,-111),Vector2(16,10),Color(SKY,fade*0.9))
    _ellipse(c,Vector2(5,-115),Vector2(18,13),Color(SKY,fade*0.9))
    _ellipse(c,Vector2(21,-108),Vector2(12,9),Color(SKY,fade*0.9))
    _path(c,BOLT,Vector2(0,-35),turn,Vector2(51,75),Color(GOLD,fade*0.52),10)
    _path(c,BOLT,Vector2(0,-35),turn,Vector2(51,75),Color(CREAM,fade),3.1)
    _twinkle(c,Vector2(0,-9),radius*(0.28+post*0.55),turn,Color(GOLD,fade))
   else:
    var burst := 0.55+post*1.25
    _star(c,Vector2(0,-12),radius*0.55*burst,-0.15,Color(LILAC,fade*0.78),Color(INK,fade*0.5),1.6)
    _twinkle(c,Vector2(0,-12),radius*0.3*burst,0.1,Color(CREAM,fade))
    for i in range(4):
     var at := Vector2.from_angle(i*PI/2+0.4)*radius*(0.35+post*1.7)+Vector2(0,-12)
     _ellipse(c,at,Vector2.ONE*(4+post*4),Color(SKY,fade*0.7))
  "frost":
   var alpha := minf(enter,fade*3)
   _path_fill(c,SECTOR,Vector2.ZERO,direction.angle(),Vector2.ONE*radius,Color(SKY,alpha*0.17))
   _arc(c,Vector2.ZERO,Vector2.ONE*radius,direction.angle()-PI*0.29,direction.angle()+PI*0.29,Color(SKY,alpha*0.68),2.0)
   for i in range(5):
    var a := direction.angle()-0.62+i*0.31
    var at := Vector2.from_angle(a)*radius*(0.48+i%2*0.16)+Vector2(0,-10)
    _crystal(c,at,11+enter*8,a+PI/2,Color(SKY,alpha),Color(INK,alpha*0.65))
  "blink":
   var grow := 0.45+0.55*sin(progress*PI*0.5)
   _ellipse(c,Vector2.ZERO,Vector2(radius*grow,radius*grow*0.44),Color(LILAC,fade*0.15))
   _ring(c,Vector2.ZERO,Vector2(radius*grow,radius*grow*0.44),Color(LILAC,fade),2.8)
   _ring(c,Vector2(0,-5),Vector2(radius*grow*0.76,radius*grow*0.35),Color(CREAM,fade*0.9),1.7)
   _paw(c,Vector2(0,-17),radius*0.28,Color(LILAC,fade*0.85))
   for i in range(3):
    var a := i*TAU/3+age
    _twinkle(c,Vector2(cos(a)*radius*grow,sin(a)*radius*grow*0.44-10),7,a,Color(CREAM,fade))
  "fan":
   for i in range(5):
    var a := direction.angle()-0.52+i*0.26
    _leaf(c,Vector2.from_angle(a)*(radius*0.6+progress*25)+Vector2(0,-18),8+enter*6,a,Color(CORAL,fade),Color(INK,fade*0.65))
  _:
   _twinkle(c,Vector2(0,-15),radius*0.45*(0.4+enter*0.6),turn,Color(LILAC,fade))
 _outcome_accents(c,outcome,age,duration,radius)
 c.draw_set_transform(Vector2.ZERO)

static func _outcome_accents(c: Node2D, outcome: String, age: float, duration: float, radius: float) -> void:
 if outcome=="success": return
 var fade := 1-clampf(age/maxf(duration,0.01),0,1)
 if fade<=0: return
 var count := 3 if outcome=="miscast" else 4
 for i in range(count):
  var a := -1.7+i*TAU/count+age*0.6
  var at := Vector2(cos(a)*radius*0.8,sin(a)*radius*0.45-20)
  _twinkle(c,at,4.5+sin(age*10+i)*1.3,a,Color(LILAC if outcome=="miscast" else CREAM,fade*0.85))

static func _ellipse(c: Node2D, at: Vector2, size_: Vector2, color: Color) -> void:
 c.draw_set_transform(at,0,size_)
 c.draw_circle(Vector2.ZERO,1,color,true,-1,true)
 c.draw_set_transform(Vector2.ZERO)

static func _ring(c: Node2D, at: Vector2, size_: Vector2, color: Color, width: float) -> void:
 _arc(c,at,size_,0,TAU,color,width)

static func _arc(c: Node2D, at: Vector2, size_: Vector2, start: float, end: float, color: Color, width: float) -> void:
 c.draw_set_transform(at,0,size_)
 c.draw_arc(Vector2.ZERO,1,start,end,40,color,width/maxf(1,size_.x),true)
 c.draw_set_transform(Vector2.ZERO)

static func _path(c: Node2D, path: PackedVector2Array, at: Vector2, angle: float, scale_: Vector2, color: Color, width: float) -> void:
 c.draw_set_transform(at,angle,scale_)
 c.draw_polyline(path,color,width/maxf(1,minf(absf(scale_.x),absf(scale_.y))),true)
 c.draw_set_transform(Vector2.ZERO)

static func _path_fill(c: Node2D, path: PackedVector2Array, at: Vector2, angle: float, scale_: Vector2, color: Color) -> void:
 c.draw_set_transform(at,angle,scale_)
 c.draw_colored_polygon(path,color)
 c.draw_set_transform(Vector2.ZERO)

static func _closed_shape(c: Node2D, path: PackedVector2Array, at: Vector2, size_: float, angle: float, fill: Color, border: Color, width: float=1.5) -> void:
 c.draw_set_transform(at,angle,Vector2.ONE*size_)
 c.draw_colored_polygon(path,fill)
 if border.a>0: c.draw_polyline(path,border,width/maxf(size_,0.1),true)
 c.draw_set_transform(Vector2.ZERO)

static func _star(c: Node2D, at: Vector2, size_: float, angle: float, fill: Color, border: Color, width: float=1.5) -> void:
 _closed_shape(c,STAR,at,size_,angle,fill,border,width)

static func _twinkle(c: Node2D, at: Vector2, size_: float, angle: float, fill: Color) -> void:
 _closed_shape(c,TWINKLE,at,size_,angle,fill,Color.TRANSPARENT)

static func _leaf(c: Node2D, at: Vector2, size_: float, angle: float, fill: Color, border: Color) -> void:
 _closed_shape(c,LEAF,at,size_,angle,fill,border,1.1)

static func _crystal(c: Node2D, at: Vector2, size_: float, angle: float, fill: Color, border: Color) -> void:
 _closed_shape(c,CRYSTAL,at,size_,angle,fill,border,1.4)
 c.draw_set_transform(at,angle,Vector2.ONE*size_)
 c.draw_line(Vector2(0,-0.82),Vector2(0,0.83),CREAM,1.1/maxf(size_,0.1),true)
 c.draw_set_transform(Vector2.ZERO)

static func _paw(c: Node2D, at: Vector2, size_: float, color: Color) -> void:
 _ellipse(c,at+Vector2(0,size_*0.22),Vector2(size_*0.53,size_*0.42),color)
 for i in range(3):
  var angle := -PI*0.82+i*PI*0.32
  _ellipse(c,at+Vector2.from_angle(angle)*size_*0.68,Vector2.ONE*size_*0.22,color)

static func _bottle(c: Node2D, at: Vector2, angle: float, size_: float, outcome: String) -> void:
 _closed_shape(c,BOTTLE,at,size_,angle,LILAC if outcome!="miscast" else SKY,INK,1.7)
 c.draw_set_transform(at,angle,Vector2.ONE)
 c.draw_rect(Rect2(-size_*0.29,-size_*1.15,size_*0.58,size_*0.2),GOLD)
 c.draw_line(Vector2(-size_*0.4,-size_*0.15),Vector2(-size_*0.23,size_*0.25),CREAM,2,true)
 c.draw_set_transform(Vector2.ZERO)

static func _chicken(c: Node2D, age: float, direction: Vector2) -> void:
 var side := -1.0 if direction.x>=0 else 1.0
 for i in range(2):
  var at := Vector2(-direction.x*(22+i*20),-12-direction.y*(22+i*20)+sin(age*19+i)*3)
  _leaf(c,at,5.5,age+i,Color(CREAM,0.55-i*0.18),Color.TRANSPARENT)
 # The exact painted picnic hen answers Pip's summon. Feet remain on the
 # charge's floor point; a tiny grounded lean gives the short dash momentum.
 var texture := WorldDetailArt.icon("hen")
 var height := 60.0*(1.0+sin(age*25)*0.018)
 var width := height*texture.get_width()/texture.get_height()
 c.draw_set_transform(Vector2.ZERO,sin(age*25)*0.035,Vector2(side,1))
 c.draw_texture_rect(texture,Rect2(-width*0.5,3-height,width,height),false)
 c.draw_set_transform(Vector2.ZERO)

static func _radial(tips: int, inner: float) -> PackedVector2Array:
 var result := PackedVector2Array()
 for i in range(tips*2+1): result.append(Vector2.from_angle(-PI/2+i*PI/tips)*(1.0 if i%2==0 else inner))
 return result
static func _curl() -> PackedVector2Array:
 var result := PackedVector2Array()
 for i in range(21):
  var t := i/20.0
  result.append(Vector2(sin(t*TAU*0.9)*0.43*(1-t*0.35),-t))
 return result
static func _swash() -> PackedVector2Array:
 var result := PackedVector2Array()
 for i in range(17):
  var t := i/16.0
  result.append(Vector2(-t,sin(t*PI)*0.42))
 return result
static func _sector() -> PackedVector2Array:
 var result := PackedVector2Array([Vector2.ZERO])
 for i in range(21): result.append(Vector2.from_angle(-PI*0.29+i*PI*0.58/20))
 result.append(Vector2.ZERO)
 return result
static func _spiral() -> PackedVector2Array:
 var result := PackedVector2Array()
 for i in range(49):
  var t := i/48.0
  result.append(Vector2.from_angle(t*TAU*1.35)*(0.15+t*0.85))
 return result
static func _paper_path() -> PackedVector2Array:
 var result := PackedVector2Array()
 var corners := [Vector2(7,-11),Vector2(7,11),Vector2(-7,11),Vector2(-7,-11)]
 for corner in range(4):
  for step in range(6):
   result.append(corners[corner]+Vector2.from_angle(-PI/2+corner*PI/2+step*PI/10)*3)
 result.append(result[0])
 return result
