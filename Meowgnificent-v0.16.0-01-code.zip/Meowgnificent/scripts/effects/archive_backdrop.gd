class_name ArchiveBackdrop
extends Node2D

# HD Pastel Storybook 2D: each location has a full-resolution hand-drawn scene.
# Room caches this painter once per arrival; gameplay draws one background quad.
const STORAGE: Texture2D = preload("res://art/hd/hd_basement_storeroom.res")
const LIBRARY: Texture2D = preload("res://art/hd/hd_academy_library.res")
const GARDEN: Texture2D = preload("res://art/hd/hd_forbidden_garden.res")
const ARCHIVE: Texture2D = preload("res://art/hd/hd_grand_archive.res")
const LIVING_REAGENTS: Texture2D = preload("res://art/enemies/living_reagents.png")
const THEMES := ["candlewick", "loose_ends", "sootbound", "kettle_quill", "restricted", "bellkeeper", "paper_moon", "final_exam"]
const STORY_LANDMARKS := [
	["basement", "violet_control_seal"],
	["synchronized_books", "violet_control_seal"],
	["equal_height_plants", "mushroom_grid", "violet_control_seal"],
	["picnic", "chicken"],
	["reading_room", "unruly_vines"],
	["ordered_tiles", "city_memorial"],
	["basement", "pink_picnic"],
	["archive_tome", "analysis_seal"]
]
const PAPER := Color("fff4d7")
const PAPER_EDGE := Color("d7b886")
var stage_index := 0
# Cutscenes reuse this exact environment painter without the gameplay HUD mat.
var include_frame := true
# Cutscenes supply the six animated living props instead of painted duplicates.
var foreground_living_props := false
# Live maps can hide screen framing while retaining genuine enemy spawn marks.
var gameplay_landmarks := false

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func configure(index: int) -> void:
	stage_index=clampi(index,0,THEMES.size()-1)
	queue_redraw()

func theme_id() -> String:
	return THEMES[stage_index]

func narrative_landmarks() -> PackedStringArray:
	return PackedStringArray(STORY_LANDMARKS[stage_index])

func floating_book_positions() -> PackedVector2Array:
	var result := PackedVector2Array()
	for column in range(8): result.append(Vector2(336+column*91,254))
	return result

func mushroom_positions() -> PackedVector2Array:
	var result := PackedVector2Array()
	for row in range(3):
		for column in range(6): result.append(Vector2(350+column*104,320+row*63))
	return result

func _location_art() -> Texture2D:
	match stage_index:
		0,6: return STORAGE
		1,4: return LIBRARY
		2,3,5: return GARDEN
		_: return ARCHIVE

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,800),PAPER)
	var washes := [Color.WHITE,Color.WHITE,Color("f4f0ff"),Color("fff5e9"),Color("f2f8ff"),Color("eaf8f8"),Color("fff2f7"),Color.WHITE]
	draw_texture_rect(_location_art(),Rect2(0,0,1280,800),false,washes[stage_index])
	if gameplay_landmarks: _live_floor_accents()
	# Painted floor pieces distinguish the route without adding obstacles.
	# These are included in the same one-time room cache as the HD plate.
	match stage_index:
		0:
			for point in [Vector2(730,295),Vector2(850,390),Vector2(1030,490)]: _control_seal(point,17,0.18)
		1:
			_synchronized_books()
			for point in [Vector2(250,380),Vector2(615,520),Vector2(1005,625)]: _control_seal(point,17,0.15)
		2:
			_perfect_garden()
			_control_seal(Vector2(640,455),34,0.14)
		3:
			_picnic_mat(Rect2(350,350,580,274),Color("daeadb"),Color("fff4dc"))
		4:
			_reading_runners()
			# The HD reading-room plate already paints ivy around its shelves.
			# Avoid drawing flat zigzag vines across that detailed floor.
		5:
			_ordered_stepping_tiles()
			_reagent_beds(true)
			_city_memorial()
		6: _picnic_mat(Rect2(270,338,740,304),Color("efd9e5"),Color("fff3dc"))
		7: _control_seal(Vector2(640,202),35,0.23)
	if stage_index in [1,4]: _story_tag(Vector2(504,176),"RETURN DESK / GUARD SPELL")
	if stage_index in [2,5]: _story_tag(Vector2(912,255),"POTION CROP / PROTECTION SPELL")
	if not include_frame: return
	# Light stationery framing follows the HUD. No pixel sampling or posterize.
	draw_rect(Rect2(0,0,1280,118),PAPER)
	draw_rect(Rect2(0,714,1280,86),PAPER)
	draw_rect(Rect2(0,114,1280,4),Color("e7cfa1"))
	draw_rect(Rect2(0,714,1280,4),Color("e7cfa1"))
	draw_line(Vector2(46,110),Vector2(1234,110),PAPER_EDGE,1,true)
	draw_line(Vector2(46,722),Vector2(1234,722),PAPER_EDGE,1,true)

func _rounded(rect: Rect2, fill: Color, outline: Color, radius: int, width := 1) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=outline
	style.set_border_width_all(width)
	style.set_corner_radius_all(radius)
	style.anti_aliasing=true
	draw_style_box(style,rect)

func _reading_runners() -> void:
	for x in [335.0,945.0]:
		WorldDetailArt.draw_floor(self,"runner",Rect2(x-48,289,96,340))

func _live_floor_accents() -> void:
	# The larger map reveals more quiet floor between encounters. Small woven
	# reading mats give those stretches a human scale without adding obstacles
	# or noisy marks near the center, where spell warnings need clear contrast.
	# These four painted details are baked into the room's single cached quad;
	# canonical cutscene plates and their staging remain untouched.
	if stage_index not in [1,7]: return
	var tint := Color("ede4e1") if stage_index==1 else Color("f2e8d6")
	for x in [270.0,1030.0]:
		for y in [365.0,555.0]:
			WorldDetailArt.draw_floor(self,"runner",Rect2(x-23,y-62,46,124),tint)

func _ordered_stepping_tiles() -> void:
	# The ordered garden still has the same precise walkable grid, now made
	# from painted stone with chipped edges, moss and softly shaded thickness.
	for row in range(4):
		for col in range(6):
			var point := Vector2(286+col*119,303+row*86)
			WorldDetailArt.draw_floor(self,"paver",Rect2(point,Vector2(106,61)))

func _picnic_mat(rect: Rect2, base: Color, _trim: Color) -> void:
	# The same woven drawing is gently warmed for the final stop. Its weave,
	# folds and fringe replace the huge flat grid of rounded UI rectangles.
	var tint := Color("ffe5ed") if base==Color("efd9e5") else Color.WHITE
	WorldDetailArt.draw_floor(self,"picnic_mat",rect,tint)

func _shadow(center: Vector2, size: Vector2) -> void:
	draw_set_transform(center,0,size)
	draw_circle(Vector2.ZERO,1,Color(0.40,0.35,0.45,0.10),true,-1,true)
	draw_set_transform(Vector2.ZERO)

func _control_seal(center: Vector2, radius: float, opacity: float) -> void:
	# Quiet, permanent floor inscriptions are visually separate from coral
	# attack warnings. Their repeated form is the trail the story follows.
	var ink := Color(0.58,0.46,0.70,opacity)
	draw_set_transform(center,0,Vector2(1,0.44))
	draw_circle(Vector2.ZERO,radius,Color(ink,opacity*0.20),true,-1,true)
	draw_arc(Vector2.ZERO,radius,0,TAU,32,ink,1.5,true)
	var points := PackedVector2Array()
	for i in range(7): points.append(Vector2.from_angle(-PI/2+i*TAU/6)*radius*0.72)
	draw_polyline(points,ink,1.5,true)
	for i in range(3):
		var at := Vector2.from_angle(i*TAU/3)*radius*0.57
		draw_line(at,-at,ink,1,true)
	draw_set_transform(Vector2.ZERO)

func live_book_positions() -> PackedVector2Array:
	var points := PackedVector2Array()
	for column in range(6): points.append(Vector2(470+112*column,310))
	return points

func live_mushroom_positions(promenade: bool=false) -> PackedVector2Array:
	var points := PackedVector2Array()
	for row in range(2):
		for column in range(3): points.append(Vector2(560+200*column,350+200*row) if promenade else Vector2(565+180*column,340+180*row))
	return points

func _synchronized_books() -> void:
	if foreground_living_props: return
	if include_frame or gameplay_landmarks:
		# The six matching books are live actors; only their patrol marks are
		# baked into the floor. Their enemy positions and collision are unchanged.
		for point in live_book_positions(): _control_seal(point,21,0.20)
		return
	for point in floating_book_positions():
		_shadow(point+Vector2(0,27),Vector2(21,4.8))
		draw_texture_rect(LivingStageArt.icon("book"),Rect2(point+Vector2(-28,-20),Vector2(56,52)),false)

func _reagent_beds(promenade: bool=false) -> void:
	if foreground_living_props: return
	for point in live_mushroom_positions(promenade):
		WorldDetailArt.draw_floor(self,"soil_bed",Rect2(point+Vector2(-43,-23),Vector2(86,46)))
		_control_seal(point+Vector2(0,4),26,0.23)
	# The same six crops have left these beds and now block the path.

func _perfect_garden() -> void:
	if foreground_living_props: return
	if include_frame or gameplay_landmarks:
		_reagent_beds()
		# Equal-height, evenly spaced flowers are already painted into the HD
		# garden plate. Extra circles on stalks made those flowers look unfinished.
		return
	for point in mushroom_positions():
		_shadow(point+Vector2(0,5),Vector2(16,3.4))
		draw_texture_rect(LivingStageArt.icon("mushroom"),Rect2(point+Vector2(-18,-37),Vector2(36,43)),false)

func _city_memorial() -> void:
	WorldDetailArt.draw_floor(self,"memorial",Rect2(526,146,228,124))
	_control_seal(Vector2(641,189),25,0.45)

func _story_tag(at: Vector2,key: String) -> void:
	var font := GameLocale.STORY_FONT
	var caption := GameLocale.text(key)
	var width := font.get_string_size(caption,HORIZONTAL_ALIGNMENT_LEFT,-1,15).x
	_rounded(Rect2(at-Vector2(12,22),Vector2(width+24,33)),Color("f5e7c9"),Color("c5ae90"),8)
	draw_string(font,at,caption,HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("7e665b"))
