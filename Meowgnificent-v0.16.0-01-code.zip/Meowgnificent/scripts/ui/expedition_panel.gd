class_name ExpeditionPanel
extends CanvasLayer

const INK := Color("654e45")
const MUTED := Color("7c6c60")
const GOLD := Color("806348")
const SLOT_NAMES := {"wand":"PRIMARY TOOL", "collar":"COLLAR", "charm":"HAT CHARM"}
const STAT_NAMES := {
	"max_hp_bonus":"Max vitality", "speed_bonus":"Move speed",
	"spell_damage_bonus":"Spell damage", "spell_cooldown_multiplier":"Spell recovery",
	"roll_damage_bonus":"Roll damage", "roll_cooldown_multiplier":"Roll recovery",
	"pickup_radius_bonus":"Pickup reach", "skill_damage_bonus":"Special damage",
	"skill_cooldown_multiplier":"Special recovery", "skill_radius_bonus":"Special reach"
}
var skill_definitions: Dictionary = {}

var room: Node2D
var mode := "inventory"
var is_open := false
var screen: Control
var heading: Label
var subtitle: Label
var gold_label: Label
var content: VBoxContainer
var notice: Label
var close_button: Button
var satchel_button: Button
var purchase_buttons: Array[Button] = []
var feedback := ""
var feedback_color := MUTED
var preview_item_id := ""
var selected_item_id := ""
var comparison_hints: Array[Dictionary] = []
var item_buttons: Dictionary = {}
var slot_buttons: Dictionary = {}
var preview_model: EquipmentPaperdoll
var equip_button: Button
var discard_button: Button
var discard_item_id := ""
var detail_title: Label
var detail_subtitle: Label
var stats_container: VBoxContainer
var shop_portrait: TextureRect

func _ready() -> void:
	if FileAccess.file_exists("res://data/skills.json"):
		skill_definitions=JSON.parse_string(FileAccess.get_file_as_string("res://data/skills.json"))
	layer=20
	screen=Control.new()
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter=Control.MOUSE_FILTER_STOP
	add_child(screen)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color=Color(0.90,0.87,0.75,0.68)
	shade.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(shade)
	var panel := PanelContainer.new()
	panel.position=Vector2(110,72)
	panel.size=Vector2(1060,656)
	panel.add_theme_stylebox_override("panel",_style(Color("fff7e6"),Color("c3a286"),22,25))
	screen.add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation",13)
	panel.add_child(column)
	var eyebrow := _label("THE CANDLEWICK EXPEDITION",12,GOLD)
	column.add_child(eyebrow)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation",12)
	column.add_child(header)
	shop_portrait=TextureRect.new()
	shop_portrait.custom_minimum_size=Vector2(44,52)
	shop_portrait.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	shop_portrait.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	shop_portrait.mouse_filter=Control.MOUSE_FILTER_IGNORE
	shop_portrait.hide()
	header.add_child(shop_portrait)
	heading=_label("Traveling possessions",30,INK)
	heading.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	header.add_child(heading)
	gold_label=_label("",23,GOLD)
	header.add_child(gold_label)
	subtitle=_label("",14,MUTED)
	column.add_child(subtitle)
	var rule := HSeparator.new()
	rule.add_theme_stylebox_override("separator",_style(Color("dfcfb5"),Color("dfcfb5"),0,0))
	column.add_child(rule)
	content=VBoxContainer.new()
	content.custom_minimum_size=Vector2(0,423)
	content.size_flags_vertical=Control.SIZE_EXPAND_FILL
	column.add_child(content)
	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation",18)
	column.add_child(footer)
	notice=_label("",13,MUTED)
	notice.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	notice.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	footer.add_child(notice)
	satchel_button=_button("I · Satchel",true)
	satchel_button.custom_minimum_size=Vector2(142,42)
	satchel_button.pressed.connect(func(): room.open_inventory())
	footer.add_child(satchel_button)
	close_button=_button("Return to the archives  /  ESC",false)
	close_button.custom_minimum_size=Vector2(295,42)
	close_button.pressed.connect(_request_close)
	footer.add_child(close_button)
	screen.hide()

func open_inventory() -> void:
	mode="inventory"
	_open()

func open_shop() -> void:
	mode="shop"
	_open()

func open_meta() -> void:
	mode="meta"
	_open()

func _open() -> void:
	is_open=true
	feedback=""
	feedback_color=MUTED
	preview_item_id=""
	selected_item_id=""
	screen.show()
	refresh(false)
	close_button.grab_focus()

func close() -> void:
	is_open=false
	if is_instance_valid(screen): screen.hide()

func refresh(keep_focus: bool=true) -> void:
	if not is_instance_valid(content) or not is_instance_valid(room): return
	var focused: Control=screen.get_viewport().gui_get_focus_owner()
	var restore_focus := keep_focus and focused!=null and content.is_ancestor_of(focused)
	discard_item_id=""
	for child in content.get_children():
		content.remove_child(child)
		child.queue_free()
	purchase_buttons.clear()
	stats_container=null
	item_buttons.clear()
	slot_buttons.clear()
	comparison_hints.clear()
	shop_portrait.visible=mode=="shop"
	satchel_button.visible=mode=="shop"
	close_button.text="Back to Pip  /  ESC" if mode=="inventory" and room.inventory_from_shop else "Return to the archives  /  ESC"
	if mode=="shop": shop_portrait.texture=AnimalCast.icon("pip")
	gold_label.text=GameLocale.text("%d  STARLIGHT") % room.profile.starlight if mode=="meta" else GameLocale.text("%d  CROWNS") % room.run.gold
	if mode=="meta":
		heading.text="Legacy Study"
		subtitle.text=GameLocale.text("Retained after defeat. Your studies strengthen the next expedition.\n%d expeditions  ·  %d clears  ·  Furthest sector %d") % [room.profile.attempts,room.profile.wins,room.profile.best_sector]
		_build_meta()
	elif mode=="shop":
		heading.text="Pip's Finds"
		subtitle.text="Spend your finds before the next fight. Purchases stay with this expedition."
		_build_shop()
	else:
		heading.text="Traveling possessions"
		subtitle.text="A little hat, a lucky trinket, your favorite wand."
		_build_inventory()
	var hint := "Hover to peek. Select, then equip.  ·  I / ESC: back"
	if mode=="shop":
		hint="Satchel full. Make room before buying equipment." if room.run.inventory.size()>=ExpeditionRun.INVENTORY_LIMIT else "1–4 purchase  ·  ESC return"
	elif mode=="meta": hint="1–4 study  ·  M or ESC return  ·  Applies to the next expedition"
	notice.text=feedback if not feedback.is_empty() else hint
	notice.modulate=feedback_color if not feedback.is_empty() else MUTED
	# Rebuilding the grid must not drop keyboard users back into the game or
	# strand focus on a freed Equip/Purchase control.
	if restore_focus: _restore_content_focus.call_deferred()

func _restore_content_focus() -> void:
	if not is_open: return
	if mode=="inventory" and item_buttons.has(selected_item_id):
		item_buttons[selected_item_id].grab_focus()
	elif mode=="shop" or mode=="meta":
		for button: Button in purchase_buttons:
			if not button.disabled:
				button.grab_focus()
				return
		if mode=="shop": satchel_button.grab_focus()
		else: close_button.grab_focus()
	else: close_button.grab_focus()

func _build_inventory() -> void:
	var owned: Array=room.run.inventory
	if not owned.has(selected_item_id):
		selected_item_id=str(room.run.equipment.get("wand",""))
		if not owned.has(selected_item_id): selected_item_id=str(owned[0]) if not owned.is_empty() else ""
	preview_item_id=selected_item_id
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",18)
	row.size_flags_vertical=Control.SIZE_EXPAND_FILL
	content.add_child(row)
	var wardrobe := _card(Color("edf2e4"),Color("c2cba9"),0)
	wardrobe.custom_minimum_size=Vector2(414,423)
	row.add_child(wardrobe)
	var canvas := Control.new()
	canvas.custom_minimum_size=Vector2(410,419)
	wardrobe.add_child(canvas)
	preview_model=EquipmentPaperdoll.new()
	preview_model.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	preview_model.set_equipment(room.run.equipment)
	canvas.add_child(preview_model)
	var who := _label("Meowmalade",20,INK)
	who.position=Vector2(105,365)
	who.size=Vector2(200,28)
	who.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	canvas.add_child(who)
	var wearing := _label("Dressed for a little mischief",12,MUTED)
	wearing.position=Vector2(75,395)
	wearing.size=Vector2(260,20)
	wearing.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	canvas.add_child(wearing)
	for slot in ["charm","collar","wand"]:
		var at: Vector2={"charm":Vector2(15,27),"collar":Vector2(15,229),"wand":Vector2(326,229)}[slot]
		var id := str(room.run.equipment.get(slot,""))
		var button := _button("",true)
		button.position=at
		button.size=Vector2(64,64)
		button.custom_minimum_size=Vector2(64,64)
		button.set_meta("slot",slot)
		button.set_meta("equipment_id",id)
		button.pressed.connect(_select_slot.bind(slot))
		canvas.add_child(button)
		slot_buttons[slot]=button
		if id.is_empty():
			var glyph := EquipmentSymbol.new(slot)
			glyph.position=Vector2(18,18)
			glyph.size=Vector2(28,28)
			button.add_child(glyph)
		else:
			var icon := _item_icon(id,0)
			icon.position=Vector2(7,7)
			icon.size=Vector2(50,50)
			button.add_child(icon)
		var label := _label(str(SLOT_NAMES[slot]),11,GOLD)
		label.position=at+Vector2(-9,68)
		label.size=Vector2(82,20)
		label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		label.clip_text=true
		canvas.add_child(label)
	var bag := VBoxContainer.new()
	bag.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	bag.add_theme_constant_override("separation",8)
	row.add_child(bag)
	bag.add_child(_label(GameLocale.text("SATCHEL  /  %d OF 18") % owned.size(),13,GOLD))
	var grid := GridContainer.new()
	grid.name="OwnedEquipmentGrid"
	grid.columns=6
	grid.add_theme_constant_override("h_separation",9)
	grid.add_theme_constant_override("v_separation",8)
	bag.add_child(grid)
	for index in range(18):
		var id := str(owned[index]) if index<owned.size() else ""
		var button := _gear_tile(id)
		grid.add_child(button)
		if not id.is_empty(): item_buttons[id]=button
	var detail := _card(Color("fffaef"),Color("d2bda0"),10)
	detail.custom_minimum_size=Vector2(0,150)
	detail.size_flags_vertical=Control.SIZE_EXPAND_FILL
	bag.add_child(detail)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",6)
	detail.add_child(box)
	var title_row := HBoxContainer.new()
	box.add_child(title_row)
	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	title_row.add_child(title_box)
	detail_title=_label("Choose a little treasure",17,INK)
	detail_title.clip_text=true
	detail_title.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	detail_title.custom_minimum_size=Vector2(0,25)
	title_box.add_child(detail_title)
	detail_subtitle=_label("",11,MUTED)
	detail_subtitle.custom_minimum_size=Vector2(0,17)
	detail_subtitle.clip_text=true
	title_box.add_child(detail_subtitle)
	equip_button=_button("Equip",false)
	equip_button.custom_minimum_size=Vector2(104,38)
	equip_button.pressed.connect(_equip_selected)
	title_row.add_child(equip_button)
	discard_button=_button("Discard",true)
	discard_button.name="DiscardEquipment"
	discard_button.custom_minimum_size=Vector2(94,38)
	discard_button.pressed.connect(_discard_selected)
	title_row.add_child(discard_button)
	stats_container=VBoxContainer.new()
	# Reserve the same space for worn gear and a candidate's arrow chips.
	# A hover must never resize the wardrobe or move the return control.
	stats_container.custom_minimum_size=Vector2(0,76)
	stats_container.add_theme_constant_override("separation",4)
	box.add_child(stats_container)
	_render_stats()

func _gear_tile(id: String) -> Button:
	var tile := _button("",true)
	tile.custom_minimum_size=Vector2(78,70)
	if id.is_empty():
		tile.disabled=true
		tile.mouse_filter=Control.MOUSE_FILTER_IGNORE
		return tile
	var item: Dictionary=room.run.item_info(id)
	tile.set_meta("equipment_id",id)
	tile.pressed.connect(_select_item.bind(id))
	tile.mouse_entered.connect(_preview_item.bind(id))
	tile.focus_entered.connect(_preview_item.bind(id))
	tile.mouse_exited.connect(_clear_hover)
	tile.focus_exited.connect(_clear_hover)
	var icon := _item_icon(id,0)
	icon.position=Vector2(11,6)
	icon.size=Vector2(56,56)
	tile.add_child(icon)
	if str(room.run.equipment.get(str(item.slot),""))==id:
		var badge := _label("Worn",9,Color("4c7655"))
		badge.position=Vector2(24,51)
		badge.size=Vector2(50,16)
		badge.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
		tile.add_child(badge)
	return tile

func _select_slot(slot: String) -> void:
	var id := str(room.run.equipment.get(slot,""))
	if not id.is_empty(): _select_item(id)

func _select_item(id: String) -> void:
	if not room.run.inventory.has(id) or not room.run.catalog.has(id): return
	if selected_item_id!=id: _cancel_discard()
	selected_item_id=id
	preview_item_id=id
	_render_stats()

func _clear_hover() -> void:
	if not is_instance_valid(stats_container): return
	preview_item_id=selected_item_id
	_render_stats()

func _equip_selected() -> void:
	if not is_open or mode!="inventory" or not room.run.inventory.has(selected_item_id): return
	if preview_item_id!=selected_item_id: return
	var item: Dictionary=room.run.item_info(selected_item_id)
	if str(room.run.equipment.get(str(item.slot),""))==selected_item_id: _unequip(str(item.slot))
	else: _equip(selected_item_id)

func _cancel_discard() -> void:
	if discard_item_id.is_empty(): return
	discard_item_id=""
	if is_instance_valid(notice):
		notice.text=feedback if not feedback.is_empty() else "Hover to peek. Select, then equip.  ·  I / ESC: back"
		notice.modulate=feedback_color if not feedback.is_empty() else MUTED

func _discard_selected() -> void:
	if not is_open or mode!="inventory" or preview_item_id!=selected_item_id: return
	if not room.run.inventory.has(selected_item_id) or room.run.equipment.values().has(selected_item_id): return
	if discard_item_id!=selected_item_id:
		discard_item_id=selected_item_id
		discard_button.text="Discard?"
		notice.text="Press Discard again to remove this unworn item. Select another item to cancel."
		notice.modulate=Color("ab5c51")
		return
	if not room.run.discard_item(selected_item_id): return
	feedback="Left the item behind. Your satchel has room again."
	feedback_color=MUTED
	selected_item_id=""
	preview_item_id=""
	refresh()

func _item_icon(id: String, extent: int=56) -> TextureRect:
	var art := TextureRect.new()
	art.texture=EquipmentArt.icon(id)
	if id=="sardine_tin": art.texture=preload("res://art/items/drop_food.svg")
	art.custom_minimum_size=Vector2(extent,extent)
	art.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	art.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	art.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	art.mouse_filter=Control.MOUSE_FILTER_IGNORE
	art.set_meta("equipment_id",id)
	return art

func _compact_button(button: Button, inset: int) -> void:
	for state in ["normal","hover","pressed","disabled","focus"]:
		var original := button.get_theme_stylebox(state)
		if original is StyleBoxFlat:
			var style: StyleBoxFlat=original.duplicate()
			style.content_margin_top=inset
			style.content_margin_bottom=inset
			style.content_margin_left=inset
			style.content_margin_right=inset
			button.add_theme_stylebox_override(state,style)

func _preview_item(id: String) -> void:
	if mode!="inventory" or not is_instance_valid(stats_container): return
	if not room.run.inventory.has(id) or not room.run.catalog.has(id) or preview_item_id==id: return
	if id!=selected_item_id: _cancel_discard()
	preview_item_id=id
	_render_stats()

func _hint_chip(row: Dictionary) -> PanelContainer:
	var quality := int(row.quality)
	var chip := _card(Color("e8f1df") if quality>0 else Color("f7e5e5"),Color("c8d6b9") if quality>0 else Color("e3c6cd"),4)
	chip.set_meta("stat_key",str(row.key))
	chip.set_meta("improvement",quality)
	chip.set_meta("direction","up" if quality>0 else "down")
	chip.mouse_filter=Control.MOUSE_FILTER_IGNORE
	var line := HBoxContainer.new()
	line.add_theme_constant_override("separation",4)
	chip.add_child(line)
	line.add_child(EquipmentSymbol.new(str(row.key)))
	line.add_child(_label(str(row.label),12,INK))
	line.add_child(EquipmentSymbol.new("arrow",quality))
	return chip

func _render_stats() -> void:
	if not is_instance_valid(stats_container): return
	for child in stats_container.get_children():
		stats_container.remove_child(child)
		child.queue_free()
	comparison_hints.clear()
	for id: String in item_buttons:
		var tile: Button=item_buttons[id]
		var item: Dictionary=room.run.item_info(id)
		var border := _rarity_color(str(item.get("rarity","common"))).lightened(0.35)
		var fill := Color("fff9ed")
		if id==selected_item_id: fill=Color("eee4f3"); border=Color("a58bb7")
		elif id==preview_item_id: fill=Color("f5eedb"); border=Color("b9a16e")
		tile.add_theme_stylebox_override("normal",_style(fill,border,12,4))
	if not room.run.inventory.has(preview_item_id):
		detail_title.text="Choose a little treasure"
		detail_subtitle.text="Find equipment on your adventures."
		equip_button.disabled=true
		discard_button.disabled=true
		stats_container.set_meta("changes",comparison_hints)
		return
	var item: Dictionary=room.run.item_info(preview_item_id)
	var wearing := str(room.run.equipment.get(str(item.slot),""))==preview_item_id
	detail_title.text=GameLocale.text(str(item.name))
	detail_subtitle.text=GameLocale.text(str(SLOT_NAMES[str(item.slot)]))
	if str(item.slot)=="wand":
		var basic := BasicMagic.for_item(item)
		detail_subtitle.text=GameLocale.text("Basic magic: %s") % GameLocale.text(str(basic.name))
	equip_button.text="Put away" if wearing else "Equip"
	equip_button.disabled=preview_item_id!=selected_item_id
	discard_button.text="Discard?" if discard_item_id==selected_item_id and not discard_item_id.is_empty() else "Discard"
	discard_button.disabled=wearing or preview_item_id!=selected_item_id
	var current := CharacterStats.for_room(room)
	var after := CharacterStats.for_room(room,preview_item_id)
	comparison_hints=EquipmentComparison.changes(current,after)
	stats_container.set_meta("changes",comparison_hints.duplicate(true))
	if not comparison_hints.is_empty():
		var flow := HFlowContainer.new()
		flow.add_theme_constant_override("h_separation",6)
		flow.add_theme_constant_override("v_separation",4)
		stats_container.add_child(flow)
		for hint: Dictionary in comparison_hints: flow.add_child(_hint_chip(hint))
	else:
		stats_container.add_child(_label("Already wearing it!" if wearing else "Feels just as comfy",12,MUTED))
	var skill := _skill_definition(item)
	if not skill.is_empty():
		var different := str(after.skill_id)!=str(current.skill_id)
		var caption := GameLocale.text("New special: %s" if different else "Q special: %s") % GameLocale.text(str(skill.name))
		stats_container.add_child(_skill_name_label(caption,str(skill.get("description",""))))
	if str(item.slot)=="wand":
		var basic := BasicMagic.for_item(item)
		var trait_label := _label(str(basic.trait),11,MUTED)
		trait_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		stats_container.add_child(trait_label)

func _build_shop() -> void:
	# Longer skill descriptions stay inside the window; the footer remains
	# reachable in both languages, regardless of the randomized stock names.
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(0,385)
	scroll.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns=2
	grid.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	grid.size_flags_vertical=Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation",16)
	grid.add_theme_constant_override("v_separation",14)
	scroll.add_child(grid)
	for index in range(room.shop_offers.size()):
		grid.add_child(_offer_card(index,room.shop_offers[index]))
	if room.shop_offers.is_empty():
		content.add_child(_label("The merchant has packed up. Perhaps farther into the archives.",18,MUTED))

func _build_meta() -> void:
	var grid := GridContainer.new()
	grid.columns=2
	grid.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	grid.size_flags_vertical=Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation",16)
	grid.add_theme_constant_override("v_separation",14)
	content.add_child(grid)
	var offers: Array=room.profile.upgrade_offers()
	for index in range(offers.size()):
		var offer: Dictionary=offers[index]
		grid.add_child(_upgrade_card(index,offer))

func _upgrade_card(index: int, offer: Dictionary) -> PanelContainer:
	var id := str(offer.get("id",""))
	var level := int(offer.get("level",0))
	var limit := int(offer.get("max_level",1))
	var cost := int(offer.get("cost",0))
	var capped := level>=limit
	var affordable: bool=room.profile.starlight>=cost
	var card := _card(Color("f3eaf7"),Color("baa6c6"),17)
	card.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	card.size_flags_vertical=Control.SIZE_EXPAND_FILL
	card.custom_minimum_size=Vector2(0,202)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",7)
	card.add_child(box)
	box.add_child(_label(GameLocale.text("%02d  /  PERMANENT STUDY  /  %d OF %d") % [index+1,level,limit],11,Color("80618e")))
	var name_label := _label(str(offer.get("name",id)),21,INK)
	name_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(name_label)
	var desc := _label(str(offer.get("description","")),14,MUTED)
	desc.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	desc.size_flags_vertical=Control.SIZE_EXPAND_FILL
	box.add_child(desc)
	var level_hint := _label("Fully studied. Kept for every new expedition." if capped else GameLocale.text("Next rank: %d / %d  ·  Takes effect on the next expedition.") % [level+1,limit],12,Color("6b795e"))
	level_hint.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(level_hint)
	var caption := "Fully studied" if capped else GameLocale.text("Study  /  %d starlight") % cost
	if not capped and not affordable: caption=GameLocale.text("Need %d starlight  /  Cost %d") % [cost-room.profile.starlight,cost]
	var button := _button(caption,capped)
	button.custom_minimum_size=Vector2(0,38)
	button.disabled=capped or not affordable
	button.pressed.connect(buy_upgrade.bind(id))
	box.add_child(button)
	purchase_buttons.append(button)
	return card

func _offer_card(index: int, offer: Dictionary) -> PanelContainer:
	var id := str(offer.get("id",""))
	var healing := str(offer.get("kind","gear"))=="heal"
	var item: Dictionary=room.run.item_info(id)
	var rarity := "provisions" if healing else str(item.get("rarity","common"))
	var card := _card(Color("f0f3e4"),_rarity_color(rarity).lightened(0.32),17)
	card.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	card.size_flags_vertical=Control.SIZE_EXPAND_FILL
	card.custom_minimum_size=Vector2(0,202)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",7)
	card.add_child(box)
	box.add_child(_label(GameLocale.text("%02d  /  %s") % [index+1,GameLocale.text(rarity.to_upper())],11,_rarity_color(rarity)))
	var title_row := HBoxContainer.new()
	title_row.add_theme_constant_override("separation",12)
	box.add_child(title_row)
	title_row.add_child(_item_icon("sardine_tin" if healing else id,60))
	var name_label := _label("Sardine tin" if healing else str(item.get("name",id)),21,INK)
	name_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	name_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	title_row.add_child(name_label)
	var description := _label("Restore 35 vitality. A practical purchase for an impractical wizard." if healing else str(SLOT_NAMES.get(str(item.get("slot","")),"")),13,MUTED)
	description.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	box.add_child(description)
	if not healing and str(item.get("slot",""))=="wand":
		var basic := BasicMagic.for_item(item)
		description.text=GameLocale.text("Basic magic: %s") % GameLocale.text(str(basic.name))
	if not healing:
		var before := CharacterStats.for_room(room)
		var after := CharacterStats.for_room(room,id)
		var changes := EquipmentComparison.changes(before,after)
		var flow := HFlowContainer.new()
		flow.add_theme_constant_override("h_separation",5)
		flow.add_theme_constant_override("v_separation",4)
		box.add_child(flow)
		for change: Dictionary in changes: flow.add_child(_hint_chip(change))
		var skill := _skill_definition(item)
		if not skill.is_empty(): box.add_child(_skill_name_label(GameLocale.text("New special: %s" if str(before.skill_id)!=str(after.skill_id) else "Q special: %s") % GameLocale.text(str(skill.name)),str(skill.get("description",""))))
	var price := int(offer.get("price",0))
	var sold := bool(offer.get("sold",false))
	var full_health: bool=healing and room.player.health.current>=room.player.health.maximum
	var full_bag: bool=not healing and room.run.inventory.size()>=ExpeditionRun.INVENTORY_LIMIT
	var affordable: bool=room.run.gold>=price
	var caption := "Bought" if sold else ("Vitality full" if full_health else (GameLocale.text("Buy  /  %d crowns") % price))
	if not sold and full_bag: caption="Satchel full"
	elif not sold and not full_health and not affordable: caption=GameLocale.text("Need %d crowns  /  Price %d") % [price-room.run.gold,price]
	var button := _button(caption,sold)
	button.custom_minimum_size=Vector2(0,38)
	button.disabled=sold or full_health or full_bag or not affordable
	button.pressed.connect(buy_offer.bind(index))
	box.add_child(button)
	purchase_buttons.append(button)
	return card

func buy_offer(index: int) -> void:
	if not is_open or mode!="shop" or index<0 or index>=room.shop_offers.size(): return
	var result: Dictionary=room.purchase_offer(index)
	if bool(result.get("ok",false)):
		var id := str(result.get("item_id",""))
		feedback="Vitality restored. Ready for more questionable magic." if int(result.get("heal",0))>0 else GameLocale.text("%s is in your satchel. Open I to equip it.") % GameLocale.text(str(room.run.item_info(id).get("name","Your purchase")))
		feedback_color=Color("4e7857")
	else:
		feedback=str(result.get("reason","The merchant cannot make that trade."))
		feedback_color=Color("ab5c51")
	refresh()

func buy_upgrade_at(index: int) -> void:
	if not is_open or mode!="meta": return
	var offers: Array=room.profile.upgrade_offers()
	if index>=0 and index<offers.size():
		buy_upgrade(str(offers[index].get("id","")))

func buy_upgrade(id: String) -> void:
	if not is_open or mode!="meta": return
	var result: Dictionary=room.purchase_upgrade(id)
	var ok := bool(result.get("ok",false))
	feedback="Study recorded. Your next expedition inherits it." if ok else str(result.get("reason","This study is not available yet."))
	feedback_color=Color("4e7857") if ok else Color("ab5c51")
	refresh()

func _equip(id: String) -> void:
	var ok: bool=room.equip_gear(id)
	feedback=(GameLocale.text("Equipped %s.") % GameLocale.text(str(room.run.item_info(id).get("name",id)))) if ok else "That item cannot be equipped."
	feedback_color=Color("4e7857") if ok else Color("ab5c51")
	refresh()

func _unequip(slot: String) -> void:
	var ok: bool=room.unequip_gear(slot)
	feedback="Put away. It stays safe in your satchel." if ok else "That slot is already empty."
	feedback_color=MUTED
	refresh()

func _request_close() -> void:
	room.close_panel()

func _stats_text(stats: Dictionary) -> String:
	var parts: Array[String]=[]
	for key in STAT_NAMES:
		if not stats.has(key): continue
		var amount := float(stats[key])
		if str(key).ends_with("_multiplier"):
			if is_equal_approx(amount,1.0): continue
			parts.append(GameLocale.text("%s %+.0f%%") % [GameLocale.text(STAT_NAMES[key]),(amount-1)*100])
		elif not is_zero_approx(amount):
			parts.append(GameLocale.text("%s %+.0f") % [GameLocale.text(STAT_NAMES[key]),amount])
	return "  ·  ".join(parts)

func _skill_name_label(caption: String, description: String) -> Label:
	var label := _label(caption,12,Color("886295"))
	label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	label.clip_text=true
	label.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	label.tooltip_text=caption+"\n"+GameLocale.text(description)
	return label

func _skill_definition(item: Dictionary) -> Dictionary:
	var all: Dictionary=skill_definitions.get("skills",skill_definitions)
	return all.get(str(item.get("skill_id","")),{})

func _skill_caption(item: Dictionary) -> String:
	var skill := _skill_definition(item)
	if skill.is_empty(): return ""
	return GameLocale.text("Q / RMB · %s · %.0fs") % [GameLocale.text(str(skill.get("name",""))),float(skill.get("cooldown",0))]

func _skill_description(item: Dictionary) -> String:
	var skill := _skill_definition(item)
	return GameLocale.text(str(skill.get("description","")))+"\n"+GameLocale.text("Special skills can miscast or overreact, too.")

func _comparison_text(item: Dictionary, equipped_id: String) -> String:
	var old: Dictionary=room.run.item_info(equipped_id)
	var old_stats: Dictionary=old.get("stats",{})
	var new_stats: Dictionary=item.get("stats",{})
	var differences: Dictionary={}
	for key in STAT_NAMES:
		if str(key).ends_with("_multiplier"):
			var previous := float(old_stats.get(key,1.0))
			differences[key]=float(new_stats.get(key,1.0))/maxf(0.01,previous)
		else:
			differences[key]=float(new_stats.get(key,0.0))-float(old_stats.get(key,0.0))
	var delta := _stats_text(differences)
	return "Same bonuses as equipped." if delta.is_empty() else GameLocale.text("vs equipped: ")+delta

func _rarity_color(rarity: String) -> Color:
	return {"common":Color("5d785b"),"rare":Color("547c99"),"epic":Color("8a659d"),"provisions":Color("977438")}.get(rarity,GOLD)

func _label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text=text
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	return label

func _style(fill: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left=margin
	style.content_margin_right=margin
	style.content_margin_top=margin
	style.content_margin_bottom=margin
	return style

func _card(fill: Color, border: Color, margin: int) -> PanelContainer:
	var card := PanelContainer.new()
	card.add_theme_stylebox_override("panel",_style(fill,border,14,margin))
	return card

func _button(text: String, quiet: bool) -> Button:
	var button := Button.new()
	button.text=text
	button.add_theme_font_size_override("font_size",14)
	for color_state in ["font_color","font_hover_color","font_pressed_color","font_focus_color"]:
		button.add_theme_color_override(color_state,INK)
	button.add_theme_color_override("font_disabled_color",Color("9b9081"))
	button.add_theme_color_override("font_hover_color",INK)
	button.add_theme_color_override("font_pressed_color",INK)
	button.add_theme_stylebox_override("normal",_style(Color("eee5f3") if quiet else Color("d9e9cd"),Color("bea9cc") if quiet else Color("91aa7d"),11,8))
	button.add_theme_stylebox_override("hover",_style(Color("f6eef9") if quiet else Color("e6f1da"),Color("a88bb8") if quiet else Color("799b68"),11,8))
	button.add_theme_stylebox_override("pressed",_style(Color("c9dcb9"),Color("799b68"),11,8))
	button.add_theme_stylebox_override("disabled",_style(Color("e9e4db"),Color("c7bba9"),11,8))
	button.add_theme_stylebox_override("focus",_style(Color(0,0,0,0),Color("a88bb8"),11,0))
	return button
