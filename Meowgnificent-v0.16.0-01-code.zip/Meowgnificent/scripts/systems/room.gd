extends Node2D

const PLAYER_SCENE = preload("res://scenes/player/player.tscn")
const FLOOR_FIRE_ART: Texture2D = preload("res://art/items/floor_fire.svg")
var balance: Dictionary
var bounds: Rect2
var player: WizardCat
var spells: SpellController
var skills
var hud: WizardHUD
var settings: SettingsPanel
var story_director: StoryDirector
var actors: Node2D
var projectiles: Node2D
var enemies: Array[CandleSlime] = []
var camera: Camera2D
var state := "intro"
var effects: Array[Dictionary] = []
var props: Array[ArcaneShelf] = []
var fires: Array[Dictionary] = []
var time := 0.0
var shake := 0.0
var run: ExpeditionRun
var profile: MetaProgress
var stages: Array = []
var stage_def: Dictionary = {}
var exit_open := false
var loot: Array[LootPickup] = []
var loot_root: Node2D
var markers: ExpeditionMarkers
var panel: ExpeditionPanel
var shop_offers: Array[Dictionary] = []
var background: Sprite2D
var background_viewport: SubViewport
var backdrop_painter: ArchiveBackdrop
var sector_gear_dropped := false
var drop_rng := RandomNumberGenerator.new()
var panel_return_state := "playing"
var inventory_from_shop := false
var pickup_radius := LootPickup.MAGNET_RADIUS
var _had_room_fx := false
var departure_gear_signature := ""
var departure_warning_until_msec := 0
var encounters: EncounterDirector

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	balance = JSON.parse_string(FileAccess.get_file_as_string("res://data/balance.json"))
	stages=JSON.parse_string(FileAccess.get_file_as_string("res://data/expedition.json")).stages
	run=ExpeditionRun.new()
	var profile_path := OS.get_environment("MEOW_PROFILE_PATH")
	profile=MetaProgress.new(profile_path) if not profile_path.is_empty() else MetaProgress.new()
	stage_def=stages[0]
	drop_rng.randomize()
	var r: Dictionary = balance.room
	bounds = Rect2(float(r.left),float(r.top),float(r.width),float(r.height))
	configure_inputs()
	# Render the unchanging room once, then reuse a single cached texture.
	background_viewport = SubViewport.new()
	background_viewport.size=Vector2i(1280,800)
	background_viewport.size_2d_override=Vector2i(1280,800)
	background_viewport.size_2d_override_stretch=true
	background_viewport.transparent_bg=true
	background_viewport.disable_3d=true
	background_viewport.render_target_update_mode=SubViewport.UPDATE_ONCE
	backdrop_painter=ArchiveBackdrop.new()
	backdrop_painter.include_frame=false
	backdrop_painter.gameplay_landmarks=true
	background_viewport.add_child(backdrop_painter)
	add_child(background_viewport)
	background = Sprite2D.new()
	background.texture=background_viewport.get_texture()
	background.centered=false
	# Floor fire and impact rings drawn by the room must remain above the backdrop.
	background.z_index=-10
	add_child(background)
	_update_background_resolution()
	get_tree().root.size_changed.connect(_update_background_resolution)
	actors = Node2D.new()
	actors.y_sort_enabled = true
	add_child(actors)
	projectiles = Node2D.new()
	add_child(projectiles)
	camera = Camera2D.new()
	camera.physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	camera.position = Vector2(640,400)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8
	add_child(camera)
	# Prepare the three effect shaders behind the start-screen backdrop.
	add_child(ShaderWarmup.new())
	player = PLAYER_SCENE.instantiate()
	player.position = Vector2(345,515)
	player.presentation_scale = 1.85
	player.setup(balance.player.duplicate(true),bounds)
	player.active = false
	actors.add_child(player)
	player.reset_physics_interpolation()
	player.health.died.connect(on_player_died)
	player.hurt.connect(func():
		shake=5.0
		_play_sound("hurt")
	)
	player.wall_bumped.connect(on_wall_bumped)
	spells = SpellController.new()
	spells.config = balance.fireball.duplicate(true)
	spells.player = player
	spells.room = self
	spells.spell_emitted.connect(on_spell_emitted)
	add_child(spells)
	skills=load("res://scripts/spells/item_skill_controller.gd").new()
	skills.room=self
	skills.player=player
	skills.skill_emitted.connect(on_skill_emitted)
	add_child(skills)
	encounters=EncounterDirector.new()
	add_child(encounters)
	encounters.encounter_requested.connect(_start_encounter)
	encounters.configure(stage_def,0,bounds)
	spawn_enemies()
	spawn_shelves()
	loot_root=Node2D.new()
	loot_root.z_index=2
	add_child(loot_root)
	markers=ExpeditionMarkers.new()
	markers.room=self
	add_child(markers)
	panel=ExpeditionPanel.new()
	panel.room=self
	add_child(panel)
	apply_equipment()
	hud = WizardHUD.new()
	hud.room = self
	hud.begin_requested.connect(request_begin)
	add_child(hud)
	story_director=StoryDirector.new()
	story_director.room=self
	add_child(story_director)
	settings=SettingsPanel.new()
	settings.room=self
	add_child(settings)

func story_enabled() -> bool:
	if OS.get_environment("MEOW_SKIP_STORY")=="1": return false
	if OS.has_feature("web") and Engine.has_singleton("JavaScriptBridge"):
		var bridge: Object=Engine.get_singleton("JavaScriptBridge")
		if bool(bridge.call("eval","new URLSearchParams(window.location.search).get('skip_story') === '1'")): return false
	return true

func request_begin() -> void:
	if story_director.is_open: return
	if state=="intro" and story_enabled() and not get_tree().root.has_meta("meow_opening_seen"):
		get_tree().root.set_meta("meow_opening_seen",true)
		state="story"
		hud.overlay.hide()
		story_director.play_opening(func():
			state="intro"
			begin_or_restart()
		)
	else: begin_or_restart()

func announce_story_chapter(index: int) -> void:
	if not story_enabled(): return
	set_running(false)
	state="story"
	hud.overlay.hide()
	story_director.show_chapter(index,func():
		spells.input_blocked_until_release=true
		set_running(true)
	)

func finish_story_ending() -> void:
	state="cleared"
	player.active=false
	hud.overlay.show()

func configure_inputs() -> void:
	var keys := {"move_left":[KEY_A,KEY_LEFT],"move_right":[KEY_D,KEY_RIGHT],"move_up":[KEY_W,KEY_UP],"move_down":[KEY_S,KEY_DOWN],"cast":[KEY_SPACE],"roll":[KEY_SHIFT],"special_skill":[KEY_Q]}
	for action: String in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key: int in keys[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action,event)
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("cast",mouse)
	var special_mouse := InputEventMouseButton.new()
	special_mouse.button_index=MOUSE_BUTTON_RIGHT
	InputMap.action_add_event("special_skill",special_mouse)

func spawn_enemies(definition: Dictionary={}) -> void:
	if definition.is_empty(): definition=encounters.current_definition()
	if definition.is_empty(): return
	var roles: Array=definition.roles
	var locations: Array=definition.positions
	var is_boss_group := bool(definition.get("boss_encounter",false))
	for i in range(roles.size()):
		var enemy: CandleSlime
		if is_boss_group and i==int(definition.get("elite",-1)): enemy=PerfectExaminer.new()
		elif str(roles[i]) in ["book","mushroom"]: enemy=LivingStageEnemy.new()
		else: enemy=CandleSlime.new()
		enemy.position = WorldLayout.point(Vector2(float(locations[i][0]),float(locations[i][1])))
		enemy.role = str(roles[i])
		var settings: Dictionary=balance.enemy.duplicate(true)
		settings.hp=int(definition.get("hp",40))
		settings.speed=float(definition.get("speed",83))
		settings.contact_damage=int(definition.get("damage",12))
		var families: Array=definition.get("element_families",[])
		if i<families.size() and not str(families[i]).is_empty(): settings.element_family=str(families[i])
		var elite := i==int(definition.get("elite",-1))
		if elite:
			settings.hp=int(settings.hp)*(3 if is_boss_group else 2)
			settings.contact_damage=int(settings.contact_damage)+3
			settings.radius=23.0*WorldLayout.ACTOR_SCALE
			enemy.scale=Vector2(1.25,1.25)
			enemy.modulate=Color.WHITE
			enemy.set_meta("elite",true)
		enemy.setup(settings,player,bounds)
		enemy.active = false
		enemy.defeated.connect(on_enemy_defeated)
		enemy.health.changed.connect(func(current: int, maximum: int):
			if current<maximum: _play_sound("hit")
		)
		if enemy is PerfectExaminer: enemy.barrier_broken.connect(on_examiner_barrier_broken)
		enemies.append(enemy)
		actors.add_child(enemy)
		enemy.scale*=WorldLayout.ACTOR_SCALE
		enemy.reset_physics_interpolation()

func _start_encounter(definition: Dictionary) -> void:
	if state!="playing": return
	spawn_enemies(definition)
	for enemy in enemies: enemy.active=true
	tell(GameLocale.text("Encounter %d / %d — %s") % [encounters.index+1,encounters.definitions.size(),GameLocale.text(str(definition.name))],Color("ead6b3"))

func navigation_target() -> Vector2:
	if exit_open: return WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)
	if encounters.state in ["waiting","windup"]: return encounters.waypoint()
	var target := player.position
	var nearest := INF
	for enemy in enemies:
		if not is_instance_valid(enemy): continue
		var distance := player.position.distance_squared_to(enemy.position)
		if distance<nearest:
			nearest=distance
			target=enemy.position
	return target

func spawn_shelves() -> void:
	for i in range(stage_def.shelves.size()):
		var point: Array=stage_def.shelves[i]
		var shelf := ArcaneShelf.new()
		shelf.room=self
		shelf.reveal_cache=i==int(stage_def.get("cache_shelf",-1))
		shelf.position=WorldLayout.point(Vector2(float(point[0]),float(point[1])))
		props.append(shelf)
		actors.add_child(shelf)

func begin_or_restart() -> void:
	if state == "intro":
		skills.reset()
		var attempt_id: int=profile.begin_run()
		var legacy: Dictionary=profile.bonuses()
		run.add_gold(int(legacy.starting_gold))
		var starter: String=str(legacy.starter_item)
		if starter.is_empty(): starter="practice_wand"
		if not run.inventory.has(starter): run.add_item(starter)
		run.equip_item(starter)
		apply_equipment()
		player.health.current=player.health.maximum
		player.position = WorldLayout.point(WorldLayout.FIRST_ENTRY)
		player.reset_physics_interpolation()
		player.presentation_scale = WorldLayout.ACTOR_SCALE
		camera.position=WorldLayout.camera_center(player.position)
		camera.reset_smoothing()
		spells.input_blocked_until_release=true
		set_running(true)
		if attempt_id==0 and not profile.save_error.is_empty(): tell(GameLocale.text("Progress could not be saved: ")+GameLocale.text(profile.save_error),Color("ffac8f"))
	elif state == "paused":
		set_running(true)
	else:
		get_tree().reload_current_scene()

func set_running(running: bool) -> void:
	if not running: departure_gear_signature=""
	state = "playing" if running else "paused"
	player.active = running
	for enemy in enemies:
		enemy.active = running
	projectiles.process_mode = Node.PROCESS_MODE_INHERIT if running else Node.PROCESS_MODE_DISABLED
	if running:
		skills.input_blocked_until_release=true
		hud.overlay.hide()
	else:
		hud.show_overlay("Taking a catnap", "The archives can wait.\nYour current study is paused.", "Resume study   /   ENTER")

func _unhandled_key_input(event: InputEvent) -> void:
	if is_instance_valid(settings) and settings.blocks_gameplay_input(): return
	if is_instance_valid(story_director) and story_director.is_open: return
	if not event.is_pressed() or event.is_echo():
		return
	if event is InputEventKey:
		match event.keycode:
			KEY_ENTER:
				if panel.is_open: return
				if state=="playing" and exit_open: advance_sector()
				elif state != "playing": request_begin()
			KEY_R:
				if state in ["playing","paused","inventory","shop"]: profile.finish_run(false)
				get_tree().reload_current_scene()
			KEY_ESCAPE:
				if panel.is_open: close_panel()
				elif state == "playing": set_running(false)
				elif state == "paused": set_running(true)
			KEY_I:
				if panel.is_open and panel.mode=="inventory": close_panel()
				elif state in ["playing","shop"]: open_inventory()
			KEY_M:
				if panel.is_open and panel.mode=="meta": close_panel()
				elif state in ["intro","defeated","cleared"]: open_legacy()
			KEY_E:
				if not panel.is_open: interact()
			KEY_T:
				if state=="playing" and str(stage_def.kind)=="shop" and markers.gathering.is_pip_near(player.position):
					markers.gathering.interact("pip")
			KEY_1,KEY_2,KEY_3,KEY_4:
				if panel.is_open:
					var index := int(event.keycode)-KEY_1
					if panel.mode=="shop": panel.buy_offer(index)
					elif panel.mode=="meta": panel.buy_upgrade_at(index)
			KEY_F1: spells.resolver.forced = "success"
			KEY_F2: spells.resolver.forced = "miscast"
			KEY_F3: spells.resolver.forced = "overreaction"

func on_spell_emitted(result: String, point: Vector2) -> void:
	_play_sound("cast_"+spells.last_element)
	if result=="miscast": _play_sound("miscast")
	hud.show_outcome(result)
	if result == "miscast":
		var burst := MiscastBurst.new()
		burst.room = self
		burst.position = point
		add_child(burst)
	else:
		effects.append({"point":point,"age":0.0,"radius":35.0,"color":Color("f6be70")})
	if result == "overreaction": shake = 7.0

func on_skill_emitted(result: String, _point: Vector2) -> void:
	_play_sound("skill")
	# A special has its own gesture and effect. The basic-magic failure puff
	# must not obscure it or make a successful Q look like a failed fireball.
	hud.show_outcome(result)
	hud.show_skill_cast(skills.skill_definition(skills.last_skill_id),result)
	if result=="overreaction": shake=maxf(shake,5.0)

func apply_miscast_blast(point: Vector2, damage: int, radius: float, direction: Vector2) -> void:
	apply_blast(point,damage,radius,direction,Color("b7a6c5"),"miscast")


func apply_blast(point: Vector2, damage: int, radius: float, direction: Vector2, tint: Color = Color("ffcb86"), spell_outcome: String = "overreaction", element: String = "fire") -> void:
	effects.append({"point":point,"age":0.0,"radius":maxf(24,radius),"color":tint})
	if radius <= 0:
		return
	shake = 6.0
	for shelf in props:
		if shelf.position.distance_to(point)<=radius+30:
			shelf.receive_magic(element,(shelf.position-point).normalized(),spell_outcome)
	# Iterate a copy because defeated signals remove enemies immediately.
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and enemy.position.distance_to(point) <= radius + float(enemy.config.radius):
			var push: Vector2 = (enemy.position-point).normalized() if direction==Vector2.ZERO else direction
			if enemy.has_method("take_elemental_damage"): enemy.call("take_elemental_damage",damage,push,spell_outcome,element)
			elif enemy.has_method("take_spell_damage"): enemy.call("take_spell_damage",damage,push,spell_outcome)
			else: enemy.take_damage(damage,push)

func _play_sound(cue: String) -> void:
	var sound := get_node_or_null("/root/Sound")
	if sound!=null: sound.play_cue(cue)

func tell(message: String, color: Color = Color("eacb9e")) -> void:
	if is_instance_valid(hud): hud.show_incident(message,color)

func on_wall_bumped(point: Vector2) -> void:
	shake=6
	tell("Wall: 1. Wizard: 0.",Color("ffb5a0"))
	effects.append({"point":point,"age":0.0,"radius":45.0,"color":Color("d7c4aa")})
	for shelf in props:
		if shelf.position.distance_to(point)<110: shelf.topple(player.roll_direction)

func ignite_floor(point: Vector2) -> void:
	for fire in fires:
		if fire.point.distance_to(point)<45: return
	fires.append({"point":point,"age":0.0,"tick":0.0})

func _physics_process(delta: float) -> void:
	if state!="playing": return
	encounters.tick(delta,player.position,true)
	update_loot(delta)
	for shelf in props:
		if shelf.state=="standing" or shelf.state=="burning":
			var offset := player.position-shelf.position
			if offset.length()<55:
				if player.roll_time>0: shelf.topple(player.roll_direction)
				else: player.position=shelf.position+(offset.normalized() if offset.length()>0.01 else Vector2.DOWN)*55
			for enemy in enemies.duplicate():
				var gap: Vector2 = enemy.position-shelf.position
				if gap.length()<48:
					if enemy.phase=="attack" and enemy.role=="broom": shelf.topple(enemy.attack_direction)
					else: enemy.position=shelf.position+(gap.normalized() if gap.length()>0.01 else Vector2.DOWN)*48
	if player.roll_time>0:
		for enemy in enemies.duplicate():
			if player.position.distance_to(enemy.position)<float(player.config.radius)+float(enemy.config.radius)+3.0 and not player.roll_hits.has(enemy.get_instance_id()):
				player.roll_hits.append(enemy.get_instance_id())
				enemy.take_damage(int(player.config.get("roll_damage",30)),player.roll_direction)
				tell("An advanced belly-based technique.",Color("e1d4a5"))
	for fire in fires:
		fire.age+=delta
		fire.tick-=delta
		if fire.tick<=0 and not exit_open:
			fire.tick=0.7
			if player.position.distance_to(fire.point)<43: player.take_damage(6,fire.point-Vector2(1,0))
			for enemy in enemies.duplicate():
				if enemy.position.distance_to(fire.point)<48: enemy.take_elemental_damage(10,Vector2.UP,"miscast","fire")
	fires=fires.filter(func(f: Dictionary) -> bool: return f.age<4.2)


func on_enemy_defeated(enemy: CandleSlime) -> void:
	effects.append({"point":enemy.position,"age":0.0,"radius":40.0,"color":Color("9dd6bb")})
	if state=="playing":
		run.enemies_defeated+=1
		spawn_enemy_loot(enemy)
	enemies.erase(enemy)
	if enemies.is_empty() and state == "playing":
		if encounters.finish_current(): complete_sector()
		else:
			_clear_combat_hazards()
			tell("Follow the glowing seal to the next encounter.",Color("d6e7be"))

func on_player_died() -> void:
	skills.clear_transients()
	skills.clear_presentation()
	hud.clear_skill_cast()
	profile.finish_run(false)
	state = "defeated"
	player.active = false
	for enemy in enemies:
		enemy.active = false
	projectiles.process_mode = Node.PROCESS_MODE_DISABLED
	hud.show_overlay("A brief interruption.",GameLocale.text("Reached area %d / 8. Crowns and gear belong to this expedition.\nYour %d Starlight and legacy studies are safe.\nM: legacy upgrades before the next attempt.") % [run.stage_index+1,profile.starlight],"New expedition   /   ENTER")

func _process(delta: float) -> void:
	if state != "playing":
		return
	markers.update_visuals()
	time += delta
	shake = move_toward(shake,0,delta*25)
	# Camera2D eases this target at render time. Keep the camera out of physics
	# interpolation so its existing smoothing never applies a second delay.
	camera.position = WorldLayout.camera_center(player.global_position)
	camera.offset = Vector2(sin(time*79),cos(time*91))*shake
	if not effects.is_empty():
		for effect in effects:
			effect.age += delta
		effects = effects.filter(func(e: Dictionary) -> bool: return float(e.age)<0.5)
	var has_fx := not effects.is_empty() or not fires.is_empty()
	if has_fx or _had_room_fx:
		queue_redraw()
	_had_room_fx=has_fx

func _clear_combat_hazards() -> void:
	# A landed signature may finish its brief visual flourish; future damage
	# and unlanded attacks stop immediately when the encounter ends.
	skills.clear_transients(true)
	for shot in projectiles.get_children():
		if shot.has_method("is_cosmetic_tail") and shot.is_cosmetic_tail(): continue
		shot.queue_free()
	spells.pending=false
	spells.pending_magic.clear()
	spells.pending_config.clear()
	player.cast_prepare=0
	fires.clear()
	queue_redraw()

func complete_sector() -> void:
	if exit_open: return
	_play_sound("clear")
	exit_open=true
	_clear_combat_hazards()
	var awarded: int=profile.award_sector(run.stage_index,int(stage_def.get("reward",0)))
	if str(stage_def.kind)=="final":
		collect_remaining_loot()
		profile.finish_run(true)
		state="cleared"
		player.active=false
		projectiles.process_mode=Node.PROCESS_MODE_DISABLED
		hud.show_overlay("Accidentally magnificent.",GameLocale.text("All 8 areas cleared. %d foes, %d Crowns collected.\n%d Starlight remains for permanent legacy upgrades.\nM: legacy studies. ENTER: a fresh expedition.") % [run.enemies_defeated,run.collected_gold,profile.starlight],"Begin another expedition   /   ENTER")
		if story_enabled():
			state="story"
			hud.overlay.hide()
			story_director.play_ending(finish_story_ending)
	else:
		if not profile.save_error.is_empty():
			tell(GameLocale.text("Passage open. Progress could not be saved: ")+GameLocale.text(profile.save_error),Color("ffac8f"))
		else:
			tell(GameLocale.text("Passage open! +%d Starlight saved. Collect loot; ENTER continues.") % awarded,Color("d7c597"))
	markers.update_visuals()

func advance_sector() -> bool:
	if state!="playing" or not exit_open or run.stage_index>=stages.size()-1: return false
	collect_remaining_loot()
	# A rejected full-bag drop must not disappear without a deliberate choice.
	# Tapping the exit again confirms only this exact remaining set of gear.
	var remaining: Array[int] = []
	for pickup in loot:
		if is_instance_valid(pickup) and pickup.kind=="gear": remaining.append(pickup.get_instance_id())
	remaining.sort()
	var signature := str(run.stage_index)+":"+str(remaining)
	if not remaining.is_empty() and (departure_gear_signature!=signature or Time.get_ticks_msec()>departure_warning_until_msec):
		departure_gear_signature=signature
		departure_warning_until_msec=Time.get_ticks_msec()+5000
		tell("Gear is still here. I: make room · ENTER / E: leave it and continue.",Color("ffd6a3"))
		hud.incident_time=5.0
		return false
	load_sector(run.stage_index+1)
	return true

func load_sector(index: int) -> void:
	departure_gear_signature=""
	skills.clear_transients()
	skills.clear_presentation()
	hud.clear_skill_cast()
	state="transition"
	player.active=false
	for enemy in enemies: enemy.active=false
	var old_actors := actors
	actors=Node2D.new()
	actors.y_sort_enabled=true
	add_child(actors)
	player.reparent(actors)
	old_actors.queue_free()
	projectiles.process_mode=Node.PROCESS_MODE_DISABLED
	projectiles.queue_free()
	projectiles=Node2D.new()
	add_child(projectiles)
	for pickup in loot:
		if is_instance_valid(pickup): pickup.queue_free()
	loot.clear()
	enemies.clear()
	props.clear()
	fires.clear()
	effects.clear()
	_had_room_fx=false
	queue_redraw()
	for child in get_children():
		if child is MiscastBurst: child.queue_free()
	run.stage_index=index
	stage_def=stages[index]
	exit_open=str(stage_def.kind)=="shop"
	sector_gear_dropped=false
	shop_offers.clear()
	if exit_open: shop_offers=run.shop_offers(int(stage_def.tier))
	refresh_backdrop(index)
	encounters.configure(stage_def,index,bounds)
	spawn_enemies()
	spawn_shelves()
	player.position=WorldLayout.point(WorldLayout.ENTRY)
	player.presentation_scale=WorldLayout.ACTOR_SCALE
	player.reset_physics_interpolation()
	player.velocity=Vector2.ZERO
	player.recoil=Vector2.ZERO
	player.roll_time=0
	player.hit_reaction=0
	player.invulnerability=0.8
	spells.pending=false
	spells.pending_magic.clear()
	spells.pending_config.clear()
	spells.prepare_time=0
	player.cast_prepare=0
	spells.cooldown=0
	spells.input_blocked_until_release=true
	hud.outcome_time=0
	shake=0
	camera.offset=Vector2.ZERO
	camera.position=WorldLayout.camera_center(player.position)
	camera.reset_smoothing()
	set_running(true)
	markers.update_visuals()
	tell("A safe stop. Walk to Pip and press E to browse." if exit_open else GameLocale.text("Area %d / 8 — %s") % [index+1,GameLocale.text(str(stage_def.name))],Color("ead6b3"))
	announce_story_chapter(index)

func _update_background_resolution() -> void:
	# Canonical art is painted once at the useful density of the larger world.
	var pixels := WorldLayout.cache_pixels(get_tree().root.size)
	background.scale=WorldLayout.cache_scale(pixels)
	if background_viewport.size==pixels: return
	background_viewport.size=pixels
	background_viewport.render_target_update_mode=SubViewport.UPDATE_ONCE

func refresh_backdrop(index: int) -> void:
	# Rebuild only on a sector change. Gameplay frames sample one cached quad.
	backdrop_painter.configure(index)
	background.modulate=Color.WHITE
	background_viewport.render_target_update_mode=SubViewport.UPDATE_ONCE

func interact() -> void:
	if state!="playing": return
	for shelf in props:
		if shelf.is_cache_near(player.position):
			shelf.scavenge_cache()
			return
	if str(stage_def.kind)=="shop":
		var friend_id := markers.gathering.nearest_interaction(player.position)
		if not friend_id.is_empty():
			markers.gathering.interact(friend_id)
			return
	if str(stage_def.kind)=="shop" and markers.is_shop_near(player.position):
		open_shop()
	elif exit_open and WorldLayout.canonical(player.position).distance_to(ExpeditionMarkers.EXIT_POSITION)<86:
		advance_sector()
	elif not exit_open:
		tell("The passage opens when every foe is defeated.")

func open_inventory() -> void:
	departure_gear_signature=""
	var from_shop := state=="shop" and panel.is_open and panel.mode=="shop"
	if state!="playing" and not from_shop: return
	inventory_from_shop=from_shop
	if not from_shop: panel_return_state=state
	set_running(false)
	state="inventory"
	hud.overlay.hide()
	panel.open_inventory()

func open_shop() -> void:
	if state!="playing" or str(stage_def.kind)!="shop": return
	inventory_from_shop=false
	panel_return_state=state
	set_running(false)
	state="shop"
	hud.overlay.hide()
	panel.open_shop()

func open_legacy() -> void:
	if state not in ["intro","defeated","cleared"]: return
	panel_return_state=state
	state="legacy"
	panel.open_meta()

func close_panel() -> void:
	if not panel.is_open: return
	if inventory_from_shop and panel.mode=="inventory":
		inventory_from_shop=false
		state="shop"
		panel.open_shop()
		return
	panel.close()
	spells.input_blocked_until_release=true
	skills.input_blocked_until_release=true
	if panel_return_state=="playing": set_running(true)
	else: state=panel_return_state

func equip_gear(id: String) -> bool:
	if not run.equip_item(id): return false
	_play_sound("equip")
	apply_equipment()
	return true

func unequip_gear(slot: String) -> bool:
	if not run.unequip_slot(slot): return false
	apply_equipment()
	return true

func apply_equipment() -> void:
	if is_instance_valid(player):
		for child in player.get_children():
			if child is WizardCatVisual and is_instance_valid(child.equipment_visual):
				child.equipment_visual.set_equipment(run.equipment)
	var stats := CharacterStats.for_room(self)
	player.config=balance.player.duplicate(true)
	player.config.speed=stats.speed
	player.config.roll_cooldown=stats.roll_cooldown
	player.config.roll_damage=stats.roll_damage
	player.health.maximum=stats.max_hp
	# Swapping maximum vitality equipment cannot create free healing.
	player.health.current=mini(player.health.current,player.health.maximum)
	player.health.changed.emit(player.health.current,player.health.maximum)
	spells.config=balance.fireball.duplicate(true)
	spells.config.success_damage=stats.spell_damage
	spells.config.miscast_damage=stats.spell_miscast_damage
	spells.config.overreaction_damage=stats.spell_overreaction_damage
	spells.config.cooldown=stats.spell_cooldown
	pickup_radius=stats.pickup_radius

func on_examiner_barrier_broken(point: Vector2, _reason: String) -> void:
	if state!="playing" or not is_instance_valid(hud): return
	shake=maxf(shake,12.0)
	effects.append({"point":point,"age":0.0,"radius":115.0,"color":Color("ffe3aa")})
	hud.arrival_pending=false
	hud.sector_banner.elapsed=hud.sector_banner.duration
	hud.sector_banner.hide()
	hud.show_boss_break()

func purchase_offer(index: int) -> Dictionary:
	if state!="shop" or index<0 or index>=shop_offers.size(): return {"ok":false,"reason":"Browse the shop to buy."}
	var offer: Dictionary=shop_offers[index]
	if str(offer.kind)=="heal" and player.health.current>=player.health.maximum:
		return {"ok":false,"reason":"Already at full vitality."}
	var result: Dictionary=run.purchase(offer)
	if bool(result.ok) and int(result.get("heal",0))>0: heal_player(int(result.heal))
	return result

func purchase_upgrade(id: String) -> Dictionary:
	if state!="legacy": return {"ok":false,"reason":"Legacy studies are available between expeditions."}
	return profile.purchase_upgrade(id)

func heal_player(amount: int) -> void:
	player.health.current=mini(player.health.maximum,player.health.current+maxi(0,amount))
	player.health.changed.emit(player.health.current,player.health.maximum)

func spawn_enemy_loot(enemy: CandleSlime) -> void:
	var point := enemy.position
	spawn_pickup("gold",point+Vector2(-16,6),4+run.stage_index+(8 if enemy.has_meta("elite") else 0))
	var guaranteed := run.enemies_defeated==1 or enemies.size()==1 and not sector_gear_dropped or enemy.has_meta("elite")
	if guaranteed or drop_rng.randf()<0.18:
		var tier := int(stage_def.tier)
		var pool: Array[String]=run.droppable_items(tier)
		var current_tier: Array[String]=[]
		for id in pool:
			if int(run.item_info(id).tier)==tier: current_tier.append(id)
		var item_id: String=current_tier[drop_rng.randi_range(0,current_tier.size()-1)]
		if run.enemies_defeated==1:
			item_id="brass_bell_collar" if run.inventory.has("crooked_ash_wand") else "crooked_ash_wand"
		spawn_pickup("gear",point+Vector2(18,0),0,item_id)
		sector_gear_dropped=true
	if run.enemies_defeated%5==0 or drop_rng.randf()<0.12:
		spawn_pickup("food",point+Vector2(0,27),20)

func spawn_pickup(kind: String, point: Vector2, amount: int=0, item_id: String="") -> LootPickup:
	var pickup := LootPickup.new()
	pickup.kind=kind
	pickup.amount=amount
	pickup.item_id=item_id
	pickup.position=point.clamp(bounds.position+Vector2(22,25),bounds.end-Vector2(22,25))
	if kind=="gear":
		var info: Dictionary=run.item_info(item_id)
		pickup.rarity=str(info.get("rarity","common"))
		pickup.slot=str(info.get("slot","wand"))
	loot.append(pickup)
	loot_root.add_child(pickup)
	return pickup

func collect_pickup(pickup: LootPickup) -> bool:
	if state!="playing" or not is_instance_valid(pickup) or not loot.has(pickup): return false
	var credited := pickup.amount
	match pickup.kind:
		"gold": run.add_gold(pickup.amount)
		"gear":
			if not run.add_item(pickup.item_id):
				if not pickup.has_meta("bag_warning"):
					pickup.set_meta("bag_warning",true)
					tell("Bag full. Gear left on the floor.",Color("ffb28e"))
				return false
			tell(GameLocale.text("Found %s. I: compare and equip.") % GameLocale.text(str(run.item_info(pickup.item_id).name)),Color("d1c4ed"))
		"food":
			if player.health.current>=player.health.maximum: return false
			credited=mini(pickup.amount,player.health.maximum-player.health.current)
			heal_player(pickup.amount)
		_: return false
	_play_sound("gear" if pickup.kind=="gear" else "pickup")
	_pickup_feedback(pickup,credited)
	loot.erase(pickup)
	pickup.queue_free()
	return true

func _pickup_feedback(pickup: LootPickup, credited: int) -> void:
	# The world already owns a short, paused-with-play effect list. Reuse it
	# rather than spawning labels/emitters for every coin in a large loot pile.
	var count := 0
	for effect in effects:
		if not effect.has("pickup_kind"): continue
		count+=1
		if str(effect.pickup_kind)==pickup.kind and float(effect.age)<0.3 and Vector2(effect.point).distance_squared_to(player.position)<6400:
			effect.pickup_amount=int(effect.pickup_amount)+credited
			return
	if count>=4: return
	var icon: Texture2D=LootPickup.GOLD_ART if pickup.kind=="gold" else LootPickup.FOOD_ART if pickup.kind=="food" else EquipmentArt.icon(pickup.item_id)
	if icon==null: return
	effects.append({"point":player.position,"age":0.0,"pickup_kind":pickup.kind,"pickup_amount":credited,"texture":icon,"radius":0.0,"color":Color("edf5dc") if pickup.kind=="food" else Color("fff0cf")})

func collect_remaining_loot() -> void:
	for pickup in loot.duplicate(): collect_pickup(pickup)

func update_loot(delta: float) -> void:
	for pickup in loot.duplicate():
		if not is_instance_valid(pickup): continue
		pickup.age+=delta
		var distance: float = pickup.position.distance_to(player.position)
		var eligible: bool=pickup.kind=="gold" or pickup.kind=="gear" and run.inventory.size()<ExpeditionRun.INVENTORY_LIMIT or pickup.kind=="food" and player.health.current<player.health.maximum
		if eligible and distance<=pickup_radius:
			pickup.position=pickup.position.move_toward(player.position,delta*LootPickup.MAGNET_SPEED)
		if pickup.position.distance_to(player.position)<=LootPickup.COLLECT_RADIUS:
			collect_pickup(pickup)
		if is_instance_valid(pickup) and not pickup.is_queued_for_deletion(): pickup.queue_redraw()

func _draw() -> void:
	for fire in fires:
		var p: Vector2=fire.point
		var fade := minf(1,(4.2-float(fire.age))*2)
		# One shared flame image replaces sixteen per-frame shapes per fire.
		var pulse := Vector2(1+sin(time*8+p.x)*0.025,1+cos(time*11+p.y)*0.025)
		draw_set_transform(p,0,pulse)
		draw_texture_rect(FLOOR_FIRE_ART,Rect2(-60,-90,120,135),false,Color(1,1,1,fade))
	draw_set_transform(Vector2.ZERO)
	for effect in effects:
		var t := clampf(float(effect.age)/0.5,0,1)
		if effect.has("pickup_kind"):
			var fade := 1.0-smoothstep(0.45,1.0,t)
			var side := -26.0 if str(effect.pickup_kind)=="food" else 27.0 if str(effect.pickup_kind)=="gold" else 0.0
			var at: Vector2=effect.point+Vector2(side,-75-22*t)
			draw_set_transform(at)
			draw_texture_rect(effect.texture,Rect2(-10,-12,20,20),false,Color(1,1,1,fade))
			if int(effect.pickup_amount)>0:
				var label := "+%d" % int(effect.pickup_amount)
				draw_string_outline(ThemeDB.fallback_font,Vector2(11,4),label,HORIZONTAL_ALIGNMENT_LEFT,-1,13,3,Color(0.32,0.25,0.34,fade*0.85))
				var ink: Color=effect.color
				ink.a=fade
				draw_string(ThemeDB.fallback_font,Vector2(11,4),label,HORIZONTAL_ALIGNMENT_LEFT,-1,13,ink)
			continue
		var c: Color=effect.color
		c.a=(1-t)*0.9
		var reach := float(effect.radius)*(0.45+t*0.8)
		draw_set_transform(effect.point+Vector2(0,-18),t*0.4)
		draw_texture_rect(SpellArt.part("impact"),Rect2(-reach,-reach,reach*2,reach*2),false,c)
	draw_set_transform(Vector2.ZERO)
