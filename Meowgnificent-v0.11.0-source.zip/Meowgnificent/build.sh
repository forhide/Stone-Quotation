#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
"$PROJECT_DIR/setup-exports.sh"
"$PROJECT_DIR/test.sh"
mkdir -p "$PROJECT_DIR/exports/"{windows,linux,web,macos}
for TARGET in Windows Linux Web macOS; do
  "$PROJECT_DIR/run.sh" --headless --export-release "$TARGET"
done
