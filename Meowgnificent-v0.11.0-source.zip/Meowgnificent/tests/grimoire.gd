extends SceneTree

# Combat rules are exercised directly with a stationary real WizardCat target.
# Automatic physics is disabled so warning/window durations are deterministic.
class TrainingCat extends WizardCat:
	func _ready() -> void:
		pass

var checks := 0
var failures := 0
var boss: PerfectExaminer
var cat: WizardCat
var arena := Rect2(100,160,1080,535)
var settings := {"hp":180,"speed":60.0,"contact_damage":14,"radius":24.0}

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func fresh() -> void:
	if is_instance_valid(boss): boss.free()
	boss=PerfectExaminer.new()
	boss.position=Vector2(700,400)
	boss.setup(settings.duplicate(),cat,arena)
	root.add_child(boss)
	boss.set_physics_process(false)
	cat.position=Vector2(550,400)
	cat.active=true
	cat.invulnerability=0
	cat.health.current=100

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	cat=TrainingCat.new()
	cat.setup({"hp":100,"radius":23.0,"invulnerability":0.65},arena)
	root.add_child(cat)
	cat.set_physics_process(false)
	fresh()
	check(boss is CandleSlime and boss.role=="examiner" and str(boss.get_meta("archetype"))=="perfect_wizard","final examiner preserves enemy integration and identifies its distinct archetype")
	check(boss.health.maximum==180 and boss.barrier_active,"examiner begins with configured HP and its prediction barrier")
	check(boss.art_frames.size()==2 and boss.body_sprite.texture==boss.art_frames[0],"examiner starts with its cached illustrated composed pose")
	boss.take_spell_damage(20,Vector2.RIGHT,"success")
	check(boss.health.current==180 and boss.blocked_spells==1 and boss.counter_flash>0,"controlled fireball is visibly predicted without damaging the barrier")
	boss.take_spell_damage(12,Vector2.RIGHT,"miscast")
	check(boss.health.current==168 and not boss.barrier_active and is_equal_approx(boss.vulnerability_time,4.0),"miscast damages the examiner and opens a four-second opportunity")
	boss.take_spell_damage(20,Vector2.RIGHT,"success")
	check(boss.health.current==148 and is_equal_approx(boss.vulnerability_time,4.0),"controlled spell works during the opportunity without extending its duration")
	boss.cooldown=100
	boss._physics_process(1.2)
	check(is_equal_approx(boss.vulnerability_time,2.8),"accident opening counts down during active combat")
	boss.active=false
	var timer := boss.vulnerability_time
	var flash := boss.hit_flash
	boss._physics_process(1.5)
	check(is_equal_approx(boss.vulnerability_time,timer) and is_equal_approx(boss.hit_flash,flash),"pausing the enemy preserves vulnerability and visual feedback timers")
	boss.active=true
	cat.active=false
	boss._physics_process(1.5)
	check(is_equal_approx(boss.vulnerability_time,timer),"inactive player freezes the examiner during panels and transitions")
	cat.active=true
	boss._physics_process(3.0)
	check(boss.barrier_active,"the prediction barrier returns when the accident window expires")
	boss.take_spell_damage(20,Vector2.RIGHT,"success")
	check(boss.health.current==148 and boss.blocked_spells==2,"a later controlled spell is predicted again after the window closes")
	fresh()
	boss.take_spell_damage(45,Vector2.RIGHT,"overreaction")
	check(boss.health.current==135 and not boss.barrier_active and boss.window_source=="overreaction","uncontrolled oversized magic also breaks the prediction pattern")
	fresh()
	boss.take_damage(30,Vector2.RIGHT)
	check(boss.health.current==150 and not boss.barrier_active and boss.window_source=="accident","a belly-roll or environmental hit creates an accident opening")
	boss.take_spell_damage(20,Vector2.RIGHT,"success")
	check(boss.health.current==130,"an environmental accident can be followed by a normal fireball")
	fresh()
	boss.phase="windup"
	boss.phase_time=0.7
	boss.take_spell_damage(12,Vector2.RIGHT,"miscast")
	check(boss.phase=="recover" and boss.vulnerability_time>3.9,"miscast interrupts an announced attack and rewards the player with an opening")
	fresh()
	boss.cooldown=0
	boss._physics_process(0.01)
	check(boss.phase=="windup" and boss.phase_time>=0.84 and cat.health.current==100,"boss announces its beam for at least 0.85 seconds before any damage")
	var direction := boss.attack_direction
	cat.position+=Vector2(0,110)
	boss._physics_process(0.40)
	check(boss.attack_direction==direction and boss.phase=="windup","beam direction remains locked while the player sidesteps")
	boss._physics_process(0.46)
	boss._physics_process(0.02)
	boss._physics_process(0.30)
	check(cat.health.current==100 and boss.phase=="recover","sidestepping the announced lane avoids the attack")
	check(not boss.barrier_active and boss.window_source=="recovery" and boss.vulnerability_time>=1.59,"every completed attack grants a guaranteed recovery opening without random miscasts")
	check(boss.break_event_count==0 and boss.barrier_break_age>PerfectExaminer.BREAK_DURATION,"ordinary attack recovery grants an opening without pretending the shield was shattered")
	boss.take_spell_damage(20,Vector2.RIGHT,"success")
	check(boss.health.current==160,"normal fireball can exploit the guaranteed recovery window")
	boss._physics_process(1.7)
	check(boss.barrier_active and boss.phase=="approach","recovery ends and the boss resumes its readable combat loop")
	fresh()
	boss.cooldown=0
	boss._physics_process(0.01)
	boss._physics_process(0.86)
	check(cat.health.current==100,"transition from warning to beam does not inflict a surprise instant hit")
	boss._physics_process(0.02)
	check(cat.health.current==86 and boss.attack_hit,"remaining in the beam lane takes the configured damage")
	cat.invulnerability=0
	boss._physics_process(0.02)
	check(cat.health.current==86,"one beam damages the player only once even if invulnerability is cleared")
	fresh()
	boss.take_spell_damage(0,Vector2.RIGHT,"miscast")
	boss.take_damage(-10,Vector2.RIGHT)
	check(boss.barrier_active and boss.health.current==180,"zero and negative damage cannot fabricate an accident window")
	boss.position=arena.end
	boss.cooldown=100
	boss.take_damage(1,Vector2.RIGHT)
	boss._physics_process(1.0)
	check(boss.position.x<=arena.end.x-32 and boss.position.y<=arena.end.y-32,"examiner knockback remains inside the room bounds")
	fresh()
	var break_events: Array[Dictionary]=[]
	var reform_events: Array[Vector2]=[]
	boss.barrier_broken.connect(func(point: Vector2, reason: String): break_events.append({"point":point,"reason":reason}))
	boss.barrier_reformed.connect(func(point: Vector2): reform_events.append(point))
	boss.cooldown=100
	boss.take_spell_damage(20,Vector2.RIGHT,"success")
	check(break_events.is_empty() and boss.break_event_count==0,"a predicted controlled spell does not manufacture a shield-break cinematic")
	var break_origin := boss.global_position
	boss.take_spell_damage(12,Vector2.RIGHT,"miscast")
	check(break_events.size()==1 and break_events[0].reason=="miscast" and break_events[0].point==break_origin,"a real closed-to-open accident emits one localized barrier-break event at the actual boss")
	check(is_zero_approx(boss.barrier_break_age) and boss.barrier_visual!=null,"shield-break crack and stagger begin at impact without changing the four-second gameplay window")
	check(boss.art_pose==1 and boss.body_sprite.texture==boss.art_frames[1],"the first broken shield immediately changes the wizard to its surprised illustrated pose")
	boss._physics_process(0.2)
	var impact_age := boss.barrier_break_age
	boss.take_spell_damage(3,Vector2.RIGHT,"overreaction")
	check(break_events.size()==1 and is_equal_approx(boss.barrier_break_age,impact_age),"further accidents extend the opening without replaying or restarting its burst")
	boss.active=false
	var frozen := boss.presentation_timers_snapshot()
	boss._physics_process(0.7)
	check(boss.presentation_timers_snapshot()==frozen,"pause freezes shield fragments, stagger and reform presentation clocks together")
	boss.active=true
	boss._physics_process(4.1)
	check(boss.barrier_active and reform_events.size()==1 and boss.reform_event_count==1 and is_zero_approx(boss.barrier_reform_age),"barrier expiry triggers exactly one visible reconstruction when protection actually returns")
	check(boss.art_pose==0 and boss.body_sprite.texture==boss.art_frames[0],"the examiner regains its composed illustration when protection returns")
	boss._physics_process(0.3)
	check(reform_events.size()==1 and is_equal_approx(boss.barrier_reform_age,0.3),"the reconstruction animation advances without repeatedly emitting its completion transition")
	boss.take_damage(1,Vector2.RIGHT)
	check(break_events.size()==2 and break_events[1].reason=="accident","a later fresh shield can be dramatically broken again by a physical/environmental accident")
	fresh()
	var defeated: Array[CandleSlime]=[]
	boss.defeated.connect(func(enemy: CandleSlime): defeated.append(enemy))
	boss.take_damage(9999,Vector2.RIGHT)
	boss.take_spell_damage(9999,Vector2.RIGHT,"miscast")
	check(boss.health.current==0 and defeated.size()==1,"defeating the examiner emits the normal enemy completion signal exactly once")
	await process_frame
	check(not is_instance_valid(boss),"defeated examiner cleans up its body and health display")
	cat.free()
	print("GRIMOIRE RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
