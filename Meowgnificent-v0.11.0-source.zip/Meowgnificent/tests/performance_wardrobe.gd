# Isolate the render cost of the three worn equipment attachments in the same
# final-room stress fixture. Run sequentially with performance_expedition.gd.
extends "res://tests/performance_expedition.gd"
func start() -> void:
 await super.start()
 for id in ["apprentice_thesis","nine_lives_collar","moonlit_yarn"]:
  room.run.add_item(id)
  room.equip_gear(id)
