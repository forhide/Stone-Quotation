# Same final-room stress as the wardrobe fixture, with every foe announcing
# at once. This deliberately exceeds the normal mix of attack phases.
extends "res://tests/performance_wardrobe.gd"

func sample() -> void:
	for enemy in room.enemies:
		enemy.phase="windup"
		enemy.phase_time=(PerfectExaminer.WARNING_TIME if enemy is PerfectExaminer else enemy.warning_duration())*(0.35+0.25*sin(frame*0.025))
		enemy.attack_direction=Vector2.from_angle(enemy.position.x*0.01)
		enemy.queue_redraw()
	super.sample()
