extends SceneTree

# Exercise every new reward through the same ownership and shop interfaces as
# play. A wider catalog must offer more choices without granting extra slots,
# free stats, unreachable drops, or rerolled stock.
const RunModel = preload("res://scripts/systems/expedition_run.gd")
const ORIGINAL_IDS := ["crooked_ash_wand","cinderfork_wand","apprentice_thesis","brass_bell_collar","velvet_bell_collar","nine_lives_collar","loose_feather","warm_sardine_charm","moonlit_yarn"]
const SKILL_IDS := ["ember_ring","cinder_fan","margin_burst","spark_burst","frost_wave","blink_burst","chicken_dash","vine_snare","potion_bomb","thunder_stamp","bubble_guard","comet_shower"]
var checks := 0
var failures := 0

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok:
		print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var model := RunModel.new()
	check(model.catalog.size()==36,"the reward catalog contains36 equipment choices")
	check(model.inventory.is_empty() and model.gold==0 and model.equipment.values()==["","",""],"the run model itself remains empty until the room grants its starting gear")
	var originals_retained := true
	for id: String in ORIGINAL_IDS:
		originals_retained=originals_retained and model.catalog.has(id)
	check(originals_retained,"existing equipment identifiers remain valid for permanent unlocks and rewards")
	var slots := {"wand":0,"collar":0,"charm":0}
	var cells: Dictionary={}
	var skills: Dictionary={}
	var valid := true
	var only_weapons_unlock_skills := true
	var every_item_usable := true
	var no_free_stats := true
	var all_reachable := true
	var passive_signatures: Dictionary={}
	var skill_modifiers := {"skill_damage_bonus":false,"skill_cooldown_multiplier":false,"skill_radius_bonus":false}
	for id: String in model.catalog:
		var item := model.item_info(id)
		var slot := str(item.get("slot",""))
		var tier := int(item.get("tier",-1))
		valid=valid and slots.has(slot) and tier in [0,1,2] and int(item.get("price",0))>0 and not str(item.get("name","")).is_empty() and not str(item.get("description","")).is_empty()
		if not slots.has(slot): continue
		slots[slot]+=1
		var cell := "%s:%d" % [slot,tier]
		cells[cell]=int(cells.get(cell,0))+1
		var skill := str(item.get("skill_id",""))
		if slot=="wand":
			only_weapons_unlock_skills=only_weapons_unlock_skills and SKILL_IDS.has(skill) and not skills.has(skill)
			skills[skill]=true
		else:
			only_weapons_unlock_skills=only_weapons_unlock_skills and skill.is_empty()
			var signature: String=JSON.stringify(item.get("stats",{}),"",true)
			passive_signatures[slot+":"+signature]=true
		var owned := RunModel.new()
		var base := owned.stats()
		owned.add_gold(int(item.price))
		var offer := {"id":id,"kind":"gear","price":int(item.price),"sold":false}
		var bought := owned.purchase(offer)
		every_item_usable=every_item_usable and bool(bought.get("ok",false)) and owned.gold==0 and owned.inventory==[id] and bool(offer.sold) and str(owned.equipment[slot]).is_empty()
		no_free_stats=no_free_stats and owned.stats()==base
		every_item_usable=every_item_usable and owned.equip_item(id) and str(owned.equipment[slot])==id
		for modifier: String in skill_modifiers:
			if item.get("stats",{}).has(modifier):
				var actual: float=float(owned.stats().get(modifier,0))
				var expected: float=float(item.stats[modifier])
				skill_modifiers[modifier]=bool(skill_modifiers[modifier]) or not is_equal_approx(actual,float(base.get(modifier,0)))
				every_item_usable=every_item_usable and is_equal_approx(actual,expected)
		every_item_usable=every_item_usable and owned.unequip_slot(slot) and owned.stats()==base and owned.inventory==[id]
		for unlocked_tier in range(3):
			all_reachable=all_reachable and (model.droppable_items(unlocked_tier).has(id)==(tier<=unlocked_tier))
	check(valid,"every reward has a legal slot, tier, name, description and positive price")
	check(slots=={"wand":12,"collar":12,"charm":12},"weapon, collar and charm categories each offer12 choices")
	var balanced_tiers := true
	for slot: String in slots:
		for tier in range(3): balanced_tiers=balanced_tiers and int(cells.get("%s:%d" % [slot,tier],0))==4
	check(balanced_tiers,"each rarity tier contains four choices for each of the three slots")
	check(only_weapons_unlock_skills and skills.size()==12,"each weapon unlocks one distinct special skill while passive slots add no extra active buttons")
	check(passive_signatures.size()==24,"all24 passive items have distinct stat combinations")
	check(every_item_usable,"all36 items can be bought at their real price, equipped in their slot, and removed without consuming ownership")
	check(no_free_stats,"all36 purchased items wait in the bag without granting unearned equipped bonuses")
	check(skill_modifiers.values()==[true,true,true],"new equipment can actually alter special-skill damage, cooldown and reach")
	check(all_reachable and model.droppable_items(0).size()==12 and model.droppable_items(1).size()==24 and model.droppable_items(2).size()==36,"drop eligibility expands12→24→36 without leaking later-tier rewards into the tutorial")

	var shops := RunModel.new()
	shops.shop_rng.seed=1734
	var seen: Dictionary={}
	var shops_valid := true
	for tier in range(3):
		for roll in range(256):
			var offers := shops.shop_offers(tier)
			shops_valid=shops_valid and offers.size()==4 and str(offers[3].id)==RunModel.HEAL_ID
			for index in range(3):
				var offer: Dictionary=offers[index]
				var info := shops.item_info(str(offer.id))
				shops_valid=shops_valid and str(info.slot)==str(RunModel.SLOTS[index]) and int(info.tier)==tier and int(offer.price)==int(info.price) and not bool(offer.sold)
				seen[str(offer.id)]=true
	check(shops_valid,"randomized shop stock always includes the three slots at the visited tier and their catalog prices plus one provision")
	check(seen.size()==36,"seeded repeated expeditions can find every item in shop stock instead of only the first entry of each slot")
	var same_a := RunModel.new()
	var same_b := RunModel.new()
	same_a.shop_rng.seed=5021
	same_b.shop_rng.seed=5021
	var deterministic := true
	for tier in [0,1,2,0,2,1]: deterministic=deterministic and same_a.shop_offers(tier)==same_b.shop_offers(tier)
	check(deterministic,"the seeded shop sequence is reproducible for encounter and economy verification")
	var carried_stock := shops.shop_offers(1)
	shops.add_gold(1000)
	var purchased_id := str(carried_stock[0].id)
	var purchase_price := int(carried_stock[0].price)
	var stock_purchase := shops.purchase(carried_stock[0])
	var stock_snapshot: Array=carried_stock.duplicate(true)
	for tier in range(3): shops.shop_offers(tier)
	check(bool(stock_purchase.ok) and shops.gold==1000-purchase_price and shops.inventory==[purchased_id] and carried_stock==stock_snapshot and bool(carried_stock[0].sold),"retained room stock keeps its purchased state when another selection is generated")
	var wallet := shops.gold
	check(not bool(shops.purchase(carried_stock[0]).ok) and shops.gold==wallet and shops.inventory==[purchased_id],"a randomized sold offer cannot charge twice or duplicate its reward")

	var full := RunModel.new()
	full.add_gold(1000)
	for index in range(RunModel.INVENTORY_LIMIT): full.add_item("loose_feather")
	var full_offer: Dictionary=full.shop_offers(2)[0]
	check(not full.add_item("comet_crayon") and not bool(full.purchase(full_offer).ok) and full.gold==1000 and not bool(full_offer.sold) and full.inventory.size()==18,"a larger reward pool preserves the18-item bag limit and atomic full-bag rejection")
	var provision: Dictionary=full.shop_offers(0)[3]
	check(bool(full.purchase(provision).ok) and full.inventory.size()==18,"a full equipment bag still allows a restorative provision")
	var original_gold := full.gold
	var forged := {"id":"comet_crayon","kind":"gear","price":1,"sold":false}
	check(not bool(full.purchase(forged).ok) and full.gold==original_gold and not bool(forged.sold),"new rare items reject forged prices without charging or marking stock sold")
	var invalid := RunModel.new()
	invalid.equipment.wand="comet_crayon"
	invalid.equipment.collar="crooked_ash_wand"
	check(invalid.stats()==model.stats(),"unowned or wrong-slot equipment references never grant expanded skill bonuses")
	var shared_icons := true
	var safe_regions := true
	var all_layouts_fit := true
	var preserved_aspect := true
	var unique_regions: Dictionary={}
	var atlas_resources: Dictionary={}
	var original_collar_crops := true
	var new_pendants_safe := true
	for id: String in model.catalog:
		var texture := EquipmentArt.icon(id) as AtlasTexture
		var worn := EquipmentArt.worn_icon(id) as AtlasTexture
		shared_icons=shared_icons and EquipmentArt.has_icon(id) and texture!=null and worn!=null
		if texture==null or worn==null: continue
		shared_icons=shared_icons and texture==EquipmentArt.icon(id) and worn==EquipmentArt.worn_icon(id)
		var atlas_rect := Rect2(Vector2.ZERO,texture.atlas.get_size())
		safe_regions=safe_regions and atlas_rect.encloses(texture.region) and texture.region.size.x>0 and texture.region.size.y>0 and texture.filter_clip
		safe_regions=safe_regions and Rect2(Vector2.ZERO,worn.atlas.get_size()).encloses(worn.region) and worn.filter_clip
		var region_key := "%d:%s" % [texture.atlas.get_instance_id(),str(texture.region)]
		unique_regions[region_key]=true
		atlas_resources[texture.atlas.get_instance_id()]=true
		var item: Dictionary=model.catalog[id]
		var layout := EquipmentArt.attachment_layout(id)
		var extent: Vector2=layout.get("extent",Vector2.ZERO)
		var source: Vector2=worn.get_size()
		all_layouts_fit=all_layouts_fit and str(layout.get("slot",""))==str(item.slot) and EquipmentArt.slot_for(id)==str(item.slot) and extent.x>0 and extent.y>0
		var box := Vector2(44,52)
		if str(item.slot)=="collar": box=Vector2(14,17)
		elif str(item.slot)=="charm": box=Vector2(24,26)
		all_layouts_fit=all_layouts_fit and extent.x<=box.x+0.001 and extent.y<=box.y+0.001
		preserved_aspect=preserved_aspect and is_equal_approx(extent.x/extent.y,source.x/source.y)
		if str(item.slot)=="collar":
			if ORIGINAL_IDS.has(id):
				original_collar_crops=original_collar_crops and worn!=texture and texture.region.size.x>worn.region.size.x and texture.region.size.y>worn.region.size.y
			else:
				new_pendants_safe=new_pendants_safe and worn==texture and extent.x<=14.001 and extent.y<=17.001
	check(shared_icons,"all36 inventory, drop and worn images reuse cached textures")
	check(safe_regions and unique_regions.size()==36 and atlas_resources.size()==4,"all36 distinct icon regions stay inside four shared imported atlases")
	check(all_layouts_fit,"all36 worn items fit their proper paw, neck or hat attachment bounds")
	check(preserved_aspect,"equipment keeps its authored proportions when fitted to the character")
	check(original_collar_crops and new_pendants_safe,"old collars use small pendant crops and new pendants fit safely below the cat's muzzle")
	check(not EquipmentArt.has_icon("unknown") and EquipmentArt.icon("unknown")==null and EquipmentArt.worn_icon("unknown")==null and EquipmentArt.attachment_layout("unknown").is_empty(),"unknown item identifiers cannot create a fallback icon or wearable")
	var wardrobe := CatEquipmentVisual.new()
	wardrobe.set_equipment({"wand":"comet_crayon","collar":"bubble_pearl_collar","charm":"comet_stamp"})
	var original_revision: int=wardrobe.revision
	wardrobe.set_equipment({"wand":"comet_crayon","collar":"bubble_pearl_collar","charm":"comet_stamp"})
	check(wardrobe.equipment=={"wand":"comet_crayon","collar":"bubble_pearl_collar","charm":"comet_stamp"} and wardrobe.revision==original_revision,"new weapon, pendant and charm IDs are accepted without refreshing unchanged equipment")
	wardrobe.set_equipment({"wand":"bubble_pearl_collar","collar":"comet_stamp","charm":"comet_crayon"})
	check(wardrobe.equipment.values()==["","",""],"wearable validation rejects real items placed in the wrong attachment slot")
	wardrobe.free()
	print("CATALOG EXPANSION RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
