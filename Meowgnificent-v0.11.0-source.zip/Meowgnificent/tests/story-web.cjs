const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');

// Default-player narrative path: deliberately does not use skip_story or
// internal engine state. Screen OCR and real keyboard input prove the flow.
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 let checks=0;
 try {
  const context=await browser.newContext({viewport:{width:1280,height:800}});
  const page=await context.newPage();const errors=[];const failed=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('console',message=>{if(message.type()==='error')errors.push(message.text())});
  page.on('response',response=>{if(response.status()>=400)failed.push([response.status(),response.url()])});
  function check(ok,name){assert(ok,name);checks++;console.log('PASS: '+name)}
  async function screen(name){
   const path='/tmp/meowgnificent-v0110-story-web-'+name+'.png';await page.screenshot({path});
   let extra='';
   if(['opening','page02','detention'].includes(name)){
    const crop=path.replace('.png','-caption.png');const bounds=name==='detention'?'(350,126,930,238)':'(75,735,600,779)';
    execFileSync('python3',['-c','from PIL import Image,ImageOps,ImageEnhance; import sys; im=ImageEnhance.Contrast(ImageOps.autocontrast(Image.open(sys.argv[1]).crop('+bounds+').convert("L"))).enhance(2); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,crop]);
    extra=execFileSync('tesseract',[crop,'stdout','--psm',name==='detention'?'11':'7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   return extra+'\n'+execFileSync('tesseract',[path,'stdout','--psm','11'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
  }
  async function expectScreen(name,predicate,description){
   let text='';
   for(let attempt=0;attempt<24;attempt++){
    await page.waitForTimeout(120);text=await screen(name);
    if(predicate(text)){check(true,description);return text}
   }
   assert.fail(description+'; last canvas OCR: '+JSON.stringify(text));
  }
  const gameUrl=new URL(process.env.GAME_URL || 'http://127.0.0.1:8082/');gameUrl.searchParams.delete('skip_story');gameUrl.searchParams.set('lang','en');
  await page.goto(gameUrl.href,{waitUntil:'networkidle'});
  await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});
  await page.waitForTimeout(500);
  check(!new URL(page.url()).searchParams.has('skip_story'),'default-player URL has no narrative bypass flag');
  await expectScreen('intro',text=>text.includes('a minor magical incident'),'default exported build renders the start screen');
  await page.locator('#canvas').click({position:{x:200,y:680}});
  await page.keyboard.press('Enter');
  await expectScreen('opening',text=>text.includes('arcana academy') && text.includes('skip story') && /\b0?1\s*[/|]\s*14\b/.test(text),'Enter opens the Academy story instead of entering combat immediately');
  await page.keyboard.press('Space');
  await expectScreen('page02',text=>text.includes('professor') && /\b0?2\s*[/|]\s*14\b/.test(text),'Space advances to the professor’s request on the next story page');
  await page.keyboard.press('Escape');
  await expectScreen('detention',text=>/entering\s+area\s+0?1/.test(text) && text.includes('detention') && text.includes('passage locked') && !text.includes('skip story'),'Escape skips the opening into the playable Detention tutorial');
  await page.keyboard.press('i');
  await expectScreen('equipment',text=>text.includes('traveling possessions') && text.includes('satchel'),'the tutorial accepts equipment input after the narrative callback');
  await page.keyboard.press('Escape');
  await expectScreen('equipment-closed',text=>!text.includes('traveling possessions') && text.includes('detention'),'Escape closes equipment without reopening or advancing the story');
  await page.keyboard.press('Escape');
  await expectScreen('pause',text=>text.includes('taking a catnap'),'normal pause input works after the story has released control');
  check(failed.length===0,'default narrative assets load without HTTP failures');
  check(errors.length===0,'default narrative path has no browser or engine console errors: '+JSON.stringify(errors));
  console.log(`STORY WEB RESULT: ${checks} checks, 0 failures`);
  console.log('Scope: default exported narrative start, one page advance, Escape skip into Detention, equipment and pause control; no browser full-opening autoplay, campaign-clear or ending claim.');
 } finally {await browser.close()}
})().catch(error=>{console.error(error);process.exit(1)});
