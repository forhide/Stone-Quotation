extends SceneTree

const MetaModel = preload("res://scripts/systems/meta_progress.gd")
var checks := 0
var failures := 0
var test_dir: String

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func _initialize() -> void:
	call_deferred("run")

func write_text(path: String, text: String) -> void:
	var file := FileAccess.open(path,FileAccess.WRITE)
	assert(file!=null)
	file.store_string(text)
	file.close()

func run() -> void:
	test_dir="/tmp/meowgnificent-meta-%d-%d" % [OS.get_process_id(),Time.get_ticks_usec()]
	assert(DirAccess.make_dir_recursive_absolute(test_dir)==OK)
	var path := test_dir+"/progress.json"
	var meta := MetaModel.new(path)
	check(meta.starlight==0 and meta.attempts==0 and meta.wins==0 and meta.best_sector==0 and meta.save_error.is_empty(),"missing profile starts safely with no permanent unlocks")
	check(meta.begin_run()==1 and meta.attempts==1 and FileAccess.file_exists(path),"beginning a run commits a new attempt and active run id")
	check(meta.award_sector(0,1)==1 and meta.starlight==1 and meta.best_sector==1,"first sector immediately persists starlight and one-based progress")
	check(meta.award_sector(0,99)==0 and meta.starlight==1,"one sector cannot award twice during the same run")
	var reloaded := MetaModel.new(path)
	check(reloaded.starlight==1 and reloaded.active_run_id==1 and reloaded.award_sector(0,99)==0,"reload preserves both earned currency and the duplicate-award guard")
	check(reloaded.award_sector(1,1)==1 and reloaded.finish_run(false),"a failed run is committed without removing earned starlight")
	check(not reloaded.finish_run(true) and reloaded.wins==0,"finishing one run twice cannot fabricate a win")
	meta=MetaModel.new(path)
	check(meta.starlight==2 and meta.attempts==1 and meta.wins==0 and meta.active_run_finished,"permanent currency survives a failed run and reload")
	check(meta.begin_run()==2 and meta.award_sector(0,1)==1 and meta.starlight==3 and meta.best_sector==2,"a retry resets sector awards while retaining permanent currency and best progress")
	check(meta.finish_run(true) and MetaModel.new(path).wins==1,"winning increments the lifetime win count exactly once")
	var result := meta.purchase_upgrade("vitality")
	check(result.ok and meta.starlight==0 and meta.upgrades.vitality==1 and meta.bonuses().max_hp_bonus==5,"buying an upgrade commits its exact cost and future-run bonus")
	meta=MetaModel.new(path)
	check(meta.upgrades.vitality==1 and meta.bonuses().max_hp_bonus==5 and meta.starlight==0,"purchased permanent upgrades survive reload")
	check(not meta.purchase_upgrade("purse").ok and not meta.purchase_upgrade("missing").ok and meta.starlight==0,"insufficient funds and unknown upgrades never spend currency")
	meta.begin_run()
	meta.award_sector(2,100)
	for i in range(3): meta.purchase_upgrade("vitality")
	var before: int = meta.starlight
	check(meta.upgrades.vitality==4 and not meta.purchase_upgrade("vitality").ok and meta.starlight==before,"vitality caps at four ranks and cannot charge beyond the cap")
	for i in range(3): meta.purchase_upgrade("purse")
	for i in range(3): meta.purchase_upgrade("magnet")
	meta.purchase_upgrade("starter_wand")
	var bonuses := meta.bonuses()
	check(bonuses.max_hp_bonus==20 and bonuses.starting_gold==15 and bonuses.pickup_radius_bonus==24 and bonuses.starter_item=="crooked_ash_wand","all four permanent unlocks yield the specified bounded bonuses")
	check(not meta.purchase_upgrade("starter_wand").ok and meta.upgrades.starter_wand==1,"starter wand unlock is a one-time purchase")
	var offers := meta.upgrade_offers()
	check(offers.size()==4 and offers[0].level==4 and offers[0].max_level==4 and offers[0].cost==0,"upgrade UI sees current level, cap and sold-out cost")
	var bank: int = meta.starlight
	meta.begin_run()
	check(meta.starlight==bank and meta.award_sector(0,1)==1 and meta.bonuses().starting_gold==15,"new expeditions preserve the bank and purchased bonuses")
	check(meta.award_sector(3,0)==0 and meta.best_sector==4 and meta.award_sector(3,2)==0,"zero-reward shop sectors still advance progress and cannot later pay twice")
	check(meta.award_sector(-1,5)==0 and meta.award_sector(99999,5)==0 and meta.award_sector(4,-1)==0,"invalid sectors and negative rewards are rejected")

	var broken_path := test_dir+"/recover.json"
	var recover := MetaModel.new(broken_path)
	recover.begin_run()
	recover.award_sector(0,5)
	recover.award_sector(1,2)
	write_text(broken_path,"{broken JSON")
	recover=MetaModel.new(broken_path)
	check(recover.starlight==5 and recover.best_sector==1 and not recover.save_error.is_empty(),"corrupt primary falls back to the previous valid committed backup")
	check(recover.begin_run()==2 and MetaModel.new(broken_path).starlight==5,"recovered progress can be committed again without erasing its bank")
	var corrupt_path := test_dir+"/corrupt.json"
	write_text(corrupt_path,"[not a profile")
	var fresh := MetaModel.new(corrupt_path)
	check(fresh.starlight==0 and not fresh.save_error.is_empty() and fresh.begin_run()==1,"corruption without a usable backup recovers to a safe writable profile")

	var malformed_path := test_dir+"/malformed.json"
	write_text(malformed_path,JSON.stringify({"version":1,"starlight":-200,"attempts":-2,"wins":500,"best_sector":999999,"active_run_id":999,"active_run_finished":false,"upgrades":{"vitality":999,"purse":-3,"magnet":"bad","starter_wand":1.5},"awarded_sectors":["1",0,0,-1,99999]}))
	var malformed := MetaModel.new(malformed_path)
	check(malformed.starlight==0 and malformed.attempts==0 and malformed.wins==0 and malformed.best_sector==8 and malformed.active_run_id==0 and malformed.active_run_finished,"malformed counters and active state are validated and clamped")
	check(malformed.upgrades.vitality==4 and malformed.upgrades.purse==0 and malformed.upgrades.magnet==0 and malformed.upgrades.starter_wand==1,"malformed upgrade levels cannot exceed caps or grant invalid ranks")

	var future_path := test_dir+"/future.json"
	var future_raw := "{\"version\":2,\"starlight\":999,\"future_data\":\"KEEP EXACTLY\"}\n"
	write_text(future_path,future_raw)
	var future := MetaModel.new(future_path)
	check(future.begin_run()==0 and future.award_sector(0,5)==0 and not future.finish_run(true) and not future.purchase_upgrade("vitality").ok,"unsupported future profile blocks mutating operations")
	check(FileAccess.get_file_as_string(future_path)==future_raw and not FileAccess.file_exists(future_path+".bak") and not future.save_error.is_empty(),"unsupported future-version bytes remain unchanged without a replacement backup")

	var failure_path := test_dir+"/write-failure.json"
	var failing := MetaModel.new(failure_path)
	failing.begin_run()
	failing.award_sector(0,10)
	assert(DirAccess.remove_absolute(failure_path+".bak")==OK)
	assert(DirAccess.make_dir_absolute(failure_path+".bak")==OK)
	var failed_buy := failing.purchase_upgrade("vitality")
	check(not failed_buy.ok and failing.starlight==10 and failing.upgrades.vitality==0 and not failing.save_error.is_empty(),"failed atomic commit rolls back upgrade cost and level")
	check(failing.award_sector(1,2)==0 and failing.starlight==10 and failing.best_sector==1,"failed reward commit rolls back currency and sector progress")
	check(not failing.finish_run(true) and failing.wins==0 and not failing.active_run_finished,"failed finish commit does not record a phantom win")
	check(failing.begin_run()==0 and failing.attempts==1 and failing.active_run_id==1,"failed begin commit rolls back attempt and active run identifiers")
	var still_valid := MetaModel.new(failure_path)
	check(still_valid.starlight==10 and still_valid.upgrades.vitality==0 and still_valid.attempts==1,"save failures leave the previous primary profile valid on reload")
	assert(DirAccess.remove_absolute(failure_path+".bak")==OK)
	check(failing.purchase_upgrade("vitality").ok and MetaModel.new(failure_path).starlight==7,"saving recovers normally when the filesystem obstruction is removed")
	var leftovers := DirAccess.get_files_at(test_dir)
	var no_temps := true
	for file: String in leftovers:
		if ".tmp-" in file: no_temps=false
	check(no_temps,"failed atomic saves leave no temporary files")
	for file: String in DirAccess.get_files_at(test_dir): DirAccess.remove_absolute(test_dir+"/"+file)
	DirAccess.remove_absolute(test_dir)
	print("META RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
