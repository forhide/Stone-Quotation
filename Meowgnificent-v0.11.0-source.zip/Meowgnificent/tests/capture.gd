# Optional graphical check: requires a real or virtual display (not --headless).
extends SceneTree

func _initialize() -> void:
	call_deferred("capture")

func capture() -> void:
	var room = load("res://scenes/main.tscn").instantiate()
	root.add_child(room)
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://docs/phase1-intro.png")
	room.begin_or_restart()
	for enemy in room.enemies:
		enemy.active=false
	room.spells.resolver.forced="overreaction"
	room.spells.cast(Vector2(0.95,-0.3).normalized())
	for i in range(8): await physics_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://docs/phase1-gameplay.png")
	room.set_running(false)
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("res://docs/phase1-paused.png")
	print("Saved intro, gameplay and pause screenshots")
	quit()
