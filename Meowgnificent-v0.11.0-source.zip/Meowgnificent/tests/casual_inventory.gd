extends SceneTree

# Exercise the actual panel callbacks and real equip model. The comparison is
# deliberately qualitative; arithmetic remains covered by character_stats.gd.
var checks := 0
var failures := 0
var room
var panel

func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func frames(n: int=3) -> void:
 for i in range(n):
  await physics_frame
  await process_frame
func fingerprint() -> Dictionary:
 return {"inventory":room.run.inventory.duplicate(),"equipment":room.run.equipment.duplicate(),"gold":room.run.gold,"hp":room.player.health.current,"max_hp":room.player.health.maximum,"special_cooldown":room.skills.cooldown_remaining,"spell_cooldown":room.spells.cooldown}
func hint_rows(node: Node) -> Array:
 var result: Array=[]
 if node.has_meta("stat_key"): result.append(node)
 for child in node.get_children(): result.append_array(hint_rows(child))
 return result
func labels(node: Node) -> Array:
 var result: Array=[]
 if node is Label: result.append(node)
 for child in node.get_children(): result.append_array(labels(child))
 return result
func icon_of(node: Node) -> Texture2D:
 if node is Button and node.icon!=null: return node.icon
 if node is TextureRect and node.texture!=null: return node.texture
 for child in node.get_children():
  var texture := icon_of(child)
  if texture!=null: return texture
 return null
func paperdoll_equipment() -> Dictionary:
 if panel.preview_model.has_method("get_equipment"):
  var data: Variant=panel.preview_model.call("get_equipment")
  return data.duplicate() if data is Dictionary else {}
 for property in panel.preview_model.get_property_list():
  if str(property.name)=="equipment":
   var data: Variant=panel.preview_model.get("equipment")
   return data.duplicate() if data is Dictionary else {}
 return {}
func change_map(rows: Array) -> Dictionary:
 var result := {}
 for row: Dictionary in rows: result[str(row.key)]=int(row.quality)
 return result
func visible_rect(control: Control) -> Rect2:
 var result := control.get_global_rect()
 var node := control.get_parent()
 while node!=null:
  if node is Control and node.clip_contents: result=result.intersection(node.get_global_rect())
  node=node.get_parent()
 return result

func run() -> void:
 change_scene_to_file("res://scenes/main.tscn")
 await frames()
 room=current_scene
 room.begin_or_restart()
 room.set_physics_process(false)
 room.player.set_physics_process(false)
 for enemy in room.enemies: enemy.active=false
 room.player.health.current=37
 room.skills.set_physics_process(false)
 room.spells.set_physics_process(false)
 room.skills.cooldown_remaining=3.0
 room.spells.cooldown=2.0
 for id in ["cinderfork_wand","brass_bell_collar","loose_feather","linen_star_collar","moss_heart_collar","bubble_teapot","bloop_cork"]: room.run.add_item(id)
 var current := CharacterStats.for_room(room)
 var same := current.duplicate(true)
 check(EquipmentComparison.changes(current,same).is_empty(),"identical equipment does not fill the panel with unchanged statistics")
 var faster := current.duplicate(true)
 faster.spell_cooldown=float(current.spell_cooldown)*0.8
 faster.roll_cooldown=float(current.roll_cooldown)*0.8
 var ratings := change_map(EquipmentComparison.changes(current,faster))
 check(ratings=={"spell_cooldown":1,"roll_cooldown":1},"shorter spell and roll recovery use improvement arrows")
 var slower := current.duplicate(true)
 slower.spell_cooldown=float(current.spell_cooldown)*1.2
 check(change_map(EquipmentComparison.changes(current,slower))=={"spell_cooldown":-1},"longer recovery is shown as a downgrade rather than a numerical increase")
 var skill_boost := current.duplicate(true)
 skill_boost.skill_damage=int(current.skill_damage)+7
 skill_boost.skill_cooldown=float(current.skill_cooldown)*0.8
 skill_boost.skill_radius=float(current.skill_radius)+14
 var skill_changes := EquipmentComparison.changes(current,skill_boost)
 check(change_map(skill_changes)=={"skill_damage":1,"skill_cooldown":1,"skill_radius":1},"the same special skill can compare its meaningful power, recovery and reach")
 var other_skill := skill_boost.duplicate(true)
 other_skill.skill_id="bubble_guard"
 check(EquipmentComparison.changes(current,other_skill).is_empty(),"different special skills are not given a misleading numeric damage/reach rating")
 check(current==same and faster.spell_cooldown<float(current.spell_cooldown),"qualitative comparison never mutates its input snapshots")

 room.open_inventory()
 await frames()
 panel=room.panel
 check(panel.item_buttons.size()==room.run.inventory.size() and panel.slot_buttons.keys().size()==3,"owned items become grid buttons and exactly three equipment slots remain")
 check(panel.preview_model!=null and paperdoll_equipment()==room.run.equipment,"the paperdoll initially shows the actual equipped items")
 check(panel.item_buttons.values().all(func(button: Button) -> bool: return button.tooltip_text.is_empty()) and panel.slot_buttons.values().all(func(button: Button) -> bool: return button.tooltip_text.is_empty()),"comparison and slot names use the panel directly without a redundant native tooltip window")
 var before := fingerprint()
 var initial_selection: String=panel.selected_item_id
 check(initial_selection=="practice_wand","opening the grid selects the currently owned primary tool")
 panel.item_buttons["cinderfork_wand"].mouse_entered.emit()
 await frames()
 check(panel.preview_item_id=="cinderfork_wand" and panel.selected_item_id==initial_selection,"hover previews an owned item without silently selecting it")
 check(fingerprint()==before and paperdoll_equipment()==before.equipment,"hover cannot equip, charge currency, heal, reset cooldown or change the worn preview")
 var rows := hint_rows(panel.stats_container)
 var hints := {}
 var semantic_arrows := true
 for row in rows:
  hints[str(row.get_meta("stat_key"))]=int(row.get_meta("improvement"))
  semantic_arrows=semantic_arrows and str(row.get_meta("direction"))==("up" if int(row.get_meta("improvement"))>0 else "down")
 check(hints=={"spell_damage":1,"spell_cooldown":-1} and semantic_arrows,"the real hovered wand shows only its damage upgrade and slower-recovery downgrade")
 var number_pattern := RegEx.new()
 number_pattern.compile("[0-9]")
 var no_numeric_table := true
 for label in labels(panel.stats_container):
  no_numeric_table=no_numeric_table and number_pattern.search(label.text)==null and label.text not in ["Base","Now","After","Change"]
 check(no_numeric_table,"the visible comparison contains no base/current/after numeric table")
 panel.item_buttons["brass_bell_collar"].pressed.emit()
 await frames()
 check(panel.selected_item_id=="brass_bell_collar" and panel.preview_item_id=="brass_bell_collar" and fingerprint()==before,"clicking a grid item selects its comparison without equipping it")
 panel.item_buttons["loose_feather"].mouse_entered.emit()
 await frames()
 check(panel.preview_item_id=="loose_feather" and panel.selected_item_id=="brass_bell_collar" and panel.equip_button.disabled,"temporary hover preserves the selected item and cannot activate an unrelated equipment action")
 panel._clear_hover()
 await frames()
 check(panel.preview_item_id=="brass_bell_collar","leaving a hovered item restores the selected comparison")
 var unowned := ""
 for id in room.run.catalog:
  if not room.run.inventory.has(id):
   unowned=id
   break
 panel._preview_item(unowned)
 panel._select_item(unowned)
 panel._preview_item("missing-item")
 panel._select_item("missing-item")
 await frames()
 check(panel.selected_item_id=="brass_bell_collar" and panel.preview_item_id=="brass_bell_collar" and fingerprint()==before,"unknown or unowned icons cannot select or preview equipment")
 var keyboard_item: Button=panel.item_buttons["linen_star_collar"]
 keyboard_item.grab_focus()
 await frames()
 check(keyboard_item.focus_mode==Control.FOCUS_ALL and keyboard_item.has_focus() and panel.preview_item_id=="linen_star_collar","keyboard focus provides the same comparison as pointer hover")
 check(fingerprint()==before,"keyboard comparison remains read-only while combat is paused")

 for id in ["cinderfork_wand","brass_bell_collar","loose_feather"]:
  panel._select_item(id)
  await frames()
  check(not panel.equip_button.disabled,"a selected owned item exposes an explicit equipment action: "+id)
  panel.equip_button.pressed.emit()
  await frames()
  var slot := str(room.run.catalog[id].slot)
  check(str(room.run.equipment[slot])==id and icon_of(panel.slot_buttons[slot])==EquipmentArt.icon(id),"explicit equip updates the actual slot and its miniature artwork: "+id)
  check(paperdoll_equipment()==room.run.equipment,"explicit equip refreshes the current worn paperdoll: "+id)
 check(room.player.health.current==37 and room.skills.cooldown_remaining==3.0 and room.spells.cooldown==2.0,"equipping from the casual screen preserves health and both active cooldowns")
 for id in ["loose_feather","brass_bell_collar","cinderfork_wand"]:
  var slot := str(room.run.catalog[id].slot)
  panel._select_item(id)
  await frames()
  panel.equip_button.pressed.emit()
  await frames()
  check(str(room.run.equipment[slot]).is_empty() and room.run.inventory.has(id) and icon_of(panel.slot_buttons[slot])!=EquipmentArt.icon(id),"the equipped-item action puts it away while keeping ownership: "+id)
 check(room.run.equipment.values()==["","",""] and paperdoll_equipment()==room.run.equipment,"removing the last slot also clears the final worn item from the paperdoll")

 room.close_panel()
 for id in room.run.catalog:
  if room.run.inventory.size()>=18: break
  if not room.run.inventory.has(id): room.run.add_item(id)
 for lang in ["ko","en"]:
  GameLocale.set_language(lang,false)
  room.open_inventory()
  panel=room.panel
  await frames()
  check(panel.item_buttons.size()==18 and room.run.inventory.size()==18,"the full eighteen-item bag remains reachable in the icon grid: "+lang)
  var viewport := Rect2(0,0,1280,800)
  var inside := true
  var right_of_character := true
  for id in panel.item_buttons:
   var button: Button=panel.item_buttons[id]
   var clipped := visible_rect(button)
   inside=inside and (clipped.size==Vector2.ZERO or viewport.encloses(clipped))
   right_of_character=right_of_character and button.global_position.x>=panel.preview_model.global_position.x+panel.preview_model.size.x*0.5
  check(inside and right_of_character,"owned icons stay to the right of the character and inside the clipped viewport: "+lang)
  var slots_inside := true
  for slot in ["wand","collar","charm"]:
   slots_inside=slots_inside and viewport.encloses(panel.slot_buttons[slot].get_global_rect())
  check(slots_inside and viewport.encloses(panel.preview_model.get_global_rect()),"the character and all three positioned equipment slots remain visible: "+lang)
  panel._preview_item("cinderfork_wand")
  await frames()
  check(panel.close_button.get_global_rect().end.y<800 and panel.stats_container.get_global_rect().end.y<panel.close_button.global_position.y,"compact hints and return controls fit both translations: "+lang)
  room.close_panel()
 check(room.state=="playing" and room.player.active,"closing the redesigned inventory returns control to the current expedition")
 print("CASUAL INVENTORY RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
