extends SceneTree
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func frames(count: int) -> void:
 for i in range(count):
  await physics_frame
  await process_frame
func _initialize() -> void: call_deferred("run")
func run() -> void:
 # Whole-body frames remove the detached belly/paw patch regression.
 var seen := {}
 for i in range(6):
  var frame := GroundedCatGait.frame_for(i*16.0)
  seen[frame]=true
  check(frame>=0 and frame<6,"distance selects a valid connected full-body pose")
  check(GroundedCatGait.frame_for(i*16.0+96.0)==frame,"gait loops after one travelled stride")
 check(seen.size()==6,"the stride uses all six authored contact and passing drawings")
 check(2.0*220.0/GroundedCatGait.CYCLE_DISTANCE<=5.0,"normal walking avoids a rapid pattering cadence")
 for rect: Rect2i in WizardCatVisual.WALK_RECTS:
  check(Rect2i(Vector2i.ZERO,WizardCatVisual.WALK_SHEET.get_size()).encloses(rect),"walk crop stays inside the authored sheet")
 change_scene_to_file("res://scenes/main.tscn")
 await frames(4)
 var room=current_scene
 room.begin_or_restart()
 for enemy in room.enemies: enemy.active=false
 room.player.invulnerability=1000
 room.player.position=Vector2(500,420)
 var visual: WizardCatVisual=room.player.visual
 room.player.set_physics_process(false)
 room.player.walk_distance=4
 room.player.ground_speed=float(room.player.config.speed)
 room.player.walk_direction=Vector2.RIGHT
 visual.gait=1
 visual._process(0)
 var first_frame := visual.walk_frame
 var immutable_mesh := visual.sprite.mesh
 check(visual.sprite.texture==WizardCatVisual.WALK_SHEET,"walking renders the complete new painted figure")
 room.player.position+=Vector2(32,0)
 room.player.walk_distance+=32
 visual._process(0)
 check(visual.walk_frame!=first_frame,"real travel advances the full-body contact sequence")
 check(visual.sprite.mesh==immutable_mesh,"changing walk frames does not rebuild geometry")
 room.player.set_physics_process(true)
 var start_distance: float=room.player.walk_distance
 Input.action_press("move_right")
 await frames(18)
 Input.action_release("move_right")
 check(room.player.walk_distance>start_distance+20 and room.player.ground_speed>0,"real movement advances the foot cycle using displacement")
 check(visual.get_child_count()==2 and visual.body_offset==Vector2.ZERO,"the visual uses one connected figure and gear without detached paw or belly nodes")
 check(visual.rotation==0 and visual.position==Vector2.ZERO,"walking does not rock or lift the entire character off the floor")
 var mesh := visual.sprite.mesh
 room.player.position=Vector2(room.bounds.end.x-float(room.player.config.radius),420)
 room.player.velocity=Vector2.ZERO
 Input.action_press("move_right")
 await frames(5)
 var wall_distance: float=room.player.walk_distance
 await frames(10)
 Input.action_release("move_right")
 check(is_equal_approx(room.player.walk_distance,wall_distance) and room.player.ground_speed==0,"pushing a room wall does not moonwalk in place")
 room.player.position=Vector2(500,420)
 room.player.velocity=Vector2.ZERO
 room.player.start_roll(Vector2.RIGHT)
 var roll_distance: float=room.player.walk_distance
 await frames(8)
 check(is_equal_approx(room.player.walk_distance,roll_distance) and visual.active_pose==5,"rolling uses its tucked pose without advancing walking feet")
 room.player.roll_time=0.001
 await frames(1)
 check(is_equal_approx(room.player.walk_distance,roll_distance),"the final partial roll tick does not become a walking stride")
 room.player.velocity=Vector2.ZERO
 await frames(6)
 room.set_running(false)
 await frames(2)
 var paused_distance: float=room.player.walk_distance
 var paused_art := visual.art_key
 var paused_elapsed: float=visual.elapsed
 await frames(8)
 check(is_equal_approx(room.player.walk_distance,paused_distance) and visual.art_key==paused_art and is_equal_approx(visual.elapsed,paused_elapsed),"pause freezes gait, body and feet together")
 check(visual.sprite.mesh==mesh,"walking, wall contact, rolling and pause reuse the same mesh resource")
 check(visual.walk_frame==-1 and visual.sprite.texture==WizardCatVisual.ACTION_SHEET,"stopping returns to the approved intact idle art")
 print("GROUNDED GAIT RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
