const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 let checks=0;
 const check=(ok,name)=>{assert(ok,name);checks++;console.log('PASS: '+name)};
 try{
  for(const mode of ['keyboard','right-click']){
   const context=await browser.newContext({viewport:{width:1280,height:800}});
   const page=await context.newPage();const errors=[];
   page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
   const url=new URL(process.env.GAME_URL||'http://127.0.0.1:8082/');url.searchParams.set('skip_story','1');url.searchParams.set('lang','en');
   await page.goto(url.href);await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});await page.waitForTimeout(1700);
   await page.keyboard.down('Enter');await page.waitForTimeout(100);await page.keyboard.up('Enter');await page.waitForTimeout(900);
   async function read(name){
    const path='/tmp/meowgnificent-v0110-item-skills-'+mode+'-'+name+'.png';await page.screenshot({path});
    const crop=path.replace('.png','-ocr.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps;import sys;im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((530,720,850,776)).convert("L"));im.resize((im.width*4,im.height*4)).save(sys.argv[2])',path,crop]);
    return execFileSync('tesseract',[crop,'stdout','--psm','6'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   async function until(name,predicate){let text='';for(let i=0;i<15;i++){text=await read(name);if(predicate(text))return text;await page.waitForTimeout(120)}assert.fail(name+': '+text)}
   const ready=await until('ready',t=>t.includes('pocket')&&t.includes('ready'));check(ready.includes('spark'),mode+': starter weapon exposes the actual equipped Pocket Spark skill');
   await page.mouse.move(870,440);
   async function activate(){if(mode==='keyboard'){await page.keyboard.down('q');await page.waitForTimeout(120);await page.keyboard.up('q')}else await page.mouse.click(870,440,{button:'right',delay:120});}
   await activate();await page.waitForTimeout(180);
   const cast=await until('cast',t=>t.includes('remaining'));check(cast.includes('remaining'),mode+': real special action starts the visible shared cooldown');
   function seconds(t){const m=t.match(/(\d+[.,]\d)\s*s/);assert(m,'Cooldown number unreadable: '+t);return Number(m[1].replace(',','.'))}
   const before=seconds(cast);await activate();await page.waitForTimeout(160);const after=seconds(await read('again'));
   check(after<=before+0.1&&after>0,mode+': pressing again during recovery cannot restart or bypass it');
   check(errors.length===0,mode+': no browser or engine errors: '+JSON.stringify(errors));
   await context.close();
  }
  console.log('ITEM SKILLS WEB RESULT: '+checks+' checks, 0 failures');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
