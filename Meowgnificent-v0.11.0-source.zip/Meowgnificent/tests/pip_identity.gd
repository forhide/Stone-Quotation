extends SceneTree

# Check the real world renderer identity and anchored idle behavior with the same atlas used by story, inventory and world.
class RunStub extends RefCounted:
 var stage_index := 0
class RoomStub extends Node2D:
 var run := RunStub.new()
 var stage_def := {"name":"Detention","kind":"combat"}
 var exit_open := false
 var player := Node2D.new()
 var state := "playing"
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func run() -> void:
 var room := RoomStub.new()
 root.add_child(room)
 room.add_child(room.player)
 var markers := ExpeditionMarkers.new()
 markers.room=room
 room.add_child(markers)
 await process_frame
 var texture: Texture2D=markers.merchant_sprite.texture
 check(texture is AtlasTexture and texture.atlas==ExpeditionMarkers.MERCHANT_ART,"merchant uses the shared squirrel Pip sprite from the animal cast")
 check(ExpeditionMarkers.MERCHANT_ART==AnimalCast.SHEET and texture==AnimalCast.icon("pip"),"the identity source and cached icon are shared by story and field")
 check(Rect2(Vector2.ZERO,ExpeditionMarkers.MERCHANT_ART.get_size()).encloses(ExpeditionMarkers.MERCHANT_REGION) and Rect2(Vector2.ZERO,ExpeditionMarkers.MERCHANT_ART.get_size()).encloses(ExpeditionMarkers.MERCHANT_PORTRAIT_REGION),"full-body and shop portrait crops stay inside the same identity sheet")
 check(markers.gathering is ShopGathering and markers.gathering.get_child_count()==5,"the central market uses two animal friends and three bounded tea-steam lines")
 var story: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/story.json"))
 for index in range(8):
  var is_shop := index in [3,6]
  room.run.stage_index=index
  room.stage_def={"name":"Pip’s Picnic" if index==3 else "The Last Loose End" if index==6 else "Combat","kind":"shop" if is_shop else "combat"}
  room.exit_open=is_shop
  markers.update_visuals()
  var snapshot := markers.merchant_snapshot()
  check(bool(snapshot.visible)==is_shop,"area%02d shows Pip only when its real shop is present" % (index+1))
  if not is_shop: continue
  check(snapshot.id=="pip" and snapshot.species=="squirrel" and str(story.chapters[index].get("merchant_id",""))==snapshot.id and str(story.chapters[index].get("merchant_species",""))==snapshot.species,"area%02d story and actual merchant agree on squirrel Pip" % (index+1))
  check(snapshot.anchor==Vector2(640,315),"area%02d retains its existing shop interaction point" % (index+1))
  var feet: Vector2=markers.merchant_root.global_position
  markers._process(0.4)
  check(markers.merchant_root.global_position.is_equal_approx(feet) and absf(markers.merchant_root.scale.y-1.0)<=0.0031,"area%02d breathing leaves both feet anchored with a bounded cape motion" % (index+1))
  var time: float=markers.merchant_time
  var pose: Vector2=markers.merchant_root.scale
  room.state="shop"
  markers._process(1.0)
  check(is_equal_approx(markers.merchant_time,time) and markers.merchant_root.scale==pose,"area%02d trading pauses merchant idle motion" % (index+1))
  room.state="playing"
  room.player.position=ExpeditionMarkers.SHOP_POSITION+Vector2(0,99)
  markers.update_visuals()
  check(markers._shop_near and markers.merchant_sprite.texture==texture,"area%02d near-shop feedback reuses the same Pip artwork" % (index+1))
 room.queue_free()
 await process_frame
 print("PIP IDENTITY RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
