extends SceneTree

# Check what the player is promised, against actual locked attacks and their
# contact geometry. These tests do not assert decorative drawing primitives.
class TrainingCat extends WizardCat:
	func _ready() -> void:
		pass

var checks := 0
var failures := 0
var arena := Rect2(100,160,1080,535)
var cat: WizardCat

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func _initialize() -> void:
	call_deferred("run")

func make_enemy(role: String) -> CandleSlime:
	var enemy := CandleSlime.new()
	enemy.role=role
	enemy.position=Vector2(600,410)
	enemy.setup({"hp":40,"speed":83.0,"contact_damage":12,"radius":18.0},cat,arena)
	root.add_child(enemy)
	enemy.set_physics_process(false)
	return enemy

func run() -> void:
	cat=TrainingCat.new()
	cat.setup({"hp":100,"radius":23.0,"invulnerability":0.65},arena)
	root.add_child(cat)
	cat.set_physics_process(false)
	for role in ["candle","broom","bat"]:
		var enemy := make_enemy(role)
		cat.position=enemy.position+Vector2(50,0)
		cat.health.current=100
		cat.invulnerability=0
		check(enemy.get_attack_preview().is_empty(),role+": approaching foe does not imply an active danger lane")
		enemy._physics_process(0.01)
		var first := enemy.get_attack_preview()
		var points: PackedVector2Array=first.path
		check(enemy.phase=="windup" and cat.health.current==100 and is_zero_approx(first.progress),role+": complete footprint appears before any damage, with a fresh countdown")
		check(is_equal_approx(float(first.radius),41.0) and is_equal_approx(AttackTelegraph.path_length(points),enemy.attack_speed()*enemy.attack_duration()),role+": warning includes the player's collider and actual dash travel")
		check(enemy.attack_floor_ink.z_index<0,role+": danger ink stays on the floor below actors")
		var end_world := enemy.position+points[-1]
		cat.position+=Vector2(0,110)
		enemy._physics_process(enemy.warning_duration()*0.5)
		var halfway := enemy.get_attack_preview()
		check(is_equal_approx(halfway.progress,0.5) and halfway.path==points,role+": countdown advances without tracking a sidestepping player or changing the promised range")
		enemy.active=false
		enemy._physics_process(0.3)
		check(is_equal_approx(enemy.get_attack_preview().progress,0.5),role+": pause freezes the countdown")
		enemy.active=true
		enemy._physics_process(enemy.warning_duration()*0.51)
		enemy._physics_process(1.0/60.0)
		var strike := enemy.get_attack_preview()
		var strike_points: PackedVector2Array=strike.path
		check(strike.striking and is_equal_approx(strike.progress,1.0) and (enemy.position+strike_points[-1]).is_equal_approx(end_world),role+": striking lane stays anchored to its floor endpoint instead of sliding ahead of the enemy")
		for tick in range(40): enemy._physics_process(1.0/60.0)
		check(cat.health.current==100 and enemy.get_attack_preview().is_empty(),role+": sidestepping is safe and the lane clears after the attack")
		enemy.phase="windup"
		enemy.phase_time=0.4
		enemy.take_damage(1,Vector2.UP)
		check(enemy.get_attack_preview().is_empty(),role+": interrupted windup immediately withdraws its warning")
		enemy.free()
		# Exercise actual damage rather than merely comparing two formulas.
		for outside in [false,true]:
			enemy=make_enemy(role)
			enemy.scale=Vector2.ONE*1.25
			enemy.phase="attack"
			enemy.phase_time=enemy.attack_duration()
			enemy.attack_origin=enemy.position
			enemy.attack_direction=Vector2.RIGHT
			var preview := enemy.get_attack_preview()
			enemy._refresh_attack_telegraph()
			cat.position=enemy.attack_floor_ink.to_global(Vector2(enemy.attack_speed()/60.0,float(preview.radius)+(0.01 if outside else -0.01)))
			cat.health.current=100
			cat.invulnerability=0
			enemy._physics_process(1.0/60.0)
			check(cat.health.current==(100 if outside else 88),role+(": just outside the visible side edge is safe" if outside else ": just inside the visible side edge takes actual contact damage"))
			enemy.free()
		for tick_size in [1.0/60.0,0.037,0.11]:
			enemy=make_enemy(role)
			enemy.phase="attack"
			enemy.phase_time=enemy.attack_duration()
			enemy.attack_origin=enemy.position
			enemy.attack_direction=Vector2.RIGHT
			var promised: PackedVector2Array=enemy.get_attack_preview().path
			var promised_end := enemy.position+promised[-1]
			cat.position=Vector2(200,200)
			var overshot := false
			while enemy.phase=="attack":
				enemy._physics_process(tick_size)
				overshot=overshot or enemy.position.x>promised_end.x+0.001
			check(not overshot and enemy.position.distance_to(promised_end)<0.001,role+": fractional %.4fs ticks finish exactly at the announced endpoint" % tick_size)
			enemy.free()
	var elite := make_enemy("broom")
	elite.scale=Vector2.ONE*1.25
	elite.phase="windup"
	elite.phase_time=elite.warning_duration()
	elite.attack_direction=Vector2.RIGHT
	elite._refresh_attack_telegraph()
	var elite_preview := elite.get_attack_preview()
	var elite_path: PackedVector2Array=elite_preview.path
	check(elite.attack_floor_ink.global_scale.is_equal_approx(Vector2.ONE),"scaled elite warning keeps an unscaled world-space render transform")
	check(elite.attack_floor_ink.to_global(elite_path[-1]).is_equal_approx(elite.global_position+Vector2(190,0)),"scaled broom's rendered endpoint remains190 collision pixels, not237.5 art-scaled pixels")
	check(is_equal_approx(elite.attack_floor_ink.to_global(Vector2(0,float(elite_preview.radius))).distance_to(elite.global_position),41.0),"scaled elite's rendered side boundary remains the actual41-pixel contact radius")
	elite.free()
	var corner := Rect2(0,0,100,100)
	var direction := Vector2(1,0.5).normalized()
	var path := AttackTelegraph.dash_path(Vector2(80,50),direction,90,corner)
	check(path.size()==3 and path[1].is_equal_approx(Vector2(100,60)) and path[-1].is_equal_approx(Vector2(100,50+direction.y*90)),"diagonal wall approach includes the same corner slide as per-axis movement clamping")
	var all_inside := true
	for point in path: all_inside=all_inside and point==point.clamp(corner.position,corner.end)
	check(all_inside,"wall-clipped warning never projects a centre path outside the playable arena")
	check(AttackTelegraph.point_at(PackedVector2Array([Vector2.ZERO,Vector2(100,0)]),0.5)==Vector2(50,0),"countdown fill traverses distance evenly")
	var boss := PerfectExaminer.new()
	boss.position=Vector2(600,410)
	boss.setup({"hp":180,"speed":60.0,"contact_damage":14,"radius":24.0},cat,arena)
	root.add_child(boss)
	boss.set_physics_process(false)
	boss.phase="windup"
	boss.phase_time=PerfectExaminer.WARNING_TIME
	boss.attack_direction=Vector2.RIGHT
	var beam := boss.get_attack_preview()
	var half_width := float(beam.radius)
	boss.scale=Vector2.ONE*1.25
	boss._refresh_attack_telegraph()
	check(boss.attack_floor_ink.global_scale.is_equal_approx(Vector2.ONE),"scaled examiner warning retains a unit world-space render transform")
	check(boss.attack_floor_ink.to_global(Vector2(PerfectExaminer.BEAM_LENGTH,0)).is_equal_approx(boss.global_position+Vector2(310,0)),"scaled examiner's rendered beam endpoint matches310-pixel collision length")
	check(is_equal_approx(boss.attack_floor_ink.to_global(Vector2(150,half_width)).y-boss.global_position.y,35.05),"scaled examiner's rendered side boundary matches the actual35.05-pixel collision width")
	check(beam.beam and is_equal_approx(half_width,35.05),"examiner warning includes the actual player-radius collision allowance")
	check(boss._beam_contains(boss.position+Vector2(150,half_width-0.01)) and not boss._beam_contains(boss.position+Vector2(150,half_width+0.01)),"both beam side edges match the visible rectangle exactly")
	check(boss._beam_contains(boss.position+Vector2(310,0)) and not boss._beam_contains(boss.position+Vector2(310.01,0)) and not boss._beam_contains(boss.position+Vector2(-0.01,0)),"beam start and endpoint agree with its real hit test")
	boss.free()
	cat.free()
	await process_frame
	print("TELEGRAPHS RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
