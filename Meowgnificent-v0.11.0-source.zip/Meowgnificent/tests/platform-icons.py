#!/usr/bin/env python3
"""Verify exported native icons match the game's authored ICO/ICNS.
Read-only structural checks on Linux; this does not replace viewing a live
Windows taskbar or macOS Dock icon on the target operating system.
"""
from pathlib import Path
import argparse, hashlib, plistlib, struct, zipfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--windows', type=Path, default=ROOT/'exports/windows/Meowgnificent.exe')
parser.add_argument('--macos', type=Path, default=ROOT/'exports/macos/Meowgnificent.zip')
a = parser.parse_args()

def digest(blob):
    return hashlib.sha256(blob).hexdigest()

png = ROOT/'art/ui/app_icon.png'
ico = (ROOT/'art/ui/app_icon.ico').read_bytes()
icns = (ROOT/'art/ui/app_icon.icns').read_bytes()
assert png.read_bytes().startswith(b'\x89PNG\r\n\x1a\n'), 'Missing game PNG icon'
reserved, kind, count = struct.unpack_from('<HHH', ico)
assert reserved == 0 and kind == 1 and count >= 4, 'Expected a multi-size Windows ICO'
source_payloads = {}
source_sizes = set()
for i in range(count):
    width, height, colors, reserved, planes, depth, size, offset = struct.unpack_from('<BBBBHHII', ico, 6+i*16)
    width, height = width or 256, height or 256
    assert offset+size <= len(ico)
    source_sizes.add((width, height))
    source_payloads[digest(ico[offset:offset+size])] = (width, height)
assert {(16,16), (32,32), (48,48), (256,256)} <= source_sizes
assert icns[:4] == b'icns' and struct.unpack_from('>I', icns, 4)[0] == len(icns), 'Invalid game ICNS'

exe = a.windows.read_bytes()
assert exe[:2] == b'MZ'
pe = struct.unpack_from('<I', exe, 0x3c)[0]
assert exe[pe:pe+4] == b'PE\0\0'
section_count = struct.unpack_from('<H', exe, pe+6)[0]
optional_size = struct.unpack_from('<H', exe, pe+20)[0]
optional = pe+24
magic = struct.unpack_from('<H', exe, optional)[0]
assert magic in {0x10b, 0x20b}
directories = optional+(112 if magic == 0x20b else 96)
resource_rva, resource_size = struct.unpack_from('<II', exe, directories+8*2)
assert resource_rva and resource_size, 'Windows executable has no native icon resource tree'
sections = []
for i in range(section_count):
    pos = optional+optional_size+i*40
    virtual_size, virtual_address, raw_size, raw_start = struct.unpack_from('<IIII', exe, pos+8)
    sections.append((virtual_address, max(virtual_size, raw_size), raw_start))
def at_rva(rva):
    for start, length, raw in sections:
        if start <= rva < start+length: return raw+rva-start
    raise AssertionError('PE resource RVA is outside a section')
resource_base = at_rva(resource_rva)
resources = {}
def walk(relative, path=()):
    pos = resource_base+relative
    named, numbered = struct.unpack_from('<HH', exe, pos+12)
    for i in range(named+numbered):
        name, child = struct.unpack_from('<II', exe, pos+16+i*8)
        key = name if not name & 0x80000000 else 'named'
        if child & 0x80000000:
            walk(child & 0x7fffffff, path+(key,))
        else:
            rva, size, _, _ = struct.unpack_from('<IIII', exe, resource_base+child)
            begin = at_rva(rva)
            resources[path+(key,)] = exe[begin:begin+size]
walk(0)
icon_payloads = {key[1]: value for key, value in resources.items() if key[0] == 3}
groups = [value for key, value in resources.items() if key[0] == 14]
assert icon_payloads and groups, 'No Windows application icon/group resources'
matched = set()
for group in groups:
    _, group_type, group_count = struct.unpack_from('<HHH', group)
    assert group_type == 1
    for i in range(group_count):
        width, height, colors, reserved, planes, depth, length, icon_id = struct.unpack_from('<BBBBHHIH', group, 6+i*14)
        payload = icon_payloads.get(icon_id, b'')
        assert len(payload) == length
        if digest(payload) in source_payloads:
            matched.add(source_payloads[digest(payload)])
# Godot embeds its six supported Windows sizes; a24px source entry is
# available to runtime window loading but is not a PE export size.
required_sizes = {(16,16), (32,32), (48,48), (64,64), (128,128), (256,256)}
assert required_sizes <= matched, f'Windows native icon differs from game ICO; matched only {sorted(matched)}'
assert all(digest(blob) in source_payloads for blob in icon_payloads.values()), 'Unexpected engine/default icon payload remains in the executable'
print(f'PASS: Windows PE application icons match authored game ICO at {len(matched)} sizes')

with zipfile.ZipFile(a.macos) as app:
    plist_paths = [n for n in app.namelist() if n.endswith('.app/Contents/Info.plist')]
    assert len(plist_paths) == 1
    base = plist_paths[0].removesuffix('Info.plist')
    info = plistlib.loads(app.read(plist_paths[0]))
    icon_name = info.get('CFBundleIconFile', '')
    assert icon_name, 'Mac app has no configured bundle icon'
    if not icon_name.endswith('.icns'): icon_name += '.icns'
    actual = app.read(base+'Resources/'+icon_name)
    assert actual == icns, 'Mac bundle icon differs from authored game ICNS'
print('PASS: Mac bundle references and contains the authored game ICNS')

project = (ROOT/'project.godot').read_text()
assert 'config/icon="res://art/ui/app_icon.png"' in project
assert 'config/windows_native_icon="res://art/ui/app_icon.ico"' in project
presets = (ROOT/'export_presets.cfg').read_text()
windows = presets.split('[preset.0.options]',1)[1].split('[preset.1]',1)[0]
macos = presets.split('[preset.3.options]',1)[1]
assert 'application/icon="res://art/ui/app_icon.ico"' in windows
assert 'application/icon="res://art/ui/app_icon.icns"' in macos
print('PASS: project/window, Windows export and Mac export icon configuration uses the game assets')
print('PLATFORM ICONS RESULT: 3 checks, 0 failures')
