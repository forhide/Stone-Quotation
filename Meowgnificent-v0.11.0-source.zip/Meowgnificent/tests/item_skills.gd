extends SceneTree

# Real room/combat objects with manually stepped physics: these checks exercise
# item ownership, damage, state cleanup and the one shared action cooldown.
const WEAPONS := {
 "practice_wand":"spark_burst", "crooked_ash_wand":"ember_ring",
 "cinderfork_wand":"cinder_fan", "apprentice_thesis":"margin_burst",
 "frost_whisker_wand":"frost_wave", "hopscotch_wand":"blink_burst",
 "pip_feather_staff":"chicken_dash", "moss_bud_staff":"vine_snare",
 "bloop_bottle_wand":"potion_bomb", "thunder_spoon":"thunder_stamp",
 "bubble_teapot":"bubble_guard", "comet_crayon":"comet_shower"
}
var checks := 0
var failures := 0
var room
var controller
var emitted: Array[Dictionary] = []
var previous_profile := ""
var previous_skip := ""
var profile_path := ""

func check(ok: bool, message: String) -> void:
 checks += 1
 if ok: print("PASS: "+message)
 else:
  failures += 1
  push_error("FAIL: "+message)

func frames(count: int=2) -> void:
 for i in range(count):
  await physics_frame
  await process_frame

func _initialize() -> void:
 call_deferred("run")

func fixture() -> void:
 previous_profile=OS.get_environment("MEOW_PROFILE_PATH")
 previous_skip=OS.get_environment("MEOW_SKIP_STORY")
 profile_path="/tmp/meow-item-skills-%d.json" % OS.get_process_id()
 OS.set_environment("MEOW_PROFILE_PATH",profile_path)
 OS.set_environment("MEOW_SKIP_STORY","1")
 change_scene_to_file("res://scenes/main.tscn")
 await frames(5)
 room=current_scene
 room.begin_or_restart()
 room.set_process(false)
 room.set_physics_process(false)
 room.player.set_physics_process(false)
 room.spells.set_physics_process(false)
 var script: Script=load("res://scripts/spells/item_skill_controller.gd")
 for child in room.get_children():
  if child.get_script()==script: controller=child
 if controller==null:
  controller=script.new()
  controller.room=room
  controller.player=room.player
  room.add_child(controller)
 controller.set_physics_process(false)
 controller.skill_emitted.connect(func(outcome: String,point: Vector2): emitted.append({"outcome":outcome,"point":point}))
 for prop in room.props:
  if is_instance_valid(prop): prop.queue_free()
 room.props.clear()
 await fresh()

func fresh() -> void:
 controller.clear_transients()
 for effect in room.projectiles.get_children(): effect.queue_free()
 for enemy in room.enemies:
  if is_instance_valid(enemy): enemy.queue_free()
 room.enemies.clear()
 await frames(2)
 controller.reset()
 controller.input_blocked_until_release=false
 room.state="playing"
 room.exit_open=false
 room.player.active=true
 room.player.position=Vector2(500,430)
 room.player.velocity=Vector2.ZERO
 room.player.recoil=Vector2.ZERO
 room.player.roll_time=0
 room.player.roll_cooldown=0
 room.player.invulnerability=0
 room.player.cast_prepare=0
 room.player.health.maximum=1000
 room.player.health.current=1000
 room.spells.pending=false
 room.run.inventory.clear()
 room.run.equipment={"wand":"","collar":"","charm":""}
 room.effects.clear()
 room.fires.clear()
 emitted.clear()
 if InputMap.has_action("special_skill"): Input.action_release("special_skill")

func equip(weapon: String) -> void:
 if not room.run.inventory.has(weapon): room.run.add_item(weapon)
 room.run.equip_item(weapon)

func enemy_at(point: Vector2,boss: bool=false) -> CandleSlime:
 var foe: CandleSlime=PerfectExaminer.new() if boss else CandleSlime.new()
 foe.position=point
 foe.setup({"hp":1000,"speed":83.0,"contact_damage":12,"radius":18.0},room.player,room.bounds)
 room.actors.add_child(foe)
 foe.set_physics_process(false)
 foe.active=true
 room.enemies.append(foe)
 return foe

func tick(seconds: float, step: float=1.0/60.0, advance_player: bool=false) -> void:
 var remaining := seconds
 while remaining>0.0001:
  var dt := minf(step,remaining)
  if advance_player and room.state=="playing" and room.player.active: room.player._physics_process(dt)
  controller._physics_process(dt)
  for effect in room.projectiles.get_children():
   effect.set_physics_process(false)
   if not effect.is_queued_for_deletion() and effect.can_process() and effect.has_method("_physics_process"):
    effect._physics_process(dt)
  remaining-=dt

func living_effects() -> Array[Node]:
 var result: Array[Node]=[]
 for effect in room.projectiles.get_children():
  if not effect.is_queued_for_deletion(): result.append(effect)
 return result

func run() -> void:
 await fixture()
 # More detailed mechanic assertions are appended after the controller's
 # concrete effect timing is available; ownership/cooldown checks are stable.
 var definitions := {}
 for weapon: String in WEAPONS:
  var info: Dictionary=controller.definition_for_item(weapon)
  definitions[WEAPONS[weapon]]=info
  check(not info.is_empty() and str(room.run.catalog[weapon].skill_id)==WEAPONS[weapon],weapon+": catalog links to its actual special-skill definition")
  check(float(info.get("cooldown",0))>0 and not str(info.get("name","")).is_empty() and not str(info.get("description","")).is_empty(),weapon+": skill has player-facing identity and a positive recovery time")
 check(definitions.size()==12,"twelve weapon choices provide twelve distinct skill definitions")
 check(controller.current_skill_id().is_empty() and not controller.cast(Vector2.RIGHT),"a fresh unequipped run cannot invoke an item it does not own")
 room.run.equipment.wand="crooked_ash_wand"
 check(controller.current_skill_id().is_empty() and not controller.cast(Vector2.RIGHT),"spoofing the equipment ID without an owned copy does not unlock its skill")
 room.run.equipment.wand=""
 equip("practice_wand")
 check(controller.current_skill_id()=="spark_burst" and controller.skill_info()==controller.skill_definition("spark_burst"),"only the equipped owned weapon selects the one active skill")
 controller.resolver.forced="success"
 check(controller.cast(Vector2.RIGHT) and controller.cooldown_remaining>0 and emitted.size()==1,"a deliberate skill activation emits once and starts the shared cooldown")
 var shared: float=controller.cooldown_remaining
 equip("crooked_ash_wand")
 check(controller.current_skill_id()=="ember_ring" and is_equal_approx(controller.cooldown_remaining,shared) and not controller.cast(Vector2.RIGHT),"swapping weapons changes the selected skill but cannot bypass its shared cooldown")
 controller.clear_transients()
 check(is_equal_approx(controller.cooldown_remaining,shared),"stage/transient cleanup preserves the shared cooldown")
 room.run.unequip_slot("wand")
 check(not controller.cast(Vector2.RIGHT),"unequipping the weapon immediately removes its special action")
 await fresh()
 equip("practice_wand")
 for state: String in ["intro","paused","inventory","shop","settings","story","transition","defeated","cleared"]:
  room.state=state
  controller.cooldown_remaining=3.0
  controller._physics_process(0.4)
  check(is_equal_approx(controller.cooldown_remaining,3.0) and not controller.cast(Vector2.RIGHT),state+": menus/story/inactive run freeze recovery and reject skill casts")
 room.state="playing"
 controller.cooldown_remaining=0
 room.player.active=false
 check(not controller.cast(Vector2.RIGHT),"inactive player cannot activate a skill even when room state is playing")
 room.player.active=true
 room.player.roll_time=0.2
 check(not controller.cast(Vector2.RIGHT),"rolling rejects a conflicting item-skill action")
 room.player.roll_time=0
 room.spells.pending=true
 check(not controller.cast(Vector2.RIGHT),"an already-preparing normal spell does not get overwritten by a skill")
 room.spells.pending=false
 room.exit_open=true
 check(not controller.cast(Vector2.RIGHT),"cleared-area input cannot queue a delayed attack for the next stage")
 await mechanics()
 await finish()

func finish() -> void:
 controller.clear_transients()
 current_scene.queue_free()
 await frames(2)
 if previous_profile.is_empty(): OS.unset_environment("MEOW_PROFILE_PATH")
 else: OS.set_environment("MEOW_PROFILE_PATH",previous_profile)
 if previous_skip.is_empty(): OS.unset_environment("MEOW_SKIP_STORY")
 else: OS.set_environment("MEOW_SKIP_STORY",previous_skip)
 for suffix: String in ["",".tmp",".bak"]:
  if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
 print("ITEM SKILLS RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)

func force_skill(weapon: String, outcome: String="success", direction: Vector2=Vector2.RIGHT) -> bool:
 equip(weapon)
 controller.resolver.forced=outcome
 return controller.cast(direction)

func mechanics() -> void:
 # Each weapon is activated against real enemy bodies. Defensive/movement
 # cases also have precise dedicated checks below instead of treating a VFX
 # spawn or a catalog entry as proof that the skill works.
 for weapon: String in WEAPONS:
  await fresh()
  var victims: Array[CandleSlime]=[]
  for offset in [35,74,125,175,225,300]: victims.append(enemy_at(room.player.position+Vector2(offset,0)))
  var before_position: Vector2=room.player.position
  var fired := force_skill(weapon)
  var protected: bool=room.player.invulnerability>1.0
  var moved: bool=room.player.position.distance_to(before_position)>40
  tick(3.8)
  var dealt := false
  for victim in victims: dealt=dealt or victim.health.current<1000
  check(fired and (dealt or protected or moved),weapon+": real activation damages a target, moves the cat or provides an actual guard")
  check(living_effects().is_empty(),weapon+": bounded skill actors expire rather than accumulating in the room")

 await fresh()
 var spark_target := enemy_at(room.player.position+Vector2(125,0))
 force_skill("practice_wand")
 check(spark_target.health.current==976,"Pocket Spark damages the aimed point immediately with its configured24 damage")
 await fresh()
 var rear := enemy_at(room.player.position-Vector2(125,0))
 var front := enemy_at(room.player.position+Vector2(125,0))
 force_skill("practice_wand","miscast")
 check(rear.health.current<1000 and front.health.current==1000 and room.player.recoil.length()>0,"miscast spark actually flies to the wrong side and produces recoil rather than doing nothing")

 await fresh()
 var near := enemy_at(room.player.position+Vector2(100,0))
 var far := enemy_at(room.player.position+Vector2(200,0))
 force_skill("crooked_ash_wand")
 check(near.health.current==966 and near.knockback.length()>0 and far.health.current==1000,"Hearth Circle damages and pushes only foes inside its radial footprint")
 await fresh()
 var enlarged := enemy_at(room.player.position+Vector2(145,0))
 force_skill("crooked_ash_wand","overreaction")
 check(enlarged.health.current==946,"overreaction increases both the ring reach and real damage")

 await fresh()
 var fan_victims: Array[CandleSlime]=[]
 for y in [-70,0,70]: fan_victims.append(enemy_at(room.player.position+Vector2(150,y)))
 force_skill("cinderfork_wand")
 var shots: Array[SpellProjectile]=[]
 for node in living_effects():
  if node is SpellProjectile: shots.append(node)
 var distinct := false
 if shots.size()>=2: distinct=shots[0].direction.dot(shots[-1].direction)<0.8
 check(shots.size()==5 and distinct,"Cinder Fan launches five separate fireballs across a real angular spread")
 tick(0.65,0.11)
 check(fan_victims.all(func(foe: CandleSlime): return foe.health.current<1000),"fan projectile substeps hit the centre and both sides even at coarse physics intervals")

 await fresh()
 var page_target := enemy_at(room.player.position+Vector2(74,0))
 var page_far := enemy_at(room.player.position+Vector2(180,0))
 force_skill("apprentice_thesis")
 tick(0.1)
 var after_first: int=page_target.health.current
 tick(0.25)
 check(after_first<1000 and page_target.health.current==after_first,"orbiting pages hit a nearby foe but do not damage it every frame")
 tick(1.0)
 check(page_target.health.current<after_first and page_target.health.current>=930 and page_far.health.current==1000,"pages repeat bounded contact damage while excluding distant foes")
 var orbit= living_effects()[0]
 room.player.position+=Vector2(0,40)
 tick(0.02)
 check(orbit.position.is_equal_approx(room.player.position),"page orbit follows the moving cat instead of remaining at its original cast location")

 await fresh()
 var chilled := enemy_at(room.player.position+Vector2(100,0))
 var side := enemy_at(room.player.position+Vector2(0,100))
 var behind := enemy_at(room.player.position-Vector2(100,0))
 force_skill("frost_whisker_wand")
 check(chilled.health.current==976 and side.health.current==1000 and behind.health.current==1000,"frost uses an aimed cone instead of a generic omnidirectional blast")
 check(chilled.config.speed<30 and chilled.config.speed>0 and chilled.active,"frost slows an actual living enemy without disabling all of its behavior")
 chilled.phase="approach"
 chilled.cooldown=100
 chilled.knockback=Vector2.ZERO
 var first: Vector2=chilled.position
 chilled._physics_process(0.1)
 check(chilled.position.distance_to(first)>2 and chilled.position.distance_to(first)<3,"slowed enemy's real approach movement uses the reduced speed")
 room.set_running(false)
 var slow_speed: float=chilled.config.speed
 var slow_cd: float=controller.cooldown_remaining
 tick(4)
 check(is_equal_approx(chilled.config.speed,slow_speed) and is_equal_approx(controller.cooldown_remaining,slow_cd),"pausing freezes both the frost duration and skill recovery")
 room.set_running(true)
 tick(3)
 check(is_equal_approx(chilled.config.speed,83.0) and controller.status_leases.is_empty(),"frost expiration restores the original enemy speed exactly")

 await fresh()
 var destination := enemy_at(room.player.position+Vector2(175,0))
 var origin: Vector2=room.player.position
 force_skill("hopscotch_wand")
 check(room.player.position.is_equal_approx(origin+Vector2(175,0)) and destination.health.current==974 and room.player.invulnerability>0,"blink moves to a new position, damages at arrival and briefly protects the landing")
 await fresh()
 room.player.position=room.bounds.end-Vector2(25,80)
 force_skill("hopscotch_wand")
 var radius: float=room.player.config.radius
 check(room.player.position==room.player.position.clamp(room.bounds.position+Vector2.ONE*radius,room.bounds.end-Vector2.ONE*radius),"blink clamps its landing to the actual player-radius room boundary")

 await fresh()
 var chicken_first := enemy_at(room.player.position+Vector2(95,0))
 var chicken_second := enemy_at(room.player.position+Vector2(205,0))
 force_skill("pip_feather_staff")
 tick(1.2,0.11)
 check(chicken_first.health.current==968 and chicken_second.health.current==968,"the charging chicken crosses and hits two foes once each without tunnelling")

 await fresh()
 var rooted := enemy_at(room.player.position+Vector2(125,0))
 force_skill("moss_bud_staff")
 check(not rooted.active and rooted.health.current==983,"vine patch immediately roots a foe and applies its first damage")
 tick(1.3)
 check(rooted.health.current<=977 and not rooted.active,"vine field deals repeated damage while holding its target")
 room.set_running(false)
 var root_hp: int=rooted.health.current
 var root_cd: float=controller.cooldown_remaining
 tick(4)
 check(rooted.health.current==root_hp and is_equal_approx(controller.cooldown_remaining,root_cd),"paused vine field does not keep damaging enemies or consuming its recovery")
 room.set_running(true)
 controller._physics_process(0)
 tick(3)
 check(rooted.active and is_equal_approx(rooted.config.speed,83.0) and controller.status_leases.is_empty(),"vine expiration releases the foe and restores its prior movement settings")

 await fresh()
 var bomb_target := enemy_at(room.player.position+Vector2(200,0))
 force_skill("bloop_bottle_wand")
 tick(0.6)
 check(bomb_target.health.current==1000,"potion damage waits for its thrown arc to reach the landing")
 tick(0.25)
 var bomb_hp: int=bomb_target.health.current
 tick(1)
 check(bomb_hp==954 and bomb_target.health.current==bomb_hp,"potion explodes exactly once after landing rather than ticking continuous blast damage")

 await fresh()
 var thunder_targets: Array[CandleSlime]=[]
 for x in [65,145,225]: thunder_targets.append(enemy_at(room.player.position+Vector2(x,0)))
 force_skill("thunder_spoon")
 tick(0.24)
 check(thunder_targets.all(func(foe: CandleSlime): return foe.health.current==1000),"thunder telegraphs its strikes before dealing damage")
 tick(0.04)
 check(thunder_targets[0].health.current==960 and thunder_targets[1].health.current==1000 and thunder_targets[2].health.current==1000,"first thunder strike hits only its first marked point")
 tick(0.22)
 check(thunder_targets[1].health.current==960 and thunder_targets[2].health.current==1000,"second thunder strike arrives later along the aim direction")
 tick(0.22)
 check(thunder_targets[2].health.current==960,"third thunder strike completes the timed line")

 await fresh()
 force_skill("bubble_teapot")
 var protected_hp: int=room.player.health.current
 room.player.take_damage(50,room.player.position+Vector2.RIGHT)
 check(room.player.health.current==protected_hp and room.player.invulnerability>2,"bubble guard blocks real incoming player damage")
 tick(1.0,1.0/60.0,true)
 room.set_running(false)
 var guard_time: float=room.player.invulnerability
 tick(4,1.0/60.0,true)
 check(is_equal_approx(room.player.invulnerability,guard_time),"opening a menu pauses bubble protection instead of spending it offscreen")
 room.set_running(true)
 tick(1.6,1.0/60.0,true)
 room.player.take_damage(25,room.player.position+Vector2.RIGHT)
 check(room.player.health.current==protected_hp-25,"bubble expires and ordinary incoming damage resumes")

 await fresh()
 var comet_target := enemy_at(room.player.position+Vector2(190,0))
 force_skill("comet_crayon")
 tick(0.29)
 check(comet_target.health.current==1000,"comet shower provides a landing warning before its first impact")
 tick(0.06)
 var early_hp: int=comet_target.health.current
 check(early_hp==970,"comets begin with one impact instead of applying all four at once")
 tick(0.7)
 check(comet_target.health.current==880,"four independently timed comets damage a central target four times")

 await fresh()
 var boss := enemy_at(room.player.position+Vector2(60,0),true) as PerfectExaminer
 force_skill("crooked_ash_wand")
 check(boss.health.current==1000 and boss.blocked_spells==1 and boss.barrier_active,"a controlled item skill obeys the Perfect Wizard's prediction barrier")
 tick(12)
 boss.position=room.player.position-Vector2(70,0)
 controller.resolver.forced="miscast"
 controller.cast(Vector2.RIGHT)
 check(boss.health.current<1000 and not boss.barrier_active and boss.window_source=="miscast","an accidental item skill breaks the prediction pattern and opens the real boss barrier")

 await fresh()
 var waiting := enemy_at(room.player.position+Vector2(200,0))
 force_skill("bloop_bottle_wand")
 var cd_before_clear: float=controller.cooldown_remaining
 room.exit_open=true
 tick(2)
 check(waiting.health.current==1000 and living_effects().is_empty(),"an area clear cancels pending potion damage and removes delayed actors")
 check(is_equal_approx(controller.cooldown_remaining,cd_before_clear-2),"cleared-room recovery remains shared while delayed attacks are discarded")

 await fresh()
 var lease_target := enemy_at(room.player.position+Vector2(125,0))
 force_skill("moss_bud_staff")
 var preserved: float=controller.cooldown_remaining
 controller.clear_transients()
 check(lease_target.active and is_equal_approx(lease_target.config.speed,83.0) and controller.status_leases.is_empty() and living_effects().is_empty(),"explicit transient cleanup restores rooted enemies and removes owned effect actors")
 check(is_equal_approx(controller.cooldown_remaining,preserved),"status and actor cleanup cannot refresh the shared cooldown")
 var next_stage: int=room.run.stage_index+1
 room.load_sector(next_stage)
 for foe in room.enemies: foe.set_physics_process(false)
 await frames(2)
 controller._physics_process(0)
 check(is_equal_approx(controller.cooldown_remaining,preserved) and controller.status_leases.is_empty(),"real room transition retains item recovery while old status references are discarded")

 await fresh()
 var bonus_target := enemy_at(room.player.position+Vector2(125,0))
 equip("practice_wand")
 for item in ["thunder_key_collar","clover_leaf"]:
  room.run.add_item(item)
  room.run.equip_item(item)
 controller.resolver.forced="success"
 controller.cast(Vector2.RIGHT)
 check(bonus_target.health.current==952,"collar and charm skill-damage bonuses add to the actual equipped weapon's damage")
 await fresh()
 equip("practice_wand")
 for item in ["bloop_locket_collar","thunder_marble"]:
  room.run.add_item(item)
  room.run.equip_item(item)
 controller.resolver.forced="success"
 controller.cast(Vector2.RIGHT)
 check(is_equal_approx(controller.cooldown_duration,8.0*0.87*0.82),"collar and charm recovery modifiers multiply into the shared skill cooldown")
 await fresh()
 var widened := enemy_at(room.player.position+Vector2(225,0))
 var excluded := enemy_at(room.player.position+Vector2(265,0))
 equip("practice_wand")
 for item in ["comet_medal_collar","comet_stamp"]:
  room.run.add_item(item)
  room.run.equip_item(item)
 controller.resolver.forced="success"
 controller.cast(Vector2.RIGHT)
 check(widened.health.current==976 and excluded.health.current==1000,"area bonuses extend the real aimed burst without damaging foes beyond its new boundary")

 await fresh()
 var freed_target := enemy_at(room.player.position+Vector2(125,0))
 force_skill("moss_bud_staff")
 freed_target.queue_free()
 await frames(2)
 tick(0.05)
 check(controller.status_leases.is_empty(),"status ticking discards a freed foe reference without dereferencing it")
 await fresh()
 var freed_during_clear := enemy_at(room.player.position+Vector2(125,0))
 force_skill("moss_bud_staff")
 freed_during_clear.queue_free()
 await frames(2)
 controller.clear_transients()
 check(controller.status_leases.is_empty() and living_effects().is_empty(),"stage cleanup safely removes a lease whose enemy has already been freed")
 await fresh()
 var sleeping_foe := enemy_at(room.player.position+Vector2(125,0))
 sleeping_foe.active=false
 force_skill("moss_bud_staff")
 tick(3.0)
 check(not sleeping_foe.active and is_equal_approx(sleeping_foe.config.speed,83.0),"root expiration preserves an enemy that was already inactive before the cast")

 await fresh()
 var resume_foe := enemy_at(room.player.position+Vector2(15,0))
 force_skill("moss_bud_staff")
 resume_foe.phase="attack"
 resume_foe.phase_time=0.2
 resume_foe.attack_direction=Vector2.LEFT
 room.set_running(false)
 room.set_running(true)
 resume_foe.set_physics_process(true)
 controller.set_physics_process(true)
 await frames(2)
 controller.set_physics_process(false)
 resume_foe.set_physics_process(false)
 check(room.player.health.current==1000 and not resume_foe.active,"resuming a menu reapplies a root before the foe gets even one attack physics tick")

 await fresh()
 room.player.invulnerability=0.6
 force_skill("bubble_teapot")
 tick(0.2,1.0/60.0,true)
 controller.clear_transients()
 check(is_equal_approx(room.player.invulnerability,0.4),"clearing a guard preserves the remainder of pre-existing hit protection")

 await fresh()
 equip("practice_wand")
 if not InputMap.has_action("special_skill"): InputMap.add_action("special_skill")
 controller.input_blocked_until_release=false
 controller.resolver.forced="success"
 Input.action_press("special_skill")
 controller._physics_process(0.01)
 check(emitted.size()==1,"one new special-action press casts exactly once")
 await frames(1)
 tick(10)
 check(emitted.size()==1 and controller.cooldown_remaining==0,"holding the special-action key does not auto-cast again when recovery ends")
 Input.action_release("special_skill")
 await frames(1)
 Input.action_press("special_skill")
 controller.resolver.forced="success"
 controller._physics_process(0.01)
 check(emitted.size()==2,"a second deliberate press after release can activate the ready skill")
 var retained_valid := true
 for effect in controller.spawned_effects: retained_valid=retained_valid and is_instance_valid(effect)
 check(retained_valid,"recasting after expired effects are freed retains only valid actor references")
 Input.action_release("special_skill")
