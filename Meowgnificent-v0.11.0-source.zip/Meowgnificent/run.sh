#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-$PROJECT_DIR/.local/cache}"
export XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$PROJECT_DIR/.local/config}"
export XDG_DATA_HOME="${XDG_DATA_HOME:-$PROJECT_DIR/.local/data}"
mkdir -p "$XDG_CACHE_HOME" "$XDG_CONFIG_HOME" "$XDG_DATA_HOME"
exec godot --path "$PROJECT_DIR" "$@"
