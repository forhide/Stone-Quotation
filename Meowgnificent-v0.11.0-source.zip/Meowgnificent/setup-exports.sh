#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export MEOW_PROJECT_DIR="$PROJECT_DIR"
python3 - <<'PY'
import hashlib, os, pathlib, urllib.request, zipfile
root=pathlib.Path(os.environ['MEOW_PROJECT_DIR'])
archive=root/'.local/downloads/Godot_v4.6.3-stable_export_templates.tpz'
target=pathlib.Path(os.environ.get('XDG_DATA_HOME',str(root/'.local/data')))/'godot/export_templates/4.6.3.stable'
checks={
 'macos.zip':'808f190c2c2e58509f3d4bddd450bc39690e9155a195cfc88959846cc5ceaf7a959257045257b09950e11b10ae7968365ac6b507f2674f5248ff5a900fe82d8b',
 'linux_release.x86_64':'e56a29c6cf4a794147f2d3bac8283e41095b8d9a96a4d132693a60df42de1c01ff1c5f9b24343cb464fd272349773b03c8fe83814a5d3467880ac0acc1282dbd',
 'windows_release_x86_64.exe':'2e558aa8812d0acac9dea1895f01883ea9b84e305716d56e42e817491b9de07811ee0c393a7e4d042b363a1ac4d289898b0c9d0bc50ac3c958693cc11057d3c5',
 'web_nothreads_release.zip':'be2efc7d6c158d04d09e949cd7756dfcef40e9bf0ada5f73fbdc7cc375b6a48c71da423c855c0cf14f5f515e4f78ed5d658870a64cc6b89eab350c8d9b119330',
 'version.txt':'fc471a2fde147ad663394367b2aa84c7084399d6ab5542b8911f72c8b33ade8d6b39c26982933d526951142485304208d47eef2807ed71e14b8c981a85d63a7b'
}
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha512').hexdigest()
if all((target/n).is_file() and digest(target/n)==h for n,h in checks.items()):
 print('Export templates verified; reusing Godot 4.6.3 templates.')
else:
 archive.parent.mkdir(parents=True,exist_ok=True)
 expected='da606b61c10157844f8300172df374472665f95015495cb1a7cd132c40ede404faa96cc1016a4b9662db9909ddea69632c4948b2cd11163438dad4808881fb68'
 if not archive.exists():
  print('Downloading official Godot 4.6.3 export templates (1.2 GB).',flush=True)
  temporary=archive.with_suffix('.download')
  urllib.request.urlretrieve('https://github.com/godotengine/godot/releases/download/4.6.3-stable/'+archive.name,temporary)
  if digest(temporary)!=expected:raise SystemExit('Template archive SHA512 mismatch; refusing installation.')
  temporary.replace(archive)
 if digest(archive)!=expected:raise SystemExit('Cached template SHA512 mismatch; refusing installation.')
 target.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(archive) as z:
  for name,expected_hash in checks.items():
   data=z.read('templates/'+name)
   if hashlib.sha512(data).hexdigest()!=expected_hash:raise SystemExit('Template file checksum mismatch: '+name)
   (target/name).write_bytes(data)
   (target/name).chmod(0o755)
 print('Installed verified templates:',target)
PY
