# Download delivery security notice

The anonymous temporary-host links previously supplied in this chat are withdrawn.
The user reported being instructed to run a CMD command that downloads an unrelated
MSI installer and invokes msiexec with silent installation flags. This is consistent
with a ClickFix-style social engineering attack. Do not follow that instruction.

The game distribution is a ZIP containing the Godot-based executable and notices.
It does not require an MSI installer, CMD/PowerShell download commands, or disabling
security checks. The reported command is not part of the game or its launch process.

The assistant previously verified downloaded ZIP bytes against local SHA256 hashes.
That was an integrity check only; it did not establish that the hosting landing page,
advertising, redirects or user download experience was safe. Describing that route
as a verified download without checking those aspects was inadequate.

Preserve the local source, tested binaries, checksums and incident metadata. Do not
reuse the temporary-host URLs or upload replacement files to another anonymous host.
The user confirmed they did not execute the command. No request was made to the
reported installer endpoint and the payload was not downloaded or executed.

Defanged payload endpoint from user report: hxxp://392073673/61844
Decoded host (static conversion only): 23[.]94[.]145[.]201
Reported local payload filename: S928.msi

If execution occurred: disconnect the affected Windows PC from the network and run
Microsoft Defender Offline scan. Use a separate trusted device for account/session
recovery if needed; a clean scan alone does not prove that credentials were not stolen.
