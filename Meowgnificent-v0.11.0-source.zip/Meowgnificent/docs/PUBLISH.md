# 실행 파일 배포

현재 대상은 Windows x86_64, Linux x86_64, macOS (Apple Silicon 지원 Universal), 단일 스레드 Web 빌드입니다. Windows/Linux 실행 파일에는 PCK가 내장되고, Mac은 .app 내부에 포함되어 Godot 설치 없이 실행할 수 있습니다. 사용자는 압축을 풀어 실행하면 되며 MSI 설치나 CMD 다운로드 명령은 필요하지 않습니다.

## 재빌드

Godot 4.6.3, Python 3.12+, curl, rg가 필요합니다.

```bash
./build.sh
python3 package.py
```

공식 export template의 SHA512를 검증하고 기능·회귀·사고 상호작용 검사를 실행한 뒤 내보냅니다. 배포 ZIP에는 플랫폼 안내문과 엔진 라이선스/고지가 포함됩니다.

## 전달 방식

사용자가 제시한 Style Lab 방식에 따라 `forhide/Stone-Quotation`의 전용 브랜치 `meowgnificent-downloads-v<버전>`에 ZIP과 SHA-256 목록을 게시합니다. 기존 앱 브랜치는 수정하지 않습니다. GitHub raw 직링크에서 모든 ZIP을 다시 내려받아 체크섬과 압축 무결성을 확인합니다.

사용자가 요청한 범위는 다운로드 가능한 실행 파일까지이며 별도 게임 웹사이트는 게시하지 않습니다. Web ZIP은 정적 서버에 올리는 용도입니다. HTML 파일을 직접 여는 방식은 지원하지 않습니다.

익명 임시 파일 호스트의 이전 링크는 철회되었습니다. 상세 기록은 `DOWNLOAD-SECURITY-NOTICE.md`를 참고하세요.

## 검증 한계

Windows 실행 검사는 Wine 호환 환경에서 수행하며 실제 Windows PC 검사와 구분합니다. Windows EXE는 코드 서명이 없습니다. PC 키보드·마우스가 대상이며 모바일, 게임패드는 이번 배포 범위가 아닙니다. macOS는 임시(ad-hoc) 서명된 Apple Silicon 앱이며 실제 Mac 실행 및 Apple 공증은 미실시입니다. 버전별 검사 결과는 해당 릴리스 문서에 기록합니다.
