# Vertical Slice Scope

## Must Have
- 1 playable Chonky Wizard Cat
- 1 test biome
- 6–8 rooms
- room transition flow
- 3 enemy types
- 1 elite
- 1 boss
- 4 spells
- success/miscast/overreaction system
- food pickup system
- Chonk growth
- body roll
- belly slam
- between-room reward choice
- HUD
- start screen
- game-over screen
- victory screen
- basic save/unlock support

## Nice to Have
- hat physics
- body jiggle
- controller support
- short funny event popups
- hit-stop
- screen shake
- replay-friendly visual events

## Not Required Yet
- multiplayer
- full campaign
- voice acting
- multiple biomes
- deep inventory
- advanced procedural generation
