# HD Pastel Storybook 2D — final art direction

The user’s final direction supersedes the earlier pixel-art experiment.

High-resolution illustrated 2D; no visible pixel grid or retro pixel aesthetic. Soft pastel colors, clean hand-drawn silhouettes, rounded SD characters, whimsical fantasy environments, a slightly top-down 3/4 view and cozy storybook feeling. Zwei!! supplies mood/composition, Fantasy Life supplies broad-audience proportions, and WitchSpring R supplies soft color/light polish. Create original artwork rather than copying game assets. Avoid fully3D/toy rendering and excessive anime styling.

Meowmalade is a very chubby orange cat wearing an oversized wizard hat, with a round torso, extremely short legs, minimal clothing and mostly neutral/deadpan face. The body is the identity. Approximate head40–45%, body55–60%; no complex robes, armor, belts or straps. Paw casting fits the opening. Small bell collar preserves the original wizard-cat reference.

Animation: subtle breathing/belly motion and delayed hat-tip sway; waddling walk with side-to-side motion, very short foot movement and belly bounce; exaggerated run/roll momentum with opposing hat motion. Combine efficient 2D deformation and expressive drawn key poses. Hand-drawn spells and impacts should support comic physical accidents.

Narrative reference: MEOWMALADE-STORYBOARD.md. Meowmalade has extreme magical power and poor control; accidents create possibilities. Arcana Academy, detention storage, The Library, The Forbidden Garden, Pip/Moss/Bloop and The Perfect Grimoire form the narrative spine.
