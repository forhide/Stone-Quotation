# Meowgnificent the wizard cat Codex Handoff Package

Recommended order:

1. Give Codex `10_CODEX_MASTER_PROMPT.txt`
2. Keep the full package available as project context
3. After Phase 1 works, give Codex `11_CODEX_CONTINUATION_PROMPT.txt`
4. Use the numbered markdown files as design authority when implementation questions arise

Most important design constraints:
- Chonky Wizard Cat appearance is fixed
- do not over-design the cat
- wizard hat + fat orange cat silhouette must remain immediately readable
- clumsy magic is the main gameplay hook
- miscasts must produce gameplay, not just failure
- Chonk level must affect both visuals and mechanics

Suggested first milestone:
A single room where the cat can move, cast Fireball, randomly miscast, fight one enemy, eat one food pickup, and become visibly chonkier.
