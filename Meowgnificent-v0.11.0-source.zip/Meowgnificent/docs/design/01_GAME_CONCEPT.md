# Meowgnificent the wizard cat — Game Concept

## Elevator Pitch
A fat orange wizard cat fights through magical environments using spells that can work normally, fail spectacularly, or become absurdly overpowered.

## Core Pillars
1. Clumsy magic is the main mechanic.
2. Chonkiness directly affects gameplay.
3. Miscasts must often remain useful.
4. Every run should produce short, funny, shareable moments.
5. The cat itself stays visually simple and instantly readable.

## Tone
- cute
- absurd
- dry comedy
- magical chaos
- slightly deadpan
- not overly cartoony in personality

## Core Loop
1. Enter a room
2. Fight enemies with unstable magic
3. Survive the consequences of your own spells
4. Collect food, relics, and upgrades
5. Grow stronger and/or chonkier
6. Reach boss
7. Win or fail
8. Unlock modifiers and relics

## Main Hook
Every spell resolves into one of three outcomes:
- Success
- Miscast
- Overreaction

The player's skill comes from adapting quickly and exploiting the outcome.

## Example
Fireball:
- Success: normal forward projectile
- Miscast: fires sideways, drops at feet, or ignites nearby objects
- Overreaction: enormous explosive fireball

Teleport:
- Success: short controlled blink
- Miscast: awkward random displacement or wall collision
- Overreaction: chain blink + shockwave
