# Initial Balance Seed

## Player
HP: 100
Move Speed: 220
Dash Cooldown: 1.2 sec

Spell Outcome Base:
Success: 70
Miscast: 20
Overreaction: 10

## Chonk
Chonk 0:
- baseline

Chonk 1:
- HP +10%
- speed -3%
- body damage +10%

Chonk 2:
- HP +20%
- speed -7%
- body damage +25%

Chonk 3:
- HP +35%
- speed -12%
- body damage +45%

## Fireball
Cooldown: 0.8 sec
Success Damage: 20
Miscast Damage: 8–15 depending on variant
Overreaction Damage: 45 AoE

## Ice Burst
Cooldown: 1.4 sec
Success Damage: 12 + slow
Overreaction Damage: 18 AoE + freeze

## Blink
Cooldown: 3.0 sec

## Summon Puff
Cooldown: 6.0 sec
Summon Duration: 8 sec
