# Main Character Specification — Chonky Wizard Cat

## Visual Identity
The character design is fixed around the established Chonky Wizard Cat look.

### Required Features
- orange / cheese-colored fur
- very round torso
- large belly
- short legs
- compact neck
- round head
- large wizard hat
- simple face
- neutral or mildly confused expression
- no complex costume layers

### Costume Rule
The wizard hat is the primary fantasy signifier.
Avoid turning the character into a humanoid wizard.
Avoid heavy robes, armor, boots, belts, pauldrons, or elaborate accessories.

Optional:
- tiny cape
- simple wand
- small pouch

## Animation Personality
Movement should feel heavy and slightly delayed.

Required animation ideas:
- waddling walk/run
- belly jiggle
- hat flop
- tiny jump with heavy landing
- exaggerated casting pose
- deadpan recovery after spell failure
- rolling body attack
- belly slam
- sitting idle
- confused stare after miscast

## Expression Set
Prototype minimum:
1. Neutral
2. Confused
3. Slightly annoyed
4. Focused
5. Startled
6. Sleepy / exhausted

## Character Rule
The cat should remain emotionally understated even when the world is exploding around it.
That contrast is the comedy.
