# Godot 4.x Technical Specification

## Suggested Structure
project/
  scenes/
    player/
    enemies/
    boss/
    rooms/
    ui/
    effects/
  scripts/
    player/
    combat/
    spells/
    ai/
    systems/
    ui/
  data/
    spells.json
    enemies.json
    relics.json
    balance.json
  art/
    placeholder/
  audio/
    placeholder/

## Core Systems
1. Player controller
2. Spell controller
3. Spell outcome resolver
4. Projectile base
5. Enemy base AI
6. Damage/health system
7. Food/Chonk system
8. Roll/body attack system
9. Room flow manager
10. Reward selection
11. Save/unlock manager
12. HUD/event feedback

## Data-Driven Requirements
At minimum spells should expose:
- id
- display_name
- cooldown
- cast_time
- success_weight
- miscast_weight
- overreaction_weight
- success_behavior
- miscast_behavior
- overreaction_behavior
- damage values
- VFX hook
- SFX hook

## Coding Rules
- modular scripts
- typed GDScript where practical
- minimal hardcoding
- gameplay tuning values moved into Resources or JSON
- comments only where logic is non-obvious
- placeholder assets must be easy to replace
