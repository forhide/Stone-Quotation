# Enemies and Boss

## Candle Slime
Role: basic pressure enemy
- slow chase
- leaves small fire hazard
- low HP

## Library Bat
Role: fast harassment enemy
- swooping attack
- low HP
- forces player repositioning

## Broom Knight
Role: armored charger
- short windup
- straight charge
- medium HP

## Elite — Arcane Vacuum
Role: physics disruptor
- periodically pulls player and projectiles
- can redirect spell chaos

## Boss — Professor Catastrophus
Personality:
- serious
- controlled
- highly competent wizard
- total contrast with protagonist

Attack Ideas:
- magic circles
- beam sweep
- summoned minions
- area denial

Boss Design Principle:
The easiest or funniest strategies should involve exploiting magical accidents rather than perfect conventional play.
