# Art Direction

## Main Character
Preserve the Chonky Wizard Cat identity:
- very round orange cat
- short legs
- big wizard hat
- minimal clothing
- deadpan face

## Visual Style
Recommended:
- 2.5D
- 3D character and environment
- slightly elevated camera
- readable silhouettes
- soft fantasy lighting
- exaggerated VFX

## Character Motion
Key selling point:
- belly jiggle
- hat flop
- short-legged waddling
- heavy landings
- delayed recovery

## Environment
Magic school / magical dungeon aesthetic.
Avoid grim-dark presentation.
Use readable whimsical props:
- books
- candles
- potion shelves
- enchanted furniture
- moving brooms
- glowing runes

## VFX
Success:
- clean, controlled effect

Miscast:
- asymmetric, awkward, messy effect

Overreaction:
- oversized, dramatic, absurd effect

## UI
- chunky readable icons
- playful fantasy framing
- minimal clutter
- large spell status feedback
