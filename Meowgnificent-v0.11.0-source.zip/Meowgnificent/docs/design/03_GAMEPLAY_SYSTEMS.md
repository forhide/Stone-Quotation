# Gameplay Systems

## Movement
- 8-direction movement
- short dash / evasive move
- optional body roll
- heavy acceleration/deceleration feel

## Combat
The cat uses magic instead of conventional weapons.

Prototype spell set:
1. Fireball
2. Ice Burst
3. Blink
4. Summon Puff

## Spell Outcome Resolver
Each cast chooses among:
- Success
- Miscast
- Overreaction

### Seed Probabilities
- Success: 70%
- Miscast: 20%
- Overreaction: 10%

These values must be data-driven.

## Design Rule for Miscasts
Miscasts should rarely result in “nothing happens.”
A miscast should instead:
- create danger
- create movement
- alter the room
- accidentally damage enemies
- create a temporary tactical problem
- create comedy

## Fireball
Success:
- normal forward projectile

Miscast variants:
- weak fire puff at feet
- projectile launches 70–110 degrees off-angle
- projectile arcs backward
- nearby object ignites

Overreaction:
- giant explosive fireball
- large knockback

## Ice Burst
Success:
- cone of ice damage + slow

Miscast:
- creates ice under player
- player slips forward

Overreaction:
- radial freeze nova

## Blink
Success:
- short controlled teleport

Miscast:
- random short displacement
- wall bump / bounce

Overreaction:
- teleport + AoE shockwave

## Summon Puff
Success:
- summon small useful magical creature

Miscast:
- summon useless but distracting creature

Overreaction:
- summon large temporary beast

## Chonk System
Food increases Chonk Level.

### Chonk Effects
Higher Chonk:
- HP up
- knockback resistance up
- body attack damage up
- roll momentum up
- movement speed down slightly
- dodge precision down slightly

### Chonk Tiers
Chonk 0 — normal chubby
Chonk 1 — rounder
Chonk 2 — very round
Chonk 3 — maximum chonk

## Body Attacks
### Belly Slam
- heavy AoE impact
- scales with Chonk

### Roll
- player curls and rolls forward
- damage scales with momentum and Chonk

## Food
Prototype foods:
- fish
- meat
- cheese
- cream/milk snack

Food can restore health and increase Chonk.
