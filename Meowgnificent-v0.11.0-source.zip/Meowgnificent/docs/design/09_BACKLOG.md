# Development Backlog

## Phase 1 — Foundation
- create Godot project
- player movement
- camera
- test room
- health/damage
- one enemy
- HUD

## Phase 2 — Core Spell System
- spell base architecture
- outcome resolver
- Fireball
- Ice Burst
- Blink
- Summon Puff
- debug spell testing controls

## Phase 3 — Chonk Gameplay
- food pickups
- Chonk meter
- stat scaling
- size scaling hooks
- belly slam
- roll collision attack

## Phase 4 — Content
- Candle Slime
- Library Bat
- Broom Knight
- Arcane Vacuum elite
- Professor Catastrophus boss
- room pool

## Phase 5 — Run Structure
- reward choice
- relics
- room progression
- run start/end
- unlock save

## Phase 6 — Polish
- camera shake
- hit-stop
- hat flop
- body jiggle
- funny popups
- controller support
- sound hooks
- balance pass
