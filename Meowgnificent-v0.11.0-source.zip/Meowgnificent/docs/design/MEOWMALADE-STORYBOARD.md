# MEOWGNIFICENT

## Main Character

### Meowmalade

통통한 치즈색 고양이 마법사.

항상 커다란 마법사 모자를 쓰고 다니며, 표정은 거의 변하지 않는다.

문제는 마법 실력이다.

정확히는 마력이 약한 게 아니다.

오히려 반대다.

> **Meowmalade는 엄청난 마력을 가지고 있지만, 그 힘을 제대로 제어하지 못한다.**

그래서 아주 간단한 주문도 이상하게 끝나는 경우가 많다.

불덩이를 쏘면 뒤로 날아가고,  
순간이동을 하면 벽에 박히고,  
소환마법을 쓰면 전혀 예상하지 못한 생물이 나타난다.

그런데 이상하게도 그 사고들이 결국 문제를 해결해버린다.

---

# Opening

대륙 최고의 마법 교육기관.

## Arcana Academy

학생들의 마법 실기시험이 진행 중이다.

시험 내용은 간단하다.

> “표적에 Fireball을 정확히 한 발 명중시키시오.”

학생들이 하나씩 시험을 본다.

불덩이가 날아가고, 표적이 정확히 폭발한다.

그리고 마지막 차례.

Meowmalade.

교수가 한숨을 쉰다.

> “Meowmalade. 이번에는 제발 표적만 맞히게.”

Meowmalade가 앞발을 든다.

작은 불꽃 하나가 생긴다.

교수:

> “…좋아.”

불꽃이 천천히 앞으로 움직인다.

> “아주 좋아.”

그런데 불꽃이 갑자기 방향을 바꾼다.

교수:

> “…잠깐.”

불꽃이 Meowmalade 뒤편으로 날아간다.

그리고 잠시 정적.

### BOOOOOOM.

시험장 전체 폭발.

화면 암전.

---

연기가 걷힌다.

Meowmalade는 그대로 앉아 있다.

😐

마법사 모자 끝부분만 살짝 타 있다.

그리고 타이틀.

# MEOWGNIFICENT

---

# Meowmalade's Academic Record

Meowmalade는 Arcana Academy 역사에서도 손꼽히는 문제 학생이다.

| Subject | Grade |
|---|---:|
| Elemental Magic | D |
| Teleportation | F |
| Summoning | F |
| Potion Making | C- |
| Magical Control | F |
| Destruction | S+ |

교수들도 이해하지 못한다.

마법 제어 능력은 최악인데,

사고가 날 때 발생하는 마력은 교수들보다 강하다.

---

# The Incident

어느 날,

Arcana Academy 깊은 곳에 봉인되어 있던 고대의 마도서가 깨어난다.

## The Perfect Grimoire

수백 년 전 만들어진 전설적인 마법 장치.

그 목적은 단 하나였다.

> **모든 마법의 오류를 제거한다.**

처음에는 좋은 의도로 만들어졌다.

불안정한 주문을 안정시키고,

마법사의 실수를 막고,

마법 사고를 없애기 위한 것이었다.

하지만 오랜 시간이 지나면서 그 논리는 점점 극단적으로 변한다.

> 오류가 문제다.

↓

> 오류를 만드는 마법사가 문제다.

↓

> 예측할 수 없는 행동이 문제다.

↓

> 모든 마법은 통제되어야 한다.

---

# The Perfect Magic

Perfect Grimoire는 세상의 모든 마법을 분석하기 시작한다.

Fireball.

분석 완료.

Teleport.

분석 완료.

Summoning.

분석 완료.

Shield.

분석 완료.

모든 주문에는 공식이 존재한다.

그래서 정상적인 마법사들의 공격은 전부 예측된다.

세계 최고의 마법사들이 도전하지만,

Perfect Grimoire는 공격하기도 전에 대응책을 만들어낸다.

---

하지만 한 존재만 분석할 수 없다.

## Meowmalade.

이유는 단순하다.

> **Meowmalade 자신도 다음 주문이 어떻게 나갈지 모르기 때문이다.**

---

# Chapter 1  
## Detention

시험장 폭발 사건 이후,

Meowmalade는 벌로 마법학교 지하 창고를 청소하게 된다.

이곳이 게임의 튜토리얼 지역이다.

플레이어는 여기서 배우게 된다.

- 이동
- Fireball
- Dash
- Miscast
- 음식 먹기
- Chonk System
- Roll Attack

그러던 중 창고의 마법 물건들이 갑자기 스스로 움직이기 시작한다.

마법 빗자루가 공격하고,

상자가 움직이고,

슬라임이 튀어나온다.

교수들은 당연히 Meowmalade가 또 사고를 친 줄 안다.

> “MEOWMALADE!”

Meowmalade:

😐

하지만 이번에는 정말로 억울하다.

---

# Chapter 2  
## The Library

마법학교 도서관 전체가 이상해진다.

책들이 날아다닌다.

책장이 움직인다.

사서 골렘들이 학생들을 공격한다.

그런데 이상한 점이 하나 있다.

모든 움직임이 지나치게 정확하다.

수백 권의 책이 완벽하게 같은 간격으로 날아다닌다.

마법 빗자루들이 군대처럼 움직인다.

Perfect Grimoire의 영향이다.

처음으로 플레이어는

## Magic Perfection

현상을 발견한다.

---

# Chapter 3  
## The Forbidden Garden

마법학교 바깥의 생태계에도 변화가 시작된다.

식물들이 모두 같은 높이로 자란다.

버섯들이 완벽한 격자로 배열된다.

나뭇가지의 개수조차 동일하다.

정원의 관리자가 말한다.

> “Nothing grows like this.”

Perfect Grimoire는 자연까지도

**완벽하게 정렬된 시스템**

으로 바꾸고 있다.

---

# Chapter 4  
## The Failed Wizards

Meowmalade는 학교에서 실패자로 취급받던 다른 학생들을 만나게 된다.

### Pip

소환마법 학생.

용을 소환하려고 하면 항상 닭이 나온다.

---

### Moss

식물마법 학생.

식물을 제어할 수는 있지만,

항상 자기 몸에도 덩굴이 자란다.

---

### Bloop

연금술 학생.

포션은 제대로 만들지 못한다.

하지만 이상하게도 모든 포션이 폭발한다.

---

이들은 모두 학교에서 실패한 마법사 취급을 받아왔다.

하지만 Perfect Grimoire에게는 가장 위험한 존재들이다.

왜냐하면 그들의 마법에는

**정해진 패턴이 없기 때문이다.**

---

# The Truth

중반부에서 Perfect Grimoire의 과거가 밝혀진다.

수백 년 전,

한 번의 마법 사고로 도시 하나가 파괴되었다.

당시 최고의 마법사들은 결론을 내렸다.

> “마법에서 실수를 없애면 이런 사고는 다시 일어나지 않을 것이다.”

그래서 Perfect Grimoire를 만들었다.

하지만 Grimoire는 결국 다음과 같은 결론에 도달한다.

> “완전한 안전을 위해서는 완전한 통제가 필요하다.”

그리고 모든 마법사에게서 자유로운 판단과 변수를 제거하려 한다.

---

# Meowmalade's Role

Meowmalade는 처음부터 끝까지 뛰어난 마법사가 아니다.

오히려 마지막까지도 마법을 제대로 제어하지 못한다.

하지만 그게 장점이 된다.

예를 들어,

Fireball 실패.

→ 책장에 불이 붙는다.

→ 책장이 무너진다.

→ 숨겨진 통로가 열린다.

Teleport 실패.

→ 엉뚱한 위치로 이동한다.

→ 보스의 공격을 우연히 피한다.

Summoning 실패.

→ 이상한 생물이 나온다.

→ 그 생물이 퍼즐을 해결한다.

즉,

> **실패가 새로운 가능성을 만든다.**

---

# Final Area  
## The Grand Archive

Perfect Grimoire가 존재하는 거대한 마법 기록보관소.

수천 년 동안 사용된 모든 주문이 저장되어 있다.

Grimoire가 하나씩 분석한다.

> FIREBALL  
> PREDICTABLE.

> TELEPORTATION  
> PREDICTABLE.

> SUMMONING  
> PREDICTABLE.

그리고 Meowmalade를 분석한다.

```text
SUBJECT: MEOWMALADE

MAGICAL POWER:
EXTREME

MAGICAL CONTROL:
3%

PREDICTABILITY:
0%

BEHAVIORAL CONSISTENCY:
ERROR

THREAT ASSESSMENT:

...

ERROR
```

Perfect Grimoire는 처음으로 계산을 멈춘다.

---

# Final Boss  
## The Perfect Wizard

Perfect Grimoire가 자신이 수집한 모든 마법 데이터를 이용해 하나의 존재를 만든다.

완벽한 마법사.

모든 마법을 완벽한 정확도로 사용하는 존재.

- Fireball
- Ice Magic
- Blink
- Summoning
- Barrier
- Counter Spell

어떤 실수도 하지 않는다.

플레이어가 정상적으로 사용하는 마법은 대부분 대응당한다.

그래서 이 보스전에서는

**Miscast가 정답이다.**

Fireball이 빗나간다.

벽에 튕긴다.

보스의 뒤를 맞힌다.

Ice Spell이 잘못 나간다.

Meowmalade가 미끄러진다.

보스의 공격을 우연히 회피한다.

Summoning이 실패한다.

이상한 생물이 나타난다.

그 생물이 보스의 방어막을 먹어버린다.

---

# Ending

Perfect Grimoire:

> “WHY CAN I NOT PREDICT YOU?”

Meowmalade:

😐

Perfect Grimoire:

> “YOUR MAGIC IS IMPERFECT.”

Meowmalade가 앞발을 든다.

아주 작은 불꽃 하나가 나온다.

Perfect Grimoire:

> “FAILURE.”

불꽃이 바닥에 떨어진다.

잠시 아무 일도 일어나지 않는다.

Perfect Grimoire:

> “AS EXPECTED.”

뒤편에서 작은 연기가 올라온다.

그리고—

### BOOOOOOOOOOM.

Perfect Grimoire 파괴.

---

# Epilogue

며칠 후.

Arcana Academy.

학교는 복구 중이다.

교수가 Meowmalade에게 새로운 성적표를 건넨다.

```text
Elemental Magic        D

Teleportation          F

Summoning              F

Magical Control        F

World Saving           A+

Overall Evaluation:

MEOWGNIFICENT
```

Meowmalade:

😐

교수가 말한다.

> “Well… I suppose that is an improvement.”

Meowmalade 옆에 작은 촛불이 하나 있다.

Meowmalade가 촛불을 쳐다본다.

촛불:

🔥

Meowmalade:

😐

### BOOM.

화면 암전.

# MEOWGNIFICENT

THE END