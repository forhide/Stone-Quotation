# Meowgnificent the wizard cat — Project Brief

## Goal
Build a playable Godot 4.x vertical slice for a comedy action roguelite starring Chonky Wizard Cat.

## Character Identity — FIXED
The protagonist must preserve the recognizable Chonky Wizard Cat look:
- very chubby orange / cheese-colored cat
- round body and short legs
- large wizard hat as the defining costume element
- simple, deadpan / slightly vacant facial expression
- minimal clothing; do not over-design the character with armor or elaborate robes
- waddling, heavy, clumsy movement
- magic is powerful but execution is unreliable

The character should remain visually simple. The appeal comes from the contrast between an ordinary fat cat and absurdly strong magic.

## Core Fantasy
You are an extremely chubby wizard cat whose magic is powerful, unstable, and frequently wrong in funny ways.

Failure is not punishment. Magical mistakes become opportunities.

## Genre
Comedy Action Roguelite + Light Physics Interaction

## Engine
Godot 4.x

## Platform
PC first

## Prototype Goal
One polished playable run containing:
- one biome
- 6–8 combat rooms
- 3 normal enemy types
- 1 elite enemy
- 1 boss
- 4 spells
- spell miscast system
- chonk growth system
- between-room upgrades
- basic meta unlock/save support

## Target Run Length
Prototype: 10–20 minutes
Long-term: 20–40 minutes
