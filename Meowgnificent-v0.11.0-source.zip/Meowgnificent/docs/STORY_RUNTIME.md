# Runtime story sequences

`data/story.json` adapts the supplied Meowmalade / Arcana Academy development story into the current eight-area expedition. Dialogue bodies are Korean. Proper names, speaker labels, report-card subjects and the main game’s existing menu captions remain English where useful.

The opening has fourteen timed illustrated beats: the academy exam, a small Fireball reversing direction, the examination-hall explosion, Meowmalade’s deadpan reaction, the title, academic record, the Perfect Grimoire’s awakening and Detention. Area transitions 1–7 show chapter pages for The Library, The Forbidden Garden, Pip’s Picnic, The Failed Wizards, The Ordered Promenade, The Last Loose End and The Grand Archive. The final victory plays a twelve-beat ending with the World Saving A+ report card, deadpan reaction and final BOOM.

These are actual skippable runtime sequences, not documentation-only story text. The illustrated stage uses the same smooth full-body hero texture as gameplay, with small classroom/book/garden/companion drawings. It does not imply that every spell, traversal puzzle or ally ability described in the original development note is playable.

## Integration

`StoryDirector` is a `CanvasLayer` at layer22. The room assigns `story_director.room=self`, pauses combat, sets state `story`, then calls one of these methods:

| API | Behavior |
|---|---|
| `play_opening(done: Callable)` | Starts timed opening pages. Completion calls `done` once, deferred. |
| `show_chapter(index: int, done: Callable)` | Opens the matching chapter and waits for page advance. |
| `play_ending(done: Callable)` | Starts timed ending pages. |
| `advance()` | Advances a page, or completes the sequence after its last page. |
| `skip()` | Completes an open sequence and invokes its callback once. |
| `close()` | Cancels and hides the UI, discarding the callback. Used for teardown. |

Public review fields are `is_open`, `mode`, `chapter_index`, `pages`, `page_index`, `elapsed`, `auto_advance`, `story` and `last_completed_sequence`. Signals are `sequence_started`, `page_changed` and `sequence_finished`.

Enter/Space advance, Escape skips, and explicit Next/Skip buttons support pointer input. Keyboard events are consumed while open. Completion releases the held cast action; the room also blocks casting until the physical input releases. The room owns combat pause/resume and victory persistence. Narration does not modify combat rewards, health or run progression.

The opening is shown once per application through the room’s `request_begin()` path. Direct `begin_or_restart()` stays available for gameplay fixtures. Old automation sets `MEOW_SKIP_STORY=1` (Web uses `skip_story=1`) to preserve its combat focus. `tests/story.gd` explicitly overrides that flag, runs the actual user-start and route callbacks, and verifies timed/page input, pause boundaries, Pip/Moss/Bloop, the victory ending and callback behavior.

## v0.9.0

The original MEOWMALADE-STORYBOARD remains the narrative basis. Fifty revised bilingual beats restore underground detention, synchronized floating books, grid mushrooms, failed-wizard friends, the city-accident origin of the Grimoire and the unpredictable-failure ending. Briefings and actual areas share ArchiveBackdrop and its visible landmarks. Borrowed item magic is now playable: the equipped primary tool grants one Q/right-click skill, while normal fireball remains separate. Twelve skills include frost, blink, chicken, vines, potion, guard and other effects; all retain70/20/10 success/miscast/overreaction. Friends appear in story portrait vignettes; autonomous companion AI is not implemented. Skill cooldown is shared across equipment swaps, pauses in menus and survives area transitions; new expeditions reset it.
