> Historical v0.9.0 asset. v0.10.0 uses cute_fireball.png and the shared anchors in SpellArt; see README.md.

# v0.9.0 fireball

`fireball_flame.png` is a new image_gen illustration generated for Meowgnificent.
Original output: `/workspace/generated_images/exec-e9f5c87d-b228-4c94-8e2f-546791222bc5.png`.
The original output remains unchanged; the game uses a byte-for-byte copy.

The design is an incandescent round yellow-white core with vivid orange/red flame tongues and trailing embers, pointing right on true alpha transparency. It replaces the pale star-and-puff comet used by previous versions. No third-party game sprite is embedded.

Gameplay and `SpellArt.part("comet")` use this same source. A one-quad shader ripples only the trailing flame region and streams a subtle energy variation, leaving the hot core anchored above the real projectile hit position. Animation is driven by the projectile's combat age, so it freezes with paused combat. Normal, miscast and oversized spells share the texture and shader; there is no particle emitter or per-frame texture/mesh bake.

The source is 1774×887. Its measured white-hot core centre is approximately (1541,485); `SpellProjectile.FIRE_RECT` places this point at local zero before the unchanged 3/4-view offset (0,-20) and heading rotation. Collision, substeps, speed, damage, lifetime and explosion signals are unchanged.

Staged actual-size and enlarged render checks: `.local/qa/v090-fireball-{headings,close,flow}.png`. Five shot quads, six text captions and one background measured 12 draw calls. This isolated visual fixture does not measure gameplay FPS.

Standalone contract checks passed15/15, covering four motion directions, low-FPS substeps, damage/outcome dispatch, one-shot explosion callbacks, bounds, lifetime, pause age and shared story/gameplay resources. The movement/collision/impact function text is byte-identical to v0.8.0. Full main-scene suites are run after combined feature import by the release QA workflow.
