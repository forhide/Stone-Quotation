# Spell artwork

The active `storybook_spell_fx.png` is original generated transparent HD hand-drawn art: a peach/cream puff-tail star, a rounded cartoon impact pop, a crooked coral failed star and lavender cotton smoke. Smooth cocoa outlines and simple pastel cel shading match the final HD Pastel Storybook 2D direction. There are no pixel clusters, retro grid, ornate rune, realistic fire or dynamic bloom.

`scripts/effects/spell_art.gd` defines clipped shared AtlasTexture regions. The impact center and the area surrounding each shape have genuine zero alpha; image-generation RGB under fully transparent pixels is not a background in the game. Failure's separate WHOOPS mark remains distinct. Collision, damage and lifetime are independent of artwork.

Earlier painted and pixel sheets are inactive historical source assets.

## v0.10.0 fireball

`cute_fireball.png` is an image_gen illustrated replacement with a round cream/yellow core, soft orange contour and short cartoon flame tail. SpellArt centralizes its measured core at(1400,490) in1774×887pixels for story and combat. One shaded quad gently animates from the pause-aware projectile age; movement, radius, damage, collision substeps and lifetime are unchanged. The older painted fireball remains a source reference and is excluded from exports.
