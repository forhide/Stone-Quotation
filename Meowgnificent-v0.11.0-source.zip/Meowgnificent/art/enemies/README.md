# Archive familiars artwork

The active `storybook_familiars.png` atlas is original generated HD hand-drawn art. Rounded sage-mint candle jelly, a lavender-cap toy broom and a plush lavender bat use cocoa outlines, small deadpan eyes and simple pastel cel shading. Smooth anti-aliased curves and linear filtering implement the final HD Pastel Storybook 2D direction, without visible pixels or a retro grid.

Four shared AtlasTexture regions supply three bodies and a mirrored bat wing. AI, hitboxes, attack timing, and squash/flap motion are independent of artwork. The small cream-and-caramel crown identifies elites without overlapping their attack warning.

Earlier painted and pixel atlases are inactive historical source assets.
