# Illustrated story plates / v0.7.0

Four original 1536x1024 image_gen HD storybook scenes generated2026-10-23:

- academy.png: `/workspace/generated_images/exec-a4928e0b-450a-4ec5-a74f-1c6ea135a22c.png`
- library.png: `/workspace/generated_images/exec-c4d562b4-90af-4bca-ad3c-29c5ebd9aea2.png`
- friends.png: `/workspace/generated_images/exec-fc4db3ce-2694-4911-bcac-7b6adf40a59b.png`
- archive.png: `/workspace/generated_images/exec-5b1ec4ec-a4da-4316-93b8-1ec4f0b01f6a.png`

StoryStage selects a scene for Academy exam, library/Grimoire, garden/friends and final archive. The hero is a separate crop of the same animation atlas as gameplay, avoiding a different character design between story and combat. The stage uses a small slow pan and existing shared spell/smoke textures, with no particle scene or per-frame render-target bake. Report-card and analysis text are live typeset elements so both languages remain readable; text is not baked into generated pictures. The generated supporting cast is narrative presentation, not companion combat AI.
