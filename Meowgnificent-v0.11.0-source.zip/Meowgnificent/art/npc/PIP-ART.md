> Historical v0.10.0 human Pip asset. v0.11.0 uses squirrel Pip from animal_cast.png everywhere; see ANIMAL-CAST.md and PICNIC-MARKET.md.

# Human Pip merchant

`pip_merchant.png` is an original image_gen derivative of the existing `art/story/friends.png` illustration. Pip remains the blond human student with warm brown eyes, a cream cape edged with sage leaves and a white chicken. The green hooded student is Moss and the blue-haired student is Bloop.

Original output remains at `/workspace/generated_images/exec-cfbd6c61-3284-4441-a80e-b127ce56b44d.png`. The shared world/shop sprite region is `(240,25,694,1323)`; the portrait region `(285,25,649,840)`. No cat or owl face is used for Pip. The original full merchant SVG is used only for its empty lower-cart crop `(24,244,400,104)`, excluding the old owl.

The reused sprite breathes by at most0.3% around a fixed foot anchor; menus pause this small idle motion. Both shop areas use the same identity and interaction position.
