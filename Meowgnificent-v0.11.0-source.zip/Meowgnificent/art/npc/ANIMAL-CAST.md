# Animal supporting cast / v0.11.0

`animal_cast.png` is an original image_gen edit using the approved Meowmalade action sheet as the anatomy/style reference and the previous friend/boss pictures only for identifying color and props. All supporting characters now have round animal bodies, short paws/feet, natural animal muzzles/beaks and no human anatomy or hair.

Top row: Professor (owl), Pip (squirrel with a white chicken), Moss (hedgehog). Bottom row: Bloop (otter with a pink potion), Perfect Wizard (white fox and floating Grimoire, calm), same fox surprised by shield break.

Original generated output remains at `/workspace/generated_images/exec-54808dea-2f70-4c72-af1b-ca155273e18f.png`. Source is1536×1024RGBA. Explicit independently measured alpha regions are in AnimalCast.REGIONS; frame rectangles include transparent margins and are not naive512px grid cuts. Cached AtlasTexture references are reused in story/world/shop/boss, not reallocated per frame. Original human illustrations remain historical workspace sources and are no longer active gameplay/story references.
