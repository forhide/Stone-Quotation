# Central picnic market / v0.11.0

`picnic_market.png` is an original image_gen transparent illustration matching the existing HD Pastel Storybook environments. Original output: `/workspace/generated_images/exec-0d6e05cf-615e-49ad-beeb-7de9f4f265e8.png`.

The low oval table, tea set, bun basket, trinket chest, crates and bunting are one shared texture quad, cropped to `(52,85,1511,841)` and displayed at470×260. Both shop areas reuse the same island; the basement rest stop has a mild pink tint. The two animal guests use the same AnimalCast atlas as their story portraits. Three small Line2D wisps update at10Hz from a pause-aware clock. No particles, dynamic lighting, collision bodies, healing, currency or save changes are added.

The original Pip interaction anchor remains640,315; the new table is also interactable within165px of640,445. Props render below the player's actor layer and leave the left spawn and east exit clear.
