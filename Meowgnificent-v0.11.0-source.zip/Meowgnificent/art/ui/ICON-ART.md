# Game application icon / v0.10.0

Original image_gen round orange wizard-cat illustration in app_icon.png. ICO and ICNS are size/format conversions of that PNG, retaining transparent edges. Windows PE application resources, runtime window icon and macOS bundle use the matching assets; the Web export takes the PNG. tests/platform-icons.py validates actual exported icon bytes, not just settings.
