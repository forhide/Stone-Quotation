# Storybook equipment / v0.7.0

`storybook_equipment.png`: image_gen original transparent illustration atlas, 2026-10-23, original `/workspace/generated_images/exec-dd5300a8-35bc-4cbf-90ef-a22461f83f01.png`. All nine catalog IDs use individually bounded AtlasTexture regions in EquipmentArt; the same cached images are shared by inventory, shop, dropped gear and worn accessories. No icon is synthesized per frame. It contains three wands/books, three collars and three charms.

Wand/book floats beside the paw, collar replaces the neck accessory, and charm is a small hat pin. CatEquipmentVisual creates exactly three Sprite2D nodes and changes their textures on a real equipment change. The parent body supplies waddle/roll rotation; attachments follow casting direction and pause clock. All loose accessories tuck out of view during a roll, then return. No extra robe, armor or backpack covers the cat body. Existing stats, ownership and save rules remain unchanged.

v0.9.0 expands the catalog to36: twelve tools, twelve collars and twelve hat charms. The27new images are original image_gen outputs matching the existing pastel painted atlas. `expanded_weapons.png` originates from exec-2f0b479b-cd1b-41d7-a4ea-61a7c478f5bb.png; `expanded_pendants.png` from exec-ff2aaa5a-6729-4e00-b660-f77111ef066c.png; `expanded_charms.png` from exec-9c571867-ab96-40d3-bd98-4b56fd8c8d9e.png. Originals remain in /workspace/generated_images. Connected-alpha crop rectangles are stored in EquipmentArt; generated sheets are1254square, so crops deliberately avoid naive grid cuts. Pendants retain the cat's thin original neckband. Shared cached icons appear in HUD, equipment, shops, drops and worn attachments.

## v0.10.0

Active art is now `cute_equipment.png`, `cute_weapons.png`, `cute_pendants.png` and `cute_charms.png`: image_gen edits preserving the36item identities, with rounded shapes, soft outlines and simpler cartoon shading. Each atlas has nine individually measured connected-alpha regions in EquipmentArt. Original collar icons show the whole collar in menus, but only the pendant is worn. Old sheets remain historical references and are excluded from executable exports. Icons are cached and reused in inventory, shop, loot and the three worn sprites.

## v0.11.0

Fourteen incorrect atlas-to-item mappings are fixed by explicit rows and columns. Weapon art now uses `cute_weapons_spaced.png`, an image_gen edit of the9cute tools with transparent gutters so neighboring bubbles and staff tips cannot leak into another icon or the worn sprite. Original output: `/workspace/generated_images/exec-4ac96e0c-cec6-4254-babe-3c53b7c0d85a.png`. Other active sheets remain cute_equipment/cute_pendants/cute_charms. Geometry and outline evidence is in docs/qa/v0110-spaced-weapons-evidence.json and v0110-art-mapping-evidence.json. Historical crowded weapon sheets remain source references and are excluded from executable exports.
