# HD Pastel Storybook 2D environments — v0.6.0

The active background uses four original, independent 1536×1024 illustrated scenes. These are full-resolution images, not four-cell atlases or enlarged low-resolution tiles:

- `hd_detention_storage.png`: Arcana Academy's sunny detention storeroom, with rounded shelves, brooms, folded cloths, crates and cleaning supplies.
- `hd_academy_library.png`: the bright academy library, cream floor, rounded bookcases and a large open storybook.
- `hd_forbidden_garden.png`: the Forbidden Garden; flowerpots and foliage have unnaturally equal spacing and height, reflecting the Perfect Grimoire's influence in the supplied story notes.
- `hd_grand_archive.png`: the Grand Archive, softly lit record cabinets and the ancient grimoire at the far perimeter.

`ArchiveBackdrop` maps these locations onto the eight existing route stops. The route maps Detention to the storage, The Library and Failed Wizards to the library/classroom, Forbidden Garden/Pip Picnic/Ordered Promenade to the garden, Last Loose End to a storage market and Grand Archive to the archive. Soft reading runners, flush stepping tiles and picnic cloths distinguish the classroom, ordered promenade and two merchant stops. These decorations do not add collision obstacles. The supplied story is a location/art reference; the backgrounds do not imply that every chapter or the final boss has been implemented.

The artwork uses smooth hand-drawn outlines, pastel cream/sage/lavender/coral color, soft cel shading and a fixed three-quarter top-down view. LINEAR filtering preserves the HD illustration. There is no pixel-grid effect, low-resolution render pass or nearest-neighbor scaling in the background. The room still renders one UPDATE_ONCE cache per arrival and one cached sprite during gameplay.

Earlier experimental pixel atlases were moved into the excluded `.local/retired-art/v060-pixel/` working folder. The old v0.5.0 gritty library resources are inactive historical assets, not used by this painter.
