# Pastel storybook props — v0.6.0

These original SVG props use smooth hand-shaped curves, soft cel colors and rounded cocoa outlines. Loot icons rasterize at 128×128; the garden arch at 208×360; the plush owl shop at 448×360. Linear texture sampling preserves clean curves when they appear at their smaller world sizes. The cream, sage, honey, peach and lavender palette has no material grain or bright glow gradients.

`floor_fire.svg` rasterizes at 320×360 while preserving the existing 160×180 viewBox and 56-unit warning radius. Its gameplay footprint remains independent of the curled peach flame artwork. `archive_route.svg` supplies the compact route overlay.

The `ShelfArt` painter makes smooth cream toy cupboards, scattered picturebooks and peach flame tufts in the existing shared once-rendered shelf atlas. Its original atlas crops and world anchors are preserved. No retro pixel grid or nearest-neighbor sampling is used.
