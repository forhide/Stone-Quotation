# Connected walking / v0.10.0

meme_walk.png is an original image_gen six-pose edit of the approved wizard-cat action artwork. Full-body drawings keep the short legs attached to the belly and hide the tail. Distance-driven contact/pass/advance poses replace the previous separate paw/belly crop rig. A shared immutable mesh swaps only texture UV/pivot uniforms; idle and the other five actions retain pastel_meme_actions.png. Visual evidence in docs/qa/v0100-walk-00..05.png uses the real visual at2.25× for inspection.
