"""Stage final archives and optional <20 MiB parts; does not upload or register artifacts."""
import ast, hashlib, pathlib, shutil
ROOT=pathlib.Path(__file__).resolve().parent.parent
VERSION=next(n.value.value for n in ast.parse((ROOT/'package.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in n.targets))
DEST=ROOT.parent/'shared/downloads'/('Meowgnificent-'+VERSION)
DEST.mkdir(parents=True,exist_ok=True)
for platform in ['windows','linux','macos','web','source']:
    suffix=platform
    p=ROOT.parent/f'Meowgnificent-{VERSION}-{suffix}.zip'
    shutil.copy2(p,DEST/p.name)
archive=DEST/f'Meowgnificent-{VERSION}-windows.zip'
parts=[]
with archive.open('rb') as f:
    i=1
    while data:=f.read(20*1024*1024):
        p=DEST/(archive.name+f'.{i:03}')
        p.write_bytes(data);parts.append(p);i+=1
cmd='''@echo off
setlocal
cd /d "%~dp0"
'''
for p in parts:
    cmd+=f'if not exist "{p.name}" (echo Missing: {p.name} & goto :failed)\n'
cmd+=f'if exist "{archive.name}" (echo ZIP already exists. Move it elsewhere before joining. & goto :failed)\n'
cmd+='copy /b '+ '+'.join('"'+p.name+'"' for p in parts)+' "'+archive.name+'" >nul\n'
cmd+='''if errorlevel 1 goto :failed
echo ZIP created. Extract it, then run Meowgnificent.exe.
if /I "%~1"=="--no-pause" exit /b 0
pause
exit /b 0
:failed
if /I "%~1"=="--no-pause" exit /b 1
pause
exit /b 1
'''
(DEST/'JOIN-WINDOWS.cmd').write_bytes(cmd.replace('\n','\r\n').encode('ascii'))
(DEST/'DOWNLOAD-README.txt').write_text('''Meowgnificent download package

Preferred: download the Windows or Linux ZIP, extract, then run the executable.
If only the large Windows ZIP fails, download both .zip.001 and .zip.002 plus
JOIN-WINDOWS.cmd into the SAME folder, then double-click JOIN-WINDOWS.cmd.
This creates the identical Windows ZIP; extract it and run Meowgnificent.exe.
No Godot editor is needed.

Parts are an optional size fallback, not proof that chat download transport works.
This folder only stages files. It does not upload/register chat attachments.
''')
files=[p for p in sorted(DEST.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt']
lines=[]
for p in files:
    with p.open('rb') as f:lines.append(hashlib.file_digest(f,'sha256').hexdigest()+'  '+p.name+'\n')
(DEST/'SHA256SUMS.txt').write_text(''.join(lines))
# Verify split contents against the original without modifying it.
with archive.open('rb') as f:expected=hashlib.file_digest(f,'sha256').hexdigest()
h=hashlib.sha256()
for p in parts:h.update(p.read_bytes())
assert h.hexdigest()==expected
for p in DEST.iterdir():
    print(p.name,p.stat().st_size)
