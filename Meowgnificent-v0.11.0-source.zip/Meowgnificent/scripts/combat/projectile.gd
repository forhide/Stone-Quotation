class_name SpellProjectile
extends Node2D

signal impacted(point: Vector2, damage: int, radius: float, direction: Vector2)
var direction := Vector2.RIGHT
var speed := 540.0
var lifetime := 2.3
var damage := 20
var radius := 9.0
var explosion_radius := 0.0
var outcome := "success"
var room: Node2D
var bounds: Rect2
var age := 0.0
var spent := false
var flame_material: ShaderMaterial
var flame_mode := -1
const FIRE_SURFACE: Texture2D = SpellArt.FIREBALL
const FIRE_SHADER: Shader = preload("res://scripts/effects/fireball.gdshader")
# The round cartoon fire core is anchored to the projectile's actual hit point.
const FIRE_SCALE := 0.046
const FIRE_RECT := Rect2(-SpellArt.FIRE_CORE*FIRE_SCALE,SpellArt.FIRE_SIZE*FIRE_SCALE)

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	flame_material=ShaderMaterial.new()
	flame_material.shader=FIRE_SHADER
	material=flame_material

func _physics_process(delta: float) -> void:
	if spent:
		return
	age += delta
	# Substeps prevent tunnelling through an enemy at low frame rates.
	var distance := speed * delta
	var steps := maxi(1,ceili(distance / 8.0))
	for i in range(steps):
		position += direction * distance / steps
		if not bounds.has_point(position):
			impact()
			return
		for shelf in room.props:
			if shelf.state!="fallen" and shelf.state!="falling" and position.distance_to(shelf.position)<radius+32:
				shelf.ignite(direction)
				impact()
				return
		for enemy in room.enemies:
			if is_instance_valid(enemy) and enemy.health.current > 0 and position.distance_to(enemy.position) <= radius + float(enemy.config.radius):
				if explosion_radius == 0.0:
					if enemy.has_method("take_spell_damage"): enemy.call("take_spell_damage",damage,direction,outcome)
					else: enemy.take_damage(damage,direction)
				impact()
				return
	if age >= lifetime:
		impact()
	queue_redraw()

func impact() -> void:
	if spent:
		return
	spent = true
	impacted.emit(position,damage,explosion_radius,direction)
	queue_free()

func _draw() -> void:
	# Hot core, tapered moving flame tongues and embers share one shaded quad.
	# Direction and the raised 3/4-view origin are the same as the old projectile.
	var size := radius/9.0
	var next_mode := 1 if outcome=="miscast" else 2 if outcome=="overreaction" else 0
	if flame_mode!=next_mode:
		flame_material.set_shader_parameter("outcome_mode",next_mode)
		flame_mode=next_mode
	flame_material.set_shader_parameter("age",age)
	draw_set_transform(Vector2(0,-20),direction.angle(),Vector2.ONE*size)
	draw_texture_rect(FIRE_SURFACE,FIRE_RECT,false)
	draw_set_transform(Vector2.ZERO)
