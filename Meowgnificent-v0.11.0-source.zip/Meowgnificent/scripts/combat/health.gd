class_name CombatHealth
extends RefCounted

signal changed(current: int, maximum: int)
signal died
var current: int
var maximum: int

func _init(value: int = 100) -> void:
	maximum = value
	current = value

func damage(amount: int) -> bool:
	if current <= 0 or amount <= 0:
		return false
	current = maxi(0, current - amount)
	changed.emit(current, maximum)
	if current == 0:
		died.emit()
	return true
