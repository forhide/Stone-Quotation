class_name MetaProgress
extends RefCounted

const VERSION := 1
const MAX_STARLIGHT := 1000000
const MAX_RUNS := 1000000000
const MAX_SECTOR := 7
const UPGRADES := {
	"vitality":{"name":"Sturdier Whiskers","description":"+5 maximum HP per rank for future runs.","costs":[3,6,9,12]},
	"purse":{"name":"Hidden Coin Pouch","description":"Begin future runs with +5 gold per rank.","costs":[4,8,12]},
	"magnet":{"name":"Moonbell Magnet","description":"Collect drops from +8 pixels away per rank.","costs":[3,6,9]},
	"starter_wand":{"name":"Hand-Me-Down Wand","description":"Begin future runs owning a Crooked Ash Wand.","costs":[6]}
}

var starlight: int = 0
var upgrades: Dictionary = {"vitality":0,"purse":0,"magnet":0,"starter_wand":0}
var attempts: int = 0
var wins: int = 0
# One-based number of sectors cleared: 0 means no sector completed yet.
var best_sector: int = 0
var active_run_id: int = 0
var active_run_finished: bool = true
var save_error: String = ""
var _awarded_sectors: Array[int] = []
var _path: String
var _read_only := false

func _init(path: String = "user://progress-v1.json") -> void:
	_path=ProjectSettings.globalize_path(path)
	_load()

func begin_run() -> int:
	if _read_only: return 0
	if attempts>=MAX_RUNS:
		save_error="The profile has reached its run counter limit."
		return 0
	var previous := _snapshot()
	attempts+=1
	active_run_id=attempts
	active_run_finished=false
	_awarded_sectors.clear()
	if not _save():
		_apply_profile(previous)
		return 0
	return active_run_id

func award_sector(index: int, amount: int) -> int:
	if _read_only or active_run_id<=0 or active_run_finished: return 0
	if index<0 or index>MAX_SECTOR or amount<0 or _awarded_sectors.has(index): return 0
	var previous := _snapshot()
	var awarded := mini(clampi(amount,0,MAX_STARLIGHT),MAX_STARLIGHT-starlight)
	starlight+=awarded
	_awarded_sectors.append(index)
	best_sector=maxi(best_sector,index+1)
	if not _save():
		_apply_profile(previous)
		return 0
	return awarded

func finish_run(won: bool) -> bool:
	if _read_only or active_run_id<=0 or active_run_finished: return false
	var previous := _snapshot()
	active_run_finished=true
	if won: wins=mini(attempts,wins+1)
	if not _save():
		_apply_profile(previous)
		return false
	return true

func purchase_upgrade(id: String) -> Dictionary:
	if _read_only: return {"ok":false,"reason":save_error}
	if not UPGRADES.has(id): return {"ok":false,"reason":"Unknown upgrade."}
	var costs: Array = UPGRADES[id].costs
	var level := _level(id)
	if level>=costs.size(): return {"ok":false,"reason":"Maximum rank reached."}
	var cost: int = int(costs[level])
	if starlight<cost: return {"ok":false,"reason":"Not enough starlight."}
	var previous := _snapshot()
	starlight-=cost
	upgrades[id]=level+1
	if not _save():
		_apply_profile(previous)
		return {"ok":false,"reason":save_error}
	return {"ok":true,"reason":"Upgrade unlocked for future runs."}

func upgrade_offers() -> Array[Dictionary]:
	var offers: Array[Dictionary] = []
	for id: String in UPGRADES:
		var definition: Dictionary = UPGRADES[id]
		var level := _level(id)
		var costs: Array = definition.costs
		offers.append({"id":id,"name":str(definition.name),"description":str(definition.description),"level":level,"max_level":costs.size(),"cost":int(costs[level]) if level<costs.size() else 0})
	return offers

func bonuses() -> Dictionary:
	return {
		"max_hp_bonus":5*_level("vitality"),
		"starting_gold":5*_level("purse"),
		"pickup_radius_bonus":8*_level("magnet"),
		"starter_item":"crooked_ash_wand" if _level("starter_wand")>0 else ""
	}

func _level(id: String) -> int:
	return _bounded_int(upgrades.get(id,0),0,UPGRADES[id].costs.size())

func _snapshot() -> Dictionary:
	return {"version":VERSION,"starlight":starlight,"upgrades":upgrades.duplicate(true),"attempts":attempts,"wins":wins,"best_sector":best_sector,"active_run_id":active_run_id,"active_run_finished":active_run_finished,"awarded_sectors":_awarded_sectors.duplicate()}

func _apply_profile(data: Dictionary) -> void:
	starlight=_bounded_int(data.get("starlight",0),0,MAX_STARLIGHT)
	attempts=_bounded_int(data.get("attempts",0),0,MAX_RUNS)
	wins=_bounded_int(data.get("wins",0),0,attempts)
	best_sector=_bounded_int(data.get("best_sector",0),0,MAX_SECTOR+1)
	active_run_id=_bounded_int(data.get("active_run_id",0),0,attempts)
	var finished: Variant = data.get("active_run_finished",true)
	active_run_finished=finished if finished is bool else true
	if active_run_id==0: active_run_finished=true
	upgrades={}
	var saved_upgrades: Variant = data.get("upgrades",{})
	for id: String in UPGRADES:
		upgrades[id]=_bounded_int(saved_upgrades.get(id,0),0,UPGRADES[id].costs.size()) if saved_upgrades is Dictionary else 0
	_awarded_sectors.clear()
	var saved_awards: Variant = data.get("awarded_sectors",[])
	if saved_awards is Array and active_run_id>0:
		for sector: Variant in saved_awards:
			if sector is int or sector is float:
				var index := _bounded_int(sector,-1,MAX_SECTOR+1,-1)
				if index>=0 and index<=MAX_SECTOR and not _awarded_sectors.has(index):
					_awarded_sectors.append(index)

func _bounded_int(value: Variant, minimum: int, maximum: int, fallback: int = 0) -> int:
	if value is int: return clampi(value,minimum,maximum)
	if value is float and is_finite(value): return int(clampf(value,float(minimum),float(maximum)))
	return fallback

func _read_profile(path: String) -> Dictionary:
	if not FileAccess.file_exists(path): return {"status":"missing"}
	var file := FileAccess.open(path,FileAccess.READ)
	if file==null: return {"status":"error"}
	var raw := file.get_as_text()
	file.close()
	var parser := JSON.new()
	if parser.parse(raw)!=OK or not parser.data is Dictionary: return {"status":"corrupt"}
	var data: Dictionary = parser.data
	var raw_version: Variant = data.get("version",null)
	if not (raw_version is int or raw_version is float): return {"status":"corrupt"}
	if not is_finite(float(raw_version)) or float(raw_version)!=floorf(float(raw_version)): return {"status":"corrupt"}
	if float(raw_version)>VERSION: return {"status":"future"}
	if float(raw_version)!=VERSION: return {"status":"corrupt"}
	return {"status":"ok","data":data,"raw":raw}

func _load() -> void:
	var primary := _read_profile(_path)
	if primary.status=="ok":
		_apply_profile(primary.data)
		return
	if primary.status=="future":
		_lock_future_profile()
		return
	var backup := _read_profile(_path+".bak")
	if backup.status=="future":
		_lock_future_profile()
		return
	if backup.status=="ok":
		_apply_profile(backup.data)
		save_error="Progress was recovered from the previous valid backup."
	elif primary.status!="missing" or backup.status!="missing":
		save_error="The progress file could not be read. A fresh profile is available."

func _lock_future_profile() -> void:
	_read_only=true
	save_error="This progress file belongs to a newer game version and has been left unchanged."

func _save() -> bool:
	if _read_only: return false
	# Recheck before writing in case a newer application replaced the file since load.
	var primary := _read_profile(_path)
	if primary.status=="future":
		_lock_future_profile()
		return false
	if primary.status=="error":
		save_error="Progress could not be read before saving."
		return false
	var parent_dir := _path.get_base_dir()
	if not DirAccess.dir_exists_absolute(parent_dir):
		if DirAccess.make_dir_recursive_absolute(parent_dir)!=OK:
			save_error="The progress folder could not be created."
			return false
	# Keep one previous committed profile. Never copy corrupt data over a valid backup.
	if primary.status=="ok":
		var backup := _read_profile(_path+".bak")
		if backup.status!="future" and not _atomic_write(_path+".bak",str(primary.raw)):
			return false
	if not _atomic_write(_path,JSON.stringify(_snapshot(),"  ")+"\n"):
		return false
	save_error=""
	return true

func _atomic_write(path: String, text: String) -> bool:
	var temporary := path+".tmp-%d-%d" % [OS.get_process_id(),Time.get_ticks_usec()]
	var file := FileAccess.open(temporary,FileAccess.WRITE)
	if file==null:
		save_error="Progress could not be written. Check available disk space and folder access."
		return false
	file.store_string(text)
	file.flush()
	var result := file.get_error()
	file.close()
	if result!=OK:
		DirAccess.remove_absolute(temporary)
		save_error="Progress could not be fully written. The previous save was kept."
		return false
	if DirAccess.rename_absolute(temporary,path)!=OK:
		DirAccess.remove_absolute(temporary)
		save_error="Progress could not be committed. The previous save was kept."
		return false
	return true
