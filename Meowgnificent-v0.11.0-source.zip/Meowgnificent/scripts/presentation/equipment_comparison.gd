class_name EquipmentComparison
extends RefCounted

# Compare the real totals, but present only direction. Different special spells
# have different hit counts and utility; their raw damage/radius is not a rating.
const LABELS := {"max_hp":"Heartiness", "speed":"Quick feet", "spell_damage":"Firepower", "spell_cooldown":"Spell pace", "roll_damage":"Rolling power", "roll_cooldown":"Roll pace", "pickup_radius":"Gathering", "skill_damage":"Special power", "skill_cooldown":"Special pace", "skill_radius":"Special reach"}

static func changes(current: Dictionary, after: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	for row: Dictionary in CharacterStats.ROWS:
		var key := str(row.key)
		if key.begins_with("skill_") and str(current.get("skill_id",""))!=str(after.get("skill_id","")): continue
		# A passive bonus to a special does nothing with an empty weapon slot.
		if key.begins_with("skill_") and str(after.get("skill_id","")).is_empty(): continue
		var quality := CharacterStats.improvement(row,current,after)
		if quality!=0: result.append({"key":key,"label":str(LABELS[key]),"quality":quality})
	return result
