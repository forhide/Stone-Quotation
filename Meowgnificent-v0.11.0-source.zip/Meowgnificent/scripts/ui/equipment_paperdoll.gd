class_name EquipmentPaperdoll
extends Control

var equipment: Dictionary={"wand":"","collar":"","charm":""}

func _init() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func set_equipment(value: Dictionary) -> void:
	equipment=value.duplicate(true)
	queue_redraw()

func get_equipment() -> Dictionary:
	return equipment.duplicate(true)

func _draw() -> void:
	var source: Rect2=WizardCatVisual.POSE_RECTS[0]
	var factor := 292.0/source.size.y
	var extent := source.size*factor
	var feet := Vector2(205,340)
	draw_set_transform(feet+Vector2(0,3),0,Vector2(1,0.24))
	draw_circle(Vector2.ZERO,65,Color(0.52,0.50,0.37,0.12))
	draw_set_transform(Vector2.ZERO)
	# Guide lines stop at the small equipment slots around the silhouette.
	for line in [[Vector2(72,64),Vector2(132,92)],[Vector2(73,263),Vector2(181,230)],[Vector2(333,263),Vector2(285,245)]]:
		draw_line(line[0],line[1],Color("d5c6a7"),2,true)
	draw_texture_rect_region(WizardCatVisual.ACTION_SHEET,Rect2(feet-Vector2(extent.x*0.5,extent.y),extent),source)
	var scale_factor := 292.0/(source.size.y*168.0*0.86/510.0)
	for slot in ["collar","charm","wand"]:
		var id := str(equipment.get(slot,""))
		var texture := EquipmentArt.worn_icon(id)
		if texture==null: continue
		var layout := EquipmentArt.attachment_layout(id)
		var target: Vector2={"wand":Vector2(40,-47),"collar":Vector2(-7,-53),"charm":Vector2(-24,-114)}[slot]
		var item_size: Vector2=Vector2(layout.extent)*scale_factor*(0.80 if slot=="wand" else 1.0)
		draw_set_transform(feet+target*scale_factor,float(layout.angle))
		draw_texture_rect(texture,Rect2(-item_size*0.5,item_size),false)
		draw_set_transform(Vector2.ZERO)
