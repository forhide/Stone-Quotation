class_name EquipmentSymbol
extends Control

# Tiny vector UI symbols remain crisp at any scale and need no font glyphs.
var kind := "wand"
var quality := 0
var ink := Color("8d7763")

func _init(symbol: String="wand", rating: int=0) -> void:
	kind=symbol
	quality=rating
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	custom_minimum_size=Vector2(22,22)

func _draw() -> void:
	var extent := minf(size.x,size.y)
	draw_set_transform((size-Vector2.ONE*extent)*0.5,0,Vector2.ONE*extent/24.0)
	var c := Color("4d815e") if quality>0 else Color("b36678") if quality<0 else ink
	if kind=="arrow":
		var points := PackedVector2Array([Vector2(12,3),Vector2(21,12),Vector2(16,12),Vector2(16,21),Vector2(8,21),Vector2(8,12),Vector2(3,12)])
		if quality<0:
			for i in range(points.size()): points[i].y=24-points[i].y
		draw_colored_polygon(points,c)
	elif kind=="charm":
		draw_colored_polygon(PackedVector2Array([Vector2(5,17),Vector2(13,3),Vector2(18,17)]),c)
		draw_line(Vector2(3,19),Vector2(21,19),c,3,true)
		draw_circle(Vector2(13,11),1.5,Color("fff5d9"))
	elif kind=="collar":
		draw_arc(Vector2(12,9),7,0,PI,16,c,2,true)
		draw_circle(Vector2(12,18),4,c)
		draw_line(Vector2(12,18),Vector2(12,21),Color("fff5d9"),1,true)
	elif kind=="max_hp":
		draw_circle(Vector2(8,9),5,c)
		draw_circle(Vector2(16,9),5,c)
		draw_colored_polygon(PackedVector2Array([Vector2(3,10),Vector2(21,10),Vector2(12,22)]),c)
	elif kind=="speed":
		draw_circle(Vector2(12,16),5,c)
		for at in [Vector2(5,9),Vector2(10,5),Vector2(16,5),Vector2(20,10)]: draw_circle(at,2.3,c)
	elif kind.ends_with("cooldown"):
		draw_arc(Vector2(12,12),8,-PI*0.5,PI*1.3,24,c,2,true)
		draw_line(Vector2(12,6),Vector2(12,12),c,2,true)
		draw_line(Vector2(12,12),Vector2(16,14),c,2,true)
	elif kind=="pickup_radius":
		draw_arc(Vector2(12,13),7,0,PI,16,c,4,true)
		draw_line(Vector2(5,13),Vector2(5,6),c,4,true)
		draw_line(Vector2(19,13),Vector2(19,6),c,4,true)
	elif kind=="roll_damage":
		draw_circle(Vector2(12,13),8,c)
		draw_arc(Vector2(12,13),4,0,PI*1.6,18,Color("fff5d9"),2,true)
	elif kind=="wand":
		draw_line(Vector2(5,20),Vector2(17,7),c,3,true)
		_star(Vector2(17,6),5,c)
	else:
		_star(Vector2(12,12),10,c)
	draw_set_transform(Vector2.ZERO)

func _star(center: Vector2, radius: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(8): points.append(center+Vector2.UP.rotated(i*TAU/8)*(radius if i%2==0 else radius*0.4))
	draw_colored_polygon(points,color)
