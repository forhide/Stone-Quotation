class_name ShopGathering
extends Node2D

# One authored market quad fills the rest-stop centre. These props and friends
# are presentation only; the route and the player's movement stay unobstructed.
const ART: Texture2D = preload("res://art/npc/picnic_market.png")
const ART_REGION := Rect2(52,85,1511,841)
const MARKET_RECT := Rect2(405,300,470,260)
const TABLE_POSITION := Vector2(640,445)
const FRIEND_POSITIONS := {"moss":Vector2(408,478),"bloop":Vector2(858,484)}
var friends: Dictionary = {}
var steam: Array[Line2D] = []
var elapsed := 0.0
var _steam_tick := 0.0
var stage_index := -1

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	for id: String in FRIEND_POSITIONS:
		var sprite := Sprite2D.new()
		sprite.name=id.capitalize()+"AtTea"
		sprite.texture=AnimalCast.icon(id)
		sprite.centered=false
		var factor := 101.0/sprite.texture.get_height()
		sprite.scale=Vector2.ONE*factor
		sprite.position=Vector2(FRIEND_POSITIONS[id])+Vector2(-sprite.texture.get_width()*factor*0.5,-101)
		add_child(sprite)
		friends[id]=sprite
	for offset in [-11.0,0.0,11.0]:
		var line := Line2D.new()
		line.position=Vector2(642+offset,410)
		line.width=1.7
		line.default_color=Color(1,0.97,0.88,0.58)
		line.begin_cap_mode=Line2D.LINE_CAP_ROUND
		line.end_cap_mode=Line2D.LINE_CAP_ROUND
		line.antialiased=true
		add_child(line)
		steam.append(line)
	_update_steam()
	visible=false

func configure(index: int, enabled: bool) -> void:
	stage_index=index
	visible=enabled
	# The basement's final rest stop is slightly rosier, using the same shape.
	self_modulate=Color("fff1f6") if index==6 else Color.WHITE

func animate(delta: float) -> void:
	if not visible: return
	elapsed+=delta
	_steam_tick+=delta
	if _steam_tick>=0.10:
		_steam_tick=0
		_update_steam()

func _update_steam() -> void:
	for i in range(steam.size()):
		var line := steam[i]
		var points := PackedVector2Array()
		for j in range(5):
			var height := j*5.0
			points.append(Vector2(sin(elapsed*1.8+j*0.75+i)*2.1,-height))
		line.points=points

func snapshot() -> Dictionary:
	var identities: Dictionary={}
	for id: String in friends: identities[id]=friends[id].texture
	return {"visible":visible,"center":TABLE_POSITION,"rect":MARKET_RECT,"friends":identities,"clock":elapsed,"stage":stage_index}

func _draw() -> void:
	draw_texture_rect_region(ART,MARKET_RECT,ART_REGION)
