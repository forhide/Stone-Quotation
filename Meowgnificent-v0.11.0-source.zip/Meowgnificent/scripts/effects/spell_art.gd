class_name SpellArt
extends RefCounted

# Smooth HD storybook stars, pop and smoke share one imported atlas.
const ATLAS: Texture2D = preload("res://art/fx/storybook_spell_fx.png")
const FIREBALL: Texture2D = preload("res://art/fx/cute_fireball.png")
const FIRE_CORE := Vector2(1400,490)
const FIRE_SIZE := Vector2(1774,887)
static var parts: Dictionary = {}

static func part(kind: String) -> Texture2D:
 if kind=="comet" or kind=="fireball": return FIREBALL
 if parts.has(kind): return parts[kind]
 var region := AtlasTexture.new()
 region.atlas=ATLAS
 match kind:
  "impact": region.region=Rect2(916,22,544,498)
  "fizzle": region.region=Rect2(66,639,728,280)
  "smoke": region.region=Rect2(907,518,565,485)
  _: region.region=Rect2(64,115,754,294)
 region.filter_clip=true
 parts[kind]=region
 return region
