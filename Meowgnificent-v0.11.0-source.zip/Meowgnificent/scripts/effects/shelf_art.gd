class_name ShelfArt
extends Node2D

# Smooth toy cupboards and picturebooks are baked once into the room atlas.
const COCOA := Color("8b6f79")
const CREAM := Color("f8e2be")
const PAPER := Color("fff4d9")

func ellipse(at: Vector2, size: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(64):
		var a := TAU*i/64.0
		points.append(at+Vector2(cos(a),sin(a))*size)
	draw_colored_polygon(points,color)

func box(color: Color, border: Color, radius: int = 5) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	return style

func _draw() -> void:
	draw_set_transform(Vector2(80,112))
	draw_standing()
	draw_set_transform(Vector2(240,80))
	draw_fallen()
	draw_set_transform(Vector2(400,112))
	draw_fire()
	draw_set_transform(Vector2.ZERO)

func draw_standing() -> void:
	ellipse(Vector2(0,7),Vector2(48,11),Color(0.37,0.47,0.36,0.17))
	draw_style_box(box(Color("e2baa6"),COCOA,8),Rect2(-43,-80,86,84))
	draw_style_box(box(Color("c0a4a8"),Color("b3969e"),5),Rect2(-35,-73,70,70))
	for x in [-41,34]:
		draw_style_box(box(CREAM,Color("c4a38f"),3),Rect2(x,-76,7,80))
		draw_line(Vector2(x+2,-72),Vector2(x+2,0),PAPER,1.3,true)
	var colors := [Color("b5cfb5"),Color("c9b8df"),Color("edb7b0"),Color("add0d2"),Color("f0d39e"),Color("d4c6dd")]
	for row in range(2):
		for i in range(6):
			var x := -30+i*10
			var y := -68+row*33+(i%3)*1.8
			var h := 26.0-(i%3)*2
			var c: Color=colors[(i+row)%6]
			draw_style_box(box(c,COCOA,2),Rect2(x,y,8.5,h))
			draw_line(Vector2(x+2,y+3),Vector2(x+2,y+h-3),c.lightened(0.18),1.0,true)
			draw_line(Vector2(x+3,y+5),Vector2(x+6,y+5),PAPER,1.3,true)
			draw_line(Vector2(x+3,y+h-5),Vector2(x+6,y+h-5),PAPER,1.3,true)
			if i%3==1:
				draw_circle(Vector2(x+4.6,y+h*0.53),1.3,PAPER,true,-1,true)
		var shelf_y := -36+row*33
		draw_style_box(box(CREAM,Color("c4a38f"),2),Rect2(-38,shelf_y,76,6))
		draw_line(Vector2(-35,shelf_y+1),Vector2(35,shelf_y+1),PAPER,1.3,true)
	draw_style_box(box(CREAM,COCOA,5),Rect2(-45,-83,90,9))
	draw_line(Vector2(-38,-81),Vector2(38,-81),PAPER,1.5,true)
	for x in [-37,30]:
		draw_style_box(box(Color("d5b19c"),COCOA,3),Rect2(x,2,8,8))
	# A flower sticker replaces the old metal crest.
	for i in range(5):
		var at := Vector2(0,-81)+Vector2.from_angle(TAU*i/5.0)*4
		ellipse(at,Vector2(3.5,3.5),Color("eab6b3"))
	draw_circle(Vector2(0,-81),2.6,PAPER,true,-1,true)

func draw_fallen() -> void:
	ellipse(Vector2(1,4),Vector2(48,67),Color(0.37,0.47,0.36,0.16))
	draw_style_box(box(Color("dfbda8"),COCOA,8),Rect2(-42,-65,84,127))
	draw_style_box(box(Color("f2d8b7"),Color("bf9e90"),5),Rect2(-35,-58,70,113))
	for y in [-23,20]:
		draw_style_box(box(CREAM,Color("c4a38f"),3),Rect2(-36,y,72,6))
	var colors := [Color("c9b8df"),Color("add0d2"),Color("edb7b0"),Color("b5cfb5")]
	for i in range(9):
		var at := Vector2(sin(i*8.0)*28,cos(i*9.0)*47)
		draw_set_transform(Vector2(240,80)+at,(i-4)*0.29)
		draw_style_box(box(colors[i%4],COCOA,3),Rect2(-11,-8,22,16))
		draw_style_box(box(PAPER,Color("d4bbac"),2),Rect2(-8,-6,16,11))
		draw_line(Vector2(0,-5),Vector2(0,4),Color("c4a992"),1,true)
		draw_line(Vector2(-6,-2),Vector2(-2,-2),Color("cdb5a2"),1,true)
		draw_line(Vector2(2,1),Vector2(6,1),Color("cdb5a2"),1,true)
	draw_set_transform(Vector2(240,80))
	for at in [Vector2(-44,3),Vector2(32,57),Vector2(-15,-69)]:
		draw_style_box(box(PAPER,Color("d4bbac"),2),Rect2(at,Vector2(12,9)))

func draw_fire() -> void:
	# Friendly peach flame tufts with hand-shaped curves and flat cel shadows.
	for i in range(5):
		var p := Vector2(-28+i*14,-38-(i%3)*5)
		var curve := Curve2D.new()
		curve.bake_interval=1.5
		curve.add_point(p+Vector2(0,-24),Vector2.ZERO,Vector2(-1,10))
		curve.add_point(p+Vector2(-10,-1),Vector2(-2,-10),Vector2(0,8))
		curve.add_point(p+Vector2(0,10),Vector2(-7,0),Vector2(8,0))
		curve.add_point(p+Vector2(10,-2),Vector2(0,8),Vector2(-1,-9))
		curve.add_point(p+Vector2(0,-24),Vector2(7,9),Vector2.ZERO)
		var points := curve.get_baked_points()
		points.remove_at(points.size()-1)
		draw_colored_polygon(points,Color("f1b08d"))
		points.append(points[0])
		draw_polyline(points,Color("ca8c7e"),1.2,true)
		ellipse(p+Vector2(0,2),Vector2(5,7),Color("ffe8bb"))
