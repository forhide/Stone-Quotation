class_name ExaminerBarrierVisual
extends Node2D

# A single shaded quad owns the protective glass, rune ring, fracture and
# dispersing pieces. All time comes from the boss's pause-aware combat clock.
const INK := preload("res://scripts/effects/examiner_barrier.gdshader")
var ink := ShaderMaterial.new()
var boss: Node
var draw_mode := -1

func _ready() -> void:
 ink.shader=INK
 material=ink
 z_index=1

func sync() -> void:
 if not is_instance_valid(boss): return
 ink.set_shader_parameter("clock",boss.time)
 ink.set_shader_parameter("shielded",boss.barrier_active)
 ink.set_shader_parameter("break_age",boss.barrier_break_age)
 ink.set_shader_parameter("reform_age",boss.barrier_reform_age)
 ink.set_shader_parameter("blocked_flash",boss.counter_flash)
 var next := 0 if boss.barrier_active else 1 if boss.barrier_break_age<0.95 else 2
 if next!=draw_mode:
  draw_mode=next
  queue_redraw()

func _draw() -> void:
 if not is_instance_valid(boss): return
 if draw_mode==0:
  draw_rect(Rect2(-118,-136,236,272),Color.WHITE)
 elif draw_mode==1:
  draw_rect(Rect2(-200,-225,400,450),Color.WHITE)
