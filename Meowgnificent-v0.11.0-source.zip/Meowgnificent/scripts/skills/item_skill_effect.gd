class_name ItemSkillEffect
extends Node2D

# Bounded, short-lived skill actors share one draw node per effect. They live
# under the room's projectile root, so menus and room changes pause/clear them.
var controller: Node
var kind := "spark"
var direction := Vector2.RIGHT
var origin := Vector2.ZERO
var target := Vector2.ZERO
var radius := 55.0
var damage := 0
var duration := 0.5
var delay := 0.0
var speed := 390.0
var outcome := "success"
var age := 0.0
var triggered := false
var next_tick := 0.6
var hit_times: Dictionary = {}
var points: PackedVector2Array = PackedVector2Array()

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func _physics_process(delta: float) -> void:
	if not is_instance_valid(controller) or not is_instance_valid(controller.room):
		queue_free()
		return
	if not controller.is_combat_active():
		if controller.room.exit_open or controller.room.state in ["transition","cleared","defeated","intro"]: queue_free()
		return
	age+=delta
	match kind:
		"pages":
			# A miscast sends the footnotes circling an empty patch behind the
			# caster instead of protecting their feet. The pages still hit foes.
			position=controller.player.position+(direction*85.0 if outcome=="miscast" else Vector2.ZERO)
			for enemy in controller.room.enemies.duplicate():
				if not is_instance_valid(enemy) or enemy.health.current<=0: continue
				var id: int=enemy.get_instance_id()
				if age-float(hit_times.get(id,-10.0))<0.5: continue
				for i in range(6):
					var page := position+Vector2.from_angle(age*3.3+i*TAU/6.0)*radius
					if page.distance_to(enemy.position)<=19.0+float(enemy.config.radius):
						controller.hit_enemy(enemy,damage,(enemy.position-position).normalized(),outcome)
						hit_times[id]=age
						break
		"bubble":
			position=controller.player.position
		"chicken":
			var travel := speed*delta
			var steps := maxi(1,ceili(travel/9.0))
			for step in range(steps):
				position+=direction*travel/steps
				if not controller.room.bounds.has_point(position):
					queue_free()
					return
				for enemy in controller.room.enemies.duplicate():
					if not is_instance_valid(enemy) or enemy.health.current<=0: continue
					var id: int=enemy.get_instance_id()
					if not hit_times.has(id) and position.distance_to(enemy.position)<=radius+float(enemy.config.radius):
						controller.hit_enemy(enemy,damage,direction,outcome)
						hit_times[id]=age
		"vine":
			if age>=next_tick:
				next_tick+=0.6
				controller.hit_area(position,damage,radius,outcome)
		"potion":
			position=origin.lerp(target,clampf(age/duration,0.0,1.0))
			if age>=duration and not triggered:
				triggered=true
				controller.hit_area(target,damage,radius,outcome)
				controller.visual("potion_pop",target,radius,0.55,outcome)
		"thunder","meteor":
			if age>=delay and not triggered:
				triggered=true
				controller.hit_area(position,damage,radius,outcome)
	if age>=duration+delay: queue_free()
	queue_redraw()

func _ellipse(at: Vector2, extent: Vector2, color: Color) -> void:
	draw_set_transform(at,0,extent)
	draw_circle(Vector2.ZERO,1,color,true,-1,true)
	draw_set_transform(Vector2.ZERO)

func _draw() -> void:
	var ratio := clampf(age/maxf(duration,0.01),0.0,1.0)
	var fade := 1.0-clampf((age-delay)/maxf(duration,0.01),0.0,1.0)
	var coral := Color("e7a77c")
	var cream := Color("fff2c7")
	var mint := Color("9cbba3")
	match kind:
		"pages":
			draw_arc(Vector2(0,-9),radius,0,TAU,40,Color(0.69,0.61,0.79,0.18),1.5,true)
			for i in range(6):
				var point := Vector2.from_angle(age*3.3+i*TAU/6.0)*radius+Vector2(0,-18)
				draw_set_transform(point,age*0.6+i,Vector2.ONE)
				draw_rect(Rect2(-7,-10,14,20),Color("fff4d7"))
				draw_rect(Rect2(-7,-10,14,20),Color("a995b6"),false,1.0)
				draw_line(Vector2(-4,-4),Vector2(4,-4),Color("bca6ca"),1.0,true)
				draw_line(Vector2(-4,0),Vector2(3,0),Color("bca6ca"),1.0,true)
				draw_set_transform(Vector2.ZERO)
		"bubble":
			var alpha := minf(0.6,fade*1.5)
			_ellipse(Vector2(0,-63),Vector2(radius*0.78,radius),Color(0.73,0.88,0.91,alpha*0.25))
			draw_set_transform(Vector2(0,-63),0,Vector2(0.78,1))
			draw_arc(Vector2.ZERO,radius,0,TAU,48,Color(0.69,0.84,0.88,alpha),2.2,true)
			draw_arc(Vector2.ZERO,radius-7,-2.5,-1.75,10,Color(1,0.98,0.89,alpha),3.0,true)
			draw_set_transform(Vector2.ZERO)
		"chicken":
			_ellipse(Vector2(0,3),Vector2(19,5),Color(0.39,0.32,0.30,0.14))
			_ellipse(Vector2(-2,-16),Vector2(17,14),Color("fff0ca"))
			_ellipse(Vector2(-8,-17+sin(age*24)*2),Vector2(8,5),Color("ebd4a9"))
			draw_circle(Vector2(10,-29),10,Color("fff3d3"),true,-1,true)
			draw_circle(Vector2(8,-38),4,Color("db8c83"),true,-1,true)
			draw_circle(Vector2(14,-37),3.5,Color("db8c83"),true,-1,true)
			draw_colored_polygon(PackedVector2Array([Vector2(18,-30),Vector2(26,-26),Vector2(17,-24)]),Color("e6b565"))
			draw_circle(Vector2(13,-31),1.5,Color("654e45"),true,-1,true)
			for i in [-1,1]:
				var leg := Vector2(i*7,-2)
				draw_line(leg,leg+Vector2(sin(age*26+i)*5,7),Color("c99b60"),2.0,true)
		"vine":
			_ellipse(Vector2.ZERO,Vector2(radius,radius*0.48),Color(0.64,0.77,0.61,0.13))
			for i in range(7):
				var angle := i*TAU/7.0
				var at := Vector2.from_angle(angle)*radius*0.68
				var leaf := at+Vector2(sin(age*2+i)*4,-16)
				draw_line(at,leaf,mint,3.2,true)
				_ellipse(leaf+Vector2(4,-3),Vector2(7,3),Color("b4c9a0"))
			draw_arc(Vector2.ZERO,radius*0.92,0,TAU,36,Color(0.59,0.72,0.57,0.42),1.5,true)
		"potion":
			var height := sin(ratio*PI)*80.0
			_ellipse(Vector2(0,3),Vector2(11,3),Color(0.42,0.31,0.43,0.13))
			draw_set_transform(Vector2(0,-height-17),ratio*TAU,Vector2.ONE)
			draw_circle(Vector2.ZERO,10,Color("c9a3cf"),true,-1,true)
			draw_rect(Rect2(-4,-15,8,8),Color("e7c394"))
			draw_line(Vector2(-4,-4),Vector2(2,-7),Color("fff1d7"),2.0,true)
			draw_set_transform(Vector2.ZERO)
		"thunder","meteor":
			if age<delay:
				draw_arc(Vector2.ZERO,radius,0,TAU,32,Color(0.79,0.68,0.43,0.28),1.5,true)
				draw_circle(Vector2.ZERO,4,Color(0.91,0.79,0.49,0.45),true,-1,true)
			else:
				var elapsed := age-delay
				if kind=="thunder":
					var bolt := PackedVector2Array([Vector2(-5,-105),Vector2(-18,-66),Vector2(7,-68),Vector2(-8,-29),Vector2(2,-31),Vector2.ZERO])
					draw_polyline(bolt,Color(0.95,0.78,0.45,fade*0.34),10,true)
					draw_polyline(bolt,Color(1,0.95,0.75,fade),3.0,true)
				else:
					draw_set_transform(Vector2(0,-maxf(0,70-elapsed*350)),0.5,Vector2.ONE)
					draw_circle(Vector2.ZERO,17,Color(0.94,0.63,0.42,fade),true,-1,true)
					draw_circle(Vector2(3,-2),9,Color(1,0.93,0.69,fade),true,-1,true)
					draw_set_transform(Vector2.ZERO)
				draw_arc(Vector2.ZERO,radius*(0.4+elapsed),0,TAU,32,Color(0.92,0.74,0.49,fade*0.7),2,true)
		"frost":
			var shape := PackedVector2Array([Vector2.ZERO])
			for i in range(15): shape.append(Vector2.from_angle(direction.angle()-PI*0.29+i*PI*0.58/14)*radius*minf(1,ratio*3))
			draw_colored_polygon(shape,Color(0.67,0.84,0.88,fade*0.3))
			for i in range(5):
				var at := Vector2.from_angle(direction.angle()-0.6+i*0.3)*radius*0.65
				draw_line(at-Vector2(5,0),at+Vector2(5,0),Color(0.88,0.97,0.97,fade),1.7,true)
				draw_line(at-Vector2(0,5),at+Vector2(0,5),Color(0.88,0.97,0.97,fade),1.7,true)
		_:
			var shade := Color("bea6cb") if kind in ["blink","potion_pop"] else coral
			draw_arc(Vector2(0,-10),radius*(0.18+ratio*0.82),0,TAU,40,Color(shade,fade*0.8),3.0,true)
			draw_arc(Vector2(0,-10),radius*(0.12+ratio*0.65),0,TAU,36,Color(cream,fade*0.72),2.0,true)
			for i in range(7):
				var at := Vector2.from_angle(i*TAU/7.0)*radius*ratio+Vector2(0,-10)
				draw_circle(at,2.5,Color(cream,fade),true,-1,true)
