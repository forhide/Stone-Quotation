class_name SpellOutcomeResolver
extends RefCounted

var rng := RandomNumberGenerator.new()
var forced: String = ""

func _init() -> void:
	rng.randomize()

func resolve(config: Dictionary) -> String:
	if not forced.is_empty():
		var result := forced
		forced = ""
		return result
	var weights: Array[float] = [float(config.success_weight), float(config.miscast_weight), float(config.overreaction_weight)]
	var total := weights[0] + weights[1] + weights[2]
	assert(total > 0.0 and weights.min() >= 0.0, "Spell weights must be nonnegative and nonzero")
	var roll := rng.randf() * total
	if roll < weights[0]:
		return "success"
	if roll < weights[0] + weights[1]:
		return "miscast"
	return "overreaction"
