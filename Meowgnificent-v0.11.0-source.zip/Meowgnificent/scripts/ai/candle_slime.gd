class_name CandleSlime
extends Node2D

signal defeated(enemy: CandleSlime)
var config: Dictionary
var health: CombatHealth
var target: WizardCat
var bounds: Rect2
var cooldown := 0.0
var hit_flash := 0.0
var time := 0.0
var knockback := Vector2.ZERO
var active := true
var role := "candle"
var phase := "approach"
var phase_time := 0.0
var attack_direction := Vector2.RIGHT
var attack_hit := false
var attack_origin := Vector2.ZERO
var attack_floor_ink: AttackTelegraph
# Smooth HD storybook sprites and the mirrored wing share one GPU texture.
# Atlas resources are reused across rooms; no render-to-texture warmup on arrival.
const ENEMY_ATLAS: Texture2D = preload("res://art/enemies/storybook_familiars.png")
static var _art_textures: Dictionary = {}
var body_root: Node2D
var body_sprite: Sprite2D
var wing_roots: Array[Node2D] = []
var health_track: Line2D
var health_fill: Line2D
var foreground_effects: ForegroundEnemyEffects

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	config = settings
	target = player
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	health.died.connect(func(): defeated.emit(self); queue_free())
	time = position.x
	health.changed.connect(_update_health)

func _physics_process(delta: float) -> void:
	if not active or not is_instance_valid(target) or not target.active or health.current<=0:
		return
	time += delta
	cooldown = maxf(0,cooldown-delta)
	hit_flash = maxf(0,hit_flash-delta)
	var remaining_before_tick := phase_time
	phase_time = maxf(0,phase_time-delta)
	var to_player := target.position-position
	match phase:
		"approach":
			var reach := 230.0 if role=="broom" else (150.0 if role=="bat" else 85.0)
			if to_player.length()<reach and cooldown<=0:
				phase="windup"
				phase_time=warning_duration()
				attack_direction=to_player.normalized()
				attack_origin=position
				attack_hit=false
			else:
				var speed := float(config.speed)*(1.25 if role=="bat" else 0.8 if role=="broom" else 1.0)
				position+=to_player.normalized()*speed*delta
		"windup":
			attack_origin=position
			if phase_time<=0:
				phase="attack"
				phase_time=attack_duration()
		"attack":
			# The last physics tick may only contain part of the dash. Never
			# travel beyond the endpoint promised by its floor warning.
			position+=attack_direction*attack_speed()*minf(delta,remaining_before_tick)
			if not attack_hit and position.distance_to(target.position)<contact_radius():
				target.take_damage(int(config.contact_damage),position)
				attack_hit=true
			if phase_time<=0:
				phase="recover"
				phase_time=0.85
		"recover":
			if phase_time<=0:
				phase="approach"
				cooldown=0.25
	position+=knockback*delta
	position=position.clamp(bounds.position+Vector2.ONE*20,bounds.end-Vector2.ONE*20)
	knockback=knockback.move_toward(Vector2.ZERO,delta*550)
	queue_redraw()

func take_damage(amount: int, direction: Vector2) -> void:
	if health.damage(amount):
		hit_flash=0.15
		knockback=direction*240
		# A hit interrupts the telegraph: a clumsy roll can rescue a bad cast.
		phase="recover"
		phase_time=0.6

func _ready() -> void:
	_add_attack_telegraph()
	if role=="bat":
		for side in [-1,1]:
			var wing := Node2D.new()
			wing.scale.x=side
			wing.position=Vector2(side*7,-31)
			add_child(wing)
			wing_roots.append(wing)
			_add_part(wing,"bat_wing")
	body_root=Node2D.new()
	add_child(body_root)
	body_sprite=_add_part(body_root,role)
	health_track=_health_line(Color("8e7776"))
	health_fill=_health_line(Color("a5c593"))
	_update_health()
	_sync_visuals()
	if has_meta("elite"):
		var insignia := EliteInsignia.new()
		insignia.position=Vector2(0,-106)
		add_child(insignia)
	foreground_effects=ForegroundEnemyEffects.new()
	foreground_effects.enemy=self
	add_child(foreground_effects)

func _add_attack_telegraph() -> void:
	attack_floor_ink=AttackTelegraph.new()
	attack_floor_ink.enemy=self
	# Floor warnings remain below every y-sorted actor, never over its face.
	attack_floor_ink.z_index=-2
	attack_floor_ink.visible=false
	add_child(attack_floor_ink)

func _refresh_attack_telegraph() -> void:
	if attack_floor_ink==null: return
	# Elite size is an art transform; combat still uses room-space pixels.
	# Cancel inherited scale/rotation while retaining this floor layer's z.
	attack_floor_ink.global_transform=Transform2D(0.0,global_position)
	attack_floor_ink.visible=phase in ["windup","attack"]
	if attack_floor_ink.visible: attack_floor_ink.queue_redraw()

func warning_duration() -> float:
	return 0.5 if role=="bat" else 0.72

func attack_duration() -> float:
	return 0.38 if role=="broom" else 0.3

func attack_speed() -> float:
	return 500.0 if role=="broom" else 390.0 if role=="bat" else 210.0

func contact_radius() -> float:
	return float(config.radius)+float(target.config.radius)

func get_attack_preview() -> Dictionary:
	if phase not in ["windup","attack"]: return {}
	var origin := position if phase=="windup" else attack_origin
	var arena := bounds.grow(-20.0)
	var path := AttackTelegraph.dash_path(origin,attack_direction,attack_speed()*attack_duration(),arena)
	for i in range(path.size()): path[i]-=position
	# All warnings describe danger to the player's foot-centre, including
	# their circular collider. Standing just outside a lane is always safe.
	return {"path":path,"radius":contact_radius(),"progress":1.0-clampf(phase_time/warning_duration(),0,1) if phase=="windup" else 1.0,"striking":phase=="attack"}

func _cached_art(key: String) -> Texture2D:
	if _art_textures.has(key): return _art_textures[key]
	var texture := AtlasTexture.new()
	texture.atlas=ENEMY_ATLAS
	texture.region=_atlas_region(key)
	texture.filter_clip=true
	_art_textures[key]=texture
	return texture

func _atlas_region(key: String) -> Rect2:
	match key:
		"broom": return Rect2(691,24,506,672)
		"bat": return Rect2(73,676,565,557)
		"bat_wing": return Rect2(676,769,556,365)
		_: return Rect2(38,60,599,612)

func _art_bounds(key: String) -> Rect2:
	match key:
		"broom": return Rect2(-32,-72,64,82)
		"bat": return Rect2(-18,-29,36,49)
		"bat_wing": return Rect2(-1.5,-25,52,34)
		_: return Rect2(-31,-65,62,70)

func _add_part(parent_node: Node2D, key: String) -> Sprite2D:
	var part := Sprite2D.new()
	part.texture=_cached_art(key)
	part.centered=false
	part.position=_art_bounds(key).position
	part.scale=_art_bounds(key).size/_atlas_region(key).size
	part.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	parent_node.add_child(part)
	return part

func _health_line(color: Color) -> Line2D:
	var line := Line2D.new()
	line.position=Vector2(0,-78)
	line.points=PackedVector2Array([Vector2(-20,0),Vector2(20,0)])
	line.width=3
	line.default_color=color
	line.antialiased=true
	add_child(line)
	return line

func _update_health(_current: int=0, _maximum: int=0) -> void:
	if health_track==null or health==null: return
	var damaged := health.current<health.maximum
	health_track.visible=damaged
	health_fill.visible=damaged
	if damaged:
		health_fill.points=PackedVector2Array([Vector2(-20,0),Vector2(-20+40*float(health.current)/health.maximum,0)])

func _sync_visuals() -> void:
	if body_root==null: return
	body_sprite.self_modulate=Color(1.28,1.18,1.1) if hit_flash>0 else Color.WHITE
	if role=="broom":
		body_root.rotation=attack_direction.x*0.2 if phase=="attack" else sin(time*3)*0.04
		body_root.position=Vector2(0,-3+sin(time*5)*0.7)
		body_root.scale=Vector2(1.04,0.94) if phase=="windup" else Vector2(0.96,1.04) if phase=="attack" else Vector2.ONE
	elif role=="bat":
		var lift := -31+sin(time*8)*4
		body_root.position=Vector2(0,lift)
		body_root.rotation=attack_direction.x*0.10 if phase=="attack" else sin(time*4)*0.035
		for i in range(wing_roots.size()):
			var side := -1.0 if i==0 else 1.0
			wing_roots[i].position=Vector2(side*7,lift)
			wing_roots[i].rotation=side*(sin(time*12)*0.22+(0.22 if phase=="windup" else -0.15 if phase=="attack" else 0.0))
			wing_roots[i].scale=Vector2(side,0.90+sin(time*12)*0.23)
	else:
		body_root.rotation=sin(time*4)*0.045
		var squash := 0.10 if phase=="windup" else -0.06 if phase=="attack" else sin(time*4)*0.025
		body_root.scale=Vector2(1.0+squash,1.0-squash*1.2)

func _draw() -> void:
	# Benchmarks may advance time while AI is inactive; pause itself keeps time frozen.
	_sync_visuals()
	if foreground_effects!=null: foreground_effects.queue_redraw()
	_refresh_attack_telegraph()
	draw_set_transform(Vector2(0,5),0,Vector2(1,0.30))
	draw_circle(Vector2.ZERO,25,Color(0.36,0.31,0.29,0.18))
	draw_set_transform(Vector2.ZERO)
	if role=="candle":
		var flame := body_root.transform*Vector2(sin(time*5)*1.2,-65)
		draw_circle(flame,12+sin(time*9),Color(1,0.81,0.54,0.13))

class EliteInsignia extends Node2D:
	func _draw() -> void:
		# A silhouette marker, not just a tint: important for the final examiner.
		var gold := Color("c39c63")
		draw_colored_polygon(PackedVector2Array([Vector2(-15,0),Vector2(-15,-9),Vector2(-7,-4),Vector2(0,-13),Vector2(7,-4),Vector2(15,-9),Vector2(15,0)]),Color("fff1d4"))
		draw_polyline(PackedVector2Array([Vector2(-15,0),Vector2(-15,-9),Vector2(-7,-4),Vector2(0,-13),Vector2(7,-4),Vector2(15,-9),Vector2(15,0),Vector2(-15,0)]),gold,1.5,true)
		for x in [-9,0,9]:
			draw_circle(Vector2(x,-1),1.3,gold)
		draw_colored_polygon(PackedVector2Array([Vector2(0,3),Vector2(3,6),Vector2(0,9),Vector2(-3,6)]),gold)

class ForegroundEnemyEffects extends Node2D:
	var enemy: CandleSlime

	func _draw() -> void:
		if not is_instance_valid(enemy): return
		if enemy.phase=="recover":
			draw_arc(Vector2(0,-59),12,enemy.time*5,enemy.time*5+4,12,Color("8b859e"),2,true)
		if enemy.role=="candle":
			var flame := enemy.body_root.transform*Vector2(sin(enemy.time*5)*1.2,-65)
			draw_colored_polygon(PackedVector2Array([flame+Vector2(-5,2),flame+Vector2(-4,-4),flame+Vector2(sin(enemy.time*7)*2,-12),flame+Vector2(5,-2),flame+Vector2(4,5)]),Color("f1ba85"))
			draw_circle(flame+Vector2(0,1),2.8,Color("fff1d4"))
		if enemy.hit_flash>0:
			draw_arc(Vector2(0,-20),27,0,TAU,20,Color("e8ad95"),3,true)

