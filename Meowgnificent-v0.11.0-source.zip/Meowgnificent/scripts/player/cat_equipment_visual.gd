class_name CatEquipmentVisual
extends Node2D

var equipment := {"wand":"","collar":"","charm":""}
var attachments: Dictionary = {}
var visual: WizardCatVisual
var revision := 0
var _layouts: Dictionary = {}

func _ready() -> void:
 visual=get_parent() as WizardCatVisual
 texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
 for slot: String in equipment:
  var sprite := Sprite2D.new()
  sprite.name=slot.capitalize()+"Attachment"
  sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
  sprite.visible=false
  attachments[slot]=sprite
  add_child(sprite)
 _refresh_textures()

func set_equipment(value: Dictionary) -> void:
 var next := {"wand":"","collar":"","charm":""}
 for slot: String in next:
  var id := str(value.get(slot,""))
  if EquipmentArt.has_icon(id) and EquipmentArt.slot_for(id)==slot: next[slot]=id
 if next==equipment: return
 equipment=next
 revision+=1
 if is_node_ready(): _refresh_textures()

func _refresh_textures() -> void:
 for slot: String in attachments:
  var sprite: Sprite2D=attachments[slot]
  sprite.texture=EquipmentArt.worn_icon(str(equipment[slot]))
  _layouts[slot]=EquipmentArt.attachment_layout(str(equipment[slot]))
  sprite.visible=sprite.texture!=null
 _process(0)

func _process(_delta: float) -> void:
 if not is_instance_valid(visual) or visual.cat==null: return
 var pose := visual.active_pose
 var facing := visual.mesh_facing if visual.mesh_facing!=0 else 1.0
 scale.x=facing
 # Attachments follow the small weight shift, not an independent hover sine.
 var sway := sin(visual.elapsed*2.8)*0.25
 for slot: String in attachments:
  var sprite: Sprite2D=attachments[slot]
  sprite.visible=sprite.texture!=null and pose!=5
  if not sprite.visible: continue
  var target := Vector2(43,-47)
  var layout: Dictionary=_layouts[slot]
  var extent: Vector2=layout.get("extent",Vector2(40,52))
  var angle: float=float(layout.get("angle",-0.12))
  if slot=="collar":
   target=Vector2(-7,-53)
   angle=0
   if pose==1: target=Vector2(-9,-49)
   elif pose==2: target=Vector2(15,-48)
   elif pose==3: target=Vector2(-10,-63)
   elif pose==4: target=Vector2(-2,-43)
  elif slot=="charm":
   target=Vector2(-24,-114)
   angle=-0.25+sin(visual.elapsed*2.2)*0.05
   if pose==4: target.y+=13
   elif pose==2: target+=Vector2(8,-1)
  else:
   if pose==1: target=Vector2(-43,-82)
   elif pose==2: target=Vector2(60,-68)
   elif pose==3: target=Vector2(54,-25)
   elif pose==4: target=Vector2(45,-32)
   target.y+=sin(visual.elapsed*3.1)*0.35
  sprite.position=target+Vector2(sway,0)+visual.body_offset
  sprite.scale=extent/sprite.texture.get_size()
  sprite.rotation=angle

func appearance_snapshot() -> Dictionary:
 var shown: Dictionary={}
 for slot: String in attachments:
  var sprite: Sprite2D=attachments[slot]
  shown[slot]={"id":equipment[slot],"visible":sprite.visible,"texture":sprite.texture,"position":sprite.position}
 return {"equipment":equipment.duplicate(),"attachments":shown,"revision":revision}
