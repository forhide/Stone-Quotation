class_name GroundedCatGait
extends RefCounted

# Six whole-body drawings use actual travelled distance, not a wall-clock jig.
# Left/right contact/pass/advance poses are ordered as one continuous loop.
const CYCLE_DISTANCE := 96.0
const FRAME_ORDER := [0,3,4,1,5,2]
static func frame_for(distance: float) -> int:
 return FRAME_ORDER[posmod(int(floor(distance/CYCLE_DISTANCE*6.0)),6)]
