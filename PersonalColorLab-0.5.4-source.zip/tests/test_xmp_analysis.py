"""Recorded sidecar evidence, strict XML boundaries and metadata minimization."""
import hashlib
import json
import socket
from pathlib import Path

import pytest

from personal_color_lab.core import xmp_analysis
from personal_color_lab.core.xmp_analysis import analyze_raw_xmp

CRS = xmp_analysis.CAMERA_RAW_NAMESPACE
RDF = xmp_analysis.RDF_NAMESPACE


def _xml(attributes="", body="", prefix="crs"):
    return (
        f'<x:xmpmeta xmlns:x="adobe:ns:meta/">'
        f'<rdf:RDF xmlns:rdf="{RDF}">'
        f'<rdf:Description xmlns:{prefix}="{CRS}" {attributes}>'
        f'{body}</rdf:Description></rdf:RDF></x:xmpmeta>'
    )


def _sources(tmp_path: Path, data: str | bytes):
    raw = tmp_path / "sample.NEF"
    sidecar = tmp_path / "sample.XMP"
    # Deliberately not a decodable photo: metadata extraction does not require
    # a RAW rendering engine and must not claim rendered-image verification.
    raw.write_bytes(b"test RAW bytes\x00not rendered")
    sidecar.write_bytes(data.encode("utf-8") if isinstance(data, str) else data)
    return raw, sidecar


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_records_attribute_and_element_values_with_units_and_provenance(tmp_path, monkeypatch):
    raw, sidecar = _sources(tmp_path, _xml(
        'crs:Exposure2012="+0.70" crs:Contrast2012="-21" crs:Temperature="6200" '
        'crs:Tint="+12.5" crs:ProcessVersion="11.0" crs:CameraProfile="Adobe Color" '
        'crs:HasSettings="True" crs:WhiteBalance="Custom"',
        '<crs:Highlights2012>-53</crs:Highlights2012>'
        '<crs:Shadows2012>36</crs:Shadows2012>'
        '<crs:Whites2012>4</crs:Whites2012><crs:Blacks2012>-16</crs:Blacks2012>'
        '<crs:Texture>12</crs:Texture><crs:Clarity2012>6</crs:Clarity2012>'
        '<crs:Dehaze>8</crs:Dehaze><crs:Vibrance>19</crs:Vibrance>'
        '<crs:Saturation>-6</crs:Saturation>',
    ))
    before = {"original": _hash(raw), "edited": _hash(sidecar)}

    def reject_network(*args, **kwargs):
        raise AssertionError("Sidecar analysis must not use the network")

    monkeypatch.setattr(socket, "socket", reject_network)
    result = analyze_raw_xmp(raw, sidecar)
    assert result["status"] == "ok"
    assert result["source_type"] == "raw_xmp"
    assert result["schema_version"] == 1
    assert result["algorithm_version"] == "0.5.4"
    assert result["parameters"] == {
        "Exposure2012": 0.7, "Contrast2012": -21, "Temperature": 6200,
        "Tint": 12.5, "WhiteBalance": "Custom", "Highlights2012": -53,
        "Shadows2012": 36, "Whites2012": 4, "Blacks2012": -16,
        "Texture": 12, "Clarity2012": 6, "Dehaze": 8,
        "Vibrance": 19, "Saturation": -6,
    }
    assert type(result["parameters"]["Temperature"]) is int
    assert result["parameter_units"]["Exposure2012"] == "ev"
    assert result["parameter_units"]["Temperature"] == "kelvin"
    assert result["parameter_units"]["Tint"] == "slider_points"
    assert result["metadata"] == {
        "ProcessVersion": "11.0", "CameraProfile": "Adobe Color", "HasSettings": True,
    }
    assert result["confidence_scope"] == "recorded_xmp_parameters"
    assert result["provenance"]["exact_xmp_parameters"] is True
    assert result["provenance"]["inferred"] is False
    assert result["provenance"]["raw_decoded"] is False
    assert result["provenance"]["render_equivalence_verified"] is False
    assert result["provenance"]["input_fingerprints"] == before
    assert result["provenance"]["source_identity_verified"] is True
    assert before == {"original": _hash(raw), "edited": _hash(sidecar)}
    json.dumps(result, allow_nan=False)


def test_hsl_grading_sharpness_noise_crop_and_rgb_curves(tmp_path):
    controls = {
        "Sharpness": "48", "SharpenRadius": "0.8", "SharpenDetail": "35",
        "SharpenEdgeMasking": "72", "LuminanceSmoothing": "15",
        "LuminanceNoiseReductionDetail": "52", "ColorNoiseReduction": "26",
        "ColorNoiseReductionSmoothness": "60", "SplitToningShadowHue": "220",
        "SplitToningShadowSaturation": "15", "SplitToningHighlightHue": "42",
        "SplitToningHighlightSaturation": "19", "SplitToningBalance": "-12",
        "ColorGradeMidtoneHue": "44", "ColorGradeMidtoneSat": "7",
        "ColorGradeMidtoneLum": "5", "ColorGradeShadowLum": "-8",
        "ColorGradeHighlightLum": "10", "ColorGradeBlending": "60",
        "ColorGradeGlobalHue": "25", "ColorGradeGlobalSat": "5",
        "ColorGradeGlobalLum": "2", "HasCrop": "true",
        "CropTop": ".1", "CropLeft": ".2", "CropBottom": ".8",
        "CropRight": ".9", "CropAngle": "-1.25", "CropConstrainToWarp": "1",
        "ConvertToGrayscale": "false", "ToneCurveName2012": "Custom",
    }
    for band in ("Red", "Orange", "Yellow", "Green", "Aqua", "Blue", "Purple", "Magenta"):
        for adjustment, value in (("HueAdjustment", "-12"), ("SaturationAdjustment", "-18"), ("LuminanceAdjustment", "7")):
            controls[adjustment + band] = value
    curves = "".join(
        f'<crs:{name}><rdf:Seq><rdf:li>0, 8</rdf:li>'
        f'<rdf:li>100, 90</rdf:li><rdf:li>255, 246</rdf:li></rdf:Seq></crs:{name}>'
        for name in ("ToneCurvePV2012", "ToneCurvePV2012Red", "ToneCurvePV2012Green", "ToneCurvePV2012Blue")
    )
    raw, sidecar = _sources(tmp_path, _xml(
        " ".join(f'crs:{name}="{value}"' for name, value in controls.items()), curves,
    ))
    result = analyze_raw_xmp(raw, sidecar)
    assert set(result["parameters"]) == set(controls)
    assert result["parameters"]["HasCrop"] is True
    assert result["parameters"]["ConvertToGrayscale"] is False
    assert result["parameters"]["CropTop"] == 0.1
    assert result["parameters"]["ColorGradeGlobalLum"] == 2
    assert result["parameter_units"]["CropLeft"] == "normalized_coordinate"
    assert result["parameter_units"]["SharpenRadius"] == "pixels"
    assert len(result["tone_curves"]) == 4
    assert result["tone_curves"]["ToneCurvePV2012Blue"] == [[0, 8], [100, 90], [255, 246]]
    assert result["invalid_parameters"] == []


def test_namespace_identity_matters_not_prefix_or_bare_property_name(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml(
        'settings:Exposure2012="1.25" Exposure2012="4" '
        'xmlns:fake="https://example.invalid/other" fake:Contrast2012="80"',
        '<settings:Saturation>-23</settings:Saturation><fake:Temperature>5500</fake:Temperature>',
        prefix="settings",
    ))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["parameters"] == {"Exposure2012": 1.25, "Saturation": -23}


def test_unknown_and_private_metadata_are_not_retained(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml(
        'crs:Exposure2012=".5" crs:CameraProfile="Creator Secret GPS 51.51" '
        'xmlns:exif="http://ns.adobe.com/exif/1.0/" exif:GPSLatitude="51,30.6N" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" dc:creator="private-person" '
        'crs:UnknownSecret="secret-value"',
        '<crs:Look><rdf:Description crs:Name="private-look" crs:Exposure2012="4" /></crs:Look>'
        '<crs:MaskGroupBasedCorrections><rdf:Seq><rdf:li><rdf:Description '
        'crs:Exposure2012="3" crs:CorrectionName="private-mask" />'
        '</rdf:li></rdf:Seq></crs:MaskGroupBasedCorrections>',
    ))
    result = analyze_raw_xmp(raw, sidecar)
    serialized = json.dumps(result)
    for forbidden in ("51,30.6N", "51.51", "private-person", "private-look", "private-mask", "secret-value", "UnknownSecret", "GPSLatitude"):
        assert forbidden not in serialized
    assert result["parameters"] == {"Exposure2012": 0.5}
    assert result["metadata"] == {"custom_profile_present": True}
    assert "xmp_local_adjustments_not_extracted" in result["warnings"]
    assert "xmp_custom_profile_not_rendered" in result["warnings"]
    assert "xmp_unsupported_settings_ignored" in result["warnings"]


@pytest.mark.parametrize("value", ["NaN", "INF", "-Infinity", "1e900", "5.1", "1,5", "not a number", ""])
def test_malformed_nonfinite_and_out_of_range_values_are_omitted_but_valid_values_survive(tmp_path, value):
    raw, sidecar = _sources(tmp_path, _xml(
        f'crs:Exposure2012="{value}" crs:Texture="18" crs:Tint="-6"',
    ))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["status"] == "ok"
    assert result["parameters"] == {"Texture": 18, "Tint": -6.0}
    assert result["invalid_parameters"] == ["Exposure2012"]
    assert "xmp_invalid_values_ignored" in result["warnings"]
    json.dumps(result, allow_nan=False)


def test_invalid_integer_bool_enum_version_and_inverted_crop_are_not_reported_as_valid(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml(
        'crs:Temperature="6200.25" crs:HasCrop="perhaps" crs:WhiteBalance="Secret" '
        'crs:ProcessVersion="GPS 51.51" crs:CropTop="0.8" crs:CropBottom="0.2" '
        'crs:CropLeft="0.1" crs:CropRight="0.9"',
    ))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["parameters"] == {"CropLeft": 0.1, "CropRight": 0.9}
    assert set(result["invalid_parameters"]) == {
        "Temperature", "HasCrop", "WhiteBalance", "ProcessVersion", "CropTop", "CropBottom",
    }
    assert result["metadata"] == {}
    assert "Secret" not in json.dumps(result)


@pytest.mark.parametrize("body", [
    "",
    '<crs:Unsupported>100</crs:Unsupported>',
    '<crs:Exposure2012>NaN</crs:Exposure2012>',
    '<crs:ProcessVersion>11.0</crs:ProcessVersion><crs:HasSettings>True</crs:HasSettings>',
    '<crs:MaskGroupBasedCorrections><rdf:Description crs:Exposure2012="3" /></crs:MaskGroupBasedCorrections>',
])
def test_no_supported_settings_is_explicit_not_a_successful_style(tmp_path, body):
    raw, sidecar = _sources(tmp_path, _xml(body=body))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["status"] == "no_supported_settings"
    assert result["parameters"] == result["tone_curves"] == {}
    assert result["confidence"] == 0
    assert "xmp_no_supported_settings" in result["warnings"]


@pytest.mark.parametrize("entries", [
    ["0, 0"], ["0, 0", "256, 255"], ["0, NaN", "255, 255"],
    ["0, 0", "0, 40", "255, 255"], ["100, 0", "0, 255"],
    ["0, 0", "255, 255, 255"], ["0.0, 0", "255, 255"],
])
def test_invalid_curve_is_withheld_in_full(tmp_path, entries):
    body = '<crs:ToneCurvePV2012><rdf:Seq>' + "".join(f'<rdf:li>{point}</rdf:li>' for point in entries)
    body += '</rdf:Seq></crs:ToneCurvePV2012>'
    raw, sidecar = _sources(tmp_path, _xml('crs:Vibrance="20"', body))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["parameters"] == {"Vibrance": 20}
    assert result["tone_curves"] == {}
    assert result["invalid_parameters"] == ["ToneCurvePV2012"]


def test_curve_can_have_decreasing_output_for_recorded_creative_curve(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml('crs:ToneCurvePV2012="0, 255; 128, 110; 255, 0"'))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["tone_curves"]["ToneCurvePV2012"] == [[0, 255], [128, 110], [255, 0]]


def test_conflicting_duplicate_global_values_are_withheld(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml(
        'crs:Exposure2012="1.25" crs:Texture="5"',
        '<crs:Exposure2012>2.5</crs:Exposure2012><crs:Exposure2012>1.25</crs:Exposure2012>'
        '<crs:Texture>5</crs:Texture>',
    ))
    result = analyze_raw_xmp(raw, sidecar)
    assert result["parameters"] == {"Texture": 5}
    assert result["invalid_parameters"] == ["Exposure2012"]
    assert "xmp_conflicting_settings_ignored" in result["warnings"]


@pytest.mark.parametrize("encoding", ["utf-8", "utf-16", "utf-16-be", "utf-32", "utf-32-be"])
def test_rejects_dtd_and_external_entities_in_utf_encodings(tmp_path, encoding):
    payload = '<!DOCTYPE x [<!ENTITY secret SYSTEM "file:///private/must-not-read">]>'
    payload += _xml(body='<crs:Exposure2012>&secret;</crs:Exposure2012>')
    raw, sidecar = _sources(tmp_path, payload.encode(encoding))
    with pytest.raises(ValueError, match="DTD and entity"):
        analyze_raw_xmp(raw, sidecar)


def test_rejects_internal_entity_expansion_and_even_non_entity_doctype(tmp_path):
    for declaration in ('<!DOCTYPE x [<!ENTITY a "123">]>', '<!DOCTYPE x>'):
        raw, sidecar = _sources(tmp_path, declaration + _xml('crs:Texture="4"'))
        with pytest.raises(ValueError, match="DTD and entity"):
            analyze_raw_xmp(raw, sidecar)


def test_utf16_sidecar_with_regular_settings_is_supported(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml('crs:Exposure2012="-.75"').encode("utf-16"))
    assert analyze_raw_xmp(raw, sidecar)["parameters"] == {"Exposure2012": -0.75}


def test_rejects_malformed_xml_size_and_depth_limits(tmp_path, monkeypatch):
    raw, sidecar = _sources(tmp_path, "<unclosed>")
    with pytest.raises(ValueError, match="well-formed"):
        analyze_raw_xmp(raw, sidecar)
    sidecar.write_text("<a>" * 66 + "</a>" * 66)
    with pytest.raises(ValueError, match="structure"):
        analyze_raw_xmp(raw, sidecar)
    monkeypatch.setattr(xmp_analysis, "MAX_XMP_BYTES", 20)
    sidecar.write_text("x" * 21)
    with pytest.raises(ValueError, match="size limit"):
        analyze_raw_xmp(raw, sidecar)


def test_rejects_wrong_extension_missing_and_directory_inputs(tmp_path):
    raw, sidecar = _sources(tmp_path, _xml())
    wrong = tmp_path / "photo.jpg"
    wrong.write_bytes(b"jpeg")
    with pytest.raises(ValueError, match="RAW"):
        analyze_raw_xmp(wrong, sidecar)
    with pytest.raises(ValueError, match="XMP"):
        analyze_raw_xmp(raw, wrong)
    with pytest.raises(FileNotFoundError):
        analyze_raw_xmp(tmp_path / "missing.nef", sidecar)
    directory = tmp_path / "directory.dng"
    directory.mkdir()
    with pytest.raises(ValueError, match="RAW"):
        analyze_raw_xmp(directory, sidecar)


@pytest.mark.parametrize("which", ["raw", "xmp"])
def test_rejects_source_changed_while_reading_recorded_settings(tmp_path, monkeypatch, which):
    raw, sidecar = _sources(tmp_path, _xml('crs:Exposure2012=".5"'))
    original = xmp_analysis._read_settings

    def mutate(root):
        result = original(root)
        path = raw if which == "raw" else sidecar
        path.write_bytes(path.read_bytes() + b" ")
        return result

    monkeypatch.setattr(xmp_analysis, "_read_settings", mutate)
    with pytest.raises(ValueError, match="changed during analysis"):
        analyze_raw_xmp(raw, sidecar)


def test_rejects_xmp_changed_between_fingerprinting_and_parse(tmp_path, monkeypatch):
    raw, sidecar = _sources(tmp_path, _xml('crs:Exposure2012=".5"'))
    fingerprint = xmp_analysis.file_fingerprint

    def mutate_after_hash(path):
        digest = fingerprint(path)
        if Path(path) == sidecar:
            sidecar.write_text(_xml('crs:Exposure2012="2"'))
        return digest

    monkeypatch.setattr(xmp_analysis, "file_fingerprint", mutate_after_hash)
    with pytest.raises(ValueError, match="changed during analysis"):
        analyze_raw_xmp(raw, sidecar)
