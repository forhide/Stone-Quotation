# Original sound palette

These 16 short PCM effects were composed and synthesized specifically for
Meowgnificent with `tools/generate_sound_palette.py`. They contain no sampled
recordings or third-party music. Rerunning that script reproduces the files.

Rounded attacks and releases avoid waveform clicks; the default effects level
is soft. All cues last at most half a second. Element cues distinguish warm
flame, a water plop, ice, air, stone, growing wood, electrical fizz and metal.
Other cues mark a fizzle, special cast, hit, hurt, pickup, new gear, equipping
and a cleared area. There is no automatic playback or background music.

Runtime playback uses a fixed pool of eight imported-stream players and
per-cue rate limits. The settings menu persists mute / soft / normal without
replacing language or display preferences.
