extends RefCounted

# Test driver for the real encounter lifecycle. Never changes director state,
# skips a windup, or opens the exit directly. Combat mechanics have their own
# impact tests; route tests remove foes through their normal health signals.
static func arrive_next(room) -> bool:
	if room.encounters.state!="waiting" or room.exit_open: return false
	room.player.position=room.encounters.waypoint()
	room.player.velocity=Vector2.ZERO
	room.player.recoil=Vector2.ZERO
	room.player.invulnerability=10000
	for step in range(40):
		room.encounters.tick(0.1,room.player.position,room.state=="playing")
		if room.encounters.state=="active":
			for enemy in room.enemies: enemy.active=false
			return not room.enemies.is_empty() and not room.exit_open
	return false

static func clear_area(room, through_health: bool=false) -> int:
	var defeated := 0
	for guard in range(10):
		for enemy in room.enemies.duplicate():
			defeated+=1
			if through_health: enemy.health.damage(99999)
			else: enemy.take_damage(99999,Vector2.RIGHT)
		if room.encounters.is_complete(): return defeated
		if not arrive_next(room): return -1000
		room.collect_remaining_loot()
	return -1000

static func reach_boss(room) -> bool:
	for guard in range(10):
		for enemy in room.enemies:
			if enemy is PerfectExaminer: return true
		for enemy in room.enemies.duplicate(): enemy.take_damage(99999,Vector2.RIGHT)
		if not arrive_next(room): return false
		room.collect_remaining_loot()
	return false
