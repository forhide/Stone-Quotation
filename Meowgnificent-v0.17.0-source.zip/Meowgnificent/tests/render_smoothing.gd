extends SceneTree

# Verify interpolation configuration AND actual engine reset notifications on
# teleports. A separate graphical10Hz probe measures visible substep movement.
class ResetSpy extends Node:
	var resets := 0
	func _notification(what: int) -> void:
		if what==Node.NOTIFICATION_RESET_PHYSICS_INTERPOLATION: resets+=1
var checks := 0
var failures := 0
var room
var profile_path := "/tmp/meow-render-smoothing-%d.json" % OS.get_process_id()
func _initialize() -> void: call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(n: int=2) -> void:
	for i in range(n): await process_frame
func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames(4)
	room=current_scene
	room.begin_or_restart()
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.spells.set_physics_process(false)
	room.skills.set_physics_process(false)
	room.player.invulnerability=10000
	for enemy in room.enemies: enemy.active=false
	check(is_physics_interpolation_enabled(),"the running scene tree actually enables physics interpolation")
	check(Engine.max_fps==0 and int(ProjectSettings.get_setting("display/window/vsync/vsync_mode"))==1,"VSync can follow the display without a competing60FPS application cap")
	check(room.player.is_physics_interpolated_and_enabled() and room.actors.is_physics_interpolated_and_enabled(),"the moving cat inherits interpolation through its real actor parent")
	check(not room.camera.is_physics_interpolated() and room.camera.position_smoothing_enabled,"the camera keeps one render-time smoothing path instead of double interpolation")
	check(not room.player.visual.is_physics_interpolated() and not room.player.visual.equipment_visual.is_physics_interpolated(),"render-driven body and worn-equipment rigs retain their smooth parent while avoiding local interpolation delay")
	check(not room.markers.is_physics_interpolated(),"render-time shop gestures and exit reveals are not quantized to physics updates")
	var original_window_size := root.size
	root.size=Vector2i(2560,1600)
	await frames(2)
	check(room.background_viewport.size==Vector2i(3840,2400) and room.background_viewport.size_2d_override==Vector2i(1280,800),"a 2x window repaints the enlarged world at the bounded source-art resolution")
	check((room.background.scale*Vector2(room.background_viewport.size)-Vector2(2048,1280)).length()<0.001,"a resized cached backdrop still covers the full enlarged world")
	root.size=Vector2i(5120,3200)
	await frames(2)
	check(room.background_viewport.size==Vector2i(3840,2400),"background cache allocation stays bounded at 3x on displays larger than4K")
	root.size=original_window_size
	await frames(2)
	check(room.background_viewport.size==WorldLayout.cache_pixels(original_window_size) and room.background.scale==WorldLayout.cache_scale(WorldLayout.cache_pixels(original_window_size)),"returning to the normal window restores the enlarged 2048px cache without compounded scaling")
	var copy := BasicMagic.definition("water")
	var expected := BasicMagic.color("water")
	copy.color="000000"
	check(BasicMagic.color("water")==expected and str(BasicMagic.definition("water").color)!="000000","UI definition copies cannot mutate the cached projectile color")
	var spy := ResetSpy.new()
	room.player.add_child(spy)
	var before := spy.resets
	room.load_sector(1)
	check(spy.resets>before and room.player.position==WorldLayout.point(WorldLayout.ENTRY),"loading the next room resets actual interpolation history at the new entrance")
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.skills.set_physics_process(false)
	for enemy in room.enemies: enemy.active=false
	# Preserve teleport interpolation coverage for the supported legacy blink
	# mechanic; the current stone weapon now correctly casts Stone Quake.
	room.run.catalog["hopscotch_wand"].skill_id="blink_burst"
	room.run.add_item("hopscotch_wand")
	room.equip_gear("hopscotch_wand")
	room.player.position=Vector2(500,450)
	room.player.reset_physics_interpolation()
	var origin: Vector2=room.player.position
	before=spy.resets
	room.skills.cooldown_remaining=0
	room.skills.resolver.forced="success"
	var accepted: bool=room.skills.cast(Vector2.RIGHT)
	check(accepted and room.player.position.distance_to(origin)>150 and spy.resets>before,"the real blink moves the cat and resets its old transform instead of drawing a trail across the room")
	var shot := SpellProjectile.new()
	shot.room=room
	shot.bounds=room.bounds
	shot.position=Vector2(300,450)
	shot.speed=0
	room.projectiles.add_child(shot)
	shot.set_physics_process(false)
	check(shot.is_physics_interpolated_and_enabled(),"real basic projectiles share the interpolated world-motion path")
	var impact := BasicMagicImpact.new()
	impact.element="ice"
	room.projectiles.add_child(impact)
	await frames(2)
	check(is_instance_valid(impact) and impact.age>0 and not impact.is_physics_interpolated(),"a short non-damaging impact animates on render time")
	room.set_running(false)
	var age: float=impact.age
	await frames(8)
	check(is_instance_valid(impact) and impact.age==age,"the actual projectile-root pause freezes the render-time impact")
	room.set_running(true)
	for enemy in room.enemies: enemy.active=false
	await frames(2)
	check(not is_instance_valid(impact) or impact.age>age,"a cosmetic impact resumes or finishes naturally after the menu closes")
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("RENDER SMOOTHING RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
