extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# Exercise the real final-room spawn and its expression changes while the
# existing grimoire suite covers the complete prediction/beam combat rules.
var checks := 0
var failures := 0
var room
var previous_skip := ""

func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
 checks+=1
 if ok: print("PASS: "+label)
 else:
  failures+=1
  push_error("FAIL: "+label)
func frames(count: int=2) -> void:
 for i in range(count):
  await physics_frame
  await process_frame

func run() -> void:
 previous_skip=OS.get_environment("MEOW_SKIP_STORY")
 OS.set_environment("MEOW_SKIP_STORY","1")
 change_scene_to_file("res://scenes/main.tscn")
 await frames()
 room=current_scene
 room.begin_or_restart()
 room.load_sector(7)
 check(RouteFixture.reach_boss(room),"actual archive seals lead to the final book encounter")
 room.set_running(false)
 await frames()
 var boss: PerfectExaminer
 for enemy in room.enemies:
  if enemy is PerfectExaminer: boss=enemy
 check(boss!=null,"the real final expedition room spawns the book antagonist")
 if boss==null:
  await finish()
  return
 check(str(boss.get_meta("character_identity",""))=="sentient_grimoire","runtime identity names the book itself rather than a fox stand-in")
 check(boss.EXAMINER_ART==GrimoireArt.SHEET and boss.EXAMINER_ART!=AnimalCast.SHEET,"final battle uses the shared sentient-book atlas, not the supporting animal cast")
 check(boss.art_frames.size()==4,"four authored expressions are imported for the book cover and pages")
 check(boss.body_sprite.texture==boss.art_frames[0] and boss.art_pose==0,"a protected idle grimoire wears its composed cover expression")
 check(is_equal_approx(boss.body_sprite.scale.y*boss.EXAMINER_POSES[0].size.y,164.0),"calm art retains the reviewed164px footprint before elite scaling")
 check(is_equal_approx(boss.body_sprite.position.y+boss.body_sprite.scale.y*boss.EXAMINER_POSES[0].size.y,3.0),"the book retains the same collision-origin and visual-foot anchor")
 check(boss.health.maximum==180 and boss.barrier_active,"new appearance preserves180HP and the initial prediction barrier")
 var count_before := boss.blocked_spells
 boss.take_spell_damage(20,Vector2.RIGHT,"success")
 check(boss.health.current==180 and boss.blocked_spells==count_before+1,"the book visibly predicts a controlled spell without losing health")
 boss.phase="windup"
 boss.phase_time=0.8
 boss._sync_art_pose()
 check(boss.art_pose==2 and boss.body_sprite.texture==boss.art_frames[2],"beam anticipation opens angry pages before the attack")
 boss.take_spell_damage(12,Vector2.RIGHT,"miscast")
 check(boss.health.current==168 and is_equal_approx(boss.vulnerability_time,4.0),"an actual accident still damages the book and opens exactly four seconds")
 check(boss.art_pose==1 and boss.body_sprite.texture==boss.art_frames[1],"a shield break immediately fans out the shocked book pages")
 var frozen := boss.presentation_timers_snapshot()
 var frozen_pose := boss.art_pose
 await frames(6)
 check(boss.presentation_timers_snapshot()==frozen and boss.art_pose==frozen_pose,"paused gameplay freezes the book's reaction and shield presentation together")
 boss.barrier_break_age=1.1
 boss.phase="recover"
 boss.health.current=50
 boss._sync_art_pose()
 check(boss.art_pose==3 and boss.body_sprite.texture==boss.art_frames[3],"low-health exposed book uses its scuffed, exhausted cover expression")
 boss.vulnerability_time=0
 boss.phase="approach"
 boss._sync_art_pose()
 check(boss.art_pose==0,"reformed protection closes and composes the book again")
 for pose: String in ["calm","angry","shocked","damaged"]:
  var texture: AtlasTexture=GrimoireArt.icon(pose)
  var region: Rect2=GrimoireArt.region(pose)
  check(texture.atlas==GrimoireArt.SHEET and texture.region==region and texture.filter_clip,"story portraits share the exact filtered book pose used by combat: "+pose)
  check(GrimoireArt.icon(pose)==texture,"repeated book portraits reuse one cached atlas texture: "+pose)
  check(Rect2(Vector2.ZERO,GrimoireArt.SHEET.get_size()).encloses(region),"the complete page silhouette stays inside its authored atlas region: "+pose)
 check(GrimoireArt.icon("alert")==GrimoireArt.icon("angry") and GrimoireArt.icon("unknown")==GrimoireArt.icon("calm"),"dialogue alert and unknown-pose fallbacks resolve to safe book expressions")
 await finish()

func finish() -> void:
 if is_instance_valid(current_scene): current_scene.queue_free()
 await frames()
 if previous_skip.is_empty(): OS.unset_environment("MEOW_SKIP_STORY")
 else: OS.set_environment("MEOW_SKIP_STORY",previous_skip)
 print("GRIMOIRE CHARACTER RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
