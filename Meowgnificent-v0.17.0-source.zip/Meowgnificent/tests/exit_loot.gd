extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# User-facing exit timing and forgiving pickups through the actual room. AI is
# frozen so these tests measure route/loot actions, not elapsed fight timing.
var checks := 0
var failures := 0
var room
var profile_path := ""
var previous_profile := ""
var previous_skip := ""
var had_profile := false
var had_skip := false

func _initialize() -> void: call_deferred("run")

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(count: int=2) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func freeze_world() -> void:
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.player.invulnerability=10000
	room.spells.set_physics_process(false)
	room.skills.set_physics_process(false)
	room.markers.set_process(false)
	for enemy in room.enemies:
		enemy.active=false
		enemy.set_physics_process(false)

func clear_loot() -> void:
	for pickup in room.loot:
		if is_instance_valid(pickup): pickup.free()
	room.loot.clear()

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.physical_keycode=code
	event.pressed=true
	room._unhandled_key_input(event)

func view() -> Dictionary:
	room.markers.update_visuals()
	return room.markers.exit_snapshot()

func reset_bag() -> void:
	room.run.inventory.clear()
	room.run.add_item("practice_wand")
	room.run.equipment={"wand":"practice_wand","collar":"","charm":""}
	room.profile.upgrades["magnet"]=0
	room.apply_equipment()

func run() -> void:
	had_profile=OS.has_environment("MEOW_PROFILE_PATH")
	had_skip=OS.has_environment("MEOW_SKIP_STORY")
	previous_profile=OS.get_environment("MEOW_PROFILE_PATH")
	previous_skip=OS.get_environment("MEOW_SKIP_STORY")
	profile_path="/tmp/meow-exit-loot-%d-%d.json" % [OS.get_process_id(),Time.get_ticks_usec()]
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	OS.set_environment("MEOW_SKIP_STORY","1")
	change_scene_to_file("res://scenes/main.tscn")
	await frames()
	room=current_scene
	freeze_world()
	var initial := view()
	check(initial.has_all(["visible","progress","stage","unlocked"]),"the live gate reports the same reveal state used by its presentation")
	check(not bool(initial.visible) and not bool(initial.unlocked),"the start screen has no premature exit gate")
	room.begin_or_restart()
	freeze_world()
	var before := view()
	check(room.state=="playing" and not room.exit_open and not bool(before.visible),"an uncleared tutorial starts without an exit gate or exit prompt")
	room.player.position=WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)
	key(KEY_E)
	key(KEY_ENTER)
	check(room.run.stage_index==0 and not room.exit_open and not bool(view().visible),"E and Enter cannot use the absent exit before the fight is cleared")
	while room.enemies.size()>1: room.enemies[0].take_damage(99999,Vector2.RIGHT)
	check(not bool(view().visible) and not room.exit_open,"the exit still waits while one actual foe remains")
	room.enemies[0].take_damage(99999,Vector2.RIGHT)
	check(not room.exit_open and not bool(view().visible) and room.encounters.state=="waiting","clearing only the first group reveals the next seal, not the exit")
	check(RouteFixture.arrive_next(room),"approaching the seal completes the arrival warning and spawns the next group")
	check(RouteFixture.clear_area(room)==5,"the last tutorial group is defeated through actual combat signals")
	var opened := view()
	check(room.exit_open and bool(opened.visible) and bool(opened.unlocked) and room.enemies.is_empty(),"the last real defeat reveals the usable onward gate")
	check(float(opened.progress)<1.0,"a newly revealed gate begins its short arrival instead of appearing as a stale open prop")
	room.markers._process(0.2)
	var progressing := view()
	check(float(progressing.progress)>float(opened.progress) and float(progressing.progress)<1.0,"the gate reveal advances smoothly while play continues")
	room.set_running(false)
	var paused := view()
	room.markers._process(1.0)
	check(is_equal_approx(float(view().progress),float(paused.progress)),"pausing freezes the exit's reveal rather than consuming it behind a menu")
	room.set_running(true)
	room.markers._process(1.0)
	check(is_equal_approx(float(view().progress),1.0),"the complete gate stays fully visible after its short reveal")
	room.player.position=WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)
	key(KEY_E)
	await frames()
	freeze_world()
	check(room.run.stage_index==1 and room.state=="playing" and not room.exit_open and not bool(view().visible),"E at the new gate enters the next fight and removes the previous exit")
	clear_loot()
	room.load_sector(3)
	await frames()
	freeze_world()
	check(room.enemies.is_empty() and room.exit_open and bool(view().visible),"a peaceful shop has its already-available exit without waiting for nonexistent enemies")
	room.load_sector(0)
	await frames()
	freeze_world()
	clear_loot()
	reset_bag()
	room.player.position=Vector2(640,450)
	check(is_equal_approx(room.pickup_radius,128.0) and is_equal_approx(CharacterStats.for_room(room).pickup_radius,128.0),"the actual base attraction and its equipment preview both use the wider 128-pixel reach")
	check(is_equal_approx(LootPickup.COLLECT_RADIUS,52.0),"collection no longer requires matching the old 30-pixel centre")
	for kind in ["gold","gear","food"]:
		clear_loot()
		room.player.health.current=room.player.health.maximum-40
		var pickup: LootPickup=room.spawn_pickup(kind,room.player.position+Vector2(90,0),9 if kind=="gold" else 20,"crooked_ash_wand" if kind=="gear" else "")
		var origin: Vector2=pickup.position
		var gold_before: int=room.run.gold
		var count_before: int=room.run.inventory.size()
		var health_before: int=room.player.health.current
		room.update_loot(0.05)
		check(room.loot.has(pickup) and pickup.position.distance_to(room.player.position)<origin.distance_to(room.player.position) and pickup.position!=room.player.position,"walking nearby attracts the real "+kind+" drop smoothly instead of requiring exact contact")
		room.update_loot(0.2)
		var credited: bool=room.run.gold==gold_before+9 if kind=="gold" else room.run.inventory.size()==count_before+1 if kind=="gear" else room.player.health.current==health_before+20
		check(not room.loot.has(pickup) and credited,"the attracted "+kind+" is collected by its normal economy/health action")
		check(not room.collect_pickup(pickup),"the collected "+kind+" cannot be credited twice")
	clear_loot()
	var near_gear: LootPickup=room.spawn_pickup("gear",room.player.position+Vector2(55,0),0,"loose_feather")
	room.update_loot(0.0)
	check(room.loot.has(near_gear),"a 55-pixel gear drop begins outside the generous collection edge")
	room.update_loot(0.01)
	check(not room.loot.has(near_gear) and room.run.inventory.has("loose_feather"),"a tiny step of attraction collects nearby gear without pixel-perfect steering")
	for kind in ["gold","gear","food"]:
		clear_loot()
		room.player.health.current=room.player.health.maximum-40
		var boundary: LootPickup=room.spawn_pickup(kind,room.player.position+Vector2(52,0),3 if kind=="gold" else 20,"linen_star_collar" if kind=="gear" else "")
		room.update_loot(0.0)
		check(not room.loot.has(boundary),"the 52-pixel collection edge is inclusive for "+kind)
	for kind in ["gold","gear","food"]:
		clear_loot()
		room.player.health.current=room.player.health.maximum-40
		var outside: LootPickup=room.spawn_pickup(kind,room.player.position+Vector2(129,0),3 if kind=="gold" else 20,"linen_star_collar" if kind=="gear" else "")
		var origin: Vector2=outside.position
		room.update_loot(0.25)
		check(room.loot.has(outside) and outside.position==origin,"the wider attraction still has a real outer boundary for "+kind)
	clear_loot()
	room.profile.upgrades["magnet"]=3
	room.apply_equipment()
	var legacy_gold: LootPickup=room.spawn_pickup("gold",room.player.position+Vector2(150,0),4)
	var legacy_origin: Vector2=legacy_gold.position
	room.update_loot(0.01)
	check(is_equal_approx(room.pickup_radius,152.0) and legacy_gold.position!=legacy_origin,"permanent magnet ranks still extend actual attraction beyond the new base")
	clear_loot()
	room.run.add_item("moonlit_yarn")
	room.equip_gear("moonlit_yarn")
	var bonus_gear: LootPickup=room.spawn_pickup("gear",room.player.position+Vector2(170,0),0,"linen_star_collar")
	var bonus_origin: Vector2=bonus_gear.position
	room.update_loot(0.01)
	check(is_equal_approx(room.pickup_radius,176.0) and bonus_gear.position!=bonus_origin and is_equal_approx(CharacterStats.for_room(room).pickup_radius,176.0),"gear and permanent reach bonuses combine for actual equipment drops as well as gold")
	clear_loot()
	reset_bag()
	room.player.health.current=room.player.health.maximum-40
	var paused_drops: Array[LootPickup]=[]
	for kind in ["gold","gear","food"]:
		paused_drops.append(room.spawn_pickup(kind,room.player.position+Vector2(90,0),4 if kind=="gold" else 20,"crooked_ash_wand" if kind=="gear" else ""))
	room.open_inventory()
	var points: Array[Vector2]=[]
	var ages: Array[float]=[]
	for pickup in paused_drops:
		points.append(pickup.position)
		ages.append(pickup.age)
	room._physics_process(1.0)
	var paused_unchanged := true
	for i in range(paused_drops.size()): paused_unchanged=paused_unchanged and paused_drops[i].position==points[i] and paused_drops[i].age==ages[i]
	check(paused_unchanged,"inventory pause freezes the animation and attraction of all three drop types")
	room.close_panel()
	freeze_world()
	room._physics_process(0.05)
	var resumed := true
	for i in range(paused_drops.size()): resumed=resumed and room.loot.has(paused_drops[i]) and paused_drops[i].position!=points[i] and paused_drops[i].age>ages[i]
	check(resumed,"resuming lets each nearby drop continue its normal smooth approach")
	clear_loot()
	room.player.health.current=room.player.health.maximum
	var unused_food: LootPickup=room.spawn_pickup("food",room.player.position+Vector2(90,0),20)
	var food_origin: Vector2=unused_food.position
	room.update_loot(0.4)
	check(room.loot.has(unused_food) and unused_food.position==food_origin and room.player.health.current==room.player.health.maximum,"unneeded food stays on the floor without drifting or being wasted at full health")
	room.player.health.current-=40
	room.update_loot(0.4)
	check(not room.loot.has(unused_food) and room.player.health.current==room.player.health.maximum-20,"the same saved food becomes attractable when healing is needed")
	clear_loot()
	room.run.inventory.clear()
	room.run.equipment={"wand":"","collar":"","charm":""}
	for i in range(ExpeditionRun.INVENTORY_LIMIT): room.run.add_item("loose_feather")
	room.apply_equipment()
	var full_far: LootPickup=room.spawn_pickup("gear",room.player.position+Vector2(90,0),0,"crooked_ash_wand")
	var full_origin: Vector2=full_far.position
	room.update_loot(0.2)
	check(room.loot.has(full_far) and full_far.position==full_origin and room.run.inventory.size()==18,"a full bag leaves distant equipment in place instead of pulling an uncollectible drop under the cat")
	var full_near: LootPickup=room.spawn_pickup("gear",room.player.position+Vector2(50,0),0,"crooked_ash_wand")
	room.update_loot(0.0)
	check(room.loot.has(full_near) and full_near.has_meta("bag_warning") and room.run.inventory.size()==18,"a nearby full-bag drop stays recoverable and explains the rejection")
	room.hud.incident_time=0.37
	room.update_loot(0.0)
	check(is_equal_approx(room.hud.incident_time,0.37),"remaining near a rejected item does not repeat its bag-full notice every frame")
	var full_gold_before: int=room.run.gold
	var full_gold: LootPickup=room.spawn_pickup("gold",room.player.position+Vector2(90,0),7)
	room.update_loot(0.3)
	check(not room.loot.has(full_gold) and room.run.gold==full_gold_before+7 and room.loot.has(full_far),"full equipment capacity never prevents collecting nearby Crowns")
	room.loot.erase(full_near)
	full_near.free()
	room.run.inventory.remove_at(room.run.inventory.size()-1)
	room.update_loot(0.3)
	check(not room.loot.has(full_far) and room.run.inventory.size()==18 and room.run.inventory.has("crooked_ash_wand"),"making one bag slot free makes the preserved drop collectable again")
	clear_loot()
	reset_bag()
	room.load_sector(3)
	await frames()
	freeze_world()
	room.player.position=Vector2(640,450)
	room.player.health.current=room.player.health.maximum-35
	var carried_gold: int=room.run.gold
	var carried_hp: int=room.player.health.current
	room.spawn_pickup("gold",room.player.position+Vector2(500,0),11)
	room.spawn_pickup("gear",room.player.position+Vector2(400,0),0,"brass_bell_collar")
	room.spawn_pickup("food",room.player.position+Vector2(300,0),20)
	check(room.advance_sector(),"the normal completed-stage action still accepts an onward transition")
	await frames()
	freeze_world()
	check(room.run.stage_index==4 and room.run.gold==carried_gold+11 and room.run.inventory.has("brass_bell_collar") and room.player.health.current==carried_hp+20 and room.loot.is_empty(),"leaving a completed stage preserves the existing automatic sweep of distant usable loot")
	check(not bool(view().visible),"the next uncleared fight does not inherit the shop's visible gate")
	# Full bags must not silently erase equipment during the onward sweep.
	room.load_sector(3)
	await frames()
	freeze_world()
	clear_loot()
	room.run.inventory.clear()
	for i in range(ExpeditionRun.INVENTORY_LIMIT): room.run.add_item("loose_feather")
	var left: LootPickup=room.spawn_pickup("gear",Vector2(1000,420),0,"silverthorn_wand")
	check(not room.advance_sector() and room.run.stage_index==3 and room.loot.has(left),"full-bag departure keeps the dropped equipment and asks before leaving it")
	room.open_inventory()
	check(room.departure_gear_signature.is_empty(),"opening the satchel cancels the previous leave-equipment confirmation")
	room.close_panel()
	check(not room.advance_sector() and room.run.stage_index==3,"returning from the satchel cannot accidentally confirm an old departure")
	room.run.discard_item("loose_feather")
	check(room.advance_sector() and room.run.inventory.has("silverthorn_wand"),"making room lets the normal exit collect the preserved equipment")
	await frames()
	freeze_world()
	room.load_sector(3)
	await frames()
	freeze_world()
	clear_loot()
	room.spawn_pickup("gear",Vector2(1000,420),0,"silverthorn_wand")
	check(not room.advance_sector(),"a new full-bag departure has a fresh warning")
	room.departure_warning_until_msec=0
	check(not room.advance_sector() and room.run.stage_index==3,"an expired departure warning cannot silently confirm a much later exit")
	room.spawn_pickup("gear",Vector2(1050,420),0,"moss_bud_staff")
	check(not room.advance_sector() and room.run.stage_index==3,"changed remaining drops require a fresh deliberate choice")
	check(room.advance_sector() and room.run.stage_index==4,"a repeated departure with the same remaining gear intentionally leaves it behind")
	await frames()
	freeze_world()
	room.load_sector(7)
	await frames()
	freeze_world()
	check(not bool(view().visible) and not room.exit_open,"the final fight also begins without an onward exit")
	check(RouteFixture.clear_area(room)==18,"the final area requires its two defender groups and boss group")
	check(room.state=="cleared" and room.exit_open and not bool(view().visible),"final victory presents its ending/result instead of a gate to a nonexistent ninth area")
	await finish()

func finish() -> void:
	if is_instance_valid(current_scene): current_scene.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	if had_profile: OS.set_environment("MEOW_PROFILE_PATH",previous_profile)
	else: OS.unset_environment("MEOW_PROFILE_PATH")
	if had_skip: OS.set_environment("MEOW_SKIP_STORY",previous_skip)
	else: OS.unset_environment("MEOW_SKIP_STORY")
	print("EXIT LOOT RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
