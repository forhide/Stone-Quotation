extends SceneTree

const RunModel = preload("res://scripts/systems/expedition_run.gd")

var checks := 0
var failures := 0

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var model := RunModel.new()
	check(model.catalog.size()==85,"catalog has85 distinct equipment pieces")
	check(model.gold==0 and model.inventory.is_empty() and model.equipment.values()==["","",""],"new expedition begins with empty bag, slots and wallet")
	var base := model.stats()
	check(base.max_hp_bonus==0 and base.spell_damage_bonus==0 and is_equal_approx(base.spell_cooldown_multiplier,1.0),"empty slots preserve base combat stats")
	var catalog_valid := true
	for id: String in model.catalog:
		var item := model.item_info(id)
		catalog_valid=catalog_valid and model.SLOTS.has(item.slot) and int(item.price)>0 and not str(item.description).is_empty()
	check(catalog_valid,"every catalog item has a valid slot, price and description")
	var copy := model.item_info("crooked_ash_wand")
	copy.stats.spell_damage_bonus=999
	check(model.item_info("crooked_ash_wand").stats.spell_damage_bonus==5,"UI item descriptions cannot mutate catalog stats")
	check(model.item_info("missing").is_empty() and not model.add_item("missing") and not model.equip_item("missing"),"unknown items are rejected without granting stats")
	model.add_gold(40)
	model.add_gold(-100)
	check(model.gold==40 and model.collected_gold==40,"gold drops count income and ignore negative additions")
	var offers := model.shop_offers(0)
	check(offers.size()==4 and offers[3].id=="sardine_tin","shop offers three equipment slots and one heal")
	# Transaction and modifier assertions below use known catalog fixtures.
	# Randomized stock is independently checked for tier/slot/price validity.
	for index in range(2):
		var id := "crooked_ash_wand" if index==0 else "brass_bell_collar"
		var item := model.item_info(id)
		offers[index]={"id":id,"kind":"gear","name":str(item.name),"price":int(item.price),"sold":false}
	var bought := model.purchase(offers[0])
	check(bought.ok and bought.item_id=="crooked_ash_wand" and model.gold==12 and model.inventory==["crooked_ash_wand"] and offers[0].sold,"gear purchase charges once and transfers one item")
	check(model.equipment.wand=="" and model.stats().spell_damage_bonus==0,"purchased gear waits in the bag until equipped")
	var gold_before: int = model.gold
	var stock_before: int = model.inventory.size()
	check(not model.purchase(offers[0]).ok and model.gold==gold_before and model.inventory.size()==stock_before,"sold stock cannot be bought twice")
	check(not model.purchase(offers[1]).ok and not offers[1].sold and model.gold==gold_before,"insufficient funds preserve wallet and shop stock")
	model.add_gold(100)
	var forged := {"id":"moonlit_yarn","kind":"gear","price":0,"sold":false}
	gold_before=model.gold
	check(not model.purchase(forged).ok and not forged.sold and model.gold==gold_before,"invalid free or underpriced offers do not grant gear")
	forged={"id":"missing","kind":"gear","price":1,"sold":false}
	check(not model.purchase(forged).ok and model.gold==gold_before,"invalid catalog references never charge gold")
	check(model.equip_item("crooked_ash_wand") and model.stats().spell_damage_bonus==5,"equipping a wand applies its spell damage bonus")
	model.add_item("crooked_ash_wand")
	model.equip_item("crooked_ash_wand")
	check(model.stats().spell_damage_bonus==5,"duplicate copies and repeated equip do not stack a slot")
	model.add_item("cinderfork_wand")
	model.equip_item("cinderfork_wand")
	check(model.stats().spell_damage_bonus==10 and model.inventory.has("crooked_ash_wand") and model.inventory.size()==3,"swapping wands replaces bonuses and preserves owned gear")
	check(is_equal_approx(model.stats().spell_cooldown_multiplier,1.12),"slower recharge tradeoff is represented as a multiplier")
	model.add_item("velvet_bell_collar")
	model.equip_item("velvet_bell_collar")
	model.add_item("moonlit_yarn")
	model.equip_item("moonlit_yarn")
	var combined := model.stats()
	check(combined.max_hp_bonus==30 and combined.speed_bonus==18 and combined.pickup_radius_bonus==24,"three slots combine health, speed and pickup reach")
	check(is_equal_approx(combined.spell_cooldown_multiplier,1.12*0.95) and is_equal_approx(combined.roll_cooldown_multiplier,0.8),"cooldown modifiers multiply without changing spell outcome weights")
	check(model.unequip_slot("wand") and model.stats().spell_damage_bonus==0 and model.inventory.size()==5,"unequipping removes bonuses without deleting the item")
	check(not model.unequip_slot("missing") and not model.unequip_slot("wand"),"invalid and empty slot removals are harmless")
	var healer := model.shop_offers(1)[3]
	gold_before=model.gold
	var heal_result := model.purchase(healer)
	check(heal_result.ok and heal_result.heal==35 and heal_result.item_id=="" and model.gold==gold_before-12 and healer.sold,"healing purchase returns health amount and consumes one stock")
	var stocked := true
	for tier in range(3):
		var tier_offers := model.shop_offers(tier)
		var slots := []
		for offer in tier_offers:
			if offer.kind=="gear":
				var info := model.item_info(offer.id)
				slots.append(info.slot)
				stocked=stocked and int(info.tier)==tier and offer.price==info.price
		stocked=stocked and slots==["wand","collar","charm"]
	check(stocked,"each shop tier stocks all three valid slots at catalog prices")
	check(model.droppable_items(0).size()==28 and model.droppable_items(1).size()==57 and model.droppable_items(2).size()==85,"drop pools expand28→57→85 as the expedition deepens")
	var fresh := RunModel.new()
	fresh.add_gold(1000)
	for i in range(model.INVENTORY_LIMIT): fresh.add_item("loose_feather")
	var full_offer := fresh.shop_offers(0)[0]
	gold_before=fresh.gold
	check(not fresh.add_item("crooked_ash_wand") and not fresh.purchase(full_offer).ok and not full_offer.sold and fresh.gold==gold_before and fresh.inventory.size()==18,"full bag rejects drops and purchases atomically")
	check(fresh.purchase(fresh.shop_offers(0)[3]).ok,"healing remains purchasable with a full equipment bag")
	fresh.equip_item("loose_feather")
	check(not fresh.discard_item("loose_feather") and fresh.inventory.size()==18 and fresh.equipment.charm=="loose_feather","discard never removes worn gear, even when the bag contains duplicate copies")
	fresh.unequip_slot("charm")
	var before_discard_gold := fresh.gold
	check(fresh.discard_item("loose_feather") and fresh.inventory.size()==17 and fresh.inventory.count("loose_feather")==17 and fresh.gold==before_discard_gold,"discarding an unworn item removes one copy and creates a bag slot without granting money")
	check(not fresh.discard_item("missing") and fresh.purchase(full_offer).ok and fresh.inventory.size()==18,"unknown discard requests do nothing and freed capacity accepts the previously blocked purchase")
	var reset := RunModel.new()
	check(reset.gold==0 and reset.stage_index==0 and reset.enemies_defeated==0 and reset.collected_gold==0 and reset.inventory.is_empty(),"a new run does not inherit previous currency, progression or gear")
	print("ECONOMY RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
