extends SceneTree

# Exercise the actual moving contact point and its cosmetic growth history.
# A vine's old stem must not turn into an invisible extra damage collider.
class ProbeHealth extends RefCounted:
 var current := 1000
class ProbeFoe extends Node2D:
 var health := ProbeHealth.new()
 var config := {"radius":18.0}
 var knockback := Vector2.ZERO
 func take_damage(amount: int, direction: Vector2) -> void:
  health.current-=amount
  knockback=direction*200
class ProbeRoom extends Node2D:
 var enemies: Array = []
 var props: Array = []
 var skills: Node
 var projectiles := Node2D.new()
 func _ready() -> void: add_child(projectiles)

var checks := 0
var failures := 0
var room: ProbeRoom
func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)

func shot_at(point: Vector2) -> SpellProjectile:
 var shot := SpellProjectile.new()
 shot.element="leaf"
 shot.room=room
 shot.bounds=Rect2(-1000,-1000,4000,4000)
 shot.position=point
 shot.speed=500.0
 room.projectiles.add_child(shot)
 shot.set_physics_process(false)
 shot.set_process(false)
 return shot

func run() -> void:
 room=ProbeRoom.new()
 root.add_child(room)
 var fine := shot_at(Vector2(100,100))
 for i in range(30): fine._physics_process(1.0/60)
 check(fine.growth_path.size()==SpellProjectile.GROWTH_POINTS,"a travelling vine retains a bounded history instead of allocating an endless trail")
 var fine_length := fine.position.distance_to(fine.growth_path[0])
 check(fine_length>=84 and fine_length<90,"living growth has a short84–90px physical extent at normal physics cadence")
 check(fine.growth_path[fine.growth_path.size()-1].distance_to(fine.position)<6.01,"the final stem sample remains beside the actual growing contact point")
 var coarse := shot_at(Vector2(100,200))
 for i in range(5): coarse._physics_process(0.1)
 check(is_equal_approx(coarse.position.x,fine.position.x),"coarse and fine stepping preserve the same actual spell movement")
 var coarse_length := coarse.position.distance_to(coarse.growth_path[0])
 check(absf(fine_length-coarse_length)<0.05,"a frame hitch does not stretch or shorten the visible vine")
 var curved := shot_at(Vector2(100,350))
 var seeking := ProbeFoe.new()
 seeking.position=Vector2(245,390)
 room.add_child(seeking)
 room.enemies=[seeking]
 for i in range(9): curved._physics_process(1.0/60)
 check(curved.direction.y>0 and curved.direction.y<0.3,"the new growing presentation retains gentle existing seeking rather than snapping")
 var first := curved.growth_path[0]
 var last := curved.growth_path[curved.growth_path.size()-1]
 var chord := last-first
 var bend := 0.0
 for point in curved.growth_path:
  bend=maxf(bend,absf(chord.cross(point-first))/maxf(chord.length(),0.01))
 check(bend>0.2,"the stored stem follows the real curved route rather than one rigid rotated sprite")
 var damage_before := seeking.health.current
 curved._physics_process(0.3)
 check(curved.spent and seeking.health.current==damage_before-curved.damage,"a coarse frame still sweeps the growing tip into its foe exactly once")
 room.enemies.clear()
 seeking.queue_free()
 var trail := shot_at(Vector2(100,500))
 for i in range(18): trail._physics_process(1.0/60)
 var behind := ProbeFoe.new()
 behind.position=trail.position-Vector2(60,0)
 room.add_child(behind)
 room.enemies=[behind]
 trail._physics_process(1.0/60)
 check(behind.health.current==1000 and not trail.spent,"an old visible stem never damages a foe behind the true moving hit point")
 room.enemies.clear()
 behind.queue_free()
 var previous := trail.growth_path.duplicate()
 trail.speed=0
 trail._physics_process(0.1)
 check(trail.growth_path==previous,"a stationary spell cannot fill its history with duplicate samples")
 for element in ["water","ice","wind","stone","leaf","lightning","metal"]:
  var impact := BasicMagicImpact.new()
  impact.element=element
  impact.direction=Vector2(0.6,0.8)
  room.projectiles.add_child(impact)
  impact.set_process(false)
  impact._process(BasicMagicImpact.DURATION+0.01)
  check(impact.is_queued_for_deletion(),element+": material contact effect expires promptly without lingering nodes")
 room.queue_free()
 await process_frame
 print("ELEMENTAL NATURE RESULT: %d checks, %d failures" % [checks,failures])
 quit(1 if failures else 0)
