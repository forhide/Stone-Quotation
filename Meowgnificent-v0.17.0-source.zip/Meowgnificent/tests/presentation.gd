extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# Follow the real eight-area route and verify the messages a player relies on
# to distinguish arriving, clearing a fight, visiting a shop, and finishing.
# Artwork quality and cached texture output are also reviewed in GUI captures.
var checks := 0
var failures := 0
var room
var profile_path := ""
var previous_profile_path := ""
var had_profile_override := false

func check(ok: bool, message: String) -> void:
	checks += 1
	if ok:
		print("PASS: " + message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func frames(count: int = 3) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func freeze_foes() -> void:
	for enemy in room.enemies:
		enemy.active = false
	room.player.invulnerability = 1000

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	had_profile_override = OS.has_environment("MEOW_PROFILE_PATH")
	previous_profile_path = OS.get_environment("MEOW_PROFILE_PATH")
	profile_path = "/tmp/meow-presentation-%d-%d.json" % [OS.get_process_id(), Time.get_ticks_usec()]
	OS.set_environment("MEOW_PROFILE_PATH", profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames()
	room = current_scene
	check(room.stages.size() == 8, "route contains eight areas, including its tutorial and shops")
	check(not room.hud.sector_banner.visible, "start menu does not display a stale arrival card")
	room.begin_or_restart()
	await frames()
	freeze_foes()
	var banner = room.hud.sector_banner
	check(banner.visible and banner.mode == "arrival", "beginning the expedition visibly announces the tutorial arrival")
	room.set_running(false)
	await frames(2)
	var paused_elapsed: float = banner.elapsed
	await frames(10)
	check(not banner.visible and is_equal_approx(banner.elapsed, paused_elapsed), "pause hides the arrival card and preserves its display time")
	room.set_running(true)
	await frames(2)
	freeze_foes()
	check(banner.visible and banner.stage_index == 0, "resuming restores the same arrival without advancing the route")
	room.open_inventory()
	await frames(2)
	check(not banner.visible, "equipment panel hides the arrival card so menu controls remain readable")
	room.close_panel()
	await frames(2)
	freeze_foes()
	var themes: Dictionary = {}
	var shops := 0
	var combats := 0
	for index in range(8):
		banner = room.hud.sector_banner
		var number := "%02d" % (index + 1)
		var kind: String = str(room.stage_def.kind)
		var theme: String = room.backdrop_painter.theme_id()
		themes[theme] = true
		check(room.backdrop_painter.stage_index == index, "area %s selects the corresponding background" % number)
		check(banner.visible and banner.mode == "arrival" and banner.stage_index == index and banner.stage_total == 8, "area %s announces arrival with the correct position in the route" % number)
		check(banner.title_label.text.contains(number + " / 08") and banner.name_label.text == str(room.stage_def.name), "area %s arrival spells out its number and destination name" % number)
		check(room.hud.route_nodes.size() == 8 and bool(room.hud.route_nodes[index].get_meta("active", false)), "area %s is highlighted on the eight-stop route" % number)
		var active_nodes := 0
		for node in room.hud.route_nodes:
			if bool(node.get_meta("active", false)):
				active_nodes += 1
		check(active_nodes == 1, "area %s has exactly one current route marker" % number)
		if kind == "shop":
			shops += 1
			check(room.enemies.is_empty() and room.exit_open and bool(room.hud.route_nodes[index].get_meta("shop", false)), "area %s is clearly marked as a safe shop stop" % number)
			check(banner.detail_label.text.to_lower().contains("shop") or banner.detail_label.text.to_lower().contains("merchant"), "area %s arrival gives a shopping objective" % number)
			room.player.position = WorldLayout.point(ShopGathering.PIP_POSITION)
			room.interact()
			await frames(2)
			check(room.panel.is_open and not banner.visible, "area %s merchant panel suppresses the arrival card" % number)
			room.close_panel()
			await frames(2)
		else:
			combats += 1
			check(not room.exit_open and not room.advance_sector(), "area %s cannot advance before its defenders are defeated" % number)
			freeze_foes()
			check(RouteFixture.clear_area(room)>0,"area %s completes every encounter before its onward announcement" % number)
			await frames()
			if index < 7:
				check(banner.visible and banner.mode == "cleared" and banner.name_label.text == "PASSAGE OPEN", "area %s clear has a different announcement from arrival" % number)
				check(banner.detail_label.text.contains(str(room.stages[index + 1].name)), "area %s clear names the next destination" % number)
			else:
				check(room.state == "cleared" and room.hud.overlay.visible and not banner.visible, "last area shows final victory rather than another route transition")
		if index < 7:
			var accepted: bool = room.advance_sector()
			if not accepted and not room.departure_gear_signature.is_empty(): accepted=room.advance_sector()
			await frames(3)
			freeze_foes()
			check(accepted and room.run.stage_index == index + 1, "area %s exits into the next distinct area" % number)
	check(themes.size() == 8, "all eight route stops have distinct visual themes")
	check(shops == 2 and combats == 6, "eight-area route consists of six combat areas and two shops")
	room.begin_or_restart()
	await frames(4)
	room = current_scene
	check(room.state == "intro" and room.run.stage_index == 0 and not room.hud.sector_banner.visible, "retry resets the route and clears the previous run's transition card")
	check(room.backdrop_painter.stage_index == 0 and room.backdrop_painter.theme_id() == "candlewick", "retry restores tutorial artwork instead of retaining the final area")
	await finish()

func finish() -> void:
	if is_instance_valid(current_scene):
		current_scene.queue_free()
	await frames(2)
	for suffix: String in ["", ".tmp", ".bak"]:
		var path: String = profile_path + suffix
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	if had_profile_override:
		OS.set_environment("MEOW_PROFILE_PATH", previous_profile_path)
	else:
		OS.unset_environment("MEOW_PROFILE_PATH")
	print("PRESENTATION RESULT: %d checks, %d failures" % [checks, failures])
	quit(0 if failures == 0 else 1)
