extends SceneTree

# Test the real enemy entry point: prediction, HP, material state and cosmetic
# feedback must agree for primary spells and delayed item-skill damage.
class TrainingCat extends WizardCat:
 func _ready() -> void: pass
class ProbeRoom extends Node2D:
 var enemies: Array = []
 var props: Array = []
 var skills: Node
 var projectiles := Node2D.new()
 func _ready() -> void: add_child(projectiles)

var checks := 0
var failures := 0
var cat: WizardCat
var arena := Rect2(100,160,1080,535)

func _initialize() -> void: call_deferred("run")
func check(ok: bool, caption: String) -> void:
 checks+=1
 if ok: print("PASS: "+caption)
 else:
  failures+=1
  push_error("FAIL: "+caption)

func foe(role: String, family: String="") -> CandleSlime:
 var enemy: CandleSlime=PerfectExaminer.new() if role=="examiner" else LivingStageEnemy.new() if role in ["book","mushroom"] else CandleSlime.new()
 enemy.role=role
 enemy.position=Vector2(640,410)
 enemy.setup({"hp":1000,"speed":83.0,"contact_damage":12,"radius":18.0,"element_family":family},cat,arena)
 root.add_child(enemy)
 enemy.set_physics_process(false)
 return enemy

func hit(enemy: CandleSlime, element: String, expected: int, message: String) -> void:
 var before := enemy.health.current
 var applied := enemy.take_elemental_damage(20,Vector2.RIGHT,"success",element)
 check(applied==expected and enemy.health.current==before-expected,message)

func run() -> void:
 cat=TrainingCat.new()
 cat.setup({"hp":100,"radius":23.0,"invulnerability":0.65},arena)
 root.add_child(cat)
 cat.set_physics_process(false)
 cat.active=true
 cat.position=Vector2(300,410)
 for role in ["candle","broom","book","mushroom","bat"]:
  var enemy := foe(role)
  var profile := enemy.affinity_profile()
  hit(enemy,str(profile.weak[0]),30,role+": a material weakness increases the real20damage hit to30")
  check(enemy.last_affinity_reaction=="weak" and enemy.affinity_feedback_time>0,role+": the upward feedback represents an actual weak-point hit")
  enemy.wet_time=0.0
  hit(enemy,str(profile.resist[0]),13,role+": resistance reduces the same hit to13 rather than granting immunity")
  check(enemy.last_affinity_reaction=="resist",role+": downward feedback represents actual resistance")
  var before := enemy.health.current
  enemy.take_damage(20,Vector2.LEFT)
  check(enemy.health.current==before-20,role+": body rolls and falling scenery retain neutral physical damage")
  enemy.free()
 for family in ElementAffinity.FAMILIES:
  var enemy := foe("mushroom",family)
  var profile := enemy.affinity_profile()
  check(profile.family==family and not profile.weak.is_empty() and not profile.resist.is_empty(),family+": a later-encounter ward has a complete explicit profile")
  hit(enemy,str(profile.weak[0]),30,family+": ward weakness affects actual HP")
  enemy.wet_time=0.0
  hit(enemy,str(profile.resist[0]),13,family+": ward resistance affects actual HP")
  enemy.free()
 var unknown := foe("candle","unknown")
 check(unknown.affinity_profile().family=="" and unknown.affinity_profile().weak==["water","ice"],"unknown ward metadata falls back to the enemy's material")
 hit(unknown,"not-an-element",20,"unknown spell metadata is neutral rather than silently becoming fire")
 check(unknown.take_elemental_damage(0,Vector2.RIGHT,"success","fire")==0 and unknown.take_elemental_damage(-3,Vector2.RIGHT,"success","water")==0,"zero and negative damage cannot manufacture feedback or material states")
 unknown.free()
 var conductor := foe("book","lightning")
 hit(conductor,"lightning",13,"an unsoaked lightning ward initially resists electricity")
 hit(conductor,"water",20,"water deals its own neutral hit before setting conduction")
 check(conductor.is_wet() and is_equal_approx(conductor.wet_time,3.0),"a real water hit leaves three seconds of visible wetness")
 hit(conductor,"lightning",30,"water enables a single conductive weakness through an electrical ward")
 check(not conductor.is_wet() and conductor.last_affinity_reaction=="conductive","the conductive discharge consumes wetness and shows upward feedback")
 hit(conductor,"lightning",13,"subsequent dry electricity returns to the ordinary resistance")
 conductor.take_elemental_damage(20,Vector2.RIGHT,"success","water")
 cat.active=false
 conductor._physics_process(1.0)
 check(is_equal_approx(conductor.wet_time,3.0),"inventory/story pause freezes the same wetness timer used by combat")
 cat.active=true
 conductor.active=false
 conductor._physics_process(1.0)
 check(is_equal_approx(conductor.wet_time,2.0),"rooting the AI does not freeze its material status indefinitely")
 conductor._physics_process(2.1)
 check(not conductor.is_wet() and conductor.affinity_feedback_time==0,"material state and temporary hit markers expire without lingering nodes")
 conductor.free()
 var naturally_weak := foe("bat")
 naturally_weak.take_elemental_damage(20,Vector2.RIGHT,"success","water")
 hit(naturally_weak,"lightning",30,"conduction does not multiply an existing electrical weakness twice")
 naturally_weak.free()
 var book := foe("book") as LivingStageEnemy
 var mushroom := foe("mushroom") as LivingStageEnemy
 book.take_elemental_damage(20,Vector2.RIGHT,"success","wind")
 mushroom.take_elemental_damage(20,Vector2.RIGHT,"success","metal")
 check(book.disordered and mushroom.awakened and mushroom.disordered,"the unified elemental entry point retains book disruption and crop awakening")
 book.free()
 mushroom.free()
 var boss := foe("examiner") as PerfectExaminer
 var before := boss.health.current
 check(boss.take_elemental_damage(20,Vector2.RIGHT,"success","water")==0 and boss.health.current==before and not boss.is_wet(),"a predicted water spell cannot soak the boss through its closed shield")
 check(boss.affinity_feedback_time==0 and boss.blocked_spells==1,"a blocked spell cannot claim weakness feedback or damage")
 check(boss.take_elemental_damage(20,Vector2.RIGHT,"miscast","leaf")==30 and not boss.barrier_active,"a genuine wood miscast opens the shield and applies the exposed book's weakness")
 boss.take_elemental_damage(20,Vector2.RIGHT,"success","water")
 boss.vulnerability_time=0
 var wet := boss.wet_time
 before=boss.health.current
 check(boss.take_elemental_damage(20,Vector2.RIGHT,"success","lightning")==0 and boss.health.current==before and boss.wet_time==wet,"a reformed shield does not let a conductive hit bypass prediction or consume wetness")
 boss.take_elemental_damage(20,Vector2.RIGHT,"overreaction","lightning")
 check(boss.health.current==before-30 and not boss.is_wet() and boss.break_event_count==2,"an overreaction legitimately breaks the shield and consumes the conductive opening once")
 before=boss.health.current
 boss.take_damage(20,Vector2.RIGHT)
 check(boss.health.current==before-20,"neutral belly rolls preserve the boss's accidental opening rule")
 boss.vulnerability_time=0
 before=boss.health.current
 boss.take_elemental_damage(20,Vector2.UP,"miscast","fire")
 check(boss.health.current==before-20 and not boss.barrier_active,"accidental floor fire retains its elemental damage and can break the prediction barrier")
 boss.free()
 var room := ProbeRoom.new()
 root.add_child(room)
 var direct := foe("candle")
 var splash := foe("candle")
 direct.position=Vector2(640,410)
 splash.position=Vector2(670,410)
 room.enemies=[direct,splash]
 var shot := SpellProjectile.new()
 shot.room=room
 shot.element="water"
 shot.damage=20
 shot.position=direct.position
 shot._hit_enemy(direct)
 check(direct.health.current==970 and direct.is_wet(),"the real primary projectile uses the same affinity and wetness entry point")
 check(splash.health.current==989 and splash.is_wet(),"water's actual nearby splash also respects weakness and sets conduction")
 shot.free()
 direct.free()
 splash.free()
 room.free()
 cat.free()
 await process_frame
 print("ELEMENT AFFINITY RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
