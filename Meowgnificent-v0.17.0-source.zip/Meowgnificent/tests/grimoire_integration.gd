extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# Exercise the real final-room spawn, projectile collision and AoE signal routes.
# No direct boss damage-method calls are used to stand in for spell impacts.
var checks := 0
var failures := 0
var room
var boss: PerfectExaminer
var had_profile := false
var original_profile := ""
var had_skip := false
var original_skip := ""
var profile_path := ""

func _initialize() -> void:
	call_deferred("run")

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(count: int=2) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func prepare_final() -> void:
	room.load_sector(7)
	check(RouteFixture.reach_boss(room),"the two archive defender groups lead to the actual boss encounter")
	boss=null
	for enemy in room.enemies:
		if enemy is PerfectExaminer: boss=enemy
	for i in range(room.enemies.size()):
		var enemy: CandleSlime=room.enemies[i]
		enemy.active=false
		if enemy!=boss: enemy.position=Vector2(160+i*55,220)
	if boss!=null: boss.position=Vector2(1000,800) # Clear floor; avoid the now-solid library case.
	room.player.position=Vector2(220,640)
	room.player.velocity=Vector2.ZERO
	room.player.recoil=Vector2.ZERO
	room.player.invulnerability=1000

func collide_spell(outcome: String, amount: int, area: float=0.0) -> SpellProjectile:
	var shot := SpellProjectile.new()
	shot.room=room
	shot.bounds=room.bounds
	shot.position=boss.position-Vector2(45,0)
	shot.direction=Vector2.RIGHT
	shot.outcome=outcome
	shot.damage=amount
	shot.radius=9.0
	shot.speed=540.0
	shot.explosion_radius=area
	shot.impacted.connect(room.apply_miscast_blast if outcome=="miscast" else room.apply_blast)
	room.projectiles.add_child(shot)
	# Real production collision code, stepped deterministically so inactive foes
	# and a shared CI frame rate cannot move the intended target out of the lane.
	shot.set_physics_process(false)
	shot._physics_process(0.06)
	return shot

func run() -> void:
	had_profile=OS.has_environment("MEOW_PROFILE_PATH")
	original_profile=OS.get_environment("MEOW_PROFILE_PATH")
	had_skip=OS.has_environment("MEOW_SKIP_STORY")
	original_skip=OS.get_environment("MEOW_SKIP_STORY")
	profile_path="/tmp/meow-grimoire-integration-%d-%d.json" % [OS.get_process_id(),Time.get_ticks_usec()]
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	OS.set_environment("MEOW_SKIP_STORY","1")
	change_scene_to_file("res://scenes/main.tscn")
	await frames(3)
	room=current_scene
	room.begin_or_restart()
	prepare_final()
	await frames()
	check(room.run.stage_index==7 and str(room.stage_def.kind)=="final" and room.state=="playing","real room enters the final area with story safely skipped for combat integration")
	var boss_count := 0
	for enemy in room.enemies:
		if enemy is PerfectExaminer: boss_count+=1
	check(boss_count==1 and boss!=null,"final-area elite spawns exactly one PerfectExaminer rather than a reskinned broom")
	if boss==null:
		await finish()
		return
	check(boss.health.maximum==180 and boss.has_meta("elite") and str(boss.get_meta("archetype"))=="perfect_wizard","spawn passes the final elite HP and identity into the new encounter")
	check(room.enemies.size()==4 and not room.exit_open and boss.barrier_active,"final passage stays locked while the shielded boss and its defenders remain")
	var shot := collide_spell("success",20)
	check(shot.spent,"a real controlled projectile reaches the boss and is consumed by collision")
	check(boss.health.current==180 and boss.blocked_spells==1 and boss.barrier_active,"projectile dispatch preserves success prediction instead of bypassing the barrier through generic damage")
	await frames()
	check(not is_instance_valid(shot),"the blocked projectile cleans up after its real impact signal")
	shot=collide_spell("miscast",12)
	check(shot.spent and boss.health.current==168,"a real miscast projectile applies exactly its configured damage")
	check(boss.break_event_count==1 and is_zero_approx(boss.barrier_break_age),"real projectile collision starts the shield-fracture presentation once at impact")
	check(room.shake>=12 and room.hud.boss_break_remaining>1.0 and room.hud.sector_banner.elapsed>=room.hud.sector_banner.duration,"real barrier collision triggers camera emphasis and replaces the arrival card with the attack opportunity")
	check(not boss.barrier_active and boss.window_source=="miscast" and boss.vulnerability_time>3.9,"miscast collision forwards its outcome and opens the accident opportunity")
	await frames()
	shot=collide_spell("success",20)
	check(shot.spent and boss.health.current==148 and boss.blocked_spells==1,"a following controlled projectile deals damage during the same opening")
	check(boss.break_event_count==1,"a follow-up projectile during the exposed window does not replay shield shattering")
	await frames()
	prepare_final()
	await frames()
	shot=collide_spell("overreaction",45,80.0)
	check(shot.spent and boss.health.current==135,"giant-projectile impact dispatches its AoE exactly once without an extra direct hit")
	check(not boss.barrier_active and boss.window_source=="overreaction","the production explosion signal reaches the boss as an uncontrolled overreaction")
	await frames()
	prepare_final()
	await frames()
	shot=collide_spell("miscast",12,80.0)
	check(shot.spent and boss.health.current==168,"miscast area impact applies the configured damage through the real signal binding")
	check(not boss.barrier_active and boss.window_source=="miscast","miscast AoE uses apply_miscast_blast rather than the default overreaction outcome")
	await frames()
	prepare_final()
	await frames()
	room.apply_blast(boss.position,20,80.0,Vector2.RIGHT,Color.WHITE,"success")
	check(boss.barrier_active and boss.health.current==180 and boss.blocked_spells==1,"explicit controlled AoE also respects the barrier through room dispatch")
	room.apply_miscast_blast(boss.position,12,80.0,Vector2.RIGHT)
	check(boss.health.current==168 and boss.window_source=="miscast","room's feet-miscast AoE path opens the correct opportunity")
	room.apply_blast(boss.position,20,80.0,Vector2.RIGHT,Color.WHITE,"success")
	check(boss.health.current==148,"controlled AoE can exploit an opening made by an accident")
	prepare_final()
	await frames()
	var before_defeated: int=room.run.enemies_defeated
	var defeated_boss := boss
	shot=collide_spell("miscast",9999)
	check(shot.spent and room.run.enemies_defeated==before_defeated+1,"lethal spell collision reaches the room's normal defeat accounting once")
	check(not room.enemies.has(defeated_boss) and room.enemies.size()==3 and not room.exit_open,"boss defeat removes only the boss and leaves surviving defenders gating completion")
	var gold_found := false
	var gear_found := false
	for pickup in room.loot:
		if pickup.kind=="gold" and pickup.amount>=19: gold_found=true
		if pickup.kind=="gear": gear_found=true
	check(gold_found and gear_found,"the real boss defeat produces its elite Crowns and guaranteed equipment drop")
	await frames()
	check(not is_instance_valid(defeated_boss),"defeated final boss is freed after the room processes its loot signal")
	for enemy in room.enemies.duplicate(): enemy.take_damage(9999,Vector2.RIGHT)
	await frames(3)
	check(room.enemies.is_empty() and room.exit_open and room.state=="cleared","defeating the remaining defenders completes the real final area")
	check(not room.player.active and room.hud.overlay.visible,"normal victory presentation replaces combat after final-room completion")
	check(room.run.gold>0 and room.profile.wins==1 and room.profile.best_sector==8,"final completion collects loot and saves permanent win and route progress")
	var saved: Variant=JSON.parse_string(FileAccess.get_file_as_string(profile_path))
	check(saved is Dictionary and int(saved.get("wins",0))==1 and int(saved.get("best_sector",0))==8,"boss encounter completion persists through the normal isolated profile writer")
	await finish()

func finish() -> void:
	if is_instance_valid(current_scene): current_scene.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	if had_profile: OS.set_environment("MEOW_PROFILE_PATH",original_profile)
	else: OS.unset_environment("MEOW_PROFILE_PATH")
	if had_skip: OS.set_environment("MEOW_SKIP_STORY",original_skip)
	else: OS.unset_environment("MEOW_SKIP_STORY")
	print("GRIMOIRE INTEGRATION RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
