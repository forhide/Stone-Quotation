extends SceneTree

const SoundScript := preload("res://scripts/systems/sound_palette.gd")
var checks := 0
var failures := 0
var path := "/tmp/meow-sound-%d.cfg" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")

func check(ok: bool, caption: String) -> void:
 checks+=1
 if ok: print("PASS: "+caption)
 else:
  failures+=1
  push_error("FAIL: "+caption)

func frames(count: int=3) -> void:
 for i in range(count): await process_frame

func run() -> void:
 var sound := SoundScript.new()
 sound.config_path=path
 root.add_child(sound)
 check(sound.voices.size()==8 and sound.get_child_count()==8,"audio preallocates exactly eight voices")
 check(sound.voices.all(func(voice): return not voice.playing),"startup stays silent until an explicit action")
 check(is_equal_approx(sound.volume,0.4),"fresh audio preferences begin softly")
 check(sound.STREAMS.size()==16,"all eight elements and eight feedback cues use cached original streams")
 var bounded := true
 for id in sound.STREAMS:
  var stream: AudioStream=sound.STREAMS[id]
  bounded=bounded and stream.get_length()>=0.1 and stream.get_length()<=0.501
 check(bounded,"all imported material cues are short and nonempty")
 check(not sound.play_cue("unknown"),"unknown cues fail harmlessly without allocation")
 check(sound.play_cue("cast_water"),"a genuine cast plays its material cue")
 check(not sound.play_cue("cast_water"),"repeated same-frame cues are throttled")
 sound.stop_all()
 var admitted := 0
 for id in ["cast_fire","cast_water","cast_ice","cast_wind","cast_stone","cast_leaf","cast_lightning","cast_metal"]:
  if sound.play_cue(id): admitted+=1
 check(admitted==8 and sound.voices.all(func(voice): return voice.playing),"eight simultaneous distinct actions fit the bounded pool")
 check(not sound.play_cue("hit") and sound.get_child_count()==8,"a busy pool does not allocate or abruptly interrupt active sound")
 check(sound.set_volume(0.0) and sound.voices.all(func(voice): return not voice.playing),"muting immediately stops all currently playing cues")
 check(not sound.play_cue("skill"),"muted gameplay remains silent")
 check(not sound.set_volume(-1) and not sound.set_volume(0.9) and sound.volume==0.0,"unsupported volume choices cannot alter persisted audio state")
 var config := ConfigFile.new()
 config.set_value("preferences","language","ko")
 config.set_value("display","frame_limit",60)
 config.save(path)
 check(sound.set_volume(0.7),"a normal volume selection persists successfully")
 config.load(path)
 check(config.get_value("preferences","language","")=="ko" and config.get_value("display","frame_limit",0)==60,"saving volume preserves language and display settings")
 check(is_equal_approx(float(config.get_value("audio","effects_volume",-1)),0.7),"audio has its own saved preference section")
 sound.load_settings(path)
 check(is_equal_approx(sound.volume,0.7),"saved volume restores on a new load")
 config.set_value("audio","effects_volume","loud")
 config.save(path)
 sound.load_settings(path)
 check(is_equal_approx(sound.volume,0.4),"invalid saved audio values recover to the soft default")
 sound.stop_all()
 check(sound.play_cue("cast_metal",99.0) and is_equal_approx(sound.voices[0].pitch_scale,1.2),"extreme pitch requests stay within a gentle bounded range")
 sound.stop_all()
 check(sound.play_cue("cast_leaf",NAN) and is_equal_approx(sound.voices[0].pitch_scale,1.0),"invalid pitch cannot reach the audio server")
 sound.stop_all()
 await create_timer(0.08).timeout
 check(sound.play_cue("hit"),"an eligible later hit can use a released voice")
 await create_timer(0.25).timeout
 check(sound.voices.all(func(voice): return not voice.playing),"short cues naturally finish and release the same pool")
 sound.queue_free()
 await frames()
 if FileAccess.file_exists(path): DirAccess.remove_absolute(path)
 print("SOUND PALETTE RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
