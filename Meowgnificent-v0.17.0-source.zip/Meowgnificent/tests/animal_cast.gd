extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# Shared images and actual story stages must agree on animal identities. The
# original50visual beats keep their order; the explicit3shot examination replay
# and dialogue explaining the living world are deliberate v0.12 additions.
const ORIGINAL_VISUAL_ORDER := "75b523149e402c0310d8f20dd9fd28b271a756a7a81ed6381bdbe902eecd0e16"
const EXPECTED := {"professor":"owl","pip":"squirrel","moss":"hedgehog","bloop":"otter"}
var checks := 0
var failures := 0

func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)

func _initialize() -> void: call_deferred("run")
func frames(n: int=3) -> void:
 for i in range(n):
  await physics_frame
  await process_frame

func run() -> void:
 for id: String in EXPECTED:
  check(AnimalCast.species(id)==str(EXPECTED[id]),"canonical supporting cast has the intended animal species: "+id)
  var icon: Texture2D=AnimalCast.icon(id)
  check(icon is AtlasTexture and icon.atlas==AnimalCast.SHEET and icon==AnimalCast.icon(id) and icon.region==AnimalCast.region(id),"story/world/boss reuse the exact cached animal image: "+id)
  check(Rect2(Vector2.ZERO,AnimalCast.SHEET.get_size()).encloses(AnimalCast.region(id)),"animal frame has bounded independently measured atlas coordinates: "+id)
 check(GrimoireArt.identity()=="sentient_grimoire" and GrimoireArt.icon("calm").atlas==GrimoireArt.SHEET,"the antagonist is the actual sentient book, a deliberate exception to the animal supporting cast")
 check(AnimalCast.icon("unknown")==null and AnimalCast.species("unknown").is_empty(),"unknown cast IDs cannot silently display a different atlas cell")
 var story: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/story.json"))
 for id in ["professor","pip","moss","bloop"]:
  check(str(story.get("cast",{}).get(id,{}).get("species",""))==AnimalCast.species(id),"story metadata and the visible supporting cast agree: "+id)
 check(str(story.cast.perfect_wizard.species)=="book" and str(story.cast.grimoire.species)=="book","narrator and final encounter identify the Grimoire and its battle form as the same book character")
 var all_pages: Array=[]
 all_pages.append_array(story.opening)
 for chapter: Dictionary in story.chapters: all_pages.append_array(chapter.beats)
 all_pages.append_array(story.ending)
 var original_visuals := ""
 var flashbacks := PackedStringArray()
 for page: Dictionary in all_pages:
  if str(page.visual).begins_with("exam_"): flashbacks.append(str(page.visual))
  else: original_visuals+=str(page.visual)+"\n"
 check(all_pages.size()==53 and original_visuals.sha256_text()==ORIGINAL_VISUAL_ORDER and flashbacks==PackedStringArray(["exam_fire","exam_reverse","exam_boom"]),"all50original visual beats remain in order, with a clearly marked3shot examination replay after the first area")
 var stage_source := FileAccess.get_file_as_string("res://scripts/ui/story_director.gd")
 check(not stage_source.contains("res://art/story/academy.png") and not stage_source.contains("res://art/story/library.png") and not stage_source.contains("res://art/story/friends.png") and not stage_source.contains("res://art/story/archive.png") and stage_source.contains("hd_academy_library.res") and stage_source.contains("hd_forbidden_garden.res") and stage_source.contains("hd_grand_archive.res"),"active story scenery reuses person-free HD environments instead of baked human illustrations")
 change_scene_to_file("res://scenes/main.tscn")
 await frames()
 var room=current_scene
 var director: StoryDirector=room.story_director
 room.state="story"
 var sequences: Array=[{"mode":"opening","index":-1,"title":"Opening","pages":story.opening}]
 for index in range(story.chapters.size()): sequences.append({"mode":"chapter","index":index,"title":str(story.chapters[index].title),"pages":story.chapters[index].beats})
 sequences.append({"mode":"ending","index":-1,"title":"Ending","pages":story.ending})
 var seen := {}
 var group_seen := false
 var page_count := 0
 for sequence: Dictionary in sequences:
  director._play(str(sequence.mode),int(sequence.index),str(sequence.title),sequence.pages,false,Callable())
  for index in range(sequence.pages.size()):
   director.page_index=index
   director._show_page()
   var stage=director.stage
   var valid := true
   for id: String in stage.actor_ids:
    seen[id]=true
    valid=valid and ((EXPECTED.has(id) and not AnimalCast.species(id).is_empty()) or id=="grimoire")
   if stage.friend_frame.visible:
    if stage.actor_ids.size()==3:
     group_seen=true
     valid=valid and stage.actor_ids==PackedStringArray(["pip","moss","bloop"]) and not stage.friend_portrait.visible
     for portrait: TextureRect in stage.group_portraits:
      var id := str(portrait.get_meta("animal_id",""))
      valid=valid and portrait.visible and portrait.texture==AnimalCast.icon(id)
    else:
     valid=valid and stage.actor_ids.size()==1 and stage.friend_portrait.visible
     if stage.actor_ids[0]=="grimoire": valid=valid and stage.friend_portrait.texture==GrimoireArt.icon(stage.grimoire_pose)
     else: valid=valid and stage.friend_portrait.texture==AnimalCast.icon(str(stage.actor_ids[0]))
   else: valid=valid and stage.actor_ids.is_empty()
   page_count+=1
   check(valid,"real illustrated story page shows canonical animals or the sentient book: %02d" % page_count)
 check(seen.has("professor") and seen.has("pip") and seen.has("moss") and seen.has("bloop") and seen.has("grimoire"),"all four animal friends and the actual sentient Grimoire appear in the authored story")
 check(group_seen and director.stage.group_portraits.size()==3,"the friends vignette composes three separate animal images rather than cropping across atlas cells")
 director.close()
 room.state="intro"
 room.begin_or_restart()
 room.load_sector(7)
 check(RouteFixture.reach_boss(room),"actual archive seals lead to the book antagonist")
 for enemy in room.enemies: enemy.active=false
 var boss: PerfectExaminer
 for enemy in room.enemies:
  if enemy is PerfectExaminer: boss=enemy
 check(boss!=null and boss.health.maximum==180 and boss.EXAMINER_ART==GrimoireArt.SHEET,"the real final-room encounter uses the same sentient book atlas while preserving its180HP")
 if boss!=null:
  check(boss.art_frames[0].region==GrimoireArt.region("calm") and boss.art_frames[1].region==GrimoireArt.region("shocked") and is_equal_approx(boss.body_sprite.scale.y*boss.art_frames[0].get_height(),164.0),"calm and shocked book poses retain the established164px calm artwork height")
  boss.take_spell_damage(1,Vector2.ZERO,"miscast")
  check(boss.art_pose==1 and boss.body_sprite.texture==boss.art_frames[1] and boss.window_source=="miscast" and boss.vulnerability_time==4.0,"a genuine miscast changes the book to its shocked cover/page pose and preserves the4second opportunity")
 print("ANIMAL CAST RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
