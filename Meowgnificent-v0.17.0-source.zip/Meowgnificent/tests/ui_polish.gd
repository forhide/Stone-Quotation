extends SceneTree

# Exercise the player's route through a full satchel, the actual rebuilt
# controls, and the primary magic card at its real HUD coordinates.
var checks := 0
var failures := 0
var room
var profile_path := "/tmp/meow-ui-polish-%d.json" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(n: int=3) -> void:
	for i in range(n): await process_frame

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.physical_keycode=code
	event.pressed=true
	room._unhandled_key_input(event)

func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames(5)
	room=current_scene
	room.begin_or_restart()
	room.load_sector(3)
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.spells.set_physics_process(false)
	room.skills.set_physics_process(false)
	var panel: ExpeditionPanel=room.panel
	var hud: WizardHUD=room.hud
	hud.set_process(false)
	var language=root.get_node("Language")
	var old_language: String=language.current
	language.set_language("en",false)
	room.run.add_item("thunder_spoon")
	room.equip_gear("thunder_spoon")
	hud._process(0)
	check(hud.cooldown_label.text==GameLocale.text(str(BasicMagic.for_run(room.run).name)) and not hud.cooldown_label.text.contains("READY"),"the primary spell name has its own line instead of competing with its readiness caption")
	check(hud.cooldown_label.get_global_rect().end.x<hud.skill_card.get_global_rect().position.x and hud.primary_state.get_global_rect().end.x<hud.skill_card.get_global_rect().position.x,"both primary captions remain inside their card and clear of the special skill")
	check(hud.cooldown_label.clip_text and hud.cooldown_label.text_overrun_behavior==TextServer.OVERRUN_TRIM_ELLIPSIS,"a future long equipment spell name is contained rather than widening the HUD")
	room.spells.cooldown=float(room.spells.config.cooldown)*0.504
	hud._process(0)
	var width: float=hud.primary_bar.size.x
	var caption := hud.primary_state.text
	room.spells.cooldown-=0.001
	hud._process(0)
	check(hud.primary_bar.size.x>width and hud.primary_state.text==caption,"the primary recovery fill advances between rounded timer updates")
	room.spells.cooldown=0
	hud._process(0)
	check(hud.primary_state.text==GameLocale.text("READY") and is_equal_approx(hud.primary_bar.size.x,170),"the full primary recovery bar agrees with readiness")
	room.spells.cooldown=float(room.spells.config.cooldown)*2
	hud._process(0)
	check(is_zero_approx(hud.primary_bar.size.x),"changing equipment during recovery cannot draw the fill outside its card")
	for id in room.run.catalog:
		if room.run.inventory.size()>=ExpeditionRun.INVENTORY_LIMIT: break
		if not room.run.inventory.has(id): room.run.add_item(id)
	room.run.gold=1000
	room.player.health.current=room.player.health.maximum-40
	var gear: Dictionary=room.run.item_info("cinderfork_wand")
	room.shop_offers[0]={"id":"cinderfork_wand","kind":"gear","name":gear.name,"price":gear.price,"sold":false}
	var stock_before: Array=room.shop_offers.duplicate(true)
	var gold_before: int=room.run.gold
	room.open_shop()
	await frames()
	check(room.state=="shop" and panel.mode=="shop" and panel.satchel_button.visible,"Pip's shop exposes the direct satchel action")
	check(panel.purchase_buttons.slice(0,3).all(func(button: Button) -> bool: return button.disabled) and not panel.purchase_buttons[3].disabled,"a full satchel blocks equipment purchases while allowing useful food")
	panel.buy_offer(0)
	await frames()
	check(room.shop_offers==stock_before and room.run.gold==gold_before,"the purchase shortcut cannot charge for gear that will not fit")
	room.spells.cooldown=1.7
	room.skills.cooldown_remaining=2.8
	panel.satchel_button.pressed.emit()
	await frames()
	check(room.state=="inventory" and panel.mode=="inventory" and room.inventory_from_shop and not room.player.active,"the shop's satchel action opens the wardrobe without resuming combat")
	check(panel.close_button.text=="Back to Pip  /  ESC" and not panel.satchel_button.visible,"the wardrobe clearly leads back to the same shop")
	var discarded := "loose_feather"
	panel._select_item(discarded)
	panel.discard_button.grab_focus()
	panel.discard_button.pressed.emit()
	check(room.run.inventory.size()==18 and panel.discard_item_id==discarded,"making room still requires a deliberate second discard press")
	panel.discard_button.pressed.emit()
	await frames()
	check(room.run.inventory.size()==17 and not room.run.inventory.has(discarded),"the shop wardrobe can free a real equipment slot")
	var focus: Control=root.gui_get_focus_owner()
	check(focus!=null and is_instance_valid(focus) and panel.content.is_ancestor_of(focus),"discard rebuilds the grid without losing keyboard focus")
	key(KEY_I)
	await frames()
	check(room.state=="shop" and panel.mode=="shop" and not room.inventory_from_shop and room.shop_offers==stock_before,"I returns to Pip with the same stock, prices and sold flags")
	check(not panel.purchase_buttons[0].disabled,"the newly freed slot immediately re-enables the blocked purchase")
	panel.purchase_buttons[0].grab_focus()
	panel.purchase_buttons[0].pressed.emit()
	await frames()
	check(bool(room.shop_offers[0].sold) and room.run.gold==gold_before-int(gear.price) and room.run.inventory.size()==18,"buying after making room charges once and fills the free slot")
	focus=root.gui_get_focus_owner()
	check(focus!=null and focus is Button and not focus.disabled and (panel.content.is_ancestor_of(focus) or focus==panel.satchel_button),"a sold offer moves keyboard focus to an available control")
	key(KEY_I)
	await frames()
	panel._select_item("cinderfork_wand")
	panel.equip_button.grab_focus()
	panel.equip_button.pressed.emit()
	await frames()
	check(room.run.equipment.wand=="cinderfork_wand" and panel.item_buttons["cinderfork_wand"].has_focus(),"equipping from the shop wardrobe restores focus to the selected item")
	check(is_equal_approx(room.spells.cooldown,1.7) and is_equal_approx(room.skills.cooldown_remaining,2.8),"the entire shopping route preserves paused spell and special recovery")
	key(KEY_ESCAPE)
	await frames()
	check(room.state=="shop" and panel.mode=="shop" and not room.player.active,"the first Escape returns from wardrobe to the paused shop")
	for locale in ["ko","en"]:
		language.set_language(locale,false)
		panel.refresh()
		await frames()
		var viewport := Rect2(0,0,1280,800)
		check(viewport.encloses(panel.satchel_button.get_global_rect()) and viewport.encloses(panel.close_button.get_global_rect()) and not panel.notice.get_global_rect().intersects(panel.satchel_button.get_global_rect()),"full-satchel notice and both footer actions fit without overlap: "+locale)
		room.open_inventory()
		await frames()
		check(viewport.encloses(panel.close_button.get_global_rect()) and panel.stats_container.get_global_rect().end.y<panel.close_button.global_position.y,"the comparison and return-to-shop action fit the wardrobe: "+locale)
		key(KEY_ESCAPE)
		await frames()
	key(KEY_ESCAPE)
	await frames()
	check(room.state=="playing" and room.player.active and not panel.is_open,"the second Escape closes the shop and returns control to the same stage")
	language.set_language(old_language,false)
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("UI POLISH RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
