extends SceneTree

const DisplayScript := preload("res://scripts/systems/display_settings.gd")
var checks := 0
var failures := 0
var config_path := "/tmp/meow-display-%d.cfg" % OS.get_process_id()
var profile_path := "/tmp/meow-display-%d.json" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")
func check(ok: bool, caption: String) -> void:
	checks+=1
	if ok: print("PASS: "+caption)
	else:
		failures+=1
		push_error("FAIL: "+caption)
func frames(count: int=3) -> void:
	for i in range(count): await process_frame

func run() -> void:
	var display := root.get_node("Display")
	var language := root.get_node("Language")
	var previous_path: String=language.settings_path
	var previous_config_path: String=display.config_path
	var previous_language: String=language.current
	var previous_mode: String=display.window_mode
	var previous_cap: int=display.frame_limit
	var previous_actual_cap := Engine.max_fps
	var previous_cli: Dictionary=display.startup_options.duplicate()
	var previous_profile := OS.get_environment("MEOW_PROFILE_PATH")
	var previous_skip := OS.get_environment("MEOW_SKIP_STORY")
	language.settings_path=config_path
	display.config_path=config_path
	display.load_settings(config_path)
	check(display.window_mode=="windowed" and display.frame_limit==0,"fresh display preferences match the monitor in a window")
	check(display.settings_path()==language.settings_path,"language and display use the same selected preferences file")
	check(not display.set_window_mode("invisible") and not display.set_frame_limit(17),"unknown display modes and arbitrary caps are rejected")
	check(display.window_mode=="windowed" and display.frame_limit==0,"invalid choices do not alter the active display preferences")
	check(language.set_language("en",true),"English can be written before display preferences")
	check(display.set_frame_limit(60) and Engine.max_fps==60,"a selected60FPS limit applies immediately and saves")
	var stored := ConfigFile.new()
	stored.load(config_path)
	check(stored.get_value("preferences","language","")=="en" and stored.get_value("display","frame_limit",0)==60,"saving display preserves the existing language section")
	display.window_mode="fullscreen"
	display._save()
	check(language.set_language("ko",true),"Korean can be saved after display preferences")
	stored=ConfigFile.new()
	stored.load(config_path)
	check(stored.get_value("display","window_mode","")=="fullscreen" and stored.get_value("display","frame_limit",0)==60,"saving language preserves display mode and frame cap")
	display.window_mode="windowed"
	display.frame_limit=0
	display.load_settings(config_path)
	check(display.window_mode=="fullscreen" and display.frame_limit==60,"both saved display choices are restored together")
	stored.set_value("display","window_mode","invalid")
	stored.set_value("display","frame_limit","not a number")
	stored.save(config_path)
	display.load_settings(config_path)
	check(display.window_mode=="windowed" and display.frame_limit==0,"malformed display values fall back to safe defaults")
	var cli := DisplayScript.command_line_options(PackedStringArray(["--resolution","3840x2160","--position=100,60","--max-fps","144","--disable-vsync"]))
	check(cli.geometry and cli.frame_limit and cli.vsync and not cli.mode,"explicit resolution, position, cap and VSync flags are recognized")
	check(DisplayScript.command_line_options(PackedStringArray(["--fullscreen"])).mode and DisplayScript.command_line_options(PackedStringArray(["--windowed"])).mode,"explicit fullscreen and windowed startup modes are recognized")
	display.startup_options=cli
	Engine.max_fps=144
	display.apply()
	check(Engine.max_fps==144,"startup application preserves an explicit engine frame limit")
	display.set_frame_limit(0)
	check(Engine.max_fps==0,"choosing match-monitor deliberately restores uncapped VSync behavior")
	display.startup_options={}
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	OS.set_environment("MEOW_SKIP_STORY","1")
	change_scene_to_file("res://scenes/main.tscn")
	await frames(5)
	var room=current_scene
	var previous_state: String=room.state
	room.settings.open()
	await frames()
	var settings=room.settings
	for locale in ["ko","en"]:
		language.set_language(locale,false)
		await frames()
		var card: Rect2=settings.settings_card.get_global_rect()
		check(Rect2(Vector2.ZERO,Vector2(1280,800)).encloses(card),locale+" settings card stays within the logical game canvas")
		var contained := true
		for control in [settings.choice,settings.display_choice,settings.frame_choice,settings.sound_choice,settings.message,settings.close_button]:
			contained=contained and card.encloses(control.get_global_rect())
		check(contained,locale+" language, display, frame, feedback and close controls all fit the card")
		check(settings.choice.get_global_rect().end.y<=settings.display_choice.get_global_rect().position.y and settings.display_choice.get_global_rect().end.y<=settings.frame_choice.get_global_rect().position.y and settings.frame_choice.get_global_rect().end.y<=settings.sound_choice.get_global_rect().position.y and settings.sound_choice.get_global_rect().end.y<=settings.message.get_global_rect().position.y,locale+" settings rows remain separate without overlapping")
		check(settings.frame_choice.get_item_text(0)==GameLocale.text("Match monitor (VSync)") and settings.display_choice.get_item_text(1)==GameLocale.text("Fullscreen"),locale+" display choices update with the selected language")
		print("DISPLAY BOUNDS "+locale+": "+str({"card":card,"language":settings.choice.get_global_rect(),"display":settings.display_choice.get_global_rect(),"frame":settings.frame_choice.get_global_rect(),"close":settings.close_button.get_global_rect()}))
	settings.close()
	check(not settings.is_open and not settings.screen.visible and room.state==previous_state,"closing expanded settings restores the previous game state")
	room.queue_free()
	await frames()
	language.settings_path=previous_path
	language.set_language(previous_language,false)
	display.config_path=previous_config_path
	display.window_mode=previous_mode
	display.frame_limit=previous_cap
	display.startup_options=previous_cli
	Engine.max_fps=previous_actual_cap
	OS.set_environment("MEOW_PROFILE_PATH",previous_profile)
	OS.set_environment("MEOW_SKIP_STORY",previous_skip)
	for path in [config_path,profile_path,profile_path+".tmp",profile_path+".bak"]:
		if FileAccess.file_exists(path): DirAccess.remove_absolute(path)
	print("DISPLAY SETTINGS RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
