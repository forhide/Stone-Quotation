extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

var checks := 0
var failures := 0
var scene := preload("res://scenes/main.tscn")

func check(ok: bool, message: String) -> void:
	checks += 1
	if ok:
		print("PASS: "+message)
	else:
		failures += 1
		push_error("FAIL: "+message)

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.physical_keycode=code
	event.pressed=true
	Input.parse_input_event(event)
	event=event.duplicate()
	event.pressed=false
	Input.parse_input_event(event)

func settle() -> void:
	for i in range(3):
		await physics_frame
		await process_frame
	if current_scene==null:
		push_error("Scene transition did not finish")
		quit(2)
		return

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	change_scene_to_packed(scene)
	await settle()
	var room=current_scene
	key(KEY_ENTER)
	await settle()
	check(room.state=="playing","Enter starts real current scene")
	for enemy in room.enemies: enemy.active=false
	room.player.position=Vector2(500,430)
	room.player.take_damage(12,Vector2(450,430))
	room.spells.resolver.forced="success"
	room.spells.cast(Vector2.RIGHT)
	for i in range(12): await physics_frame
	var enemy: CandleSlime=room.enemies[0]
	enemy.cooldown=0.95
	room.effects.append({"point":Vector2(500,400),"age":0.1,"radius":20.0,"color":Color.WHITE})
	key(KEY_ESCAPE)
	await settle()
	check(room.state=="paused","Esc pauses through real input dispatch")
	var invul: float=room.player.invulnerability
	var pose: float=room.player.cast_pose
	var attack: float=enemy.cooldown
	var feedback: float=room.hud.outcome_time
	var cooldown: float=room.spells.cooldown
	var shot=room.projectiles.get_child(0)
	var shot_position: Vector2=shot.position
	var shot_age: float=shot.age
	for i in range(24): await physics_frame
	check(is_equal_approx(room.player.invulnerability,invul),"pause preserves invulnerability time")
	check(is_equal_approx(room.player.cast_pose,pose),"pause preserves casting pose time")
	check(is_equal_approx(enemy.cooldown,attack),"pause preserves enemy attack cooldown")
	check(is_equal_approx(room.hud.outcome_time,feedback),"pause preserves outcome feedback time")
	check(is_equal_approx(room.spells.cooldown,cooldown),"pause preserves spell cooldown")
	check(shot.position==shot_position and shot.age==shot_age,"pause freezes projectile position and lifetime")
	key(KEY_ESCAPE)
	await settle()
	check(room.state=="playing","Esc resumes through real input dispatch")
	for foe in room.enemies: foe.active=false
	for i in range(4): await physics_frame
	check(room.player.invulnerability<invul and room.spells.cooldown<cooldown,"timers resume with combat")
	var original_events: Dictionary={}
	for action in ["move_left","move_right","move_up","move_down","cast"]:
		original_events[action]=InputMap.action_get_events(action).size()
	for i in range(5):
		key(KEY_R)
		await settle()
		room=current_scene
		check(room.state=="intro" and room.enemies.size()==5 and room.player.health.current==100,"restart %d resets room, enemies and HP"%(i+1))
	var bindings_stable:=true
	for action in original_events:
		if InputMap.action_get_events(action).size()!=original_events[action]: bindings_stable=false
	check(bindings_stable,"five restarts do not accumulate input bindings")
	key(KEY_ENTER)
	await settle()
	room=current_scene
	for foe in room.enemies: foe.active=false
	for code in [KEY_F1,KEY_F2,KEY_F3]:
		key(code)
		await settle()
		var expected: String={KEY_F1:"success",KEY_F2:"miscast",KEY_F3:"overreaction"}[code]
		room.spells.cooldown=0
		check(room.spells.cast(Vector2.RIGHT) and room.spells.last_outcome==expected,"debug key selects "+expected)
		check(room.spells.resolver.forced.is_empty(),"forced "+expected+" is consumed once")
		for i in range(45): await physics_frame
	room.player.invulnerability=0
	room.player.take_damage(999,Vector2.ZERO)
	await settle()
	check(room.state=="defeated" and room.hud.menu_portrait.expression=="sleepy","death presents resting portrait and retry")
	key(KEY_ENTER)
	await settle()
	room=current_scene
	check(room.state=="intro" and room.player.health.current==100,"Enter retries after defeat")
	key(KEY_ENTER)
	await settle()
	check(RouteFixture.clear_area(room)==10,"tutorial route waits for both real encounter groups")
	await settle()
	check(room.state=="playing" and room.exit_open,"all tutorial enemies defeated unlocks the passage")
	key(KEY_ENTER)
	await settle()
	check(current_scene.state=="playing" and current_scene.run.stage_index==1 and current_scene.enemies.size()==6,"Enter advances to the next expedition area")
	key(KEY_R)
	await settle()
	key(KEY_ENTER)
	await settle()
	room=current_scene
	for foe in room.enemies: foe.active=false
	room.spells.resolver.forced="miscast"
	room.spells.cooldown=0
	room.spells.cast(Vector2.RIGHT)
	for i in range(12): await physics_frame
	await process_frame
	var burst: MiscastBurst
	for child in room.get_children():
		if child is MiscastBurst: burst=child
	check(is_instance_valid(burst),"failed spell creates visible WHOOPS burst")
	key(KEY_ESCAPE)
	await settle()
	var burst_age := burst.age
	for i in range(12): await physics_frame
	check(is_equal_approx(burst.age,burst_age),"pause freezes miscast smoke and failure marker")
	key(KEY_ESCAPE)
	await settle()
	for i in range(115): await physics_frame
	check(not is_instance_valid(burst),"miscast marker cleans up after feedback")
	var remaining_miscasts := 0
	for shot_node in room.projectiles.get_children():
		if shot_node.outcome=="miscast": remaining_miscasts+=1
	check(remaining_miscasts==0,"misfired projectile expires after a limited tactical window")
	print("REGRESSION RESULT: %d checks, %d failures"%[checks,failures])
	quit(0 if failures==0 else 1)
