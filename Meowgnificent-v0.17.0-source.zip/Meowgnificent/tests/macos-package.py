#!/usr/bin/env python3
"""Validate a macOS ZIP structurally and verify its ad-hoc signature hashes.
This runs on Linux; it does not replace launch/Gatekeeper checks on a Mac.
"""
import hashlib, pathlib, plistlib, stat, struct, sys, zipfile

archive = pathlib.Path(sys.argv[1])
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None, 'Corrupt ZIP'
    for name in z.namelist():
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    infos = [n for n in z.namelist() if n.endswith('.app/Contents/Info.plist')]
    assert len(infos) == 1
    base = infos[0].removesuffix('Info.plist')
    info_data = z.read(infos[0]); info = plistlib.loads(info_data)
    assert info['CFBundleIdentifier'] == 'com.forhide.meowgnificent'
    assert info['CFBundleShortVersionString'] == '0.17.0'
    executable = base + 'MacOS/' + info['CFBundleExecutable']
    assert stat.S_IMODE(z.getinfo(executable).external_attr >> 16) & 0o111 == 0o111
    pcks = [n for n in z.namelist() if n.startswith(base+'Resources/') and n.endswith('.pck')]
    assert len(pcks) == 1 and z.read(pcks[0])[:4] == b'GDPC'
    resource_data = z.read(base+'_CodeSignature/CodeResources')
    seal = plistlib.loads(resource_data)
    sealed = 0
    for table in ['files', 'files2']:
        for name, entry in seal.get(table, {}).items():
            if isinstance(entry, bytes): entry = {'hash': entry}
            if 'symlink' in entry: continue
            data = z.read(base+name)
            for key, algorithm in [('hash','sha1'),('hash2','sha256')]:
                if key in entry:
                    assert hashlib.new(algorithm,data).digest() == entry[key], name
                    sealed += 1
    assert sealed > 0
    raw = z.read(executable)
    slices = []
    magic = struct.unpack_from('>I',raw)[0]
    if magic == 0xcafebabe:
        count = struct.unpack_from('>I',raw,4)[0]
        for i in range(count):
            cpu, subtype, offset, size, align = struct.unpack_from('>IIIII',raw,8+i*20)
            slices.append((cpu,raw[offset:offset+size]))
    else:
        assert struct.unpack_from('<I',raw)[0] == 0xfeedfacf
        slices.append((struct.unpack_from('<I',raw,4)[0],raw))
    cpus = set(); pages = 0
    for cpu, data in slices:
        cpus.add(cpu)
        assert struct.unpack_from('<I',data)[0] == 0xfeedfacf
        commands = struct.unpack_from('<I',data,16)[0]
        pos = 32; signature = None
        for _ in range(commands):
            command, length = struct.unpack_from('<II',data,pos)
            assert length >= 8 and pos+length <= len(data)
            if command == 0x1d:
                start, length_sig = struct.unpack_from('<II',data,pos+8)
                signature = data[start:start+length_sig]
            pos += length
        assert signature is not None, 'Missing code signature'
        sigmagic, siglength, entries = struct.unpack_from('>III',signature)
        assert sigmagic == 0xfade0cc0 and siglength <= len(signature)
        directories = 0
        for slot in range(entries):
            kind, begin = struct.unpack_from('>II',signature,12+slot*8)
            if kind != 0 and not 0x1000 <= kind < 0x1006: continue
            cd = signature[begin:]
            (cdmagic, cdlength, version, flags, hash_offset, ident_offset,
             specials, slots, code_limit) = struct.unpack_from('>9I',cd)
            assert cdmagic == 0xfade0c02 and flags & 2, 'Expected ad-hoc CodeDirectory'
            hash_size, hash_type, platform, page_power = struct.unpack_from('4B',cd,36)
            algorithm = {1:'sha1',2:'sha256',3:'sha256',4:'sha384'}[hash_type]
            page_size = 1 << page_power
            assert slots == (code_limit+page_size-1)//page_size
            def digest(value): return hashlib.new(algorithm,value).digest()[:hash_size]
            for page in range(slots):
                expected = cd[hash_offset+page*hash_size:hash_offset+(page+1)*hash_size]
                assert digest(data[page*page_size:min((page+1)*page_size,code_limit)]) == expected
            for index, value in [(1,info_data),(3,resource_data)]:
                assert specials >= index
                expected = cd[hash_offset-index*hash_size:hash_offset-(index-1)*hash_size]
                assert digest(value) == expected, 'Signature special slot mismatch'
            directories += 1; pages += slots
        assert directories > 0
    assert 0x0100000c in cpus, 'Apple Silicon arm64 required'
    print(f'PASS: ZIP, app metadata, executable permissions, game PCK, Apple Silicon arm64, {sealed} resource hashes and {pages} signed code pages')
    print('Mac runtime and Apple notarization were not tested.')
