extends SceneTree

# Real cast/controller/effect/affinity paths, stepped independently of render FPS.
const SIGNATURES := {"practice_wand":"meteor_shower","thunder_spoon":"chain_lightning","brook_reed_wand":"tidal_surge","frost_whisker_wand":"frost_nova","apprentice_thesis":"cyclone","hopscotch_wand":"stone_quake","moss_bud_staff":"verdant_grove","silverthorn_wand":"metal_bloom"}
var room
var checks := 0
var failures := 0
var profile_path := "/tmp/meow-signatures-%d.json" % OS.get_process_id()
func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func frames(n: int=2) -> void:
 for i in range(n): await process_frame
func fresh() -> void:
 room.skills.reset()
 for node in room.projectiles.get_children(): node.queue_free()
 for foe in room.enemies: foe.queue_free()
 room.enemies.clear()
 await frames()
 room.state="playing"
 room.exit_open=false
 room.player.active=true
 room.player.position=Vector2(800,650)
 room.player.velocity=Vector2.ZERO
 room.player.recoil=Vector2.ZERO
 room.player.roll_time=0
 room.player.health.current=room.player.health.maximum
 room.spells.pending=false
 room.run.inventory.clear()
 room.run.equipment={"wand":"","collar":"","charm":""}
func foe_at(offset: Vector2, role: String="test_neutral") -> CandleSlime:
 var foe := CandleSlime.new()
 foe.position=room.player.position+offset
 foe.role=role
 foe.setup({"hp":10000,"speed":83.0,"contact_damage":1,"radius":14.4},room.player,room.bounds)
 room.actors.add_child(foe)
 foe.set_physics_process(false)
 foe.active=true
 room.enemies.append(foe)
 return foe
func cast(weapon: String, outcome: String="success") -> bool:
 room.run.add_item(weapon)
 room.run.equip_item(weapon)
 room.skills.resolver.forced=outcome
 return room.skills.cast(Vector2.RIGHT)
func actors() -> Array[Node]:
 var result: Array[Node]=[]
 for node in room.projectiles.get_children():
  if not node.is_queued_for_deletion(): result.append(node)
 return result
func tick(seconds: float, step: float=1.0/60.0) -> void:
 var remaining := seconds
 while remaining>0.00001:
  var dt := minf(step,remaining)
  room.skills._physics_process(dt)
  for node in room.projectiles.get_children():
   node.set_physics_process(false)
   if not node.is_queued_for_deletion() and node.can_process() and node.has_method("_physics_process"): node._physics_process(dt)
  remaining-=dt
func run() -> void:
 OS.set_environment("MEOW_SKIP_STORY","1")
 OS.set_environment("MEOW_PROFILE_PATH",profile_path)
 change_scene_to_file("res://scenes/main.tscn")
 await frames(6)
 room=current_scene
 room.begin_or_restart()
 room.set_process(false)
 room.set_physics_process(false)
 room.player.set_physics_process(false)
 room.spells.set_physics_process(false)
 room.skills.set_physics_process(false)
 for weapon: String in SIGNATURES:
  for outcome in ["success","miscast","overreaction"]:
   await fresh()
   var targets: Array[CandleSlime]=[]
   for x in [-270,-100,40,140,240,350]: targets.append(foe_at(Vector2(x,0)))
   check(cast(weapon,outcome) and room.skills.current_skill_id()==SIGNATURES[weapon],weapon+":"+outcome+" enters its equipped signature")
   var count := actors().size()
   check(count>=1 and count<=3 and is_instance_valid(room.skills.cast_cue),weapon+":"+outcome+" has a bounded world effect and caster flourish")
   tick(0.25)
   check(targets.all(func(foe: CandleSlime): return foe.health.current==10000),weapon+":"+outcome+" gives a visible anticipation before damage")
   tick(3.8)
   check(targets.any(func(foe: CandleSlime): return foe.health.current<10000),weapon+":"+outcome+" affects real enemy health")
   check(actors().is_empty(),weapon+":"+outcome+" expires all effect nodes")
 await fresh()
 var meteor_target := foe_at(Vector2(260,0))
 cast("practice_wand")
 tick(0.43)
 var first_hp: int=meteor_target.health.current
 check(first_hp<10000 and actors().size()==3,"three meteor actors produce only their first impact at the first landing time")
 tick(0.23)
 var second_hp: int=meteor_target.health.current
 tick(0.23)
 check(second_hp<first_hp and meteor_target.health.current<second_hp,"second and third meteors strike at separate delayed landing times")
 await fresh()
 var targets: Array[CandleSlime]=[]
 for x in [80,180,280,380,480,580]: targets.append(foe_at(Vector2(x,0)))
 cast("thunder_spoon")
 var chain=actors()[0]
 tick(0.35)
 check(chain.pulse_index==1 and targets.filter(func(foe: CandleSlime): return foe.health.current<10000).size()==1,"chain lightning starts with one real contact after its warning")
 tick(0.5)
 check(chain.pulse_index==5 and chain.hit_times.size()==5 and chain.points.size()==6,"chain lightning connects at most five distinct foes with actual acquired points")
 check(targets.filter(func(foe: CandleSlime): return foe.health.current<10000).size()==5,"the sixth reachable foe is excluded by the chain cap")
 var hp := targets.map(func(foe: CandleSlime): return foe.health.current)
 tick(0.5)
 check(hp==targets.map(func(foe: CandleSlime): return foe.health.current),"a lightning chain never revisits and damages the same enemy twice")
 await fresh()
 var wave := foe_at(Vector2(220,0),"candle")
 cast("brook_reed_wand")
 tick(1.0,0.31)
 check(wave.health.current<10000 and wave.affinity_snapshot().wet_time>0 and wave.knockback.x>0,"tidal surge sweeps across coarse time steps, wets and pushes its target")
 var water_hp: int=wave.health.current
 room.skills.cooldown_remaining=0
 cast("thunder_spoon")
 tick(0.36)
 check(water_hp-wave.health.current==ElementAffinity.damage(34+int(room.run.stats().get("skill_damage_bonus",0)),1.5) and wave.affinity_snapshot().wet_time==0,"lightning consumes a real water skill's wet state for one non-stacking conductive hit")
 await fresh()
 var frost := foe_at(Vector2(130,0))
 cast("frost_whisker_wand")
 tick(0.36)
 check(frost.config.speed<30 and frost.active,"frost nova slows actual movement while allowing enemy behavior")
 var slow: float=frost.config.speed
 var effect_age: float=actors()[0].age
 room.state="inventory"
 tick(3)
 check(frost.config.speed==slow and actors()[0].age==effect_age,"inventory freezes the nova picture and its debuff duration")
 room.state="playing"
 tick(3)
 check(frost.config.speed==83.0 and room.skills.status_leases.is_empty(),"nova slow restores the exact original speed after resuming")
 await fresh()
 var pulled := foe_at(Vector2(145,50))
 cast("apprentice_thesis")
 tick(0.36)
 check(pulled.health.current<10000 and pulled.knockback.y<0,"cyclone deals damage and pulls a nearby enemy toward the moving vortex")
 await fresh()
 var near := foe_at(Vector2(70,0))
 var outer := foe_at(Vector2(190,0))
 cast("hopscotch_wand")
 tick(0.36)
 check(near.health.current<10000 and outer.health.current==10000,"stone quake begins with a small first ring")
 tick(0.57)
 check(outer.health.current<10000,"stone quake reaches outer foes only on the wider late pulse")
 await fresh()
 var rooted := foe_at(Vector2(225,0))
 cast("moss_bud_staff")
 tick(0.36)
 check(not rooted.active and rooted.health.current<10000,"verdant grove grows into a real root and damage effect")
 var root_hp: int=rooted.health.current
 tick(1.2)
 check(rooted.health.current<root_hp and not rooted.active,"the growing grove deals bounded repeated damage and renews its root")
 room.skills.clear_transients()
 check(rooted.active and rooted.config.speed==83.0 and actors().is_empty(),"explicit transition cleanup restores rooted enemies and removes the grove")
 await fresh()
 var thorn := foe_at(Vector2(240,0))
 cast("silverthorn_wand")
 tick(0.35)
 var thorn_hp: int=thorn.health.current
 tick(0.31)
 var final_hp: int=thorn.health.current
 tick(1)
 check(thorn_hp<10000 and final_hp<thorn_hp and thorn.health.current==final_hp,"metal bloom has exactly two real eruptions")
 await fresh()
 var resisting := foe_at(Vector2(260,0),"candle")
 var weak := foe_at(Vector2(260,50),"book")
 cast("practice_wand")
 tick(0.43)
 check(10000-weak.health.current>10000-resisting.health.current and weak.affinity_snapshot().reaction=="weak" and resisting.affinity_snapshot().reaction=="resist","the same meteor obeys enemy weaknesses and resistances")
 await fresh()
 var snapshot_target := foe_at(Vector2(260,0),"candle")
 cast("practice_wand")
 room.run.add_item("thunder_spoon")
 room.run.equip_item("thunder_spoon")
 tick(0.43)
 check(snapshot_target.affinity_snapshot().reaction=="resist","equipping a different weapon cannot change the element of an already launched meteor")
 await fresh()
 foe_at(Vector2(260,0))
 cast("practice_wand")
 tick(0.43)
 room.skills.clear_transients(true)
 var tails := actors()
 check(tails.size()==1 and tails[0].is_cosmetic_tail() and tails[0].damage==0,"encounter cleanup keeps only a landed meteor's harmless impact tail")
 var tail_duration: float=tails[0].duration
 room.skills.clear_transients(true)
 check(tails[0].duration==tail_duration,"repeated area cleanup cannot extend a cosmetic impact indefinitely")
 var untouched := foe_at(Vector2(260,0))
 tick(2)
 check(untouched.health.current==10000 and actors().is_empty(),"the preserved tail cannot damage a new foe and expires within a bounded time")
 await fresh()
 foe_at(Vector2(260,0))
 cast("practice_wand")
 tick(0.43)
 room.skills.clear_transients(true)
 room.skills.clear_transients()
 check(actors().is_empty(),"a later full transition removes even previously preserved cosmetic tails")
 room.queue_free()
 await frames(4)
 for suffix in ["",".tmp",".bak"]:
  if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
 print("SIGNATURE SKILLS RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
