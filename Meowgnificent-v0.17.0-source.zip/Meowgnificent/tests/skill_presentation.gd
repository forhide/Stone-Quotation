extends SceneTree

# The real Q entry point must read as a special skill without creating the
# primary spell's failure cloud. Existing item_skills covers damage and balance.
var checks := 0
var failures := 0
var room
var profile_path := "/tmp/meow-skill-presentation-%d.json" % OS.get_process_id()
const EFFECTS := {"spark_burst":"spark","ember_ring":"ring","cinder_fan":"fan","margin_burst":"pages","frost_wave":"frost","blink_burst":"blink","chicken_dash":"chicken","vine_snare":"vine","potion_bomb":"potion","thunder_stamp":"thunder","bubble_guard":"bubble","comet_shower":"meteor","meteor_shower":"fire_meteor","chain_lightning":"chain_lightning","tidal_surge":"tidal_surge","frost_nova":"frost_nova","cyclone":"cyclone","stone_quake":"stone_quake","verdant_grove":"verdant_grove","metal_bloom":"metal_bloom"}
func _initialize() -> void: call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(n: int=2) -> void:
	for i in range(n): await process_frame
func puffs() -> int:
	var found := 0
	for child in room.get_children():
		if child is MiscastBurst and not child.is_queued_for_deletion(): found+=1
	return found
func clear_cast() -> void:
	room.skills.clear_transients()
	room.skills.clear_presentation()
	room.hud.clear_skill_cast()
	room.skills.cooldown_remaining=0
	room.spells.cooldown=0
	room.spells.pending=false
	room.player.roll_time=0
	room.player.position=Vector2(500,450)
	room.player.reset_physics_interpolation()
func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames(5)
	room=current_scene
	room.begin_or_restart()
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.spells.set_physics_process(false)
	room.skills.set_physics_process(false)
	for foe in room.enemies:
		foe.active=false
		foe.set_physics_process(false)
		foe.position=Vector2(1100,240)
		foe.health.maximum=10000
		foe.health.current=10000
	var mesh_id: int=room.player.visual.sprite.mesh.get_instance_id()
	var echo_id: int=room.player.visual.skill_echo.get_instance_id()
	var signatures: Dictionary={}
	for id: String in EFFECTS:
		var item_id := str(room.skills.definitions[id].item_id)
		# Exercise compatibility definitions explicitly; equipped elemental skills
		# are covered against the unmodified catalog in item_skills.
		room.run.catalog[item_id].skill_id=id
		if not room.run.inventory.has(item_id): room.run.add_item(item_id)
		room.equip_gear(item_id)
		for outcome in ["success","miscast","overreaction"]:
			clear_cast()
			await frames()
			room.skills.resolver.forced=outcome
			var accepted: bool=room.skills.cast(Vector2.RIGHT)
			var cue=room.skills.cast_cue
			check(accepted and is_instance_valid(cue) and cue.skill_id==id and room.player.skill_pose_id==id,"Q begins its own body flourish and caster signature: "+id+":"+outcome)
			check(puffs()==0 and room.hud.skill_flash_remaining>0 and room.hud.skill_flash_name==str(room.skills.definitions[id].name),"Q names the special and never borrows the basic failure puff: "+id+":"+outcome)
			var found := false
			var active_count := 0
			for actor in room.skills.spawned_effects:
				if not is_instance_valid(actor) or actor.is_queued_for_deletion(): continue
				active_count+=1
				if actor is ItemSkillEffect:
					var expected := "bubble_wrong" if id=="bubble_guard" and outcome=="miscast" else str(EFFECTS[id])
					if actor.kind==expected:
						found=true
						signatures[id]=actor.presentation_snapshot().signature
			check(found and active_count<=8,"the skill has its own bounded, recognizable world effect: "+id+":"+outcome)
	check(signatures.size()==20 and not signatures.values().has("storybook_skill"),"all twenty skill definitions have authored identities instead of a fallback impact")
	check(room.player.visual.sprite.mesh.get_instance_id()==mesh_id and room.player.visual.skill_echo.get_instance_id()==echo_id,"many skill activations reuse the existing whole-body mesh and expression blend")
	clear_cast()
	room.run.catalog.practice_wand.skill_id="spark_burst"
	room.equip_gear("practice_wand")
	room.skills.resolver.forced="success"
	room.skills.cast(Vector2.RIGHT)
	check(not room.spells.cast(Vector2.RIGHT),"holding basic fire cannot overwrite the main part of a Q flourish")
	var cue=room.skills.cast_cue
	cue._process(0.12)
	var age: float=cue.age
	room.open_inventory()
	cue._process(0.3)
	var flash: float=room.hud.skill_flash_remaining
	room.hud._process(0.3)
	check(is_equal_approx(cue.age,age) and is_equal_approx(room.hud.skill_flash_remaining,flash),"inventory pauses both the special gesture cue and its HUD confirmation")
	room.close_panel()
	cue._process(0.12)
	check(cue.age>age,"a paused Q cue continues from its current phase when play resumes")
	room.load_sector(1)
	await frames()
	check(room.skills.cast_cue==null and room.player.skill_pose_time==0 and room.hud.skill_flash_remaining==0,"stage changes clear the previous skill's pose, cue and status together")
	# The last group of an area leaves its cosmetic confirmation on a final hit.
	while room.encounters.index<room.encounters.definitions.size()-1:
		for foe in room.enemies.duplicate(): foe.take_damage(99999,Vector2.RIGHT)
		check(preload("res://tests/route_fixture.gd").arrive_next(room),"the next real encounter arrives before the final-hit presentation check")
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.skills.set_physics_process(false)
	for foe in room.enemies.duplicate():
		if foe!=room.enemies[0]:
			room.enemies.erase(foe)
			foe.queue_free()
	var last=room.enemies[0]
	last.active=false
	last.set_physics_process(false)
	last.health.current=1
	room.player.position=Vector2(500,450)
	last.position=Vector2(625,450)
	room.run.catalog.practice_wand.skill_id="spark_burst"
	room.equip_gear("practice_wand")
	room.skills.cooldown_remaining=0
	room.skills.resolver.forced="success"
	room.skills.cast(Vector2.RIGHT)
	check(room.exit_open and is_instance_valid(room.skills.cast_cue) and room.hud.skill_flash_remaining>0,"a final-hit Pocket Spark remains visibly confirmed after damaging actors are cleared")
	room.load_sector(0)
	room.on_spell_emitted("miscast",room.player.position)
	check(puffs()==1,"ordinary failed basic magic retains its separate unmistakable failure cloud")
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("SKILL PRESENTATION RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
