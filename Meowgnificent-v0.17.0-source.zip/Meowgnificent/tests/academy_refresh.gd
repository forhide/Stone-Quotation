extends SceneTree
var checks := 0
var failures := 0
var room
func check(ok: bool, text: String) -> void:
	checks+=1
	if ok: print("PASS: "+text)
	else:
		failures+=1
		push_error("FAIL: "+text)
func _initialize() -> void: call_deferred("run")
func frames(n: int) -> void:
	for i in range(n):
		await physics_frame
		await process_frame
func quiet() -> void:
	for enemy in room.enemies: enemy.active=false
func run() -> void:
	var geometry := RoomObstacles.new()
	root.add_child(geometry)
	geometry.entries=[{"kind":"table","rect":Rect2(500,400,120,90)}]
	for distance in [150.0,500.0,4000.0]:
		var hit := geometry.sweep(Vector2(350,440),Vector2(350+distance,440),18,false)
		check(hit.point.x<482.01 and not hit.hit.is_empty(),"full motion stops before furniture even at coarse travel: "+str(distance))
	var sliding := geometry.sweep(Vector2(420,360),Vector2(700,470),18,true)
	check(geometry.containing(sliding.point,18).is_empty() and sliding.path.size()>=2,"diagonal motion slides outside the ground footprint")
	check(geometry.containing(geometry.project_out(Vector2(550,430),18),18).is_empty(),"an inside spawn can be safely moved to the nearest free edge")
	check(not geometry.clear_line(Vector2(350,440),Vector2(750,440),18) and geometry.steer(Vector2(350,440),Vector2(750,440),18)!=Vector2.RIGHT,"grounded enemies steer around the same cover")
	change_scene_to_file("res://scenes/main.tscn")
	await frames(3)
	room=current_scene
	room.begin_or_restart()
	room.load_sector(3)
	quiet()
	check(is_instance_valid(room.markers.gathering.table_foreground) and room.markers.gathering.table_foreground.get_parent()==room.actors,"the solid table foreground shares actor depth sorting")
	room.load_sector(3)
	await frames(2)
	check(is_instance_valid(room.markers.gathering.table_foreground) and room.markers.gathering.table_foreground.get_parent()==room.actors,"reloading the same rest stop retains table depth sorting")
	var table := WorldLayout.rect(RoomObstacles.TABLE_FOOTPRINT)
	room.player.position=Vector2(table.get_center().x,table.end.y+100)
	room.player.reset_physics_interpolation()
	room.player.roll_cooldown=0
	room.player.start_roll(Vector2.UP)
	await frames(26)
	check(room.player.position.y>=table.end.y+float(room.player.config.radius)-0.1 and room.player.roll_time==0,"a real roll cannot cross the shop's painted table")
	room.player.position=Vector2(table.position.x-80,table.end.y+70)
	room.player.velocity=Vector2.ZERO
	room.player.recoil=Vector2.ZERO
	room.player.roll_cooldown=0
	room.player.start_roll(Vector2.UP)
	await frames(25)
	check(room.player.position.y<table.end.y-40,"the clear lane beside the table stays traversable")
	room.load_sector(1)
	quiet()
	var shelf: ArcaneShelf=room.props[0]
	room.player.position=shelf.position-Vector2(145,0)
	room.player.velocity=Vector2.ZERO
	room.player.roll_cooldown=0
	room.player.start_roll(Vector2.RIGHT)
	await frames(14)
	check(room.player.position.x<shelf.position.x-60 and shelf.state=="falling" and room.player.roll_time==0,"a cupboard stops a roll before it topples")
	await frames(28)
	check(shelf.state=="fallen" and room.obstacles.containing(shelf.position,1).is_empty(),"collapsed furniture opens its former footprint")
	room.player.position=Vector2(750,440)
	room.player.invulnerability=0
	var hp: int=room.player.health.current
	var foe: CandleSlime=room.enemies[0]
	foe.obstacle_world=geometry
	foe.role="broom"
	foe.position=Vector2(350,440)
	foe.attack_direction=Vector2.RIGHT
	foe.phase="windup"
	var preview := foe.get_attack_preview()
	check((preview.path[preview.path.size()-1]+foe.position).x<500,"attack warning ends at solid cover")
	foe._advance_dash(2.0)
	check(foe.position.x<500 and room.player.health.current==hp,"a coarse enemy dash cannot hit the cat through furniture")
	quiet()
	room.player.hit_reaction=0
	room.player.invulnerability=0
	room.player.mark_miscast()
	room.player.visual._process(0)
	check(is_equal_approx(room.player.soot_time,2.8) and room.player.visual.motion_material.get_shader_parameter("soot_amount")>0.9,"miscasting applies visible soot for2.8seconds")
	check(room.player.health.current==hp and room.player.hit_reaction==0 and room.player.invulnerability==0,"soot is distinct from damage and never grants hit protection")
	room.set_running(false)
	await frames(5)
	check(is_equal_approx(room.player.soot_time,2.8),"pause freezes soot duration")
	room.set_running(true)
	quiet()
	room.player._physics_process(1.4)
	check(room.player.soot_time>1.3,"soot remains through the middle of the requested duration")
	room.player._physics_process(1.5)
	check(room.player.soot_time==0,"soot clears without a permanent palette change")
	var path := "/tmp/meow-academy-%d.json" % OS.get_process_id()
	var f := FileAccess.open(path,FileAccess.WRITE)
	f.store_string(JSON.stringify({"version":1,"starlight":50,"upgrades":{"vitality":4,"purse":2,"magnet":3,"starter_wand":1}}))
	f.close()
	var meta := MetaProgress.new(path)
	check(meta.starlight==50 and meta.upgrades.vitality==4 and meta.bonuses().max_hp_bonus==20 and meta.upgrades.spell_power==0,"version1 saves retain currency and old ranks, with new studies empty")
	check(meta.upgrade_offers().size()==16 and meta.study_progress().total==125,"sixteen real studies offer125total ranks")
	meta.begin_run()
	check(JSON.parse_string(FileAccess.get_file_as_string(path)).version==2,"a normal commit migrates the save to the protected version2 format")
	check(meta.record_research(1)==0 and meta.finish_run(false) and meta.starlight==51,"a first defeat with one foe beaten keeps a research reward")
	check(not meta.finish_run(false) and meta.starlight==51,"the same defeat never pays twice")
	meta.begin_run()
	check(meta.record_research(6)==2 and meta.record_research(6)==0 and meta.record_research(9)==1,"research pays for actual progress and rejects repeated counts")
	meta.finish_run(false)
	check(MetaProgress.new(path).starlight==54,"research survives defeat and an independent profile reload")
	room.profile=MetaProgress.new(path+"-fresh")
	var before := CharacterStats.for_room(room)
	room.profile.starlight=10000
	for id: String in MetaProgress.UPGRADES:
		for i in range(MetaProgress.UPGRADES[id].costs.size()): check(room.profile.purchase_upgrade(id).ok,"real purchase: "+id+" rank "+str(i+1))
	check(room.profile.study_progress().level==125,"all branches are purchasable and have finite caps")
	var after := CharacterStats.for_room(room)
	check(after.max_hp>before.max_hp and after.speed>before.speed and after.spell_damage>before.spell_damage and after.spell_cooldown<before.spell_cooldown,"permanent vitality, movement and basic magic affect the actual stat model")
	check(after.skill_damage>before.skill_damage and after.skill_cooldown<before.skill_cooldown and after.skill_radius>before.skill_radius and after.roll_damage>before.roll_damage and after.roll_cooldown<before.roll_cooldown,"special and roll research affect the actual stat model")
	room.apply_equipment()
	room.player.health.current=room.player.health.maximum
	room.player.invulnerability=0
	room.player.take_damage(20,Vector2.ZERO)
	check(room.player.health.current==room.player.health.maximum-12 and room.player.invulnerability>0.8,"armor and hit protection change real incoming damage")
	room.player.health.current-=20
	room.player.invulnerability=0
	var food: LootPickup=room.spawn_pickup("food",room.player.position,20)
	var previous: int=room.player.health.current
	room.collect_pickup(food)
	check(room.player.health.current-previous==32,"snack research heals actual missing vitality without overheal")
	room.state="intro"
	room.open_legacy()
	for lang in ["ko","en"]:
		GameLocale.set_language(lang,false)
		for category: String in MetaProgress.STUDY_CATEGORIES:
			var tab_index: int=MetaProgress.STUDY_CATEGORIES.keys().find(category)
			room.panel.content.get_child(0).get_child(tab_index).pressed.emit()
			check(room.panel.meta_category==category,"notebook button opens the chosen category: "+category)
			await frames(3)
			check(room.panel.purchase_buttons.size()==4,"four visible studies in notebook: "+lang+category)
			var bottom: float=room.panel.close_button.get_global_rect().position.y
			var valid := true
			for button in room.panel.purchase_buttons: valid=valid and button.get_global_rect().end.y<bottom
			check(valid and room.panel.close_button.get_global_rect().end.y<790,"study notebook and return control remain inside the screen: "+lang+category)
	for id: String in EnchantedArt.SKILLS+EnchantedArt.REGIONS.keys()+EnchantedArt.PROP_REGIONS.keys()+EnchantedArt.EXTRA_REGIONS.keys():
		var art := EnchantedArt.part(id) as AtlasTexture
		check(art!=null and Rect2(Vector2.ZERO,art.atlas.get_size()).encloses(art.region),"painted atlas crop is valid: "+id)
	room.queue_free()
	geometry.queue_free()
	await process_frame
	for suffix in ["",".bak","-fresh","-fresh.bak"]: if FileAccess.file_exists(path+suffix): DirAccess.remove_absolute(path+suffix)
	print("ACADEMY REFRESH RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
