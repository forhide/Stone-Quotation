extends SceneTree

# Identity regression: correct-size crops can still show a different item.
# Every authored atlas is semantically row-major, regardless of object height.
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func run() -> void:
 var groups := [
  {"sheet":EquipmentArt.SHEET,"ids":["crooked_ash_wand","cinderfork_wand","apprentice_thesis","brass_bell_collar","velvet_bell_collar","nine_lives_collar","loose_feather","warm_sardine_charm","moonlit_yarn"]},
  {"sheet":EquipmentArt.WEAPON_SHEET,"ids":EquipmentArt.NEW_WEAPONS},
  {"sheet":EquipmentArt.PENDANT_SHEET,"ids":EquipmentArt.NEW_COLLARS},
  {"sheet":EquipmentArt.CHARM_SHEET,"ids":EquipmentArt.NEW_CHARMS}
 ]
 for group: Dictionary in groups:
  var seen := {}
  var bounds_valid := true
  for i in range(group.ids.size()):
   var id: String=group.ids[i]
   var art := EquipmentArt.icon(id) as AtlasTexture
   var center := art.region.get_center()
   var cell := Vector2i(floori(center.x/418.0),floori(center.y/418.0))
   check(art.atlas==group.sheet and cell==Vector2i(i%3,i/3),"item picture matches its authored identity row and column: "+id)
   bounds_valid=bounds_valid and Rect2(Vector2.ZERO,art.atlas.get_size()).encloses(art.region) and not seen.has(art.region)
   seen[art.region]=true
  check(bounds_valid and seen.size()==9,"all nine identity crops are distinct and remain inside their shared sheet")
 var journey_groups := [
  {"sheet":EquipmentArt.JOURNEY_WEAPONS_SHEET,"ids":EquipmentArt.JOURNEY_WEAPONS},
  {"sheet":EquipmentArt.JOURNEY_TRINKETS_SHEET,"ids":EquipmentArt.JOURNEY_COLLARS+EquipmentArt.JOURNEY_CHARMS}
 ]
 for group: Dictionary in journey_groups:
  var regions := {}
  for i in range(group.ids.size()):
   var id: String=group.ids[i]
   var art := EquipmentArt.icon(id) as AtlasTexture
   var center := art.region.get_center()
   var cell := Vector2i(floori(center.x/256.0),floori(center.y/256.0))
   check(art.atlas==group.sheet and cell==Vector2i(i%6,i/6),"journey artwork preserves its painted element and tier identity: "+id)
   regions[art.region]=true
  check(regions.size()==24,"the journey sheet exposes24 different painted equipment silhouettes")
 var thorn := EquipmentArt.icon("silverthorn_wand") as AtlasTexture
 check(thorn!=null and thorn.atlas==EquipmentArt.SILVERTHORN_SHEET and Rect2(Vector2.ZERO,thorn.atlas.get_size()).encloses(thorn.region),"the silverthorn icon uses its own intact painted identity within source bounds")
 check(EquipmentArt.worn_icon("silverthorn_wand")==thorn and EquipmentArt.slot_for("silverthorn_wand")=="wand","the new metal weapon shares its inventory art with the correct paw attachment")
 # This suite runs against source PNGs (tests are excluded from exports).
 var source := Image.new()
 var decoded := source.load_png_from_buffer(FileAccess.get_file_as_bytes("res://art/equipment/cute_equipment.png"))
 if decoded!=OK:
  push_error("Could not decode source atlas for pendant outline checks")
  quit(1)
  return
 for id: String in EquipmentArt.ORIGINAL_PENDANTS:
  var art := EquipmentArt.worn_icon(id) as AtlasTexture
  var crop := Rect2i(art.region)
  var side_alpha := 0.0
  for y in range(crop.position.y,crop.end.y):
   side_alpha=maxf(side_alpha,maxf(source.get_pixel(crop.position.x,y).a,source.get_pixel(crop.end.x-1,y).a))
  for x in range(crop.position.x,crop.end.x):
   side_alpha=maxf(side_alpha,source.get_pixel(x,crop.end.y-1).a)
  check(side_alpha<0.05,"worn pendant preserves left/right/bottom outline with transparent margin: "+id)
 print("ART MAPPING RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
