extends SceneTree

# Exercise navigation and dialogue in the real scrolling world. In particular,
# old canonical coordinates must not silently point at a different animal.
var checks := 0
var failures := 0
var room
var profile_path := "/tmp/meow-expedition-ui-%d.json" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(count: int=3) -> void:
	for i in range(count): await process_frame

func stop_motion() -> void:
	room.set_process(false)
	room.set_physics_process(false)
	room.player.set_process(false)
	room.player.set_physics_process(false)
	room.spells.set_physics_process(false)
	room.skills.set_physics_process(false)
	room.hud.set_process(false)
	for enemy in room.enemies:
		enemy.set_physics_process(false)
		enemy.set_process(false)

func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames(5)
	room=current_scene
	room.begin_or_restart()
	stop_motion()
	var hud: WizardHUD=room.hud
	var language=root.get_node("Language")
	var old_language: String=language.current
	language.set_language("en",false)
	check(room.bounds==Rect2(160,256,1728,856),"the playable floor has grown in both axes, rather than merely changing the window resolution")
	check(room.background.scale*Vector2(room.background_viewport.size)==Vector2(2048,1280),"the cached illustration covers the entire enlarged world")
	check(not room.backdrop_painter.include_frame and room.backdrop_painter.gameplay_landmarks,"the live world retains book and mushroom landmarks without baking the fixed HUD into the floor")
	check(is_equal_approx(room.player.presentation_scale,0.8) and room.enemies.all(func(enemy: Node2D) -> bool: return enemy.scale.x<=1.0),"the actual cat and enemy presentations are reduced inside the larger arena")
	var canonical=room.encounters.current_definition().positions
	check(room.enemies[0].position.is_equal_approx(WorldLayout.point(Vector2(canonical[0][0],canonical[0][1]))),"the first live guardian stands at its enlarged authored encounter position")
	for focus in [Vector2(160,256),Vector2(1888,256),Vector2(160,1112),Vector2(1888,1112)]:
		var camera_view := Rect2(WorldLayout.camera_center(focus)-Vector2(640,400),Vector2(1280,800))
		check(WorldLayout.CANVAS.encloses(camera_view),"camera clamping never exposes empty space at floor corner "+str(focus))
	hud._process(0.1)
	var compass= hud.route_compass
	check(Rect2(417,18,291,92).encloses(compass.get_global_rect()) and not compass.get_global_rect().intersects(hud.inventory_button.get_global_rect()),"the minimap fits inside the purse header without covering the inventory button")
	check(compass.snapshot().visible and compass.snapshot().enemies==room.enemies.size(),"the real minimap includes every live guardian in the active group")
	check(not compass.destination.is_equal_approx(WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)),"a locked passage is not prematurely advertised as the map destination")
	check(hud.enemy_label.text=="Fight 1 / 2 · %d foes" % room.enemies.size(),"the header distinguishes the first combat group from completion of the whole area")
	var target=room.enemies[0]
	room.player.position=target.position-Vector2(150,0)
	room.player.aim=Vector2.RIGHT
	for other in room.enemies:
		if other!=target: other.position=room.player.position+Vector2(-350,200)
	hud._process(0.11)
	check(hud.status_label.text.contains("Water/Ice") and hud.status_label.text.contains("Fire") and not hud.status_label.text.contains("["),"aiming at a candle shows readable material weaknesses instead of raw array data")
	language.set_language("ko",false)
	hud._process(0.11)
	check(not hud.status_label.text.contains("Water") and not hud.status_label.text.contains("Fire") and hud.status_label.text.contains("물"),"aimed weakness feedback refreshes into Korean without retaining English element names")
	for enemy in room.enemies.duplicate(): enemy.take_damage(99999,Vector2.RIGHT)
	await frames()
	hud._process(0.1)
	check(room.encounters.state=="waiting" and not room.exit_open and not room.markers.exit_snapshot().visible,"clearing the first group reveals the next encounter rather than the stage exit")
	check(compass.has_destination and compass.destination==room.encounters.waypoint() and compass.enemy_points.is_empty(),"between fights the map points to the actual next seal and removes defeated guardians")
	check(hud.enemy_label.text==GameLocale.text("Next fight · follow the seal"),"the header explains what to do between fights")
	room.encounters.tick(0.1,room.encounters.waypoint(),true)
	for i in range(7): room.encounters.tick(0.1,room.encounters.waypoint(),true)
	hud._process(0.1)
	check(room.encounters.state=="windup" and hud.enemy_label.text==GameLocale.text("Seal opening… get ready!"),"the visible arrival warning has a matching preparation caption")
	room.load_sector(3)
	stop_motion()
	hud._process(0.1)
	var party: ShopGathering=room.markers.gathering
	check(compass.enemy_points.is_empty() and compass.destination==WorldLayout.point(ExpeditionMarkers.EXIT_POSITION),"a safe stop map leads to its real open exit")
	for id: String in ["moss","bloop"]:
		var feet: Vector2=WorldLayout.point(ShopGathering.FRIEND_POSITIONS[id])
		room.player.position=feet+Vector2(0,30)
		room.camera.position=WorldLayout.camera_center(room.player.position)
		room.camera.reset_smoothing()
		room.camera.force_update_scroll()
		party.set_player_position(room.player.position)
		party.animate(0.3)
		check(party.nearest_interaction(room.player.position)==id and party.friend_roots[id].global_position.is_equal_approx(feet),"interaction and illustrated feet share the same world anchor: "+id)
		room.interact()
		await frames()
		party.animate(0.1)
		check(party.active_actor==id and Rect2(24,126,1232,572).encloses(party.conversation.get_global_rect()),"scrolling to "+id+" opens a readable speech card inside the fixed UI safe area")
		check(party.friend_roots[id].global_scale.x<0.82 and party.friend_roots[id].global_scale.x>0.78,"the animal keeps the new actor scale rather than inheriting the enlarged scenery: "+id)
	language.set_language(old_language,false)
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("EXPEDITION UI RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
