extends SceneTree

# Physical contact is checked through actual coarse physics steps. Cutscene
# props are checked through the same page/animation lifecycle as normal play.
class TrainingCat extends WizardCat:
	func _ready() -> void: pass

var checks := 0
var failures := 0
var arena := Rect2(100,160,1080,535)
var cat: WizardCat
var room
var profile_path := "/tmp/meow-polish-%d.json" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func make_enemy(role: String, parent: Node=root) -> CandleSlime:
	var enemy: CandleSlime=LivingStageEnemy.new() if role in ["book","mushroom"] else CandleSlime.new()
	enemy.role=role
	enemy.position=Vector2(600,410)
	enemy.setup({"hp":40,"speed":83.0,"contact_damage":12,"radius":18.0},cat,arena)
	parent.add_child(enemy)
	enemy.set_physics_process(false)
	return enemy

func arm(enemy: CandleSlime, direction: Vector2=Vector2.RIGHT) -> void:
	enemy.phase="attack"
	enemy.phase_time=enemy.attack_duration()
	enemy.attack_origin=enemy.position
	enemy.attack_direction=direction
	enemy.attack_hit=false
	cat.health.current=100
	cat.invulnerability=0
	cat.recoil=Vector2.ZERO

func echoes(parent: Node) -> Array[EnemyDissolve]:
	var found: Array[EnemyDissolve]=[]
	for child in parent.get_children():
		if child is EnemyDissolve and not child.is_queued_for_deletion(): found.append(child)
	return found

func run() -> void:
	cat=TrainingCat.new()
	cat.setup({"hp":100,"radius":23.0,"invulnerability":0.65},arena)
	root.add_child(cat)
	cat.set_physics_process(false)
	for role in ["broom","bat","book"]:
		var enemy := make_enemy(role)
		arm(enemy)
		cat.position=enemy.position+Vector2(enemy.attack_speed()*enemy.attack_duration()*0.5,0)
		var expected := enemy.position+enemy.attack_direction*enemy.attack_speed()*enemy.attack_duration()
		enemy._physics_process(0.55)
		check(cat.health.current==88 and enemy.attack_hit,role+": a coarse tick still hits the cat inside the announced dash instead of skipping over it")
		check(enemy.position.distance_to(expected)<0.001 and enemy.phase=="recover",role+": the same coarse tick stops at the promised endpoint and enters recovery")
		cat.invulnerability=0
		enemy._physics_process(0.2)
		check(cat.health.current==88,role+": one dash cannot charge contact damage twice")
		enemy.free()
	# A diagonal clipped path must test its wall slide, not only a false chord.
	var wall_enemy := make_enemy("book")
	wall_enemy.position=Vector2(1130,400)
	arm(wall_enemy,Vector2(1,1).normalized())
	cat.position=Vector2(1160,520)
	wall_enemy._physics_process(0.5)
	check(cat.health.current==88 and is_equal_approx(wall_enemy.position.x,1160.0),"the wall-clipped book dash hits along the advertised wall-slide segment")
	wall_enemy.free()
	var safe_enemy := make_enemy("book")
	arm(safe_enemy)
	cat.position=safe_enemy.position+Vector2(100,safe_enemy.contact_radius()+0.1)
	safe_enemy._physics_process(0.5)
	check(cat.health.current==100,"the swept contact fix preserves safety immediately outside the visible lane")
	safe_enemy.free()
	var actor_parent := Node2D.new()
	root.add_child(actor_parent)
	var recoil_enemy := make_enemy("mushroom",actor_parent)
	recoil_enemy._sync_visuals()
	var before := recoil_enemy.body_root.scale
	recoil_enemy.take_damage(1,Vector2.RIGHT)
	recoil_enemy._sync_visuals()
	check(recoil_enemy.body_root.scale.x>before.x and recoil_enemy.body_root.scale.y<before.y,"a surviving living foe compresses visibly without moving its grounded root")
	var signalled := [0]
	recoil_enemy.defeated.connect(func(_enemy): signalled[0]+=1)
	recoil_enemy.take_damage(999,Vector2.LEFT)
	var list := echoes(actor_parent)
	check(signalled[0]==1 and recoil_enemy.health.current==0 and recoil_enemy.is_queued_for_deletion(),"defeat and loot callbacks occur immediately, independent of the departing picture")
	check(list.size()==1 and list[0].parts[0].texture==recoil_enemy.body_sprite.texture and list[0].drift.x<0,"the brief departure reuses the actual painted foe and follows the final blow")
	var echo: EnemyDissolve=list[0]
	echo.set_process(false)
	cat.active=false
	echo._process(0.2)
	check(echo.age==0,"inventory or story pause freezes the defeated silhouette")
	cat.active=true
	echo._process(0.1)
	check(is_equal_approx(echo.age,0.1) and not echo.is_queued_for_deletion(),"the departure resumes from the same age when play resumes")
	for i in range(12):
		var enemy := make_enemy("candle",actor_parent)
		enemy.take_damage(999,Vector2.UP)
	check(echoes(actor_parent).size()==EnemyDissolve.MAX_ACTIVE,"simultaneous kills cap their temporary painted silhouettes at eight")
	for existing in echoes(actor_parent): existing._process(1.0)
	check(echoes(actor_parent).is_empty(),"all temporary silhouettes release themselves after their short duration")
	actor_parent.queue_free()
	cat.queue_free()
	await process_frame
	OS.set_environment("MEOW_SKIP_STORY","0")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	for i in range(4): await process_frame
	room=current_scene
	room.request_begin()
	var director: StoryDirector=room.story_director
	director.auto_advance=false
	director.set_process(false)
	var stage=director.stage
	director.page_index=8
	director._show_page()
	stage.tick(1.0)
	stage._animate_actors()
	var entries: int=stage.scene_entries
	director.advance()
	check(stage.scene_entries==entries+1 and stage.snapshot().set_identity=="grimoire_vault" and not stage.hero.visible and stage.actor_ids==PackedStringArray(["grimoire"]),"the awakening is a genuine vault cutaway with the ancient book alone")
	check(stage.plate==stage.ARCHIVE and stage.actor_rect.get_center().x>500 and stage.actor_rect.get_center().x<650,"the book is centered in the archive painting rather than left beside an absent classmate")
	stage.tick(1.0)
	stage._animate_actors()
	entries=stage.scene_entries
	director.advance()
	check(stage.scene_entries==entries and stage.ambient_time>=1.0,"the next Grimoire line keeps the same cutaway and animation clock")
	director.page_index=12
	director._show_page()
	stage.tick(1.0)
	stage._animate_actors()
	director.advance()
	check(stage.location_index==0 and stage.hero.visible and stage.actor_ids==PackedStringArray(["professor"]),"the silent professor stays in the basement for the final innocent-cat reaction")
	director.show_chapter(3,Callable())
	director.set_process(false)
	check(stage.hen_sprite.visible and stage.hen_sprite.modulate.a==0 and stage.hen_sprite.texture==WorldDetailArt.icon("hen"),"Pip's failed summon starts with the shared painted hen still unrevealed")
	stage.tick(1.2)
	stage._animate_actors()
	var feet: Vector2=stage.hen_sprite.position+stage.hen_sprite.pivot_offset
	check(stage.hen_sprite.modulate.a==1 and feet==stage.HEN_FEET,"a single summon reveals the chicken with its feet on the floor")
	var hen_age: float=stage.ambient_time
	director.advance()
	check(stage.ambient_time==hen_age and stage.hen_sprite.modulate.a==1 and stage.hen_sprite.position+stage.hen_sprite.pivot_offset==feet,"the next line does not replay the summon or move the grounded hen")
	director.show_chapter(6,Callable())
	director.set_process(false)
	check(stage.hen_sprite.visible and stage.hen_sprite.modulate.a==1 and not stage.tea_sprite.visible,"the hen accompanies the final rest, while tea waits for Bloop's offer")
	director.page_index=2
	director._show_page()
	stage.tick(0.7)
	stage._animate_actors()
	check(stage.tea_sprite.visible and stage.tea_sprite.texture.atlas==stage.TEA_ART and stage.tea_sprite.modulate.a==1,"Bloop's warm drink has a painted teapot, separate from the explosive potion")
	var tea_age: float=stage.tea_age
	director.advance()
	check(stage.tea_sprite.visible and stage.tea_age==tea_age and stage.hen_sprite.visible,"tea and hen stay present when the friends share the same shot")
	director.show_chapter(7,Callable())
	director.set_process(false)
	check(not stage.hen_sprite.visible and not stage.tea_sprite.visible and stage.tea_age<0,"companion props do not leak into the boss arena")
	room.queue_free()
	await process_frame
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("POLISH PRESENTATION RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
