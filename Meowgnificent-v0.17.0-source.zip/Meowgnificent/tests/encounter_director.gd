extends SceneTree

const Director := preload("res://scripts/systems/encounter_director.gd")
const WORLD := Rect2(160,256,1728,856)
var checks := 0
var failures := 0
var director
var requests: Array[Dictionary]=[]
var completions := 0
var clears: Array[int]=[]

func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func step(seconds: float, point: Vector2, playing: bool=true) -> void:
	var remaining := seconds
	while remaining>0.00001:
		var delta := minf(0.05,remaining)
		director.tick(delta,point,playing)
		remaining-=delta

func run() -> void:
	var stages: Array=JSON.parse_string(FileAccess.get_file_as_string("res://data/expedition.json")).stages
	director=Director.new()
	root.add_child(director)
	director.encounter_requested.connect(func(definition: Dictionary): requests.append(definition))
	director.encounter_cleared.connect(func(index: int): clears.append(index))
	director.route_completed.connect(func(): completions+=1)
	var totals: Array[int]=[]
	var total_foes := 0
	var ward_families: Dictionary={}
	var valid_metadata := true
	for stage_index in range(stages.size()):
		director.configure(stages[stage_index],stage_index,WORLD)
		totals.append(int(director.snapshot().total))
		for definition in director.definitions:
			total_foes+=definition.roles.size()
			var wards: Array=definition.get("element_families",[])
			valid_metadata=valid_metadata and (wards.is_empty() or wards.size()==definition.roles.size()) and int(definition.get("elite",-1))<definition.roles.size()
			for family in wards:
				if not str(family).is_empty():
					valid_metadata=valid_metadata and ElementAffinity.FAMILIES.has(str(family))
					ward_families[str(family)]=true
			var valid: bool=definition.roles.size()==definition.positions.size() and definition.roles.size()<=Director.MAX_GROUP_SIZE and not definition.roles.is_empty()
			for raw in definition.positions:
				valid=valid and WORLD.has_point(director.map_point(Vector2(float(raw[0]),float(raw[1]))))
			check(valid,str(definition.name)+": a bounded thematic group fits its authored room")
	check(totals==[2,3,3,0,3,3,0,3] and total_foes==106,"eight story areas now contain seventeen finite encounters and106foes, with both peaceful shops intact")
	check(valid_metadata and ward_families.size()==8,"all eight enchantments occur in the real route with aligned roles, families and valid elite slots")
	director.configure(stages[1],1,WORLD)
	var initial: Dictionary=director.current_definition()
	check(initial.roles==stages[1].roles and initial.positions==stages[1].positions and director.state=="active","the library begins with its original six story-linked book positions")
	initial.positions[0][0]=-999
	check(director.current_definition().positions[0][0]==470,"a caller cannot mutate the authored encounter data through a returned definition")
	check(not director.finish_current() and director.state=="waiting" and director.index==1,"clearing the first group opens an exploration interval instead of the stage exit")
	check(clears==[0] and completions==0,"the first group reports one clear without awarding final-stage completion")
	var waiting_point: Vector2=director.waypoint()
	step(10.0,Vector2(1850,1050))
	check(requests.is_empty() and director.state=="waiting","waiting away from the next seal never spawns timer-based reinforcements")
	var previous_time: float=director.ambient_time
	step(5.0,waiting_point,false)
	check(director.ambient_time==previous_time and director.state=="waiting","inventory, story and settings pause exploration and its arrival clock")
	director.tick(0.05,waiting_point,true)
	check(director.state=="windup" and director.elapsed==0.0 and requests.is_empty(),"approaching the marked zone begins a visible warning before any enemy spawns")
	var preview: Dictionary=director.current_definition()
	var safe := true
	for raw in preview.positions:
		var point: Vector2=director.map_point(Vector2(float(raw[0]),float(raw[1])))
		safe=safe and point.distance_to(waiting_point)>=Director.SAFE_SPAWN_DISTANCE and WORLD.grow(-40).has_point(point)
	check(safe,"all previewed arrivals keep a safe gap around the cat and inside the enlarged arena")
	director.tick(10.0,waiting_point,true)
	check(director.state=="windup" and director.elapsed<0.11,"a severe stalled frame cannot swallow the complete arrival telegraph")
	var paused_elapsed: float=director.elapsed
	step(2.0,waiting_point,false)
	check(director.elapsed==paused_elapsed,"pausing during the visible warning preserves its remaining time")
	step(0.1,waiting_point+Vector2(300,0))
	check(director.state=="waiting" and director.elapsed==0.0 and requests.is_empty(),"walking out of the seal cancels the unspawned group safely")
	step(0.1,waiting_point)
	step(1.2,waiting_point)
	check(director.state=="active" and requests.size()==1 and requests[0].roles.size()==6,"returning and completing the full warning requests exactly one bounded new group")
	step(5.0,waiting_point)
	check(requests.size()==1,"an active group cannot be duplicated by later director ticks")
	check(not director.finish_current() and director.index==2,"the second clear still leaves one finite library encounter")
	step(2.0,director.waypoint())
	check(director.state=="active" and requests.size()==2,"the third encounter starts through the same visible exploration flow")
	check(director.finish_current() and director.is_complete() and completions==1,"only the third clear completes the library route")
	director.finish_current()
	step(5.0,director.waypoint())
	check(completions==1 and clears==[0,1,2] and requests.size()==2,"repeated clear/tick calls cannot duplicate completion, rewards or enemies")
	director.configure(stages[7],7,WORLD)
	check(not director.current_definition().boss_encounter and int(director.current_definition().elite)==-1,"the final area begins with defenders and does not spawn its boss early")
	director.finish_current()
	step(2.0,director.waypoint())
	check(not director.current_definition().boss_encounter,"the second archive encounter remains a defender group")
	director.finish_current()
	step(2.0,director.waypoint())
	var boss: Dictionary=director.current_definition()
	check(boss.boss_encounter and int(boss.elite)==3 and int(boss.hp)==60 and boss.roles.size()==4,"the last encounter brings the original180HP boss with three supporting defenders")
	director.configure(stages[3],3,WORLD)
	check(director.is_complete() and director.snapshot().total==0 and not director.visible,"a shop resets pending combat and has no artificial encounters")
	director.configure(stages[2],2,WORLD)
	director.finish_current()
	step(0.8,director.waypoint())
	var before_reset := requests.size()
	director.configure(stages[0],0,WORLD)
	step(3.0,director.waypoint())
	check(requests.size()==before_reset and director.index==0 and director.state=="active" and director.snapshot().spawn_points.is_empty(),"loading another area cancels a previous area's armed reinforcements")
	# Both a typical ring and a player entering from its dangerous near edge
	# get deterministic, well-spaced safe arrival locations.
	var all_safe := true
	for stage_index in [0,1,2,4,5,7]:
		director.configure(stages[stage_index],stage_index,WORLD)
		for encounter in range(1,director.definitions.size()):
			director.index=encounter
			for offset in [Vector2.ZERO,Vector2(145,0),Vector2(-145,0),Vector2(0,145),Vector2(0,-145)]:
				var player_point: Vector2=director.waypoint()+offset
				director._prepare_arrival(player_point)
				var points: PackedVector2Array=director.snapshot().spawn_points
				for i in range(points.size()):
					all_safe=all_safe and points[i].distance_to(player_point)>=Director.SAFE_SPAWN_DISTANCE-0.01 and WORLD.grow(-40).has_point(points[i])
					for j in range(i): all_safe=all_safe and points[i].distance_to(points[j])>=Director.MIN_SEPARATION-0.01
					for shelf in stages[stage_index].get("shelves",[]):
						all_safe=all_safe and points[i].distance_to(director.map_point(Vector2(float(shelf[0]),float(shelf[1]))))>=75.99
	check(all_safe,"every followup group remains inside the world, separated and safely away from five approach directions")
	director.configure(stages[1],1,WORLD)
	director.finish_current()
	step(0.8,director.waypoint())
	var warned_points: PackedVector2Array=director.snapshot().spawn_points
	var intruder_point: Vector2=warned_points[0].move_toward(director.waypoint(),Director.SAFE_SPAWN_DISTANCE*0.64)
	if intruder_point.distance_to(director.waypoint())<=Director.CANCEL_RADIUS:
		director.tick(0.05,intruder_point,true)
		var rearmed: Dictionary=director.snapshot()
		var relocated := true
		for point: Vector2 in rearmed.spawn_points:
			relocated=relocated and point.distance_to(intruder_point)>=Director.SAFE_SPAWN_DISTANCE-0.01
		check(rearmed.state=="windup" and rearmed.progress==0 and relocated,"entering a landing circle moves it away and restarts the full visible warning")
	else:
		check(false,"the landing-circle safety fixture must approach from inside the encounter zone")
	director.free()
	print("ENCOUNTER DIRECTOR RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
