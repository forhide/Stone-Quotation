extends SceneTree

# Actual CanvasItem draws, including charging, moving and impact variants.
# Run with GL to verify triangulation; headless also checks all code paths.
class InkProbe extends Node2D:
 const FAMILIES := ["fire","water","ice","wind","stone","leaf","lightning","metal"]
 var tick := 0
 func _draw() -> void:
  for family in range(FAMILIES.size()):
   for outcome in range(3):
    var clock := float(tick)*0.037+outcome*0.113
    var direction := Vector2.ZERO if tick%7==0 else Vector2.from_angle(clock*2.7)
    var size: float = [0.65,1.0,2.6][outcome]
    ElementalFlightInk.draw(self,FAMILIES[family],Vector2(95+family*155,150+outcome*200),direction,clock,size,["success","miscast","overreaction"][outcome])
var probe: InkProbe
func _initialize() -> void: call_deferred("run")
func run() -> void:
 probe=InkProbe.new()
 root.add_child(probe)
 var impacts: Array[BasicMagicImpact]=[]
 for i in range(8):
  var impact := BasicMagicImpact.new()
  impact.element=InkProbe.FAMILIES[i]
  impact.position=Vector2(95+i*155,720)
  impact.direction=Vector2.RIGHT.rotated(i*0.39)
  root.add_child(impact)
  impact.set_process(false)
  impacts.append(impact)
 for tick in range(180):
  probe.tick=tick
  probe.queue_redraw()
  for impact in impacts:
   impact.age=fmod(float(tick)*0.037,BasicMagicImpact.DURATION)
   impact.queue_redraw()
  await process_frame
 if DisplayServer.get_name()!="headless" and OS.has_environment("MEOW_ELEMENTAL_NATURE_CAPTURE"):
  await RenderingServer.frame_post_draw
  root.get_texture().get_image().save_png(OS.get_environment("MEOW_ELEMENTAL_NATURE_CAPTURE"))
 probe.free()
 for impact in impacts: impact.free()
 print("ELEMENTAL NATURE RENDER:8families ×3outcomes ×180frames; paw/flight/contact paths submitted")
 quit()
