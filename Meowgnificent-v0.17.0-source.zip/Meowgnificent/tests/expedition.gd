extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# Exercise the expedition through its public room actions. Combat timing and
# spell probabilities remain covered by smoke.gd / accidents.gd.
var checks := 0
var failures := 0
var room
var profile_path := ""
var previous_profile_path := ""
var had_profile_override := false

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok:
		print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(count: int = 3) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func freeze_foes() -> void:
	for enemy in room.enemies:
		enemy.active=false

func kill_remaining() -> int:
	return RouteFixture.clear_area(room)

func first_loot(kind: String) -> LootPickup:
	for pickup in room.loot:
		if is_instance_valid(pickup) and pickup.kind==kind:
			return pickup
	return null

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	had_profile_override=OS.has_environment("MEOW_PROFILE_PATH")
	previous_profile_path=OS.get_environment("MEOW_PROFILE_PATH")
	profile_path="/tmp/meow-expedition-%d-%d.json" % [OS.get_process_id(),Time.get_ticks_usec()]
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames()
	room=current_scene
	check(room.state=="intro" and room.run.stage_index==0,"new expedition opens at the tutorial")
	check(room.run.gold==0 and room.run.inventory.is_empty(),"new profile starts without run gold or equipment")
	room.begin_or_restart()
	await frames()
	freeze_foes()
	room.drop_rng.seed=73
	check(room.state=="playing" and room.profile.attempts==1,"starting a run records one persistent attempt")
	check(not room.exit_open and not room.advance_sector() and room.run.stage_index==0,"uncleared combat locks the next sector")
	var initial_count: int=room.enemies.size()
	var foe: CandleSlime=room.enemies[0]
	foe.position=Vector2(965,455)
	var death_point: Vector2=foe.position
	foe.take_damage(9999,Vector2.RIGHT)
	await frames(2)
	check(room.run.enemies_defeated==1 and room.enemies.size()==initial_count-1,"enemy death updates the run kill count once")
	var gold := first_loot("gold")
	var gear := first_loot("gear")
	check(gold!=null and gold.amount>0 and gold.position.distance_to(death_point)<90,"defeated enemy drops collectible gold at its location")
	check(gear!=null and gear.item_id=="crooked_ash_wand","first tutorial defeat guarantees a usable starter wand")
	if gold==null or gear==null:
		await finish()
		return
	var gold_before: int=room.run.gold
	var gold_amount: int=gold.amount
	room.player.position=gold.position
	var collected: bool=room.collect_pickup(gold)
	var collected_twice: bool=room.collect_pickup(gold)
	check(collected and not collected_twice and room.run.gold==gold_before+gold_amount,"a pickup can credit its gold only once")
	room.player.position=gear.position
	check(room.collect_pickup(gear) and room.run.inventory.has("crooked_ash_wand"),"gear pickup enters the satchel")
	check(str(room.run.equipment.wand)=="practice_wand" and int(room.run.stats().spell_damage_bonus)==0,"found gear does not replace the equipped zero-stat practice wand")
	await frames()
	room.player.position=Vector2(640,450)
	room.player.velocity=Vector2.ZERO
	room.open_inventory()
	await frames(2)
	check(room.panel.is_open and room.panel.mode=="inventory" and not room.player.active,"inventory opens and pauses the expedition")
	check(not room.advance_sector(),"inventory cannot advance the stage while paused")
	check(room.equip_gear("crooked_ash_wand"),"owned wand can be equipped through the room action")
	var expected_damage: int=int(room.balance.fireball.success_damage)+5
	check(int(room.spells.config.success_damage)==expected_damage,"equipped wand changes the actual spell configuration")
	room.close_panel()
	await frames(2)
	freeze_foes()
	foe=room.enemies[0]
	foe.position=Vector2(810,450)
	var before_hit: int=foe.health.current
	room.spells.cooldown=0
	room.spells.resolver.forced="success"
	room.spells.cast(Vector2.RIGHT)
	await frames(28)
	check(is_instance_valid(foe) and foe.health.current==before_hit-ElementAffinity.damage(expected_damage,float(ElementAffinity.response(foe.affinity_profile(),str(BasicMagic.for_run(room.run).id)).multiplier)),"a real equipped-element projectile applies wand damage and the target material reaction")
	for shot in room.projectiles.get_children(): shot.queue_free()
	room.player.health.damage(30)
	var wounded_hp: int=room.player.health.current
	var baseline_max: int=room.player.health.maximum
	room.run.add_item("brass_bell_collar")
	room.run.add_item("loose_feather")
	room.open_inventory()
	room.equip_gear("brass_bell_collar")
	check(room.player.health.maximum==baseline_max+20 and room.player.health.current==wounded_hp,"max-HP gear expands capacity without free healing")
	for i in range(3):
		room.unequip_gear("collar")
		room.equip_gear("brass_bell_collar")
	check(room.player.health.current==wounded_hp,"repeated collar swaps cannot heal the player")
	room.unequip_gear("collar")
	room.equip_gear("loose_feather")
	check(is_equal_approx(float(room.player.config.speed),float(room.balance.player.speed)+10),"charm movement bonus reaches the player controller")
	room.close_panel()
	await frames(2)
	freeze_foes()
	room.player.roll_time=0
	room.player.roll_cooldown=0
	room.player.start_roll(Vector2.LEFT)
	check(is_equal_approx(room.player.roll_cooldown,1.25*0.9),"charm changes the actual roll recovery time")
	room.player.roll_time=0
	room.player.velocity=Vector2.ZERO
	foe=room.enemies[0]
	foe.position=Vector2(965,500)
	foe.take_damage(9999,Vector2.RIGHT)
	await frames(2)
	var paused_pickup := first_loot("gold")
	check(paused_pickup!=null,"later defeats continue dropping loot")
	if paused_pickup==null:
		await finish()
		return
	room.open_inventory()
	var pickup_age: float=paused_pickup.age
	var pickup_position: Vector2=paused_pickup.position
	room.spells.cooldown=0.47
	await frames(12)
	check(is_equal_approx(paused_pickup.age,pickup_age) and paused_pickup.position==pickup_position,"inventory pauses loot animation and attraction")
	check(is_equal_approx(room.spells.cooldown,0.47),"inventory also preserves spell cooldown")
	for shot in room.projectiles.get_children(): shot.queue_free()
	await frames(2)
	Input.action_press("cast")
	room.close_panel()
	freeze_foes()
	room.spells.cooldown=0
	await frames(12)
	check(not room.spells.pending and room.projectiles.get_child_count()==0,"closing a panel while holding cast does not fire a new spell")
	Input.action_release("cast")
	await frames(2)
	room.spells.resolver.forced="success"
	Input.action_press("cast")
	await frames(4)
	check(room.spells.pending or room.projectiles.get_child_count()>0,"casting resumes after the held input is released")
	Input.action_release("cast")
	room.spells.pending=false
	room.player.cast_prepare=0
	for shot in room.projectiles.get_children(): shot.queue_free()
	var expected_kills := 2
	var shops_seen := 0
	var sectors_seen: Array[int]=[]
	while int(room.run.stage_index)<7:
		var sector: int=room.run.stage_index
		sectors_seen.append(sector)
		var kind: String=str(room.stage_def.kind)
		if kind=="shop":
			shops_seen+=1
			await check_shop(shops_seen)
		else:
			freeze_foes()
			room.player.invulnerability=1000
			expected_kills+=kill_remaining()
			await frames()
			check(room.state=="playing" and room.exit_open and room.player.active,"sector %d clear opens the route and leaves loot explorable" % (sector+1))
			check(not room.hud.overlay.visible,"sector %d does not show the final victory screen" % (sector+1))
			check(room.loot.size()<32,"sector %d keeps ground loot bounded" % (sector+1))
			var bank: int=room.profile.starlight
			check(room.profile.award_sector(sector,5)==0 and room.profile.starlight==bank,"sector %d cannot award permanent currency twice" % (sector+1))
		var carried_gold: int=room.run.gold
		var carried_wand: String=str(room.run.equipment.wand)
		var accepted: bool=room.advance_sector()
		if not accepted and not room.departure_gear_signature.is_empty(): accepted=room.advance_sector()
		await frames(4)
		check(accepted and room.run.stage_index==sector+1,"route advances from sector %d to %d" % [sector+1,sector+2])
		if not accepted or int(room.run.stage_index)!=sector+1:
			await finish()
			return
		check(room.run.gold>=carried_gold and str(room.run.equipment.wand)==carried_wand,"gold and equipped wand carry into sector %d" % (sector+2))
		check(room.loot.is_empty(),"sector %d frees the previous room's ground loot" % (sector+2))
		freeze_foes()
	check(shops_seen==2 and sectors_seen.size()==7,"route contains two shops before the eighth sector")
	check(str(room.stage_def.kind)=="final" and not room.exit_open and room.state=="playing","final examination starts as a locked combat encounter")
	check(room.enemies.size()<=8 and room.enemies.size()>0,"final encounter has a bounded group of enemies")
	var has_elite := false
	for enemy in room.enemies:
		if enemy.health.maximum>=120: has_elite=true
	check(not has_elite,"the final area opens with defenders before its stronger examiner")
	var before_guards: int=room.run.enemies_defeated
	check(RouteFixture.reach_boss(room),"clearing both defender encounters reaches the Grimoire through the real seals")
	expected_kills+=room.run.enemies_defeated-before_guards
	has_elite=false
	for enemy in room.enemies:
		if enemy is PerfectExaminer and enemy.health.maximum>=180: has_elite=true
	check(has_elite and room.encounters.index==2,"only the third final-area encounter contains the stronger examiner")
	room.player.invulnerability=1000
	while room.enemies.size()>1:
		room.enemies[0].take_damage(9999,Vector2.RIGHT)
		expected_kills+=1
	check(room.state=="playing" and room.profile.wins==0,"victory waits for the last final-sector defender")
	var before_final_reward: int=room.profile.starlight
	room.enemies[0].take_damage(9999,Vector2.RIGHT)
	expected_kills+=1
	await frames()
	check(room.state=="cleared" and room.hud.overlay.visible and not room.player.active,"only the completed eighth sector displays final victory")
	check(room.profile.wins==1 and room.profile.best_sector==8 and room.profile.starlight>=before_final_reward+5,"final victory persists the clear and permanent reward")
	check(room.run.enemies_defeated==expected_kills,"run summary counts defeated enemies across every combat sector")
	room.begin_or_restart()
	await frames(4)
	room=current_scene
	check(room.state=="intro" and room.run.gold==0 and room.run.inventory.is_empty(),"new expedition resets transient gold and gear")
	check(room.profile.wins==1 and room.profile.best_sector==8,"profile clear and furthest progress survive scene reload")
	room.open_legacy()
	await frames(2)
	check(room.panel.is_open and room.panel.mode=="meta","legacy studies open from the start screen")
	var vitality_purchase: Dictionary=room.purchase_upgrade("vitality")
	var starter_purchase: Dictionary=room.purchase_upgrade("starter_wand")
	check(bool(vitality_purchase.get("ok",false)) and bool(starter_purchase.get("ok",false)),"earned starlight buys permanent vitality and a starting wand")
	var retained_starlight: int=room.profile.starlight
	room.close_panel()
	room.begin_or_restart()
	await frames()
	freeze_foes()
	check(room.player.health.maximum==105 and room.player.health.current==105,"next expedition applies purchased permanent vitality")
	check(room.run.inventory.has("crooked_ash_wand") and str(room.run.equipment.wand)=="crooked_ash_wand","unlocked starting wand is inherited and equipped next run")
	check(room.run.gold==0 and room.profile.attempts==2,"retry starts fresh run gold and records the next attempt")
	room.run.add_gold(77)
	room.run.add_item("moonlit_yarn")
	room.player.invulnerability=0
	room.player.take_damage(9999,Vector2.ZERO)
	await frames()
	check(room.state=="defeated" and room.profile.wins==1,"death ends the expedition without adding a win")
	room.begin_or_restart()
	await frames(4)
	room=current_scene
	check(room.profile.starlight==retained_starlight and int(room.profile.upgrades.get("vitality",0))==1,"permanent currency and upgrades survive defeat")
	check(room.run.gold==0 and not room.run.inventory.has("moonlit_yarn"),"defeat discards the previous run's gold and temporary finds")
	room.begin_or_restart()
	await frames()
	check(room.player.health.maximum==105 and room.run.inventory.has("crooked_ash_wand"),"another attempt still inherits permanent upgrades and unlocks")
	await finish()

func check_shop(visit: int) -> void:
	check(room.enemies.is_empty() and room.exit_open and room.state=="playing","shop %d is a safe sector with an open onward route" % visit)
	var outside_purchase: Dictionary=room.purchase_offer(0)
	check(not bool(outside_purchase.get("ok",false)),"shop %d requires interacting with its merchant before buying" % visit)
	room.player.position=WorldLayout.point(ShopGathering.PIP_POSITION)
	room.interact()
	await frames(2)
	check(room.panel.is_open and room.panel.mode=="shop" and not room.player.active,"merchant interaction opens shop %d and pauses movement" % visit)
	check(room.shop_offers.size()==4,"shop %d carries three gear slots and one provision" % visit)
	check(not room.advance_sector(),"shop %d cannot transition while its panel is open" % visit)
	if room.shop_offers.size()<4: return
	var offer: Dictionary=room.shop_offers[0]
	var id: String=str(offer.id)
	var price: int=int(offer.price)
	if visit==1:
		check(room.run.gold>=price,"collected enemy drops can afford a first-shop equipment purchase")
	if room.run.gold<price: room.run.add_gold(price-room.run.gold)
	var old_wand: String=str(room.run.equipment.wand)
	var gold_before: int=room.run.gold
	var result: Dictionary=room.purchase_offer(0)
	if room.run.inventory.size()>=ExpeditionRun.INVENTORY_LIMIT and not bool(result.get("ok",false)):
		check(room.run.gold==gold_before and not bool(offer.sold),"shop %d rejects a full satchel without charging or selling stock" % visit)
		# The longer expedition naturally fills the bag before the second shop.
		# Make room through the public discard action, preserving worn items.
		for owned in room.run.inventory.duplicate():
			if room.run.discard_item(owned): break
		result=room.purchase_offer(0)
	check(bool(result.get("ok",false)) and room.run.gold==gold_before-price and room.run.inventory.has(id),"shop %d exchanges the exact gear price for an owned item" % visit)
	check(bool(offer.sold) and str(room.run.equipment.wand)==old_wand,"shop %d marks stock sold without silently equipping the purchase" % visit)
	gold_before=room.run.gold
	result=room.purchase_offer(0)
	check(not bool(result.get("ok",false)) and room.run.gold==gold_before,"shop %d cannot charge for sold stock twice" % visit)
	room.player.health.current=room.player.health.maximum
	room.player.health.changed.emit(room.player.health.current,room.player.health.maximum)
	var heal_offer: Dictionary=room.shop_offers[3]
	gold_before=room.run.gold
	result=room.purchase_offer(3)
	check(not bool(result.get("ok",false)) and room.run.gold==gold_before and not bool(heal_offer.sold),"shop %d rejects full-health food without charging or selling it" % visit)
	room.player.health.damage(40)
	var health_before: int=room.player.health.current
	if room.run.gold<12: room.run.add_gold(12-room.run.gold)
	gold_before=room.run.gold
	result=room.purchase_offer(3)
	check(bool(result.get("ok",false)) and room.player.health.current==health_before+35 and room.run.gold==gold_before-12,"shop %d provision restores actual vitality for its exact price" % visit)
	room.close_panel()
	room.player.position=WorldLayout.point(ShopGathering.PIP_POSITION)
	room.interact()
	await frames(2)
	check(bool(room.shop_offers[0].sold) and bool(room.shop_offers[3].sold),"reopening shop %d preserves its sold stock" % visit)
	room.close_panel()
	room.open_inventory()
	check(room.equip_gear(id) and str(room.run.equipment.wand)==id,"shop %d equipment can be deliberately equipped for the next fights" % visit)
	room.close_panel()
	await frames(2)

func finish() -> void:
	for action in ["cast","move_left","move_right","move_up","move_down"]:
		Input.action_release(action)
	if is_instance_valid(current_scene): current_scene.queue_free()
	await frames(2)
	for suffix: String in ["",".tmp",".bak"]:
		var path: String=profile_path+suffix
		if FileAccess.file_exists(path): DirAccess.remove_absolute(path)
	if had_profile_override:
		OS.set_environment("MEOW_PROFILE_PATH",previous_profile_path)
	else:
		OS.unset_environment("MEOW_PROFILE_PATH")
	print("EXPEDITION RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
