class_name ElementAffinity
extends RefCounted

# Materials react consistently across primary spells and item skills. A ward
# changes the material profile, while an unenchanted foe follows its body.
const WEAK_MULTIPLIER := 1.5
const RESIST_MULTIPLIER := 0.65
const WET_DURATION := 3.0
const ELEMENT_NAMES := {"fire":"Fire","water":"Water","ice":"Ice","wind":"Wind","stone":"Stone","leaf":"Wood","lightning":"Lightning","metal":"Metal"}
const ROLES := {
 "candle":{"name":"Wax familiar","weak":["water","ice"],"resist":["fire"]},
 "broom":{"name":"Enchanted broom","weak":["fire","metal"],"resist":["wind"]},
 "book":{"name":"Living spellbook","weak":["fire","wind"],"resist":["stone"]},
 "mushroom":{"name":"Awakened mushroom","weak":["fire","metal"],"resist":["leaf"]},
 "bat":{"name":"Flying familiar","weak":["lightning","stone"],"resist":["wind"]},
 "examiner":{"name":"The Perfect Grimoire","weak":["leaf"],"resist":["lightning"]}
}
const FAMILIES := {
 "fire":{"name":"Fire enchantment","weak":["water","ice"],"resist":["fire","leaf"]},
 "water":{"name":"Water enchantment","weak":["lightning","ice"],"resist":["fire","water"]},
 "ice":{"name":"Ice enchantment","weak":["fire","stone"],"resist":["ice","water"]},
 "wind":{"name":"Wind enchantment","weak":["stone","metal"],"resist":["wind","leaf"]},
 "stone":{"name":"Stone enchantment","weak":["water","leaf"],"resist":["metal","lightning"]},
 "leaf":{"name":"Wood enchantment","weak":["fire","metal"],"resist":["leaf","water"]},
 "lightning":{"name":"Lightning enchantment","weak":["stone","leaf"],"resist":["lightning","metal"]},
 "metal":{"name":"Metal enchantment","weak":["lightning","water"],"resist":["metal","ice"]}
}

static func profile(role: String, family: String="") -> Dictionary:
 var source: Dictionary=FAMILIES.get(family,ROLES.get(role,{"name":"Familiar","weak":[],"resist":[]}))
 var result := source.duplicate(true)
 result["family"]=family if FAMILIES.has(family) else ""
 return result

static func element_name(element: String) -> String:
 return str(ELEMENT_NAMES.get(element,"Magic"))

static func response(profile_data: Dictionary, element: String, wet: bool=false) -> Dictionary:
 var multiplier := 1.0
 var reaction := "neutral"
 if element in profile_data.get("weak",[]):
  multiplier=WEAK_MULTIPLIER
  reaction="weak"
 elif element in profile_data.get("resist",[]):
  multiplier=RESIST_MULTIPLIER
  reaction="resist"
 # Water conducts one subsequent lightning hit. It overrides resistance but
 # never multiplies an existing weakness into an unbounded damage combo.
 if wet and element=="lightning":
  multiplier=WEAK_MULTIPLIER
  reaction="conductive"
 return {"multiplier":multiplier,"reaction":reaction}

static func damage(amount: int, multiplier: float) -> int:
 return maxi(1,roundi(float(amount)*multiplier)) if amount>0 else 0

static func draw_icon(canvas: CanvasItem, element: String, at: Vector2, size: float=7.0, alpha: float=1.0) -> void:
 var ink := BasicMagic.color(element)
 ink.a=alpha
 var bright := Color(1.0,0.98,0.90,alpha)
 canvas.draw_circle(at,size+2,Color(0.31,0.27,0.36,alpha*0.76),true,-1,true)
 match element:
  "fire":
   canvas.draw_colored_polygon(PackedVector2Array([at+Vector2(0,-size),at+Vector2(size*0.8,size*0.25),at+Vector2(size*0.4,size*0.8),at+Vector2(-size*0.55,size*0.7),at+Vector2(-size*0.75,0)]),ink)
   canvas.draw_circle(at+Vector2(0,size*0.25),size*0.3,bright,true,-1,true)
  "water":
   canvas.draw_circle(at+Vector2(0,size*0.25),size*0.63,ink,true,-1,true)
   canvas.draw_colored_polygon(PackedVector2Array([at+Vector2(0,-size),at+Vector2(size*0.6,size*0.1),at+Vector2(-size*0.6,size*0.1)]),ink)
  "ice":
   for i in range(3):
    var ray := Vector2.from_angle(i*PI/3)*size
    canvas.draw_line(at-ray,at+ray,ink,1.8,true)
  "wind":
   canvas.draw_arc(at,size*0.65,-0.6,4.5,12,ink,1.7,true)
   canvas.draw_line(at+Vector2(-size*0.8,size*0.8),at+Vector2(size*0.6,size*0.8),ink,1.5,true)
  "stone":
   canvas.draw_colored_polygon(PackedVector2Array([at+Vector2(-size,-size*0.1),at+Vector2(-size*0.4,-size*0.7),at+Vector2(size*0.6,-size*0.6),at+Vector2(size,size*0.4),at+Vector2(0,size*0.8),at+Vector2(-size*0.8,size*0.5)]),ink)
  "leaf":
   canvas.draw_polyline(PackedVector2Array([at+Vector2(-size*0.6,size),at+Vector2(0,size*0.2),at+Vector2(-size*0.1,-size*0.5),at+Vector2(size*0.6,-size*0.9)]),ink,2.2,true)
   canvas.draw_line(at+Vector2(0,size*0.1),at+Vector2(size*0.65,-size*0.1),ink,1.6,true)
  "lightning":
   canvas.draw_polyline(PackedVector2Array([at+Vector2(size*0.3,-size),at+Vector2(-size*0.5,0),at+Vector2(size*0.3,-size*0.1),at+Vector2(-size*0.3,size)]),ink,2.2,true)
  "metal":
   canvas.draw_colored_polygon(PackedVector2Array([at+Vector2(size*0.6,-size),at+Vector2(size*0.35,size*0.4),at+Vector2(-size*0.6,size),at+Vector2(-size*0.35,-size*0.4)]),ink)
   canvas.draw_line(at+Vector2(-size*0.4,size*0.75),at+Vector2(size*0.5,-size*0.8),bright,1.0,true)
