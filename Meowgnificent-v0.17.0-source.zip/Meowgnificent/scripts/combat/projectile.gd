class_name SpellProjectile
extends Node2D

signal impacted(point: Vector2, damage: int, radius: float, direction: Vector2)
var direction := Vector2.RIGHT
var speed := 540.0
var lifetime := 2.3
var damage := 20
var radius := 9.0
var explosion_radius := 0.0
var outcome := "success"
var element := "fire"
var room: Node2D
var bounds: Rect2
var age := 0.0
var previous_age := 0.0
var spent := false
var hit_ids: Array[int] = []
var maximum_hits := 1
var push_multiplier := 1.0
const GROWTH_POINTS := 15
const GROWTH_SPACING := 6.0
var growth_path := PackedVector2Array()
var _growth_display := PackedVector2Array()

func configure_magic(id: String) -> void:
 element=str(BasicMagic.definition(id).id)
 var magic := BasicMagic.definition(element)
 speed*=float(magic.speed)
 radius*=float(magic.size)
 push_multiplier=float(magic.push)
 maximum_hits=2 if element=="wind" else 1

func _ready() -> void:
 texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
 if element=="leaf": growth_path.append(position)
 reset_physics_interpolation()

func _physics_process(delta: float) -> void:
 if spent: return
 previous_age=age
 age+=delta
 if element=="leaf": _steer_growth(delta)
 # Substeps prevent tunnelling through an enemy at low frame rates.
 var distance := speed*delta
 var steps := maxi(1,ceili(distance/8.0))
 # Defeat callbacks remove entries synchronously. One guarded snapshot for the
 # complete sweep is sufficient; defeated/freed handles are skipped below.
 # Copying this array for every8px substep caused avoidable cast-time churn.
 var collision_enemies: Array=room.enemies.duplicate()
 for i in range(steps):
  position+=direction*distance/steps
  if element=="leaf": _record_growth_point(position)
  if not bounds.has_point(position):
   impact()
   return
  for shelf in room.props:
   if is_instance_valid(shelf) and shelf.state!="fallen" and shelf.state!="falling" and position.distance_squared_to(shelf.position)<(radius+32)*(radius+32):
    if shelf.has_method("receive_magic"): shelf.receive_magic(element,direction,outcome)
    elif element=="fire": shelf.ignite(direction)
    else: shelf.topple(direction)
    impact()
    return
  if room.get("obstacles")!=null:
   var obstacle: Dictionary=room.obstacles.containing(position,radius)
   if not obstacle.is_empty():
    if obstacle.has("shelf"):
     var shelf: Object=obstacle.shelf.get_ref()
     if is_instance_valid(shelf): shelf.receive_magic(element,direction,outcome)
    impact()
    return
  for enemy in collision_enemies:
   if not is_instance_valid(enemy) or enemy.health.current<=0 or hit_ids.has(enemy.get_instance_id()): continue
   var hit_radius := radius+float(enemy.config.radius)
   if position.distance_squared_to(enemy.position)>hit_radius*hit_radius: continue
   if explosion_radius==0.0:
    _hit_enemy(enemy)
    hit_ids.append(enemy.get_instance_id())
    if hit_ids.size()<maximum_hits:
     _impact_art()
     continue
   impact()
   return
 if age>=lifetime: impact()
 queue_redraw()

func _process(_delta: float) -> void:
 # Transform interpolation moves the projectile between physics ticks; redraw
 # also keeps flames, growing tendrils and discharges on that visual clock.
 if not spent: queue_redraw()

func presentation_age() -> float:
 if can_process() and is_physics_interpolated_and_enabled():
  return lerpf(previous_age,age,Engine.get_physics_interpolation_fraction())
 return age

func _record_growth_point(point: Vector2) -> void:
 if growth_path.is_empty(): growth_path.append(point)
 # Sampling distance, rather than frame count, keeps the stem's length stable
 # through both small and coarse physics steps. The collision sweep is intact.
 while growth_path[growth_path.size()-1].distance_squared_to(point)>=GROWTH_SPACING*GROWTH_SPACING:
  growth_path.append(growth_path[growth_path.size()-1].move_toward(point,GROWTH_SPACING))
  if growth_path.size()>GROWTH_POINTS: growth_path.remove_at(0)

func _steer_growth(delta: float) -> void:
 var nearest: Node2D
 var nearest_distance_squared := 170.0*170.0
 for enemy in room.enemies:
  if not is_instance_valid(enemy) or enemy.health.current<=0: continue
  var offset: Vector2=enemy.position-position
  var distance_squared := offset.length_squared()
  if distance_squared<nearest_distance_squared and offset.normalized().dot(direction)>0.15:
   nearest=enemy
   nearest_distance_squared=distance_squared
 if nearest!=null:
  var turn := direction.angle_to((nearest.position-position).normalized())
  direction=direction.rotated(clampf(turn,-delta*1.6,delta*1.6)).normalized()

func _hit_enemy(enemy: Node2D) -> void:
 var before: int=enemy.health.current
 if enemy.has_method("take_elemental_damage"): enemy.call("take_elemental_damage",damage,direction,outcome,element)
 elif enemy.has_method("take_spell_damage"): enemy.call("take_spell_damage",damage,direction,outcome)
 else: enemy.take_damage(damage,direction)
 if not is_instance_valid(enemy) or enemy.health.current>=before: return
 # A shielded boss never receives a free slow/push through its counterspell.
 enemy.knockback*=push_multiplier
 if element=="ice" and is_instance_valid(room.skills): room.skills.apply_status(enemy,0.85,0.56,false)
 if element=="water":
  for neighbor in room.enemies.duplicate():
   if not is_instance_valid(neighbor) or neighbor==enemy or neighbor.health.current<=0: continue
   if position.distance_to(neighbor.position)>48+float(neighbor.config.radius): continue
   var splash_direction: Vector2=(neighbor.position-position).normalized()
   if neighbor.has_method("take_elemental_damage"): neighbor.call("take_elemental_damage",maxi(1,roundi(damage*0.35)),splash_direction,outcome,element)
   elif neighbor.has_method("take_spell_damage"): neighbor.call("take_spell_damage",maxi(1,roundi(damage*0.35)),splash_direction,outcome)
   else: neighbor.take_damage(maxi(1,roundi(damage*0.35)),splash_direction)

func _impact_art() -> void:
 if element=="fire" or not is_instance_valid(room): return
 var art := BasicMagicImpact.new()
 art.element=element
 art.direction=direction
 art.position=position
 art.size=clampf(radius/9.0,0.7,2.6)
 room.projectiles.add_child(art)

func impact() -> void:
 if spent: return
 spent=true
 _impact_art()
 impacted.emit(position,damage,explosion_radius,direction)
 queue_free()

func _draw() -> void:
 # The leading contact point and trajectory stay unchanged. Fluids hold their
 # volume; growing stems and branching discharges extend behind that point.
 var visual_scale := radius/9.0
 if element=="leaf" and growth_path.size()>1:
  _growth_display.resize(growth_path.size()+1)
  for i in range(growth_path.size()):
   _growth_display[i]=(growth_path[i]-position)/visual_scale
  _growth_display[growth_path.size()]=Vector2.ZERO
 ElementalFlightInk.draw(self,element,Vector2(0,-20),direction,presentation_age(),visual_scale,outcome,_growth_display)
