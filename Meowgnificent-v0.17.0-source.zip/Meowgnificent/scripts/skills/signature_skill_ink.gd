class_name SignatureSkillInk
extends RefCounted

# Large, readable material silhouettes with bounded reusable paths. No particle
# emitters, screen flashes, dynamic textures or per-frame scene allocations.
const KINDS := ["fire_meteor","chain_lightning","tidal_surge","frost_nova","cyclone","stone_quake","verdant_grove","metal_bloom"]
const COLORS := {"fire_meteor":Color("efad78"),"chain_lightning":Color("ead785"),"tidal_surge":Color("85c9dc"),"frost_nova":Color("a4d8e8"),"cyclone":Color("add7c4"),"stone_quake":Color("c4ae91"),"verdant_grove":Color("9ac187"),"metal_bloom":Color("b5bddb")}
const CREAM := Color("fff6dd")
static var _path := PackedVector2Array()
static var _branch := PackedVector2Array()
static var _polygon := PackedVector2Array()

static func draw(c: Node2D, kind: String, age: float, duration: float, delay: float, radius: float, direction: Vector2, outcome: String) -> void:
 var ink: Color=COLORS[kind]
 var ready := clampf(age/maxf(delay,0.01),0,1)
 if age<delay:
  EnchantedArt.stamp(c,"seal",Vector2.ZERO,Vector2(radius*1.9,radius*1.05),0.40+ready*0.46)
  c.draw_set_transform(Vector2.ZERO,0,Vector2(1,0.55))
  c.draw_arc(Vector2.ZERO,radius*0.78,-PI/2,-PI/2+ready*TAU,40,Color(CREAM,0.8),2.2,true)
  c.draw_set_transform(Vector2.ZERO)
  if kind=="fire_meteor":
   var landing := Vector2(70,-240)*(1-ready)
   EnchantedArt.stamp(c,kind,landing+Vector2(30,-52),Vector2(160,160),0.95)
  return
 var post := maxf(0,age-delay)
 var t := clampf(post/maxf(duration,0.01),0,1)
 var fade := 1.0-smoothstep(0.56,1.0,t)
 var grow := 0.72+0.28*smoothstep(0,0.16,post)
 # Three painted layers at most: grounded contact, dimensional material, motes.
 # The independently simulated skill still owns its exact hit timing/radius.
 c.draw_set_transform(Vector2.ZERO,0,Vector2(1,0.52))
 c.draw_circle(Vector2.ZERO,radius*0.8,Color(ink,0.065*fade),true,-1,true)
 c.draw_set_transform(Vector2.ZERO)
 match kind:
  "fire_meteor":
   EnchantedArt.stamp(c,"ember",Vector2(0,-30-post*15),Vector2.ONE*radius*1.75*grow,fade)
   EnchantedArt.stamp(c,"soot",Vector2(0,-15-post*25),Vector2(radius*2.2,radius*1.25)*(0.6+t*0.65),fade*0.56)
   c.draw_set_transform(Vector2.ZERO,0,Vector2(1,0.5))
   c.draw_arc(Vector2.ZERO,radius*(0.35+t*0.95),0,TAU,36,Color("efbf88",fade*0.8),2.3,true)
  "chain_lightning":
   EnchantedArt.stamp(c,kind,Vector2(0,-40),Vector2(85,105)*grow,fade*0.66)
  "tidal_surge":
   EnchantedArt.stamp(c,kind,Vector2(0,-radius*0.40),Vector2(radius*2.05,radius*1.52)*Vector2(1+sin(age*7)*0.025,1+cos(age*6)*0.035),fade,clampf(direction.y,-1,1)*0.12)
  "frost_nova":
   EnchantedArt.stamp(c,kind,Vector2(0,-radius*0.28),Vector2(radius*1.95,radius*1.65)*grow,fade)
   c.draw_arc(Vector2.ZERO,radius*smoothstep(0,0.20,post),0,TAU,40,Color(CREAM,fade*0.60),2,true)
  "cyclone":
   EnchantedArt.stamp(c,kind,Vector2(sin(age*8)*5,-radius*0.58),Vector2(radius*1.48,radius*1.96)*grow,fade,sin(age*7)*0.035)
  "stone_quake":
   EnchantedArt.stamp(c,kind,Vector2(0,-radius*0.28),Vector2(radius*1.95,radius*1.65)*Vector2(1,grow),fade)
   c.draw_set_transform(Vector2.ZERO,0,Vector2(1,0.48))
   for i in range(3):
    var pulse := clampf((post-i*0.28)/0.5,0,1)
    if post>=i*0.28: c.draw_arc(Vector2.ZERO,radius*(0.45+i*0.25)*pulse,0,TAU,32,Color(ink,(1-pulse)*0.65),2.0,true)
  "verdant_grove":
   EnchantedArt.stamp(c,kind,Vector2(0,-radius*0.30),Vector2(radius*2.0,radius*1.60)*grow,fade,sin(age*2)*0.012)
  "metal_bloom":
   var bloom := grow+sin(post*12)*0.03*(1-t)
   EnchantedArt.stamp(c,kind,Vector2(0,-radius*0.3),Vector2(radius*1.95,radius*1.7)*bloom,fade)
 c.draw_set_transform(Vector2.ZERO)
 for i in range(4):
  var a := i*TAU/4+0.3
  var at := Vector2.from_angle(a)*Vector2(radius*0.74,radius*0.38)+Vector2(0,-25-post*9)
  _spark(c,at,(3.5+sin(age*5+i)*1.5)*fade,Color(CREAM,fade*0.8))

static func draw_chain(c: Node2D, points: PackedVector2Array, age: float, duration: float, outcome: String) -> void:
 if points.size()<2: return
 var fade := 1.0-smoothstep(maxf(0.0,duration-0.3),duration,age)
 var ink := Color("e8d081") if outcome!="miscast" else Color("c9b6dc")
 for segment in range(1,points.size()):
  var start := points[segment-1]+Vector2(0,-20)
  var finish := points[segment]+Vector2(0,-20)
  var side := (finish-start).normalized().orthogonal()
  _path.resize(12)
  for i in range(12):
   var t := float(i)/11
   _path[i]=start.lerp(finish,t)+side*sin(t*PI)*(sin(i*7.1+age*43)*9+sin(i*3.3-age*27)*4)
  c.draw_polyline(_path,Color(ink,fade*0.2),13,true)
  c.draw_polyline(_path,Color(ink,fade*0.95),5.1,true)
  c.draw_polyline(_path,Color(CREAM,fade),2.1,true)
  EnchantedArt.stamp(c,"chain_lightning",finish+Vector2(0,-28),Vector2(74,105),fade*0.7)
  _spark(c,finish,9,Color(CREAM,fade))
 c.draw_set_transform(Vector2.ZERO)

static func _spark(c: Node2D, at: Vector2, size: float, color: Color) -> void:
 c.draw_line(at-Vector2(size,0),at+Vector2(size,0),color,2.1,true)
 c.draw_line(at-Vector2(0,size),at+Vector2(0,size),color,2.1,true)

static func _crystal(c: Node2D, at: Vector2, size: float, angle: float, color: Color) -> void:
 if size<0.01: return
 c.draw_set_transform(at,angle,Vector2.ONE)
 _polygon=PackedVector2Array([Vector2(0,-size),Vector2(size*0.27,-size*0.23),Vector2(size*0.17,size*0.24),Vector2(-size*0.18,size*0.24),Vector2(-size*0.28,-size*0.2)])
 c.draw_colored_polygon(_polygon,color)
 c.draw_line(Vector2(0,-size),Vector2(0,size*0.22),Color(CREAM,color.a),1.6,true)
 c.draw_set_transform(Vector2.ZERO)

static func _rock(c: Node2D, at: Vector2, size: float, color: Color) -> void:
 _polygon=PackedVector2Array([Vector2(-1,-0.2),Vector2(-0.5,-0.8),Vector2(0.35,-0.9),Vector2(1,-0.2),Vector2(0.75,0.55),Vector2(-0.65,0.65)])
 for i in range(_polygon.size()): _polygon[i]=at+_polygon[i]*size
 c.draw_colored_polygon(_polygon,color)
 c.draw_line(at+Vector2(-size*0.3,-size*0.5),at+Vector2(size*0.35,-size*0.55),Color(CREAM,color.a*0.8),2.0,true)
