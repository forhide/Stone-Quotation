class_name EnchantedArt
extends RefCounted

const LANDMARKS: Texture2D=preload("res://art/environments/enchanted_landmarks.png")
const PROPS: Texture2D=preload("res://art/environments/painted_archive_props.png")
const PROP_REGIONS := {"shelf":Rect2(198,4,414,535),"fallen_shelf":Rect2(776,21,690,507),"hatch":Rect2(98,581,598,418),"chest":Rect2(892,578,462,425)}
const COMPANIONS: Texture2D=preload("res://art/fx/painted_companion_magic.png")
const EXTRA_REGIONS := {"bubble_painted":Rect2(126,9,508,485),"potion_splash":Rect2(779,1,720,491),"potion_bottle":Rect2(203,527,371,480),"feather":Rect2(783,508,683,503)}
const SPELLS: Texture2D=preload("res://art/fx/painted_signatures.png")
const REGIONS := {"ember":Rect2(12,151,267,276),"portal":Rect2(82,6,646,544),"seal":Rect2(782,72,698,434),"plaque":Rect2(62,608,688,361),"soot":Rect2(832,554,604,452)}
const SKILLS := ["fire_meteor","chain_lightning","tidal_surge","frost_nova","cyclone","stone_quake","verdant_grove","metal_bloom"]
static var _cache: Dictionary={}

static func part(id: String) -> Texture2D:
	if _cache.has(id): return _cache[id]
	var atlas := AtlasTexture.new()
	if EXTRA_REGIONS.has(id):
		atlas.atlas=COMPANIONS
		atlas.region=EXTRA_REGIONS[id]
	elif PROP_REGIONS.has(id):
		atlas.atlas=PROPS
		atlas.region=PROP_REGIONS[id]
	elif REGIONS.has(id):
		atlas.atlas=SPELLS if id=="ember" else LANDMARKS
		atlas.region=REGIONS[id]
	else:
		var index := SKILLS.find(id)
		if index<0: return null
		atlas.atlas=SPELLS
		var x0 := roundi(float(index%4)*1774.0/4.0)
		var y0 := roundi(float(index/4)*887.0/2.0)
		var x1 := roundi(float(index%4+1)*1774.0/4.0)
		var y1 := roundi(float(index/4+1)*887.0/2.0)
		atlas.region=Rect2(x0+3,y0+3,x1-x0-6,y1-y0-6)
	atlas.filter_clip=true
	_cache[id]=atlas
	return atlas

static func stamp(canvas: CanvasItem, id: String, at: Vector2, size: Vector2, alpha: float=1.0, angle: float=0.0) -> void:
	canvas.draw_set_transform(at,angle)
	canvas.draw_texture_rect(part(id),Rect2(-size*0.5,size),false,Color(1,1,1,clampf(alpha,0,1)))
	canvas.draw_set_transform(Vector2.ZERO)
