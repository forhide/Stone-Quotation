class_name StoryShot
extends RefCounted

# The examination's small visual story has a real, continuous route. It is
# sampled from cutscene time only; it never creates a gameplay projectile.
const PAW := Vector2(494,226)
const TURN := Vector2(744,201)
const BEHIND_CAT := Vector2(84,258)
const TARGET := Rect2(842,91,165,247)

static func base_visual(visual: String) -> String:
	return visual.trim_prefix("exam_")

static func is_flashback(visual: String) -> bool:
	return visual.begins_with("exam_")

static func set_identity(visual: String, location: int, sequence: String) -> String:
	# A dialogue key may change an expression in one room, or make an actual
	# cutaway. Negative route indices alone cannot distinguish these two cases.
	if is_flashback(visual): return "examination"
	if location>=0: return "area:%d" % location
	if sequence=="opening" and base_visual(visual)=="grimoire": return "grimoire_vault"
	return "academy_epilogue" if sequence=="ending" else "examination"

static func flame_position(visual: String, time: float) -> Vector2:
	match base_visual(visual):
		"fire": return PAW.lerp(TURN,smoothstep(0.12,2.4,time))
		"reverse":
			var t := clampf(time/1.6,0.0,1.0)
			# Lift, curl and return. The flame passes the cat on its way out of
			# the frame, while the intended target remains untouched.
			var bend := Vector2(575,102)
			return TURN*(1.0-t)*(1.0-t)+bend*2.0*t*(1.0-t)+BEHIND_CAT*t*t
	return PAW

static func flame_heading(visual: String, time: float) -> float:
	if base_visual(visual)=="reverse":
		var before := flame_position(visual,maxf(0.0,time-0.015))
		var after := flame_position(visual,time+0.015)
		return (after-before).angle() if after.distance_squared_to(before)>0.001 else PI
	return (TURN-PAW).angle()

static func explosion_strength(visual: String, time: float) -> float:
	if base_visual(visual)!="boom": return 0.0
	return maxf(0.0,1.0-time/0.72)

static func snapshot(visual: String, time: float, location: int) -> Dictionary:
	var base := base_visual(visual)
	return {"visual":base,"flashback":is_flashback(visual),
		"target_visible":location<0 or is_flashback(visual),
		"target_rect":TARGET,"flame":flame_position(visual,time),
		"heading":flame_heading(visual,time),"blast":explosion_strength(visual,time),
		"rear_blast":Vector2(110,259),"target_hit":false}
