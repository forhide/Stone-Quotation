class_name EquipmentArt
extends RefCounted

# Inventory, drops and worn equipment share cached imported HD artwork.
const SHEET: Texture2D = preload("res://art/equipment/cute_equipment.png")
const WEAPON_SHEET: Texture2D = preload("res://art/equipment/elemental_weapons.png")
const PENDANT_SHEET: Texture2D = preload("res://art/equipment/cute_pendants.png")
const CHARM_SHEET: Texture2D = preload("res://art/equipment/cute_charms.png")
const JOURNEY_WEAPONS_SHEET: Texture2D = preload("res://art/equipment/journey_weapons.png")
const JOURNEY_TRINKETS_SHEET: Texture2D = preload("res://art/equipment/journey_trinkets.png")
const JOURNEY_WEAPONS := ["embermatch_wand", "hearth_lantern_staff", "sunfizz_scepter", "brook_reed_wand", "tide_shell_staff", "moonwell_scepter", "icicle_chopstick", "snowbell_staff", "aurora_crown_staff", "whistle_reed_wand", "ribbon_kite_staff", "cloudwheel_scepter", "pebble_mallet_wand", "geode_lantern_staff", "mountain_tortoise_staff", "sprout_spindle_wand", "fern_crook_staff", "elder_bloom_scepter", "copper_fork_wand", "storm_bell_staff", "tempest_coil_scepter", "sewing_needle_wand", "silver_rose_staff", "starlance_scepter"]
const JOURNEY_COLLARS := ["ember_heart_collar", "raindrop_locket", "snowmint_bell_collar", "breeze_feather_collar", "basalt_turtle_collar", "fernseed_heart_collar", "stormcloud_key_collar", "silver_moon_collar", "hearth_sun_medal", "tide_pearl_collar", "glacier_star_collar", "sky_compass_collar"]
const JOURNEY_CHARMS := ["candle_button", "seashell_spool", "frozen_berries", "kite_bow", "clay_paw_token", "rooted_acorn", "copper_cloud_charm", "silver_thimble", "phoenix_feather", "seaglass_marble", "snowglobe_star", "dandelion_clock"]
const SILVERTHORN_SHEET: Texture2D = preload("res://art/equipment/silverthorn_wand.png")
const NEW_WEAPONS := ["practice_wand", "frost_whisker_wand", "hopscotch_wand", "pip_feather_staff", "moss_bud_staff", "bloop_bottle_wand", "thunder_spoon", "bubble_teapot", "comet_crayon"]
const NEW_COLLARS := ["linen_star_collar", "acorn_bell_collar", "button_bow_collar", "frost_drop_collar", "moss_heart_collar", "bloop_locket_collar", "thunder_key_collar", "bubble_pearl_collar", "comet_medal_collar"]
const NEW_CHARMS := ["paper_pinwheel", "clover_leaf", "sleepy_acorn", "frost_button", "pip_egg", "moss_seed_pouch", "bloop_cork", "thunder_marble", "comet_stamp"]
# Explicit row-major identity order, measured from the painted objects.
# Tall/short drawings must never be sorted by rounded grid coordinates.
const RECTS := {
 "embermatch_wand":Rect2(38,35,196,218),
 "hearth_lantern_staff":Rect2(284,23,208,231),
 "sunfizz_scepter":Rect2(525,14,221,240),
 "brook_reed_wand":Rect2(794,20,218,235),
 "tide_shell_staff":Rect2(1048,23,221,232),
 "moonwell_scepter":Rect2(1290,19,220,237),
 "icicle_chopstick":Rect2(39,275,196,230),
 "snowbell_staff":Rect2(276,267,222,246),
 "aurora_crown_staff":Rect2(533,257,220,254),
 "whistle_reed_wand":Rect2(793,275,209,232),
 "ribbon_kite_staff":Rect2(1043,255,236,260),
 "cloudwheel_scepter":Rect2(1292,269,224,246),
 "pebble_mallet_wand":Rect2(37,523,211,224),
 "geode_lantern_staff":Rect2(284,521,193,226),
 "mountain_tortoise_staff":Rect2(523,514,222,237),
 "sprout_spindle_wand":Rect2(801,530,208,225),
 "fern_crook_staff":Rect2(1052,517,216,240),
 "elder_bloom_scepter":Rect2(1291,521,225,228),
 "copper_fork_wand":Rect2(25,750,217,238),
 "storm_bell_staff":Rect2(283,751,209,242),
 "tempest_coil_scepter":Rect2(535,752,212,245),
 "sewing_needle_wand":Rect2(782,758,227,239),
 "silver_rose_staff":Rect2(1045,751,229,250),
 "starlance_scepter":Rect2(1284,748,234,250),
 "ember_heart_collar":Rect2(36,20,202,232),
 "raindrop_locket":Rect2(293,15,182,246),
 "snowmint_bell_collar":Rect2(552,15,203,239),
 "breeze_feather_collar":Rect2(785,17,220,246),
 "basalt_turtle_collar":Rect2(1033,24,245,231),
 "fernseed_heart_collar":Rect2(1317,20,196,243),
 "stormcloud_key_collar":Rect2(50,265,183,246),
 "silver_moon_collar":Rect2(293,268,177,237),
 "hearth_sun_medal":Rect2(517,265,236,252),
 "tide_pearl_collar":Rect2(791,269,219,247),
 "glacier_star_collar":Rect2(1064,271,184,244),
 "sky_compass_collar":Rect2(1288,273,229,240),
 "candle_button":Rect2(45,517,197,229),
 "seashell_spool":Rect2(268,517,223,225),
 "frozen_berries":Rect2(541,524,212,214),
 "kite_bow":Rect2(772,520,224,241),
 "clay_paw_token":Rect2(1050,516,209,238),
 "rooted_acorn":Rect2(1316,524,199,228),
 "copper_cloud_charm":Rect2(26,763,235,232),
 "silver_thimble":Rect2(286,756,225,234),
 "phoenix_feather":Rect2(517,748,221,254),
 "seaglass_marble":Rect2(798,762,203,237),
 "snowglobe_star":Rect2(1066,757,177,253),
 "dandelion_clock":Rect2(1290,758,215,250),
 "silverthorn_wand":Rect2(270,109,892,1040),
 "crooked_ash_wand":Rect2(60,29,343,463),
 "cinderfork_wand":Rect2(481,15,343,484),
 "apprentice_thesis":Rect2(865,71,375,413),
 "brass_bell_collar":Rect2(26,525,380,326),
 "velvet_bell_collar":Rect2(442,527,373,324),
 "nine_lives_collar":Rect2(845,525,388,335),
 "loose_feather":Rect2(31,863,379,376),
 "warm_sardine_charm":Rect2(437,932,369,286),
 "moonlit_yarn":Rect2(862,899,374,350),
 "practice_wand":Rect2(91,53,293,403),
 "frost_whisker_wand":Rect2(504,50,313,407),
 "hopscotch_wand":Rect2(885,83,322,373),
 "pip_feather_staff":Rect2(78,471,303,380),
 "moss_bud_staff":Rect2(483,471,310,385),
 "bloop_bottle_wand":Rect2(892,499,326,321),
 "thunder_spoon":Rect2(78,869,307,332),
 "bubble_teapot":Rect2(459,872,360,330),
 "comet_crayon":Rect2(905,874,309,331),
 "linen_star_collar":Rect2(62,56,324,352),
 "acorn_bell_collar":Rect2(484,57,324,361),
 "button_bow_collar":Rect2(852,87,374,336),
 "frost_drop_collar":Rect2(100,453,250,381),
 "moss_heart_collar":Rect2(485,475,299,356),
 "bloop_locket_collar":Rect2(914,454,270,384),
 "thunder_key_collar":Rect2(94,850,249,371),
 "bubble_pearl_collar":Rect2(473,856,329,366),
 "comet_medal_collar":Rect2(902,874,315,343),
 "paper_pinwheel":Rect2(68,31,355,419),
 "clover_leaf":Rect2(472,58,341,388),
 "sleepy_acorn":Rect2(904,52,315,390),
 "frost_button":Rect2(71,465,304,367),
 "pip_egg":Rect2(502,466,287,365),
 "moss_seed_pouch":Rect2(895,462,323,377),
 "bloop_cork":Rect2(74,838,301,376),
 "thunder_marble":Rect2(482,852,289,354),
 "comet_stamp":Rect2(892,857,336,377)
}
const ORIGINAL_PENDANTS := {
 "brass_bell_collar":Rect2(132,712,150,142),
 "velvet_bell_collar":Rect2(551,712,151,142),
 "nine_lives_collar":Rect2(959,712,156,150)
}
static var _icons: Dictionary = {}

static func has_icon(id: String) -> bool:
 return RECTS.has(id)

static func slot_for(id: String) -> String:
 if not has_icon(id): return ""
 if JOURNEY_WEAPONS.has(id) or id=="silverthorn_wand" or NEW_WEAPONS.has(id) or id in ["crooked_ash_wand","cinderfork_wand","apprentice_thesis"]: return "wand"
 if JOURNEY_COLLARS.has(id) or NEW_COLLARS.has(id) or ORIGINAL_PENDANTS.has(id): return "collar"
 return "charm"

static func _sheet_for(id: String) -> Texture2D:
 if JOURNEY_WEAPONS.has(id): return JOURNEY_WEAPONS_SHEET
 if JOURNEY_COLLARS.has(id) or JOURNEY_CHARMS.has(id): return JOURNEY_TRINKETS_SHEET
 if id=="silverthorn_wand": return SILVERTHORN_SHEET
 if NEW_WEAPONS.has(id): return WEAPON_SHEET
 if NEW_COLLARS.has(id): return PENDANT_SHEET
 if NEW_CHARMS.has(id): return CHARM_SHEET
 return SHEET

static func icon(id: String) -> Texture2D:
 if not has_icon(id): return null
 if not _icons.has(id):
  var texture := AtlasTexture.new()
  texture.atlas=_sheet_for(id)
  texture.region=RECTS[id]
  texture.filter_clip=true
  _icons[id]=texture
 return _icons[id]

# Original collars show only their pendant on the character. New collar art is
# authored as small pendants already, so it never places a strap across the face.
static func worn_icon(id: String) -> Texture2D:
 if not has_icon(id): return null
 if not ORIGINAL_PENDANTS.has(id): return icon(id)
 var key := "worn:"+id
 if not _icons.has(key):
  var texture := AtlasTexture.new()
  texture.atlas=SHEET
  texture.region=ORIGINAL_PENDANTS[id]
  texture.filter_clip=true
  _icons[key]=texture
 return _icons[key]

static func attachment_layout(id: String) -> Dictionary:
 var slot := slot_for(id)
 if slot.is_empty(): return {}
 var texture := worn_icon(id)
 var box := Vector2(42,52)
 var angle := -0.12
 if slot=="collar":
  box=Vector2(14,17)
  angle=0.0
 elif slot=="charm":
  box=Vector2(24,26)
  angle=-0.25
 elif id=="apprentice_thesis":
  box=Vector2(39,41)
 elif id=="bubble_teapot":
  box=Vector2(44,43)
  angle=-0.03
 elif id=="bloop_bottle_wand":
  box=Vector2(38,44)
 var source_size := texture.get_size()
 var factor := minf(box.x/source_size.x,box.y/source_size.y)
 return {"slot":slot,"extent":source_size*factor,"angle":angle}
