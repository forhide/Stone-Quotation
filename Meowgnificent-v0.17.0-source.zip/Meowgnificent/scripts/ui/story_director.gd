class_name StoryDirector
extends CanvasLayer

# Narrative UI is independent of combat. The room pauses its actors before
# opening a sequence and resumes from the completion callback. close() cancels;
# skip() and advance() on the last page complete exactly once.
signal sequence_started(kind: String, chapter: int)
signal sequence_finished(kind: String, chapter: int)
signal page_changed(index: int, total: int)

const STORY_PATH := "res://data/story.json"
const INK := Color("654e45")
const MUTED := Color("7c6c60")
const PAPER := Color("fff7e6")
const EDGE := Color("bda286")
var room: Node
var story: Dictionary = {}
var is_open := false
var mode := ""
var chapter_index := -1
var pages: Array = []
var page_index := 0
var elapsed := 0.0
var auto_advance := true
var last_completed_sequence := ""
var screen: Control
var stage: StoryStage
var speaker_label: Label
var body_label: Label
var chapter_label: Label
var page_label: Label
var next_button: Button
var skip_button: Button
var auto_button: Button
var _completion := Callable()
var _occluded_world: Array[Dictionary] = []

func _ready() -> void:
	layer=22
	process_mode=Node.PROCESS_MODE_ALWAYS
	var loaded: Variant=JSON.parse_string(FileAccess.get_file_as_string(STORY_PATH))
	if loaded is Dictionary:
		story=loaded
	else:
		push_error("Story data could not be read.")
	screen=Control.new()
	var story_theme := Theme.new()
	story_theme.default_font=preload("res://art/fonts/Pretendard-Medium.otf")
	screen.theme=story_theme
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter=Control.MOUSE_FILTER_STOP
	add_child(screen)
	var backdrop := ColorRect.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.color=Color("f5ecd8")
	backdrop.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(backdrop)
	chapter_label=_label("",28,INK,Vector2(78,47),Vector2(980,48))
	_label("ARCANA ACADEMY  ·  THE MISADVENTURES OF MEOWMALADE",12,Color("806348"),Vector2(80,27),Vector2(900,22))
	var frame := Panel.new()
	frame.position=Vector2(74,111)
	frame.size=Vector2(1132,397)
	frame.mouse_filter=Control.MOUSE_FILTER_IGNORE
	frame.add_theme_stylebox_override("panel",_style(Color("e8efdc"),EDGE,24,0))
	screen.add_child(frame)
	stage=StoryStage.new()
	stage.position=Vector2(75,112)
	stage.size=Vector2(1130,395)
	stage.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(stage)
	var dialogue := Panel.new()
	dialogue.position=Vector2(74,528)
	dialogue.size=Vector2(1132,196)
	dialogue.mouse_filter=Control.MOUSE_FILTER_IGNORE
	dialogue.add_theme_stylebox_override("panel",_style(PAPER,EDGE,22,0))
	screen.add_child(dialogue)
	speaker_label=_label("",15,Color("806348"),Vector2(101,548),Vector2(1050,25))
	body_label=_label("",23,INK,Vector2(101,582),Vector2(1050,91))
	body_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	page_label=_label("",13,MUTED,Vector2(80,746),Vector2(950,24))
	next_button=_button("Next page",Vector2(1034,666),Vector2(148,40),Color("d7e8c9"))
	next_button.pressed.connect(advance)
	skip_button=_button("Skip story",Vector2(1060,39),Vector2(146,39),Color("eee3f2"))
	skip_button.pressed.connect(skip)
	auto_button=_button("Auto advance: Off · A",Vector2(918,737),Vector2(288,35),Color("e6e9da"))
	auto_button.pressed.connect(toggle_auto_advance)
	var settings_button := _button("Settings",Vector2(910,39),Vector2(132,39),Color("e8eeda"))
	settings_button.pressed.connect(func(): room.settings.open())
	screen.hide()
	set_process(false)

func _label(text: String, font_size: int, color: Color, position_: Vector2, size_: Vector2) -> Label:
	var label := Label.new()
	label.text=text
	label.position=position_
	label.size=size_
	label.add_theme_font_size_override("font_size",font_size)
	label.add_theme_color_override("font_color",color)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(label)
	return label

func _style(fill: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left=margin
	style.content_margin_right=margin
	style.content_margin_top=margin
	style.content_margin_bottom=margin
	return style

func _button(caption: String, at: Vector2, size_: Vector2, fill: Color) -> Button:
	var button := Button.new()
	button.text=caption
	button.position=at
	button.size=size_
	button.add_theme_font_size_override("font_size",15)
	for key in ["font_color","font_hover_color","font_pressed_color"]:
		button.add_theme_color_override(key,INK)
	button.add_theme_stylebox_override("normal",_style(fill,Color("a79983"),11,6))
	button.add_theme_stylebox_override("hover",_style(fill.lightened(0.12),Color("8e9b7f"),11,6))
	button.add_theme_stylebox_override("pressed",_style(fill.darkened(0.06),Color("8e9b7f"),11,6))
	button.add_theme_stylebox_override("focus",_style(Color(0,0,0,0),Color("a88bb8"),11,0))
	screen.add_child(button)
	return button

func play_opening(done: Callable) -> void:
	_play("opening",-1,"A minor magical incident",story.get("opening",[]),true,done)

func show_chapter(index: int, done: Callable) -> void:
	var chapters: Array=story.get("chapters",[])
	if index<0 or index>=chapters.size():
		if done.is_valid(): done.call_deferred()
		return
	var definition: Dictionary=chapters[index]
	_play("chapter",index,str(definition.get("title","A new chapter")),definition.get("beats",[]),false,done)

func play_ending(done: Callable) -> void:
	_play("ending",-1,"An unexpected correct answer",story.get("ending",[]),true,done)

func _play(kind: String, chapter: int, title: String, sequence: Array, autoplay: bool, done: Callable) -> void:
	close()
	mode=kind
	chapter_index=chapter
	pages=sequence.duplicate(true)
	_completion=done
	page_index=0
	elapsed=0.0
	auto_advance=autoplay
	_update_auto_button()
	chapter_label.text=title
	if pages.is_empty():
		_finish()
		return
	is_open=true
	screen.show()
	_obscure_world()
	set_process(true)
	stage.begin_sequence()
	_show_page()
	sequence_started.emit(mode,chapter_index)

func _show_page() -> void:
	if page_index<0 or page_index>=pages.size(): return
	var page: Dictionary=pages[page_index]
	elapsed=0.0
	speaker_label.text=str(page.get("speaker",""))
	body_label.text=GameLocale.story_text(page)
	# Dialogue expressions do not choose the location. In particular, a deadpan
	# reaction must not teleport a garden or archive chapter back to the academy.
	var location := chapter_index if mode=="chapter" else -1
	if mode=="opening" and str(page.get("visual",""))=="detention": location=0
	if mode=="ending" and page_index<6: location=7
	stage.sequence_kind=mode
	stage.line_index=page_index
	stage.set_scene(str(page.get("visual","academy")),location,str(page.get("speaker","")))
	page_label.text=GameLocale.text("%02d / %02d  ·  ENTER / SPACE: next page  ·  ESC: skip story") % [page_index+1,pages.size()]
	var last := page_index==pages.size()-1
	next_button.text=("Begin detention" if mode=="opening" else "Continue") if last else "Next page"
	if mode=="ending" and last: next_button.text="The end"
	page_changed.emit(page_index,pages.size())

func refresh_language() -> void:
	if not is_open or pages.is_empty(): return
	body_label.text=GameLocale.story_text(pages[page_index])
	page_label.text=GameLocale.text("%02d / %02d  ·  ENTER / SPACE: next page  ·  ESC: skip story") % [page_index+1,pages.size()]
	stage.queue_redraw()
	stage.location_backdrop.queue_redraw()
	_update_auto_button()

func _page_read_duration() -> float:
	if pages.is_empty(): return 0.0
	var page: Dictionary=pages[page_index]
	var text := GameLocale.story_text(page)
	# The authored value protects the action's timing; the localized reading
	# floor prevents long narration disappearing at a short animation cue.
	var characters_per_second := 10.5 if GameLocale.current=="ko" else 23.0
	return maxf(float(page.get("duration",4.0)),1.1+float(text.length())/characters_per_second)

func _update_auto_button() -> void:
	if is_instance_valid(auto_button): auto_button.text="Auto advance: On · A" if auto_advance else "Auto advance: Off · A"

func toggle_auto_advance() -> void:
	if not is_open: return
	auto_advance=not auto_advance
	# Turning automatic playback back on gives this line a full reading window.
	if auto_advance: elapsed=0.0
	_update_auto_button()

func advance() -> void:
	if not is_open: return
	if page_index>=pages.size()-1:
		_finish()
	else:
		page_index+=1
		_show_page()

func skip() -> void:
	if is_open: _finish()

func close() -> void:
	_restore_world()
	is_open=false
	_completion=Callable()
	if is_instance_valid(screen): screen.hide()
	set_process(false)

func _obscure_world() -> void:
	# The story paper covers the world completely. Pausing simulation alone
	# still submits its enemies, equipment, backdrop and HUD to the renderer.
	# Remember each local visibility flag rather than forcing hidden UI on later.
	if not is_instance_valid(room): return
	for node in [room.background,room.actors,room.projectiles,room.markers,room.hud]:
		if is_instance_valid(node):
			_occluded_world.append({"node":node,"visible":node.visible})
			node.visible=false

func _restore_world() -> void:
	for entry in _occluded_world:
		if is_instance_valid(entry.node): entry.node.visible=entry.visible
	_occluded_world.clear()

func _finish() -> void:
	var done := _completion
	var finished_mode := mode
	var finished_chapter := chapter_index
	last_completed_sequence=finished_mode
	close()
	# GUI clicks and Space are also cast bindings. Clear their held action before
	# returning to the room; its callback also blocks casts until input releases.
	if InputMap.has_action("cast"): Input.action_release("cast")
	sequence_finished.emit(finished_mode,finished_chapter)
	if done.is_valid(): done.call_deferred()

func _input(event: InputEvent) -> void:
	if is_instance_valid(room) and is_instance_valid(room.settings) and room.settings.blocks_gameplay_input(): return
	if not is_open: return
	if event is InputEventKey:
		get_viewport().set_input_as_handled()
		if not event.is_pressed() or event.is_echo(): return
		match event.keycode:
			KEY_ESCAPE: skip()
			KEY_ENTER,KEY_KP_ENTER,KEY_SPACE: advance()
			KEY_A: toggle_auto_advance()

func _process(delta: float) -> void:
	if not is_open: return
	elapsed+=delta
	stage.tick(delta)
	stage.queue_redraw()
	if auto_advance:
		if elapsed>=_page_read_duration(): advance()

class StoryStage extends Control:
	var visual := "academy"
	var base_visual := "academy"
	# `time` belongs to a distinct action (fire -> reverse -> boom). Ambient
	# movement and entrances belong to the continuous set, never a dialogue line.
	var time := 0.0
	var ambient_time := 0.0
	var entrance_time := 0.0
	var line_reaction_time := 99.0
	var background_blend_age := 99.0
	var previous_background: Texture2D
	var backdrop_configurations := 0
	var action_resets := 0
	var scene_entries := 0
	var _scene_initialized := false
	var _new_sequence := true
	var _actor_states: Dictionary = {}
	var focus_actor := ""
	var _speaker_weights := {"meowmalade":0.0,"professor":0.0,"pip":0.0,"moss":0.0,"bloop":0.0,"grimoire":0.0}
	var vine_points := PackedVector2Array()
	var reverse_trail := PackedVector2Array()
	var sequence_kind := "opening"
	var line_index := 0
	var grimoire_pose := "calm"
	var exam_flashback := false
	var exam_scene := false
	var sooty := false
	var exam_damage_age := -1.0
	var living_age := 0.0
	var _last_living_kind := ""
	var living_cue := 0
	var living_cue_start := 0.0
	var hero: TextureRect
	var hero_frames: Array[AtlasTexture] = []
	const HERO_SHEET: Texture2D = WizardCatVisual.ACTION_SHEET
	const ACADEMY: Texture2D = preload("res://art/hd/hd_academy_library.res")
	const LIBRARY: Texture2D = ACADEMY
	const FRIENDS: Texture2D = preload("res://art/hd/hd_forbidden_garden.res")
	const ARCHIVE: Texture2D = preload("res://art/hd/hd_grand_archive.res")
	const TARGET: Texture2D = preload("res://art/story/props/practice_target.png")
	var plate: Texture2D = ACADEMY
	var report_style: StyleBoxFlat
	var clear_style: StyleBoxEmpty
	var location_index := -1
	var location_backdrop: ArchiveBackdrop
	var friend_frame: Panel
	var friend_portrait: TextureRect
	var friend_regions: Dictionary = {}
	var group_portraits: Array[TextureRect] = []
	var actor_ids := PackedStringArray()
	var target_sprite: TextureRect
	var foreground: StoryForeground
	var hero_rect := Rect2(162,79,248,282)
	var actor_rect := Rect2(700,111,235,250)
	var living_props: Array[TextureRect] = []
	var living_prop_kind := ""
	var living_prop_rects: Array[Rect2] = []
	var hen_sprite: TextureRect
	var tea_sprite: TextureRect
	var tea_age := -1.0
	const HEN_FEET := Vector2(424,374)
	const TEA_RECT := Rect2(476,316,86,60)
	const TEA_ART: Texture2D = preload("res://art/npc/story_tea.png")

	func _ready() -> void:
		vine_points.resize(15)
		reverse_trail.resize(9)
		clip_contents=true
		texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
		report_style=StyleBoxFlat.new()
		report_style.bg_color=Color("fff7e9")
		report_style.border_color=Color("bca27f")
		report_style.set_border_width_all(2)
		report_style.set_corner_radius_all(14)
		report_style.shadow_color=Color(0.25,0.19,0.14,0.18)
		report_style.shadow_size=10
		clear_style=StyleBoxEmpty.new()
		location_backdrop=ArchiveBackdrop.new()
		location_backdrop.include_frame=false
		location_backdrop.foreground_living_props=true
		location_backdrop.show_behind_parent=true
		location_backdrop.visible=false
		location_backdrop.scale=Vector2.ONE*(1130.0/1280.0)
		location_backdrop.position=Vector2(0,-28)
		add_child(location_backdrop)
		for i in range(6):
			var prop := _sprite()
			prop.visible=false
			add_child(prop)
			living_props.append(prop)
		target_sprite=_sprite()
		target_sprite.texture=TARGET
		add_child(target_sprite)
		hero=_sprite()
		for rectangle in WizardCatVisual.POSE_RECTS:
			var frame := AtlasTexture.new()
			frame.atlas=HERO_SHEET
			frame.region=Rect2(rectangle)
			frame.filter_clip=true
			hero_frames.append(frame)
		hero.texture=hero_frames[0]
		add_child(hero)
		_register_actor(hero,"meowmalade")
		# All actors stand together in the illustrated set. Their feet remain
		# planted while body/hat gestures pivot from the floor, not a portrait box.
		friend_frame=Panel.new()
		friend_frame.add_theme_stylebox_override("panel",clear_style)
		friend_frame.mouse_filter=Control.MOUSE_FILTER_IGNORE
		add_child(friend_frame)
		friend_portrait=_sprite()
		friend_frame.add_child(friend_portrait)
		_register_actor(friend_portrait,"")
		for key: String in ["professor","pip","moss","bloop"]:
			friend_regions[key]=AnimalCast.icon(key)
		for key in ["pip","moss","bloop"]:
			var portrait := _sprite()
			portrait.texture=AnimalCast.icon(key)
			portrait.set_meta("animal_id",key)
			friend_frame.add_child(portrait)
			_register_actor(portrait,str(key))
			group_portraits.append(portrait)
		# Props stay allocated like the cast. Pip's failed summon must produce
		# the same actual chicken that accompanies the party in the market.
		hen_sprite=_sprite()
		hen_sprite.texture=WorldDetailArt.icon("hen")
		hen_sprite.hide()
		add_child(hen_sprite)
		tea_sprite=_sprite()
		var tea_atlas := AtlasTexture.new()
		tea_atlas.atlas=TEA_ART
		tea_atlas.region=Rect2(171,129,1216,791)
		tea_atlas.filter_clip=true
		tea_sprite.texture=tea_atlas
		tea_sprite.hide()
		add_child(tea_sprite)
		foreground=StoryForeground.new()
		foreground.stage=self
		foreground.mouse_filter=Control.MOUSE_FILTER_IGNORE
		add_child(foreground)
		set_scene(visual)

	func _sprite() -> TextureRect:
		var sprite := TextureRect.new()
		sprite.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		sprite.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
		sprite.mouse_filter=Control.MOUSE_FILTER_IGNORE
		return sprite

	func begin_sequence() -> void:
		# Nodes/textures stay allocated across chapters. Only a genuinely new
		# sequence gets an entrance; page changes keep their live composition.
		_new_sequence=true
		exam_damage_age=-1.0
		living_age=0.0
		_last_living_kind=""
		living_cue=0
		living_cue_start=0.0
		tea_age=-1.0
		time=0.0
		ambient_time=0.0
		entrance_time=0.0
		line_reaction_time=99.0
		previous_background=null
		background_blend_age=99.0
		for actor_id: int in _actor_states:
			var state: Dictionary=_actor_states[actor_id]
			state.texture=null
			state.blend_age=99.0
			state.move_age=99.0
			state.target_rect=Rect2()
			state.current_rect=Rect2()
			state.ghost.hide()
		for actor: String in _speaker_weights: _speaker_weights[actor]=0.0

	func tick(delta: float) -> void:
		time+=delta
		if tea_age>=0: tea_age+=delta
		if exam_damage_age>=0: exam_damage_age+=delta
		elif exam_scene and base_visual=="reverse" and time>=1.85:
			# The return flight hits the rear wall in its own continuous shot.
			# Reading/holding this page cannot leave a fireball frozen in midair.
			exam_damage_age=time-1.85
			sooty=true
		if not living_prop_kind.is_empty(): living_age+=delta
		ambient_time+=delta
		entrance_time+=delta
		line_reaction_time+=delta
		background_blend_age+=delta
		var smoothing := 1.0-exp(-delta*9.0)
		for actor: String in _speaker_weights:
			_speaker_weights[actor]=lerpf(float(_speaker_weights[actor]),1.0 if actor==focus_actor else 0.0,smoothing)
		for actor_id: int in _actor_states:
			var state: Dictionary=_actor_states[actor_id]
			state.blend_age+=delta
			state.move_age+=delta
			if not state.sprite.visible: state.ghost.hide()

	func _register_actor(sprite: TextureRect, actor: String) -> void:
		var ghost := _sprite()
		ghost.name="PreviousExpression"
		ghost.hide()
		var parent := sprite.get_parent()
		parent.add_child(ghost)
		parent.move_child(ghost,sprite.get_index())
		_actor_states[sprite.get_instance_id()]={"sprite":sprite,"ghost":ghost,"actor":actor,"texture":null,"blend_age":99.0,"blend_duration":0.20,"target_rect":Rect2(),"from_rect":Rect2(),"current_rect":Rect2(),"move_age":99.0}

	func set_scene(value: String, location: int=-1, speaker: String="") -> void:
		var previous := base_visual
		var previous_visual := visual
		var previous_location := location_index
		var previous_flashback := exam_flashback
		var previous_actor_ids := actor_ids.duplicate()
		var previous_pose := grimoire_pose
		var previous_set := StoryShot.set_identity(previous_visual,previous_location,sequence_kind)
		var old_background: Texture2D=location_backdrop._location_art() if is_instance_valid(location_backdrop) and location_backdrop.visible else plate
		visual=value
		base_visual=StoryShot.base_visual(value)
		exam_flashback=StoryShot.is_flashback(value)
		location_index=location
		var entering := _new_sequence or not _scene_initialized or previous_set!=StoryShot.set_identity(value,location,sequence_kind) or previous_flashback!=exam_flashback
		if entering or previous_visual!=value:
			time=0.0
			action_resets+=1
		if entering:
			entrance_time=0.0
			scene_entries+=1
			if _scene_initialized and not _new_sequence:
				previous_background=old_background
				background_blend_age=0.0
		line_reaction_time=0.0
		focus_actor={"MEOWMALADE":"meowmalade","PROFESSOR":"professor","PIP":"pip","MOSS":"moss","GARDEN KEEPER":"moss","BLOOP":"bloop","THE PERFECT GRIMOIRE":"grimoire"}.get(speaker,"")
		_scene_initialized=true
		_new_sequence=false
		exam_scene=exam_flashback or (sequence_kind=="opening" and location<0 and base_visual in ["academy","deadpan","fire","reverse","boom"])
		if exam_scene and base_visual=="boom" and exam_damage_age<0: exam_damage_age=0.0
		var remains_in_exam := exam_flashback or sequence_kind=="opening" and location<0 and base_visual in ["academy","deadpan","fire","reverse","boom","title","grades"]
		if not remains_in_exam: exam_damage_age=-1.0
		sooty=exam_damage_age>=0
		if is_instance_valid(location_backdrop):
			location_backdrop.visible=location>=0 and not exam_flashback
			if location>=0 and (location_backdrop.stage_index!=location or backdrop_configurations==0):
				location_backdrop.configure(location)
				backdrop_configurations+=1
		if base_visual in ["library","grimoire","truth","analysis"]: plate=LIBRARY
		elif base_visual in ["garden","pip","moss","bloop","friends"]: plate=FRIENDS
		elif base_visual in ["archive","examiner"]: plate=ARCHIVE
		else: plate=ACADEMY
		if exam_flashback: plate=ACADEMY
		var vault_cutaway := sequence_kind=="opening" and location<0 and base_visual=="grimoire"
		if vault_cutaway: plate=ARCHIVE
		hero_rect=Rect2(162,79,248,282)
		actor_rect=Rect2(700,111,235,250)
		if exam_scene:
			hero_rect=Rect2(284,62,250,295)
			actor_rect=Rect2(76,130,184,218)
		elif base_visual in ["friends","pip","moss","bloop","garden"]:
			hero_rect=Rect2(120,109,226,266)
			actor_rect=Rect2(652,113,234,256)
		elif base_visual in ["grades","report"]:
			hero_rect=Rect2(140,87,250,282)
		elif base_visual in ["grimoire","truth","analysis","archive","examiner"]:
			hero_rect=Rect2(146,100,230,266)
			actor_rect=Rect2(716,66,234,280)
			if base_visual=="analysis": actor_rect=Rect2(815,36,195,225)
		# A visual key describes an expression/action, not a new place to stand.
		# Keep the cat's floor anchor across narration, the book's response and
		# its own reaction. Only an actual set change establishes a new layout.
		if sequence_kind=="chapter" and not exam_flashback:
			hero_rect=Rect2(146,100,230,266) if location_index in [1,7] else Rect2(120,109,226,266) if location_index in [2,3,4,5,6] else Rect2(162,79,248,282)
		if sequence_kind=="ending":
			if location_index==7:
				hero_rect=Rect2(146,100,230,266)
			else:
				# The professor and cat share the left of the picture, leaving
				# the right clear for the report. Neither disappears between lines.
				hero_rect=Rect2(258,87,204,282)
				actor_rect=Rect2(61,126,174,236)
		if base_visual in ["garden","moss"]:
			actor_rect=Rect2(861,126,186,237)
		_configure_living_props()
		if is_instance_valid(hero):
			hero.visible=base_visual!="end" and not vault_cutaway
			hero.texture=hero_frames[1] if base_visual=="fire" else hero_frames[3] if base_visual=="reverse" else hero_frames[0]
		if is_instance_valid(target_sprite):
			target_sprite.visible=exam_scene
			target_sprite.position=StoryShot.TARGET.position
			target_sprite.size=StoryShot.TARGET.size
			target_sprite.flip_h=true
		if is_instance_valid(friend_frame):
			var group := base_visual=="friends"
			var actor := ""
			if friend_regions.has(base_visual): actor=base_visual
			elif speaker=="PROFESSOR" or base_visual=="academy" or exam_scene: actor="professor"
			elif speaker=="GARDEN KEEPER" or base_visual=="garden": actor="moss"
			elif base_visual in ["grimoire","truth","analysis","archive"] or speaker=="THE PERFECT GRIMOIRE": actor="grimoire"
			elif base_visual=="examiner": actor="grimoire"
			if sequence_kind=="ending" and location_index==7: actor="grimoire"
			if sequence_kind=="ending" and location_index<0 and base_visual!="end": actor="professor"
			var retained := actor.is_empty() and base_visual in ["deadpan","detention"] and not entering and previous_actor_ids.size()==1
			if retained: actor=str(previous_actor_ids[0])
			# Report/grades make room for the actual card, not an extra portrait.
			if base_visual in ["grades","title","end"] or base_visual=="report" and sequence_kind!="ending": actor=""
			actor_ids=PackedStringArray(["pip","moss","bloop"]) if group else PackedStringArray([actor]) if not actor.is_empty() else PackedStringArray()
			friend_frame.visible=group or not actor.is_empty()
			friend_portrait.visible=not group
			friend_frame.position=Vector2.ZERO
			friend_frame.size=size
			for index in range(group_portraits.size()):
				var portrait := group_portraits[index]
				portrait.visible=group
				portrait.position=Vector2(490+index*192,119+(9 if index==1 else 0))
				portrait.size=Vector2(185,245-(9 if index==1 else 0))
			if actor=="grimoire":
				grimoire_pose="shocked" if base_visual=="reverse" else "damaged" if base_visual=="boom" else "angry" if base_visual=="examiner" else "calm"
				if base_visual=="analysis" and line_index>0: grimoire_pose="shocked"
				if sequence_kind=="ending" and line_index==0: grimoire_pose="angry"
				if retained: grimoire_pose=previous_pose
				friend_portrait.texture=GrimoireArt.icon(grimoire_pose)
				actor_rect=Rect2(722,73,286,228) if base_visual!="analysis" else Rect2(816,44,222,206)
				if vault_cutaway: actor_rect=Rect2(422,64,286,228)
			elif not actor.is_empty(): friend_portrait.texture=friend_regions[actor]
			var partner_state: Dictionary=_actor_states[friend_portrait.get_instance_id()]
			partner_state.identity_changed=partner_state.actor!=actor
			partner_state.actor=actor
		if living_prop_kind=="book" and actor_ids==PackedStringArray(["grimoire"]): actor_rect=Rect2(864,28,151,187)
		if location_index==6 and base_visual in ["bloop","friends"] and tea_age<0: tea_age=0.0
		if location_index!=6: tea_age=-1.0
		_animate_actors()
		queue_redraw()

	func _pose(sprite: TextureRect, rect: Rect2, phase: float, gesture: float=0.0) -> void:
		var state: Variant=_actor_states.get(sprite.get_instance_id())
		if state!=null:
			if bool(state.get("identity_changed",false)):
				# A different animal enters at its own mark. Crossfade the old
				# partner where it was standing, rather than sliding one species
				# across the room while its drawing morphs into another animal.
				state.from_rect=rect
				state.target_rect=rect
				state.move_age=99.0
				state.identity_changed=false
			elif state.target_rect!=rect:
				state.from_rect=state.current_rect if state.current_rect.size!=Vector2.ZERO else rect
				state.target_rect=rect
				state.move_age=0.0
			var move := smoothstep(0.0,0.28,float(state.move_age))
			rect=Rect2(state.from_rect.position.lerp(rect.position,move),state.from_rect.size.lerp(rect.size,move))
			state.current_rect=rect
			if state.texture!=null and state.texture!=sprite.texture:
				var ghost: TextureRect=state.ghost
				ghost.texture=state.texture
				ghost.position=sprite.position
				ghost.size=sprite.size
				ghost.pivot_offset=sprite.pivot_offset
				ghost.scale=sprite.scale
				ghost.rotation=sprite.rotation
				ghost.modulate=Color.WHITE
				ghost.show()
				state.blend_age=0.0
			state.texture=sprite.texture
		var source_size := sprite.texture.get_size() if sprite.texture!=null else rect.size
		var factor := minf(rect.size.x/source_size.x,rect.size.y/source_size.y)
		var extent := source_size*factor
		sprite.position=rect.position+Vector2((rect.size.x-extent.x)*0.5,rect.size.y-extent.y)
		sprite.size=extent
		sprite.pivot_offset=Vector2(extent.x*0.5,extent.y)
		var breath := sin(ambient_time*1.9+phase)*0.005
		sprite.scale=Vector2(1.0-breath,1.0+breath)
		var emphasis := float(_speaker_weights.get(str(state.actor),0.0)) if state!=null else 0.0
		var beat := clampf(line_reaction_time/0.90,0.0,1.0)
		var nod := sin(beat*TAU)*sin(beat*PI)*0.022*emphasis
		sprite.rotation=sin(ambient_time*1.4+phase)*0.006+gesture+nod
		var entrance := 1.0-pow(1.0-clampf(entrance_time/0.38,0,1),3)
		sprite.position.x+=(1.0-entrance)*12.0*(1.0 if phase>1 else -1.0)
		sprite.modulate.a=lerpf(0.35,1.0,entrance)
		if state!=null:
			var blend := smoothstep(0.0,float(state.blend_duration),float(state.blend_age))
			var ghost: TextureRect=state.ghost
			if blend<1 and ghost.visible:
				ghost.modulate.a=(1.0-blend)*lerpf(0.35,1.0,entrance)
				sprite.modulate.a*=blend
			else: ghost.hide()

	func _animate_actors() -> void:
		if not is_instance_valid(hero): return
		var base := base_visual
		var gesture := -0.035*exp(-time*1.4) if base=="reverse" else 0.0
		if base=="fire": hero.texture=hero_frames[1 if time<0.35 else 2]
		elif base=="reverse": hero.texture=hero_frames[3]
		elif base=="boom": hero.texture=hero_frames[4 if time<0.55 else 0]
		if sooty and exam_damage_age>=0.55:
			hero.texture=StoryConsequences.sooty_actor(false)
			if actor_ids==PackedStringArray(["professor"]): friend_portrait.texture=StoryConsequences.sooty_actor(true)
		_pose(hero,hero_rect,0.0,gesture)
		if friend_frame.visible:
			if actor_ids.size()==3:
				for i in range(group_portraits.size()):
					var rect := Rect2(490+i*192,119+(9 if i==1 else 0),185,245-(9 if i==1 else 0))
					_pose(group_portraits[i],rect,float(i)+1)
			else:
				var reaction := -0.08*exp(-time*2.3) if base=="reverse" else 0.0
				_pose(friend_portrait,actor_rect,2.0,reaction)
				if actor_ids==PackedStringArray(["grimoire"]):
					friend_portrait.position.y+=sin(ambient_time*1.5)*3.0
					friend_portrait.rotation=sin(ambient_time*1.2)*0.016+reaction
		hero.self_modulate=Color.WHITE
		friend_portrait.self_modulate=Color.WHITE
		if sooty and actor_ids==PackedStringArray(["professor"]):
			friend_portrait.rotation+=sin(exam_damage_age*15)*exp(-exam_damage_age*1.5)*0.07
		_animate_living_props()
		_animate_companion_props()
		var blast := StoryShot.explosion_strength("boom",exam_damage_age) if sooty else StoryShot.explosion_strength(visual,time)
		hero.position.x+=sin(time*47)*blast*4
		if target_sprite.visible:
			target_sprite.pivot_offset=Vector2(target_sprite.size.x*0.5,target_sprite.size.y)
			target_sprite.rotation=sin(time*32)*blast*0.025
		if is_instance_valid(foreground): foreground.queue_redraw()

	func _animate_companion_props() -> void:
		if not is_instance_valid(hen_sprite): return
		hen_sprite.visible=sequence_kind=="chapter" and location_index in [3,6]
		if hen_sprite.visible:
			var reveal := smoothstep(0.62,0.96,ambient_time) if location_index==3 else 1.0
			var extent := hen_sprite.texture.get_size()
			extent*=72.0/extent.y
			hen_sprite.size=extent
			hen_sprite.pivot_offset=Vector2(extent.x*0.5,extent.y)
			hen_sprite.position=HEN_FEET-hen_sprite.pivot_offset
			var landing := sin(clampf((ambient_time-0.72)/0.48,0.0,1.0)*PI)*0.065 if location_index==3 else 0.0
			var breath := sin(ambient_time*1.8)*0.005
			hen_sprite.scale=Vector2(1.0+landing-breath,1.0-landing+breath)
			var peck_phase := fmod(maxf(0.0,ambient_time-1.5),4.7)
			var peck := sin(clampf(peck_phase/0.65,0.0,1.0)*PI)*0.095
			hen_sprite.rotation=-peck
			hen_sprite.modulate.a=reveal
		tea_sprite.visible=sequence_kind=="chapter" and location_index==6 and tea_age>=0
		if tea_sprite.visible:
			var extent := tea_sprite.texture.get_size()
			extent*=minf(TEA_RECT.size.x/extent.x,TEA_RECT.size.y/extent.y)
			tea_sprite.size=extent
			tea_sprite.position=TEA_RECT.position+Vector2((TEA_RECT.size.x-extent.x)*0.5,TEA_RECT.size.y-extent.y)
			tea_sprite.modulate.a=smoothstep(0.0,0.32,tea_age)

	func _configure_living_props() -> void:
		living_prop_kind="book" if location_index in [1,4] and not exam_flashback else "mushroom" if location_index in [2,5] else ""
		if living_prop_kind!=_last_living_kind:
			living_age=0.0
			_last_living_kind=living_prop_kind
			living_cue=0
			living_cue_start=0.0
		var next_cue := 1 if living_prop_kind=="book" and location_index==1 and line_index>=4 else mini(line_index,2) if living_prop_kind=="mushroom" and location_index==2 else 0
		if next_cue!=living_cue:
			living_cue=next_cue
			living_cue_start=living_age
		living_prop_rects.clear()
		for i in range(living_props.size()):
			var prop := living_props[i]
			prop.visible=not living_prop_kind.is_empty()
			if not prop.visible: continue
			prop.texture=LivingStageArt.icon(living_prop_kind)
			var rect := Rect2(445+i*94,266,78,64) if living_prop_kind=="book" else Rect2(428+(i%3)*127,178+(i/3)*94,85,83)
			living_prop_rects.append(rect)
			_pose(prop,rect,float(i))

	func _living_visual_age() -> float:
		var cue_age := maxf(0,living_age-living_cue_start)
		if living_prop_kind=="book" and location_index==1:
			return minf(living_age,2.4) if living_cue==0 else 2.5+cue_age
		if living_prop_kind=="mushroom" and location_index==2:
			if living_cue==0: return minf(living_age,1.4)
			if living_cue==1: return 1.5+minf(cue_age,0.9)
			return 2.6+cue_age
		return living_age

	func _animate_living_props() -> void:
		if living_prop_kind.is_empty(): return
		var cue_age := _living_visual_age()
		var wake := smoothstep(0.85,1.65,cue_age)
		var rise := smoothstep(1.4,2.35,cue_age)
		var lunge := sin(clampf((cue_age-2.5)/0.65,0,1)*PI)*24.0
		for i in range(living_props.size()):
			var prop := living_props[i]
			var rect := living_prop_rects[i]
			if living_prop_kind=="book":
				prop.texture=LivingStageArt.icon("book_fold" if cue_age>2.5 and cue_age<3.15 else "book")
				rect.position.y+=(1-rise)*18+sin(ambient_time*1.8)*3.2-lunge*0.25
				rect.position.x-=lunge
				_pose(prop,rect,1.0,0.0)
				prop.rotation=sin(ambient_time*1.8)*0.014
				prop.modulate.a*=wake
			else:
				prop.texture=LivingStageArt.icon("mushroom_sneeze" if cue_age>2.6 and cue_age<3.3 else "mushroom")
				rect.position.y+=(1-rise)*12+smoothstep(2.5,3.5,cue_age)*18.0
				_pose(prop,rect,1.0,0.0)
				var pulse := sin(ambient_time*2.2)*0.015
				prop.scale=Vector2(1.0+pulse,1.0-pulse)*(0.89+rise*0.11)
				prop.modulate=Color.WHITE.lerp(Color("bda5d3"),progress_wash(cue_age))

	func progress_wash(cue_age: float) -> float:
		return sin(clampf((cue_age-0.7)/1.6,0,1)*PI)*0.3

	func _text(source: String, at: Vector2, font_size: int=22, color: Color=Color("654e45")) -> void:
		var text := GameLocale.text(source)
		var font := GameLocale.STORY_FONT
		var width := font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x
		draw_string(font,at-Vector2(width*0.5,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,color)

	func _shadow(at: Vector2, width: float, alpha: float=0.14) -> void:
		draw_set_transform(at,0,Vector2(1,0.19))
		draw_circle(Vector2.ZERO,width,Color(0.29,0.24,0.30,alpha))
		draw_set_transform(Vector2.ZERO)

	func _draw() -> void:
		_animate_actors()
		var source := HiResArt.logical_size(plate)
		var crop_height := source.x*size.y/size.x
		var pan := sin(ambient_time*0.08)*4.0
		var crop := Rect2(0,(source.y-crop_height)*0.53+pan,source.x,crop_height)
		if location_index<0 or exam_flashback:
			draw_texture_rect_region(plate,Rect2(Vector2.ZERO,size),crop)
		if previous_background!=null and background_blend_age<0.32:
			var previous_size := HiResArt.logical_size(previous_background)
			var previous_height := previous_size.x*size.y/size.x
			draw_texture_rect_region(previous_background,Rect2(Vector2.ZERO,size),Rect2(0,(previous_size.y-previous_height)*0.53,previous_size.x,previous_height),Color(1,1,1,1.0-smoothstep(0.0,0.32,background_blend_age)))
		if sooty: StoryConsequences.draw_ruins(self,size,exam_damage_age)
		# Warm air/light provides depth without obscuring the actual room art.
		draw_rect(Rect2(Vector2.ZERO,size),Color(1,0.97,0.88,0.09))
		for i in range(7):
			var mote := Vector2(90+i*157,38+fmod(i*53-ambient_time*(4+i%3),265))
			draw_circle(mote,1.5,Color(1,0.97,0.83,0.35+sin(ambient_time+i)*0.1))
		if not living_prop_kind.is_empty(): StoryConsequences.draw_living(self,living_prop_kind,living_prop_rects,_living_visual_age())
		if hero.visible: _shadow(hero.position+hero.pivot_offset-Vector2(0,2),hero.size.x*0.32)
		if hen_sprite.visible: _shadow(HEN_FEET,22,0.12*hen_sprite.modulate.a)
		if tea_sprite.visible: _shadow(TEA_RECT.position+Vector2(TEA_RECT.size.x*0.5,TEA_RECT.size.y),23,0.10*tea_sprite.modulate.a)
		if exam_scene: _shadow(Vector2(925,338),61,0.12)
		if friend_frame.visible:
			if actor_ids.size()==3:
				for portrait in group_portraits: _shadow(portrait.position+portrait.pivot_offset-Vector2(0,2),portrait.size.x*0.31)
			else: _shadow(friend_portrait.position+friend_portrait.pivot_offset-Vector2(0,2),friend_portrait.size.x*0.31)
		if base_visual in ["grimoire","truth","analysis","archive","examiner"]:
			_draw_grimoire()
		if base_visual in ["garden","moss"]: _garden_gesture()
		if base_visual in ["grades","report"]: _report(base_visual=="report")
		if base_visual=="analysis":
			draw_style_box(report_style,Rect2(474,268,568,89))
			_text("POWER: EXTREME    CONTROL: 3%",Vector2(758,302),18)
			_text("PREDICTABILITY: 0%    …ERROR",Vector2(758,334),20,Color("a1687c"))
		if base_visual=="title" or base_visual=="end":
			draw_style_box(report_style,Rect2(420,112,650,155))
			_text("Meowgnificent",Vector2(745,178),49,Color("826492"))
			_text("THE END" if base_visual=="end" else "A minor magical incident",Vector2(745,227),21)

	func _draw_grimoire() -> void:
		# This is the book itself, not an animal speaking in its place. The
		# shared expressive cover/pages are the same character seen in battle.
		var point := actor_rect.position+actor_rect.size*0.5
		var radius := actor_rect.size.x*0.53
		for ring in range(2):
			draw_arc(point,radius+ring*11,0,TAU,72,Color(0.66,0.51,0.76,0.23-ring*0.06),1.4,true)
		for i in range(9):
			var a := ambient_time*0.16+float(i)/9.0*TAU
			var at := point+Vector2(cos(a),sin(a))*(radius+21)
			draw_circle(at,2.0,Color("d8c4e6"))
		_shadow(Vector2(point.x,actor_rect.end.y+32),radius*0.63,0.10)

	func _garden_gesture() -> void:
		# Moss's unruly vine turns his static animal drawing into the mistake
		# described by his line. It grows toward him, never across dialogue text.
		var origin := friend_portrait.get_transform()*(friend_portrait.size*Vector2(0.35,0.85))
		for i in range(15):
			var t := float(i)/14.0
			vine_points[i]=origin+Vector2(sin(t*8+ambient_time)*13,-t*friend_portrait.size.y*0.5)*minf(1.0,ambient_time/1.1+0.2)
		draw_polyline(vine_points,Color("789a72"),4,true)
		for i in range(3,vine_points.size(),4):
			draw_set_transform(vine_points[i],-0.7,Vector2(1,0.5))
			draw_circle(Vector2(7,0),8,Color("a6c394"))
			draw_set_transform(Vector2.ZERO)

	func draw_foreground(canvas: Control) -> void:
		var base := base_visual
		if sooty:
			StoryConsequences.draw_debris(canvas,exam_damage_age)
			StoryConsequences.draw_soot(canvas,hero,false,exam_damage_age)
			if actor_ids==PackedStringArray(["professor"]): StoryConsequences.draw_soot(canvas,friend_portrait,true,exam_damage_age)
		if base in ["fire","reverse","candle"] and not (exam_scene and (exam_damage_age>=0 or base=="reverse" and time>=1.6)):
			if base=="reverse" and location_index==7 and not exam_flashback:
				canvas.draw_texture_rect(SpellArt.part("smoke"),Rect2(actor_rect.end.x-24,actor_rect.position.y-10-minf(time,2.0)*8,130,108),false,Color(1,1,1,0.6))
			else:
				var at := StoryShot.flame_position(visual,time)
				var heading := StoryShot.flame_heading(visual,time)
				if base=="candle":
					at=Vector2(452,292)
					heading=-PI/2
					# In the finale this is the failed spark on the floor. The
					# epilogue's actual candle has wax and a wick, as in the notes.
					if location_index!=7:
						canvas.draw_style_box(report_style,Rect2(at+Vector2(-6,2),Vector2(12,30)))
				var flame_scale := 1.7 if base!="candle" else 0.85
				var flame_direction := Vector2.from_angle(heading) if base!="candle" else Vector2.ZERO
				if sequence_kind=="ending" and location_index==7 and base=="fire":
					at=Vector2(374,247).lerp(Vector2(452,292),clampf(time/2.1,0,1))
					heading=atan2(45,78)
					flame_scale=0.85
					flame_direction=Vector2.from_angle(heading) if time<2.1 else Vector2.ZERO
				if base=="reverse":
					for i in range(9): reverse_trail[i]=StoryShot.flame_position(visual,maxf(0,time-0.20+float(i)*0.025))
					canvas.draw_polyline(reverse_trail,Color(1,0.71,0.40,0.4),3.5,true)
					canvas.draw_polyline(reverse_trail,Color(1,0.94,0.69,0.7),1.5,true)
				# The examination and gameplay share the same living, rounded
				# flame. Ambient time keeps its surface moving across dialogue.
				ElementalFlightInk.draw(canvas,"fire",at,flame_direction,ambient_time,flame_scale)
				# The owl notices the wrong-way spell a beat before the cat does.
				if base=="reverse" and exam_scene:
					_draw_emote(canvas,Vector2(235,136),true)
		if base=="boom" or exam_scene and exam_damage_age>=0:
			var origin := _blast_origin()
			var effect_time := exam_damage_age if sooty else time
			var small_candle := sequence_kind=="ending" and location_index<0
			var scale_ := 0.4 if small_candle else 1.0
			var blast := StoryShot.explosion_strength("boom",effect_time)
			for i in range(9):
				var a := float(i)/9*TAU
				var point := origin+Vector2(cos(a),sin(a))*(43+effect_time*68)*scale_
				canvas.draw_circle(point,(22+effect_time*12)*scale_,Color(1,0.82,0.57,maxf(0,0.35-effect_time*0.22)))
			canvas.draw_texture_rect(SpellArt.part("smoke"),Rect2(origin+Vector2(-135,-157-minf(effect_time,1.6)*14)*scale_,Vector2(278,234)*scale_),false,Color(1,1,1,minf(1,effect_time*3+0.2)*clampf((1.85-effect_time)/0.75,0,1)))
			# Paper scraps and a soft expanding floor wave make the whole room
			# react, then settle; the target is deliberately the only safe thing.
			var wave := clampf(effect_time/1.15,0,1)
			canvas.draw_set_transform(origin+Vector2(100,80)*scale_,0,Vector2(1,0.32))
			canvas.draw_arc(Vector2.ZERO,(40+wave*740)*scale_,0,TAU,72,Color(0.94,0.72,0.52,(1-wave)*0.5),(9*(1-wave)+1)*scale_,true)
			canvas.draw_set_transform(Vector2.ZERO)
			var paper_alpha := 1.0-smoothstep(1.8,3.1,effect_time)
			for i in range(0 if small_candle else 13):
				if paper_alpha<=0: break
				var fall := clampf((effect_time-float(i%4)*0.12)/2.1,0,1)
				var paper_at := Vector2(65+i*84+sin(effect_time*2+i)*12,-20+fall*450)
				canvas.draw_set_transform(paper_at,sin(effect_time*2+i)*0.7)
				canvas.draw_rect(Rect2(-6,-4,12,8),Color(1,0.96,0.85,0.76*paper_alpha))
				canvas.draw_line(Vector2(-3,-1),Vector2(3,-1),Color(0.68,0.61,0.52,0.4*paper_alpha),0.7,true)
				canvas.draw_set_transform(Vector2.ZERO)
			var font := GameLocale.STORY_FONT
			if effect_time<1.0: canvas.draw_string(font,origin+Vector2(-28,-18),GameLocale.text("BOOM!"),HORIZONTAL_ALIGNMENT_LEFT,-1,22 if small_candle else 38,Color(Color("a8655c"),1.0-smoothstep(0.5,1.0,effect_time)))
			if blast>0: canvas.draw_rect(Rect2(Vector2.ZERO,size),Color(1,0.96,0.82,blast*(0.22 if small_candle else 0.65)))
		if base in ["pip","bloop","friends"]:
			_friend_magic(canvas)
		if not living_prop_kind.is_empty():
			_living_magic(canvas)
		if sooty and exam_damage_age>0.55 and exam_damage_age<2.0:
			var hat_tip := hero_rect.position+Vector2(hero_rect.size.x*0.69,24)
			canvas.draw_texture_rect(SpellArt.part("smoke"),Rect2(hat_tip+Vector2(-13,-34-minf(time,3)*4),Vector2(41,43)),false,Color(0.66,0.62,0.69,0.55))
			canvas.draw_circle(hat_tip+Vector2(0,6),4,Color(0.26,0.23,0.28,0.38))
		if exam_flashback:
			canvas.draw_style_box(report_style,Rect2(24,18,284,35))
			var font := GameLocale.STORY_FONT
			canvas.draw_string(font,Vector2(39,42),GameLocale.text("Earlier · Practical exam"),HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color("806348"))
		# A slim illustrated cinema edge keeps each shot intentional while the
		# background remains visible and all props stay inside the picture.
		canvas.draw_rect(Rect2(0,0,size.x,3),Color(0.75,0.65,0.53,0.30))
		canvas.draw_rect(Rect2(0,size.y-3,size.x,3),Color(0.75,0.65,0.53,0.30))

	func _blast_origin() -> Vector2:
		if exam_scene: return Vector2(104,249)
		if location_index==7: return Vector2(actor_rect.end.x+4,actor_rect.position.y+130)
		if sequence_kind=="ending": return Vector2(452,292)
		return Vector2(620,207)

	func _living_magic(canvas: Control) -> void:
		var cue_age := _living_visual_age()
		var amount := smoothstep(1.4,2.1,cue_age) if living_prop_kind=="book" else smoothstep(2.6,3.15,cue_age)
		if amount<=0: return
		for i in range(living_props.size()):
			var prop := living_props[i]
			var at := prop.get_transform()*(prop.size*0.5)
			if living_prop_kind=="book":
				var t := fmod(ambient_time*0.6,1.0)
				var page := at+Vector2(0,24+t*35)
				canvas.draw_set_transform(page,sin(ambient_time*3)*0.14)
				canvas.draw_rect(Rect2(-5,-3,10,6),Color(1,0.97,0.86,(1-t)*0.75*amount))
				canvas.draw_line(Vector2(-3,-1),Vector2(3,-1),Color(0.60,0.55,0.68,(1-t)*0.65*amount),1,true)
				canvas.draw_set_transform(Vector2.ZERO)
			else:
				for j in range(2):
					var t := fmod(ambient_time*0.40+j*0.5,1.0)
					var mote := at+Vector2(sin(ambient_time+j)*9,-22-t*28)
					canvas.draw_circle(mote,1.5+t,Color(0.75,0.64,0.84,(1-t)*0.58*amount))

	func _friend_magic(canvas: Control) -> void:
		var group := base_visual=="friends"
		if group or base_visual=="pip":
			# A finite little summon, then an ordinary chicken doing chicken
			# things. Dialogue changes never replay the poof or respawn the bird.
			if location_index==3:
				var summon := clampf((ambient_time-0.25)/1.05,0.0,1.0)
				var fade := sin(summon*PI)
				if fade>0:
					var at := HEN_FEET-Vector2(0,28)
					for i in range(5):
						var angle := float(i)/5.0*TAU
						canvas.draw_arc(at+Vector2.from_angle(angle)*(10+summon*28),8+summon*9,angle,angle+PI,14,Color(0.85,0.76,0.92,fade*0.65),2.0,true)
					for i in range(3):
						var feather := at+Vector2((i-1)*23,sin(summon*PI)*-30+summon*24)
						canvas.draw_set_transform(feather,summon*2.0+i)
						canvas.draw_arc(Vector2.ZERO,5,0.1,2.8,12,Color(1,0.98,0.91,fade*0.85),3,true)
						canvas.draw_set_transform(Vector2.ZERO)
		if group or base_visual=="bloop":
			if location_index==6:
				# The final rest is a warm drink, not another unstable potion.
				# Two quiet wisps rise from the same painted teapot across lines.
				if tea_sprite.visible:
					var source := TEA_RECT.position+Vector2(TEA_RECT.size.x*0.5,9)
					for i in range(2):
						var t := fmod(maxf(0.0,tea_age)*0.30+i*0.5,1.0)
						var at := source+Vector2(sin(t*5+i)*6,-t*29)
						canvas.draw_arc(at,5+t*3,-0.9,0.8,12,Color(1,0.96,0.86,(1-t)*0.50*tea_sprite.modulate.a),1.6,true)
				return
			if location_index==4:
				# The failed potion leaves a modest visible consequence; tea at
				# the final rest is deliberately not treated as another explosion.
				var spilled := smoothstep(0.7,1.8,ambient_time)
				var spill_at := Vector2(982,362) if group else Vector2(776,362)
				canvas.draw_set_transform(spill_at,0,Vector2(1,0.22))
				canvas.draw_circle(Vector2.ZERO,35*spilled,Color(0.76,0.59,0.80,0.28),true,-1,true)
				canvas.draw_set_transform(Vector2.ZERO)
			var point := Vector2(982,245) if group else Vector2(776,225)
			for i in range(4):
				var t := fmod(ambient_time*0.48+i*0.27,1.0)
				var at := point+Vector2(sin(t*5+i)*19,-t*66)
				var radius := 3+t*4
				canvas.draw_circle(at,radius,Color(0.91,0.65,0.85,(1-t)*0.34))
				canvas.draw_arc(at,radius,0,TAU,16,Color(0.78,0.51,0.77,(1-t)*0.72),1.2,true)
				canvas.draw_circle(at+Vector2(-radius*0.3,-radius*0.3),1.4,Color(1,1,1,(1-t)*0.8))

	func _draw_emote(canvas: Control, at: Vector2, surprised: bool) -> void:
		var amount := sin(clampf(time/0.25,0,1)*PI*0.5)
		if amount<=0: return
		canvas.draw_line(at+Vector2(0,-14)*amount,at+Vector2(0,-3),Color("ba7f79"),4,true)
		canvas.draw_circle(at+Vector2(0,5),2.4,Color("ba7f79"))
		if surprised:
			canvas.draw_line(at+Vector2(-12,-15),at+Vector2(-15,-23),Color("e5bc76"),2,true)
			canvas.draw_line(at+Vector2(11,-13),at+Vector2(16,-20),Color("e5bc76"),2,true)

	func snapshot() -> Dictionary:
		var result := StoryShot.snapshot(visual,time,location_index)
		result["exam_scene"]=exam_scene
		result["sooty"]=sooty
		result["exam_damage_age"]=exam_damage_age
		result["damage_amount"]=StoryConsequences.damage_amount(exam_damage_age) if sooty else 0.0
		if sooty: result["blast"]=StoryShot.explosion_strength("boom",exam_damage_age)
		result["professor_sooty"]=sooty and actor_ids==PackedStringArray(["professor"])
		result["target_facing"]="caster_left" if target_sprite.flip_h else "away"
		result["living_age"]=living_age
		result["living_phase"]=StoryConsequences.living_phase(_living_visual_age())
		result["living_cue"]=living_cue
		result["living_visual_age"]=_living_visual_age()
		result["living_kind"]=living_prop_kind
		result["actors"]=actor_ids
		result["grimoire_pose"]=grimoire_pose
		result["hero_feet"]=hero.position+hero.pivot_offset
		result["target_visible"]=target_sprite.visible
		result["flame_visible"]=base_visual in ["fire","reverse","candle"] and not (base_visual=="reverse" and location_index==7 and not exam_flashback) and not (exam_scene and (exam_damage_age>=0 or base_visual=="reverse" and time>=1.6))
		result["gameplay_objects"]=0
		result["rear_blast"]=_blast_origin()
		result["focus_actor"]=focus_actor
		result["ambient_time"]=ambient_time
		result["entrance_time"]=entrance_time
		result["scene_entries"]=scene_entries
		result["action_resets"]=action_resets
		result["backdrop_configurations"]=backdrop_configurations
		result["hero_alpha"]=hero.modulate.a
		result["actor_alpha"]=friend_portrait.modulate.a if friend_portrait.visible else 0.0
		result["allocated_actor_states"]=_actor_states.size()
		result["set_identity"]=StoryShot.set_identity(visual,location_index,sequence_kind)
		result["hen_visible"]=hen_sprite.visible
		result["hen_feet"]=hen_sprite.position+hen_sprite.pivot_offset
		result["hen_alpha"]=hen_sprite.modulate.a
		result["tea_visible"]=tea_sprite.visible
		result["tea_age"]=tea_age
		return result

	func _report(ending: bool) -> void:
		draw_style_box(report_style,Rect2(470,25,570,344))
		draw_texture_rect(EquipmentArt.icon("apprentice_thesis"),Rect2(492,43,42,42),false)
		_text("MEOWMALADE’S ACADEMIC RECORD",Vector2(783,65),20)
		var subjects := ["Elemental Magic","Teleportation","Summoning","Potion Making","Magical Control","World Saving" if ending else "Destruction"]
		var marks := ["D","F","F","C-","F","A+" if ending else "S+"]
		var font := GameLocale.STORY_FONT
		for i in range(subjects.size()):
			var y := 110+i*32
			draw_string(font,Vector2(509,y),GameLocale.text(subjects[i]),HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color("755a48"))
			draw_string(font,Vector2(932,y),marks[i],HORIZONTAL_ALIGNMENT_LEFT,-1,22,Color("9a6b86") if i==5 else Color("755a48"))
		if ending: _text("OVERALL: MEOWGNIFICENT",Vector2(755,343),19,Color("8e728e"))

class StoryForeground extends Control:
	var stage: Control
	func _draw() -> void:
		if is_instance_valid(stage): stage.draw_foreground(self)
