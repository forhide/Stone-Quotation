class_name ExpeditionRouteCompass
extends Control

# A small map in the existing purse header. The room remains the source of
# truth; this control never reveals an exit before the expedition opens it.
const PAPER := Color("f6f4e7")
const EDGE := Color("b9c9ad")
var arena := Rect2()
var player_point := Vector2.ZERO
var destination := Vector2.ZERO
var has_destination := false
var enemy_points := PackedVector2Array()
var view_rect := Rect2()
var world_state := ""
var _elapsed := 0.0

func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	custom_minimum_size=Vector2(128,54)
	size=custom_minimum_size

func sync_room(room: Node, delta: float, encounter: Dictionary={}) -> void:
	visible=str(room.state) in ["playing","paused","inventory","shop"]
	_elapsed+=delta
	var state_key := str(room.run.stage_index)+":"+str(room.exit_open)+":"+str(encounter.get("state",""))
	if _elapsed<0.075 and world_state==state_key: return
	_elapsed=0.0
	world_state=state_key
	arena=room.bounds
	player_point=room.player.position
	enemy_points.clear()
	for enemy in room.enemies:
		if is_instance_valid(enemy) and enemy.health.current>0: enemy_points.append(enemy.position)
	has_destination=false
	if room.has_method("navigation_target"):
		var target: Variant=room.navigation_target()
		if target is Vector2 and target.is_finite():
			destination=target
			has_destination=true
	elif str(encounter.get("state","")) in ["waiting","windup"]:
		destination=encounter.get("target",player_point)
		has_destination=true
	if is_instance_valid(room.camera):
		var extent: Vector2=room.get_viewport_rect().size/room.camera.zoom
		view_rect=Rect2(room.camera.get_screen_center_position()-extent*0.5,extent)
	tooltip_text=GameLocale.text("You · Guardians · Next seal / Passage")
	queue_redraw()

func map_rect() -> Rect2:
	if arena.size.x<=0 or arena.size.y<=0: return Rect2()
	var scale_factor := minf((size.x-12)/arena.size.x,(size.y-10)/arena.size.y)
	var extent := arena.size*scale_factor
	return Rect2((size-extent)*0.5,extent)

func project_point(point: Vector2) -> Vector2:
	var drawing := map_rect()
	if not drawing.has_area(): return size*0.5
	var fraction := (point-arena.position)/arena.size
	return drawing.position+fraction.clamp(Vector2.ZERO,Vector2.ONE)*drawing.size

func snapshot() -> Dictionary:
	return {"visible":visible,"bounds":arena,"map_rect":map_rect(),"player":project_point(player_point),"destination":project_point(destination),"has_destination":has_destination,"enemies":enemy_points.size(),"view":view_rect}

func _draw() -> void:
	var drawing := map_rect()
	if not drawing.has_area(): return
	draw_style_box(_paper(),Rect2(Vector2.ZERO,size))
	draw_rect(drawing,Color("e0e9d5"),true)
	var clipped := view_rect.intersection(arena)
	if clipped.has_area():
		var shown := Rect2(project_point(clipped.position),project_point(clipped.end)-project_point(clipped.position))
		draw_rect(shown,Color(1,0.99,0.91,0.48),true)
		draw_rect(shown,Color("c5bc9c"),false,1.0)
	for point in enemy_points:
		draw_circle(project_point(point),1.65,Color("bc8490"),true,-1,true)
	if has_destination:
		var at := project_point(destination)
		var diamond := PackedVector2Array([at+Vector2(0,-3.4),at+Vector2(3.4,0),at+Vector2(0,3.4),at+Vector2(-3.4,0)])
		draw_colored_polygon(diamond,Color("d4a85e"))
		draw_polyline(PackedVector2Array([diamond[0],diamond[1],diamond[2],diamond[3],diamond[0]]),Color("936e42"),1.0,true)
	var player_at := project_point(player_point)
	draw_circle(player_at,3.3,Color("fff9e7"),true,-1,true)
	draw_circle(player_at,2.1,Color("598f91"),true,-1,true)

static var _background: StyleBoxFlat
static func _paper() -> StyleBoxFlat:
	if _background==null:
		_background=StyleBoxFlat.new()
		_background.bg_color=PAPER
		_background.border_color=EDGE
		_background.set_border_width_all(1)
		_background.set_corner_radius_all(8)
	return _background
