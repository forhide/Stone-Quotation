class_name ShaderWarmup
extends Node2D
## Draw the effect materials behind the opening backdrop before gameplay.
## This moves their first rendering work to the start screen.

const SHADERS: Array[Shader] = [
	preload("res://scripts/effects/fireball.gdshader"),
	preload("res://scripts/effects/attack_telegraph.gdshader"),
	preload("res://scripts/effects/examiner_barrier.gdshader"),
	preload("res://scripts/effects/painted_alpha.gdshader"),
]
var _frames_left := 4

func _ready() -> void:
	z_index=-100
	position=Vector2(4,4)
	for shader in SHADERS:
		var probe := WarmupProbe.new()
		var warm := ShaderMaterial.new()
		warm.shader=shader
		probe.material=warm
		add_child(probe)

func _process(_delta: float) -> void:
	_frames_left-=1
	if _frames_left<=0: queue_free()

class WarmupProbe extends Node2D:
	func _draw() -> void:
		draw_texture_rect(SpellArt.FIREBALL,Rect2(0,0,2,2),false,Color(1,1,1,0.02))
