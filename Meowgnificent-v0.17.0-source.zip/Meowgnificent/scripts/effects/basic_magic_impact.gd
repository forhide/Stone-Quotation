class_name BasicMagicImpact
extends Node2D

# One brief material response at the actual collision point. Small reusable
# paths avoid particle nodes or per-frame texture/scene creation.
var element := "water"
var size := 1.0
var direction := Vector2.ZERO
var age := 0.0
var stroke := PackedVector2Array()
const DURATION := 0.34

func _ready() -> void:
 texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
 physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF

func _process(delta: float) -> void:
 # Cosmetic display-cadence motion; the projectile parent still pauses it.
 age+=delta
 if age>=DURATION:
  queue_free()
  return
 queue_redraw()

func _draw() -> void:
 var progress := clampf(age/DURATION,0,1)
 var expansion := 1.0-pow(1.0-progress,2.0)
 var ink := BasicMagic.color(element)
 ink.a=(1-progress)*0.8
 draw_set_transform(Vector2(0,-20),0,Vector2.ONE*size)
 match element:
  "water":
   draw_set_transform(Vector2(0,-20),0,Vector2(1,0.48)*size)
   draw_arc(Vector2.ZERO,8+expansion*28,0,TAU,20,ink,2.2,true)
   draw_set_transform(Vector2(0,-20),0,Vector2.ONE*size)
   for i in range(5):
    var ray := Vector2.from_angle(i*TAU/5-PI/2)
    var point := ray*(6+expansion*22)+Vector2.DOWN*progress*progress*9
    draw_circle(point,2.8*(1-progress)+0.5,ink,true,-1,true)
  "wind":
   for i in range(2):
    var phase := progress*TAU+i*PI
    draw_arc(Vector2.ZERO,6+expansion*(23-i*8),phase,phase+4.0,18,ink,2.0-i*0.5,true)
  "ice":
   for i in range(5):
    var ray := Vector2.from_angle(i*TAU/5+0.2)
    var across := ray.orthogonal()
    var point := ray*(7+expansion*18)
    var length := 4.5*(1-progress)+1
    draw_colored_polygon(PackedVector2Array([point+ray*length,point+across*1.8,point-ray*length,point-across*1.8]),ink)
  "leaf":
   # Three living stems unfurl from the struck point, then dissolve. This
   # reads as the end of the extending vine, never a burst of leaf ammo.
   for i in range(3):
    var ray := Vector2.from_angle(i*TAU/3+direction.angle()*0.3)
    var across := ray.orthogonal()
    stroke.resize(17)
    for j in range(17):
     var t := float(j)/16
     var turn := t*4.0
     stroke[j]=ray*sin(turn)*(5+expansion*14)+across*(1-cos(turn))*(2+expansion*7)
    draw_polyline(stroke,ink,2.8*(1-progress)+0.6,true)
   draw_circle(Vector2.ZERO,3.4*(1-progress),Color(0.95,0.97,0.78,(1-progress)*0.8),true,-1,true)
  "lightning":
   # Branching contact discharge is strongest immediately, then shortens and
   # fades instead of retaining a static star/snowflake silhouette.
   for i in range(4):
    var ray := Vector2.from_angle(i*TAU/4+direction.angle()+0.25)
    var across := ray.orthogonal()
    stroke.resize(6)
    for j in range(6):
     var t := float(j)/5
     stroke[j]=ray*t*(10+expansion*19)+across*sin(age*59+j*3.5+i)*3.5*sin(t*PI)
    draw_polyline(stroke,ink,2.8*(1-progress)+0.3,true)
    draw_polyline(stroke,Color(1.0,0.98,0.90,(1-progress)*0.8),1.1,true)
  "metal":
   for i in range(5):
    var ray := Vector2.from_angle(i*TAU/5+direction.angle()+0.2)
    var across := ray.orthogonal()
    var point := ray*(7+expansion*22)
    var length := 4.8*(1-progress)+0.6
    draw_colored_polygon(PackedVector2Array([point+ray*length,point+across*1.8,point-ray*length*0.6,point-across*1.8]),ink)
   draw_arc(Vector2.ZERO,4+expansion*12,0.2,5.9,16,Color(0.91,0.93,1.0,(1-progress)*0.5),1.3,true)
  _:
   for i in range(5):
    var point := Vector2.from_angle(i*TAU/5)*(7+expansion*21)
    draw_circle(point,2.5*(1-progress)+0.6,ink,true,-1,true)
 draw_set_transform(Vector2.ZERO)
