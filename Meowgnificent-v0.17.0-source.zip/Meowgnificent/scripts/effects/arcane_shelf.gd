class_name ArcaneShelf
extends Node2D

var room: Node2D
var state := "standing"
var timer := 0.0
var fall_direction := Vector2.DOWN
var burning := false
var collapsed := false
var body: Sprite2D
var flame: Sprite2D
var standing_texture: AtlasTexture
var fallen_texture: AtlasTexture
# Only the marked library/reading-room case hides a maintenance nook.
var reveal_cache := false
var revealed := false
var cache_claimed := false
var _cache_near := false
var _cache_prompt: Label

func _ready() -> void:
	var cache: SubViewport
	if room.has_meta("shelf_art_cache"):
		cache=room.get_meta("shelf_art_cache")
	else:
		cache=SubViewport.new()
		cache.size=Vector2i(1440,480)
		cache.transparent_bg=true
		cache.disable_3d=true
		cache.render_target_update_mode=SubViewport.UPDATE_ONCE
		var painter := ShelfArt.new()
		painter.scale=Vector2(3,3)
		cache.add_child(painter)
		room.add_child(cache)
		room.set_meta("shelf_art_cache",cache)
	standing_texture=AtlasTexture.new()
	standing_texture.atlas=cache.get_texture()
	# Crop transparent margins so detailed art does not add a large blended quad.
	standing_texture.region=Rect2(84,63,312,354)
	fallen_texture=AtlasTexture.new()
	fallen_texture.atlas=cache.get_texture()
	fallen_texture.region=Rect2(480,0,480,480)
	body=Sprite2D.new()
	body.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	standing_texture=EnchantedArt.part("shelf") as AtlasTexture
	fallen_texture=EnchantedArt.part("fallen_shelf") as AtlasTexture
	body.texture=standing_texture
	body.centered=true
	body.scale=Vector2(104,118)/standing_texture.region.size
	body.position=Vector2(0,-32)
	add_child(body)
	flame=Sprite2D.new()
	flame.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	var fire_texture := AtlasTexture.new()
	fire_texture.atlas=cache.get_texture()
	fire_texture.region=Rect2(1020,87,360,270)
	flame.texture=fire_texture
	flame.centered=true
	flame.scale=Vector2.ONE/3.0
	flame.position=Vector2(0,-38)
	flame.visible=false
	add_child(flame)
	# Local shaking follows the render clock; world motion still interpolates.
	body.physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	flame.physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF

	_cache_prompt=Label.new()
	_cache_prompt.position=Vector2(-135,-128)
	_cache_prompt.size=Vector2(270,28)
	_cache_prompt.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	_cache_prompt.add_theme_font_override("font",GameLocale.STORY_FONT)
	_cache_prompt.add_theme_font_size_override("font_size",15)
	_cache_prompt.add_theme_color_override("font_color",Color("775f70"))
	var prompt_style := StyleBoxFlat.new()
	prompt_style.bg_color=Color("fff3da")
	prompt_style.border_color=Color("b99d8b")
	prompt_style.set_border_width_all(1)
	prompt_style.set_corner_radius_all(6)
	_cache_prompt.add_theme_stylebox_override("normal",prompt_style)
	_cache_prompt.text=GameLocale.text("E · Inspect the nook")
	_cache_prompt.z_index=20
	_cache_prompt.mouse_filter=Control.MOUSE_FILTER_IGNORE
	_cache_prompt.hide()
	add_child(_cache_prompt)

func receive_magic(element: String, direction: Vector2, _outcome: String="success") -> void:
	if element=="fire":
		ignite(direction)
	else:
		# Water loosens the swollen case, ice tips its feet, wind/stone push it.
		# Every primary wand can use the accident route without pretending to burn.
		topple(direction)
		if state=="falling": room.tell("The control seal cracked. The case is tipping!",Color("a3c3c9"))

func receive_spell(element: String, direction: Vector2) -> void:
	receive_magic(element,direction)

func is_cache_near(point: Vector2) -> bool:
	return revealed and not cache_claimed and point.distance_to(position)<85

func scavenge_cache() -> bool:
	if not revealed or cache_claimed or room.state!="playing" or not is_cache_near(room.player.position): return false
	cache_claimed=true
	if is_instance_valid(_cache_prompt): _cache_prompt.hide()
	# A one-shot optional find, never a second mandatory exit or free stat swap.
	room.spawn_pickup("gold",position+Vector2(-18,24),12)
	room.spawn_pickup("food",position+Vector2(20,26),20)
	room.tell("A maintenance nook! Someone left Crowns and a snack.",Color("a9c9a8"))
	queue_redraw()
	return true

func cache_snapshot() -> Dictionary:
	return {"designated":reveal_cache,"revealed":revealed,"claimed":cache_claimed,"near":_cache_near}

func ignite(direction: Vector2) -> void:
	if state!="standing":
		return
	queue_redraw()
	state="burning"
	burning=true
	timer=1.15
	fall_direction=direction.normalized() if direction.length_squared()>0.01 else Vector2.DOWN
	room.tell("The books are on fire. Mind the falling shelf!",Color("b8665e"))

func topple(direction: Vector2) -> void:
	if state=="fallen" or state=="falling":
		return
	queue_redraw()
	state="falling"
	timer=0.35
	fall_direction=direction.normalized() if direction.length_squared()>0.01 else Vector2.DOWN
	room.tell("Not a spell. Still effective.",Color("79616b"))

func footprint(point: Vector2) -> bool:
	var offset := point-position
	return offset.dot(fall_direction)>-25 and offset.dot(fall_direction)<145 and absf(offset.cross(fall_direction))<48

func collapse() -> void:
	if collapsed: return
	collapsed=true
	state="fallen"
	revealed=reveal_cache
	if is_instance_valid(body):
		body.texture=fallen_texture
		body.scale=Vector2(146,103)/fallen_texture.region.size
		# Flat debris belongs below floor flames and the living actors.
		body.z_index=-1
		body.centered=true
		body.position=fall_direction*57
		body.rotation=fall_direction.angle()-PI*0.5
		flame.hide()
	room.shake=8
	for enemy in room.enemies.duplicate():
		if is_instance_valid(enemy) and footprint(enemy.position):
			enemy.take_damage(48,fall_direction)
	if footprint(room.player.position) and not room.exit_open:
		room.player.take_damage(18,position)
	room.effects.append({"point":position+fall_direction*65,"age":0.0,"radius":80.0,"color":Color("d9b6aa")})
	if burning:
		room.ignite_floor(position+fall_direction*65)
	if revealed:
		room.tell("Behind the case: a maintenance nook. Walk over and press E.",Color("a9c9a8"))
	else:
		room.tell("A scholarly approach to flattening enemies.",Color("79616b"))
	queue_redraw()

func _process(delta: float) -> void:
	if room.state!="playing": return
	var near := is_cache_near(room.player.position)
	if near!=_cache_near:
		_cache_near=near
		queue_redraw()
	if is_instance_valid(_cache_prompt):
		_cache_prompt.visible=near
		_cache_prompt.text=GameLocale.text("E · Inspect the nook")
	if state!="burning" and state!="falling": return
	var tilt := sin(timer*23)*0.035 if state=="burning" else (1-timer/0.35)*0.7
	body.rotation=tilt
	body.position=Vector2(0,-32).rotated(tilt)
	# One shared flame texture adds detail without ten per-frame circles per shelf.
	flame.visible=burning
	flame.scale=Vector2(1.0+sin(timer*9)*0.05,1.0+cos(timer*13)*0.07)/3.0
	flame.rotation=tilt
	flame.position=Vector2(0,-38).rotated(tilt)
	if state=="burning" or state=="falling":
		timer-=delta
		if timer<=0:
			if state=="burning":
				state="falling"
				timer=0.35
			else: collapse()
	queue_redraw()

func _draw() -> void:
	if revealed: _draw_maintenance_nook()
	if state=="burning" or state=="falling":
		var side := fall_direction.orthogonal()*45
		draw_colored_polygon(PackedVector2Array([side,-side,fall_direction*145-side,fall_direction*145+side]),Color(1,0.52,0.24,0.20))
		draw_line(Vector2.ZERO,fall_direction*145,Color("b8665e"),2,true)

func _draw_maintenance_nook() -> void:
	EnchantedArt.stamp(self,"hatch",Vector2.ZERO,Vector2(87,64))
	if not cache_claimed: EnchantedArt.stamp(self,"chest",Vector2(0,-4),Vector2(33,31))
