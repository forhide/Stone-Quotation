class_name EnemyDissolve
extends Node2D

# Combat and drops finish immediately. Only the old painted silhouette remains
# for a brief, gentle dispersal, without delaying the passage or a new target.
const DURATION := 0.36
const MAX_ACTIVE := 8
var age := 0.0
var target: WizardCat
var parts: Array[Dictionary] = []
var drift := Vector2.ZERO

static func leave(enemy: CandleSlime) -> EnemyDissolve:
	var parent := enemy.get_parent()
	if parent==null or not enemy.is_inside_tree(): return null
	var count := 0
	for child in parent.get_children():
		if child is EnemyDissolve and not child.is_queued_for_deletion(): count+=1
	if count>=MAX_ACTIVE: return null
	var echo := EnemyDissolve.new()
	echo.transform=enemy.transform
	echo.modulate=enemy.modulate
	echo.target=enemy.target
	echo.drift=enemy.knockback.normalized()*5.0
	for actor in [enemy.body_root]+enemy.wing_roots:
		if actor==null: continue
		for child in actor.get_children():
			if child is Sprite2D and child.visible and child.texture!=null:
				echo.parts.append({"texture":child.texture,"transform":enemy.global_transform.affine_inverse()*child.global_transform})
	if echo.parts.is_empty():
		echo.free()
		return null
	parent.add_child(echo)
	echo.reset_physics_interpolation()
	return echo

func _ready() -> void:
	physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS

func _process(delta: float) -> void:
	# Actor roots remain enabled behind inventory; follow the actual play gate.
	if is_instance_valid(target) and not target.active: return
	age+=delta
	if age>=DURATION:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	var t := clampf(age/DURATION,0.0,1.0)
	var fade := 1.0-smoothstep(0.12,1.0,t)
	var settle := Transform2D(0.0,Vector2(1.0-0.08*t,1.0-0.11*t),0.0,drift*t+Vector2(0,2*t))
	for part in parts:
		draw_set_transform_matrix(settle*part.transform)
		draw_texture(part.texture,Vector2.ZERO,Color(1.03,1.02,1.0,fade))
	draw_set_transform(Vector2.ZERO)
	# A few tiny motes communicate a released enchantment, not an explosion.
	var ink := Color("c3e1cb")
	ink.a=sin(t*PI)*0.8
	for i in range(3):
		var at := Vector2((i-1)*12,-23-i%2*8)+Vector2((i-1)*9,-19)*t
		draw_circle(at,1.8*(1.0-t*0.4),ink,true,-1,true)
