class_name ElementalFlightInk
extends RefCounted

# The spell is a moving substance, not an arrow with a different colour.
# Core motion belongs to the element; only its short wake follows velocity.
# Reused small paths keep drawing bounded without particle nodes or textures.
const CREAM := Color("fff9e8")
static var _ring: PackedVector2Array = _unit_ring(24)
static var _blob := PackedVector2Array()
static var _curl := PackedVector2Array()
static var _bolt := PackedVector2Array()
static var _fire_points := PackedVector2Array()
static var _fire_colors := PackedColorArray()
static var _fire_indices := PackedInt32Array()
static var _fire_wake_points := PackedVector2Array()
static var _fire_wake_colors := PackedColorArray()
static var _fire_wake_indices := PackedInt32Array()
static var ROCK := PackedVector2Array([Vector2(-12,-3),Vector2(-8,-10),Vector2(2,-11),Vector2(11,-5),Vector2(13,3),Vector2(6,10),Vector2(-5,11),Vector2(-12,4),Vector2(-12,-3)])
static var CRYSTAL := PackedVector2Array([Vector2(0,-13),Vector2(10,-6),Vector2(11,6),Vector2(0,13),Vector2(-10,6),Vector2(-11,-5),Vector2(0,-13)])
static var _stem := PackedVector2Array()
static var _vein := PackedVector2Array()

static func _unit_ring(count: int) -> PackedVector2Array:
 var points := PackedVector2Array()
 for i in range(count): points.append(Vector2.from_angle(float(i)/count*TAU))
 points.append(points[0])
 return points

static func draw(c: CanvasItem,element: String,center: Vector2,direction: Vector2,age: float,size: float=1.0,outcome: String="success",growth_path: PackedVector2Array=PackedVector2Array()) -> void:
 c.draw_set_transform(center,0,Vector2.ONE*size)
 var forward := direction.normalized()
 var unstable := 1.45 if outcome=="miscast" else 1.15 if outcome=="overreaction" else 1.0
 match element:
  "water": _water(c,center,forward,age,size,unstable)
  "ice": _ice(c,center,forward,age,size)
  "wind": _wind(c,forward,age)
  "stone": _stone(c,center,forward,age,size)
  # Preserve the saved ID; living magic grows instead of throwing leaves.
  "leaf": _wood(c,forward,age,unstable,growth_path)
  "lightning": _lightning(c,forward,age,unstable)
  "metal": _metal(c,center,forward,age,size)
  _: _fire(c,forward,age,unstable)
 c.draw_set_transform(Vector2.ZERO)

static func _body(c: CanvasItem,at: Vector2,radius: float,age: float,colour: Color,edge: Color,amount: float=0.06,stretch: Vector2=Vector2.ONE) -> void:
 _blob.resize(_ring.size())
 for i in range(_ring.size()):
  var angle := float(i)/float(_ring.size()-1)*TAU
  var ripple := 1.0+sin(angle*3.0+age*5.0)*amount+sin(angle*5.0-age*3.8)*amount*0.55
  _blob[i]=at+_ring[i]*radius*ripple*stretch
 # Close exactly: sin(TAU) rounding can otherwise form a microscopic edge.
 _blob[_blob.size()-1]=_blob[0]
 c.draw_colored_polygon(_blob,colour)
 if edge.a>0: c.draw_polyline(_blob,edge,1.35,true)

static func _wake(c: CanvasItem,forward: Vector2,age: float,colour: Color,phase: float=0.0,extent: float=27.0) -> void:
 if forward.is_zero_approx(): return
 var across := forward.orthogonal()
 _curl.resize(9)
 for i in range(9):
  var t := float(i)/8
  _curl[i]=-forward*(8+t*extent)+across*(sin(t*4.5-age*7+phase)*3.5*t)
 c.draw_polyline(_curl,colour,1.6,true)

static func _prepare_fire_batches() -> void:
 # One shared index layout. RenderingServer copies command data, so subsequent
 # spells can safely reuse these bounded buffers without mesh/particle nodes.
 _fire_points.resize(121)
 _fire_colors.resize(121)
 _fire_colors[0]=Color("fff2c2")
 var colors := [Color("fff2c2"),Color("ffd27a"),Color("ffad60"),Color(0.94,0.64,0.30,0.35),Color(1,0.76,0.40,0)]
 for ring in range(5):
  for i in range(24): _fire_colors[1+ring*24+i]=colors[ring]
 for i in range(24):
  var next := (i+1)%24
  _fire_indices.append_array(PackedInt32Array([0,1+i,1+next]))
  for ring in range(4):
   var inner := 1+ring*24
   var outer := inner+24
   _fire_indices.append_array(PackedInt32Array([inner+i,outer+i,inner+next,inner+next,outer+i,outer+next]))
 # Three9-point ribbons plus two small6-sided fading embers form one batch.
 _fire_wake_points.resize(68)
 _fire_wake_colors.resize(68)
 for ribbon in range(3):
  for i in range(8):
   var at := ribbon*18+i*2
   _fire_wake_indices.append_array(PackedInt32Array([at,at+1,at+2,at+2,at+1,at+3]))
 for ember in range(2):
  var at := 54+ember*7
  for i in range(6): _fire_wake_indices.append_array(PackedInt32Array([at,at+1+i,at+1+(i+1)%6]))

static func _fire(c: CanvasItem,forward: Vector2,age: float,unstable: float) -> void:
 if _fire_indices.is_empty(): _prepare_fire_batches()
 var gold := Color("ffd27a")
 var pulse := 1.0+sin(age*10)*0.027*unstable
 # Buoyancy bends the wake upward even while it is carried behind the orb.
 var drift := (-forward+Vector2.UP*0.65).normalized() if not forward.is_zero_approx() else Vector2.UP
 var across := drift.orthogonal()
 # Their tips still curl and fade independently, but all flames/embers are
 # submitted together instead of triangulating five separate polygons.
 for i in range(3):
  var rise := fmod(age*(2.0+i*0.17)+i/3.0,1.0)
  var start := across*(i-1)*4.3+drift*6
  var length := 8+rise*10
  var curl := sin(age*7+i*2.1)*3.5*unstable
  for j in range(9):
   var u := float(j)/8
   var at := start+drift*(u*length)+across*(sin(u*2.6+age*5+i*2)*3.5*u+curl*u*u)
   var side := across*(0.12+(1-u)*(2.6-rise*0.7))
   var index := i*18+j*2
   _fire_wake_points[index]=at+side
   _fire_wake_points[index+1]=at-side
   var color := Color(gold,(1-rise)*0.65*(1-u*0.45))
   _fire_wake_colors[index]=color
   _fire_wake_colors[index+1]=color
 for i in range(2):
  var t := fmod(age*(2.6+i*0.4)+i*0.46,1.0)
  var at := drift*(14+t*16)+across*sin(age*8+i*2.3)*3.5
  var index := 54+i*7
  var radius := 2.0-t*1.5
  _fire_wake_points[index]=at
  _fire_wake_colors[index]=Color(gold,(1-t)*0.65)
  for j in range(6):
   _fire_wake_points[index+1+j]=at+_ring[j*4]*radius
   _fire_wake_colors[index+1+j]=Color(gold,0)
 RenderingServer.canvas_item_add_triangle_array(c.get_canvas_item(),_fire_wake_indices,_fire_wake_points,_fire_wake_colors)
 # A calm round cream centre, molten gold middle and warm rim share a radial
 # colour mesh. The outer ring supplies its soft glow in this same draw call.
 _fire_points[0]=Vector2(-0.5,1)
 var hot_age := age*unstable
 for i in range(24):
  var angle := float(i)/24*TAU
  var outer_ripple := 1.0+sin(angle*3+hot_age*5)*0.026+sin(angle*5-hot_age*3.8)*0.0143
  var middle_ripple := 1.0+sin(angle*3-age*6)*0.025+sin(angle*5+age*4.56)*0.01375
  _fire_points[1+i]=Vector2(-0.5,1)+_ring[i]*(5.2*pulse)
  _fire_points[25+i]=Vector2(0,0.5)+_ring[i]*(8.9*pulse*middle_ripple)
  _fire_points[49+i]=_ring[i]*(11.9*pulse*outer_ripple)
  _fire_points[73+i]=_ring[i]*(12.5*pulse*outer_ripple)
  _fire_points[97+i]=_ring[i]*(16*pulse)
 RenderingServer.canvas_item_add_triangle_array(c.get_canvas_item(),_fire_indices,_fire_points,_fire_colors)

static func _water(c: CanvasItem,_center: Vector2,forward: Vector2,age: float,_size: float,unstable: float) -> void:
 var ink := BasicMagic.color("water")
 _wake(c,forward,age,Color(ink,0.30),0,22)
 # Volume sloshes sideways while a surface swirl rolls through the orb.
 var stretch := Vector2(1.0+sin(age*9)*0.065,1.0-sin(age*9)*0.065)
 _body(c,Vector2.ZERO,11.8,age*unstable,Color(ink,0.82),Color("64a7c3"),0.065,stretch)
 c.draw_arc(Vector2(-0.7,1.3),7.1,age*2.5,age*2.5+4.7,18,Color("c9f0f5"),1.7,true)
 c.draw_arc(Vector2(-3,-3),3.9,3.4,5.2,8,CREAM,2.0,true)
 if not forward.is_zero_approx():
  var across := forward.orthogonal()
  for i in range(3):
   var t := fmod(age*2.2+i*0.32,1.0)
   var at := -forward*(12+t*19)+across*(sin(age*8+i*2.8)*5)
   c.draw_circle(at,2.7-t*1.7,Color(ink,(1-t)*0.8),true,-1,true)

static func _ice(c: CanvasItem,center: Vector2,forward: Vector2,age: float,size: float) -> void:
 var ink := BasicMagic.color("ice")
 _wake(c,forward,age,Color(ink,0.28),1.8,20)
 # The crystal tumbles in its own rhythm, rather than acting as an arrowhead.
 var angle := age*1.75+0.25
 c.draw_set_transform(center,angle,Vector2.ONE*size)
 c.draw_colored_polygon(CRYSTAL,ink)
 c.draw_polyline(CRYSTAL,Color("73b1ce"),1.4,true)
 c.draw_colored_polygon(PackedVector2Array([Vector2(0,-13),Vector2(0,1),Vector2(10,-6)]),Color("e6f9fc"))
 c.draw_line(Vector2(0,-11),Vector2(0,10),Color("f8ffff"),1.1,true)
 c.draw_line(Vector2(-9,-4),Vector2(0,1),Color("c8eef6"),1.0,true)
 c.draw_set_transform(center,0,Vector2.ONE*size)
 for i in range(2):
  var point := Vector2.from_angle(age*(1.9+i*0.3)+i*PI)*18
  var fade := 0.45+sin(age*8+i*2)*0.25
  c.draw_line(point-Vector2(2.2,0),point+Vector2(2.2,0),Color(CREAM,fade),1.2,true)
  c.draw_line(point-Vector2(0,2.2),point+Vector2(0,2.2),Color(CREAM,fade),1.2,true)

static func _wind(c: CanvasItem,forward: Vector2,age: float) -> void:
 var ink := Color("80baa8")
 _wake(c,forward,age,Color(ink,0.28),1.4,25)
 # Open, breathing curls leave the centre airy instead of forming a pellet.
 for i in range(2):
  var phase := age*(3.6 if i==0 else -4.4)+i*2.1
  var r := (11.3 if i==0 else 6.3)+sin(age*6+i)*1.1
  c.draw_arc(Vector2(0.8,0),r,phase,phase+4.65,22,Color(ink,0.58 if i==0 else 0.84),3.0 if i==0 else 2.1,true)
  c.draw_arc(Vector2(0.8,-0.7),r,phase+0.2,phase+3.2,17,Color("e1f6e7"),1.15,true)
 var mote := Vector2.from_angle(age*5)*15
 c.draw_circle(mote,1.5,Color("b4ddbd"),true,-1,true)

static func _stone(c: CanvasItem,center: Vector2,forward: Vector2,age: float,size: float) -> void:
 var ink := BasicMagic.color("stone")
 if not forward.is_zero_approx():
  for i in range(2):
   var t := fmod(age*2.4+i*0.5,1.0)
   var at := -forward*(13+t*15)+forward.orthogonal()*sin(age*9+i*3)*3
   c.draw_circle(at,1.9-t,Color(ink,(1-t)*0.55),true,-1,true)
 c.draw_set_transform(center,age*4.0+0.4,Vector2.ONE*size*Vector2(1,0.94+sin(age*5)*0.04))
 c.draw_colored_polygon(ROCK,ink)
 c.draw_polyline(ROCK,Color("9c8e84"),1.5,true)
 c.draw_colored_polygon(PackedVector2Array([Vector2(-8,-7),Vector2(1,-9),Vector2(8,-4),Vector2(-3,-1)]),Color("e7dccb"))
 c.draw_line(Vector2(2,6),Vector2(7,3),Color("ad9c8b"),1.5,true)

static func _wood(c: CanvasItem,forward: Vector2,age: float,unstable: float,growth_path: PackedVector2Array) -> void:
 var ink := BasicMagic.color("leaf")
 var growth := clampf(age*8.0,0,1)
 if forward.is_zero_approx():
  # Between the paws, living light winds itself into a spring before release.
  # Open strands never become detached leaves or a solid green pellet.
  for strand in range(2):
   _stem.resize(19)
   for i in range(19):
    var t := float(i)/18
    var angle := t*TAU*1.05+age*2.4+strand*PI
    _stem[i]=Vector2.from_angle(angle)*(2.0+t*9.0)
   c.draw_polyline(_stem,Color(ink,0.82),2.8,true)
  c.draw_circle(Vector2.ZERO,3.0+sin(age*7)*0.3,Color("f2f4c8"),true,-1,true)
  return
 var across := forward.orthogonal()
 var length := clampf(age*500.0,1.0,76.0)
 _stem.resize(23)
 _vein.resize(23)
 for i in range(23):
  var t := float(i)/22
  var sway := sin(t*5.5-age*6.5)*sin(t*PI)*5.0*unstable
  var spine := -forward*(length*(1-t))
  if growth_path.size()>1:
   # Retain the actual curved route of the growing tip. Seeking no longer
   # rotates the whole stem as if it were one rigid projectile sprite.
   var sample := t*float(growth_path.size()-1)
   var index := mini(floori(sample),growth_path.size()-2)
   spine=growth_path[index].lerp(growth_path[index+1],sample-index)
  _stem[i]=spine+across*sway
  _vein[i]=_stem[i]+across*sin(t*11.0-age*8)*2.3*sin(t*PI)
 # A pale inner vein and entwining strand make the extending magic read as a
 # flexible stem. Its leading growing end is the real collision position.
 c.draw_polyline(_stem,Color("789c74"),5.2,true)
 c.draw_polyline(_stem,Color(ink,0.94),3.7,true)
 c.draw_polyline(_vein,Color("eff1bd"),1.4,true)
 for branch in range(2):
  var at := _stem[8+branch*7]
  var side := -1.0 if branch==0 else 1.0
  _curl.resize(12)
  for i in range(12):
   var t := float(i)/11
   var reach := (5.0+branch*1.5)*growth
   _curl[i]=at+across*side*sin(t*2.7)*reach+forward*(t*6.5-sin(t*PI)*2.0)*growth
  c.draw_polyline(_curl,Color(ink,0.78),2.4,true)
 # A bright growing tip curls open rather than pointing like an arrowhead.
 _curl.resize(15)
 for i in range(15):
  var t := float(i)/14
  var angle := t*PI*1.65
  _curl[i]=forward*sin(angle)*(5.8*(1-t*0.55))+across*(1-cos(angle))*3.0
 c.draw_polyline(_curl,Color("ddebaf"),3.0,true)
 c.draw_circle(Vector2.ZERO,3.2+sin(age*8)*0.25,Color("f2f4c8"),true,-1,true)
 var mote := -forward*(length*0.48)+across*(9+sin(age*5)*2)
 c.draw_circle(mote,1.5,Color(ink,0.46),true,-1,true)

static func _lightning(c: CanvasItem,forward: Vector2,age: float,unstable: float) -> void:
 var pulse := 0.79+sin(age*31)*0.10
 if forward.is_zero_approx():
  # Charge leaps between three points at the paw, then opens into a directed
  # discharge in flight. There is deliberately no circular electric orb.
  for branch in range(3):
   var ray := Vector2.from_angle(branch*TAU/3+age*0.7)
   _bolt.resize(5)
   for i in range(5):
    var t := float(i)/4
    _bolt[i]=ray*(3+t*10)+ray.orthogonal()*sin(age*37+i*3+branch)*2.2*t
   c.draw_polyline(_bolt,Color("dfbf79"),3.2,true)
   c.draw_polyline(_bolt,Color(CREAM,pulse),1.4,true)
  return
 var across := forward.orthogonal()
 var length := lerpf(18.0,61.0,clampf(age*13,0,1))
 _bolt.resize(10)
 for i in range(10):
  var t := float(i)/9
  var kink := (sin(age*39+i*8.7)*4.4+sin(age*23+i*3.2)*2.1)*sin(t*PI)*unstable
  _bolt[i]=-forward*(length*(1-t))+across*kink
 # A soft edge, bright filament and two erratic forks form a travelling flash.
 # Everything extends behind the collision point, never ahead of the foe.
 c.draw_polyline(_bolt,Color(0.91,0.76,0.45,0.25),6.0,true)
 c.draw_polyline(_bolt,Color("dfbf79"),3.3,true)
 c.draw_polyline(_bolt,Color(CREAM,pulse),1.6,true)
 for branch in range(2):
  var at := _bolt[3+branch*3]
  var side := -1.0 if branch==0 else 1.0
  _curl.resize(5)
  for i in range(5):
   var t := float(i)/4
   _curl[i]=at-forward*t*9+across*(side*t*(9+sin(age*19+branch)*2)+sin(age*41+i*4)*1.8*sin(t*PI))
  c.draw_polyline(_curl,Color("dfbf79"),2.6,true)
  c.draw_polyline(_curl,Color(CREAM,0.75),1.05,true)
 c.draw_circle(Vector2.ZERO,2.1,CREAM,true,-1,true)

static func _metal(c: CanvasItem,center: Vector2,forward: Vector2,age: float,size: float) -> void:
 # Metal condenses into actual sharp slivers, distinct from fluids and stems.
 var angle := forward.angle() if not forward.is_zero_approx() else -PI/2+sin(age*4)*0.12
 c.draw_set_transform(center,angle,Vector2.ONE*size)
 var growth := 0.72+0.28*clampf(age*12,0,1)
 for i in range(3):
  var offset := Vector2(-i*5.0,(i-1)*4.4)
  var length := (14.0-i*2.0)*growth
  var shimmer := sin(age*8+i*1.9)*0.35
  var shard := PackedVector2Array([offset+Vector2(length,0),offset+Vector2(-length*0.55,-2.4),offset+Vector2(-length*0.78,0),offset+Vector2(-length*0.55,2.4)])
  c.draw_colored_polygon(shard,Color("aeb8d0") if i!=1 else Color("c4cce2"))
  c.draw_line(offset+Vector2(-length*0.55,-0.4),offset+Vector2(length-1,shimmer),Color("f4f5fd"),1.4,true)
 c.draw_set_transform(center,0,Vector2.ONE*size)
 if not forward.is_zero_approx():
  _wake(c,forward,age,Color(0.72,0.76,0.89,0.28),0.4,17)
