extends Node

# Small original PCM cues, imported once. Playback never creates nodes, builds
# waveforms or starts music at launch; only explicit game actions call play_cue.
signal changed
const LEVELS := [0.0,0.4,0.7]
const MAX_VOICES := 8
const STREAMS := {
 "cast_fire":preload("res://art/audio/cast_fire.wav"),
 "cast_water":preload("res://art/audio/cast_water.wav"),
 "cast_ice":preload("res://art/audio/cast_ice.wav"),
 "cast_wind":preload("res://art/audio/cast_wind.wav"),
 "cast_stone":preload("res://art/audio/cast_stone.wav"),
 "cast_leaf":preload("res://art/audio/cast_leaf.wav"),
 "cast_lightning":preload("res://art/audio/cast_lightning.wav"),
 "cast_metal":preload("res://art/audio/cast_metal.wav"),
 "miscast":preload("res://art/audio/miscast.wav"),
 "skill":preload("res://art/audio/skill.wav"),
 "hit":preload("res://art/audio/hit.wav"),
 "hurt":preload("res://art/audio/hurt.wav"),
 "pickup":preload("res://art/audio/pickup.wav"),
 "gear":preload("res://art/audio/gear.wav"),
 "equip":preload("res://art/audio/equip.wav"),
 "clear":preload("res://art/audio/clear.wav")
}
const INTERVALS := {"hit":70,"pickup":100,"gear":120,"hurt":150,"clear":300}
var volume := 0.4
var save_error := false
var config_path := ""
var voices: Array[AudioStreamPlayer] = []
var last_played: Dictionary = {}

func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 load_settings(settings_path())
 for i in range(MAX_VOICES):
  var voice := AudioStreamPlayer.new()
  voice.name="Voice%d" % i
  voice.volume_db=linear_to_db(maxf(volume,0.0001))
  add_child(voice)
  voices.append(voice)

func settings_path() -> String:
 if not config_path.is_empty(): return config_path
 var language := get_tree().root.get_node_or_null("Language")
 if language!=null: return str(language.settings_path)
 return OS.get_environment("MEOW_SETTINGS_PATH") if OS.has_environment("MEOW_SETTINGS_PATH") else "user://settings-v1.cfg"

func load_settings(path: String) -> void:
 volume=0.4
 var config := ConfigFile.new()
 if config.load(path)!=OK: return
 var saved: Variant=config.get_value("audio","effects_volume",0.4)
 if (saved is int or saved is float) and float(saved) in LEVELS: volume=float(saved)

func set_volume(value: float) -> bool:
 if value not in LEVELS: return false
 volume=value
 for voice in voices:
  voice.volume_db=linear_to_db(maxf(volume,0.0001))
  if volume<=0: voice.stop()
 var config := ConfigFile.new()
 config.load(settings_path())
 config.set_value("audio","effects_volume",volume)
 save_error=config.save(settings_path())!=OK
 changed.emit()
 return not save_error

func play_cue(id: String, pitch: float=1.0) -> bool:
 if volume<=0 or not STREAMS.has(id): return false
 var now := Time.get_ticks_msec()
 if now-int(last_played.get(id,-10000))<int(INTERVALS.get(id,65)): return false
 for voice in voices:
  if voice.playing: continue
  voice.stream=STREAMS[id]
  voice.pitch_scale=clampf(pitch,0.8,1.2) if is_finite(pitch) else 1.0
  voice.volume_db=linear_to_db(volume)
  voice.play()
  last_played[id]=now
  return true
 # Do not interrupt an audible voice mid-wave or grow the pool in a mob fight.
 return false

func _exit_tree() -> void:
 stop_all()
 # Let the audio mixer consume queued stop commands before engine teardown.
 # This is shutdown-only; it never blocks a frame during gameplay.
 if not OS.has_feature("web"): OS.delay_msec(200)

func stop_all() -> void:
 for voice in voices:
  voice.stop()
  voice.stream=null
 last_played.clear()
