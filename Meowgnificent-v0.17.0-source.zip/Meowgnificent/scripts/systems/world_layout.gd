class_name WorldLayout
extends RefCounted

# Narrative plates and their authored landmarks keep one canonical canvas.
# The live expedition occupies a larger world; only the cached ground and
# landmark positions expand. Actors retain a smaller, readable silhouette.
const SCALE := 1.6
const ACTOR_SCALE := 0.8
const CANONICAL_CANVAS := Rect2(0,0,1280,800)
const CANONICAL_FLOOR := Rect2(100,160,1080,535)
const VIEW_SIZE := Vector2(1280,800)
const CANVAS := Rect2(0,0,2048,1280)
const ENTRY := Vector2(220,435)
const FIRST_ENTRY := Vector2(300,435)

static func point(canonical_point: Vector2) -> Vector2:
	return canonical_point*SCALE

static func canonical(world_point: Vector2) -> Vector2:
	return world_point/SCALE

static func rect(canonical_rect: Rect2) -> Rect2:
	return Rect2(point(canonical_rect.position),canonical_rect.size*SCALE)

static func world_bounds() -> Rect2:
	return rect(CANONICAL_FLOOR)

static func camera_center(focus: Vector2, view_size: Vector2=VIEW_SIZE) -> Vector2:
	# Leave a little more floor above the cat for ranged aiming. Clamping the
	# camera, not its target actor, keeps the painted borders on screen.
	var half := view_size*0.5
	var low := CANVAS.position+half
	var high := CANVAS.end-half
	for axis in range(2):
		if high[axis]<low[axis]:
			low[axis]=CANVAS.get_center()[axis]
			high[axis]=low[axis]
	return (focus-Vector2(0,30)).clamp(low,high)

static func cache_pixels(window_pixels: Vector2i) -> Vector2i:
	# Paint once at enough texels for the enlarged world and physical window.
	# The original3840px plates bound useful detail and allocation at3x.
	var window_density := minf(float(window_pixels.x)/VIEW_SIZE.x,float(window_pixels.y)/VIEW_SIZE.y)
	var density := clampf(window_density*SCALE,SCALE,3.0)
	return Vector2i(roundi(VIEW_SIZE.x*density),roundi(VIEW_SIZE.y*density))

static func cache_scale(pixels: Vector2i) -> Vector2:
	return CANVAS.size/Vector2(pixels)
