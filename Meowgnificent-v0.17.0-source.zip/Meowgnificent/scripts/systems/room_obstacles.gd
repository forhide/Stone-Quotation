class_name RoomObstacles
extends Node

# Shared floor footprints. Sweeping the complete motion prevents a fast roll,
# dash or low frame-rate update from skipping through a cupboard or table.
const SHELF_FOOTPRINT := Rect2(-47,-17,94,42)
const TABLE_FOOTPRINT := Rect2(490,402,300,110)
var entries: Array[Dictionary] = []

func configure(shop: bool) -> void:
	entries.clear()
	if shop: entries.append({"rect":WorldLayout.rect(TABLE_FOOTPRINT),"kind":"table"})

func add_shelf(shelf: ArcaneShelf) -> void:
	entries.append({"rect":Rect2(shelf.position+SHELF_FOOTPRINT.position,SHELF_FOOTPRINT.size),"kind":"shelf","shelf":weakref(shelf)})

func enabled(entry: Dictionary) -> bool:
	if not entry.has("shelf"): return true
	var shelf: Object=entry.shelf.get_ref()
	return is_instance_valid(shelf) and not shelf.is_queued_for_deletion() and shelf.state!="fallen"

func containing(point: Vector2, radius: float=0.0) -> Dictionary:
	for entry in entries:
		if enabled(entry) and Rect2(entry.rect).grow(radius).has_point(point): return entry
	return {}

func project_out(point: Vector2, radius: float=0.0) -> Vector2:
	for entry in entries:
		if not enabled(entry): continue
		var box := Rect2(entry.rect).grow(radius+0.05)
		if not box.has_point(point): continue
		var gaps := [absf(point.x-box.position.x),absf(point.x-box.end.x),absf(point.y-box.position.y),absf(point.y-box.end.y)]
		var side: int=gaps.find(gaps.min())
		if side==0: point.x=box.position.x-0.05
		elif side==1: point.x=box.end.x+0.05
		elif side==2: point.y=box.position.y-0.05
		else: point.y=box.end.y+0.05
	return point

func cast(start: Vector2, motion: Vector2, radius: float) -> Dictionary:
	var closest: Dictionary={}
	var best := 1.01
	for entry in entries:
		if not enabled(entry): continue
		var box := Rect2(entry.rect).grow(radius)
		var enter := 0.0
		var leave := 1.0
		var normal := Vector2.ZERO
		var possible := true
		for axis in range(2):
			if absf(motion[axis])<0.00001:
				if start[axis]<box.position[axis] or start[axis]>box.end[axis]: possible=false
				continue
			var a := (box.position[axis]-start[axis])/motion[axis]
			var b := (box.end[axis]-start[axis])/motion[axis]
			var near := minf(a,b)
			var far := maxf(a,b)
			if near>=enter:
				enter=near
				normal=Vector2.ZERO
				normal[axis]=-signf(motion[axis])
			leave=minf(leave,far)
			if enter>leave: possible=false
		if possible and leave>=0 and enter>=0 and enter<=1 and normal!=Vector2.ZERO and enter<best:
			best=enter
			closest={"fraction":enter,"normal":normal,"entry":entry}
	return closest

func sweep(start: Vector2, destination: Vector2, radius: float, slide: bool=true) -> Dictionary:
	var point := project_out(start,radius)
	var remaining := destination-start
	var path := PackedVector2Array([point])
	var first: Dictionary={}
	for step in range(3):
		if remaining.length_squared()<0.00001: break
		var hit := cast(point,remaining,radius)
		if hit.is_empty():
			point+=remaining
			path.append(point)
			break
		if first.is_empty(): first=hit
		point+=remaining*float(hit.fraction)+Vector2(hit.normal)*0.04
		path.append(point)
		if not slide: break
		remaining=(remaining*(1.0-float(hit.fraction))).slide(hit.normal)
	return {"point":point,"path":path,"hit":first}

func clear_line(start: Vector2, finish: Vector2, radius: float=0.0) -> bool:
	return cast(start,finish-start,radius).is_empty()

func steer(start: Vector2, target: Vector2, radius: float) -> Vector2:
	var hit := cast(start,target-start,radius+4)
	if hit.is_empty(): return (target-start).normalized()
	var box := Rect2(hit.entry.rect).grow(radius+13)
	var corners := [box.position,Vector2(box.end.x,box.position.y),box.end,Vector2(box.position.x,box.end.y)]
	var best := INF
	var waypoint := start
	for corner: Vector2 in corners:
		if not clear_line(start,corner,radius): continue
		var score := start.distance_to(corner)+corner.distance_to(target)
		if score<best:
			best=score
			waypoint=corner
	return (waypoint-start).normalized()

func snapshot() -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	for entry in entries:
		if enabled(entry): result.append({"kind":entry.kind,"rect":entry.rect})
	return result
