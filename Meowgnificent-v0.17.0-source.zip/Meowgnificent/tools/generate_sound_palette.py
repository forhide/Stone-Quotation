#!/usr/bin/env python3
"""Generate Meowgnificent's original, quiet material/interaction Foley.

No samples or external music are used. Mono 22.05 kHz PCM is synthesized once
at development time, with a deterministic seed and rounded attack/release.
The game imports these short files and never synthesizes audio during play.
"""
from pathlib import Path
import math
import random
import struct
import wave

RATE = 22050
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "art/audio"
TAU = math.tau


def bell(t, frequency, decay=12.0):
    return (math.sin(TAU * frequency * t) + 0.24 * math.sin(TAU * frequency * 2.01 * t)) * math.exp(-decay * t)


def render(name, duration, voice, amplitude=0.35):
    rng = random.Random(9217 + sum((i + 1) * ord(c) for i, c in enumerate(name)))
    low = 0.0
    samples = []
    for i in range(round(duration * RATE)):
        t = i / RATE
        noise = rng.uniform(-1, 1)
        low += 0.18 * (noise - low)
        # Avoid clicks at both ends, including the last sample.
        attack = min(1.0, t / 0.009)
        release = min(1.0, max(0.0, (duration - t - 1 / RATE) / 0.035))
        envelope = math.sin(attack * math.pi / 2) ** 2 * release ** 2
        value = voice(t, noise, low) * envelope * amplitude
        samples.append(value)
    peak = max(abs(x) for x in samples)
    if peak > 0.58:
        samples = [x * 0.58 / peak for x in samples]
    pcm = b"".join(struct.pack("<h", round(max(-1, min(1, x)) * 32767)) for x in samples)
    with wave.open(str(OUT / (name + ".wav")), "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(RATE)
        audio.writeframes(pcm)
    print(f"{name}: {duration:.2f}s, peak {max(abs(x) for x in samples):.3f}")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    # Rounded bodily sounds carry the element; higher partials remain gentle.
    render("cast_fire", 0.25, lambda t, n, l: (0.75*l + 0.34*math.sin(TAU*(170*t-125*t*t))) * math.exp(-9*t))
    render("cast_water", 0.29, lambda t, n, l: (math.sin(TAU*(620*t-650*t*t)) + 0.14*l) * math.exp(-14*t), 0.28)
    render("cast_ice", 0.32, lambda t, n, l: bell(t, 880, 17) + 0.32*bell(max(0,t-.045), 1320, 23) * (t>.045), 0.21)
    render("cast_wind", 0.28, lambda t, n, l: (l*1.5 + 0.22*math.sin(TAU*(430*t+110*t*t))) * math.sin(min(1,t/.28)*math.pi), 0.27)
    render("cast_stone", 0.23, lambda t, n, l: (math.sin(TAU*(135*t-65*t*t))*0.8 + l*0.8) * math.exp(-17*t), 0.37)
    render("cast_leaf", 0.33, lambda t, n, l: (0.54*l*(0.65+0.35*math.sin(TAU*26*t)) + 0.42*math.sin(TAU*(270*t+310*t*t))) * math.exp(-8*t), 0.32)
    render("cast_lightning", 0.18, lambda t, n, l: ((n-l)*0.28 + l*0.5 + 0.22*math.sin(TAU*740*t)) * math.exp(-17*t) * (0.7+0.3*math.sin(TAU*53*t)), 0.25)
    render("cast_metal", 0.32, lambda t, n, l: bell(t, 660, 18) + 0.23*bell(t, 1550, 30) + 0.18*l*math.exp(-25*t), 0.25)
    render("miscast", 0.38, lambda t, n, l: (math.sin(TAU*(340*t-270*t*t+0.7*math.sin(TAU*7*t))) * 0.52 + l*0.38) * math.exp(-6*t), 0.29)
    render("skill", 0.44, lambda t, n, l: bell(t, 523, 10)*0.65 + (bell(t-.075, 784, 10)*0.55 if t>.075 else 0) + (bell(t-.15, 1047, 13)*0.35 if t>.15 else 0), 0.25)
    render("hit", 0.16, lambda t, n, l: (0.6*l + 0.55*math.sin(TAU*(220*t-440*t*t))) * math.exp(-25*t), 0.30)
    render("hurt", 0.28, lambda t, n, l: (math.sin(TAU*(260*t-190*t*t))*0.7 + l*0.3) * math.exp(-12*t), 0.30)
    render("pickup", 0.22, lambda t, n, l: bell(t, 784, 22)*0.8 + (bell(t-.045, 1047, 25)*0.45 if t>.045 else 0), 0.19)
    render("gear", 0.38, lambda t, n, l: bell(t, 659, 12)*0.7 + (bell(t-.065, 988, 14)*0.55 if t>.065 else 0), 0.24)
    render("equip", 0.23, lambda t, n, l: bell(t, 392, 22)*0.7 + (bell(t-.045, 587, 22)*0.6 if t>.045 else 0), 0.23)
    render("clear", 0.50, lambda t, n, l: sum(bell(t-delay, freq, 12)*gain if t>delay else 0 for delay,freq,gain in [(0,523,.65),(.08,659,.55),(.16,784,.48),(.25,1047,.34)]), 0.27)


if __name__ == "__main__":
    main()
