class_name SpellProjectile
extends Node2D

signal impacted(point: Vector2, damage: int, radius: float, direction: Vector2)
var direction := Vector2.RIGHT
var speed := 540.0
var lifetime := 2.3
var damage := 20
var radius := 9.0
var explosion_radius := 0.0
var outcome := "success"
var room: Node2D
var bounds: Rect2
var age := 0.0
var spent := false

func _physics_process(delta: float) -> void:
	if spent:
		return
	age += delta
	# Substeps prevent tunnelling through an enemy at low frame rates.
	var distance := speed * delta
	var steps := maxi(1,ceili(distance / 8.0))
	for i in range(steps):
		position += direction * distance / steps
		if not bounds.has_point(position):
			impact()
			return
		for enemy in room.enemies:
			if is_instance_valid(enemy) and enemy.health.current > 0 and position.distance_to(enemy.position) <= radius + float(enemy.config.radius):
				if explosion_radius == 0.0:
					enemy.take_damage(damage,direction)
				impact()
				return
	if age >= lifetime:
		impact()
	queue_redraw()

func impact() -> void:
	if spent:
		return
	spent = true
	impacted.emit(position,damage,explosion_radius,direction)
	queue_free()

func _draw() -> void:
	var color := Color("c6a5ff") if outcome == "miscast" else Color("ffb65e")
	if outcome == "overreaction":
		color = Color("ffdf8a")
	draw_set_transform(Vector2(0,-20))
	for i in range(5,0,-1):
		draw_circle(-direction*i*7,radius*(1.0-i/6.0),Color(color,0.18))
	draw_circle(Vector2.ZERO,radius*2.3,Color(color,0.1))
	draw_circle(Vector2.ZERO,radius,color)
	draw_circle(-direction*2,radius*0.45,Color("fff5d7"))
