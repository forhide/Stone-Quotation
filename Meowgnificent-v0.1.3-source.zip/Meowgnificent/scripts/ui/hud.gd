class_name WizardHUD
extends CanvasLayer

signal begin_requested
var room: Node2D
var health_label: Label
var health_bar: ProgressBar
var status_label: Label
var cooldown_label: Label
var enemy_label: Label
var debug_label: Label
var overlay: PanelContainer
var overlay_title: Label
var overlay_body: Label
var play_button: Button
var outcome_time := 0.0
var outcome := ""
var portrait: CatPortrait
var menu_portrait: CatPortrait

func label_at(text: String, at: Vector2, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.position = at
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_color_override("font_color",color)
	add_child(label)
	return label

func panel_style(color: Color, border: Color, radius: int = 12) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 20
	style.content_margin_bottom = 20
	return style

func _ready() -> void:
	var ink := Color("ede3cc")
	var dim := Color("9098ad")
	label_at("THE DEPARTMENT OF UNSTABLE MAGIC",Vector2(52,24),12,Color("c4a46d"))
	label_at("Meowgnificent",Vector2(49,42),37,ink)
	label_at("the wizard cat",Vector2(52,88),15,dim)
	label_at("FIELD STUDY  /  01",Vector2(1025,30),13,Color("c4a46d"))
	label_at("The Candlewick Archives",Vector2(951,56),19,ink)
	enemy_label = label_at("",Vector2(1025,87),14,dim)
	var bottom := Panel.new()
	bottom.position = Vector2(45,718)
	bottom.size = Vector2(1190,66)
	bottom.add_theme_stylebox_override("panel",panel_style(Color("151c2b"),Color("364050")))
	add_child(bottom)
	portrait = CatPortrait.new()
	portrait.position = Vector2(53,721)
	portrait.size = Vector2(62,59)
	add_child(portrait)
	health_label = label_at("",Vector2(125,726),14,ink)
	health_bar = ProgressBar.new()
	health_bar.position = Vector2(126,754)
	health_bar.size = Vector2(136,8)
	health_bar.show_percentage = false
	health_bar.add_theme_stylebox_override("background",panel_style(Color("313144"),Color("313144"),4))
	health_bar.add_theme_stylebox_override("fill",panel_style(Color("d99a82"),Color("d99a82"),4))
	for kind in ["background", "fill"]:
		var bar_style := health_bar.get_theme_stylebox(kind) as StyleBoxFlat
		bar_style.content_margin_left = 0
		bar_style.content_margin_right = 0
		bar_style.content_margin_top = 0
		bar_style.content_margin_bottom = 0
	add_child(health_bar)
	label_at("LMB / SPACE",Vector2(296,729),12,Color("c4a46d"))
	cooldown_label = label_at("",Vector2(296,748),16,ink)
	status_label = label_at("A very round cat. A very unreliable wizard.",Vector2(495,739),17,ink)
	debug_label = label_at("",Vector2(820,697),11,dim)
	label_at("WASD  MOVE    ·    MOUSE  AIM    ·    R  RESTART    ·    ESC  PAUSE",Vector2(338,693),11,dim)
	overlay = PanelContainer.new()
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay.add_theme_stylebox_override("panel",panel_style(Color("171f30"),Color("c4a46d"),18))
	add_child(overlay)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",17)
	overlay.add_child(box)
	var eyebrow := Label.new()
	eyebrow.text = "A PRACTICAL EXAM IN QUESTIONABLE MAGIC"
	eyebrow.add_theme_font_size_override("font_size",12)
	eyebrow.modulate = Color("c4a46d")
	box.add_child(eyebrow)
	menu_portrait = CatPortrait.new()
	menu_portrait.custom_minimum_size = Vector2(100,100)
	box.add_child(menu_portrait)
	overlay_title = Label.new()
	overlay_title.add_theme_font_size_override("font_size",30)
	box.add_child(overlay_title)
	overlay_body = Label.new()
	overlay_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_body.custom_minimum_size = Vector2(470,85)
	overlay_body.add_theme_font_size_override("font_size",16)
	overlay_body.modulate = Color("bac2d2")
	box.add_child(overlay_body)
	play_button = Button.new()
	play_button.custom_minimum_size = Vector2(0,46)
	play_button.add_theme_stylebox_override("normal",panel_style(Color("68533c"),Color("bf9e66"),8))
	play_button.add_theme_stylebox_override("hover",panel_style(Color("876a48"),Color("e2c184"),8))
	play_button.add_theme_color_override("font_color",Color("fff1d2"))
	play_button.pressed.connect(func(): begin_requested.emit())
	box.add_child(play_button)
	show_overlay("A minor magical incident", "Clear the archives of five candle slimes. Aim carefully.\nYour spells may have other plans.\n70% success  ·  20% miscast  ·  10% overreaction", "Begin field study   /   ENTER")
	overlay.position = Vector2(600,240)
	overlay.size = Vector2(550,315)

func show_overlay(title: String, body: String, button: String) -> void:
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay_title.text = title
	overlay_body.text = body
	play_button.text = button
	overlay.show()

func show_outcome(result: String) -> void:
	outcome = result
	outcome_time = 1.5

func _process(delta: float) -> void:
	if not is_instance_valid(room.player):
		return
	portrait.sync_state(room.state,outcome,outcome_time,room.player.invulnerability)
	menu_portrait.sync_state(room.state,outcome,outcome_time,room.player.invulnerability)
	health_label.text = "VITALITY     %d / %d" % [room.player.health.current,room.player.health.maximum]
	health_bar.max_value = room.player.health.maximum
	health_bar.value = room.player.health.current
	enemy_label.text = "%02d / 05 slimes remain" % room.enemies.size()
	cooldown_label.text = "Fireball  ·  READY" if room.spells.cooldown <= 0 else "Fireball  ·  %.1fs" % room.spells.cooldown
	debug_label.text = "F1 NEXT: SUCCESS   F2: MISCAST   F3: OVERREACTION   |   %s" % ("RANDOM" if room.spells.resolver.forced.is_empty() else room.spells.resolver.forced.to_upper())
	if room.state=="playing":
		outcome_time = maxf(0.0,outcome_time-delta)
	if outcome_time > 0:
		status_label.text = {"success":"SUCCESS  /  Almost professional.","miscast":"MISCAST  /  Entirely intentional. Probably.","overreaction":"OVERREACTION  /  A proportionate response."}.get(outcome,"")
		status_label.modulate = {"success":Color("b5d6c0"),"miscast":Color("cdb0ed"),"overreaction":Color("ffcd84")}.get(outcome,Color.WHITE)
	else:
		status_label.text = "A very round cat. A very unreliable wizard."
		status_label.modulate = Color.WHITE
