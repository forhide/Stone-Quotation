class_name WizardCatVisual
extends Node2D

const CAT_TEXTURE: Texture2D = preload("res://art/characters/meowgnificent.png")
var cat: WizardCat
var sprite: Sprite2D
var elapsed := 0.0

func _ready() -> void:
	cat = get_parent() as WizardCat
	sprite = Sprite2D.new()
	var atlas := AtlasTexture.new()
	atlas.atlas = CAT_TEXTURE
	# Derive transparent padding at runtime so replacement art keeps its foot anchor.
	atlas.region = CAT_TEXTURE.get_image().get_used_rect()
	sprite.texture = atlas
	var height := float(cat.config.get("sprite_height",160.0))
	var factor := height / atlas.get_height()
	sprite.scale = Vector2.ONE * factor
	sprite.position = Vector2(0,-height*0.5+9.0)
	add_child(sprite)

func _process(delta: float) -> void:
	elapsed += delta
	var speed_ratio := clampf(cat.velocity.length() / float(cat.config.speed),0.0,1.0)
	var bob := sin(cat.wobble)*2.0*speed_ratio + sin(elapsed*2.3)*0.45
	position = Vector2(0,bob)
	rotation = sin(cat.wobble)*0.035*speed_ratio
	scale = Vector2(1+cat.cast_pose*0.04,1-cat.cast_pose*0.025)*cat.presentation_scale
	queue_redraw()

func _draw() -> void:
	# A small light at the staff is a casting hook; the illustrated staff remains intact.
	if cat != null and cat.cast_pose>0.05:
		var point := Vector2(-47,-91)
		draw_circle(point,13,Color(1,0.7,0.3,cat.cast_pose*0.15))
		draw_circle(point,4,Color(1,0.86,0.5,cat.cast_pose*0.7))
