class_name SpellController
extends Node

signal spell_emitted(outcome: String, point: Vector2)
var config: Dictionary
var resolver := SpellOutcomeResolver.new()
var cooldown := 0.0
var player: WizardCat
var room: Node2D
var last_outcome := ""

func _physics_process(delta: float) -> void:
	if not player.active:
		return
	cooldown = maxf(0.0,cooldown-delta)
	if player.active and Input.is_action_pressed("cast"):
		cast(player.aim)

func cast(direction: Vector2) -> bool:
	if not player.active or cooldown > 0:
		return false
	cooldown = float(config.cooldown)
	last_outcome = resolver.resolve(config)
	player.cast_pose = 1.0
	var launch := direction.normalized()
	var projectile := SpellProjectile.new()
	projectile.outcome = last_outcome
	projectile.speed = float(config.speed)
	projectile.lifetime = float(config.lifetime)
	projectile.damage = int(config.success_damage)
	if last_outcome == "miscast":
		projectile.damage = int(config.miscast_damage)
		var variant := resolver.rng.randi_range(0,2)
		if variant == 2:
			room.apply_blast(player.position,int(config.miscast_damage),80.0,Vector2.ZERO)
			projectile.free()
			spell_emitted.emit(last_outcome,player.position)
			return true
		var angle := resolver.rng.randf_range(70.0,110.0) if variant == 0 else 180.0
		launch = launch.rotated(deg_to_rad(angle))
	elif last_outcome == "overreaction":
		projectile.damage = int(config.overreaction_damage)
		projectile.radius = 23.0
		projectile.speed *= 0.75
		projectile.explosion_radius = float(config.explosion_radius)
	projectile.direction = launch
	projectile.room = room
	projectile.bounds = player.bounds
	projectile.position = player.position+launch*33
	projectile.impacted.connect(room.apply_blast)
	room.projectiles.add_child(projectile)
	spell_emitted.emit(last_outcome,player.position)
	return true
