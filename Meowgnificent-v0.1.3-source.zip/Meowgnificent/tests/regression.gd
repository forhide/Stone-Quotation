extends SceneTree

var checks := 0
var failures := 0
var scene := preload("res://scenes/main.tscn")

func check(ok: bool, message: String) -> void:
	checks += 1
	if ok:
		print("PASS: "+message)
	else:
		failures += 1
		push_error("FAIL: "+message)

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.physical_keycode=code
	event.pressed=true
	Input.parse_input_event(event)
	event=event.duplicate()
	event.pressed=false
	Input.parse_input_event(event)

func settle() -> void:
	for i in range(3):
		await physics_frame
		await process_frame
	if current_scene==null:
		push_error("Scene transition did not finish")
		quit(2)
		return

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	change_scene_to_packed(scene)
	await settle()
	var room=current_scene
	key(KEY_ENTER)
	await settle()
	check(room.state=="playing","Enter starts real current scene")
	for enemy in room.enemies: enemy.active=false
	room.player.position=Vector2(500,430)
	room.player.take_damage(12,Vector2(450,430))
	room.spells.resolver.forced="success"
	room.spells.cast(Vector2.RIGHT)
	var enemy: CandleSlime=room.enemies[0]
	enemy.cooldown=0.95
	room.effects.append({"point":Vector2(500,400),"age":0.1,"radius":20.0,"color":Color.WHITE})
	key(KEY_ESCAPE)
	await settle()
	check(room.state=="paused","Esc pauses through real input dispatch")
	var invul: float=room.player.invulnerability
	var pose: float=room.player.cast_pose
	var attack: float=enemy.cooldown
	var feedback: float=room.hud.outcome_time
	var cooldown: float=room.spells.cooldown
	var shot=room.projectiles.get_child(0)
	var shot_position: Vector2=shot.position
	var shot_age: float=shot.age
	for i in range(24): await physics_frame
	check(is_equal_approx(room.player.invulnerability,invul),"pause preserves invulnerability time")
	check(is_equal_approx(room.player.cast_pose,pose),"pause preserves casting pose time")
	check(is_equal_approx(enemy.cooldown,attack),"pause preserves enemy attack cooldown")
	check(is_equal_approx(room.hud.outcome_time,feedback),"pause preserves outcome feedback time")
	check(is_equal_approx(room.spells.cooldown,cooldown),"pause preserves spell cooldown")
	check(shot.position==shot_position and shot.age==shot_age,"pause freezes projectile position and lifetime")
	key(KEY_ESCAPE)
	await settle()
	check(room.state=="playing","Esc resumes through real input dispatch")
	for foe in room.enemies: foe.active=false
	for i in range(4): await physics_frame
	check(room.player.invulnerability<invul and room.spells.cooldown<cooldown,"timers resume with combat")
	var original_events: Dictionary={}
	for action in ["move_left","move_right","move_up","move_down","cast"]:
		original_events[action]=InputMap.action_get_events(action).size()
	for i in range(5):
		key(KEY_R)
		await settle()
		room=current_scene
		check(room.state=="intro" and room.enemies.size()==5 and room.player.health.current==100,"restart %d resets room, enemies and HP"%(i+1))
	var bindings_stable:=true
	for action in original_events:
		if InputMap.action_get_events(action).size()!=original_events[action]: bindings_stable=false
	check(bindings_stable,"five restarts do not accumulate input bindings")
	key(KEY_ENTER)
	await settle()
	room=current_scene
	for foe in room.enemies: foe.active=false
	for code in [KEY_F1,KEY_F2,KEY_F3]:
		key(code)
		await settle()
		var expected: String={KEY_F1:"success",KEY_F2:"miscast",KEY_F3:"overreaction"}[code]
		room.spells.cooldown=0
		check(room.spells.cast(Vector2.RIGHT) and room.spells.last_outcome==expected,"debug key selects "+expected)
		check(room.spells.resolver.forced.is_empty(),"forced "+expected+" is consumed once")
	room.player.invulnerability=0
	room.player.take_damage(999,Vector2.ZERO)
	await settle()
	check(room.state=="defeated" and room.hud.menu_portrait.expression=="sleepy","death presents resting portrait and retry")
	key(KEY_ENTER)
	await settle()
	room=current_scene
	check(room.state=="intro" and room.player.health.current==100,"Enter retries after defeat")
	key(KEY_ENTER)
	await settle()
	for foe in room.enemies.duplicate(): foe.take_damage(999,Vector2.RIGHT)
	await settle()
	check(room.state=="cleared","all enemies defeated triggers clear state")
	key(KEY_ENTER)
	await settle()
	check(current_scene.state=="intro" and current_scene.enemies.size()==5,"Enter retries after victory")
	print("REGRESSION RESULT: %d checks, %d failures"%[checks,failures])
	quit(0 if failures==0 else 1)
