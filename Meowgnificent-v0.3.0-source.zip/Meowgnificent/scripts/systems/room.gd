extends Node2D

const PLAYER_SCENE = preload("res://scenes/player/player.tscn")
var balance: Dictionary
var bounds: Rect2
var player: WizardCat
var spells: SpellController
var hud: WizardHUD
var actors: Node2D
var projectiles: Node2D
var enemies: Array[CandleSlime] = []
var camera: Camera2D
var state := "intro"
var effects: Array[Dictionary] = []
var props: Array[ArcaneShelf] = []
var fires: Array[Dictionary] = []
var time := 0.0
var shake := 0.0

func _ready() -> void:
	balance = JSON.parse_string(FileAccess.get_file_as_string("res://data/balance.json"))
	var r: Dictionary = balance.room
	bounds = Rect2(float(r.left),float(r.top),float(r.width),float(r.height))
	configure_inputs()
	# Render the unchanging room once, then reuse a single cached texture.
	var background_viewport := SubViewport.new()
	background_viewport.size=Vector2i(1280,800)
	background_viewport.transparent_bg=true
	background_viewport.disable_3d=true
	background_viewport.render_target_update_mode=SubViewport.UPDATE_ONCE
	background_viewport.add_child(ArchiveBackdrop.new())
	add_child(background_viewport)
	var background := Sprite2D.new()
	background.texture=background_viewport.get_texture()
	background.centered=false
	# Floor fire and impact rings drawn by the room must remain above the backdrop.
	background.z_index=-10
	add_child(background)
	actors = Node2D.new()
	actors.y_sort_enabled = true
	add_child(actors)
	projectiles = Node2D.new()
	add_child(projectiles)
	camera = Camera2D.new()
	camera.position = Vector2(640,400)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 4
	add_child(camera)
	player = PLAYER_SCENE.instantiate()
	player.position = Vector2(345,515)
	player.presentation_scale = 1.85
	player.setup(balance.player,bounds)
	player.active = false
	actors.add_child(player)
	player.health.died.connect(on_player_died)
	player.hurt.connect(func(): shake=5.0)
	player.wall_bumped.connect(on_wall_bumped)
	spells = SpellController.new()
	spells.config = balance.fireball
	spells.player = player
	spells.room = self
	spells.spell_emitted.connect(on_spell_emitted)
	add_child(spells)
	spawn_enemies()
	for point in [Vector2(440,330),Vector2(840,330),Vector2(440,565),Vector2(840,565)]:
		var shelf := ArcaneShelf.new()
		shelf.room=self
		shelf.position=point
		props.append(shelf)
		actors.add_child(shelf)
	hud = WizardHUD.new()
	hud.room = self
	hud.begin_requested.connect(begin_or_restart)
	add_child(hud)

func configure_inputs() -> void:
	var keys := {"move_left":[KEY_A,KEY_LEFT],"move_right":[KEY_D,KEY_RIGHT],"move_up":[KEY_W,KEY_UP],"move_down":[KEY_S,KEY_DOWN],"cast":[KEY_SPACE],"roll":[KEY_SHIFT]}
	for action: String in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key: int in keys[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action,event)
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("cast",mouse)

func spawn_enemies() -> void:
	var locations := [Vector2(270,290),Vector2(1000,310),Vector2(350,590),Vector2(980,590),Vector2(640,255)]
	for i in range(int(balance.enemy.count)):
		var enemy := CandleSlime.new()
		enemy.position = locations[i % locations.size()]
		enemy.role = ["candle","broom","candle","broom","bat"][i%5]
		enemy.setup(balance.enemy,player,bounds)
		enemy.active = false
		enemy.defeated.connect(on_enemy_defeated)
		enemies.append(enemy)
		actors.add_child(enemy)

func begin_or_restart() -> void:
	if state == "intro":
		player.position = Vector2(640,455)
		player.presentation_scale = 1.0
		set_running(true)
	elif state == "paused":
		set_running(true)
	else:
		get_tree().reload_current_scene()

func set_running(running: bool) -> void:
	state = "playing" if running else "paused"
	player.active = running
	for enemy in enemies:
		enemy.active = running
	projectiles.process_mode = Node.PROCESS_MODE_INHERIT if running else Node.PROCESS_MODE_DISABLED
	if running:
		hud.overlay.hide()
	else:
		hud.show_overlay("Taking a catnap", "The archives can wait.\nYour current study is paused.", "Resume study   /   ENTER")

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():
		return
	if event is InputEventKey:
		match event.keycode:
			KEY_ENTER:
				if state != "playing": begin_or_restart()
			KEY_R: get_tree().reload_current_scene()
			KEY_ESCAPE:
				if state == "playing": set_running(false)
				elif state == "paused": set_running(true)
			KEY_F1: spells.resolver.forced = "success"
			KEY_F2: spells.resolver.forced = "miscast"
			KEY_F3: spells.resolver.forced = "overreaction"

func on_spell_emitted(result: String, point: Vector2) -> void:
	hud.show_outcome(result)
	if result == "miscast":
		var burst := MiscastBurst.new()
		burst.room = self
		burst.position = point
		add_child(burst)
	else:
		effects.append({"point":point,"age":0.0,"radius":35.0,"color":Color("f6be70")})
	if result == "overreaction": shake = 7.0

func apply_miscast_blast(point: Vector2, damage: int, radius: float, direction: Vector2) -> void:
	apply_blast(point,damage,radius,direction,Color("9295a1"))


func apply_blast(point: Vector2, damage: int, radius: float, direction: Vector2, tint: Color = Color("ffcb86")) -> void:
	effects.append({"point":point,"age":0.0,"radius":maxf(24,radius),"color":tint})
	if radius <= 0:
		return
	shake = 6.0
	for shelf in props:
		if shelf.position.distance_to(point)<=radius+30:
			shelf.ignite((shelf.position-point).normalized())
	# Iterate a copy because defeated signals remove enemies immediately.
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and enemy.position.distance_to(point) <= radius + float(enemy.config.radius):
			var push: Vector2 = (enemy.position-point).normalized() if direction==Vector2.ZERO else direction
			enemy.take_damage(damage,push)

func tell(message: String, color: Color = Color("eacb9e")) -> void:
	if is_instance_valid(hud): hud.show_incident(message,color)

func on_wall_bumped(point: Vector2) -> void:
	shake=6
	tell("Wall: 1. Wizard: 0.",Color("ffb5a0"))
	effects.append({"point":point,"age":0.0,"radius":45.0,"color":Color("d7c4aa")})
	for shelf in props:
		if shelf.position.distance_to(point)<110: shelf.topple(player.roll_direction)

func ignite_floor(point: Vector2) -> void:
	for fire in fires:
		if fire.point.distance_to(point)<45: return
	fires.append({"point":point,"age":0.0,"tick":0.0})

func _physics_process(delta: float) -> void:
	if state!="playing": return
	for shelf in props:
		if shelf.state=="standing" or shelf.state=="burning":
			var offset := player.position-shelf.position
			if offset.length()<55:
				if player.roll_time>0: shelf.topple(player.roll_direction)
				else: player.position=shelf.position+(offset.normalized() if offset.length()>0.01 else Vector2.DOWN)*55
			for enemy in enemies.duplicate():
				var gap: Vector2 = enemy.position-shelf.position
				if gap.length()<48:
					if enemy.phase=="attack" and enemy.role=="broom": shelf.topple(enemy.attack_direction)
					else: enemy.position=shelf.position+(gap.normalized() if gap.length()>0.01 else Vector2.DOWN)*48
	if player.roll_time>0:
		for enemy in enemies.duplicate():
			if player.position.distance_to(enemy.position)<49 and not player.roll_hits.has(enemy.get_instance_id()):
				player.roll_hits.append(enemy.get_instance_id())
				enemy.take_damage(30,player.roll_direction)
				tell("An advanced belly-based technique.",Color("e1d4a5"))
	for fire in fires:
		fire.age+=delta
		fire.tick-=delta
		if fire.tick<=0:
			fire.tick=0.7
			if player.position.distance_to(fire.point)<43: player.take_damage(6,fire.point-Vector2(1,0))
			for enemy in enemies.duplicate():
				if enemy.position.distance_to(fire.point)<48: enemy.take_damage(10,Vector2.UP)
	fires=fires.filter(func(f: Dictionary) -> bool: return f.age<4.2)


func on_enemy_defeated(enemy: CandleSlime) -> void:
	effects.append({"point":enemy.position,"age":0.0,"radius":40.0,"color":Color("9dd6bb")})
	enemies.erase(enemy)
	if enemies.is_empty() and state == "playing":
		state = "cleared"
		player.active = false
		projectiles.process_mode = Node.PROCESS_MODE_DISABLED
		hud.show_overlay("Accidentally excellent.","The archives are clear. The faculty is concerned.\n\nOne room. Several avoidable accidents.","Try another study   /   ENTER")

func on_player_died() -> void:
	state = "defeated"
	player.active = false
	for enemy in enemies:
		enemy.active = false
	projectiles.process_mode = Node.PROCESS_MODE_DISABLED
	hud.show_overlay("A brief interruption.","Even a magnificent wizard needs nine lives.\n\nTry keeping some distance from the candles.","Try again   /   ENTER")

func _process(delta: float) -> void:
	if state != "playing":
		return
	time += delta
	shake = move_toward(shake,0,delta*25)
	camera.position = Vector2(640,400)+(player.position-Vector2(640,400))*0.035
	camera.offset = Vector2(sin(time*79),cos(time*91))*shake
	for effect in effects:
		effect.age += delta
	effects = effects.filter(func(e: Dictionary) -> bool: return float(e.age)<0.5)
	queue_redraw()

func _draw() -> void:
	for fire in fires:
		var p: Vector2=fire.point
		var fade := minf(1,(4.2-float(fire.age))*2)
		draw_circle(p,43,Color(0.9,0.25,0.12,0.16*fade))
		draw_arc(p,43,0,TAU,32,Color(1,0.5,0.25,0.5*fade),2,true)
		for i in range(7):
			var q := p+Vector2(sin(i*8.0)*29,cos(i*7.0)*20)
			draw_circle(q-Vector2(0,8+sin(time*11+i)*5),8,Color(1,0.4,0.15,0.7*fade))
			draw_circle(q-Vector2(0,4),4,Color(1,0.83,0.4,fade))
	for effect in effects:
		var t := float(effect.age)/0.5
		var c: Color = effect.color
		c.a = (1-t)*0.7
		draw_arc(effect.point+Vector2(0,-18),float(effect.radius)*(0.3+t),0,TAU,40,c,3*(1-t)+1,true)
		for i in range(8):
			var d := Vector2.from_angle(TAU*i/8)
			draw_circle(effect.point+Vector2(0,-18)+d*float(effect.radius)*t,3*(1-t),c)

