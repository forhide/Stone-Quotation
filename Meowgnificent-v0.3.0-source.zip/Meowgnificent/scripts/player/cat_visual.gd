class_name WizardCatVisual
extends Node2D

const ACTION_SHEET: Texture2D = preload("res://art/characters/actions.png")
# Six distinct full-body key poses; small margins keep neighboring cells out.
const POSE_RECTS: Array[Rect2i] = [Rect2i(70,10,390,490),Rect2i(552,2,440,500),Rect2i(1034,40,500,460),Rect2i(22,516,490,475),Rect2i(562,528,445,455),Rect2i(1068,550,444,430)]
const COLS := 6
const ROWS := 9
var cat: WizardCat
var sprite: MeshInstance2D
var motion_material: ShaderMaterial
var mesh_pose := -1
var mesh_facing := 0.0
var elapsed := 0.0
var active_pose := 0
var gait := 0.0
var pose_age := 0.0

func _ready() -> void:
	cat=get_parent() as WizardCat
	sprite=MeshInstance2D.new()
	sprite.texture=ACTION_SHEET
	var vertices := PackedVector2Array()
	var coordinates := PackedVector2Array()
	var indices := PackedInt32Array()
	for y in range(ROWS+1):
		for x in range(COLS+1):
			var uv := Vector2(float(x)/COLS,float(y)/ROWS)
			vertices.append(Vector2((uv.x-0.5)*160,(uv.y-1)*180))
			coordinates.append(uv)
	for y in range(ROWS):
		for x in range(COLS):
			var a := y*(COLS+1)+x
			indices.append_array(PackedInt32Array([a,a+1,a+COLS+1,a+1,a+COLS+2,a+COLS+1]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX]=vertices
	arrays[Mesh.ARRAY_TEX_UV]=coordinates
	arrays[Mesh.ARRAY_INDEX]=indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays,[],{},Mesh.ARRAY_FLAG_USE_2D_VERTICES)
	mesh.custom_aabb=AABB(Vector3(-200,-200,-1),Vector3(400,400,2))
	sprite.mesh=mesh
	motion_material=ShaderMaterial.new()
	motion_material.shader=preload("res://scripts/player/cat_motion.gdshader")
	sprite.material=motion_material
	add_child(sprite)
	update_mesh()

func choose_pose() -> int:
	if cat.roll_time>0: return 5
	if cat.hit_reaction>0 or cat.health.current<=0: return 4
	if cat.cast_prepare>0: return 1
	if cat.cast_pose>0:
		return 3 if cat.cast_outcome!="success" else 2
	return 0

func _process(delta: float) -> void:
	var animating := cat.active or cat.presentation_scale>1.0
	if animating:
		elapsed+=delta
		gait=move_toward(gait,clampf(cat.velocity.length()/float(cat.config.speed),0,1),delta*7)
		pose_age+=delta
	var next := choose_pose()
	if next!=active_pose:
		active_pose=next
		pose_age=0
	scale=Vector2.ONE*cat.presentation_scale
	if cat.roll_time>0:
		position=Vector2(0,-36)
		rotation=cat.roll_spin
	else:
		position=Vector2.ZERO
		rotation=sin(cat.wobble)*0.055*gait
		if active_pose==1: rotation-=cat.cast_aim.x*0.09
		if active_pose==2: rotation+=cat.cast_aim.x*0.12*cat.cast_pose
		if active_pose==3: rotation-=cat.cast_aim.x*0.16*cat.cast_pose
		if active_pose==4: rotation+=sin(elapsed*37)*0.07*minf(1,cat.hit_reaction*4)
	update_mesh()
	queue_redraw()

func update_mesh() -> void:
	# The indexed mesh is immutable. Only small GPU uniforms change per frame.
	if mesh_pose!=active_pose:
		var rect := POSE_RECTS[active_pose]
		var factor := float(cat.config.get("sprite_height",168.0))*0.86/490.0
		if active_pose==5: factor*=0.78
		var sheet_size := ACTION_SHEET.get_size()
		motion_material.set_shader_parameter("frame_uv",Vector4(rect.position.x/sheet_size.x,rect.position.y/sheet_size.y,rect.size.x/sheet_size.x,rect.size.y/sheet_size.y))
		motion_material.set_shader_parameter("pose_size",Vector2(rect.size)*factor)
		motion_material.set_shader_parameter("pose",active_pose)
		mesh_pose=active_pose
	var facing := -1.0 if active_pose in [1,2,3] and cat.cast_aim.x<0 else 1.0
	if facing!=mesh_facing:
		motion_material.set_shader_parameter("facing",facing)
		mesh_facing=facing
	motion_material.set_shader_parameter("motion",Vector4(sin(elapsed*2.8),sin(cat.wobble),sin(cat.wobble-0.9),gait))
	motion_material.set_shader_parameter("pose_amount",cat.cast_pose)

func _draw() -> void:
	if cat==null or cat.roll_time>0: return
	var charging := cat.cast_prepare>0
	if charging or cat.cast_pose>0.05:
		var power := 0.65 if charging else cat.cast_pose
		var point := Vector2(38 if cat.cast_aim.x>=0 else -38,-75)
		draw_circle(point,16,Color(1,0.7,0.3,power*0.16))
		draw_circle(point,4,Color(1,0.86,0.5,power*0.75))
