class_name ArchiveBackdrop
extends Node2D

const ROOM_ART: Texture2D = preload("res://art/environments/candlewick_archive.png")

func _draw() -> void:
	# Baked material detail and candlelight: rendered once by the room's cache.
	draw_rect(Rect2(0,0,1280,800),Color("0c111b"))
	# The artwork's inner floor aligns with the existing collision rectangle.
	draw_texture_rect(ROOM_ART,Rect2(20,54,1240,744),false)
	# Keep the existing HUD readable; decorative perimeter art sits beneath it.
	draw_rect(Rect2(0,0,1280,118),Color("0c111b"))
	draw_rect(Rect2(0,714,1280,86),Color("0c111b"))
	draw_line(Vector2(76,118),Vector2(1204,118),Color(0.68,0.52,0.31,0.32),1,true)
	draw_line(Vector2(76,712),Vector2(1204,712),Color(0.68,0.52,0.31,0.25),1,true)
