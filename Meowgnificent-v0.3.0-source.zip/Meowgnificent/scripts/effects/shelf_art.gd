class_name ShelfArt
extends Node2D

func ellipse(at: Vector2, size: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(40):
		var a := TAU*i/40.0
		points.append(at+Vector2(cos(a),sin(a))*size)
	draw_colored_polygon(points,color)

func _draw() -> void:
	draw_set_transform(Vector2(80,112))
	draw_standing()
	draw_set_transform(Vector2(240,80))
	draw_fallen()
	draw_set_transform(Vector2(400,112))
	draw_fire()

func draw_standing() -> void:
	ellipse(Vector2(0,6),Vector2(49,12),Color(0.03,0.025,0.04,0.38))
	draw_style_box(box(Color("49332e"),Color("a97d51"),3),Rect2(-43,-80,86,83))
	draw_rect(Rect2(-36,-72,72,70),Color("211d29"))
	for x in [-42,36]:
		draw_rect(Rect2(x,-77,6,83),Color("78503b"))
		draw_line(Vector2(x+1,-74),Vector2(x+1,3),Color("c49662"),1,true)
		for y in [-60,-38,-15]:
			draw_line(Vector2(x+3,y),Vector2(x+4,y+9),Color("513a30"),1,true)
	for row in range(2):
		for i in range(6):
			var colors := [Color("aa6e78"),Color("849d90"),Color("b39a68"),Color("777b9f")]
			var c: Color=colors[(i+row)%4]
			var x := -31+i*10
			var y := -68+row*32+(i%3)*2
			var h := 26-(i%3)*2
			draw_rect(Rect2(x+1,y+1,9,h),Color(0,0,0,0.28))
			draw_style_box(box(c,c.darkened(0.38),1),Rect2(x,y,8,h))
			draw_line(Vector2(x+1,y+2),Vector2(x+1,y+h-2),c.lightened(0.22),1,true)
			for band in [4,h-5]:
				draw_line(Vector2(x+2,y+band),Vector2(x+6,y+band),Color("cbb180"),1,true)
			draw_circle(Vector2(x+4,y+h*0.5),1,Color("d8c29a"))
		var shelf_y := -36+row*33
		draw_rect(Rect2(-38,shelf_y,76,6),Color("9b724f"))
		draw_line(Vector2(-37,shelf_y),Vector2(37,shelf_y),Color("d1ad76"),1,true)
		draw_line(Vector2(-36,shelf_y+5),Vector2(36,shelf_y+5),Color("36282b"),1,true)
	draw_rect(Rect2(-45,-82,90,7),Color("886044"))
	draw_line(Vector2(-44,-82),Vector2(44,-82),Color("c8a06a"),2,true)
	for x in [-38,38]:
		draw_circle(Vector2(x,-78),2,Color("e2bb75"))
		draw_rect(Rect2(x-3,3,6,7),Color("5c4135"))
	draw_arc(Vector2(0,-78),10,PI,TAU,18,Color("d2b176"),1,true)
	draw_line(Vector2(-4,-78),Vector2(0,-84),Color("e3c38d"),1,true)
	draw_line(Vector2(0,-84),Vector2(4,-78),Color("e3c38d"),1,true)
	draw_string(ThemeDB.fallback_font,Vector2(-32,22),"FLAMMABLE",HORIZONTAL_ALIGNMENT_LEFT,-1,10,Color("c9b28c"))

func draw_fallen() -> void:
	ellipse(Vector2(2,3),Vector2(48,68),Color(0.02,0.02,0.03,0.32))
	draw_style_box(box(Color("42302d"),Color("826345"),3),Rect2(-42,-65,84,127))
	draw_rect(Rect2(-35,-58,70,113),Color("2d252a"))
	for x in [-40,35]:
		draw_rect(Rect2(x,-63,5,124),Color("8b674b"))
		draw_line(Vector2(x,-60),Vector2(x,58),Color("ba9465"),1,true)
	for i in range(10):
		var at := Vector2(sin(i*8.0)*29,cos(i*9.0)*48)
		draw_set_transform(Vector2(240,80)+at,i*0.7)
		var c: Color=[Color("936b77"),Color("7d938d"),Color("b59b70")][i%3]
		draw_rect(Rect2(-10,-7,20,14),Color(0,0,0,0.25))
		draw_style_box(box(c,c.darkened(0.4),1),Rect2(-9,-7,18,12))
		draw_rect(Rect2(-7,-5,13,8),Color("cfc0a0"))
		draw_line(Vector2(-6,-2),Vector2(4,-2),Color("aa987d"),1)
		draw_line(Vector2(-6,1),Vector2(4,1),Color("aa987d"),1)
	draw_set_transform(Vector2(240,80))
	for i in range(5):
		var x := sin(i*7.0)*34
		var y := cos(i*5.0)*42
		draw_line(Vector2(x,y),Vector2(x+8,y+6),Color("bb9771"),2,true)

func draw_fire() -> void:
	for i in range(5):
		var p := Vector2(-28+i*14,-39-(i%3)*6)
		for ring in range(4,0,-1):
			draw_circle(p+Vector2(0,3),ring*7,Color(1,0.35,0.1,0.025))
		var outer := PackedVector2Array([p+Vector2(-8,8),p+Vector2(-9,-3),p+Vector2(-3,-11),p+Vector2(0,-25),p+Vector2(7,-10),p+Vector2(10,2),p+Vector2(6,9)])
		draw_colored_polygon(outer,Color("ed682c"))
		var inner := PackedVector2Array([p+Vector2(-5,7),p+Vector2(-4,-3),p+Vector2(2,-15),p+Vector2(6,1),p+Vector2(3,8)])
		draw_colored_polygon(inner,Color("ffbd58"))
		draw_circle(p+Vector2(0,4),3,Color("ffedb1"))

func box(color: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	return style
