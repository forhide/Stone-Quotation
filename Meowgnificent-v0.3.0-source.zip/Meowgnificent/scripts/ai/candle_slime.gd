class_name CandleSlime
extends Node2D

signal defeated(enemy: CandleSlime)
var config: Dictionary
var health: CombatHealth
var target: WizardCat
var bounds: Rect2
var cooldown := 0.0
var hit_flash := 0.0
var time := 0.0
var knockback := Vector2.ZERO
var active := true
var role := "candle"
var phase := "approach"
var phase_time := 0.0
var attack_direction := Vector2.RIGHT
var attack_hit := false
# Only four baked parts per room: three bodies and a shared mirrored bat wing.
static var _art_owner: WeakRef
static var _art_textures: Dictionary = {}
var body_root: Node2D
var body_sprite: Sprite2D
var wing_roots: Array[Node2D] = []
var health_track: Line2D
var health_fill: Line2D
var foreground_effects: ForegroundEnemyEffects

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	config = settings
	target = player
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	health.died.connect(func(): defeated.emit(self); queue_free())
	time = position.x
	health.changed.connect(_update_health)

func _physics_process(delta: float) -> void:
	if not active or not is_instance_valid(target) or not target.active or health.current<=0:
		return
	time += delta
	cooldown = maxf(0,cooldown-delta)
	hit_flash = maxf(0,hit_flash-delta)
	phase_time = maxf(0,phase_time-delta)
	var to_player := target.position-position
	match phase:
		"approach":
			var reach := 230.0 if role=="broom" else (150.0 if role=="bat" else 85.0)
			if to_player.length()<reach and cooldown<=0:
				phase="windup"
				phase_time=0.72 if role!="bat" else 0.5
				attack_direction=to_player.normalized()
				attack_hit=false
			else:
				var speed := float(config.speed)*(1.25 if role=="bat" else 0.8 if role=="broom" else 1.0)
				position+=to_player.normalized()*speed*delta
		"windup":
			if phase_time<=0:
				phase="attack"
				phase_time=0.38 if role=="broom" else 0.3
		"attack":
			position+=attack_direction*(500 if role=="broom" else 390 if role=="bat" else 210)*delta
			if not attack_hit and position.distance_to(target.position)<float(config.radius)+float(target.config.radius):
				target.take_damage(int(config.contact_damage),position)
				attack_hit=true
			if phase_time<=0:
				phase="recover"
				phase_time=0.85
		"recover":
			if phase_time<=0:
				phase="approach"
				cooldown=0.25
	position+=knockback*delta
	position=position.clamp(bounds.position+Vector2.ONE*20,bounds.end-Vector2.ONE*20)
	knockback=knockback.move_toward(Vector2.ZERO,delta*550)
	queue_redraw()

func take_damage(amount: int, direction: Vector2) -> void:
	if health.damage(amount):
		hit_flash=0.15
		knockback=direction*240
		# A hit interrupts the telegraph: a clumsy roll can rescue a bad cast.
		phase="recover"
		phase_time=0.6

func _ready() -> void:
	if role=="bat":
		for side in [-1,1]:
			var wing := Node2D.new()
			wing.scale.x=side
			wing.position=Vector2(side*7,-31)
			add_child(wing)
			wing_roots.append(wing)
			_add_part(wing,"bat_wing")
	body_root=Node2D.new()
	add_child(body_root)
	body_sprite=_add_part(body_root,role)
	health_track=_health_line(Color("273943"))
	health_fill=_health_line(Color("c8e0b4"))
	_update_health()
	_sync_visuals()
	foreground_effects=ForegroundEnemyEffects.new()
	foreground_effects.enemy=self
	add_child(foreground_effects)

func _cached_art(key: String) -> Texture2D:
	var owner_node := get_parent()
	if _art_owner==null or _art_owner.get_ref()!=owner_node:
		_art_owner=weakref(owner_node)
		_art_textures.clear()
	if _art_textures.has(key): return _art_textures[key]
	var viewport := CachedEnemyViewport.new()
	viewport.name="EnemyArt_"+key
	viewport.size=Vector2i(256,256)
	viewport.transparent_bg=true
	viewport.disable_3d=true
	viewport.gui_disable_input=true
	viewport.render_target_update_mode=SubViewport.UPDATE_ONCE
	var artwork := CachedEnemyArt.new()
	artwork.variant=key
	artwork.position=Vector2(128,192)
	artwork.scale=Vector2(2,2)
	viewport.add_child(artwork)
	# Siblings share the texture; the room owns its lifetime, not the first enemy.
	# Defer on the viewport itself so it can clean up even if the room exits first.
	viewport.cache_owner=weakref(owner_node)
	viewport.call_deferred("attach_to_owner")
	var texture := AtlasTexture.new()
	var rect := _art_bounds(key)
	texture.atlas=viewport.get_texture()
	texture.region=Rect2(Vector2(128,192)+rect.position*2,rect.size*2)
	texture.filter_clip=true
	_art_textures[key]=texture
	return texture

func _art_bounds(key: String) -> Rect2:
	match key:
		"broom": return Rect2(-30,-72,60,82)
		"bat": return Rect2(-17,-28,34,49)
		"bat_wing": return Rect2(-3,-33,49,47)
		_: return Rect2(-30,-67,60,78)

func _add_part(parent_node: Node2D, key: String) -> Sprite2D:
	var part := Sprite2D.new()
	part.texture=_cached_art(key)
	part.centered=false
	part.position=_art_bounds(key).position
	part.scale=Vector2(0.5,0.5)
	part.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	parent_node.add_child(part)
	return part

func _health_line(color: Color) -> Line2D:
	var line := Line2D.new()
	line.position=Vector2(0,-78)
	line.points=PackedVector2Array([Vector2(-20,0),Vector2(20,0)])
	line.width=3
	line.default_color=color
	line.antialiased=true
	add_child(line)
	return line

func _update_health(_current: int=0, _maximum: int=0) -> void:
	if health_track==null or health==null: return
	var damaged := health.current<health.maximum
	health_track.visible=damaged
	health_fill.visible=damaged
	if damaged:
		health_fill.points=PackedVector2Array([Vector2(-20,0),Vector2(-20+40*float(health.current)/health.maximum,0)])

func _sync_visuals() -> void:
	if body_root==null: return
	body_sprite.self_modulate=Color(1.7,1.55,1.3) if hit_flash>0 else Color.WHITE
	if role=="broom":
		body_root.rotation=attack_direction.x*0.2 if phase=="attack" else sin(time*3)*0.04
		body_root.position=Vector2(0,-3+sin(time*5)*0.7)
	elif role=="bat":
		var lift := -31+sin(time*8)*4
		body_root.position=Vector2(0,lift)
		body_root.rotation=attack_direction.x*0.10 if phase=="attack" else sin(time*4)*0.035
		for i in range(wing_roots.size()):
			var side := -1.0 if i==0 else 1.0
			wing_roots[i].position=Vector2(side*7,lift)
			wing_roots[i].rotation=side*sin(time*12)*0.22
			wing_roots[i].scale=Vector2(side,0.90+sin(time*12)*0.23)
	else:
		body_root.rotation=sin(time*4)*0.045
		body_root.scale=Vector2(1.0+sin(time*4)*0.025,1.0-sin(time*4)*0.035)

func _draw() -> void:
	# Benchmarks may advance time while AI is inactive; pause itself keeps time frozen.
	_sync_visuals()
	if foreground_effects!=null: foreground_effects.queue_redraw()
	if phase=="windup":
		var length := 205.0 if role=="broom" else 125.0 if role=="bat" else 78.0
		var tip := attack_direction*length
		draw_line(Vector2.ZERO,tip,Color(1,0.35,0.27,0.14),38,true)
		draw_line(Vector2.ZERO,tip,Color(1,0.55,0.38,0.7),2,true)
		draw_arc(Vector2.ZERO,32,0,TAU,32,Color("ffad75"),2,true)
		draw_string(ThemeDB.fallback_font,Vector2(-4,-88),"!",HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color("ffbc7e"))
	draw_set_transform(Vector2(0,5),0,Vector2(1,0.30))
	draw_circle(Vector2.ZERO,25,Color(0,0,0,0.28))
	draw_set_transform(Vector2.ZERO)
	if role=="candle":
		var flame := body_root.transform*Vector2(sin(time*5)*1.2,-65)
		draw_circle(flame,12+sin(time*9),Color(1,0.63,0.27,0.13))

class CachedEnemyViewport extends SubViewport:
	var cache_owner: WeakRef

	func attach_to_owner() -> void:
		var target_owner: Node = cache_owner.get_ref() if cache_owner!=null else null
		if is_instance_valid(target_owner) and target_owner.is_inside_tree() and not target_owner.is_queued_for_deletion():
			target_owner.add_child(self)
		else:
			# The deferred call survives its former owner; no orphan remains on reload.
			queue_free()

class ForegroundEnemyEffects extends Node2D:
	var enemy: CandleSlime

	func _draw() -> void:
		if not is_instance_valid(enemy): return
		if enemy.phase=="recover":
			draw_arc(Vector2(0,-59),12,enemy.time*5,enemy.time*5+4,12,Color("c2d5df"),2,true)
		if enemy.role=="candle":
			var flame := enemy.body_root.transform*Vector2(sin(enemy.time*5)*1.2,-65)
			draw_colored_polygon(PackedVector2Array([flame+Vector2(-5,2),flame+Vector2(-4,-4),flame+Vector2(sin(enemy.time*7)*2,-12),flame+Vector2(5,-2),flame+Vector2(4,5)]),Color("ffd88a"))
			draw_circle(flame+Vector2(0,1),2.8,Color("fff2ce"))
		if enemy.hit_flash>0:
			draw_arc(Vector2(0,-20),27,0,TAU,20,Color("fff4d7"),3,true)

class CachedEnemyArt extends Node2D:
	var variant := "candle"

	func _draw() -> void:
		match variant:
			"broom": draw_broom()
			"bat": draw_bat()
			"bat_wing": draw_wing()
			_: draw_candle_slime()

	func ellipse(center: Vector2, radii: Vector2, color: Color, steps: int=48) -> void:
		var vertices := PackedVector2Array()
		for i in range(steps):
			var a := TAU*i/steps
			vertices.append(center+Vector2(cos(a),sin(a))*radii)
		draw_colored_polygon(vertices,color)

	func rounded(rect: Rect2, color: Color, radius: int, border: Color=Color.TRANSPARENT) -> void:
		var style := StyleBoxFlat.new()
		style.bg_color=color
		style.border_color=border
		style.set_corner_radius_all(radius)
		if border.a>0: style.set_border_width_all(1)
		draw_style_box(style,rect)

	func draw_candle_slime() -> void:
		# Translucent jade wax, a dense colored center, and soft reflected candlelight.
		ellipse(Vector2(0,-11),Vector2(26,19),Color("354f50"))
		for i in range(10):
			var t := float(i)/9
			var color := Color("618b81").lerp(Color("a5c6ac"),t)
			ellipse(Vector2(-t*2,-10-t*5),Vector2(25-i*0.55,17-i*0.48),color)
		ellipse(Vector2(0,-13),Vector2(18,10),Color("92bcac"))
		for point in [Vector2(-15,-10),Vector2(13,-21),Vector2(7,-6)]:
			ellipse(point,Vector2(2.5,1.8),Color(0.8,0.95,0.82,0.36))
		ellipse(Vector2(-12,-23),Vector2(7,2.2),Color(0.9,1.0,0.84,0.38))
		for side in [-1,1]:
			ellipse(Vector2(side*7,-15),Vector2(3.3,4),Color("243c42"))
			draw_circle(Vector2(side*7-0.8,-16.3),1.0,Color("e8eed0"))
			draw_arc(Vector2(side*7,-20),3.5,PI+0.2,TAU-0.2,9,Color("4b7068"),1,true)
		draw_arc(Vector2(0,-9),4,0.1,PI-0.1,10,Color("345e58"),1.2,true)
		# A tarnished brass saucer and melted ivory candle with uneven wax runs.
		ellipse(Vector2(0,-31),Vector2(13,3.8),Color("493e36"))
		ellipse(Vector2(0,-33),Vector2(13,3.2),Color("aa8853"))
		ellipse(Vector2(-1,-34),Vector2(10,2),Color("e0c081"))
		rounded(Rect2(-6,-59,12,26),Color("c8aa7c"),3)
		rounded(Rect2(-5,-59,8,25),Color("e7cf9e"),3)
		rounded(Rect2(-4,-57,3,19),Color("f5e1b6"),2)
		for mark in [Vector2(-6,-54),Vector2(3,-53),Vector2(-1,-50)]:
			rounded(Rect2(mark,Vector2(3,9+mark.x*0.3)),Color("edd8ad"),2)
		ellipse(Vector2(0,-59),Vector2(6,2.3),Color("f2d9aa"))
		ellipse(Vector2(0,-59),Vector2(3,1.3),Color("917053"))
		draw_line(Vector2(0,-60),Vector2(1,-64),Color("473b36"),1.5,true)

	func draw_broom() -> void:
		# Walnut grain, tied straw and riveted blue-grey plate armor.
		draw_line(Vector2(0,-68),Vector2(0,-12),Color("4c3833"),8,true)
		draw_line(Vector2(-1,-68),Vector2(-1,-12),Color("b48e61"),5,true)
		draw_line(Vector2(-2,-66),Vector2(-2,-14),Color("d1ac74"),1.2,true)
		for y in [-63,-57,-23]:
			draw_line(Vector2(-2,y),Vector2(1,y+3),Color("6e4d3a"),1,true)
		draw_colored_polygon(PackedVector2Array([Vector2(-10,-24),Vector2(10,-24),Vector2(26,3),Vector2(17,7),Vector2(-18,7),Vector2(-26,3)]),Color("5e4937"))
		for i in range(15):
			var u := float(i)/14
			var from := Vector2(lerpf(-9,9,u),-24)
			var to := Vector2(lerpf(-24,24,u),3+sin(i*2.5)*2)
			var color := Color("a7804e").lerp(Color("e0c486"),1-absf(u-0.4))
			draw_line(from,to,color,2.5,true)
			draw_line(from+Vector2(1,6),to+Vector2(1,-2),Color(0.95,0.84,0.56,0.42),0.8,true)
		rounded(Rect2(-11,-24,22,7),Color("6a4d3b"),2)
		draw_line(Vector2(-10,-22),Vector2(10,-22),Color("c7a471"),1.2,true)
		draw_line(Vector2(-10,-19),Vector2(10,-19),Color("aa8257"),1.2,true)
		draw_colored_polygon(PackedVector2Array([Vector2(-16,-49),Vector2(-10,-57),Vector2(9,-57),Vector2(17,-49),Vector2(15,-29),Vector2(0,-23),Vector2(-15,-29)]),Color("34444e"))
		rounded(Rect2(-14,-52,28,24),Color("7e9ba4"),5,Color("c1c9bf"))
		draw_colored_polygon(PackedVector2Array([Vector2(-13,-51),Vector2(-8,-56),Vector2(7,-56),Vector2(13,-51)]),Color("b2c1bc"))
		draw_line(Vector2(-12,-48),Vector2(10,-48),Color("bfd0c6"),1.5,true)
		draw_line(Vector2(11,-46),Vector2(11,-32),Color("506b78"),2,true)
		rounded(Rect2(-11,-43,22,7),Color("273440"),2)
		draw_line(Vector2(-7,-40),Vector2(-2,-40),Color("f4ce83"),1.6,true)
		draw_line(Vector2(3,-40),Vector2(8,-40),Color("f4ce83"),1.6,true)
		for point in [Vector2(-11,-46),Vector2(11,-46),Vector2(-10,-31),Vector2(10,-31)]:
			draw_circle(point,1.5,Color("d8b56f"))
		draw_colored_polygon(PackedVector2Array([Vector2(0,-34),Vector2(3,-31),Vector2(0,-28),Vector2(-3,-31)]),Color("dec180"))
		# Folded cloth ribbon, deliberately small enough to preserve the silhouette.
		draw_colored_polygon(PackedVector2Array([Vector2(-3,-27),Vector2(-12,-27),Vector2(-17,-15),Vector2(-10,-18),Vector2(-8,-15)]),Color("8a5662"))

	func draw_bat() -> void:
		# Velvet fur, translucent ears, alert golden eyes and tiny hooked feet.
		ellipse(Vector2(0,1),Vector2(13,17),Color("3d374f"))
		for i in range(7):
			var t := float(i)/6
			ellipse(Vector2(-t,-t*2),Vector2(12-i*0.5,16-i*0.5),Color("514963").lerp(Color("8e81a1"),t))
		ellipse(Vector2(0,-2),Vector2(11,11),Color("6e668b"))
		for side in [-1,1]:
			draw_colored_polygon(PackedVector2Array([Vector2(side*3,-11),Vector2(side*10,-25),Vector2(side*14,-9)]),Color("51445f"))
			draw_colored_polygon(PackedVector2Array([Vector2(side*6,-12),Vector2(side*10,-21),Vector2(side*12,-10)]),Color("a8788e"))
			ellipse(Vector2(side*5,-6),Vector2(4,4.6),Color("292c3d"))
			ellipse(Vector2(side*5,-6),Vector2(2.8,3.5),Color("e3bf78"))
			draw_line(Vector2(side*5,-8),Vector2(side*5,-4),Color("302b3e"),1.2,true)
			draw_circle(Vector2(side*5-0.9,-7.1),0.8,Color("fff1c0"))
			draw_line(Vector2(side*5,12),Vector2(side*7,18),Color("c7af96"),1.3,true)
			draw_line(Vector2(side*7,18),Vector2(side*10,16),Color("dfcab1"),1.2,true)
		draw_colored_polygon(PackedVector2Array([Vector2(-2,-1),Vector2(2,-1),Vector2(0,2)]),Color("d19b96"))
		draw_arc(Vector2(0,1),4,0,PI,10,Color("28273a"),1,true)
		for side in [-1,1]:
			draw_colored_polygon(PackedVector2Array([Vector2(side*2,3),Vector2(side*4,3),Vector2(side*3,6)]),Color("e3d7bf"))
		draw_line(Vector2(-4,10),Vector2(0,13),Color("bca26d"),1,true)
		draw_line(Vector2(4,10),Vector2(0,13),Color("bca26d"),1,true)
		draw_circle(Vector2(0,13),2,Color("dbc38d"))

	func draw_wing() -> void:
		# Finger bones and scalloped leathery membrane are baked once, then flapped.
		var border := PackedVector2Array([Vector2.ZERO,Vector2(11,-15),Vector2(36,-30),Vector2(43,-26),Vector2(35,-5),Vector2(31,8),Vector2(23,3),Vector2(17,11),Vector2(10,5),Vector2(3,7)])
		draw_colored_polygon(border,Color("3c354b"))
		var membrane := PackedVector2Array([Vector2(2,0),Vector2(13,-12),Vector2(36,-27),Vector2(38,-25),Vector2(32,-4),Vector2(30,5),Vector2(23,0),Vector2(17,7),Vector2(10,2),Vector2(4,5)])
		draw_colored_polygon(membrane,Color("a292c1"))
		draw_colored_polygon(PackedVector2Array([Vector2(6,0),Vector2(34,-24),Vector2(27,-5),Vector2(23,0),Vector2(17,6),Vector2(10,2)]),Color("796b91"))
		for tip in [Vector2(36,-27),Vector2(30,5),Vector2(17,7)]:
			draw_line(Vector2(2,0),tip,Color("c3aecb"),1.3,true)
		draw_line(Vector2(1,0),Vector2(12,-14),Color("d7c0ce"),2,true)
		draw_line(Vector2(12,-14),Vector2(36,-28),Color("d7c0ce"),1.7,true)
		for i in range(8):
			var p := Vector2(14+i*2,-7-i*1.4)
			draw_line(p,p+Vector2(3,4),Color(0.86,0.76,0.88,0.25),0.7,true)
