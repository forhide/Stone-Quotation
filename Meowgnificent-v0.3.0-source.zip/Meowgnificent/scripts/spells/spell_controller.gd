class_name SpellController
extends Node

signal spell_emitted(outcome: String, point: Vector2)
var config: Dictionary
var resolver := SpellOutcomeResolver.new()
var cooldown := 0.0
var player: WizardCat
var room: Node2D
var last_outcome := ""
var pending := false
var prepare_time := 0.0
var pending_direction := Vector2.RIGHT

func _physics_process(delta: float) -> void:
	if not player.active:
		return
	cooldown = maxf(0.0,cooldown-delta)
	if pending:
		if player.roll_time>0:
			pending=false
			player.cast_prepare=0
			cooldown=minf(cooldown,0.2)
		else:
			prepare_time=maxf(0,prepare_time-delta)
			player.cast_prepare=prepare_time
			if prepare_time<=0:
				pending=false
				_emit_spell(pending_direction)
	if player.active and Input.is_action_pressed("cast"):
		cast(player.aim)

func cast(direction: Vector2) -> bool:
	if not player.active or player.roll_time>0 or pending or cooldown > 0:
		return false
	cooldown = float(config.cooldown)
	last_outcome = resolver.resolve(config)
	pending=true
	prepare_time=0.12
	pending_direction=direction.normalized()
	player.cast_aim=pending_direction
	player.cast_prepare=prepare_time
	return true

func _emit_spell(direction: Vector2) -> bool:
	player.cast_prepare=0
	player.cast_outcome=last_outcome
	player.cast_pose=1.0
	var launch := direction.normalized()
	var projectile := SpellProjectile.new()
	projectile.outcome = last_outcome
	projectile.speed = float(config.speed)
	projectile.lifetime = float(config.lifetime)
	projectile.damage = int(config.success_damage)
	if last_outcome == "miscast":
		projectile.damage = int(config.miscast_damage)
		projectile.speed *= 0.72
		projectile.lifetime = 1.3
		projectile.radius = 6.0
		var variant := resolver.rng.randi_range(0,2)
		if variant == 2:
			room.ignite_floor(player.position)
			player.start_roll(-launch,true)
			room.tell("HOT PAWS! That was supposed to go forward.",Color("ffac8f"))
			room.apply_miscast_blast(player.position,int(config.miscast_damage),80.0,Vector2.ZERO)
			projectile.free()
			spell_emitted.emit(last_outcome,player.position)
			return true
		var angle := resolver.rng.randf_range(70.0,110.0) if variant == 0 else 180.0
		launch = launch.rotated(deg_to_rad(angle))
		player.recoil=-launch*220
		room.tell("Wrong way. Make it look intentional.",Color("ffac8f"))
	elif last_outcome == "overreaction":
		projectile.damage = int(config.overreaction_damage)
		projectile.radius = 23.0
		projectile.speed *= 0.75
		player.recoil=-launch*310
		room.tell("Excellent spell. Unexpected recoil.",Color("ffdc8b"))
		projectile.explosion_radius = float(config.explosion_radius)
	projectile.direction = launch
	projectile.room = room
	projectile.bounds = player.bounds
	projectile.position = player.position+launch*33
	projectile.impacted.connect(room.apply_miscast_blast if last_outcome=="miscast" else room.apply_blast)
	room.projectiles.add_child(projectile)
	spell_emitted.emit(last_outcome,player.position)
	return true
