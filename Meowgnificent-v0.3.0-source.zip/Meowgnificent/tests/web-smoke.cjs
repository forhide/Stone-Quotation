const {chromium}=require('playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try {
 const page=await browser.newPage({viewport:{width:1280,height:800}});
 const errors=[]; const logs=[]; const failed=[];
 page.on('pageerror',e=>errors.push(e.message));
 page.on('console',m=>{logs.push(m.text());if(m.type()==='error')errors.push(m.text())});
 page.on('response',r=>{if(r.status()>=400)failed.push([r.status(),r.url()])});
 await page.goto(process.env.GAME_URL || 'http://127.0.0.1:8081/',{waitUntil:'networkidle'});
 await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});
 await page.waitForTimeout(1500);
 assert.equal(await page.title(),'Meowgnificent the wizard cat');
 await page.screenshot({path:'/tmp/meowgnificent-web-intro.png'});
 await page.locator('#canvas').click({position:{x:640,y:490}});
 await page.keyboard.press('Enter');
 await page.mouse.move(1000,300);
 await page.keyboard.down('d');await page.waitForTimeout(200);await page.keyboard.up('d');
 await page.keyboard.press('F3');
 await page.keyboard.press('Space');
 await page.waitForTimeout(160);
 await page.screenshot({path:'/tmp/meowgnificent-web-play.png'});
 await page.keyboard.press('Escape');
 await page.waitForTimeout(100);
 await page.screenshot({path:'/tmp/meowgnificent-web-pause.png'});
 assert.deepEqual(failed,[],'all web assets load');
 assert.deepEqual(errors,[],'no browser/engine console errors');
 assert(logs.some(l=>l.includes('Godot Engine')),'exported Godot engine starts');
 console.log('PASS: exported WebAssembly engine starts, assets load, canvas renders; start/move/forced cast/pause inputs sent; screenshots captured; no JS/console errors');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
