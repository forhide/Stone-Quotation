class_name EquipmentArt
extends RefCounted

# Every inventory/drop/worn icon shares one of four imported HD atlases.
const SHEET: Texture2D = preload("res://art/equipment/cute_equipment.png")
const WEAPON_SHEET: Texture2D = preload("res://art/equipment/cute_weapons.png")
const PENDANT_SHEET: Texture2D = preload("res://art/equipment/cute_pendants.png")
const CHARM_SHEET: Texture2D = preload("res://art/equipment/cute_charms.png")
const NEW_WEAPONS := ["practice_wand", "frost_whisker_wand", "hopscotch_wand", "pip_feather_staff", "moss_bud_staff", "bloop_bottle_wand", "thunder_spoon", "bubble_teapot", "comet_crayon"]
const NEW_COLLARS := ["linen_star_collar", "acorn_bell_collar", "button_bow_collar", "frost_drop_collar", "moss_heart_collar", "bloop_locket_collar", "thunder_key_collar", "bubble_pearl_collar", "comet_medal_collar"]
const NEW_CHARMS := ["paper_pinwheel", "clover_leaf", "sleepy_acorn", "frost_button", "pip_egg", "moss_seed_pouch", "bloop_cork", "thunder_marble", "comet_stamp"]
const RECTS := {
 "crooked_ash_wand":Rect2(60,29,343,463),
 "cinderfork_wand":Rect2(481,15,343,484),
 "apprentice_thesis":Rect2(865,71,375,413),
 "brass_bell_collar":Rect2(26,525,380,326),
 "velvet_bell_collar":Rect2(442,527,373,324),
 "nine_lives_collar":Rect2(845,525,388,335),
 "loose_feather":Rect2(31,863,379,376),
 "warm_sardine_charm":Rect2(437,932,369,286),
 "moonlit_yarn":Rect2(862,899,374,350),
 "practice_wand":Rect2(95,40,295,424),
 "frost_whisker_wand":Rect2(497,26,333,437),
 "hopscotch_wand":Rect2(896,46,340,418),
 "pip_feather_staff":Rect2(76,450,327,424),
 "moss_bud_staff":Rect2(452,846,413,390),
 "bloop_bottle_wand":Rect2(493,449,355,436),
 "thunder_spoon":Rect2(885,504,359,348),
 "bubble_teapot":Rect2(929,847,310,384),
 "comet_crayon":Rect2(66,867,327,363),
 "linen_star_collar":Rect2(62,56,324,352),
 "acorn_bell_collar":Rect2(484,57,324,361),
 "button_bow_collar":Rect2(852,87,374,336),
 "frost_drop_collar":Rect2(94,850,249,371),
 "moss_heart_collar":Rect2(100,453,250,381),
 "bloop_locket_collar":Rect2(485,475,299,356),
 "thunder_key_collar":Rect2(473,856,329,366),
 "bubble_pearl_collar":Rect2(914,454,270,384),
 "comet_medal_collar":Rect2(902,874,315,343),
 "paper_pinwheel":Rect2(68,31,355,419),
 "clover_leaf":Rect2(472,58,341,388),
 "sleepy_acorn":Rect2(904,52,315,390),
 "frost_button":Rect2(71,465,304,367),
 "pip_egg":Rect2(74,838,301,376),
 "moss_seed_pouch":Rect2(482,852,289,354),
 "bloop_cork":Rect2(502,466,287,365),
 "thunder_marble":Rect2(895,462,323,377),
 "comet_stamp":Rect2(892,857,336,377)
}
const ORIGINAL_PENDANTS := {
 "brass_bell_collar":Rect2(132,714,148,140),
 "velvet_bell_collar":Rect2(550,714,149,140),
 "nine_lives_collar":Rect2(962,714,145,151)
}
static var _icons: Dictionary = {}

static func has_icon(id: String) -> bool:
 return RECTS.has(id)

static func slot_for(id: String) -> String:
 if not has_icon(id): return ""
 if NEW_WEAPONS.has(id) or id in ["crooked_ash_wand","cinderfork_wand","apprentice_thesis"]: return "wand"
 if NEW_COLLARS.has(id) or ORIGINAL_PENDANTS.has(id): return "collar"
 return "charm"

static func _sheet_for(id: String) -> Texture2D:
 if NEW_WEAPONS.has(id): return WEAPON_SHEET
 if NEW_COLLARS.has(id): return PENDANT_SHEET
 if NEW_CHARMS.has(id): return CHARM_SHEET
 return SHEET

static func icon(id: String) -> Texture2D:
 if not has_icon(id): return null
 if not _icons.has(id):
  var texture := AtlasTexture.new()
  texture.atlas=_sheet_for(id)
  texture.region=RECTS[id]
  texture.filter_clip=true
  _icons[id]=texture
 return _icons[id]

# Original collars show only their pendant on the character. New collar art is
# authored as small pendants already, so it never places a strap across the face.
static func worn_icon(id: String) -> Texture2D:
 if not has_icon(id): return null
 if not ORIGINAL_PENDANTS.has(id): return icon(id)
 var key := "worn:"+id
 if not _icons.has(key):
  var texture := AtlasTexture.new()
  texture.atlas=SHEET
  texture.region=ORIGINAL_PENDANTS[id]
  texture.filter_clip=true
  _icons[key]=texture
 return _icons[key]

static func attachment_layout(id: String) -> Dictionary:
 var slot := slot_for(id)
 if slot.is_empty(): return {}
 var texture := worn_icon(id)
 var box := Vector2(42,52)
 var angle := -0.12
 if slot=="collar":
  box=Vector2(14,17)
  angle=0.0
 elif slot=="charm":
  box=Vector2(24,26)
  angle=-0.25
 elif id=="apprentice_thesis":
  box=Vector2(39,41)
 elif id=="bubble_teapot":
  box=Vector2(44,43)
  angle=-0.03
 elif id=="bloop_bottle_wand":
  box=Vector2(38,44)
 var source_size := texture.get_size()
 var factor := minf(box.x/source_size.x,box.y/source_size.y)
 return {"slot":slot,"extent":source_size*factor,"angle":angle}
