extends SceneTree
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func frames(n: int=3) -> void:
 for i in range(n):
  await physics_frame
  await process_frame
func run() -> void:
 change_scene_to_file("res://scenes/main.tscn")
 await frames()
 var room=current_scene
 room.begin_or_restart()
 room.set_physics_process(false)
 for enemy in room.enemies: enemy.active=false
 room.player.health.current=37
 var inventory_before: Array=room.run.inventory.duplicate()
 var equipment_before: Dictionary=room.run.equipment.duplicate()
 var gold_before: int=room.run.gold
 room.skills.cooldown_remaining=3.0
 room.skills.set_physics_process(false)
 var baseline := CharacterStats.for_room(room)
 for id: String in room.run.catalog:
  var preview := CharacterStats.for_room(room,id)
  check(room.run.inventory==inventory_before and room.run.equipment==equipment_before and room.run.gold==gold_before and room.player.health.current==37 and room.skills.cooldown_remaining==3.0,"preview cannot equip, purchase, heal or reset cooldown: "+id)
  var candidate: Dictionary=room.run.catalog[id]
  check(preview.equipment[str(candidate.slot)]==id,"preview replaces only the candidate equipment slot: "+id)
  if not room.run.inventory.has(id): room.run.inventory.append(id)
  room.equip_gear(id)
  var actual := CharacterStats.for_room(room)
  check(actual==preview and room.player.config.speed==preview.speed and room.player.health.maximum==preview.max_hp and room.spells.config.success_damage==preview.spell_damage and is_equal_approx(room.spells.config.cooldown,preview.spell_cooldown) and room.pickup_radius==preview.pickup_radius,"preview equals equipped gameplay values: "+id)
  room.run.inventory.assign(inventory_before)
  room.run.equipment=equipment_before.duplicate()
  room.apply_equipment()
 check(room.player.health.current==37,"swapping maximum-vitality gear never heals the player")
 var recovery: Dictionary=CharacterStats.ROWS[3]
 check(CharacterStats.improvement(recovery,{"spell_cooldown":0.8},{"spell_cooldown":0.6})==1 and CharacterStats.improvement(recovery,{"spell_cooldown":0.8},{"spell_cooldown":1.0})==-1,"shorter recovery is better even though the numerical delta is negative")
 check(CharacterStats.improvement(CharacterStats.ROWS[2],{"spell_damage":20},{"spell_damage":25})==1,"higher damage is a positive improvement")
 check(CharacterStats.for_room(room,"missing-id")==baseline,"unknown preview identifiers cannot manufacture equipment or stats")
 room.open_inventory()
 await frames()
 room.panel._preview_item("cinderfork_wand")
 await frames()
 check(room.panel.stats_container.get_child_count()>10 and room.panel.preview_item_id=="cinderfork_wand","the real inventory exposes all ten stats and a selected comparison")
 check(room.state=="inventory" and not room.player.active,"comparison leaves combat paused")
 room.close_panel()
 for lang in ["ko","en"]:
  GameLocale.set_language(lang,false)
  for index in range(8):
   room.load_sector(index)
   room.hud._process(0)
   await frames(2)
   var title: Label=room.hud.destination_label
   var identity: Label=room.hud.identity_label
   check(title.get_global_rect().end.y<=115 and identity.get_global_rect().end.y<=115 and title.get_global_rect().end.x<417,"stage title and identity remain within the combat header: "+lang+str(index))
   var font: Font=title.get_theme_font("font")
   check(font.get_string_size(GameLocale.text(str(room.stage_def.name)),HORIZONTAL_ALIGNMENT_LEFT,-1,title.get_theme_font_size("font_size")).x<=title.size.x,"full translated stage name fits the title cell: "+lang+str(index))
  room.open_inventory()
  await frames()
  check(room.panel.close_button.get_global_rect().end.y<800 and room.panel.stats_container.get_global_rect().end.y<room.panel.close_button.global_position.y,"all ten stats and the return button fit the viewport: "+lang)
  room.close_panel()
 print("CHARACTER STATS RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
