const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');

(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 let checks=0;
 try {
 const context=await browser.newContext({viewport:{width:1280,height:800}});
 const page=await context.newPage();
 const errors=[];const logs=[];const failed=[];
 page.on('pageerror',e=>errors.push(e.message));
 page.on('console',m=>{logs.push(m.text());if(m.type()==='error')errors.push(m.text())});
 page.on('response',r=>{if(r.status()>=400)failed.push([r.status(),r.url()])});
 function check(ok,name){assert(ok,name);checks++;console.log('PASS: '+name)}
 function textFrom(path){
  let extra='';
  if(path.endsWith('-legacy.png')||path.endsWith('-reloaded.png')){
   const crop=path.replace('.png','-counter.png');
   execFileSync('python3',['-c','from PIL import Image,ImageOps,ImageEnhance; import sys; im=ImageEnhance.Contrast(ImageOps.autocontrast(Image.open(sys.argv[1]).crop((130,176,1115,234)).convert("L"))).enhance(2); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,crop]);
   extra=execFileSync('tesseract',[crop,'stdout','--psm','6'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
  }
  if(path.endsWith('-arrival.png')){
   const crop=path.replace('.png','-ocr.png');
   execFileSync('python3',['-c','from PIL import Image,ImageOps,ImageEnhance; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((350,126,930,238)).convert("L")); im=ImageEnhance.Contrast(im).enhance(2); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,crop]);
   path=crop;
  }
  return extra+'\n'+execFileSync('tesseract',[path,'stdout','--psm','11'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
 }
 async function screenshot(name){
  const path='/tmp/meowgnificent-v0100-web-'+name+'.png';
  await page.screenshot({path});
  return path;
 }
 async function expectScreen(name,predicate,description){
  let text='';
  for(let attempt=0;attempt<20;attempt++){
   await page.waitForTimeout(150);
   text=textFrom(await screenshot(name));
   if(predicate(text)){check(true,description);return text}
  }
  assert.fail(description+'; last canvas OCR: '+JSON.stringify(text));
 }
 async function ready(){
  await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});
  await page.waitForTimeout(700);
 }
 const gameUrl=new URL(process.env.GAME_URL || 'http://127.0.0.1:8082/');gameUrl.searchParams.set('skip_story','1');gameUrl.searchParams.set('lang','en');
 await page.goto(gameUrl.href,{waitUntil:'networkidle'});
 await ready();
 check(await page.title()==='Meowgnificent the wizard cat','exported web page has the game title');
 await expectScreen('intro',t=>t.includes('a minor magical incident'),'WASM canvas renders the expedition start screen');
 await page.locator('#canvas').click({position:{x:200,y:680}});
 await page.keyboard.press('m');
 await expectScreen('legacy',t=>t.includes('legacy study') && /\b[0o]\s*expeditions\b/.test(t),'a fresh browser context starts with zero recorded expeditions');
 await page.keyboard.press('Escape');
 await expectScreen('intro',t=>t.includes('a minor magical incident') && !t.includes('legacy study'),'Escape closes legacy studies and returns to the start screen');
 await page.keyboard.press('Enter');
 await expectScreen('arrival',t=>/entering\s+area\s+0?1/.test(t) && t.includes('detention'),'starting the expedition prominently announces entry into area 01');
 await page.keyboard.press('i');
 await expectScreen('equipment',t=>t.includes('traveling possessions') && t.includes('character stats') && t.includes('primary tool') && t.includes('practice wand') && t.includes('satchel'),'Enter starts the expedition and I opens the real equipment panel');
 await page.keyboard.press('Escape');
 await page.mouse.move(1000,300);
 await page.keyboard.down('d');await page.waitForTimeout(200);await page.keyboard.up('d');
 await page.keyboard.press('F3');
 await page.keyboard.press('Space');
 await page.waitForTimeout(160);
 const playPath=await screenshot('play');
 await page.keyboard.press('Escape');
 await expectScreen('pause',t=>t.includes('taking a catnap'),'Escape closes equipment and the game can cast, move and pause');
 const playText=textFrom(playPath);
 check(playText.includes('passage locked') && !playText.includes('traveling possessions') && !playText.includes('taking a catnap'),'play screenshot shows the active expedition rather than a menu');
 await page.keyboard.press('r');
 await expectScreen('intro',t=>t.includes('a minor magical incident'),'R ends the current expedition and restores the start screen');
 await page.keyboard.press('m');
 await expectScreen('legacy',t=>t.includes('legacy study') && /\b[1il]\s*expeditions\b/.test(t),'legacy studies record the completed attempt before a browser reload');
 await page.keyboard.press('Escape');
 // Give Godot's asynchronous IDBFS synchronization time to persist the save.
 await page.waitForTimeout(3000);
 await page.reload({waitUntil:'networkidle'});
 await ready();
 await expectScreen('intro',t=>t.includes('a minor magical incident'),'a full page reload starts a new WASM engine at the start screen');
 await page.locator('#canvas').click({position:{x:200,y:680}});
 await page.keyboard.press('m');
 await expectScreen('reloaded',t=>t.includes('legacy study') && /\b[1il]\s*expeditions\b/.test(t),'the saved expedition count survives a full browser reload through IDBFS');
 check(logs.filter(l=>l.includes('Godot Engine')).length>=2,'both original and reloaded exported Godot engines started');
 check(failed.length===0,'all web assets load without HTTP failures');
 check(errors.length===0,'browser and exported engine have no JavaScript/console errors: '+JSON.stringify(errors));
 console.log(`WEB RESULT: ${checks} checks, 0 failures`);
 console.log('Scope: real canvas/OCR start, inventory, movement/cast inputs, pause, legacy study and persistent attempt count after a full page reload; no web campaign-clear or permanent-upgrade purchase claim.');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
