#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
CHECK_LOG="$(mktemp)"
TEST_PROFILE_DIR="$(mktemp -d)"
export MEOW_SKIP_STORY=1
export MEOW_LANGUAGE=en
export MEOW_SETTINGS_PATH="$TEST_PROFILE_DIR/settings.cfg"
export MEOW_PROFILE_PATH="$TEST_PROFILE_DIR/profile.json"
trap 'rm -f "$CHECK_LOG"; rm -rf "$TEST_PROFILE_DIR"' EXIT
run_check() {
  local check_status=0
  "$PROJECT_DIR/run.sh" "$@" > "$CHECK_LOG" 2>&1 || check_status=$?
  cat "$CHECK_LOG"
  if (( check_status != 0 )) || rg -q 'SCRIPT ERROR:|ERROR:' "$CHECK_LOG"; then return 1; fi
}
run_check --headless --editor --import --quit
for SUITE in smoke regression accidents economy meta_progress expedition presentation grimoire grimoire_integration story localization_appearance grounded_gait telegraphs catalog_expansion item_skills pip_identity character_stats; do
  run_check --headless --script "res://tests/$SUITE.gd"
done
