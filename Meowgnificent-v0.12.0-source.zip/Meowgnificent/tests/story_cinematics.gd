extends SceneTree

var checks := 0
var failures := 0

func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(n: int=3) -> void:
	for i in range(n): await process_frame

func run() -> void:
	var director := StoryDirector.new()
	root.add_child(director)
	await frames()
	director.play_opening(Callable())
	director.auto_advance=false
	var stage=director.stage
	var indices := {}
	for i in range(director.pages.size()):
		var visual := str(director.pages[i].visual)
		if not indices.has(visual): indices[visual]=i
	for visual in ["academy","fire","reverse","boom","grades","detention"]:
		check(indices.has(visual),"authored opening includes the actual "+visual+" shot")
	director.page_index=int(indices.fire)
	director._show_page()
	check(stage.target_sprite.visible and stage.target_sprite.texture==stage.TARGET and stage.actor_ids==PackedStringArray(["professor"]),"the examination has a real painted target and grounded owl instructor")
	stage.time=0.2
	stage._animate_actors()
	var start: Vector2=stage.snapshot().flame
	var preparing: Texture2D=stage.hero.texture
	stage.time=2.4
	stage._animate_actors()
	var near_target: Vector2=stage.snapshot().flame
	check(near_target.x>start.x+220 and near_target.distance_to(StoryShot.TARGET.get_center())<start.distance_to(StoryShot.TARGET.get_center()),"the small forward flame visibly travels from the raised paw toward the bullseye")
	check(stage.hero.texture!=preparing and stage.hero.texture==stage.hero_frames[2],"preparation changes into the actual casting pose as the forward spell leaves")
	director.page_index=int(indices.reverse)
	director._show_page()
	stage.time=0
	var turn: Vector2=stage.snapshot().flame
	check(turn.distance_to(near_target)<0.1,"reverse shot starts at the forward shot's last flame position without teleporting")
	stage.time=0.8
	var curl: Vector2=stage.snapshot().flame
	stage.time=1.6
	var behind: Vector2=stage.snapshot().flame
	check(curl.y<turn.y and curl.x<turn.x and behind.x<stage.hero_rect.position.x,"the U-turn curls upward then passes behind the cat instead of merely swapping a still image")
	check(absf(stage.snapshot().heading)>2.4 and not stage.snapshot().target_hit and stage.target_sprite.visible,"the returning spell points backward and the original target remains intact")
	stage.time=1
	stage._animate_actors()
	var planted: Vector2=stage.snapshot().hero_feet
	stage.time=2
	stage._animate_actors()
	check(planted.distance_to(stage.snapshot().hero_feet)<0.1,"breathing and recoil pivot around planted feet rather than floating the whole actor")
	director.page_index=int(indices.boom)
	director._show_page()
	stage.time=0
	var burst: Dictionary=stage.snapshot()
	stage.time=1
	check(burst.blast>0.99 and stage.snapshot().blast==0 and burst.rear_blast.x<stage.hero_rect.position.x,"the rear impact has a timed light burst that settles into smoke")
	check(stage.target_sprite.visible and stage.snapshot().sooty and stage.snapshot().gameplay_objects==0,"the joke leaves the target standing and the cat singed without spawning combat hazards")
	director.show_chapter(1,Callable())
	director.auto_advance=false
	for i in range(3):
		director.page_index=i
		director._show_page()
		check(stage.exam_flashback and stage.exam_scene and stage.location_index==1 and not stage.location_backdrop.visible and stage.target_sprite.visible,"post-area1 replay is explicitly a memory of the exam, while route location stays library: "+str(i))
	director.page_index=3
	director._show_page()
	check(not stage.exam_flashback and not stage.target_sprite.visible and stage.location_backdrop.visible and stage.location_backdrop.stage_index==1,"after the replay, the camera returns to the actual library and removes the exam props")
	var shared_books: bool= stage.living_prop_kind=="book" and stage.living_props.size()==6
	for prop: TextureRect in stage.living_props: shared_books=shared_books and prop.visible and prop.texture==LivingStageArt.icon("book")
	check(shared_books,"the library tableau shows the same six living-book actors and cached artwork as combat")
	stage.time=2.7
	stage._animate_actors()
	var synchronized := true
	for prop: TextureRect in stage.living_props:
		synchronized=synchronized and prop.texture==LivingStageArt.icon("book_fold") and is_equal_approx(prop.position.y,stage.living_props[0].position.y)
	check(synchronized,"library books change pose together at the same height, acting out the Grimoire's control")
	director.show_chapter(2,Callable())
	var shared_mushrooms: bool= stage.living_prop_kind=="mushroom" and stage.living_props.size()==6
	for prop: TextureRect in stage.living_props: shared_mushrooms=shared_mushrooms and prop.visible and prop.texture==LivingStageArt.icon("mushroom")
	check(shared_mushrooms and stage.living_prop_rects[1].position-stage.living_prop_rects[0].position==Vector2(127,0) and stage.living_prop_rects[3].position-stage.living_prop_rects[0].position==Vector2(0,94),"garden's evenly spaced crop grid is made of the actual living reagent mushrooms")
	director.show_chapter(4,Callable())
	director.page_index=2
	director._show_page()
	check(stage.actor_ids==PackedStringArray(["pip","moss","bloop"]) and stage.group_portraits.size()==3 and stage.friend_frame.get_theme_stylebox("panel") is StyleBoxEmpty,"the friends act together in the environment without generic portrait cards")
	director.show_chapter(7,Callable())
	check(stage.location_backdrop.visible and stage.location_backdrop.stage_index==7 and not stage.target_sprite.visible,"the finale retains the actual Grand Archive instead of reusing the exam set")
	check(stage.actor_ids==PackedStringArray(["grimoire"]) and stage.friend_portrait.texture==GrimoireArt.icon("calm"),"the Grimoire speaks as the actual expressive book, with no animal proxy")
	director.page_index=1
	director._show_page()
	check(stage.grimoire_pose=="shocked" and stage.friend_portrait.texture==GrimoireArt.icon("shocked"),"failed prediction changes the cover and pages into the shared shocked-book pose")
	director.page_index=2
	director._show_page()
	check(stage.grimoire_pose=="angry" and stage.friend_portrait.texture==GrimoireArt.icon("angry"),"the perfect-wizard combat form is the same book becoming angry")
	director.play_ending(Callable())
	director.auto_advance=false
	var book_stays := true
	for i in range(6):
		director.page_index=i
		director._show_page()
		book_stays=book_stays and stage.actor_ids==PackedStringArray(["grimoire"]) and not stage.target_sprite.visible
	check(book_stays and stage.grimoire_pose=="damaged","the book remains in every final exchange and ends visibly damaged, rather than disappearing during the cat's spell")
	check(stage.snapshot().rear_blast.x>stage.actor_rect.get_center().x and not stage.snapshot().sooty,"the finale's failed spark explodes behind the Grimoire, and its visible damage belongs to the book")
	director.close()
	check(not director.is_open and not director.is_processing(),"closing a cinematic stops its animation and input flow")
	director.queue_free()
	await frames()
	print("STORY CINEMATICS RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
