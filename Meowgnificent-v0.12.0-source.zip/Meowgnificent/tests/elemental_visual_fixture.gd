extends SceneTree

# Controlled visual/performance fixture. The actual projectile classes draw at
# their normal gameplay size; only speed is held at zero so seven styles can be
# compared in one frame. Production gameplay does not show these test labels.
var room
var shots: Array[SpellProjectile] = []
var samples: Array[float] = []
var draw_samples: Array[int] = []
var elements := ["fire","water","ice","wind","stone","leaf","lightning"]
var frame_index := 0
var previous_time := 0
var output_dir := "res://docs/qa"
var performance := false
var all_fire := false

func _initialize() -> void: call_deferred("run")

func run() -> void:
 OS.set_environment("MEOW_SKIP_STORY","1")
 OS.set_environment("MEOW_PROFILE_PATH","/tmp/meow-elemental-visual-profile.json")
 OS.set_environment("MEOW_SETTINGS_PATH","/tmp/meow-elemental-visual-settings.cfg")
 performance=OS.get_environment("MEOW_ELEMENTAL_PERF")=="1"
 all_fire=OS.get_environment("MEOW_ELEMENTAL_ALL_FIRE")=="1"
 change_scene_to_file("res://scenes/main.tscn")
 for i in range(5): await process_frame
 room=current_scene
 room.begin_or_restart()
 room.load_sector(1)
 room.set_process(false)
 room.set_physics_process(false)
 room.player.set_physics_process(false)
 room.spells.set_physics_process(false)
 room.skills.set_physics_process(false)
 room.player.position=Vector2(200,470)
 room.run.add_item("frost_whisker_wand")
 room.equip_gear("frost_whisker_wand")
 for foe in room.enemies:
  if is_instance_valid(foe): foe.queue_free()
 room.enemies.clear()
 for prop in room.props:
  if is_instance_valid(prop): prop.queue_free()
 room.props.clear()
 room.exit_open=false
 room.hud._process(0)
 room.hud.set_process(false)
 room.hud.sector_banner.visible=false
 room.hud.incident_time=0
 room.hud.incident_label.text=""
 var tools := ["practice_wand","bloop_bottle_wand","frost_whisker_wand","pip_feather_staff","hopscotch_wand","moss_bud_staff","thunder_spoon"]
 for i in range(elements.size()):
  var point := Vector2(390+(i%4)*215,365+(i/4)*215)
  var shot := SpellProjectile.new()
  shot.room=room
  shot.bounds=room.bounds
  shot.position=point
  shot.configure_magic("fire" if all_fire else elements[i])
  shot.speed=0
  shot.lifetime=1000
  shot.direction=Vector2.RIGHT
  shot.age=0.25+i*0.09
  room.projectiles.add_child(shot)
  shots.append(shot)
  if not performance:
   var label := Label.new()
   label.position=point+Vector2(-65,24)
   label.size=Vector2(130,30)
   label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
   label.add_theme_font_override("font",GameLocale.STORY_FONT)
   label.add_theme_font_size_override("font_size",18)
   label.add_theme_color_override("font_color",Color("66535e"))
   label.text=GameLocale.text(str(BasicMagic.definition(elements[i]).name))
   room.add_child(label)
   var icon := TextureRect.new()
   icon.position=point+Vector2(-25,-109)
   icon.size=Vector2(50,58)
   icon.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
   icon.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
   icon.texture=EquipmentArt.icon(tools[i])
   room.add_child(icon)
 previous_time=Time.get_ticks_usec()
 for frame in range(220 if performance else 40):
  await RenderingServer.frame_post_draw
  var now := Time.get_ticks_usec()
  if frame>=40:
   samples.append(float(now-previous_time)/1000.0)
   draw_samples.append(int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)))
  previous_time=now
 if performance:
  var ordered := samples.duplicate()
  ordered.sort()
  var total := 0.0
  for value in samples: total+=value
  var draws := 0.0
  for value in draw_samples: draws+=value
  var result := {"fixture":"seven fire projectiles" if all_fire else "seven equipped primary magic families, normal size, stationary", "samples":samples.size(),"frame_ms":samples,"draw_calls":draw_samples,"mean_ms":total/maxi(1,samples.size()),"median_ms":ordered[ordered.size()/2],"p95_ms":ordered[floori((ordered.size()-1)*0.95)],"mean_draw_calls":draws/maxi(1,draw_samples.size()),"max_draw_calls":draw_samples.max()}
  var file := FileAccess.open("/tmp/meow-v012-elemental-fire-control.json" if all_fire else "/tmp/meow-v012-elemental-performance.json",FileAccess.WRITE)
  file.store_string(JSON.stringify(result,"  "))
  print("ELEMENTAL PERFORMANCE: "+JSON.stringify(result))
 else:
  var image := root.get_texture().get_image()
  var path := OS.get_environment("MEOW_ELEMENTAL_CAPTURE")
  if path.is_empty(): path="res://docs/qa/v0120-elemental-magic.png"
  image.save_png(path)
  print("ELEMENTAL CAPTURE: "+path)
 room.free()
 await process_frame
 quit()
