class_name GrimoireArt
extends RefCounted

# The antagonist is the enchanted book itself. Its leather cover is its face;
# pages and ribbon bookmarks supply expression without an animal stand-in.
const SHEET: Texture2D = preload("res://art/grimoire/perfect_grimoire.png")
const REGIONS := {
 "calm":Rect2(28,44,608,492),
 "angry":Rect2(634,26,610,541),
 "shocked":Rect2(22,657,657,544),
 "damaged":Rect2(686,632,523,583)
}
static var _icons: Dictionary = {}

static func region(pose: String="calm") -> Rect2:
 if pose=="alert": pose="angry"
 return REGIONS.get(pose,REGIONS.calm)

static func icon(pose: String="calm") -> Texture2D:
 if pose=="alert": pose="angry"
 if not REGIONS.has(pose): pose="calm"
 if not _icons.has(pose):
  var texture := AtlasTexture.new()
  texture.atlas=SHEET
  texture.region=region(pose)
  texture.filter_clip=true
  _icons[pose]=texture
 return _icons[pose]

static func identity() -> String:
 return "sentient_grimoire"
