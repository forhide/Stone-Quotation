class_name ExpeditionMarkers
extends Node2D

const EXIT_POSITION := Vector2(1136,430)
const SHOP_POSITION := Vector2(640,315)
const GATE_CLOSED: Texture2D = preload("res://art/items/archive_gate_closed.svg")
const GATE_OPEN: Texture2D = preload("res://art/items/archive_gate_open.svg")
const MERCHANT_ID := "pip"
const MERCHANT_NAME := "Pip"
const MERCHANT_TITLE := "Pip's Finds"
# Story portraits, the field merchant and the shop now share animal Pip.
const MERCHANT_ART: Texture2D = AnimalCast.SHEET
const MERCHANT_REGION: Rect2 = AnimalCast.REGIONS["pip"]
const MERCHANT_PORTRAIT_REGION: Rect2 = MERCHANT_REGION
const ROUTE_ART: Texture2D = preload("res://art/items/archive_route.svg")

var room: Node2D
var _signature := ""
var _stage_index := 0
var _sector_name := "The Candlewick Archives"
var _kind := "combat"
var _exit_open := false
var _exit_near := false
var _shop_near := false
var merchant_root: Node2D
var merchant_sprite: Sprite2D
var merchant_time := 0.0
var gathering: ShopGathering

func _ready() -> void:
	# Storybook garden gate and Pip's little stall stay behind living actors.
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	z_index=-2
	gathering=ShopGathering.new()
	add_child(gathering)
	_create_merchant()
	update_visuals()

func _create_merchant() -> void:
	merchant_root=Node2D.new()
	merchant_root.name="PipMerchant"
	# Feet meet the far table edge; the interaction anchor remains compatible.
	merchant_root.position=SHOP_POSITION+Vector2(0,70)
	add_child(merchant_root)
	merchant_sprite=Sprite2D.new()
	merchant_sprite.name="PipAndChicken"
	merchant_sprite.texture=AnimalCast.icon("pip")
	merchant_sprite.centered=false
	merchant_sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	var factor := 144.0/MERCHANT_REGION.size.y
	merchant_sprite.scale=Vector2.ONE*factor
	merchant_sprite.position=Vector2(-MERCHANT_REGION.size.x*factor*0.5,-144)
	merchant_root.add_child(merchant_sprite)
	merchant_root.visible=false

func _process(delta: float) -> void:
	if _kind!="shop" or not is_instance_valid(room) or room.state!="playing": return
	merchant_time+=delta
	# The feet stay at the same anchor. Only a barely visible breath passes
	# through the soft cape and the chicken held in Pip's arm.
	var reaction := gathering.reaction_for("pip") if is_instance_valid(gathering) else 0.0
	merchant_root.scale=Vector2(1+reaction*0.025,1+sin(merchant_time*2.2)*0.007-reaction*0.018)
	merchant_root.rotation=sin(merchant_time*7.0)*0.035*reaction
	if is_instance_valid(gathering):
		gathering.set_player_position(room.player.position)
		gathering.animate(delta)

func is_shop_near(point: Vector2) -> bool:
	return _kind=="shop" and (point.distance_to(SHOP_POSITION)<120 or point.distance_to(ShopGathering.TABLE_POSITION)<165)

func merchant_snapshot() -> Dictionary:
	return {"id":MERCHANT_ID,"name":MERCHANT_NAME,"species":AnimalCast.species("pip"), "visible":is_instance_valid(merchant_root) and merchant_root.visible,
		"anchor":SHOP_POSITION,"feet":merchant_root.position if is_instance_valid(merchant_root) else Vector2.ZERO,
		"texture":merchant_sprite.texture if is_instance_valid(merchant_sprite) else null,"portrait_region":MERCHANT_PORTRAIT_REGION}

func update_visuals() -> void:
	if not is_instance_valid(room) or room.run==null:
		return
	var stage_index := int(room.run.stage_index)
	var sector_name := str(room.stage_def.get("name","The Candlewick Archives"))
	var kind := str(room.stage_def.get("kind","combat"))
	var exit_open := bool(room.exit_open)
	var exit_near := false
	var shop_near := false
	if is_instance_valid(room.player):
		exit_near=room.player.position.distance_to(EXIT_POSITION)<86
		shop_near=kind=="shop" and (room.player.position.distance_to(SHOP_POSITION)<120 or room.player.position.distance_to(ShopGathering.TABLE_POSITION)<165)
	var signature := GameLocale.text("%d|%s|%s|%s|%s|%s") % [stage_index,sector_name,kind,exit_open,exit_near,shop_near]
	signature+=GameLocale.current
	if signature==_signature:
		return
	_signature=signature
	_stage_index=stage_index
	_sector_name=sector_name
	_kind=kind
	_exit_open=exit_open
	_exit_near=exit_near
	_shop_near=shop_near
	if is_instance_valid(merchant_root): merchant_root.visible=_kind=="shop"
	if is_instance_valid(gathering): gathering.configure(stage_index,_kind=="shop")
	queue_redraw()

func _centered(text: String, at: Vector2, size: int, color: Color) -> void:
	text=GameLocale.text(text)
	var width := ThemeDB.fallback_font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
	draw_string(ThemeDB.fallback_font,at-Vector2(width*0.5,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _draw() -> void:
	var gate := GATE_OPEN if _exit_open else GATE_CLOSED
	draw_texture_rect(gate,Rect2(EXIT_POSITION+Vector2(-52,-170),Vector2(104,178)),false)
	var prompt := "E  ·  Next area" if _exit_open else "Defeat foes to unlock"
	var color := Color("5d746a") if _exit_open else Color("8c737d")
	if _exit_open and _exit_near:
		color=Color("586e63")
	draw_style_box(_plate(Color("fff1d6")),Rect2(1041,449,190,32))
	_centered(prompt,Vector2(1136,470),13,color)
	if _exit_open and not _exit_near:
		_centered("ARCHIVE PASSAGE",Vector2(1136,493),10,Color("79616b"))
	if _kind=="shop":
		draw_set_transform(merchant_root.position+Vector2(0,4),0,Vector2(1,0.28))
		draw_circle(Vector2.ZERO,33,Color(0.39,0.33,0.31,0.16))
		draw_set_transform(Vector2.ZERO)
		_centered(MERCHANT_TITLE,Vector2(640,205),19,Color("735b67"))
		draw_style_box(_plate(Color("fff1d6")),Rect2(535,598,210,31))
		_centered("E  ·  Browse shop",Vector2(640,619),15,Color("586e63") if _shop_near else Color("79616b"))
	# One imported route texture replaces sixteen separate line/circle commands.
	draw_texture_rect(ROUTE_ART,Rect2(340,654,600,24),false)
	var current_x := 352+clampi(_stage_index,0,7)*(576.0/7.0)
	if _stage_index>0:
		draw_line(Vector2(352,666),Vector2(current_x,666),Color("a5c7b4"),2,true)
	draw_circle(Vector2(current_x,666),5,Color("b37c87"))
	_centered(GameLocale.text("%02d / 08  ·  %s") % [_stage_index+1,GameLocale.text(_sector_name)],Vector2(640,644),13,Color("735b67"))

func _plate(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=Color("b6a092")
	style.set_border_width_all(1)
	style.set_corner_radius_all(10)
	return style
