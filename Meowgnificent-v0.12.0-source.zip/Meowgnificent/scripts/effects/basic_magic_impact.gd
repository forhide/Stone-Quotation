class_name BasicMagicImpact
extends Node2D

# A short hand-drawn splash, snowflake, breeze or pebble ring. No particle
# emitters, per-frame texture creation or timers: at most a few small shapes.
var element := "water"
var size := 1.0
var age := 0.0
const DURATION := 0.34

func _ready() -> void:
 texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func _physics_process(delta: float) -> void:
 age+=delta
 if age>=DURATION:
  queue_free()
  return
 queue_redraw()

func _draw() -> void:
 var progress := clampf(age/DURATION,0,1)
 var ink := BasicMagic.color(element)
 ink.a=(1-progress)*0.8
 draw_set_transform(Vector2(0,-20),0,Vector2.ONE*size)
 if element=="water":
  draw_set_transform(Vector2(0,-20),0,Vector2(1,0.48)*size)
  draw_arc(Vector2.ZERO,8+progress*28,0,TAU,20,ink,2.2,true)
 elif element=="wind":
  draw_arc(Vector2.ZERO,8+progress*23,progress*TAU,progress*TAU+4.6,15,ink,2.0,true)
 elif element=="ice":
  for i in range(3):
   var direction := Vector2.from_angle(i*PI/3)
   draw_line(-direction*(4+progress*14),direction*(4+progress*14),ink,2,true)
 else:
  for i in range(5):
   var point := Vector2.from_angle(i*TAU/5)*(7+progress*21)
   draw_circle(point,2.5*(1-progress)+0.6,ink)
 draw_set_transform(Vector2.ZERO)
