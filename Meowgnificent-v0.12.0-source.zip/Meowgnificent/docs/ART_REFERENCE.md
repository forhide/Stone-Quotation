# 기본형 캐릭터 아트 — v0.1.2

## 실제 사용한 기준

사용자가 채팅으로 제공한 기본형 사진을 기준으로 새 투명 배경 캐릭터 일러스트를 생성했습니다. 원본 사진 자체를 게임 텍스처로 잘라 쓰지 않았습니다. 새 파일은 `art/characters/meowgnificent.png`입니다.

추가 자료로 지정한 계정: https://www.instagram.com/fatchonkywizardcat/
계정에 직접 접속하는 것은 현재 403으로 차단되어 있습니다. 대신 사용자가 제공한 **계정 그리드 캡처**를 추가 기준으로 사용했습니다. 캡처의 실사 사진에서 넓고 납작한 볼, 작은 귀와 눈, 분홍 코, 큰 검은 금속 방울, 졸린 얼굴·심드렁한 눈·입을 벌린 표정을 참고했습니다. 왼쪽 위 커플 만화, 배경 거리, 사람 손, 인스타그램 UI는 게임에 넣지 않았습니다.

## 기본형에서 살린 특징

| 요소 | 적용한 표현 |
| --- | --- |
| 체형 | 거의 직립한 배 모양 몸, 커다랗게 처진 배, 밑에 살짝 보이는 짧은 발 |
| 털 | 주황·황갈색 줄무늬, 크림색 얼굴과 주둥이, 배를 가로지르는 무늬, 세밀한 털 결 |
| 얼굴 | 넓고 둥근 얼굴, 작은 자연스러운 눈, 분홍 코, 흰 수염, 담담하고 약간 엄격한 표정 |
| 모자 | 짙은 차콜색의 높은 낡은 모자, 넓고 찌그러진 챙, 구부러진 끝, 마모된 천 질감 |
| 목줄 | 단순한 검은 목줄과 작은 금속 방울 |
| 지팡이 | 화면 왼쪽 앞발이 잡은 가늘고 불규칙한 나무 지팡이 |
| 의상 | 옷이나 갑옷 없이 고양이 몸 자체를 노출 |

기존 보라색 모자·금색 띠·별 장식·단순 도형 얼굴을 교체했습니다. 얼굴·털·모자·지팡이는 한 장의 자세한 전신 일러스트에 포함됩니다. 시작 화면은 왼쪽에 확대 전신을 보여주고 안내 패널은 오른쪽에 배치합니다. 전투에서는 발 좌표 기준으로 크기를 줄여 표시합니다.

## 초기 게임 통합 — v0.1.1

- `WizardCatVisual`이 투명 여백을 읽어 발 기준으로 Sprite2D를 배치합니다.
- `player.sprite_height`로 전투 표시 크기를 조정합니다.
- 이동 시 전체 몸을 살짝 기울이고 상하로 흔들어 무게감을 표현합니다.
- 가만히 있을 때 작은 호흡 움직임, 캐스팅 때 미세한 스쿼시와 지팡이 빛이 있습니다.
- 무적 시간에는 캐릭터 전체가 깜빡입니다. 시각적 몸 크기와 실제 충돌 반경은 구분되어 있습니다.

## 현재 한계

현재는 v0.2.1에서 추가한 여섯 전신 키포즈를 사용합니다. 8방향 개별 그림, 팔다리·모자의 분리 리깅, 방향별 다프레임 걷기 시트는 없습니다. 얼굴은 사진의 특징을 바탕으로 새로 그린 표현으로, 사진과 픽셀 단위로 같지는 않습니다. 새로운 네 가지 **초상화**는 제공된 계정 캡처와 기존 전신 그림을 함께 참조해 생성한 `art/characters/expressions.png`입니다. 원계정 전체나 캡처에 보이지 않는 게시물을 확인한 것은 아닙니다.


## v0.1.2 표정 피드백

전신 그림은 유지하고 HUD·시작/종료 메뉴에 네 가지 표정 초상화를 추가했습니다. 2×2 시트는 왼쪽 위 기본, 오른쪽 위 심드렁함, 왼쪽 아래 졸림, 오른쪽 아래 놀람 순서입니다. Godot의 AtlasTexture로 읽으며 원본 PNG를 잘라 수정하지 않습니다.

| 게임 상태 | 표시 표정 |
| --- | --- |
| 평상시 / 피드백 종료 | 기본 무표정 |
| 마법 실수 피드백 | 심드렁함 |
| 폭주 또는 피격 무적 시간 | 놀람 |
| 일시정지 / 패배 | 졸림 |

일시정지·패배가 전투 반응보다 우선합니다. 28개 기능 검사에 이 전환과 우선순위·만료 처리를 포함했습니다. 초상화는 상태 피드백이며 전신 얼굴의 프레임별 애니메이션을 뜻하지 않습니다.


## v0.2.1 전신 포즈

기존 기본형 일러스트를 참고해 새 3×2 전신 키포즈 시트 `art/characters/actions.png`를 제작했습니다. 대기, 준비, 발사, 당황, 피격, 몸을 말아 구르기를 구분합니다. `WizardCatVisual`은 포즈별 영역을 사용하고 삼각형 메시를 변형해 배의 눌림, 어깨 흔들림, 모자의 지연 움직임을 만듭니다. 실제 3D 골격이나 방향별 다프레임 걷기 시트는 아닙니다.


## v0.3.0 도서관·적·책장 아트

- `art/environments/candlewick_archive.png`는 게임용으로 새로 생성한 도서관 환경 일러스트입니다. 석재 바닥, 목재 책장, 책·두루마리, 황동과 촛불 조명을 표현합니다. Instagram 사진이나 계정 캡처에서 가져온 배경이 아닙니다. `ArchiveBackdrop`이 이 이미지를 표시하고 방의 SubViewport 캐시에 담아 재사용합니다.
- 촛불 슬라임·갑옷 빗자루·박쥐는 코드로 그린 절차형 아트입니다. 촛농/젤의 음영, 철제 투구와 황동·솔, 가죽 날개·털·발톱을 표현하며, `CandleSlime`의 역할별 공유 텍스처 캐시를 사용합니다. 본체와 움직이는 날개·불꽃을 나눠 표시합니다. 외부 계정에서 적 이미지를 가져오지 않았습니다.
- 파괴 가능한 책장은 `scripts/effects/shelf_art.gd`에서 목재, 장식과 책을 그립니다. 서 있는 책장·넘어진 책과 나무·불꽃의 세 영역을 방의 공유 아틀라스에 담고 `ArcaneShelf`가 상태에 맞는 영역을 표시합니다. 이 아틀라스도 코드로 생성한 자체 절차형 아트입니다.


## v0.4.0 원정의 소품과 불꽃

`art/items/`의 SVG 아이콘은 게임용 벡터 소품입니다. 금화·지팡이·목줄·부적·음식, 출입문·상인과 경로를 공용 텍스처로 사용하며 Instagram에서 가져온 그림이 아닙니다. `floor_fire.svg`는 위험 범위·불꽃·잿불을 함께 담아 화재 한 곳마다 여러 원과 선을 재생성하던 그리기를 텍스처 한 번으로 대체합니다. 실시간 조명이나 무제한 파티클은 추가하지 않았습니다.

## v0.5.0 재질과 적·주문 그림

`art/enemies/archive_familiars.png`는 게임용으로 새로 생성한 투명 그림입니다. 기존 절차형 적 몸체를 촛농·황동·금속·짚·털·가죽 날개의 재질이 있는 그림으로 교체했습니다. 역할별 본체와 박쥐 날개는 하나의 공유 아틀라스에서 표시합니다.

`art/environments/archive_floor_materials.png`는 석재·그을린 돌·목재·대리석 4종을 담은 생성 그림입니다. `ArchiveBackdrop`이 장소별 문양·직조 러그·배너·창문광을 합쳐 8종의 배경을 입장 때 캐시합니다.

`art/fx/painted_spell_fx.png`는 화염탄·충격 문양·실패 불꽃·연기의 생성 아틀라스입니다. 미리 그려진 빛과 연기를 사용하며 실시간 광원이나 파티클 시뮬레이션은 사용하지 않습니다. 실패의 X 표식과 WHOOPS 문구는 별도 표시합니다. 구르기 먼지는 `roll_dust.svg`를 사용합니다. 이번 생성 아트는 Instagram 이미지를 직접 복사한 에셋이 아닙니다.

## v0.6.0 HD Pastel Storybook 2D

사용자가 제공한 쯔바이!! 참고 화면과 최종 아트 디렉션은 분위기·구도·비례의 방향으로 사용했습니다. 픽셀 실험은 폐기하고 최종 활성 에셋을 고해상도 손그림으로 교체했습니다. 원작 게임의 캐릭터·배경 에셋을 복사하지 않았습니다.

`storybook_actions.png`와 `storybook_expressions.png`는 작은 무심한 눈, 큰 라벤더 모자, 둥근 주황 몸과 짧은 다리의 Meowmalade를 표현합니다. 복잡한 옷이나 지팡이 대신 앞발로 시전합니다. `hd_detention_storage.png`, `hd_academy_library.png`, `hd_forbidden_garden.png`, `hd_grand_archive.png`는 각각 독립1536×1024 배경입니다. 적과 마법 효과는 `storybook_familiars.png`, `storybook_spell_fx.png`를 사용합니다. 모든 활성 캐릭터의 UV 격자·색 단계 양자화·최근접 필터는 제거했습니다.

마도서 보스와 소품은 부드러운 SVG 곡선·캐시 그림으로 표현합니다. 이야기의 한국어 대사는 로컬 Noto Sans CJK KR에서 Hangul/Latin을 추출하고 이름을 바꾼 MeowStory Sans로 표시하며 SIL OFL1.1 라이선스를 동봉합니다. 게임 내 실행 흐름은 `STORY_RUNTIME.md`, 기준 문서는 `design/HD-PASTEL-ART-DIRECTION.md`와 `design/MEOWMALADE-STORYBOARD.md`에 있습니다.

## v0.7.0

Original-meme identity update: `art/characters/meme_actions.png`; four story plates: `art/story/`; nine equipment icons: `art/equipment/`. These are original image_gen outputs with provenance in their adjacent README/STORYBOOK-ART files. Gameplay, inventory, shop and pickups share the same cached equipment atlas; neck items display their pendant while preserving the original thin black collar. Korean/English copy and font use are documented in `docs/LOCALIZATION.md`.

## v0.8.0

The approved meme-cat identity now uses `art/characters/pastel_meme_actions.png`, with reduced fur micro-detail, warm cocoa contours and softer slate-hat shadows. `GroundedCatGait` drives two paw bones from actual movement distance rather than swaying the entire sprite. Chapter briefings reuse the same `ArchiveBackdrop` location art and decorations as gameplay. `AttackTelegraph` uses cream-edged coral floor ink, directional chevrons and a charging seal; the complete locked footprint remains visible through the attack.


## v0.12.0

장착 주무기의 기본 마법과 그림을 연결하는 `elemental_weapons.png`, 실제 책/재배 버섯 적의 `living_reagents.png`, 과녁 소품 `practice_target.png`, 책 자체의 표지 표정과 책장4포즈인 `art/grimoire/perfect_grimoire.png`를 추가했습니다. 인물은 HD Pastel Storybook 2D 톤을 유지합니다. 마도서는 동물 캐스트의 예외로, 이야기와 최종전이 공용 GrimoireArt를 사용합니다. 아트 출처와 생성 의도는 각 폴더의 설명에 기록합니다. 이전 동물 아틀라스의 흰여우 셀은 역사적 미사용 그림이며 활성 인물/전투는 참조하지 않습니다.
