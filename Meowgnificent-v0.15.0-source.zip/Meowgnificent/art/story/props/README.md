# Examination prop

`practice_target.png` is an original generated HD pastel illustration authored
for v0.12.0. The original output remains at
`/workspace/generated_images/exec-3fabb2e7-c34d-4470-9bb2-7f811240a453.png`.
It depicts a honey-wood easel, coral/butter/lavender/mint bullseye and hanging
star. It contains no historical human character illustration.

The story stage uses the transparent full image. Forward and reverse fire
shots share one continuous sampled trajectory in `StoryShot`. The target stays
standing while the backwards spell produces the rear blast. The library's
explicit `exam_*` replay uses the same prop and action, labeled as a flashback.

Supporting actors use `AnimalCast`; the Perfect Grimoire is the separate book
character from `GrimoireArt`. Flying books and living mushrooms use exactly the
same `LivingStageArt` atlas as their actual stage enemies.
