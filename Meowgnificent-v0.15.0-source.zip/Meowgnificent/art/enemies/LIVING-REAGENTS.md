# Awakened library books and reagent mushrooms

`living_reagents.png` was generated for Meowgnificent v0.12.0 with the existing
storybook familiar atlas as the style reference. All four sprites were then
re-spaced by the image generation tool to provide transparent atlas gutters.
Original generator output: `/workspace/generated_images/exec-2b7be260-ff91-4c95-9cea-9d075906cade.png`.

Top row: open/folded versions of one controlled flying library book. Bottom row:
standing/sneezing versions of one awakened potion-reagent mushroom. Their violet
seals connect them to the Perfect Grimoire's imposed order in the original
storyboard. These are live enemies with different attacks, not scenic stickers.

Book patrols start in an even row, then telegraph a locked straight page-cutting
swoop. Mushroom crops start in two orderly beds, wake when approached or struck,
uproot and shuffle, then telegraph a circular spore sneeze. The warning radius
and actual hit test use the same player-centre geometry.
