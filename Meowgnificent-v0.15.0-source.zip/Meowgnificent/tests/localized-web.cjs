const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 let checks=0;
 try {
  const context=await browser.newContext({viewport:{width:1280,height:800}});const page=await context.newPage();const errors=[],failed=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('response',r=>{if(r.status()>=400)failed.push(r.url())});
  function koHas(text,phrase){return text.replace(/\s+/g,'').includes(phrase.replace(/\s+/g,''))}
  function check(ok,name){assert(ok,name);checks++;console.log('PASS: '+name)}
  async function screen(name,savedPath=null){
   const path=savedPath||'/tmp/meowgnificent-v0150-localized-web-'+name+'.png';if(!savedPath)await page.screenshot({path});
   let clip=null;
   if(name.includes('settings'))clip={x:370,y:128,width:540,height:544};
   else if(name.includes('intro')||name.includes('reloaded'))clip={x:600,y:240,width:550,height:470};
   else if(name.includes('inventory'))clip={x:110,y:72,width:1060,height:656};
   else if(name==='story-en'||name==='story-ko'||name==='professor-ko')clip={x:74,y:528,width:1132,height:248};
   let input=path;
   if(clip){input=path.replace('.png','-ocr.png');execFileSync('python3',['-c','from PIL import Image; import sys,json; c=json.loads(sys.argv[3]); Image.open(sys.argv[1]).crop((c["x"],c["y"],c["x"]+c["width"],c["y"]+c["height"])).save(sys.argv[2])',path,input,JSON.stringify(clip)])}
   if(name==='story-ko'||name==='professor-ko'){
    const normalized=input.replace('.png','-contrast.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps,ImageEnhance; import sys; im=ImageEnhance.Contrast(ImageOps.autocontrast(Image.open(sys.argv[1]).convert("L"))).enhance(2); im.resize((im.width*2,im.height*2)).save(sys.argv[2])',input,normalized]);
    input=normalized;
   }
   let text=execFileSync('tesseract',[input,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','11'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   if(name.includes('intro')||name.includes('reloaded')){
    // Read the actual start-button interior separately: page OCR treats its
    // rounded green border as a table and can omit the Korean caption.
    const button=path.replace('.png','-start-button.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((750,563,1020,598)).convert("L")); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,button]);
    text+='\n'+execFileSync('tesseract',[button,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   if(name==='story-ko'||name==='professor-ko'){
    for(const [part,box,psm] of [['body',[98,580,1155,672],'6'],['speaker',[98,545,600,573],'7']]){
     const focused=path.replace('.png','-'+part+'-focused.png');
     execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys,json; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop(tuple(json.loads(sys.argv[3]))).convert("L")); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,focused,JSON.stringify(box)]);
     text+='\n'+execFileSync('tesseract',[focused,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm',psm],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
    }
   }
   if(name==='detention-ko'){
    const title=path.replace('.png','-stage-title.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((50,43,396,82)).convert("L")); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,title]);
    text+='\n'+execFileSync('tesseract',[title,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
    const caption=path.replace('.png','-state-caption.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((970,77,1240,112)).convert("L")); im.resize((im.width*4,im.height*4)).save(sys.argv[2])',path,caption]);
    text+='\n'+execFileSync('tesseract',[caption,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   if(name==='inventory-ko'){
    const slot=path.replace('.png','-hat-slot.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((142,316,237,342)).convert("L")); im.resize((im.width*4,im.height*4)).save(sys.argv[2])',path,slot]);
    text+='\n'+execFileSync('tesseract',[slot,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   if(name==='inventory-ko'){
    for(const [part,box] of [['collar',[142,518,237,544]],['wand',[452,518,552,544]]]){
     const focused=path.replace('.png','-'+part+'-slot.png');
     execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys,json; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop(tuple(json.loads(sys.argv[3]))).convert("L")); im.resize((im.width*5,im.height*5)).save(sys.argv[2])',path,focused,JSON.stringify(box)]);
     text+='\n'+execFileSync('tesseract',[focused,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
    }
   }
   return text;
  }
  async function expectScreen(name,predicate,description){let text='';for(let i=0;i<20;i++){await page.waitForTimeout(180);text=await screen(name);if(predicate(text)){check(true,description);return text}}assert.fail(description+'; OCR '+JSON.stringify(text))}
  async function ready(){await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});await page.waitForTimeout(600)}
  async function key(value){await page.keyboard.down(value);await page.waitForTimeout(100);await page.keyboard.up(value);await page.waitForTimeout(150)}
  async function choose(index){
   // Settings.open() focuses the real LanguageChoice button. Opening it
   // with the keyboard focuses its checked item; this flow toggles KO0 -> EN1
   // and then EN1 -> KO0. Avoid assuming popup row positions or font metrics.
   await page.keyboard.press('Space');await page.waitForTimeout(250);
   await page.screenshot({path:'/tmp/meowgnificent-v0150-language-dropdown-'+index+'.png'});
   await page.keyboard.press(index===0?'ArrowUp':'ArrowDown');
   await page.keyboard.press('Enter');await page.waitForTimeout(350)
  }
  const url=new URL(process.env.GAME_URL||'http://127.0.0.1:8082/');url.searchParams.delete('lang');url.searchParams.delete('skip_story');
  await page.goto(url.href,{waitUntil:'networkidle'});await ready();
  check(!new URL(page.url()).searchParams.has('lang'),'ordinary player URL has no forced language');
  await expectScreen('intro-ko',t=>koHas(t,'영구 강화')&&koHas(t,'모험 시작'),'fresh player sees Korean menu by default');
  await page.locator('#canvas').click({position:{x:180,y:680}});await key('F10');
  await expectScreen('settings-ko',t=>koHas(t,'설정')&&koHas(t,'언어')&&koHas(t,'한국어'),'F10 opens Korean settings and language choice');
  await choose(1);
  await expectScreen('settings-en',t=>t.includes('settings')&&t.includes('language')&&t.includes('english')&&t.includes('changes apply'),'real language dropdown immediately changes the options screen to English');
  await key('Escape');
  await expectScreen('intro-en',t=>t.includes('a minor magical incident')&&t.includes('begin expedition'),'closing settings returns to the English start menu');
  await page.waitForTimeout(3000);await page.reload({waitUntil:'networkidle'});await ready();
  await expectScreen('reloaded-en',t=>t.includes('a minor magical incident')&&t.includes('begin expedition'),'English preference survives a complete WASM page reload with no language flag');
  await page.locator('#canvas').click({position:{x:180,y:680}});await key('Enter');
  await page.waitForTimeout(180);
  const storyENPath='/tmp/meowgnificent-v0150-localized-web-story-en.png';
  await page.screenshot({path:storyENPath});await key('F10');
  const storyEN=await screen('story-en',storyENPath);
  check(storyEN.includes('arcana academy')&&/0?1\s*\/\s*14/.test(storyEN),'default opening uses English dialogue after the saved language choice; OCR '+JSON.stringify(storyEN));
  await expectScreen('story-settings',t=>t.includes('changes apply'),'settings can open over an active story');
  await choose(0);
  // The taller settings card covers dialogue. Capture the real translated
  // page while options are closed, then pause again before slow Korean OCR.
  await key('Escape');
  const storyKOPath='/tmp/meowgnificent-v0150-localized-web-story-ko.png';
  await page.screenshot({path:storyKOPath});await key('F10');
  const storyKO=await screen('story-ko',storyKOPath);
  check(koHas(storyKO,'대륙 최고의')&&/0?1\s*\/\s*14/.test(storyKO),'switching back to Korean keeps the same opening page and translates its dialogue; OCR '+JSON.stringify(storyKO));
  await key('Escape');await page.waitForTimeout(180);await key('Space');
  await page.waitForTimeout(100);
  const professorPath='/tmp/meowgnificent-v0150-localized-web-professor-ko.png';
  await page.screenshot({path:professorPath});await key('F10');
  const professorKO=await screen('professor-ko',professorPath);
  check(koHas(professorKO,'화염구')&&koHas(professorKO,'교수')&&/0?2\s*[/|7]\s*14/.test(professorKO),'Korean professor dialogue advances normally after leaving language options; OCR '+JSON.stringify(professorKO));
  await key('Escape');await page.waitForTimeout(180);await key('Escape');
  // Freeze gameplay with its real inventory key before the slow Korean OCR
  // reads the saved live frame. OCR time must not become an idle-death fixture.
  await page.waitForTimeout(450);
  const detentionPath='/tmp/meowgnificent-v0150-localized-web-detention-ko.png';
  await page.screenshot({path:detentionPath});
  await key('i');
  const detentionText=await screen('detention-ko',detentionPath);
  check(detentionText.replace(/\s/g,'').includes('벌청소')&&detentionText.replace(/\s/g,'').includes('통로잠김')&&!koHas(detentionText,'이야기 건너뛰기'),'skipping the story enters Korean gameplay');
  await expectScreen('inventory-ko',t=>koHas(t,'장비와 가방')&&koHas(t,'지팡이')&&koHas(t,'목걸이')&&koHas(t,'장식'),'equipment UI is Korean during the same expedition');
  await page.waitForTimeout(3000);await page.reload({waitUntil:'networkidle'});await ready();
  await expectScreen('reloaded-ko',t=>koHas(t,'영구 강화')&&koHas(t,'모험 시작'),'Korean preference also survives a complete reload');
  check(failed.length===0,'all localized assets load successfully');check(errors.length===0,'localized dropdown, story and reload flow have no JavaScript or engine errors: '+JSON.stringify(errors));
  console.log(`LOCALIZED WEB RESULT: ${checks} checks, 0 failures`);
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
