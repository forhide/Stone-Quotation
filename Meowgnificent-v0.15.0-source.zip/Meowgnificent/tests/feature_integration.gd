extends SceneTree

# Cross-feature checks use the actual equipment panel, room key dispatch,
# narrative transition and pause path; module-specific collision suites are separate.
var checks := 0
var failures := 0
var room
var profile_path := "/tmp/meow-feature-integration-%d.json" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")
func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(count: int=2) -> void:
	for i in range(count):
		await physics_frame
		await process_frame
func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.physical_keycode=code
	event.pressed=true
	room._unhandled_key_input(event)
func freeze() -> void:
	room.player.invulnerability=10000
	for enemy in room.enemies: enemy.active=false
func run() -> void:
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	OS.set_environment("MEOW_SKIP_STORY","1")
	change_scene_to_file("res://scenes/main.tscn")
	await frames()
	room=current_scene
	room.begin_or_restart()
	freeze()
	for id in ["frost_whisker_wand","hopscotch_wand","pip_feather_staff","moss_bud_staff","bloop_bottle_wand","thunder_spoon"]: room.run.add_item(id)
	room.open_inventory()
	await frames()
	var wardrobe_rect: Rect2=room.panel.preview_model.get_global_rect()
	var return_rect: Rect2=room.panel.close_button.get_global_rect()
	var equipped_before: Dictionary=room.run.equipment.duplicate()
	room.panel._preview_item("bloop_bottle_wand")
	await frames()
	check(room.panel.preview_model.get_global_rect()==wardrobe_rect and room.panel.close_button.get_global_rect()==return_rect,"hovering a new magic trait leaves wardrobe and return control stationary")
	check(room.panel.detail_subtitle.text==GameLocale.text("Basic magic: %s") % GameLocale.text("Waterdrop"),"hover identifies the candidate's actual basic spell")
	check(room.run.equipment==equipped_before and BasicMagic.for_run(room.run).id=="fire","previewing water cannot silently change the live fire spell")
	room.panel._select_item("bloop_bottle_wand")
	room.panel._equip_selected()
	check(BasicMagic.for_run(room.run).id=="water","explicit Equip updates the live primary spell")
	room.close_panel()
	await frames()
	check(room.hud.cooldown_label.text.contains(GameLocale.text("Waterdrop")) and not room.hud.cooldown_label.text.contains("Fireball"),"combat HUD names the equipped water spell")
	for lang in ["ko","en"]:
		GameLocale.set_language(lang,false)
		room.open_inventory()
		await frames()
		wardrobe_rect=room.panel.preview_model.get_global_rect()
		return_rect=room.panel.close_button.get_global_rect()
		for id in ["practice_wand","frost_whisker_wand","hopscotch_wand","pip_feather_staff","moss_bud_staff","bloop_bottle_wand","thunder_spoon"]:
			room.panel._select_item(id)
			await frames()
			var bottom: float=room.panel.stats_container.get_global_rect().end.y
			check(bottom<=660.0 and room.panel.equip_button.get_global_rect().end.x<=1170.0 and room.panel.preview_model.get_global_rect()==wardrobe_rect and room.panel.close_button.get_global_rect()==return_rect,"basic traits and arrows fit without shifting wardrobe or controls: "+lang+":"+id)
		room.close_panel()
		freeze()
	GameLocale.set_language("ko",false)
	room.load_sector(3)
	await frames()
	room.player.position=ShopGathering.FRIEND_POSITIONS.moss+Vector2(0,35)
	await frames()
	var wallet_before: int=room.run.gold
	var hp_before: int=room.player.health.current
	key(KEY_E)
	await frames()
	var gathering: ShopGathering=room.markers.gathering
	check(room.state=="playing" and gathering.active_actor=="moss" and gathering.conversation.visible,"real E dispatch addresses Moss while movement remains available")
	check(not room.hud.sector_banner.visible,"arrival card makes room for an active NPC conversation")
	check(room.run.gold==wallet_before and room.player.health.current==hp_before,"a friendly reaction neither buys stock nor grants hidden healing")
	var line_before: int=gathering.active_line
	var echo := InputEventKey.new()
	echo.keycode=KEY_E
	echo.pressed=true
	echo.echo=true
	room._unhandled_key_input(echo)
	check(gathering.active_line==line_before,"held E key repeat cannot skip the NPC's lines")
	room.set_running(false)
	var clock: float=gathering.elapsed
	var remaining: float=gathering.dialogue_remaining
	await frames(12)
	check(is_equal_approx(gathering.elapsed,clock) and is_equal_approx(gathering.dialogue_remaining,remaining),"room pause freezes both NPC acting and speech duration")
	room.set_running(true)
	room.player.position=ShopGathering.PIP_POSITION
	await frames(20)
	key(KEY_T)
	check(gathering.active_actor=="pip" and room.state=="playing","T starts squirrel Pip's own conversation without opening trade")
	key(KEY_E)
	check(room.state=="shop" and room.panel.is_open,"Pip's existing E-to-browse control still opens his real stock")
	room.close_panel()
	room.player.position=ShopGathering.TABLE_POSITION
	key(KEY_E)
	check(room.state=="shop" and room.panel.is_open,"the central picnic table remains a second entry to the same shop")
	room.close_panel()
	room.load_sector(6)
	await frames()
	check(gathering.active_actor.is_empty() and not gathering.conversation.visible,"changing to the final rest stop clears the previous conversation")
	OS.set_environment("MEOW_SKIP_STORY","0")
	room.load_sector(1)
	await frames()
	check(room.state=="story" and room.story_director.pages[0].visual=="exam_fire","the first-area exit restores the clearly marked target-exam replay")
	var stage=room.story_director.stage
	check(stage.exam_flashback and stage.location_index==1,"explicit replay is a memory while route identity remains the library")
	room.story_director.skip()
	await frames()
	check(room.state=="playing" and room.run.stage_index==1 and room.enemies[0] is LivingStageEnemy,"leaving the replay resumes the live-book stage instead of restarting the exam")
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("FEATURE INTEGRATION RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
