extends SceneTree

var checks := 0
var failures := 0
var room

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(count: int) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func fresh() -> void:
	if is_instance_valid(room): room.free()
	room=load("res://scenes/main.tscn").instantiate()
	root.add_child(room)
	await frames(3)
	room.begin_or_restart()
	for enemy in room.enemies: enemy.active=false
	room.player.position=Vector2(640,460)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	await fresh()
	check(room.props.size()==1,"the storeroom has one old storage case; library cases stay in library stages")
	var roles: Array[String]=[]
	for enemy in room.enemies:
		if not roles.has(enemy.role): roles.append(enemy.role)
	check(roles.size()==3,"candle, broom and bat have distinct roles")
	var enemy: CandleSlime=room.enemies[0]
	enemy.position=Vector2(640,405)
	enemy.active=true
	await frames(4)
	check(enemy.phase=="windup" and room.player.health.current==100,"nearby enemy telegraphs without contact damage")
	var locked := enemy.attack_direction
	room.player.position=Vector2(740,460)
	await frames(12)
	check(enemy.attack_direction==locked,"attack locks direction so stepping aside is meaningful")
	for i in range(90):
		if enemy.phase=="recover": break
		await frames(1)
	check(room.player.health.current==100,"sidestepping avoids the telegraphed attack")
	enemy.active=false
	enemy.phase="windup"
	enemy.take_damage(1,Vector2.RIGHT)
	check(enemy.phase=="recover","a hit interrupts an enemy windup")

	await fresh()
	enemy=room.enemies[0]
	enemy.position=Vector2(700,460)
	check(room.player.start_roll(Vector2.RIGHT),"manual roll starts")
	check(not room.player.start_roll(Vector2.RIGHT),"roll cannot be stacked while rolling")
	room.player.take_damage(12,enemy.position)
	check(room.player.health.current==100,"roll evades incoming damage")
	await frames(12)
	check(enemy.health.current==10,"rolling belly hits once for 30 damage")
	await frames(20)
	check(enemy.health.current==10,"one roll does not repeatedly damage the same enemy")
	check(not room.player.start_roll(Vector2.RIGHT),"roll recovery prevents continuous invulnerability")

	await fresh()
	var shelf: ArcaneShelf=room.props[0]
	enemy=room.enemies[0]
	enemy.position=shelf.position+Vector2(105,0)
	var victim_health: CombatHealth=enemy.health
	shelf.ignite(Vector2.RIGHT)
	check(shelf.state=="burning" and enemy.health.current==40,"ignition warns before shelf deals damage")
	room.set_running(false)
	var timer := shelf.timer
	await frames(20)
	check(is_equal_approx(shelf.timer,timer),"pause freezes shelf ignition countdown")
	room.set_running(true)
	for foe in room.enemies: foe.active=false
	await frames(110)
	check(shelf.state=="fallen" and victim_health.current==0,"burning shelf falls and defeats an enemy in its footprint")
	check(room.fires.size()>0,"burning shelf leaves a temporary fire hazard")
	await frames(280)
	check(room.fires.is_empty(),"fire hazard expires rather than filling the arena permanently")

	await fresh()
	shelf=room.props[0]
	room.player.position=shelf.position+Vector2(-90,0)
	room.player.start_roll(Vector2.RIGHT)
	await frames(35)
	check(shelf.state=="fallen","body roll topples a shelf without magic")

	await fresh()
	room.player.position=Vector2(640,460)
	room.spells.resolver.forced="miscast"
	var rng := RandomNumberGenerator.new()
	var chosen_seed := 0
	for seed_value in range(100):
		rng.seed=seed_value
		if rng.randi_range(0,2)==2:
			chosen_seed=seed_value
			break
	room.spells.resolver.rng.seed=chosen_seed
	room.spells.cast(Vector2.RIGHT)
	await frames(10)
	check(room.player.roll_time>0 and room.fires.size()==1,"feet miscast starts a panic roll and ignites the floor")
	check(room.hud.incident_label.text.contains("HOT PAWS"),"panic accident explains itself in the room")
	await frames(28)
	check(room.player.position.x<560,"panic roll actually displaces the cat")
	check(room.player.health.current==100,"initial panic roll protects the cat from its own new fire")

	await fresh()
	shelf=room.props[0]
	room.player.position=shelf.position-Vector2(130,0)
	room.spells.resolver.forced="success"
	room.spells.cast(Vector2.RIGHT)
	await frames(20)
	check(shelf.burning,"a real fireball collision ignites an interactive bookshelf")

	await fresh()
	room.player.position=Vector2(1170,450)
	room.player.start_roll(Vector2.RIGHT)
	await frames(6)
	check(room.player.position.x<=1177 and room.player.roll_time<=0,"wall bump stops a roll inside room bounds")
	check(room.hud.incident_label.text.contains("Wall:"),"wall collision has visible comic feedback")
	await fresh()
	var visual: WizardCatVisual
	for child in room.player.get_children():
		if child is WizardCatVisual: visual=child
	room.spells.resolver.forced="success"
	room.spells.cast(Vector2.RIGHT)
	check(visual.choose_pose()==1 and room.projectiles.get_child_count()==0,"cast anticipation precedes the projectile")
	room.set_running(false)
	var preparation: float=room.spells.prepare_time
	await frames(20)
	check(room.spells.pending and is_equal_approx(room.spells.prepare_time,preparation),"pause preserves a prepared spell without releasing it")
	room.set_running(true)
	for foe in room.enemies: foe.active=false
	await frames(12)
	check(room.projectiles.get_child_count()>0 and visual.choose_pose()==2,"resuming releases the spell with its full-body casting pose")
	room.player.take_damage(12,Vector2.ZERO)
	check(visual.choose_pose()==4,"damage changes the full-body pose to hurt")
	room.player.start_roll(Vector2.LEFT)
	check(visual.choose_pose()==5,"rolling uses a tucked-body pose")
	await fresh()
	room.spells.resolver.forced="success"
	room.spells.cast(Vector2.RIGHT)
	room.player.start_roll(Vector2.RIGHT)
	await frames(12)
	check(not room.spells.pending and room.projectiles.get_child_count()==0,"rolling cancels preparation instead of firing from inside the roll")
	room.free()
	print("ACCIDENT RESULT: %d checks, %d failures"%[checks,failures])
	quit(0 if failures==0 else 1)
