extends SceneTree
var checks := 0
var failures := 0
var profile_path := ""
var settings_path := ""
func check(ok: bool, caption: String) -> void:
 checks+=1
 if ok: print("PASS: "+caption)
 else:
  failures+=1
  push_error("FAIL: "+caption)
func frames(count: int=3) -> void:
 for i in range(count):
  await physics_frame
  await process_frame
func escape() -> void:
 var event := InputEventKey.new()
 event.keycode=KEY_ESCAPE
 event.physical_keycode=KEY_ESCAPE
 event.pressed=true
 Input.parse_input_event(event)
 event=event.duplicate()
 event.pressed=false
 Input.parse_input_event(event)
func _initialize() -> void: call_deferred("run")
func visual_of(player: WizardCat) -> WizardCatVisual:
 for child in player.get_children():
  if child is WizardCatVisual: return child
 return null
func run() -> void:
 var locale := root.get_node("Language")
 var previous_path: String=locale.settings_path
 var previous_language: String=locale.current
 var previous_profile := OS.get_environment("MEOW_PROFILE_PATH")
 var previous_skip := OS.get_environment("MEOW_SKIP_STORY")
 var seen: Variant=root.get_meta("meow_opening_seen") if root.has_meta("meow_opening_seen") else null
 if root.has_meta("meow_opening_seen"): root.remove_meta("meow_opening_seen")
 profile_path="/tmp/meow-v090-features-%d.json" % OS.get_process_id()
 settings_path=profile_path+".cfg"
 OS.set_environment("MEOW_PROFILE_PATH",profile_path)
 OS.set_environment("MEOW_SKIP_STORY","0")
 locale.settings_path=settings_path
 check(locale.load_language(settings_path)=="ko","a fresh settings file defaults to Korean")
 check(not locale.set_language("zz",false) and locale.current==previous_language,"unknown locale is rejected without changing the selected language")
 locale.set_language("ko",false)
 check(GameLocale.text("Settings")=="설정" and GameLocale.text(str(BasicMagic.definition("water").name))=="물방울" and GameLocale.text("READY")=="준비 완료","menus and spell state use Korean copy")
 var format_regex := RegEx.new()
 format_regex.compile("%[-+0-9.]*[sdf]")
 var placeholders_valid := true
 for key: String in locale.translations:
  var before := format_regex.search_all(key)
  var after := format_regex.search_all(str(locale.translations[key]))
  if before.size()!=after.size(): placeholders_valid=false
  else:
   for index in range(before.size()):
    if before[index].get_string()!=after[index].get_string(): placeholders_valid=false
 check(placeholders_valid,"all localized UI messages preserve their interpolation types and order")
 change_scene_to_file("res://scenes/main.tscn")
 await frames()
 var room=current_scene
 var story=room.story_director
 var all_copy := true
 var beats: Array=story.story.opening.duplicate()
 for chapter in story.story.chapters: beats.append_array(chapter.beats)
 beats.append_array(story.story.ending)
 for page in beats:
  if str(page.get("text","")).is_empty() or str(page.get("text_en","")).is_empty(): all_copy=false
 check(all_copy and beats.size()==53,"all53story pages, including the restored examination replay, have Korean and complete English copy")
 # Cover newly authored NPC reactions and replay/boss text with the bundled
 # font itself, without silently relying on a host Korean fallback font.
 for source_path in ["res://data/locales/ko.json","res://data/story.json","res://data/shop_dialogue.json"]:
  var localized_source := FileAccess.get_file_as_string(source_path)
  var missing: Dictionary={}
  for character in localized_source:
   var code: int=character.unicode_at(0)
   if code>=0xAC00 and code<=0xD7A3 and not GameLocale.STORY_FONT.has_char(code): missing[character]=true
  check(missing.is_empty(),"all rendered Korean syllables exist in the bundled story font: "+source_path+str(missing.keys()))
 var catalog_localized := true
 for item in room.run.catalog.values():
  catalog_localized=catalog_localized and GameLocale.text(item.name)!=item.name and GameLocale.text(item.description)!=item.description
 check(catalog_localized and room.run.catalog.size()==36,"all thirty-six equipment names and descriptions have Korean translations")
 var names_localized := true
 for area in room.stages: names_localized=names_localized and GameLocale.text(area.name)!=area.name
 check(names_localized,"all eight destination names have Korean translations")
 room.request_begin()
 await frames()
 story.auto_advance=false
 story.elapsed=1.25
 var page_index: int=story.page_index
 room.settings.open()
 check(room.settings.is_open and room.state=="settings" and not room.player.active and not story.is_processing(),"settings pause an active story without dismissing it")
 locale.set_language("en",true)
 check(story.page_index==page_index and is_equal_approx(story.elapsed,1.25) and story.body_label.text==story.pages[page_index].text_en,"changing language updates the current story page without advancing or rewinding it")
 check(locale.load_language(settings_path)=="en","English preference is persisted independently of progress")
 escape()
 await frames(1)
 check(room.settings.blocks_gameplay_input(),"settings close guards the triggering Escape from the story and room input handlers")
 check(story.is_open and room.state=="story" and not room.player.active,"closing settings returns to the same narrative page")
 story.skip()
 await frames()
 check(room.state=="playing" and room.player.active,"story completion still returns control to the expedition after language switching")
 for enemy in room.enemies: enemy.active=false
 room.player.invulnerability=1000
 var visual := visual_of(room.player)
 var gear := visual.equipment_visual
 check(gear.attachments.size()==3 and gear.equipment=={"wand":"practice_wand","collar":"","charm":""} and room.run.inventory==["practice_wand"],"the tutorial equips only its zero-stat practice wand, leaving collar and charm empty")
 room.unequip_gear("wand")
 room.run.inventory.clear()
 for id: String in room.run.catalog:
  var item: Dictionary=room.run.item_info(id)
  var added: bool=room.run.add_item(id)
  check(added and room.equip_gear(id),"a real owned-item equip action accepts "+id)
  await frames(1)
  var icon := EquipmentArt.icon(id)
  var snapshot := gear.appearance_snapshot()
  check(icon!=null and icon==EquipmentArt.icon(id) and snapshot.attachments[item.slot].texture==EquipmentArt.worn_icon(id) and snapshot.attachments[item.slot].visible,"equipping "+id+" shows its shared unique artwork on the cat")
  room.unequip_gear(str(item.slot))
  room.run.inventory.erase(id)
 # Verify every catalog item in its own slot without bypassing the bag limit.
 # Restore a complete owned loadout for the action/mirror/roll checks below.
 for id in ["apprentice_thesis","nine_lives_collar","moonlit_yarn"]:
  room.run.add_item(id)
  room.equip_gear(id)
 check(gear.attachments.size()==3 and room.run.inventory.size()==3,"swapping all thirty-six items reuses three accessory nodes and respects the bag limit")
 var revision: int=gear.revision
 room.apply_equipment()
 check(gear.revision==revision,"reapplying unchanged equipment does not rebuild its visual resources")
 room.player.active=false
 room.player.cast_aim=Vector2.LEFT
 room.player.cast_pose=0.3
 room.player.cast_outcome="success"
 await frames()
 check(visual.active_pose==2 and gear.scale.x<0 and gear.attachments.wand.visible,"casting attachments follow the left-facing action pose")
 room.player.roll_time=0.2
 await frames()
 check(not gear.attachments.wand.visible and not gear.attachments.collar.visible and not gear.attachments.charm.visible,"tucked rolls hide loose accessories while retaining their equipped identities")
 room.player.roll_time=0
 room.player.cast_pose=0
 await frames()
 check(gear.attachments.wand.visible and gear.attachments.collar.visible and gear.attachments.charm.visible,"all attachments return after a roll")
 room.player.active=true
 room.settings.open()
 locale.set_language("ko",true)
 escape()
 await frames(1)
 check(not room.settings.is_open and room.settings.blocks_gameplay_input(),"combat options consume their Escape close event before gameplay resumes")
 check(room.state=="playing" and room.player.active and locale.load_language(settings_path)=="ko","Korean can be restored and persisted while combat resumes correctly")
 check(room.enemies.all(func(enemy): return not enemy.active),"closing settings preserves individual enemy activity instead of waking frozen actors")
 room.open_inventory()
 room.settings.open()
 locale.set_language("en",false)
 room.settings.close()
 check(room.panel.is_open and room.state=="inventory" and not room.player.active,"language options preserve an already-open equipment panel and combat pause")
 room.close_panel()
 for slot in ["wand","collar","charm"]:
  check(room.unequip_gear(slot) and not gear.attachments[slot].visible and gear.equipment[slot]=="","unequipping "+slot+" immediately removes the worn image")
 check(room.run.stats().spell_damage_bonus==0 and room.run.stats().max_hp_bonus==0,"removing visual equipment also removes the real combat bonuses")
 room.begin_or_restart()
 await frames()
 room=current_scene
 check(visual_of(room.player).equipment_visual.equipment.values()==["","",""] and room.run.inventory.is_empty(),"a new expedition does not retain previous equipment visuals")
 current_scene.queue_free()
 await frames()
 locale.settings_path=previous_path
 locale.set_language(previous_language,false)
 OS.set_environment("MEOW_PROFILE_PATH",previous_profile)
 OS.set_environment("MEOW_SKIP_STORY",previous_skip)
 if seen==null:
  if root.has_meta("meow_opening_seen"): root.remove_meta("meow_opening_seen")
 else: root.set_meta("meow_opening_seen",seen)
 for suffix in ["",".bak",".tmp",".cfg"]:
  if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
 print("LOCALIZATION APPEARANCE RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
