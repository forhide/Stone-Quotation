extends SceneTree

# Exercise the real HUD with a counted skill-definition provider. Unchanged
# frames should not repeatedly clone descriptions or replace icon resources.
class CountedSkills extends ItemSkillController:
	var info_calls := 0
	func skill_info() -> Dictionary:
		info_calls+=1
		return super.skill_info()

var checks := 0
var failures := 0
var profile_path := "/tmp/meow-hud-refresh-%d.json" % OS.get_process_id()

func _initialize() -> void: call_deferred("run")

func check(ok: bool,message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func frames(n: int=2) -> void:
	for i in range(n): await process_frame

func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames(5)
	var room=current_scene
	room.begin_or_restart()
	room.set_process(false)
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.spells.set_physics_process(false)
	room.skills.set_physics_process(false)
	for foe in room.enemies:
		foe.active=false
		foe.set_physics_process(false)
	var hud: WizardHUD=room.hud
	hud.set_process(false)
	var language=root.get_node("Language")
	var old_locale: String=language.current
	language.set_language("en",false)
	var probe := CountedSkills.new()
	probe.room=room
	probe.player=room.player
	room.add_child(probe)
	probe.set_physics_process(false)
	room.skills=probe
	room.run.add_item("bloop_bottle_wand")
	room.equip_gear("bloop_bottle_wand")
	hud.clear_skill_cast()
	hud.outcome_time=0
	hud._process(0)
	var icon_id := hud.skill_icon.texture.get_instance_id()
	var description := hud.skill_label.tooltip_text
	for i in range(120): hud._process(0)
	check(probe.info_calls==1 and hud.skill_icon.texture.get_instance_id()==icon_id and hud.skill_label.tooltip_text==description,"120 unchanged frames reuse the skill definition, icon and description")
	check(hud.cooldown_label.text.begins_with("Waterdrop") and hud.skill_label.text=="Q · Bloop's Best Batch","equipping a water wand updates both primary spell and special skill")
	probe.cooldown_duration=8.0
	probe.cooldown_remaining=4.04
	hud._process(0)
	var first_width: float=hud.skill_bar.size.x
	var first_caption := hud.skill_state.text
	probe.cooldown_remaining=4.01
	hud._process(0)
	check(hud.skill_bar.size.x>first_width and hud.skill_state.text==first_caption,"the cooldown fill moves continuously between text's tenth-second changes")
	for i in range(60):
		probe.cooldown_remaining=4.0-float(i)/60.0
		hud._process(0)
	check(probe.info_calls==1,"a moving cooldown does not reread the unchanged skill description")
	room.player.health.current-=7
	room.run.gold+=9
	room.profile.starlight+=2
	hud._process(0)
	check(hud.health_bar.value==room.player.health.current and hud.health_label.text.contains(str(room.player.health.current)),"damage updates both the vitality text and bar")
	check(hud.wallet_label.text=="%d  /  %d" % [room.run.gold,room.profile.starlight],"wallet changes still appear immediately")
	room.player.roll_cooldown=0.5
	hud._process(0)
	check(hud.roll_label.text.contains("RECOVERING"),"roll recovery updates without waiting for another HUD change")
	room.player.roll_cooldown=0
	hud._process(0)
	check(hud.roll_label.text.contains("READY"),"the roll caption returns to ready on its first available frame")
	hud.show_skill_cast(probe.skill_info(),"miscast")
	hud._process(0.1)
	check(hud.skill_state.text=="SPECIAL CAST!" and hud.status_label.text.begins_with("SKILL MISCAST") and hud.skill_icon.scale.x>1,"a special cast keeps its named outcome, card and animated icon")
	language.set_language("ko",false)
	hud._process(0)
	check(hud.skill_state.text==GameLocale.text("SPECIAL CAST!") and hud.status_label.text.begins_with(GameLocale.text("SKILL MISCAST · %s").split("%s")[0]),"changing language refreshes the active special confirmation")
	check(hud.cooldown_label.text.begins_with(GameLocale.text("Waterdrop")) and hud.destination_label.text==GameLocale.text(str(room.stage_def.name)),"cached primary and destination labels refresh in Korean")
	var paused_flash: float=hud.skill_flash_remaining
	room.open_inventory()
	hud._process(0.5)
	check(is_equal_approx(hud.skill_flash_remaining,paused_flash) and hud.inventory_button.disabled,"opening equipment pauses the cast animation and disables the HUD button")
	room.close_panel()
	hud._process(2.0)
	check(hud.skill_flash_remaining==0 and hud.skill_state.text!=GameLocale.text("SPECIAL CAST!") and hud.skill_icon.scale==Vector2.ONE,"special confirmation expires into the live cooldown on the same frame")
	room.unequip_gear("wand")
	hud._process(0)
	check(hud.skill_state.text==GameLocale.text("Equip a wand to unlock its skill") and hud.skill_bar.size.x==0 and hud.skill_label.tooltip_text.is_empty(),"unequipping clears the obsolete description and disables the skill bar")
	check(hud.cooldown_label.text.begins_with(GameLocale.text("Fireball")),"an empty wand slot restores the ordinary primary spell")
	room.exit_open=true
	hud._process(0)
	check(hud.enemy_label.text==GameLocale.text("PASSAGE OPEN  ·  ENTER") and hud.status_label.text==GameLocale.text("PASSAGE OPEN  /  ENTER to continue"),"a newly opened exit updates both localized passage captions")
	language.set_language(old_locale,false)
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("HUD REFRESH RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
