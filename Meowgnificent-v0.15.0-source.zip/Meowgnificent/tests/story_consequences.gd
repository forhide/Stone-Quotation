extends SceneTree
var checks := 0
var failures := 0
var room
var director
var stage
var profile_path := "/tmp/meow-consequences-%d.json" % OS.get_process_id()
func _initialize() -> void: call_deferred("run")
func check(ok: bool,caption: String) -> void:
 checks+=1
 if ok: print("PASS: "+caption)
 else:
  failures+=1
  push_error("FAIL: "+caption)
func frames(n: int=3) -> void:
 for i in range(n): await process_frame
func page(index: int) -> void:
 director.page_index=index
 director._show_page()
func tick(seconds: float) -> void:
 stage.tick(seconds)
 stage._animate_actors()
func nodes(node: Node) -> int:
 var total := 1
 for child in node.get_children(): total+=nodes(child)
 return total
func run() -> void:
 OS.set_environment("MEOW_SKIP_STORY","1")
 OS.set_environment("MEOW_PROFILE_PATH",profile_path)
 change_scene_to_file("res://scenes/main.tscn")
 await frames(5)
 room=current_scene
 room.begin_or_restart()
 room.set_running(false)
 room.state="story"
 director=room.story_director
 stage=director.stage
 director.play_opening(Callable())
 director.auto_advance=false
 director.set_process(false)
 var allocated := nodes(stage)
 page(3)
 check(stage.target_sprite.flip_h and stage.target_sprite.position.x>stage.hero_rect.end.x,"the intact target's illustrated face points left toward the caster")
 check(stage.exam_damage_age<0 and stage.hero.self_modulate==Color.WHITE,"the exam begins with a clean class and clean cat")
 page(5)
 check(stage.sooty and stage.exam_damage_age==0 and stage.actor_ids==PackedStringArray(["professor"]),"the rear blast arms one persistent aftermath for both actual actors")
 tick(0.9)
 check(stage.snapshot().damage_amount==1 and StoryConsequences.RUINS.get_size().x>=1536,"the flash reveals an authored ruined classroom, not only a fireball decal")
 check(stage.hero.texture==StoryConsequences.sooty_actor(false) and stage.friend_portrait.texture==StoryConsequences.sooty_actor(true) and stage.snapshot().professor_sooty,"both cat and owl remain visibly singed after the smoke clears")
 var age: float=stage.exam_damage_age
 var entries: int=stage.scene_entries
 page(6)
 check(stage.exam_damage_age==age and stage.sooty and stage.snapshot().professor_sooty and stage.scene_entries==entries,"the deadpan reaction retains the wrecked set and both sooty characters without another entrance")
 director.set_process(true)
 room.settings.open()
 var paused: float=stage.exam_damage_age
 await frames(8)
 check(stage.exam_damage_age==paused,"options freeze the aftermath, falling debris and soot age")
 room.settings.close()
 director.set_process(false)
 tick(0.4)
 check(stage.exam_damage_age>age,"the aftermath resumes from its existing age")
 page(7)
 page(8)
 check(stage.sooty and stage.snapshot().damage_amount==1,"title and report-card beats do not silently repair the classroom or clean the cat")
 page(9)
 check(not stage.sooty and stage.hero.self_modulate==Color.WHITE,"moving to the Grimoire's separate scene clears exam-only dirt")
 director.play_opening(Callable())
 director.auto_advance=false
 director.set_process(false)
 check(stage.exam_damage_age<0 and not stage.sooty,"starting another sequence cannot leak the last exam's damage")
 director.show_chapter(1,Callable())
 director.set_process(false)
 page(2)
 tick(1)
 check(stage.exam_flashback and stage.sooty,"the explicit exam memory includes the same damaged set")
 page(3)
 check(not stage.sooty and stage.location_backdrop.visible and stage.living_prop_kind=="book","the memory gives way to the actual library without exam rubble")
 check(stage.living_props.size()==6 and stage.living_props[0].modulate.a==0,"six ordinary volumes start at the returns desk before the faces wake")
 tick(1.1)
 check(stage.snapshot().living_phase=="seal" and stage.living_props[0].modulate.a>0 and stage.living_props[0].modulate.a<1,"the control glyph precedes the books' full reveal")
 var low: Vector2=stage.living_props[0].position
 tick(1.0)
 check(stage.snapshot().living_phase=="waking" and stage.living_props[0].position.y<low.y,"marked books rise from their resting covers before forming the guard row")
 tick(0.65)
 check(stage.living_props[0].texture==LivingStageArt.icon("book"),"woken books wait for the spoken guard order before attacking")
 age=stage.living_age
 page(4)
 tick(0.2)
 age=stage.living_age
 check(stage.living_props[0].texture==LivingStageArt.icon("book_fold") and stage.living_props[0].position.x<stage.living_prop_rects[0].position.x,"the guard command triggers the page-folding lunge instead of playing it before the order")
 check(stage.living_prop_kind=="book" and stage.living_age==age and stage.actor_rect.end.y<stage.living_prop_rects[0].position.y,"the Grimoire gives its guard order while all six books stay on screen without overlapping its face")
 page(5)
 check(stage.living_prop_kind=="book" and stage.living_age==age,"the cat's reaction continues the same guarding books rather than recreating their awakening")
 room.load_sector(1)
 var books := 0
 for enemy in room.enemies:
  if enemy is LivingStageEnemy and enemy.role=="book": books+=1
 check(books==6 and room.backdrop_painter.live_book_positions().size()==6 and stage.location_backdrop.foreground_living_props,"the six cinematic books have the same real enemy population and marked floor positions")
 room.load_sector(2)
 room.set_running(false)
 room.state="story"
 director.show_chapter(2,Callable())
 director.set_process(false)
 check(stage.living_prop_kind=="mushroom" and stage.living_age==0,"the garden introduces its own rooted potion crop instead of inheriting the book attack")
 tick(1.1)
 check(stage.snapshot().living_phase=="seal" and stage.living_props[0].modulate!=Color.WHITE,"the same violet control command visibly reaches the cultivated mushrooms")
 tick(1.8)
 check(stage.living_props[0].texture==LivingStageArt.icon("mushroom"),"the cultivation introduction holds the crop in its marked soil bed")
 director.advance()
 tick(0.85)
 check(stage.snapshot().living_phase=="waking","Moss notices uprooting at the same time the crop physically rises")
 director.advance()
 tick(0.3)
 check(stage.living_props[0].texture==LivingStageArt.icon("mushroom_sneeze"),"the protection-order explanation triggers the visible spore attack")
 age=stage.living_age
 director._show_page()
 check(stage.living_age==age and stage.living_prop_kind=="mushroom","Moss's response keeps the same crop and uninterrupted transformation")
 var mushrooms := 0
 for enemy in room.enemies:
  if enemy is LivingStageEnemy and enemy.role=="mushroom": mushrooms+=1
 check(mushrooms==6 and room.backdrop_painter.live_mushroom_positions().size()==6,"the six story plants correspond to the real potion beds and spore-sneezing enemies")
 check(nodes(stage)==allocated and room.projectiles.get_child_count()==0,"all consequences reuse the stage without debris actors, gameplay hazards or node growth")
 director.skip()
 await frames()
 check(room.actors.visible and room.hud.visible,"leaving the richer cinematic restores the playable world")
 room.queue_free()
 await frames()
 for suffix in ["",".tmp",".bak"]:
  if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
 print("STORY CONSEQUENCES RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
