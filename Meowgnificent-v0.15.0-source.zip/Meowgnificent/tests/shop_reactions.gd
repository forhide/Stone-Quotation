extends SceneTree
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func run() -> void:
	var gathering := ShopGathering.new()
	root.add_child(gathering)
	await process_frame
	check(not gathering.visible and gathering.nearest_interaction(Vector2(408,478)).is_empty(),"no friend can be addressed outside a rest stop")
	gathering.configure(3,true)
	check(gathering.hen_sprite.texture==WorldDetailArt.icon("hen") and gathering.hen_root.position==ShopGathering.HEN_FEET,"the picnic hen uses the shared painted illustration at the former chicken's grounded position")
	var resting_hen: Transform2D=gathering.hen_root.transform
	gathering.animate(0.4)
	check(gathering.hen_root.position==ShopGathering.HEN_FEET and gathering.hen_root.transform!=resting_hen,"the painted hen breathes and pecks without moving its floor anchor")
	check(gathering.nearest_interaction(ShopGathering.TABLE_POSITION).is_empty(),"the middle table keeps its trading interaction instead of becoming NPC talk")
	check(gathering.nearest_interaction(ExpeditionMarkers.EXIT_POSITION).is_empty(),"the exit never becomes a friend interaction")
	check(gathering.is_pip_near(ExpeditionMarkers.SHOP_POSITION) and gathering.is_pip_near(ShopGathering.PIP_POSITION),"Pip can be spoken to at both the old merchant anchor and his visible feet")
	check(gathering.nearest_interaction(ShopGathering.PIP_POSITION).is_empty(),"Pip's old E-to-shop interaction remains separate from the T-to-talk shortcut")
	for id: String in ["moss","bloop"]:
		gathering.animate(0.3)
		var feet: Vector2=ShopGathering.FRIEND_POSITIONS[id]
		gathering.set_player_position(feet)
		gathering.animate(0.4)
		gathering.set_player_position(feet)
		check(gathering.nearest_interaction(feet)==id and gathering.prompt.visible,"close range exposes the correct animal's talk cue: "+id)
		var original_position: Vector2=gathering.friend_roots[id].position
		check(gathering.interact(id),"the animal responds to the first deliberate interaction: "+id)
		var first: int=gathering.active_line
		check(not gathering.interact(id) and gathering.active_line==first,"an immediate repeated call cannot skip over dialogue: "+id)
		gathering.animate(0.3)
		check(gathering.reaction_for(id)>0 and gathering.gestures[id].visible,"talk starts a visible one-shot gesture: "+id)
		check(gathering.friend_roots[id].position==original_position and absf(gathering.friend_roots[id].rotation)<0.05,"motion pivots at grounded feet instead of levitating the animal: "+id)
		var visual_clock: float=gathering.elapsed
		var remaining: float=gathering.dialogue_remaining
		await process_frame
		await process_frame
		check(gathering.elapsed==visual_clock and gathering.dialogue_remaining==remaining,"modal pauses cannot advance gestures or consume the speech card timer: "+id)
		check(gathering.interact(id) and gathering.active_line!=first,"a released and repeated interaction advances that animal's conversation: "+id)
	gathering.animate(0.3)
	gathering.set_player_position(ShopGathering.PIP_POSITION)
	gathering.animate(0.4)
	gathering.set_player_position(ShopGathering.PIP_POSITION)
	check(gathering.prompt.visible and gathering.prompt.text.begins_with("T"),"Pip advertises his dedicated talk key while E remains browse")
	check(gathering.interact("pip") and gathering.conversation.portrait.texture==AnimalCast.icon("pip"),"Pip responds with the same squirrel identity as his merchant portrait")
	gathering.animate(0.1)
	var greeting_hen: Transform2D=gathering.hen_root.transform
	var greeting_age: float=gathering.reaction_age.pip
	gathering.reaction_age.pip=ShopGathering.GESTURE_SECONDS
	gathering.animate(0.0)
	check(greeting_hen!=gathering.hen_root.transform and gathering.hen_root.position==ShopGathering.HEN_FEET,"Pip's greeting also produces a distinct grounded response from his painted hen")
	gathering.reaction_age.pip=greeting_age
	gathering.animate(0.0)
	GameLocale.set_language("ko",false)
	gathering.animate(0.1)
	check(gathering.conversation.speaker.text=="핍" and gathering.conversation.body.text.contains("용"),"a live Korean language change updates the active conversation")
	GameLocale.set_language("en",false)
	gathering.animate(0.1)
	check(gathering.conversation.speaker.text=="Pip" and gathering.conversation.body.text.contains("dragon"),"a live English language change preserves the same beat")
	check(gathering.conversation.mouse_filter==Control.MOUSE_FILTER_IGNORE and gathering.prompt.mouse_filter==Control.MOUSE_FILTER_IGNORE,"speech and prompts remain non-modal and cannot consume movement or clicks")
	gathering.set_player_position(Vector2(1100,600))
	gathering.animate(0.4)
	check(not gathering.conversation.visible and gathering.active_actor.is_empty(),"walking away gently dismisses the speech card")
	check(not gathering.prompt.visible,"far-away NPC prompts stay hidden")
	var picnic_text: Dictionary={}
	for id: String in ["moss","bloop","pip"]:
		picnic_text[id]=gathering._lines(id)[0].ko
	gathering.configure(6,true)
	for id: String in ["moss","bloop","pip"]:
		check(gathering._lines(id)[0].ko!=picnic_text[id],"the final rest stop has different context for "+id)
		var lines: Array=gathering._lines(id)
		check(lines.size()==3 and lines.all(func(line: Dictionary) -> bool: return not str(line.ko).is_empty() and not str(line.en).is_empty() and not str(line.gesture).is_empty()),"all three final-stop lines have Korean, English and a matching gesture: "+id)
	gathering.set_player_position(ShopGathering.FRIEND_POSITIONS.moss)
	gathering.interact("moss")
	var anchors: Dictionary=gathering.snapshot().feet.duplicate()
	for i in range(120): gathering.animate(0.1)
	check(gathering.snapshot().feet==anchors,"long-running idle and one-shot reactions never drift either animal's feet")
	check(not gathering.conversation.visible,"a completed exchange expires instead of leaving an overlay on the playfield")
	gathering.animate(0.1)
	check(gathering.ambient_turn>0,"a resting party occasionally reacts on its own without opening a dialogue or spawning combat effects")
	gathering.configure(7,false)
	check(not gathering.visible and gathering.active_actor.is_empty() and not gathering.conversation.visible,"leaving the shop removes dialogue, cue and reactions together")
	check(not gathering.interact("moss") and not gathering.interact("unknown"),"hidden and unknown actors cannot start stale conversations")
	check(gathering.gestures.values().all(func(gesture: Node2D) -> bool: return not gesture.visible) and gathering.friend_roots.values().all(func(actor: Node2D) -> bool: return actor.rotation==0 and actor.scale==Vector2.ONE),"stage changes clear the old reaction drawing and pose before a new shop appears")
	check(gathering.hen_root.rotation==0 and gathering.hen_root.scale==Vector2.ONE and gathering.hen_root.position==ShopGathering.HEN_FEET,"leaving the gathering resets the hen's previous gesture without moving its feet")
	# The story font is shared with the speech card; do not silently depend on a
	# host Korean fallback for newly introduced dialogue syllables.
	var missing: Dictionary={}
	var source := FileAccess.get_file_as_string(ShopGathering.DIALOGUE_PATH)
	for character in source:
		var code: int=character.unicode_at(0)
		if code>=0xAC00 and code<=0xD7A3 and not GameLocale.STORY_FONT.has_char(code): missing[character]=true
	check(missing.is_empty(),"every Korean dialogue syllable exists in the bundled story font: "+str(missing.keys()))
	var layouts_fit := true
	for language in ["ko","en"]:
		GameLocale.set_language(language,false)
		for index in [3,6]:
			gathering.configure(index,true)
			for id: String in ["moss","bloop","pip"]:
				gathering.set_player_position(gathering._anchor(id))
				for line in range(3):
					gathering.animate(0.3)
					gathering.interact(id)
					await process_frame
					var label: Label=gathering.conversation.body
					layouts_fit=layouts_fit and label.get_line_count()*label.get_line_height()<=label.size.y
	check(layouts_fit,"all 36 localized speech layouts fit inside their card without cutting off the last line")
	gathering.queue_free()
	await process_frame
	change_scene_to_file("res://scenes/main.tscn")
	for frame in range(3):
		await physics_frame
		await process_frame
	var room=current_scene
	room.begin_or_restart()
	for stage in [3,6]:
		room.load_sector(stage)
		for frame in range(3): await process_frame
		var party: ShopGathering=room.markers.gathering
		for id: String in ["moss","bloop"]:
			room.player.position=ShopGathering.FRIEND_POSITIONS[id]+Vector2(0,55)
			party.set_player_position(room.player.position)
			party.animate(0.3)
			var gold_before: int=room.run.gold
			var equipment_before: Dictionary=room.run.equipment.duplicate()
			var hp_before: int=room.player.health.current
			room.skills.cooldown_remaining=3.5
			room.spells.cooldown=0.3
			room.interact()
			check(room.state=="playing" and not room.panel.is_open and party.active_actor==id,"real rest stop %d gives E to the nearby friend: %s" % [stage,id])
			check(room.run.gold==gold_before and room.run.equipment==equipment_before and room.player.health.current==hp_before and is_equal_approx(room.skills.cooldown_remaining,3.5) and is_equal_approx(room.spells.cooldown,0.3),"talk cannot spend, equip, heal or reset skill recovery: "+id)
		room.player.position=ExpeditionMarkers.SHOP_POSITION
		party.set_player_position(room.player.position)
		party.animate(0.3)
		var talk := InputEventKey.new()
		talk.pressed=true
		talk.keycode=KEY_T
		room._unhandled_key_input(talk)
		check(party.active_actor=="pip" and room.state=="playing" and not room.panel.is_open,"real T shortcut speaks with Pip without opening the shop")
		var pip_line: int=party.active_line
		party.animate(0.3)
		talk.echo=true
		room._unhandled_key_input(talk)
		check(party.active_line==pip_line,"holding the real talk key cannot advance past Pip's dialogue")
		var before_pause: float=party.dialogue_remaining
		var hen_clock_before: float=party.elapsed
		var hen_pose_before: Transform2D=party.hen_root.transform
		room.open_inventory()
		for frame in range(5): await process_frame
		check(is_equal_approx(party.dialogue_remaining,before_pause),"the real inventory modal pauses active NPC dialogue and gestures")
		check(party.elapsed==hen_clock_before and party.hen_root.transform==hen_pose_before,"the real inventory modal also freezes the painted hen's breathing, peck and greeting")
		room.close_panel()
		room.player.position=ShopGathering.TABLE_POSITION
		room.interact()
		check(room.panel.is_open and room.panel.mode=="shop","the real centre table still opens gear trading after a conversation")
		room.close_panel()
	print("SHOP REACTIONS RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
