extends SceneTree

# Real equipped tools, real projectiles and the actual shielded boss. Primary
# magic is checked through collisions, not by mirroring its configuration.
const WEAPONS := {"practice_wand":"fire","crooked_ash_wand":"leaf","cinderfork_wand":"fire","apprentice_thesis":"wind","frost_whisker_wand":"ice","hopscotch_wand":"stone","pip_feather_staff":"wind","moss_bud_staff":"leaf","bloop_bottle_wand":"water","thunder_spoon":"lightning","bubble_teapot":"water","comet_crayon":"stone"}
var checks := 0
var failures := 0
var room
var previous_profile := ""
var previous_skip := ""
var profile_path := ""

func check(ok: bool,message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)

func _initialize() -> void: call_deferred("run")

func frames(count: int=2) -> void:
 for i in range(count):
  await physics_frame
  await process_frame

func clear_combat() -> void:
 room.skills.clear_transients()
 for child in room.projectiles.get_children():
  child.queue_free()
 for enemy in room.enemies:
  if is_instance_valid(enemy): enemy.queue_free()
 room.enemies.clear()
 room.spells.pending=false
 room.spells.pending_magic.clear()
 room.spells.pending_config.clear()
 room.spells.cooldown=0
 room.player.roll_time=0
 room.player.roll_cooldown=0
 room.player.position=Vector2(400,450)
 room.player.active=true
 room.state="playing"
 room.exit_open=false
 room.fires.clear()
 await frames()

func equip(id: String) -> void:
 if not room.run.inventory.has(id): room.run.add_item(id)
 room.equip_gear(id)

func enemy_at(point: Vector2,boss: bool=false) -> CandleSlime:
 var enemy: CandleSlime=PerfectExaminer.new() if boss else CandleSlime.new()
 enemy.position=point
 enemy.setup({"hp":1000,"speed":83.0,"contact_damage":12,"radius":18.0},room.player,room.bounds)
 room.actors.add_child(enemy)
 enemy.set_physics_process(false)
 enemy.active=true
 room.enemies.append(enemy)
 return enemy

func cast_shot(outcome: String) -> SpellProjectile:
 room.spells.cooldown=0
 room.spells.resolver.forced=outcome
 # Choose an off-angle/backward mishap, not the separate feet-puff variant.
 room.spells.resolver.rng.seed=2
 room.spells.cast(Vector2.RIGHT)
 room.spells._physics_process(0.13)
 for child in room.projectiles.get_children():
  if child is SpellProjectile and not child.is_queued_for_deletion():
   child.set_physics_process(false)
   return child
 return null

func tick(shot: SpellProjectile,duration: float) -> void:
 var remaining := duration
 while remaining>0 and not shot.spent:
  shot._physics_process(minf(remaining,1.0/60.0))
  remaining-=1.0/60.0

func run() -> void:
 previous_profile=OS.get_environment("MEOW_PROFILE_PATH")
 previous_skip=OS.get_environment("MEOW_SKIP_STORY")
 profile_path="/tmp/meow-elemental-%d.json" % OS.get_process_id()
 OS.set_environment("MEOW_PROFILE_PATH",profile_path)
 OS.set_environment("MEOW_SKIP_STORY","1")
 change_scene_to_file("res://scenes/main.tscn")
 await frames(5)
 room=current_scene
 room.begin_or_restart()
 room.set_process(false)
 room.set_physics_process(false)
 room.player.set_physics_process(false)
 room.spells.set_physics_process(false)
 room.spells.input_blocked_until_release=true
 room.skills.set_physics_process(false)
 for prop in room.props:
  if is_instance_valid(prop): prop.queue_free()
 room.props.clear()
 await clear_combat()
 room.run.inventory.clear()
 room.run.equipment={"wand":"","collar":"","charm":""}
 check(BasicMagic.for_run(room.run).id=="fire","bare paws retain the opening story's small fireball")
 room.run.equipment.wand="frost_whisker_wand"
 check(BasicMagic.for_run(room.run).id=="fire","unowned spoofed equipment cannot grant ice magic")
 room.run.equipment.wand=""
 var families := {}
 for id: String in WEAPONS:
  await clear_combat()
  equip(id)
  var magic := BasicMagic.for_run(room.run)
  families[magic.id]=true
  check(str(magic.id)==WEAPONS[id] and EquipmentArt.has_icon(id),id+": equipped icon and owned tool select the intended basic element")
  var shot := cast_shot("success")
  check(shot!=null and shot.element==WEAPONS[id] and shot.damage==CharacterStats.for_room(room).spell_damage,id+": emitted basic projectile uses the actual equipped element and stat damage")
 check(families.size()==7,"the twelve tools cover seven visually distinct basic magic families")
 await clear_combat()
 equip("frost_whisker_wand")
 room.spells.resolver.forced="success"
 room.spells.cast(Vector2.RIGHT)
 var damage_at_start := int(room.spells.pending_config.success_damage)
 equip("cinderfork_wand")
 var cooldown_at_swap: float=room.spells.cooldown
 room.spells._physics_process(0.13)
 var locked: SpellProjectile
 for child in room.projectiles.get_children():
  if child is SpellProjectile: locked=child
 check(locked!=null and locked.element=="ice" and locked.damage==damage_at_start,"changing equipment during paw anticipation cannot transform a prepared spell")
 check(cooldown_at_swap>0 and room.spells.cooldown>0,"changing the element cannot bypass the shared primary cooldown")
 await clear_combat()
 equip("bloop_bottle_wand")
 var water_main := enemy_at(Vector2(610,450))
 var water_near := enemy_at(Vector2(635,475))
 var water_far := enemy_at(Vector2(760,450))
 var water := cast_shot("success")
 tick(water,0.7)
 check(water_main.health.current<1000 and water_near.health.current<1000 and water_far.health.current==1000,"water hits its target and splashes only nearby foes")
 check(room.fires.is_empty(),"water leaves no misleading floor fire")
 await clear_combat()
 equip("frost_whisker_wand")
 var frozen := enemy_at(Vector2(610,450))
 var ice := cast_shot("success")
 tick(ice,0.7)
 check(frozen.health.current<1000 and float(frozen.config.speed)<83,"ice damage briefly slows the struck enemy")
 room.skills._tick_statuses(1.0)
 check(is_equal_approx(float(frozen.config.speed),83.0),"ice slow restores the enemy's true speed after its short duration")
 await clear_combat()
 equip("pip_feather_staff")
 var wind_a := enemy_at(Vector2(560,450))
 var wind_b := enemy_at(Vector2(640,450))
 var wind_c := enemy_at(Vector2(720,450))
 var wind := cast_shot("success")
 tick(wind,1.0)
 check(wind_a.health.current<1000 and wind_b.health.current<1000 and wind_c.health.current==1000,"wind passes through exactly two foes without repeatedly hitting the first")
 check(wind_a.knockback.length()>240,"wind's breeze adds a visible extra shove")
 await clear_combat()
 equip("hopscotch_wand")
 var pebble_foe := enemy_at(Vector2(610,450))
 var pebble := cast_shot("success")
 check(pebble.speed<float(room.balance.fireball.speed) and pebble.radius>9,"stone visibly travels slower with a larger pebble silhouette")
 tick(pebble,0.8)
 check(pebble_foe.health.current<1000 and pebble_foe.knockback.length()>300,"stone's collision lands with a heavier push")
 await clear_combat()
 equip("moss_bud_staff")
 enemy_at(Vector2(610,490))
 var leaf := cast_shot("success")
 tick(leaf,0.1)
 check(leaf.direction.y>0 and leaf.direction.y<0.25,"leaf magic curves gently toward a nearby foe rather than snapping onto it")
 await clear_combat()
 equip("thunder_spoon")
 var lightning := cast_shot("success")
 check(lightning.speed>float(room.balance.fireball.speed),"the lightning spoon sends a faster small spark")
 var family_tools := {"fire":"practice_wand","water":"bloop_bottle_wand","ice":"frost_whisker_wand","wind":"pip_feather_staff","stone":"hopscotch_wand","leaf":"moss_bud_staff","lightning":"thunder_spoon"}
 for family: String in family_tools:
  for outcome: String in ["success","miscast","overreaction"]:
   await clear_combat()
   equip(family_tools[family])
   var boss := enemy_at(Vector2(740,450),true) as PerfectExaminer
   var shot := cast_shot(outcome)
   if shot==null:
    check(false,family+"/"+outcome+": cast emitted a collision-test projectile")
    continue
   shot.position=boss.position-shot.direction*60
   tick(shot,0.4)
   check(boss.health.current==1000 and boss.blocked_spells>0 and boss.barrier_active if outcome=="success" else boss.health.current<1000 and not boss.barrier_active,family+"/"+outcome+": shield still predicts controlled magic and opens only to a real accident")
   check(room.fires.is_empty(),family+"/"+outcome+": projectile path never invents floor flames")
 # Exercise the third mishap variant for every family. It must still be an
 # accident near the cat, but only the fire wand is allowed to ignite the floor.
 for family: String in family_tools:
  await clear_combat()
  equip(family_tools[family])
  room.spells.resolver.forced="miscast"
  var chosen_seed := 0
  for candidate in range(50):
   var rng := RandomNumberGenerator.new()
   rng.seed=candidate
   if rng.randi_range(0,2)==2:
    chosen_seed=candidate
    break
  room.spells.resolver.rng.seed=chosen_seed
  room.spells.cast(Vector2.RIGHT)
  room.spells._physics_process(0.13)
  check(room.player.roll_time>0 and (not room.fires.is_empty() if family=="fire" else room.fires.is_empty()),family+": feet mishap creates the element's own accident, with flames only for fire")
 await clear_combat()
 room.free()
 await frames()
 OS.set_environment("MEOW_PROFILE_PATH",previous_profile)
 OS.set_environment("MEOW_SKIP_STORY",previous_skip)
 if FileAccess.file_exists(profile_path): DirAccess.remove_absolute(profile_path)
 print("ELEMENTAL MAGIC RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
