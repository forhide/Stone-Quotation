class_name LivingStageArt
extends RefCounted

# Shared identity and crop source for story tableaux and actual room enemies.
const SHEET: Texture2D = preload("res://art/enemies/living_reagents.png")
const REGIONS := {
	"book": Rect2(96,154,490,358),
	"book_fold": Rect2(681,187,495,367),
	"mushroom": Rect2(127,727,414,413),
	"mushroom_sneeze": Rect2(710,806,456,318)
}
static var _icons: Dictionary = {}

static func icon(key: String) -> Texture2D:
	if not REGIONS.has(key): return null
	if not _icons.has(key):
		var texture := AtlasTexture.new()
		texture.atlas=SHEET
		texture.region=REGIONS[key]
		texture.filter_clip=true
		_icons[key]=texture
	return _icons[key]
