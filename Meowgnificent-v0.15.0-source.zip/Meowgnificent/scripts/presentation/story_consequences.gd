class_name StoryConsequences
extends RefCounted

# One painted set and a fixed number of ink accents. These remain cosmetic;
# no physics actors, timers or debris nodes are allocated during dialogue.
const RUINS: Texture2D=preload("res://art/story/props/exam_aftermath.png")
const SOOT_SHEET: Texture2D=preload("res://art/story/props/exam_sooty_cast.png")
const SOOT := Color("534856")
static var _soot: Dictionary = {}
const VIOLET := Color("bb9acc")
static var CRACK := PackedVector2Array([Vector2(-27,-18),Vector2(-8,-9),Vector2(-16,6),Vector2(6,14),Vector2(3,26)])
static var SEAL := _seal()

static func _seal() -> PackedVector2Array:
 var p := PackedVector2Array()
 for i in range(7): p.append(Vector2.from_angle(i*TAU/6)*16)
 return p

static func damage_amount(age: float) -> float:
 return smoothstep(0.12,0.65,age)

static func draw_ruins(c: CanvasItem,extent: Vector2,age: float) -> void:
 var source := RUINS.get_size()
 var crop_h := source.x*extent.y/extent.x
 var crop := Rect2(0,(source.y-crop_h)*0.53,source.x,crop_h)
 c.draw_texture_rect_region(RUINS,Rect2(Vector2.ZERO,extent),crop,Color(1,1,1,damage_amount(age)))

static func draw_debris(c: CanvasItem,age: float) -> void:
 # A short, bounded shower settles; the painted wreckage remains afterwards.
 var fall := clampf(age/1.2,0,1)
 for i in range(12):
  var x := 35.0+i*31+sin(i*1.7)*13
  var at := Vector2(x,60+float(i%4)*45+fall*220)
  var fade := (1-smoothstep(0.85,1.5,age))*0.8
  if fade<=0: break
  c.draw_set_transform(at,age*(0.6+float(i%3)*0.3)+i)
  c.draw_rect(Rect2(-5,-3,10,6),Color(Color("e4d0b1"),fade))
 c.draw_set_transform(Vector2.ZERO)

static func sooty_actor(owl: bool) -> Texture2D:
 if not _soot.has(owl):
  var icon := AtlasTexture.new()
  icon.atlas=SOOT_SHEET
  icon.region=Rect2(960,77,733,780) if owl else Rect2(123,40,740,809)
  icon.filter_clip=true
  _soot[owl]=icon
 return _soot[owl]

static func draw_soot(c: CanvasItem,sprite: TextureRect,owl: bool,age: float) -> void:
 # The soot itself is painted into the two expressive aftermath actors. Only
 # brief ash and a dislodged feather animate separately, never round decals.
 if not sprite.visible or age>2.1: return
 var tip := sprite.get_transform()*(Vector2(0.61,0.13)*sprite.size)
 var fade := clampf((2.1-age)/1.5,0,1)
 c.draw_circle(tip+Vector2(sin(age*3)*3,-age*12),4+age*2,Color(SOOT,fade*0.18),true,-1,true)
 if owl and age>0.7:
  var t := clampf((age-0.7)/1.4,0,1)
  var at := tip+Vector2(-19+sin(t*5)*11,16+t*64)
  c.draw_set_transform(at,sin(t*5)*0.7)
  c.draw_line(Vector2(0,-7),Vector2(0,7),Color(Color("d1b994"),fade),3,true)
  c.draw_line(Vector2(-4,-4),Vector2(0,5),Color(Color("b29a84"),fade),3,true)
  c.draw_set_transform(Vector2.ZERO)

static func living_phase(age: float) -> String:
 return "quiet" if age<0.7 else "seal" if age<1.5 else "waking" if age<2.5 else "guarding"

static func draw_living(c: CanvasItem,kind: String,rects: Array[Rect2],age: float) -> void:
 if kind.is_empty(): return
 var progress := smoothstep(0.7,1.55,age)
 var source := Vector2(1024,65) if kind=="book" else Vector2(1052,120)
 # The same control glyph is used on live enemies and room landmarks.
 c.draw_set_transform(source,age*0.08)
 if progress>0: c.draw_polyline(SEAL,Color(VIOLET,0.6*progress),2,true)
 c.draw_set_transform(Vector2.ZERO)
 for i in range(rects.size()):
  var rect := rects[i]
  var feet := rect.position+Vector2(rect.size.x*0.5,rect.size.y-3)
  if kind=="mushroom":
   var bed := Rect2(rect.position+Vector2(-9,rect.size.y-16),Vector2(rect.size.x+18,25))
   WorldDetailArt.draw_floor(c,"soil_bed",bed)
  elif age<1.7:
   # Ordinary bound volumes at rest before the spine/eyes wake up.
   var at := feet+Vector2(-27,-19)
   c.draw_rect(Rect2(at,Vector2(54,18)),Color("aaa5bd"))
   c.draw_rect(Rect2(at+Vector2(4,3),Vector2(46,11)),Color("fff0cc"))
   c.draw_line(at+Vector2(0,18),at+Vector2(54,18),Color("7c6c85"),2,true)
  if progress>0 and age<3.2:
   var lead := smoothstep(0.7+i*0.06,1.35+i*0.06,age)
   c.draw_line(source,source.lerp(feet,lead),Color(VIOLET,0.28*progress),1.5,true)
  c.draw_set_transform(feet,0,Vector2(1,0.32))
  c.draw_arc(Vector2.ZERO,26,0,TAU,24,Color(VIOLET,(0.25+sin(age*3)*0.06)*progress),2,true)
  c.draw_set_transform(Vector2.ZERO)
 var label := "RETURNED BOOKS → GUARD DUTY" if kind=="book" else "POTION REAGENTS → KEEP OUT"
 var font := GameLocale.STORY_FONT
 var command := smoothstep(2.5,2.85,age)
 if command>0: c.draw_string(font,Vector2(434,379),GameLocale.text(label),HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color(Color("806783"),command))
 if kind=="mushroom":
  # A cultivation marker and reagent vial anchor these as school-grown crops.
  c.draw_line(Vector2(415,269),Vector2(415,322),Color("ad9278"),4,true)
  c.draw_rect(Rect2(371,247,93,28),Color("f5e4bc"))
  c.draw_string(font,Vector2(378,266),GameLocale.text("POTION CROP"),HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color("795f55"))
  c.draw_style_box(_vial_style(),Rect2(389,293,23,27))
  c.draw_rect(Rect2(395,288,10,8),Color("ad9278"))

static var _vial: StyleBoxFlat
static func _vial_style() -> StyleBoxFlat:
 if _vial==null:
  _vial=StyleBoxFlat.new()
  _vial.bg_color=Color("b8d2bf")
  _vial.border_color=Color("8aa796")
  _vial.set_border_width_all(2)
  _vial.set_corner_radius_all(6)
 return _vial
