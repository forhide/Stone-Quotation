class_name HiResArt
extends RefCounted

# Portable textures retain the original atlas coordinate space while storing
# denser source pixels. Shader UVs and region crops use those logical dimensions.
static func logical_size(texture: Texture2D) -> Vector2:
	if texture is PortableCompressedTexture2D and texture.size_override!=Vector2.ZERO:
		return texture.size_override
	return texture.get_size()
