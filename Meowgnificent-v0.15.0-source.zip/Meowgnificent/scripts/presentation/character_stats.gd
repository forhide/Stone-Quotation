class_name CharacterStats
extends RefCounted

# These are the actual normal-outcome values used by movement, health, spells
# and item skills. Preview replaces one slot on a shadow run; it never equips,
# heals, charges gold, or changes the live run's cooldown.
const ROWS := [
 {"key":"max_hp","label":"Max vitality","unit":"","digits":0,"lower":false},
 {"key":"speed","label":"Move speed","unit":"","digits":0,"lower":false},
 {"key":"spell_damage","label":"Spell damage","unit":"","digits":0,"lower":false},
 {"key":"spell_cooldown","label":"Spell recovery","unit":"s","digits":2,"lower":true},
 {"key":"roll_damage","label":"Roll damage","unit":"","digits":0,"lower":false},
 {"key":"roll_cooldown","label":"Roll recovery","unit":"s","digits":2,"lower":true},
 {"key":"pickup_radius","label":"Pickup reach","unit":"","digits":0,"lower":false},
 {"key":"skill_damage","label":"Special damage","unit":"","digits":0,"lower":false},
 {"key":"skill_cooldown","label":"Special recovery","unit":"s","digits":2,"lower":true},
 {"key":"skill_radius","label":"Special reach","unit":"","digits":0,"lower":false}
]

static func compute(balance: Dictionary, legacy: Dictionary, catalog: Dictionary, equipment: Dictionary, inventory: Array, definitions: Dictionary, preview_item_id: String="", include_equipment: bool=true) -> Dictionary:
 var shadow := ExpeditionRun.new()
 shadow.catalog=catalog
 shadow.equipment=equipment.duplicate(true)
 shadow.inventory.assign(inventory)
 if catalog.has(preview_item_id):
  var candidate: Dictionary=catalog[preview_item_id]
  var slot := str(candidate.get("slot",""))
  if ExpeditionRun.SLOTS.has(slot):
   if not shadow.inventory.has(preview_item_id): shadow.inventory.append(preview_item_id)
   shadow.equipment[slot]=preview_item_id
 var modifiers: Dictionary=shadow.stats()
 if not include_equipment:
  var empty := ExpeditionRun.new()
  modifiers=empty.stats()
 var player_data: Dictionary=balance.player
 var fireball: Dictionary=balance.fireball
 var id := str(shadow.equipment.get("wand",""))
 var info: Dictionary=catalog.get(id,{}) if shadow.inventory.has(id) else {}
 var skill_id := str(info.get("skill_id",""))
 var skill: Dictionary=definitions.get(skill_id,{})
 var result := {
  "max_hp":int(player_data.hp)+int(legacy.get("max_hp_bonus",0))+int(modifiers.max_hp_bonus),
  "speed":float(player_data.speed)+float(modifiers.speed_bonus),
  "spell_damage":int(fireball.success_damage)+int(modifiers.spell_damage_bonus),
  "spell_miscast_damage":int(fireball.miscast_damage)+int(modifiers.spell_damage_bonus),
  "spell_overreaction_damage":int(fireball.overreaction_damage)+int(modifiers.spell_damage_bonus),
  "spell_cooldown":maxf(0.35,float(fireball.cooldown)*float(modifiers.spell_cooldown_multiplier)),
  "roll_damage":30+int(modifiers.roll_damage_bonus),
  "roll_cooldown":1.25*float(modifiers.roll_cooldown_multiplier),
  "pickup_radius":LootPickup.MAGNET_RADIUS+float(legacy.get("pickup_radius_bonus",0))+float(modifiers.pickup_radius_bonus),
  "skill_id":skill_id if not skill.is_empty() else "",
  "skill_name":str(skill.get("name","No special skill")),
  "skill_damage":0,"skill_cooldown":0.0,"skill_radius":0.0,"skill_duration":0.0,
  "equipment":shadow.equipment.duplicate(true),"modifiers":modifiers.duplicate(true)
 }
 if not skill.is_empty():
  result.skill_damage=0 if skill_id=="bubble_guard" else maxi(0,roundi(float(skill.damage)+float(modifiers.skill_damage_bonus)))
  result.skill_cooldown=maxf(2.0,float(skill.cooldown)*float(modifiers.skill_cooldown_multiplier))
  result.skill_radius=clampf(float(skill.radius)+float(modifiers.skill_radius_bonus),8.0,260.0)
  result.skill_duration=float(skill.duration)
 return result

static func for_room(room: Node, preview_item_id: String="", include_equipment: bool=true) -> Dictionary:
 var definitions: Dictionary={}
 if room.get("skills")!=null: definitions=room.skills.definitions
 return compute(room.balance,room.profile.bonuses(),room.run.catalog,room.run.equipment,room.run.inventory,definitions,preview_item_id,include_equipment)

static func improvement(row: Dictionary, before: Dictionary, after: Dictionary) -> int:
 var change := float(after.get(row.key,0))-float(before.get(row.key,0))
 if is_zero_approx(change): return 0
 return 1 if (change<0 if bool(row.lower) else change>0) else -1

static func format_value(row: Dictionary, value: float) -> String:
 var number := str(roundi(value)) if int(row.digits)==0 else ("%.2f" % value if int(row.digits)==2 else "%.1f" % value)
 return number+(GameLocale.text("s") if str(row.unit)=="s" else "")
