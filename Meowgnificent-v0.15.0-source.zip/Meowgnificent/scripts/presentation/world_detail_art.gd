class_name WorldDetailArt
extends RefCounted

# Small authored HD props belong to the same painted world as the room plates.
# Crop each sprite once; room-floor art is still baked into its arrival cache.
const SHEET: Texture2D=preload("res://art/environments/storybook_world_details.png")
# Alpha bounds were checked against the unchanged1536x1024 painting.
# Three transparent pixels preserve antialiased edges without neighbor bleed.
const REGIONS := {
 "hen":Rect2(71,143,386,376),
 "picnic_mat":Rect2(470,187,687,312),
 "runner":Rect2(1179,31,290,551),
 "paver":Rect2(14,660,468,281),
 "soil_bed":Rect2(506,662,525,262),
 "memorial":Rect2(1052,692,470,232)
}
static var _parts: Dictionary={}

static func icon(kind: String) -> Texture2D:
 if not REGIONS.has(kind): return null
 if not _parts.has(kind):
  var sprite := AtlasTexture.new()
  sprite.atlas=SHEET
  sprite.region=REGIONS[kind]
  sprite.filter_clip=true
  _parts[kind]=sprite
 return _parts[kind]

static func draw_floor(canvas: CanvasItem,kind: String,rect: Rect2,tint: Color=Color.WHITE) -> void:
 var art := icon(kind)
 if art!=null: canvas.draw_texture_rect(art,rect,false,tint)
