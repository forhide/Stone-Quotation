class_name AnimalCast
extends RefCounted

# One shared HD painted atlas supplies story portraits, world friends and boss.
# Explicit row-major identity maps avoid centroid-rounding atlas swaps.
const SHEET: Texture2D = preload("res://art/hd/animal_cast.res")
const REGIONS := {
	"professor":Rect2(37,4,449,486),
	"pip":Rect2(521,30,504,455),
	"moss":Rect2(1071,38,433,448),
	"bloop":Rect2(8,519,456,446),
	"examiner":Rect2(517,484,511,492),
	"examiner_hurt":Rect2(1037,495,491,479)
}
const SPECIES := {"professor":"owl", "pip":"squirrel", "moss":"hedgehog", "bloop":"otter", "examiner":"fox", "examiner_hurt":"fox", "perfect_wizard":"fox"}
static var _icons: Dictionary={}

static func region(id: String) -> Rect2:
	if id=="perfect_wizard": id="examiner"
	return REGIONS.get(id,Rect2())

static func species(id: String) -> String:
	return str(SPECIES.get(id,""))

static func icon(id: String) -> Texture2D:
	if id=="perfect_wizard": id="examiner"
	if not REGIONS.has(id): return null
	if not _icons.has(id):
		var texture := AtlasTexture.new()
		texture.atlas=SHEET
		texture.region=REGIONS[id]
		texture.filter_clip=true
		_icons[id]=texture
	return _icons[id]
