class_name CatPortrait
extends TextureRect

const SHEET: Texture2D = WizardCatVisual.ACTION_SHEET
const STATES := {"neutral": 0, "annoyed": 1, "sleepy": 2, "startled": 3}
var expression := ""
var faces: Array[AtlasTexture] = []

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	var rectangles := [Rect2(70,12,430,350),Rect2(570,20,440,350),Rect2(568,515,430,335),Rect2(40,518,470,360)]
	for rectangle: Rect2 in rectangles:
		var face := AtlasTexture.new()
		face.atlas = SHEET
		face.region = rectangle
		face.filter_clip = true
		faces.append(face)
	set_expression("neutral")

func set_expression(value: String) -> void:
	if not STATES.has(value):
		value = "neutral"
	if value != expression:
		expression = value
		texture = faces[int(STATES[value])]

func sync_state(run_state: String, last_outcome: String, outcome_seconds: float, hit_seconds: float) -> void:
	if run_state in ["paused","defeated"]:
		set_expression("sleepy")
	elif hit_seconds>0.0 or (last_outcome=="overreaction" and outcome_seconds>0.0):
		set_expression("startled")
	elif last_outcome=="miscast" and outcome_seconds>0.0:
		set_expression("annoyed")
	else:
		set_expression("neutral")
