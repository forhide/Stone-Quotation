class_name ShopConversation
extends Control

# A light, non-modal speech card. It never receives keyboard or pointer input;
# the room keeps ownership of E/T and movement remains available.
var portrait: TextureRect
var speaker: Label
var body: Label
var hint: Label
var tail_x := 180.0
var opacity := 1.0
var tail_side := false

func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	z_index=35
	size=Vector2(568,176)
	portrait=TextureRect.new()
	portrait.position=Vector2(20,30)
	portrait.size=Vector2(92,112)
	portrait.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	portrait.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	portrait.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(portrait)
	speaker=_label(Vector2(132,15),Vector2(411,30),20,Color("795f62"))
	body=_label(Vector2(132,49),Vector2(411,91),19,Color("65564f"))
	body.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	hint=_label(Vector2(132,145),Vector2(411,23),12,Color("a08a81"))
	visible=false

func _label(at: Vector2, box: Vector2, font_size: int, ink: Color) -> Label:
	var label := Label.new()
	label.position=at
	label.size=box
	label.add_theme_font_override("font",GameLocale.STORY_FONT)
	label.add_theme_font_size_override("font_size",font_size)
	label.add_theme_color_override("font_color",ink)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(label)
	return label

func show_line(actor: String, actor_name: String, text: String, next_hint: String, anchor: Vector2) -> void:
	position=Vector2(clampf(anchor.x-284,180,532),188)
	tail_side=actor=="pip"
	if tail_side: position=Vector2(701,206)
	tail_x=clampf(anchor.x-position.x,38,size.x-38)
	portrait.texture=AnimalCast.icon(actor)
	speaker.text=actor_name
	body.text=text
	hint.text=next_hint
	visible=true
	opacity=1.0
	modulate.a=1
	queue_redraw()

func set_opacity(value: float) -> void:
	opacity=clampf(value,0,1)
	modulate.a=opacity

func dismiss() -> void:
	visible=false

func _draw() -> void:
	var shadow := StyleBoxFlat.new()
	shadow.bg_color=Color(0.28,0.22,0.25,0.14)
	shadow.set_corner_radius_all(22)
	draw_style_box(shadow,Rect2(3,5,size.x,size.y))
	var card := StyleBoxFlat.new()
	card.bg_color=Color("fff9eb")
	card.border_color=Color("c6ad98")
	card.set_border_width_all(2)
	card.set_corner_radius_all(22)
	draw_style_box(card,Rect2(Vector2.ZERO,size))
	if tail_side:
		draw_colored_polygon(PackedVector2Array([Vector2(2,70),Vector2(2,91),Vector2(-20,84)]),Color("fff9eb"))
		draw_polyline(PackedVector2Array([Vector2(1,70),Vector2(-20,84),Vector2(1,91)]),Color("c6ad98"),2,true)
	else:
		draw_colored_polygon(PackedVector2Array([Vector2(tail_x-11,size.y-2),Vector2(tail_x+8,size.y-2),Vector2(tail_x-5,size.y+15)]),Color("fff9eb"))
		draw_polyline(PackedVector2Array([Vector2(tail_x-11,size.y-1),Vector2(tail_x-5,size.y+15),Vector2(tail_x+8,size.y-1)]),Color("c6ad98"),2,true)
	draw_line(Vector2(122,25),Vector2(122,149),Color("e8d9bf"),1,true)
