class_name WizardCat
extends CharacterBody2D


signal hurt
signal wall_bumped(point: Vector2)
var config: Dictionary
var health: CombatHealth
var bounds: Rect2
var aim := Vector2.RIGHT
var invulnerability := 0.0
var wobble := 0.0
var cast_pose := 0.0
var cast_prepare := 0.0
var cast_outcome := "success"
var cast_element := "fire"
var cast_aim := Vector2.RIGHT
const SKILL_POSE_SECONDS := 0.68
var skill_pose_time := 0.0
var skill_pose_id := ""
var skill_pose_outcome := "success"
var skill_pose_direction := Vector2.RIGHT
var skill_pose_serial := 0
var hit_reaction := 0.0
var active := true
var presentation_scale := 1.0
var roll_time := 0.0
var roll_cooldown := 0.0
var roll_direction := Vector2.RIGHT
var roll_speed := 530.0
var roll_spin := 0.0
var roll_hits: Array[int] = []
var recoil := Vector2.ZERO
var walk_distance := 0.0
var ground_speed := 0.0
var walk_direction := Vector2.RIGHT
var visual: WizardCatVisual
var floor_point: Vector2:
	get: return position

func setup(settings: Dictionary, room_bounds: Rect2) -> void:
	config = settings
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	collision_layer = 1
	collision_mask = 0
	var shape := CircleShape2D.new()
	shape.radius = float(config.radius)
	var collider := CollisionShape2D.new()
	collider.shape = shape
	add_child(collider)

func begin_skill_pose(id: String, outcome: String, direction: Vector2) -> void:
	skill_pose_id=id
	skill_pose_outcome=outcome
	skill_pose_direction=direction
	skill_pose_time=SKILL_POSE_SECONDS
	skill_pose_serial+=1
	cast_aim=direction
	cast_pose=0.0
	cast_prepare=0.0

func clear_skill_pose() -> void:
	skill_pose_time=0.0
	skill_pose_id=""

func start_roll(direction: Vector2, panic: bool = false) -> bool:
	if not active or roll_time>0 or (roll_cooldown>0 and not panic):
		return false
	roll_direction = direction.normalized() if direction.length_squared()>0.01 else aim
	roll_time = 0.42 if panic else 0.36
	roll_speed = 430.0 if panic else 530.0
	roll_cooldown = float(config.get("roll_cooldown",1.25))
	invulnerability = maxf(invulnerability,roll_time)
	roll_hits.clear()
	return true

func _physics_process(delta: float) -> void:
	if not active:
		velocity = Vector2.ZERO
		ground_speed = 0.0
		queue_redraw()
		return
	invulnerability = maxf(0.0,invulnerability-delta)
	skill_pose_time=maxf(0,skill_pose_time-delta)
	cast_pose = maxf(0.0,cast_pose-delta*2.6)
	hit_reaction = maxf(0.0,hit_reaction-delta)
	roll_cooldown = maxf(0.0,roll_cooldown-delta)
	var direction := Input.get_vector("move_left","move_right","move_up","move_down")
	if Input.is_action_just_pressed("roll"):
		start_roll(direction if direction!=Vector2.ZERO else aim)
	var mouse_direction := get_global_mouse_position()-global_position
	if mouse_direction.length_squared()>4:
		aim = mouse_direction.normalized()
	var rolling := roll_time>0
	if rolling:
		roll_time = maxf(0.0,roll_time-delta)
		velocity = roll_direction*roll_speed
		roll_spin += delta*20.0*signf(roll_direction.x if absf(roll_direction.x)>0.1 else 1.0)
	else:
		roll_spin = lerpf(roll_spin,roundf(roll_spin/TAU)*TAU,minf(1.0,delta*18))
		var rate := float(config.acceleration) if direction!=Vector2.ZERO else float(config.friction)
		velocity = velocity.move_toward(direction*float(config.speed),rate*delta)
	velocity += recoil*delta*8
	recoil = recoil.move_toward(Vector2.ZERO,delta*900)
	var previous_position := position
	move_and_slide()
	var radius := float(config.radius)
	var clamped := position.clamp(bounds.position+Vector2.ONE*radius,bounds.end-Vector2.ONE*radius)
	if clamped!=position and roll_time>0:
		roll_time = 0
		recoil = -roll_direction*220
		hit_reaction=0.32
		wall_bumped.emit(clamped)
	position = clamped
	var travelled := position - previous_position
	ground_speed = 0.0 if rolling else travelled.length() / maxf(delta, 0.0001)
	if not rolling and travelled.length_squared() > 0.0001:
		walk_distance += travelled.length()
		walk_direction = travelled.normalized()
	wobble += delta*velocity.length()*0.055
	queue_redraw()

func take_damage(amount: int, source: Vector2) -> void:
	if not active or invulnerability>0:
		return
	if health.damage(amount):
		hit_reaction=0.38
		invulnerability = float(config.invulnerability)
		recoil += (position-source).normalized()*180
		hurt.emit()

func _ready() -> void:
	visual = WizardCatVisual.new()
	add_child(visual)

func _draw() -> void:
	var shadow_size := Vector2(33,7)*presentation_scale
	var points := PackedVector2Array()
	for i in range(40):
		var a := TAU*i/40.0
		points.append(Vector2(-4,4)*presentation_scale+Vector2(cos(a),sin(a))*shadow_size)
	draw_colored_polygon(points,Color(0.38,0.30,0.29,0.15))
	modulate.a = 0.65 if invulnerability>0 and fmod(invulnerability,0.14)<0.07 else 1.0
	if active and roll_time<=0:
		var center := Vector2(0,-22)
		draw_arc(center,66,aim.angle()-0.09,aim.angle()+0.09,10,Color(0.9,0.85,0.7,0.55),1.5,true)
	if roll_time>0:
		draw_set_transform(Vector2(0,5),roll_direction.angle(),Vector2(1,1+sin(wobble*2)*0.07))
		draw_texture_rect(SpellArt.part("smoke"),Rect2(-105,-30,105,48),false)
		draw_set_transform(Vector2.ZERO)
