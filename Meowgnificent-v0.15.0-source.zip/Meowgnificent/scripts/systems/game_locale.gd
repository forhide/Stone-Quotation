class_name GameLocale
extends RefCounted

const STORY_FONT: Font = preload("res://art/fonts/Pretendard-Medium.otf")
static var current: String:
 get:
  var node := service()
  return str(node.current) if node!=null else "ko"
static var save_error: bool:
 get:
  var node := service()
  return bool(node.save_error) if node!=null else false

static func service() -> Node:
 var tree := Engine.get_main_loop() as SceneTree
 return tree.root.get_node_or_null("Language") if tree!=null else null

static func text(source: String) -> String:
 return str(TranslationServer.translate(source))

static func story_text(page: Dictionary) -> String:
 return str(page.get("text_en",page.get("text",""))) if current=="en" else str(page.get("text",""))

static func set_language(value: String, persist: bool=true) -> bool:
 var node := service()
 return bool(node.set_language(value,persist)) if node!=null else false
