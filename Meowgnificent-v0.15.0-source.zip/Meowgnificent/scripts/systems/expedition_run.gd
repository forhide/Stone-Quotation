class_name ExpeditionRun
extends RefCounted

signal changed

const INVENTORY_LIMIT := 18
const SLOTS := ["wand", "collar", "charm"]
const HEAL_ID := "sardine_tin"
const HEAL_PRICE := 12
const HEAL_AMOUNT := 35
const CATALOG_PATH := "res://data/items.json"

var gold: int = 0
var stage_index: int = 0
var enemies_defeated: int = 0
var collected_gold: int = 0
# Owned items include equipped copies. Equipping never consumes or duplicates one.
var inventory: Array[String] = []
var equipment: Dictionary = {"wand":"", "collar":"", "charm":""}
var catalog: Dictionary = {}
var shop_rng := RandomNumberGenerator.new()

func _init() -> void:
	shop_rng.randomize()
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(CATALOG_PATH))
	if parsed is Dictionary:
		catalog=parsed
	else:
		push_error("Could not load the expedition item catalog.")

func item_info(id: String) -> Dictionary:
	var item: Variant = catalog.get(id,{})
	return item.duplicate(true) if item is Dictionary else {}

func add_gold(amount: int) -> void:
	if amount<=0: return
	gold+=amount
	collected_gold+=amount
	changed.emit()

func add_item(id: String) -> bool:
	if not _valid_gear(id) or inventory.size()>=INVENTORY_LIMIT:
		return false
	inventory.append(id)
	changed.emit()
	return true

func equip_item(id: String) -> bool:
	if not inventory.has(id) or not _valid_gear(id): return false
	var slot: String = str(catalog[id].slot)
	if equipment[slot]==id: return true
	equipment[slot]=id
	changed.emit()
	return true

func unequip_slot(slot: String) -> bool:
	if not SLOTS.has(slot) or str(equipment.get(slot,"")).is_empty(): return false
	equipment[slot]=""
	changed.emit()
	return true

func discard_item(id: String) -> bool:
	# A full satchel must be recoverable through the wardrobe. Leave worn gear
	# alone, including duplicate copies that share its catalog identity.
	if not inventory.has(id) or not _valid_gear(id) or equipment.values().has(id): return false
	inventory.erase(id)
	changed.emit()
	return true

func stats() -> Dictionary:
	var result := {
		"max_hp_bonus":0, "speed_bonus":0, "spell_damage_bonus":0,
		"spell_cooldown_multiplier":1.0, "roll_damage_bonus":0,
		"roll_cooldown_multiplier":1.0, "pickup_radius_bonus":0,
		"skill_damage_bonus":0, "skill_cooldown_multiplier":1.0,
		"skill_radius_bonus":0
	}
	for slot: String in SLOTS:
		var id: String = str(equipment.get(slot,""))
		if not inventory.has(id) or not _valid_gear(id): continue
		if str(catalog[id].slot)!=slot: continue
		var modifiers: Dictionary = catalog[id].get("stats",{})
		for key: String in result:
			if not modifiers.has(key): continue
			if key.ends_with("_multiplier"):
				result[key]=float(result[key])*float(modifiers[key])
			else:
				result[key]=int(result[key])+int(modifiers[key])
	return result

func purchase(offer: Dictionary) -> Dictionary:
	var failed := {"ok":false,"reason":"Invalid offer.","item_id":"","heal":0}
	if bool(offer.get("sold",false)):
		failed.reason="Already sold."
		return failed
	var id: String = str(offer.get("id",""))
	var kind: String = str(offer.get("kind",""))
	var price: int = int(offer.get("price",-1))
	var is_heal := kind=="heal" and id==HEAL_ID
	var is_gear := kind=="gear" and _valid_gear(id)
	if not is_heal and not is_gear: return failed
	var expected_price: int = HEAL_PRICE if is_heal else int(catalog[id].price)
	if price!=expected_price: return failed
	if gold<price:
		failed.reason="Not enough gold."
		return failed
	if is_gear and inventory.size()>=INVENTORY_LIMIT:
		failed.reason="Bag full (18 items)."
		return failed
	# Validate everything before charging or marking this shop's stock sold.
	gold-=price
	if is_gear: inventory.append(id)
	offer["sold"]=true
	changed.emit()
	return {"ok":true,"reason":"Purchased.","item_id":id if is_gear else "","heal":HEAL_AMOUNT if is_heal else 0}

func shop_offers(tier: int) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var selected_tier := clampi(tier,0,2)
	for slot: String in SLOTS:
		var choices: Array[String] = []
		for id: String in catalog:
			var item: Dictionary = catalog[id]
			if str(item.slot)==slot and int(item.tier)==selected_tier:
				choices.append(id)
		if choices.is_empty(): continue
		var selected: String = choices[shop_rng.randi_range(0,choices.size()-1)]
		var item: Dictionary = catalog[selected]
		result.append({"id":selected,"kind":"gear","name":str(item.name),"price":int(item.price),"sold":false})
	result.append({"id":HEAL_ID,"kind":"heal","name":"Sardine Tin","price":HEAL_PRICE,"sold":false,"heal":HEAL_AMOUNT})
	return result

func droppable_items(tier: int) -> Array[String]:
	var result: Array[String] = []
	var allowed_tier := clampi(tier,0,2)
	for id: String in catalog:
		if int(catalog[id].tier)<=allowed_tier:
			result.append(id)
	return result

func _valid_gear(id: String) -> bool:
	if not catalog.has(id) or not catalog[id] is Dictionary: return false
	var item: Dictionary = catalog[id]
	return SLOTS.has(str(item.get("slot",""))) and int(item.get("price",0))>0
