extends Node

# Share one preferences file with Language without replacing its section.
# Explicit engine arguments remain authoritative during startup, so QA captures
# and players who launch at a chosen size or frame limit keep that choice.
signal changed
const MODES := ["windowed", "fullscreen"]
const FRAME_LIMITS := [0, 60, 30]
const BASE_SIZE := Vector2i(1280,800)
var window_mode := "windowed"
var frame_limit := 0
var save_error := false
var config_path := ""
var startup_options: Dictionary = {}

func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	load_settings(settings_path())
	startup_options=command_line_options(OS.get_cmdline_args())
	# Godot removes consumed engine flags from get_cmdline_args(). Preserve
	# non-default engine state as well as any explicit launch hints. The hints
	# also cover --resolution1280x800 / --max-fps0, whose values equal defaults
	# and therefore cannot be distinguished through the public OS API alone.
	if Engine.max_fps!=int(ProjectSettings.get_setting("application/run/max_fps",0)):
		startup_options.frame_limit=true
	if OS.get_environment("MEOW_DISPLAY_RESPECT_ENGINE_FPS")=="1": startup_options.frame_limit=true
	if OS.get_environment("MEOW_DISPLAY_AUTOFIT")=="0": startup_options.geometry=true
	if DisplayServer.get_name()!="headless" and not OS.has_feature("web"):
		var window := get_tree().root
		var configured := Vector2i(int(ProjectSettings.get_setting("display/window/size/window_width_override",1280)),int(ProjectSettings.get_setting("display/window/size/window_height_override",800)))
		if window.size!=configured: startup_options.geometry=true
		if window.mode!=Window.MODE_WINDOWED: startup_options.mode=true
		if DisplayServer.window_get_vsync_mode()!=int(ProjectSettings.get_setting("display/window/vsync/vsync_mode",1)):
			startup_options.vsync=true
	apply.call_deferred()

func settings_path() -> String:
	if not config_path.is_empty(): return config_path
	var language := get_tree().root.get_node_or_null("Language")
	if language!=null: return str(language.settings_path)
	return OS.get_environment("MEOW_SETTINGS_PATH") if OS.has_environment("MEOW_SETTINGS_PATH") else "user://settings-v1.cfg"

func load_settings(path: String) -> void:
	window_mode="windowed"
	frame_limit=0
	var config := ConfigFile.new()
	if config.load(path)!=OK: return
	var saved_mode := str(config.get_value("display","window_mode","windowed"))
	if saved_mode in MODES: window_mode=saved_mode
	var saved_limit: Variant=config.get_value("display","frame_limit",0)
	if (saved_limit is int or saved_limit is float) and int(saved_limit) in FRAME_LIMITS:
		frame_limit=int(saved_limit)

static func command_line_options(arguments: PackedStringArray) -> Dictionary:
	var result := {"geometry":false,"mode":false,"frame_limit":false,"vsync":false}
	for argument in arguments:
		var flag := argument.split("=",true,1)[0]
		if flag in ["--resolution","--position","--screen","--embedded"]: result.geometry=true
		if flag in ["--fullscreen","-f","--windowed","-w","--maximized","-m"]: result.mode=true
		if flag=="--max-fps": result.frame_limit=true
		if flag=="--disable-vsync": result.vsync=true
	return result

func apply(preserve_cli: bool=true) -> void:
	if preserve_cli and OS.get_environment("MEOW_DISPLAY_APPLY")=="0": return
	if not preserve_cli or not bool(startup_options.get("frame_limit",false)):
		Engine.max_fps=frame_limit
	if DisplayServer.get_name()=="headless" or OS.has_feature("web"): return
	if not preserve_cli or not bool(startup_options.get("vsync",false)):
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
	var window := get_tree().root
	if preserve_cli and bool(startup_options.get("mode",false)): return
	if window_mode=="fullscreen":
		window.mode=Window.MODE_FULLSCREEN
	else:
		if window.mode!=Window.MODE_WINDOWED: window.mode=Window.MODE_WINDOWED
		if not preserve_cli or not bool(startup_options.get("geometry",false)):
			_fit_window()

func _fit_window() -> void:
	var window := get_tree().root
	var usable := DisplayServer.screen_get_usable_rect(window.current_screen)
	if usable.size.x<=0 or usable.size.y<=0: return
	var dpi_scale := clampf(DisplayServer.screen_get_dpi(window.current_screen)/96.0,1.0,3.0)
	var fit := minf(usable.size.x*0.94/BASE_SIZE.x,usable.size.y*0.88/BASE_SIZE.y)
	var factor := minf(dpi_scale,fit)
	var fitted := Vector2i(roundi(BASE_SIZE.x*factor),roundi(BASE_SIZE.y*factor))
	window.size=fitted
	window.position=usable.position+(usable.size-fitted)/2

func set_window_mode(value: String) -> bool:
	if value not in MODES: return false
	window_mode=value
	apply(false)
	return _save()

func set_frame_limit(value: int) -> bool:
	if value not in FRAME_LIMITS: return false
	frame_limit=value
	# A frame-rate choice should not move or resize the player's window.
	Engine.max_fps=frame_limit
	return _save()

func _save() -> bool:
	var config := ConfigFile.new()
	config.load(settings_path())
	config.set_value("display","window_mode",window_mode)
	config.set_value("display","frame_limit",frame_limit)
	save_error=config.save(settings_path())!=OK
	changed.emit()
	return not save_error
