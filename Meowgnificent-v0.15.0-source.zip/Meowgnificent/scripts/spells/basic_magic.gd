class_name BasicMagic
extends RefCounted

# The owned primary tool chooses one basic spell. Damage/recovery still use the
# shared CharacterStats totals, so equipment comparisons remain truthful.
const DEFINITIONS := {
 "fire":{"name":"Fireball","trait":"A warm little fireball.","color":"f1b77a","speed":1.0,"size":1.0,"push":1.0},
 "water":{"name":"Waterdrop","trait":"Splashes nearby foes.","color":"80cce5","speed":0.94,"size":1.05,"push":1.1},
 "ice":{"name":"Ice shard","trait":"Briefly slows a struck foe.","color":"a5d9f1","speed":1.02,"size":0.95,"push":0.9},
 "wind":{"name":"Breeze loop","trait":"Passes through two foes.","color":"b2dfcb","speed":1.12,"size":1.0,"push":1.35},
 "stone":{"name":"Skipping stone","trait":"A slow, hefty pebble.","color":"c9b9a8","speed":0.72,"size":1.3,"push":1.65},
 "leaf":{"name":"Leaf dart","trait":"Curves gently toward a nearby foe.","color":"b5d589","speed":0.93,"size":1.0,"push":0.85},
 "lightning":{"name":"Lightning spark","trait":"A quick little zigzag.","color":"f0dc8e","speed":1.4,"size":0.9,"push":1.0}
}
# Drawing a projectile/impact must not deep-copy a spell definition or parse its
# hex string every frame. Definitions remain independent editable copies for UI.
const COLORS := {"fire":Color("f1b77a"),"water":Color("80cce5"),"ice":Color("a5d9f1"),"wind":Color("b2dfcb"),"stone":Color("c9b9a8"),"leaf":Color("b5d589"),"lightning":Color("f0dc8e")}

static func definition(element: String) -> Dictionary:
 var id := element if DEFINITIONS.has(element) else "fire"
 var result: Dictionary=DEFINITIONS[id].duplicate(true)
 result["id"]=id
 return result

static func color(element: String) -> Color:
 return COLORS.get(element,COLORS.fire)

static func id_for_item(item: Dictionary) -> String:
 var id := str(item.get("basic_magic","fire"))
 return id if str(item.get("slot",""))=="wand" and DEFINITIONS.has(id) else "fire"

static func for_item(item: Dictionary) -> Dictionary:
 return definition(id_for_item(item))

static func for_run(run: ExpeditionRun) -> Dictionary:
 if run==null: return definition("fire")
 var id := str(run.equipment.get("wand",""))
 if not run.inventory.has(id): return definition("fire")
 return for_item(run.item_info(id))
