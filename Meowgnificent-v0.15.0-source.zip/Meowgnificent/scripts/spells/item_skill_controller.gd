class_name ItemSkillController
extends Node

signal skill_emitted(outcome: String, point: Vector2)
const DEFINITIONS_PATH := "res://data/skills.json"
const OUTCOME_WEIGHTS := {"success_weight":70.0,"miscast_weight":20.0,"overreaction_weight":10.0}
const EffectScript = preload("res://scripts/skills/item_skill_effect.gd")
const CastCueScript = preload("res://scripts/skills/skill_cast_cue.gd")
var room: Node2D
var player: WizardCat
var definitions: Dictionary = {}
var resolver := SpellOutcomeResolver.new()
var cooldown_remaining := 0.0
var cooldown_duration := 0.0
var input_blocked_until_release := true
var last_outcome := ""
var last_skill_id := ""
var status_leases: Array[Dictionary] = []
var spawned_effects: Array[Node] = []
var _stage_index := -1
var _guard_remaining := 0.0
var _guard_base_remaining := 0.0
var cast_cue: SkillCastCue

func _init() -> void:
	var parsed: Variant=JSON.parse_string(FileAccess.get_file_as_string(DEFINITIONS_PATH))
	if parsed is Dictionary: definitions=parsed
	else: push_error("Item skill definitions could not be read.")

func _ready() -> void:
	# Room/menu resume can restore enemy activity. Reapply active roots before
	# any enemy physics, rather than letting a rooted foe attack for one frame.
	process_physics_priority=-10

func skill_definition(id: String) -> Dictionary:
	var value: Variant=definitions.get(id,{})
	return value.duplicate(true) if value is Dictionary else {}

func definition_for_item(item_id: String) -> Dictionary:
	if not is_instance_valid(room) or room.run==null: return {}
	var item: Dictionary=room.run.item_info(item_id)
	return skill_definition(str(item.get("skill_id","")))

func current_skill_id() -> String:
	if not is_instance_valid(room) or room.run==null: return ""
	var id: String=str(room.run.equipment.get("wand",""))
	if not room.run.inventory.has(id): return ""
	var item: Dictionary=room.run.item_info(id)
	if str(item.get("slot",""))!="wand": return ""
	var skill_id: String=str(item.get("skill_id",""))
	return skill_id if definitions.has(skill_id) else ""

func skill_info() -> Dictionary:
	return skill_definition(current_skill_id())

func is_combat_active() -> bool:
	return is_instance_valid(room) and is_instance_valid(player) and room.state=="playing" and player.active and player.health.current>0 and not room.exit_open

func _sync_stage() -> void:
	if not is_instance_valid(room) or room.run==null: return
	var next: int=room.run.stage_index
	if _stage_index>=0 and _stage_index!=next:
		clear_transients()
		clear_presentation()
	_stage_index=next

func _physics_process(delta: float) -> void:
	_sync_stage()
	if not is_instance_valid(room) or not is_instance_valid(player): return
	if room.state!="playing" or not player.active: return
	cooldown_remaining=maxf(0,cooldown_remaining-delta)
	_tick_statuses(delta)
	_guard_base_remaining=maxf(0,_guard_base_remaining-delta)
	if _guard_remaining>0:
		_guard_remaining=maxf(0,_guard_remaining-delta)
		if _guard_remaining<=0: _clear_guard()
	if room.exit_open:
		clear_transients()
		return
	if not InputMap.has_action("special_skill"): return
	if input_blocked_until_release:
		if not Input.is_action_pressed("special_skill"): input_blocked_until_release=false
		return
	if Input.is_action_just_pressed("special_skill"): cast(player.aim)

func cast(direction: Vector2) -> bool:
	_sync_stage()
	if not is_combat_active() or cooldown_remaining>0 or player.roll_time>0: return false
	if is_instance_valid(room.spells) and room.spells.pending: return false
	var id := current_skill_id()
	if id.is_empty(): return false
	var definition: Dictionary=definitions[id]
	var stats: Dictionary=room.run.stats()
	cooldown_duration=maxf(2.0,float(definition.cooldown)*float(stats.get("skill_cooldown_multiplier",1.0)))
	cooldown_remaining=cooldown_duration
	last_skill_id=id
	last_outcome=resolver.resolve(OUTCOME_WEIGHTS)
	var aim := direction.normalized() if direction.length_squared()>0.001 else player.aim.normalized()
	if aim.length_squared()<0.1: aim=Vector2.RIGHT
	var power := 1.6 if last_outcome=="overreaction" else 0.7 if last_outcome=="miscast" else 1.0
	var damage := maxi(0,roundi((float(definition.damage)+float(stats.get("skill_damage_bonus",0)))*power))
	var area := clampf((float(definition.radius)+float(stats.get("skill_radius_bonus",0)))*(1.22 if last_outcome=="overreaction" else 1.0),8,260)
	var reach := float(definition.range)
	var duration := float(definition.duration)*(1.25 if last_outcome=="overreaction" else 1.0)
	var launch := aim
	if last_outcome=="miscast":
		launch=aim.rotated(PI if id not in ["blink_burst","frost_wave"] else (PI/2 if resolver.rng.randi_range(0,1)==0 else -PI/2))
		player.recoil-=launch*85
		if id=="frost_wave": player.recoil+=aim*240
	elif last_outcome=="overreaction":
		player.recoil-=aim*120
	player.cast_aim=launch
	player.cast_outcome=last_outcome
	player.cast_pose=1.0
	_dispatch(id,launch,damage,area,reach,duration,last_outcome)
	# Dispatch can immediately clear the last foe and its damaging actors. The
	# caster's cosmetic signature still completes, including that final hit.
	_start_presentation(id,last_outcome,launch)
	skill_emitted.emit(last_outcome,player.position)
	# A typed filter lambda attempts to cast freed Node handles before its
	# validity check. Remove invalid handles in place instead.
	for i in range(spawned_effects.size()-1,-1,-1):
		if not is_instance_valid(spawned_effects[i]) or spawned_effects[i].is_queued_for_deletion(): spawned_effects.remove_at(i)
	return true

func _start_presentation(id: String, outcome: String, direction: Vector2) -> void:
	clear_presentation()
	if not is_instance_valid(player) or not is_instance_valid(room) or room.state!="playing": return
	player.begin_skill_pose(id,outcome,direction)
	cast_cue=CastCueScript.new()
	cast_cue.controller=self
	cast_cue.skill_id=id
	cast_cue.outcome=outcome
	cast_cue.direction=direction
	player.add_child(cast_cue)

func clear_presentation() -> void:
	if is_instance_valid(cast_cue): cast_cue.queue_free()
	cast_cue=null
	if is_instance_valid(player): player.clear_skill_pose()

func _dispatch(id: String, direction: Vector2, damage: int, radius: float, reach: float, duration: float, outcome: String) -> void:
	var center := player.position
	var aimed := _bounded(center+direction*reach)
	match id:
		"spark_burst":
			hit_area(aimed,damage,radius,outcome)
			visual("spark",aimed,radius,duration,outcome)
		"ember_ring":
			if outcome=="miscast":
				center=_bounded(center+direction*75)
				room.ignite_floor(player.position)
			hit_area(center,damage,radius,outcome)
			visual("ring",center,radius,duration,outcome)
		"cinder_fan":
			var fan := visual("fan",center,68.0,0.64,outcome)
			if fan!=null: fan.direction=direction
			var count := 7 if outcome=="overreaction" else 5
			for i in range(count):
				if not is_combat_active(): break
				var shot := SpellProjectile.new()
				shot.room=room
				shot.bounds=player.bounds
				shot.position=player.position+direction*34
				shot.direction=direction.rotated(lerpf(-0.52,0.52,float(i)/maxi(1,count-1)))
				shot.speed=430
				shot.radius=clampf(radius,7.5,28.0)
				shot.damage=damage
				shot.outcome=outcome
				shot.lifetime=maxf(0.25,reach/shot.speed)
				shot.impacted.connect(func(point: Vector2, amount: int, blast_radius: float, push: Vector2): room.apply_blast(point,amount,blast_radius,push,Color("efbd81"),outcome))
				room.projectiles.add_child(shot)
				spawned_effects.append(shot)
		"margin_burst":
			var pages := _effect("pages",center,radius,duration,outcome)
			if pages!=null:
				pages.damage=damage
				pages.direction=direction
		"frost_wave":
			var frost := visual("frost",center,radius,0.62,outcome)
			if frost!=null: frost.direction=direction
			for enemy in room.enemies.duplicate():
				if not is_instance_valid(enemy): continue
				var offset: Vector2=enemy.position-center
				if offset.length()<=radius+float(enemy.config.radius) and (offset.length()<30 or offset.normalized().dot(direction)>=cos(PI*0.29)):
					if hit_enemy(enemy,damage,direction,outcome): apply_status(enemy,duration,0.3,false)
		"blink_burst":
			var origin := player.position
			player.position=aimed
			player.reset_physics_interpolation()
			player.velocity=Vector2.ZERO
			player.invulnerability=maxf(player.invulnerability,0.4)
			if origin.distance_to(aimed)<reach*0.7:
				player.hit_reaction=0.2
				player.recoil=-direction*100
			visual("blink",origin,radius*0.6,0.4,outcome)
			hit_area(aimed,damage,radius,outcome)
			visual("blink",aimed,radius,0.5,outcome)
		"chicken_dash":
			var chicken := _effect("chicken",center+direction*25,radius,duration,outcome)
			if chicken!=null:
				chicken.direction=direction
				chicken.damage=damage
				chicken.speed=reach/maxf(duration,0.1)
		"vine_snare":
			hit_area(aimed,damage,radius,outcome,"root",duration)
			var vines := _effect("vine",aimed,radius,duration,outcome)
			if vines!=null: vines.damage=maxi(1,damage-2)
		"potion_bomb":
			var potion := _effect("potion",center,radius,duration,outcome)
			if potion!=null:
				potion.origin=center
				potion.target=aimed
				potion.damage=damage
			if outcome=="miscast" and potion!=null:
				potion.target=_bounded(center+direction*42)
				room.ignite_floor(potion.target)
		"thunder_stamp":
			for i in range(3):
				var point := _bounded(center+direction*(65+i*80))
				var thunder := _effect("thunder",point,radius,duration,outcome)
				if thunder!=null:
					thunder.delay=0.25+i*0.2
					thunder.damage=damage
		"bubble_guard":
			if outcome=="miscast":
				# The bubble lands on a foe instead: a short-lived snare, while
				# the cat must still dodge. A failed guard has a visible use.
				var wrong := _bounded(center+direction*95)
				hit_area(wrong,maxi(1,damage+8),radius,outcome,"root",1.1)
				visual("bubble_wrong",wrong,radius,0.7,outcome)
			else:
				_guard_base_remaining=player.invulnerability
				_guard_remaining=duration
				player.invulnerability=maxf(player.invulnerability,duration)
				_effect("bubble",center,radius,duration,outcome)
		"comet_shower":
			var count := 6 if outcome=="overreaction" else 4
			for i in range(count):
				var offset := Vector2.from_angle(i*TAU/count)*44 if i>0 else Vector2.ZERO
				var meteor := _effect("meteor",_bounded(aimed+offset),radius,duration,outcome)
				if meteor!=null:
					meteor.delay=0.3+i*0.2
					meteor.damage=damage

func _bounded(point: Vector2) -> Vector2:
	var margin := float(player.config.get("radius",23))
	return point.clamp(room.bounds.position+Vector2.ONE*margin,room.bounds.end-Vector2.ONE*margin)

func _effect(kind: String, point: Vector2, radius: float, duration: float, outcome: String) -> ItemSkillEffect:
	if not is_combat_active(): return null
	var node := EffectScript.new() as ItemSkillEffect
	node.controller=self
	node.kind=kind
	node.position=point
	node.radius=radius
	node.duration=duration
	node.outcome=outcome
	if kind in ["vine","frost","ring","spark","blink"]: node.z_index=-1
	room.projectiles.add_child(node)
	spawned_effects.append(node)
	return node

func visual(kind: String, point: Vector2, radius: float, duration: float, outcome: String) -> ItemSkillEffect:
	return _effect(kind,point,radius,duration,outcome)

func hit_enemy(enemy: Node, damage: int, direction: Vector2, outcome: String) -> bool:
	if not is_combat_active() or not is_instance_valid(enemy) or enemy.health.current<=0: return false
	var before: int=enemy.health.current
	if enemy.has_method("take_spell_damage"): enemy.call("take_spell_damage",damage,direction,outcome)
	else: enemy.take_damage(damage,direction)
	return enemy.health.current<before

func hit_area(point: Vector2, damage: int, radius: float, outcome: String, status: String="", duration: float=0.0) -> void:
	if not is_combat_active(): return
	for enemy in room.enemies.duplicate():
		if not is_instance_valid(enemy) or enemy.position.distance_to(point)>radius+float(enemy.config.radius): continue
		var direction: Vector2=(enemy.position-point).normalized()
		if hit_enemy(enemy,damage,direction,outcome) and not status.is_empty(): apply_status(enemy,duration,0.3,status=="root")

func apply_status(enemy: Node, duration: float, factor: float, rooted: bool) -> void:
	if not is_instance_valid(enemy) or enemy.health.current<=0: return
	var lease: Dictionary={}
	for existing in status_leases:
		if existing.enemy==enemy:
			lease=existing
			break
	if lease.is_empty():
		lease={"enemy":enemy,"base_speed":float(enemy.config.speed),"base_active":bool(enemy.active),"slow":0.0,"root":0.0,"factor":1.0}
		status_leases.append(lease)
	if rooted: lease.root=maxf(float(lease.root),duration)
	else:
		lease.slow=maxf(float(lease.slow),duration)
		lease.factor=minf(float(lease.factor),factor)
	enemy.config.speed=float(lease.base_speed)*(float(lease.factor) if float(lease.slow)>0 else 1.0)
	if float(lease.root)>0: enemy.active=false

func _tick_statuses(delta: float) -> void:
	for lease in status_leases.duplicate():
		if not is_instance_valid(lease.get("enemy")):
			status_leases.erase(lease)
			continue
		var enemy: Node=lease.enemy
		if enemy.health.current<=0:
			status_leases.erase(lease)
			continue
		lease.slow=maxf(0,float(lease.slow)-delta)
		lease.root=maxf(0,float(lease.root)-delta)
		enemy.config.speed=float(lease.base_speed)*(float(lease.factor) if float(lease.slow)>0 else 1.0)
		enemy.active=bool(lease.base_active) and float(lease.root)<=0
		if float(lease.slow)<=0 and float(lease.root)<=0: status_leases.erase(lease)

func _clear_guard() -> void:
	if is_instance_valid(player): player.invulnerability=maxf(minf(player.invulnerability,_guard_base_remaining),player.roll_time)
	_guard_remaining=0
	_guard_base_remaining=0

func clear_transients() -> void:
	for lease in status_leases:
		if not is_instance_valid(lease.get("enemy")): continue
		var enemy: Node=lease.enemy
		enemy.config.speed=float(lease.base_speed)
		enemy.active=bool(lease.base_active) and is_instance_valid(player) and player.active and is_instance_valid(room) and room.state=="playing"
	status_leases.clear()
	if _guard_remaining>0: _clear_guard()
	for effect in spawned_effects:
		if is_instance_valid(effect): effect.queue_free()
	spawned_effects.clear()

func reset() -> void:
	clear_transients()
	clear_presentation()
	cooldown_remaining=0
	cooldown_duration=0
	last_outcome=""
	last_skill_id=""
	_stage_index=-1
	input_blocked_until_release=true

func _exit_tree() -> void:
	clear_transients()
	clear_presentation()
