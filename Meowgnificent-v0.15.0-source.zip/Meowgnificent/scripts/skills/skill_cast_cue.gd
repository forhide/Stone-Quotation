class_name SkillCastCue
extends Node2D

# A cosmetic signature follows the caster, independent of damaging actors. The
# final foe may die immediately; that must not erase the fact that Q was used.
const DURATION := 0.68
const COLORS := {
 "spark_burst":"edba74", "ember_ring":"e6a386", "cinder_fan":"edb17b",
 "margin_burst":"b9a0cf", "frost_wave":"9bcfe1", "blink_burst":"baa5d8",
 "chicken_dash":"e6c68d", "vine_snare":"9fc58f", "potion_bomb":"cea2ce",
 "thunder_stamp":"ecd182", "bubble_guard":"9dccdb", "comet_shower":"b6a8da"
}
var controller: Node
var skill_id := "spark_burst"
var outcome := "success"
var direction := Vector2.RIGHT
var age := 0.0
var ink := Color("edba74")
static var STAR := _star_path()

func _ready() -> void:
 physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
 z_index=4
 texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
 ink=Color(str(COLORS.get(skill_id,"b9a0cf")))
 queue_redraw()

func _process(delta: float) -> void:
 if not is_instance_valid(controller) or not is_instance_valid(controller.room) or not is_instance_valid(controller.player):
  queue_free()
  return
 var state: String=controller.room.state
 if state in ["transition","defeated","cleared","intro"]:
  queue_free()
  return
 if state!="playing" or not controller.player.active: return
 age+=delta
 if age>=DURATION: queue_free()
 queue_redraw()

func _star(at: Vector2, size: float, color: Color, angle: float=0.0, stretch: Vector2=Vector2.ONE) -> void:
 draw_set_transform(at,angle,Vector2.ONE*size*stretch)
 draw_colored_polygon(STAR,color)
 draw_polyline(STAR,Color(color.darkened(0.24),color.a),1.4/maxf(size,0.01),true)
 draw_set_transform(Vector2.ZERO)

static func _star_path() -> PackedVector2Array:
 var points := PackedVector2Array()
 for i in range(11): points.append(Vector2.from_angle(-PI/2+i*PI/5)*(1.0 if i%2==0 else 0.45))
 return points

func _draw() -> void:
 var t := clampf(age/DURATION,0,1)
 var arrival := minf(1,t/0.18)
 var fade := minf(1,(1-t)/0.26)
 var alpha := arrival*fade
 var release := clampf((t-0.23)/0.4,0,1)
 var crooked := sin(t*19)*0.12 if outcome=="miscast" else 0.0
 var spread := 1.15 if outcome=="overreaction" else 1.0
 # Distinct lavender caster seals never resemble coral enemy attack warnings.
 draw_set_transform(Vector2(0,3),crooked,Vector2(1,0.33))
 draw_arc(Vector2.ZERO,(36+release*16)*spread,0,TAU,32,Color(ink,alpha*0.5),2,true)
 draw_set_transform(Vector2.ZERO)
 for i in range(4):
  var at := Vector2.from_angle(t*2+i*TAU/4)*43*spread*Vector2(1,0.33)+Vector2(0,3)
  _star(at,4,Color(Color("fff2cd"),alpha*0.9),t*0.4,Vector2(1,0.5))
 draw_set_transform(Vector2.ZERO)
 var facing := 1.0 if direction.x>=0 else -1.0
 var paw := Vector2(49*facing,-66)
 var pull := 1.0-smoothstep(0.05,0.35,t)
 var expansion := sin(release*PI)*12
 draw_arc(paw,9+pull*13+expansion,0.3+t*3,TAU-0.45+t*3,24,Color(ink,alpha*0.82),2.2,true)
 _star(paw,8+sin(release*PI)*8,Color(Color("fff4cf"),alpha),crooked+t*0.7)
 for side in [-1.0,1.0]:
  var at := paw+Vector2(side*(13+release*20),-6-release*14)
  _star(at,3.5+release*1.4,Color(ink,alpha*0.8),-t)

func snapshot() -> Dictionary:
 return {"skill":skill_id,"outcome":outcome,"age":age,"duration":DURATION,"cosmetic":true}
