class_name ItemSkillEffect
extends Node2D

# Bounded, short-lived skill actors share one draw node per effect. They live
# under the room's projectile root, so menus and room changes pause/clear them.
var controller: Node
var kind := "spark"
var direction := Vector2.RIGHT
var origin := Vector2.ZERO
var target := Vector2.ZERO
var radius := 55.0
var damage := 0
var duration := 0.5
var delay := 0.0
var speed := 390.0
var outcome := "success"
var age := 0.0
var triggered := false
var next_tick := 0.6
var hit_times: Dictionary = {}
var points: PackedVector2Array = PackedVector2Array()

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	reset_physics_interpolation()

func _process(_delta: float) -> void:
	if is_instance_valid(controller) and controller.is_combat_active(): queue_redraw()

func _physics_process(delta: float) -> void:
	if not is_instance_valid(controller) or not is_instance_valid(controller.room):
		queue_free()
		return
	if not controller.is_combat_active():
		if controller.room.exit_open or controller.room.state in ["transition","cleared","defeated","intro"]: queue_free()
		return
	age+=delta
	match kind:
		"pages":
			# A miscast sends the footnotes circling an empty patch behind the
			# caster instead of protecting their feet. The pages still hit foes.
			position=controller.player.position+(direction*85.0 if outcome=="miscast" else Vector2.ZERO)
			for enemy in controller.room.enemies.duplicate():
				if not is_instance_valid(enemy) or enemy.health.current<=0: continue
				var id: int=enemy.get_instance_id()
				if age-float(hit_times.get(id,-10.0))<0.5: continue
				for i in range(6):
					var page := position+Vector2.from_angle(age*3.3+i*TAU/6.0)*radius
					if page.distance_to(enemy.position)<=19.0+float(enemy.config.radius):
						controller.hit_enemy(enemy,damage,(enemy.position-position).normalized(),outcome)
						hit_times[id]=age
						break
		"bubble":
			position=controller.player.position
		"chicken":
			var travel := speed*delta
			var steps := maxi(1,ceili(travel/9.0))
			for step in range(steps):
				position+=direction*travel/steps
				if not controller.room.bounds.has_point(position):
					queue_free()
					return
				for enemy in controller.room.enemies.duplicate():
					if not is_instance_valid(enemy) or enemy.health.current<=0: continue
					var id: int=enemy.get_instance_id()
					if not hit_times.has(id) and position.distance_to(enemy.position)<=radius+float(enemy.config.radius):
						controller.hit_enemy(enemy,damage,direction,outcome)
						hit_times[id]=age
		"vine":
			if age>=next_tick:
				next_tick+=0.6
				controller.hit_area(position,damage,radius,outcome)
		"potion":
			position=origin.lerp(target,clampf(age/duration,0.0,1.0))
			if age>=duration and not triggered:
				triggered=true
				controller.hit_area(target,damage,radius,outcome)
				controller.visual("potion_pop",target,radius,0.55,outcome)
		"thunder","meteor":
			if age>=delay and not triggered:
				triggered=true
				controller.hit_area(position,damage,radius,outcome)
	if age>=duration+delay: queue_free()
	queue_redraw()

func _ellipse(at: Vector2, extent: Vector2, color: Color) -> void:
	draw_set_transform(at,0,extent)
	draw_circle(Vector2.ZERO,1,color,true,-1,true)
	draw_set_transform(Vector2.ZERO)

func _draw() -> void:
	var drawing_age := age
	if ProjectSettings.get_setting("physics/common/physics_interpolation",false) and is_instance_valid(controller) and controller.is_combat_active():
		drawing_age=maxf(0,age-(1.0-Engine.get_physics_interpolation_fraction())/float(Engine.physics_ticks_per_second))
	SkillEffectInk.draw_effect(self,kind,drawing_age,duration,delay,radius,direction,outcome)

func presentation_snapshot() -> Dictionary:
	return {"kind":kind,"signature":SkillEffectInk.signature(kind),"draw_command_budget":SkillEffectInk.max_draw_commands(kind),"age":age,"duration":duration,"outcome":outcome}
