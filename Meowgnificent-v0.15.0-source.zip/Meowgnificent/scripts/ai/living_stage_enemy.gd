class_name LivingStageEnemy
extends CandleSlime

# The ordered books and reagent mushrooms from the storyboard are the foes,
# rather than scenery over an unrelated population of slimes.
const REAGENT_ATLAS: Texture2D = LivingStageArt.SHEET
const REGIONS: Dictionary = LivingStageArt.REGIONS
var formation_home := Vector2.ZERO
var awakened := false
var disordered := false
var _pose := ""
var _spore_age := -1.0

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	super.setup(settings,player,room_bounds)
	formation_home=position
	# A shared initial rhythm makes the row/bed order legible before it breaks.
	time=0.0
	cooldown=0.65
	awakened=role=="book"

func _ready() -> void:
	super._ready()
	# Even the crop's tougher overseer obeys the Grimoire's same-height rule.
	# Its crown/health still distinguish it; art scale does not change hit tests.
	if role=="mushroom":
		scale=Vector2.ONE
		for child in get_children():
			if child is Node2D and child.position==Vector2(0,-106): child.position.y=-78

func _physics_process(delta: float) -> void:
	if not active or not is_instance_valid(target) or not target.active or health.current<=0: return
	time+=delta
	cooldown=maxf(0,cooldown-delta)
	hit_flash=maxf(0,hit_flash-delta)
	if _spore_age>=0:
		_spore_age+=delta
		if _spore_age>0.45: _spore_age=-1
	var to_player := target.position-position
	if not awakened:
		# Beds wake in response to a visitor, not an invisible universal timer.
		if to_player.length()<330: awakened=true
		else:
			queue_redraw()
			return
	var remaining_before_tick := phase_time
	phase_time=maxf(0,phase_time-delta)
	match phase:
		"approach":
			var reach := 310.0 if role=="book" else 125.0
			if to_player.length()<reach and cooldown<=0:
				phase="windup"
				phase_time=warning_duration()
				attack_direction=to_player.normalized()
				attack_origin=position
				attack_hit=false
			else:
				# Books advance in an orderly patrol; farm mushrooms uproot and
				# shuffle on their short feet after the control seal wakes them.
				position+=to_player.normalized()*float(config.speed)*(0.57 if role=="book" else 0.62)*delta
		"windup":
			attack_origin=position
			if phase_time<=0:
				phase="attack"
				phase_time=attack_duration()
				if role=="mushroom": _spore_age=0.0
		"attack":
			if role=="book":
				position+=attack_direction*attack_speed()*minf(delta,remaining_before_tick)
			if not attack_hit and position.distance_to(target.position)<=contact_radius():
				target.take_damage(int(config.contact_damage),position)
				attack_hit=true
			if phase_time<=0:
				phase="recover"
				phase_time=1.05 if role=="mushroom" else 0.8
		"recover":
			if phase_time<=0:
				phase="approach"
				cooldown=0.4
	position+=knockback*delta
	position=position.clamp(bounds.position+Vector2.ONE*20,bounds.end-Vector2.ONE*20)
	knockback=knockback.move_toward(Vector2.ZERO,delta*550)
	queue_redraw()

func take_damage(amount: int, direction: Vector2) -> void:
	awakened=true
	disordered=true
	super.take_damage(amount,direction)

func warning_duration() -> float:
	return 0.82 if role=="book" else 0.92

func attack_duration() -> float:
	return 0.46 if role=="book" else 0.16

func attack_speed() -> float:
	return 520.0 if role=="book" else 0.0

func contact_radius() -> float:
	return (74.0+float(target.config.radius)) if role=="mushroom" else super.contact_radius()

func get_attack_preview() -> Dictionary:
	if phase not in ["windup","attack"]: return {}
	if role=="book": return super.get_attack_preview()
	# A tiny centreline renders a round warning through the shared SDF ink.
	# Its radius includes exactly the same player-centre allowance as damage.
	return {"path":PackedVector2Array([Vector2.ZERO,Vector2(0.01,0)]),"radius":contact_radius(),"progress":1.0-clampf(phase_time/warning_duration(),0,1) if phase=="windup" else 1.0,"striking":phase=="attack"}

func _cached_art(key: String) -> Texture2D:
	var icon := LivingStageArt.icon(key)
	return icon if icon!=null else super._cached_art(key)

func _atlas_region(key: String) -> Rect2:
	return REGIONS[key] if REGIONS.has(key) else super._atlas_region(key)

func _art_bounds(key: String) -> Rect2:
	if key in ["book","book_fold"]: return Rect2(-40,-72,80,59)
	if key=="mushroom": return Rect2(-32,-65,64,64)
	if key=="mushroom_sneeze": return Rect2(-33,-48,71,49)
	return super._art_bounds(key)

func _sync_visuals() -> void:
	if body_root==null: return
	var key := role
	if role=="book" and (phase=="attack" or sin(time*6.2)>0.25): key="book_fold"
	if role=="mushroom" and phase in ["windup","attack"]: key="mushroom_sneeze"
	if key!=_pose:
		_pose=key
		body_sprite.texture=_cached_art(key)
		body_sprite.position=_art_bounds(key).position
		body_sprite.scale=_art_bounds(key).size/_atlas_region(key).size
	body_sprite.self_modulate=Color(1.22,1.12,1.02) if hit_flash>0 else Color.WHITE
	if role=="book":
		body_root.position=Vector2(0,sin(time*6.2)*1.6)
		body_root.rotation=attack_direction.x*0.14 if phase=="attack" else sin(time*3.1)*0.025
		body_root.scale=Vector2(1.06,0.94) if phase=="windup" else Vector2.ONE
	else:
		# Root stays on the soil; only the cap/body squashes and the feet shuffle.
		var walking := phase=="approach" and awakened
		body_root.position=Vector2.ZERO
		body_root.rotation=sin(time*5)*0.045 if walking else 0.0
		var squash := 0.035*sin(time*(5 if walking else 2))
		body_root.scale=Vector2(1+squash,1-squash)

func snapshot() -> Dictionary:
	return {"role":role,"home":formation_home,"awakened":awakened,"disordered":disordered,"phase":phase,"pose":_pose,"spore_age":_spore_age}

func _draw() -> void:
	super._draw()
	if not awakened:
		# A controlled sleeping bed reads as a reagent crop until it stirs.
		draw_arc(Vector2(0,2),24,0,TAU,24,Color("ba9acb"),1.1,true)
	elif not disordered:
		for side in [-1,1]:
			var p := Vector2(side*29,-22)
			draw_line(p+Vector2(-3,0),p+Vector2(3,0),Color("bc9bd2"),1.5,true)
	if role=="mushroom" and _spore_age>=0:
		var t := _spore_age/0.45
		var ink := Color("efdca6")
		ink.a=(1-t)*0.65
		# Eight authored puffs, no particles, screen shaders or persistent hazard.
		for i in range(8):
			var p := Vector2.from_angle(TAU*i/8)*(22+52*t)
			draw_circle(p+Vector2(0,-8-12*t),3.5*(1-t*0.4),ink,true,-1,true)
