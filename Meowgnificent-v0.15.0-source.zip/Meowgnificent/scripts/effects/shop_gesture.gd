class_name ShopGesture
extends Node2D

# Tiny authored vector accents, not a particle emitter. A fixed handful of
# leaves/bubbles/feathers are redrawn only on the market's 10 Hz visual tick.
var kind := ""
var progress := 0.0
var weight := 0.0

func update_gesture(value: String, normalized_time: float, strength: float) -> void:
	kind=value
	progress=normalized_time
	weight=strength
	visible=weight>0.001
	queue_redraw()

func _draw() -> void:
	var ink := Color("79a68a")
	ink.a=weight
	match kind:
		"leaf", "tangle":
			if kind=="tangle":
				var points := PackedVector2Array()
				for j in range(17):
					points.append(Vector2(-31+j*4,-12-sin(j*0.68+progress*5)*6))
				draw_polyline(points,ink,2.8,true)
			for i in range(4):
				var at := Vector2(-39+i*25,-48-sin(progress*PI)*24-sin(i*1.7)*14)
				draw_set_transform(at,progress*0.8+i*0.7,Vector2(1,0.6))
				draw_colored_polygon(PackedVector2Array([Vector2(-7,0),Vector2(-2,-5),Vector2(5,-4),Vector2(8,0),Vector2(2,5),Vector2(-5,4)]),ink)
				draw_line(Vector2(-5,0),Vector2(5,0),Color(0.97,0.96,0.80,weight),1,true)
				draw_set_transform(Vector2.ZERO)
		"bubble", "pop":
			for i in range(5):
				var at := Vector2(-29+i*15+sin(progress*4+i)*4,-30-progress*42-i*7)
				var bubble_ink := Color(0.49,0.72,0.82,weight*0.85)
				draw_arc(at,3+(i%3)*1.7,0,TAU,16,bubble_ink,1.7,true)
				draw_circle(at+Vector2(-1,-1),1,Color(1,1,0.97,weight))
			if kind=="pop":
				var cork := Vector2(10+progress*29,-70-sin(progress*PI)*39)
				draw_set_transform(cork,progress*4.2)
				draw_style_box(_cork(Color(0.74,0.53,0.35,weight)),Rect2(-4,-6,8,11))
				draw_set_transform(Vector2.ZERO)
		"feather":
			for i in range(3):
				var at := Vector2(-30+i*28+sin(progress*5+i)*9,-59-sin(progress*PI)*24+i*7)
				draw_set_transform(at,progress*2+i)
				draw_style_box(_cork(Color(1,0.96,0.82,weight)),Rect2(-3,-8,6,16))
				draw_line(Vector2(0,-5),Vector2(0,6),Color(0.78,0.68,0.51,weight),1,true)
				draw_set_transform(Vector2.ZERO)
		_:
			var spark := Color(0.92,0.69,0.40,weight)
			for i in range(3):
				var at := Vector2(-36+i*34,-81-sin(progress*PI)*7)
				draw_line(at-Vector2(3,0),at+Vector2(3,0),spark,1.8,true)
				draw_line(at-Vector2(0,3),at+Vector2(0,3),spark,1.8,true)

func _cork(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.set_corner_radius_all(3)
	return style
