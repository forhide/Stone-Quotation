class_name LootPickup
extends Node2D

const MAGNET_RADIUS := 128.0
const COLLECT_RADIUS := 52.0
const MAGNET_SPEED := 380.0

const GOLD_ART: Texture2D = preload("res://art/items/drop_gold.svg")
const WAND_ART: Texture2D = preload("res://art/items/drop_wand.svg")
const COLLAR_ART: Texture2D = preload("res://art/items/drop_collar.svg")
const CHARM_ART: Texture2D = preload("res://art/items/drop_charm.svg")
const FOOD_ART: Texture2D = preload("res://art/items/drop_food.svg")

var kind: String = "gold"
var amount: int = 0
var item_id: String = ""
var rarity: String = "common"
var slot: String = "wand"
var age: float = 0.0

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func _draw() -> void:
	var bob := sin(age*3.2+position.x*0.025)*2.0
	var tint := Color("d8ab61")
	var icon: Texture2D = GOLD_ART
	if kind=="food":
		icon=FOOD_ART
		tint=Color("aad4bc")
	elif kind=="gear":
		icon=EquipmentArt.icon(item_id)
		if icon==null: icon={"wand":WAND_ART,"collar":COLLAR_ART,"charm":CHARM_ART}.get(slot,WAND_ART)
		tint={"common":Color("a0908a"),"rare":Color("7eabb5"),"epic":Color("a491bf")}.get(rarity,Color("a0908a"))
	# Imported vector art is one texture; no per-frame curves or particle emitters.
	draw_set_transform(Vector2(0,4),0,Vector2(1,0.28))
	draw_circle(Vector2.ZERO,15,Color(0.36,0.45,0.33,0.20))
	draw_set_transform(Vector2.ZERO)
	draw_texture_rect(icon,Rect2(-21,-38-bob,42,42),false)
	if kind=="gold" and amount>0:
		var caption := str(amount)
		var width := ThemeDB.fallback_font.get_string_size(caption,HORIZONTAL_ALIGNMENT_LEFT,-1,11).x
		draw_string(ThemeDB.fallback_font,Vector2(-width*0.5,15),caption,HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color("735b67"))
	elif kind=="gear":
		draw_arc(Vector2(0,-15-bob),22,-0.4,PI+0.4,16,tint,1.2,true)

