# Skill effect illustrations — v0.13

`SkillEffectInk` draws high-resolution rounded vector illustrations from cached paths. It does not reuse the primary fireball/miscast atlas. The caller remains responsible for damage, movement, lifetime, pause and cleanup.

| Kind | Visual identity |
| --- | --- |
| spark | Five-point star blossom, cream inset and three orbiting colored stars |
| ring | Two spiraling ember ribbons and seven small leaf-shaped embers |
| pages | Six rounded parchment sigils at the same angle/radius as actual page damage |
| bubble / bubble_wrong | Pearl rim and paw-print shield / squashed wrong-place bubble |
| chicken | Rounded chicken, stepping feet, wing beat and feather ribbon |
| vine | Seven curling stems and leaves over a soft garden patch |
| potion / potion_pop | Corked bottle following the actual lob / six-petal potion bloom |
| thunder | Small cloud, cream/gold lightning and a landing sparkle |
| meteor | Doodle-star comet descending before its real delay, then a landing bloom |
| frost | Five outlined crystals along the actual whisker-cone arc |
| blink | Paw-print portal with double pastel rings |
| fan | Five leaf-shaped embers across the actual fan angle |

The `signature(kind)` values provide stable presentation identifiers. `max_draw_commands(kind)` is a conservative bound on primitive drawing calls, excluding transform setup; it is not an assertion about GPU draw-call counts or hardware frame rate. No particle emitter, viewport, texture or node is allocated per frame by this module. Static arrays cache stars, crystals, leaves, bolts, bottle outline, curls, motion swashes, cone, spiral and rounded paper.

Outcomes preserve the same skill identity: miscasts wobble and carry lavender accents, while overreactions have cream/gold sparks. Radius/outcome damage remains controlled by ItemSkillController; the illustration never enlarges collision.
