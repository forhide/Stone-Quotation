# Shop gathering — v0.12

Both safe stops retain the trading table and the existing Pip E-to-browse interaction. The two companions now respond to E at close range, while T talks to Pip without changing what E does at his stall. There is no dialogue modal: movement stays available and walking away dismisses the card.

`data/shop_dialogue.json` holds three Korean and English exchanges per animal for each stop. The picnic introduces the garden's animated mushrooms, Moss's unruly vines, Pip's chicken and Bloop's potions. The final stop acknowledges the coming Grand Archive encounter and the friends' trust in one another's mistakes. These additions elaborate the supplied storyboard rather than replace its plot.

Moss and Bloop breathe and glance toward the visitor around a fixed floor anchor. Conversation plays a small leaf/vine, bubble/cork or feather reaction. Pip's existing merchant sprite uses the same reaction clock. Between conversations, one friend occasionally makes a small gesture. The animation is driven by the room's active-world clock, so trading, inventory and pause freeze it together with the game.

Speech cards and prompts do not capture pointer or keyboard input. Dialogue cannot spend currency, equip an item, heal, grant a reward or change ability recovery. Repeated input has a short debounce in addition to the room's key-echo filter. Dialogue expires, and changing stage clears its state.

The gathering remains passable; no NPC/table collision or gameplay economy changes were introduced. Its visual cost is fixed: the existing market illustration, animal sprites, three tea-steam lines and a handful of vector accents updated at 10 Hz.

Verification: `tests/shop_reactions.gd` checks localized lines, glyph coverage and all 36 rendered text layouts; grounded motion; pause, range and stage resets; plus real-room interaction dispatch and read-only game-state behavior in both shop stages. `tests/shop_gathering.gd` retains the original table, free-route and exit checks.
