# 기본형 캐릭터 아트 — v0.1.2

## 실제 사용한 기준

사용자가 채팅으로 제공한 기본형 사진을 기준으로 새 투명 배경 캐릭터 일러스트를 생성했습니다. 원본 사진 자체를 게임 텍스처로 잘라 쓰지 않았습니다. 새 파일은 `art/characters/meowgnificent.png`입니다.

추가 자료로 지정한 계정: https://www.instagram.com/fatchonkywizardcat/
계정에 직접 접속하는 것은 현재 403으로 차단되어 있습니다. 대신 사용자가 제공한 **계정 그리드 캡처**를 추가 기준으로 사용했습니다. 캡처의 실사 사진에서 넓고 납작한 볼, 작은 귀와 눈, 분홍 코, 큰 검은 금속 방울, 졸린 얼굴·심드렁한 눈·입을 벌린 표정을 참고했습니다. 왼쪽 위 커플 만화, 배경 거리, 사람 손, 인스타그램 UI는 게임에 넣지 않았습니다.

## 기본형에서 살린 특징

| 요소 | 적용한 표현 |
| --- | --- |
| 체형 | 거의 직립한 배 모양 몸, 커다랗게 처진 배, 밑에 살짝 보이는 짧은 발 |
| 털 | 주황·황갈색 줄무늬, 크림색 얼굴과 주둥이, 배를 가로지르는 무늬, 세밀한 털 결 |
| 얼굴 | 넓고 둥근 얼굴, 작은 자연스러운 눈, 분홍 코, 흰 수염, 담담하고 약간 엄격한 표정 |
| 모자 | 짙은 차콜색의 높은 낡은 모자, 넓고 찌그러진 챙, 구부러진 끝, 마모된 천 질감 |
| 목줄 | 단순한 검은 목줄과 작은 금속 방울 |
| 지팡이 | 화면 왼쪽 앞발이 잡은 가늘고 불규칙한 나무 지팡이 |
| 의상 | 옷이나 갑옷 없이 고양이 몸 자체를 노출 |

기존 보라색 모자·금색 띠·별 장식·단순 도형 얼굴을 교체했습니다. 얼굴·털·모자·지팡이는 한 장의 자세한 전신 일러스트에 포함됩니다. 시작 화면은 왼쪽에 확대 전신을 보여주고 안내 패널은 오른쪽에 배치합니다. 전투에서는 발 좌표 기준으로 크기를 줄여 표시합니다.

## 초기 게임 통합 — v0.1.1

- `WizardCatVisual`이 투명 여백을 읽어 발 기준으로 Sprite2D를 배치합니다.
- `player.sprite_height`로 전투 표시 크기를 조정합니다.
- 이동 시 전체 몸을 살짝 기울이고 상하로 흔들어 무게감을 표현합니다.
- 가만히 있을 때 작은 호흡 움직임, 캐스팅 때 미세한 스쿼시와 지팡이 빛이 있습니다.
- 무적 시간에는 캐릭터 전체가 깜빡입니다. 시각적 몸 크기와 실제 충돌 반경은 구분되어 있습니다.

## 현재 한계

현재는 v0.2.1에서 추가한 여섯 전신 키포즈를 사용합니다. 8방향 개별 그림, 팔다리·모자의 분리 리깅, 방향별 다프레임 걷기 시트는 없습니다. 얼굴은 사진의 특징을 바탕으로 새로 그린 표현으로, 사진과 픽셀 단위로 같지는 않습니다. 새로운 네 가지 **초상화**는 제공된 계정 캡처와 기존 전신 그림을 함께 참조해 생성한 `art/characters/expressions.png`입니다. 원계정 전체나 캡처에 보이지 않는 게시물을 확인한 것은 아닙니다.


## v0.1.2 표정 피드백

전신 그림은 유지하고 HUD·시작/종료 메뉴에 네 가지 표정 초상화를 추가했습니다. 2×2 시트는 왼쪽 위 기본, 오른쪽 위 심드렁함, 왼쪽 아래 졸림, 오른쪽 아래 놀람 순서입니다. Godot의 AtlasTexture로 읽으며 원본 PNG를 잘라 수정하지 않습니다.

| 게임 상태 | 표시 표정 |
| --- | --- |
| 평상시 / 피드백 종료 | 기본 무표정 |
| 마법 실수 피드백 | 심드렁함 |
| 폭주 또는 피격 무적 시간 | 놀람 |
| 일시정지 / 패배 | 졸림 |

일시정지·패배가 전투 반응보다 우선합니다. 28개 기능 검사에 이 전환과 우선순위·만료 처리를 포함했습니다. 초상화는 상태 피드백이며 전신 얼굴의 프레임별 애니메이션을 뜻하지 않습니다.


## v0.2.1 전신 포즈

기존 기본형 일러스트를 참고해 새 3×2 전신 키포즈 시트 `art/characters/actions.png`를 제작했습니다. 대기, 준비, 발사, 당황, 피격, 몸을 말아 구르기를 구분합니다. `WizardCatVisual`은 포즈별 영역을 사용하고 삼각형 메시를 변형해 배의 눌림, 어깨 흔들림, 모자의 지연 움직임을 만듭니다. 실제 3D 골격이나 방향별 다프레임 걷기 시트는 아닙니다.


## v0.3.0 도서관·적·책장 아트

- `art/environments/candlewick_archive.png`는 게임용으로 새로 생성한 도서관 환경 일러스트입니다. 석재 바닥, 목재 책장, 책·두루마리, 황동과 촛불 조명을 표현합니다. Instagram 사진이나 계정 캡처에서 가져온 배경이 아닙니다. `ArchiveBackdrop`이 이 이미지를 표시하고 방의 SubViewport 캐시에 담아 재사용합니다.
- 촛불 슬라임·갑옷 빗자루·박쥐는 코드로 그린 절차형 아트입니다. 촛농/젤의 음영, 철제 투구와 황동·솔, 가죽 날개·털·발톱을 표현하며, `CandleSlime`의 역할별 공유 텍스처 캐시를 사용합니다. 본체와 움직이는 날개·불꽃을 나눠 표시합니다. 외부 계정에서 적 이미지를 가져오지 않았습니다.
- 파괴 가능한 책장은 `scripts/effects/shelf_art.gd`에서 목재, 장식과 책을 그립니다. 서 있는 책장·넘어진 책과 나무·불꽃의 세 영역을 방의 공유 아틀라스에 담고 `ArcaneShelf`가 상태에 맞는 영역을 표시합니다. 이 아틀라스도 코드로 생성한 자체 절차형 아트입니다.


## v0.4.0 원정의 소품과 불꽃

`art/items/`의 SVG 아이콘은 게임용 벡터 소품입니다. 금화·지팡이·목줄·부적·음식, 출입문·상인과 경로를 공용 텍스처로 사용하며 Instagram에서 가져온 그림이 아닙니다. `floor_fire.svg`는 위험 범위·불꽃·잿불을 함께 담아 화재 한 곳마다 여러 원과 선을 재생성하던 그리기를 텍스처 한 번으로 대체합니다. 실시간 조명이나 무제한 파티클은 추가하지 않았습니다.

## v0.5.0 재질과 적·주문 그림

`art/enemies/archive_familiars.png`는 게임용으로 새로 생성한 투명 그림입니다. 기존 절차형 적 몸체를 촛농·황동·금속·짚·털·가죽 날개의 재질이 있는 그림으로 교체했습니다. 역할별 본체와 박쥐 날개는 하나의 공유 아틀라스에서 표시합니다.

`art/environments/archive_floor_materials.png`는 석재·그을린 돌·목재·대리석 4종을 담은 생성 그림입니다. `ArchiveBackdrop`이 장소별 문양·직조 러그·배너·창문광을 합쳐 8종의 배경을 입장 때 캐시합니다.

`art/fx/painted_spell_fx.png`는 화염탄·충격 문양·실패 불꽃·연기의 생성 아틀라스입니다. 미리 그려진 빛과 연기를 사용하며 실시간 광원이나 파티클 시뮬레이션은 사용하지 않습니다. 실패의 X 표식과 WHOOPS 문구는 별도 표시합니다. 구르기 먼지는 `roll_dust.svg`를 사용합니다. 이번 생성 아트는 Instagram 이미지를 직접 복사한 에셋이 아닙니다.

## v0.6.0 HD Pastel Storybook 2D

사용자가 제공한 쯔바이!! 참고 화면과 최종 아트 디렉션은 분위기·구도·비례의 방향으로 사용했습니다. 픽셀 실험은 폐기하고 최종 활성 에셋을 고해상도 손그림으로 교체했습니다. 원작 게임의 캐릭터·배경 에셋을 복사하지 않았습니다.

`storybook_actions.png`와 `storybook_expressions.png`는 작은 무심한 눈, 큰 라벤더 모자, 둥근 주황 몸과 짧은 다리의 Meowmalade를 표현합니다. 복잡한 옷이나 지팡이 대신 앞발로 시전합니다. `hd_detention_storage.png`, `hd_academy_library.png`, `hd_forbidden_garden.png`, `hd_grand_archive.png`는 각각 독립1536×1024 배경입니다. 적과 마법 효과는 `storybook_familiars.png`, `storybook_spell_fx.png`를 사용합니다. 모든 활성 캐릭터의 UV 격자·색 단계 양자화·최근접 필터는 제거했습니다.

마도서 보스와 소품은 부드러운 SVG 곡선·캐시 그림으로 표현합니다. 이야기의 한국어 대사는 로컬 Noto Sans CJK KR에서 Hangul/Latin을 추출하고 이름을 바꾼 MeowStory Sans로 표시하며 SIL OFL1.1 라이선스를 동봉합니다. 게임 내 실행 흐름은 `STORY_RUNTIME.md`, 기준 문서는 `design/HD-PASTEL-ART-DIRECTION.md`와 `design/MEOWMALADE-STORYBOARD.md`에 있습니다.

## v0.7.0

Original-meme identity update: `art/characters/meme_actions.png`; four story plates: `art/story/`; nine equipment icons: `art/equipment/`. These are original image_gen outputs with provenance in their adjacent README/STORYBOOK-ART files. Gameplay, inventory, shop and pickups share the same cached equipment atlas; neck items display their pendant while preserving the original thin black collar. Korean/English copy and font use are documented in `docs/LOCALIZATION.md`.

## v0.8.0

The approved meme-cat identity now uses `art/characters/pastel_meme_actions.png`, with reduced fur micro-detail, warm cocoa contours and softer slate-hat shadows. `GroundedCatGait` drives two paw bones from actual movement distance rather than swaying the entire sprite. Chapter briefings reuse the same `ArchiveBackdrop` location art and decorations as gameplay. `AttackTelegraph` uses cream-edged coral floor ink, directional chevrons and a charging seal; the complete locked footprint remains visible through the attack.


## v0.12.0

장착 주무기의 기본 마법과 그림을 연결하는 `elemental_weapons.png`, 실제 책/재배 버섯 적의 `living_reagents.png`, 과녁 소품 `practice_target.png`, 책 자체의 표지 표정과 책장4포즈인 `art/grimoire/perfect_grimoire.png`를 추가했습니다. 인물은 HD Pastel Storybook 2D 톤을 유지합니다. 마도서는 동물 캐스트의 예외로, 이야기와 최종전이 공용 GrimoireArt를 사용합니다. 아트 출처와 생성 의도는 각 폴더의 설명에 기록합니다. 이전 동물 아틀라스의 흰여우 셀은 역사적 미사용 그림이며 활성 인물/전투는 참조하지 않습니다.


## v0.15.0 마법의 형태와 움직임

공개 액션 RPG [Flare: Empyrean Campaign](https://github.com/flareteam/flare-game)의 실제 게임 스크린샷과 마법 프레임을 확인했다. 참고한 커밋은 `af6eee6d339ac98011864bfe89da837fe7769c28`이다.

- [화염구4프레임](https://github.com/flareteam/flare-game/blob/af6eee6d339ac98011864bfe89da837fe7769c28/mods/fantasycore/images/powers/fireball.png): 둥근 발광 중심부, 일렁이는 외곽, 떨어져 나오는 불씨. 원본 정의는266ms 루프와8개 이동 방향을 구분한다.
- [플라즈마 구체4프레임](https://github.com/flareteam/flare-game/blob/af6eee6d339ac98011864bfe89da837fe7769c28/mods/fantasycore/images/powers/plasmaball.png): 원형 외곽 안에서 바뀌는 에너지 가지. 정의는400ms 루프다.
- [번개6프레임](https://github.com/flareteam/flare-game/blob/af6eee6d339ac98011864bfe89da837fe7769c28/mods/fantasycore/images/powers/lightning.png):200ms 루프에서 계속 바뀌는 방사형 방전. 고정된 번개 기호를 이동시키는 방식과 구분된다.

이 그림들은 비교용으로만 확인했으며 게임이나 배포 소스에 복사하지 않았다. 새 효과는 직접 그리는 파스텔 도형이며, 중심부의 자체 움직임과 이동 뒤에 남는 짧은 잔상을 분리한다. 물의 출렁임, 바람의 빈 소용돌이, 얼음·돌의 회전, 잎의 팔랑임을 속성별로 구분한다. 시전 준비와 이야기의 불꽃도 같은 표현을 쓴다. 타격·속도·시전 시간은 유지한다.

Wizard of Legend·Nine Parchments의 공식 페이지와 Steam 시연 자료는 이 환경의 연결 제한(HTTP403)으로 열리지 않아 검토했다고 주장하지 않는다.

## v0.15.0 배경 소품의 화풍 통일

기존 HD 정원·동물 그림을 참조해 새 투명 소품 그림6종을 제작했다. 사용 파일은 `art/environments/storybook_world_details.png`이며, 닭·짜임 있는 민트 돗자리·라벤더 러너·풍화된 석재·흙 재배상자·도시 부조 기념비다. 그림의 원본은 보존하고 맞춤형 AtlasTexture 영역으로 잘라 재사용한다. 닭은 상점과 특수기에서 같은 그림을 쓰고, 바닥 장식은 기존 배경 캐시에만 그린다. 위치·길찾기·적 배치·상호작용은 바꾸지 않는다.

## v0.16.0 — 속성의 물성과 은가시 지팡이

사용자의 최신 요청에 따라 나무를 생명의 덩굴, 전기를 갈래 방전, 금속을 은빛 가시로 해석했습니다. 이전의 떠다니는 잎 표현은 교체했으며, 원래의7개 내부 속성 ID를 보존하고 metal을 더했습니다. 형상·자라남·뒤따르는 흐름·충돌을 자체 코드로 그립니다.

`art/equipment/silverthorn_wand.png`는 기존 장비 그림을 방향 참고로 새로 생성한 투명 HD 그림입니다. 원본 생성 파일 `exec-cd075b1d-ea70-4b73-8333-c096dec7c615.png`의 픽셀을 수정하지 않고 AtlasTexture 영역으로 사용합니다. 장비창과 캐릭터의 착용 그림이 동일합니다.

`art/audio/*.wav`의16개 효과음은 `tools/generate_sound_palette.py`의 결정적 합성으로 제작했습니다. 외부 음원이나 게임 오디오를 복사하지 않았습니다. 22.05kHz mono PCM, 최대0.5초이며 게임은 완성된 파일을 재사용합니다.

`art/npc/story_tea.png`는 같은 상점의 피크닉 그림을 참고해 새로 생성한 찻주전자·두 찻잔·천 소품입니다. 원본 픽셀을 수정하지 않고 투명 영역을 제외한 AtlasTexture 범위로 사용하며, 무기 아이콘을 차 소품으로 사용하던 임시 표현을 교체했습니다.

## v0.16.0 확장 장비와 대표 특수기

`art/equipment/journey_weapons.png`와 `journey_trinkets.png`는 기존 파스텔 장비 그림을 참고해 새로 생성한 투명 HD 아틀라스입니다. 각각 무기 24점과 목걸이·부적 24점이며, 원본 픽셀을 변경하지 않고 개별 AtlasTexture 영역으로 사용합니다. 가방과 착용 그림에서 같은 영역을 공유하며 작은 크기의 반짝임을 줄이도록 mipmap을 사용합니다.

메테오·체인 라이트닝·물결·눈꽃·회오리·돌기둥·덩굴·금속 가시의 대표 특수기는 자체 코드의 제한된 도형과 공유 그림으로 그립니다. 예고·타격·잔상을 분리하고, 동시에 존재하는 효과와 대상 수를 제한합니다. 외부 게임의 이펙트 파일이나 화면을 가져오지 않았습니다.


## v0.17.0 — 마법·표지·가구의 그림 통일

기존 `storybook_world_details.png`를 화풍 참고로 새 투명 HD 아틀라스 세 개를 생성했습니다. `art/fx/painted_signatures.png`는 메테오·번개·물결·얼음·회오리·돌·덩굴·금속의8효과, `art/environments/enchanted_landmarks.png`는 출구·소환진·나무 표지·그을음 연기, `painted_archive_props.png`는 책장·넘어진 책장·통로·보관함입니다. 원본 픽셀을 수정하지 않고 AtlasTexture로 필요한 영역만 사용합니다. 외부 게임 에셋을 복사하지 않았습니다. 출구·소환진·책장과 현재 HD 배경에 같은 목재·석재·라벤더·꽃의 질감을 씁니다. 효과 그림과 판정은 분리하며 큰 효과는 배우 뒤에 그립니다.

`art/fx/painted_companion_magic.png`는 보호 거품·물약 병/폭발·닭 소환의 깃털 여운을 위한 추가 생성 아틀라스입니다. 원본 픽셀은 유지하며 실행 중 셰이더가 매우 낮은 알파 배경을 부드럽게 제거합니다.


## v0.18.0 material art and typography

Seven new generated PNGs preserve the image-generation outputs byte for byte. Atlas cropping, contact shadows, staggered emergence and local neck masking happen at render time; source pixels were not resampled or edited by scripts. The cat cleanup generations use the approved action/walk atlases as edit references; the game samples only each original bell area and retains the approved base texture elsewhere. Props use the existing painted rooms and original prop identities as style references. The directional flourish uses the actual game warning screenshot.

- `art/fx/material_spells_a.png` · 1254×1254 · original `exec-6a78261f-0095-4f50-9918-ba3293e183aa.png` · SHA-256 `695fd9f89d1890a5521a188e28b8ef2aa59e16e5958fddb9097bde2a12ba9496`
- `art/fx/material_spells_b.png` · 1254×1254 · original `exec-cc5902ee-f7f6-4496-8688-68293fabbc8b.png` · SHA-256 `496d2acbd04b911d0556489e70fdfca757c0b544dcd9376955640a155eb89a2c`
- `art/environments/storybook_furnishings.png` · 1254×1254 · original `exec-c201875f-9e75-4e45-b426-1c4493dda7ce.png` · SHA-256 `b6bfa3ee3395f2b56a0759dc1f62c1324453685a7dc293ab02fcbd41db659fe0`
- `art/environments/storybook_supplies.png` · 1254×1254 · original `exec-0b5d4074-d1fc-4603-a3a8-25f8cea9061e.png` · SHA-256 `b249c9477a82798c710b5a992028f5a29fadc9940dc6920c186aa5b35d9549b7`
- `art/characters/collarless_actions.png` · 1536×1024 · original `exec-ead7756c-f0b3-46af-ad6c-231dcb9142df.png` · SHA-256 `350cf29e9c2b1957544a7e792fb4e9e9462d3629d9c7d230582cabd5db950c92`
- `art/characters/collarless_walk.png` · 1536×1024 · original `exec-6e49fa6e-65f6-444a-aee1-268d3da7c593.png` · SHA-256 `4376836f64f5303c88fcf85615f0ca539a5cdf37281ae4e818d48e2f36700ea3`
- `art/fx/warning_flourish.png` · 1774×887 · original `exec-a6b7db38-5b25-4ff8-8dae-8db368489b8c.png` · SHA-256 `ae02b86079efb958339c950816c2520ab61b0d0bd8a3a6d06ae5427bdef6bce6`

The eight spell materials occupy four cells per atlas rather than eight small cells. Scene furniture shows top/side faces in the same3/4 camera as the room. Generated images include no player-facing UI text.

Jua-Regular.ttf and GowunDodum-Regular.ttf were downloaded unchanged from the official google/fonts repository (`ofl/jua` and `ofl/gowundodum`). Both use SIL Open Font License1.1; full license texts are in art/fonts/ and docs/. Jua is display lettering, Gowun Dodum is readable body/dialogue text and the display font fallback. All667 distinct Hangul syllables currently in data/*.json are present in both files.
- `Jua-Regular.ttf` · SHA-256 `769677aef240bfc3b9965f2b50748075bff885e6c6992fc591a3fb268279f898`
- `GowunDodum-Regular.ttf` · SHA-256 `a6e457933227483a11758fd0947bc74422a106d46f0bf057fdaa5af94a30067d`
