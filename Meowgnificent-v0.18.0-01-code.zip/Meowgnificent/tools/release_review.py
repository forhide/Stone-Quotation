#!/usr/bin/env python3
"""Review ZIP payloads and deliver immutable, official-GitHub-only downloads.

This does not build or claim runtime validation. `stage` creates a new isolated
Git repository; only the explicit `push` command publishes it. Existing release
branches cannot be overwritten. Uses Python's standard library and Git only.
"""
import argparse
import datetime as dt
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import urllib.parse
import urllib.request
import urllib.error
import time
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPOSITORY = "forhide/Stone-Quotation"
REMOTE = f"https://github.com/{REPOSITORY}.git"
PLATFORMS = ("windows", "linux", "macos", "web", "source")
LICENSES = ("GODOT-LICENSE.txt", "GODOT-THIRD-PARTY.txt", "NOTO-FONT-LICENSE.txt", "PRETENDARD-LICENSE.txt", "JUA-FONT-LICENSE.txt", "GOWUN-DODUM-LICENSE.txt")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def run(*args, cwd=None, capture=True):
    result = subprocess.run(args, cwd=cwd, check=True, text=True,
                            stdout=subprocess.PIPE if capture else None)
    return result.stdout.strip() if capture else ""


def prefix(version):
    return "v" + "".join(re.findall(r"\d", version))


def branch(version):
    return "meowgnificent-downloads-" + version


def release_files(version):
    manifest = ROOT.parent / f"Meowgnificent-{version}-SHA256SUMS.txt"
    require(manifest.is_file(), f"Missing {manifest}; run package.py first")
    expected_names = {f"Meowgnificent-{version}-{platform}.zip" for platform in PLATFORMS}
    records = []
    for line in manifest.read_text().splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([^/\\]+)", line)
        require(match is not None, "Malformed checksum manifest line")
        checksum, name = match.groups()
        require(name in expected_names, f"Unexpected or duplicate archive: {name}")
        expected_names.remove(name)
        path = ROOT.parent / name
        require(path.is_file() and digest(path) == checksum, f"Checksum failed: {name}")
        require(path.stat().st_size < 100 * 1024 * 1024, f"GitHub file-size limit: {name}")
        with zipfile.ZipFile(path) as archive:
            require(archive.testzip() is None, f"ZIP integrity failed: {name}")
            for entry in archive.namelist():
                require(not entry.startswith("/") and ".." not in pathlib.PurePosixPath(entry).parts,
                        f"Unsafe archive path: {entry}")
        records.append({"file": name, "bytes": path.stat().st_size, "sha256": checksum})
    require(not expected_names, f"Missing archives: {expected_names}")
    records.append({"file": manifest.name, "bytes": manifest.stat().st_size, "sha256": digest(manifest)})
    for record in records:
        record["url"] = f"https://github.com/{REPOSITORY}/raw/refs/heads/{branch(version)}/{record['file']}"
    return records


def verify_payloads(version):
    release_files(version)
    result = []
    for platform in PLATFORMS:
        if platform == "source":
            continue
        path = ROOT.parent / f"Meowgnificent-{version}-{platform}.zip"
        with zipfile.ZipFile(path) as archive:
            for license_name in LICENSES:
                require(archive.read(license_name) == (ROOT/"docs"/license_name).read_bytes(),
                        f"License differs: {platform}/{license_name}")
            if platform == "macos":
                export = ROOT/"exports/macos/Meowgnificent.zip"
                with zipfile.ZipFile(export) as original:
                    for entry in original.infolist():
                        require(archive.read(entry.filename) == original.read(entry.filename),
                                f"Mac exported payload differs: {entry.filename}")
                        require(archive.getinfo(entry.filename).external_attr == entry.external_attr,
                                f"Mac exported permissions differ: {entry.filename}")
                run("python3", str(ROOT/"tests/macos-package.py"), str(path), capture=False)
                result.append({"platform": platform, "export_and_permissions_match": True,
                               "mac_structure_and_signatures_checked": True, "runtime_tested": False})
                continue
            files = sorted(path for path in (ROOT/"exports"/platform).iterdir() if path.is_file())
            for file in files:
                require(sha(archive.read(file.name)) == digest(file), f"Export payload differs: {platform}/{file.name}")
            item = {"platform": platform, "export_payload_matches": True, "files": len(files)}
            if platform == "windows":
                data = archive.read("Meowgnificent.exe")
                require(data[:2] == b"MZ", "Windows executable is not PE")
                item["sha256"] = sha(data)
            elif platform == "linux":
                entry = archive.getinfo("Meowgnificent.x86_64")
                data = archive.read(entry)
                require(data[:4] == b"\x7fELF" and (entry.external_attr >> 16) & 0o111,
                        "Linux ELF/executable permission missing")
                item["sha256"] = sha(data)
            result.append(item)
    run("python3", str(ROOT/"tests/platform-icons.py"), capture=False)
    path = ROOT/".local"/(prefix(version)+"-payload-verification.json")
    write_json(path, result)
    write_json(ROOT/"docs/qa"/(prefix(version)+"-payload-verification.json"), result)
    print(json.dumps(result, indent=2))


def stage(version, destination):
    records = release_files(version)
    require(not destination.exists(), f"Refusing to overwrite staging directory: {destination}")
    release = ROOT/"docs"/f"RELEASE-{version}.md"
    qa = ROOT/"docs"/f"QA-{version}.md"
    require(release.is_file() and qa.is_file(), "Prepare release and QA documents before staging")
    destination.mkdir(parents=True)
    for record in records:
        shutil.copy2(ROOT.parent/record["file"], destination/record["file"])
    for file in (ROOT/"docs").glob("*"+version+".md"):
        shutil.copy2(file, destination/file.name)
    for file in (ROOT/"docs/qa").glob(prefix(version)+"*"):
        output = destination/"qa"/file.name
        output.parent.mkdir(exist_ok=True)
        if file.is_dir():
            shutil.copytree(file, output)
        else:
            shutil.copy2(file, output)
    readme = release.read_text() + "\n\n## Direct downloads\n\n" + "\n".join(
        f"- [{record['file']}]({record['url']})" for record in records)
    readme += "\n\nDownload the ZIP, extract it, and launch the executable or app. No MSI installer or CMD download command is needed.\n"
    readme += f"\n[같은 버전 코드·그래픽 인계 세트 — ZIP마다20MiB 미만](https://github.com/{REPOSITORY}/tree/meowgnificent-handoff-{version})\n"
    (destination/"README.md").write_text(readme)
    write_json(destination/"release.json", {"version": version, "branch": branch(version), "files": records})
    run("git", "init", "-b", branch(version), str(destination))
    run("git", "config", "user.name", "Codex", cwd=destination)
    run("git", "config", "user.email", "codex@openai.com", cwd=destination)
    run("git", "remote", "add", "origin", REMOTE, cwd=destination)
    run("git", "add", ".", cwd=destination)
    run("git", "commit", "-m", f"Publish Meowgnificent {version} downloads and verification", cwd=destination)
    print(f"Staged only; not published: {destination}")
    print(run("git", "log", "-1", "--oneline", cwd=destination))


def push(version, destination):
    require(run("git", "remote", "get-url", "origin", cwd=destination) == REMOTE, "Unexpected release remote")
    require(run("git", "branch", "--show-current", cwd=destination) == branch(version), "Unexpected release branch")
    require(not run("git", "status", "--porcelain", cwd=destination), "Release staging has uncommitted changes")
    parents = run("git", "rev-list", "--parents", "-1", "HEAD", cwd=destination).split()
    require(len(parents) == 1, "Expected independent orphan release root commit")
    require(not run("git", "ls-remote", "--heads", "origin", "refs/heads/"+branch(version), cwd=destination),
            "Release branch already exists; refusing overwrite")
    records = release_files(version)
    for record in records:
        require(digest(destination/record["file"]) == record["sha256"], "Staged archive differs from checked archive")
    run("git", "push", "origin", "HEAD:refs/heads/"+branch(version), cwd=destination, capture=False)
    print("Published new isolated release branch: " + branch(version))


class OfficialRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlparse(newurl)
        require(parsed.scheme == "https" and parsed.hostname in {"github.com", "raw.githubusercontent.com"},
                "Refusing download redirect outside official GitHub hosts")
        return super().redirect_request(request, fp, code, msg, headers, newurl)


def verify_downloads(version):
    records = release_files(version)
    directory = ROOT/".local"/(prefix(version)+"-fresh-downloads")
    directory.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(OfficialRedirects())
    results = []
    for record in records:
        target = directory/record["file"]
        part = target.with_suffix(target.suffix+".part")
        canonical = record["url"]
        direct = f"https://raw.githubusercontent.com/{REPOSITORY}/refs/heads/{branch(version)}/{record['file']}"
        for attempt in range(4):
            retrieval = canonical if attempt < 2 else direct
            try:
                # A normal cacheable HEAD primes GitHub's new branch route.
                # Integrity comes from the complete byte hash, not bypassing
                # HTTP caches; forced no-cache previously caused504 responses.
                request = urllib.request.Request(retrieval, method="HEAD", headers={"User-Agent":"Meowgnificent-release-verification/1.0"})
                with opener.open(request, timeout=25) as response:
                    require(response.status == 200, "Download header did not return HTTP200")
                request = urllib.request.Request(retrieval, headers={"User-Agent":"Meowgnificent-release-verification/1.0"})
                with opener.open(request, timeout=50) as response, part.open("wb") as stream:
                    require(response.status == 200, "Download did not return HTTP200")
                    final_host = urllib.parse.urlparse(response.url).hostname
                    require(final_host in {"github.com", "raw.githubusercontent.com"}, "Unexpected final host")
                    shutil.copyfileobj(response, stream)
                    content_type = response.headers.get("Content-Type", "")
                require(part.stat().st_size == record["bytes"] and digest(part) == record["sha256"], "Fresh download differs from packaged release: "+record["file"])
                if target.suffix == ".zip":
                    with zipfile.ZipFile(part) as archive:
                        require(archive.testzip() is None, "Downloaded ZIP integrity failed")
                part.replace(target)
                results.append({**record, "verified":True, "content_type":content_type, "final_host":final_host, "retrieval_url":retrieval})
                print("Verified official GitHub download: "+record["file"], flush=True)
                break
            except urllib.error.HTTPError as error:
                if error.code not in {429,500,502,503,504} or attempt == 3:
                    raise
                print(f"Retry official HTTPS download: {record['file']} (HTTP{error.code})", flush=True)
                time.sleep(min(4,1+attempt))
    path = ROOT/".local"/(prefix(version)+"-download-verification.json")
    write_json(path, results)
    write_json(ROOT/"docs/qa"/(prefix(version)+"-download-verification.json"), results)
    print("Verified all five ZIPs and checksum manifest. Runtime test scope is unchanged.")


def record_delivery(version, destination):
    records = release_files(version)
    qa_path = ROOT/".local"/(prefix(version)+"-qa-summary.json")
    require(qa_path.is_file(), "Prepare this release's actual QA summary before recording delivery")
    qa = json.loads(qa_path.read_text())
    require(qa.get("version") == version, "QA summary has a different version")
    downloads = json.loads((ROOT/".local"/(prefix(version)+"-download-verification.json")).read_text())
    require(len(downloads) == len(records), "Incomplete fresh-download evidence")
    by_name = {item["file"]: item for item in downloads}
    for record in records:
        item = by_name.get(record["file"], {})
        require(item.get("verified") and all(item.get(key) == value for key, value in record.items()),
                "Fresh download evidence does not match this release")
    payloads = json.loads((ROOT/".local"/(prefix(version)+"-payload-verification.json")).read_text())
    require({item["platform"] for item in payloads} == set(PLATFORMS)-{"source"},
            "Missing platform payload evidence")
    commit = run("git", "rev-parse", "HEAD", cwd=destination)
    remote = run("git", "ls-remote", "--heads", "origin", "refs/heads/"+branch(version), cwd=destination)
    require(remote.split() and remote.split()[0] == commit, "Local release commit is not published")
    require(not run("git", "status", "--porcelain", cwd=destination), "Uncommitted release evidence remains")
    result = {**qa, "version": version, "branch": branch(version), "commit": commit,
              "files": records, "packaged_payloads_verified": True, "download_verified": True,
              "download_verified_at": dt.datetime.now(dt.timezone.utc).isoformat(),
              "mac_runtime_tested": bool(qa.get("mac_runtime_tested", False)),
              "native_windows_tested": bool(qa.get("native_windows_tested", False))}
    write_json(ROOT/".local/current-release.json", result)
    print("Recorded verified current release: "+version+" "+commit[:12])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("verify-payloads", "stage", "push", "verify-downloads", "record-delivery"))
    parser.add_argument("version")
    parser.add_argument("--stage-dir", type=pathlib.Path)
    args = parser.parse_args()
    require(re.fullmatch(r"v\d+\.\d+\.\d+", args.version), "Expected version such as v0.15.0")
    destination = args.stage_dir or ROOT.parent/("meowgnificent-download-"+prefix(args.version))
    if args.command == "verify-payloads":
        verify_payloads(args.version)
    elif args.command == "stage":
        stage(args.version, destination)
    elif args.command == "push":
        push(args.version, destination)
    elif args.command == "verify-downloads":
        verify_downloads(args.version)
    else:
        record_delivery(args.version, destination)


if __name__ == "__main__":
    main()
