const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');

// Default-player narrative path: deliberately does not use skip_story or
// internal engine state. Screen OCR and real keyboard input prove the flow.
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 let checks=0;
 try {
  const context=await browser.newContext({viewport:{width:1280,height:800}});
  const page=await context.newPage();const errors=[];const failed=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('console',message=>{if(message.type()==='error')errors.push(message.text())});
  page.on('response',response=>{if(response.status()>=400)failed.push([response.status(),response.url()])});
  function check(ok,name){assert(ok,name);checks++;console.log('PASS: '+name)}
  async function screen(name){
   const path='/tmp/meowgnificent-v0180-story-web-'+name+'.png';await page.screenshot({path});
   let extra='';
   if(name==='detention'){
    // Read the three actual arrival/HUD captions without slow room-art OCR;
    // their2.4s card must be observed before it fades or the idle cat is hit.
    for(const [label,bounds] of [['entry','(366,132,920,164)'],['name','(366,164,920,206)'],['fight','(970,77,1240,112)']]){
     const crop=path.replace('.png','-'+label+'.png');
     execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop('+bounds+').convert("L")); im.resize((im.width*4,im.height*4)).save(sys.argv[2])',path,crop]);
     extra+='\n'+execFileSync('tesseract',[crop,'stdout','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
    }
    return extra;
   }
   if(name==='pause'){
    const crop=path.replace('.png','-dialog.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((395,390,890,520)).convert("L")); im.resize((im.width*4,im.height*4)).save(sys.argv[2])',path,crop]);
    extra=execFileSync('tesseract',[crop,'stdout','--psm','6'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   if(['opening','page02','auto-paused','auto-held','auto-resumed','detention'].includes(name)){
    const crop=path.replace('.png','-caption.png');const bounds=name==='detention'?'(350,126,930,238)':'(75,735,600,779)';
    execFileSync('python3',['-c','from PIL import Image,ImageOps,ImageEnhance; import sys; im=ImageEnhance.Contrast(ImageOps.autocontrast(Image.open(sys.argv[1]).crop('+bounds+').convert("L"))).enhance(2); im.resize((im.width*3,im.height*3)).save(sys.argv[2])',path,crop]);
    extra=execFileSync('tesseract',[crop,'stdout','--psm',name==='detention'?'11':'7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   if(name.startsWith('auto-')){
    // Read the actual button interior separately; whole-canvas OCR skips
    // rounded controls as table borders. Its exact words remain required.
    const control=path.replace('.png','-auto-control.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps; import sys; im=ImageOps.autocontrast(Image.open(sys.argv[1]).crop((930,742,1198,768)).convert("L")); im.resize((im.width*4,im.height*4)).save(sys.argv[2])',path,control]);
    extra+='\n'+execFileSync('tesseract',[control,'stdout','--psm','7'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
   }
   return extra+'\n'+execFileSync('tesseract',[path,'stdout','--psm','11'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase();
  }
  async function expectScreen(name,predicate,description){
   let text='';
   for(let attempt=0;attempt<24;attempt++){
    await page.waitForTimeout(120);text=await screen(name);
    if(predicate(text)){check(true,description);return text}
   }
   assert.fail(description+'; last canvas OCR: '+JSON.stringify(text));
  }
  const gameUrl=new URL(process.env.GAME_URL || 'http://127.0.0.1:8082/');gameUrl.searchParams.delete('skip_story');gameUrl.searchParams.set('lang','en');
  await page.goto(gameUrl.href,{waitUntil:'networkidle'});
  await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});
  await page.waitForTimeout(500);
  check(!new URL(page.url()).searchParams.has('skip_story'),'default-player URL has no narrative bypass flag');
  await expectScreen('intro',text=>text.includes('a minor magical incident'),'default exported build renders the start screen');
  await page.locator('#canvas').click({position:{x:200,y:680}});
  await page.keyboard.press('Enter');
  await expectScreen('opening',text=>text.includes('arcana academy') && text.includes('skip story') && /\b0?1\s*[/|]\s*14\b/.test(text),'Enter opens the Academy story instead of entering combat immediately');
  await page.keyboard.press('Space');
  await expectScreen('page02',text=>text.includes('professor') && /\b0?2\s*[/|]\s*14\b/.test(text),'Space advances to the professor’s request on the next story page');
  await page.keyboard.press('a');
  await expectScreen('auto-paused',text=>text.includes('auto advance') && /\boff\b/.test(text) && /\b0?2\s*[/|]\s*14\b/.test(text),'A visibly disables automatic story advance on the professor page');
  await page.waitForTimeout(6500);
  await expectScreen('auto-held',text=>/\b0?2\s*[/|]\s*14\b/.test(text) && /\boff\b/.test(text),'manual reading holds the same page beyond its normal automatic duration');
  await page.keyboard.press('a');
  await expectScreen('auto-resumed',text=>text.includes('auto advance') && /\bon\b/.test(text) && /\b0?2\s*[/|]\s*14\b/.test(text),'A resumes automatic reading with a fresh full window for the current line');
  await page.keyboard.press('Escape');
  await expectScreen('detention',text=>/entering\s+area\s+0?1/.test(text) && text.includes('detention') && /fight\s+[1il]\s*[/|]\s*2/.test(text) && !text.includes('skip story'),'Escape skips the opening into the playable Detention tutorial');
  await page.keyboard.press('i');
  await expectScreen('equipment',text=>text.includes('traveling possessions') && text.includes('satchel'),'the tutorial accepts equipment input after the narrative callback');
  // Close the satchel and pause before slow OCR leaves the idle cat exposed
  // to the guardians gathered during the preceding rendered UI assertions.
  await page.keyboard.press('Escape',{delay:120});
  await page.waitForTimeout(160);
  await page.keyboard.press('Escape',{delay:120});
  const paused=await expectScreen('pause',text=>text.includes('taking a catnap'),'normal pause input works after the story has released control');
  check(!paused.includes('traveling possessions') && !paused.includes('skip story') && paused.includes('detention'),'Escape closes equipment without reopening or advancing the story');
  check(failed.length===0,'default narrative assets load without HTTP failures');
  check(errors.length===0,'default narrative path has no browser or engine console errors: '+JSON.stringify(errors));
  console.log(`STORY WEB RESULT: ${checks} checks, 0 failures`);
  console.log('Scope: default exported narrative start, one page advance, A manual hold/resume, Escape skip into Detention, equipment and pause control; no browser full-opening autoplay, campaign-clear or ending claim.');
 } finally {await browser.close()}
})().catch(error=>{console.error(error);process.exit(1)});
