extends SceneTree

const RouteFixture = preload("res://tests/route_fixture.gd")

# Exercise the story props as actual enemies, collisions and optional finds.
var checks := 0
var failures := 0
var room
var profile_path := "/tmp/meow-living-stages-%d.json" % OS.get_process_id()

func check(ok: bool, message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)

func _initialize() -> void:
	call_deferred("run")

func frames(count: int=2) -> void:
	for i in range(count):
		await physics_frame
		await process_frame

func freeze() -> void:
	room.player.set_physics_process(false)
	for enemy in room.enemies:
		enemy.active=false
		enemy.set_physics_process(false)

func world_points(points: PackedVector2Array) -> PackedVector2Array:
	var mapped := PackedVector2Array()
	for point in points: mapped.append(WorldLayout.point(point))
	return mapped

func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames()
	room=current_scene
	room.begin_or_restart()
	freeze()
	check(room.props.size()>=3,"detention keeps expanded storage bookcases appropriate to the storeroom")
	room.load_sector(1)
	await frames()
	freeze()
	var books := 0
	var initial_row := PackedVector2Array()
	for enemy in room.enemies:
		if enemy is LivingStageEnemy and enemy.role=="book":
			books+=1
			initial_row.append(enemy.formation_home)
	check(books==6 and initial_row==world_points(room.backdrop_painter.live_book_positions()),"the library's evenly spaced floating-book row is the actual six enemies")
	check(room.props.size()>=6 and room.props[0].reveal_cache,"one of the real library cases conceals a maintenance nook")
	var book: LivingStageEnemy=room.enemies[0]
	book.position=Vector2(640,430)
	room.player.position=Vector2(800,430)
	room.player.active=true
	room.player.health.current=100
	room.player.invulnerability=0
	book.active=true
	book.cooldown=0
	book._physics_process(0.01)
	var lane := book.get_attack_preview()
	var locked: PackedVector2Array=lane.path
	check(book.phase=="windup" and room.player.health.current==100,"a book opens its page-cutting warning before causing damage")
	check(is_equal_approx(AttackTelegraph.path_length(locked),239.2),"book warning promises its actual 239.2-pixel swoop")
	room.player.position=Vector2(800,550)
	book._physics_process(0.4)
	check(book.get_attack_preview().path==locked,"book locks the swoop direction instead of tracking a sidestep")
	book._physics_process(0.5)
	for i in range(35): book._physics_process(1.0/60.0)
	check(room.player.health.current==100 and book.phase=="recover","stepping out of the book's lane avoids actual swoop damage")
	book.position=Vector2(640,430)
	book.phase="attack"
	book.phase_time=book.attack_duration()
	book.attack_direction=Vector2.RIGHT
	book.attack_origin=book.position
	book.attack_hit=false
	room.player.position=Vector2(800,430)
	for i in range(35): book._physics_process(1.0/60.0)
	check(room.player.health.current==100-int(book.config.contact_damage),"remaining in the book's promised lane takes one real hit")
	book.phase="windup"
	book.phase_time=0.5
	book.take_damage(1,Vector2.UP)
	check(book.disordered and book.phase=="recover" and book.get_attack_preview().is_empty(),"hitting a book breaks its imposed order and interrupts the attack")
	book.active=false
	var shelf: ArcaneShelf=room.props[0]
	for foe in room.enemies: foe.active=false
	room.player.position=shelf.position+Vector2(-100,0)
	var before_loot: int=room.loot.size()
	check(not shelf.scavenge_cache() and room.loot.size()==before_loot,"a standing case cannot hand out the hidden supplies")
	shelf.receive_magic("water",Vector2.RIGHT,"success")
	check(shelf.state=="falling" and not shelf.burning,"water tips the controlled case without an unrelated fire effect")
	room.state="paused"
	var fall_clock := shelf.timer
	shelf._process(1.0)
	check(is_equal_approx(shelf.timer,fall_clock),"pause also freezes the newly exposed story-prop action")
	room.state="playing"
	shelf._process(0.36)
	check(shelf.state=="fallen" and shelf.revealed and not shelf.cache_claimed,"falling exposes the former blocked footprint and a visible service hatch")
	check(not shelf.scavenge_cache(),"the newly visible nook still requires walking close enough")
	room.player.position=shelf.position+Vector2(0,30)
	room.interact()
	check(shelf.cache_claimed and room.loot.size()==before_loot+2,"E at the revealed hatch finds actual Crowns and a snack")
	var gold_sum := 0
	var foods := 0
	for drop in room.loot:
		if drop.kind=="gold": gold_sum+=drop.amount
		if drop.kind=="food" and drop.amount==20: foods+=1
	check(gold_sum==12 and foods==1,"the optional accident find contains exactly its authored supplies")
	check(not shelf.scavenge_cache() and room.loot.size()==before_loot+2,"a maintenance find cannot be claimed twice")
	check(not room.exit_open and room.enemies.size()==6,"finding the nook neither skips the fight nor removes its enemies")
	var ordinary: ArcaneShelf=room.props[1]
	ordinary.receive_magic("fire",Vector2.RIGHT,"miscast")
	check(ordinary.state=="burning" and ordinary.burning,"fire retains the original failed-fireball-to-burning-shelf chain")
	ordinary.collapse()
	check(not ordinary.revealed,"ordinary cases remain combat props without duplicating the special find")
	room.load_sector(2)
	await frames()
	freeze()
	var mushrooms := 0
	var beds := PackedVector2Array()
	for enemy in room.enemies:
		if enemy is LivingStageEnemy and enemy.role=="mushroom":
			mushrooms+=1
			beds.append(enemy.formation_home)
	check(mushrooms==6 and beds==world_points(room.backdrop_painter.live_mushroom_positions()),"the forbidden garden's aligned reagent beds are the six live mushroom enemies")
	check(room.props.is_empty(),"the mushroom farm has no unexplained falling library case")
	var mushroom: LivingStageEnemy=room.enemies[0]
	mushroom.position=Vector2(640,430)
	mushroom.awakened=false
	mushroom.active=true
	room.player.position=Vector2(200,430)
	var home: Vector2=mushroom.position
	mushroom._physics_process(0.2)
	check(not mushroom.awakened and mushroom.position==home,"a distant controlled reagent crop stays rooted in its bed")
	room.player.position=Vector2(800,430)
	mushroom._physics_process(0.01)
	check(mushroom.awakened and mushroom.position!=home,"approaching the crop wakes it and its short feet really move")
	mushroom.position=Vector2(640,430)
	mushroom.phase="windup"
	mushroom.phase_time=mushroom.warning_duration()
	var circle := mushroom.get_attack_preview()
	check(is_equal_approx(circle.radius,74.0+float(room.player.config.radius)) and AttackTelegraph.path_length(circle.path)<0.02,"mushroom warns a circular spore sneeze, including the player's actual radius")
	for outside in [true,false]:
		room.player.position=mushroom.position+Vector2(0,float(circle.radius)+(0.01 if outside else -0.01))
		room.player.health.current=100
		room.player.invulnerability=0
		mushroom.phase="attack"
		mushroom.phase_time=mushroom.attack_duration()
		mushroom.attack_hit=false
		mushroom._physics_process(0.01)
		check(room.player.health.current==(100 if outside else 100-int(mushroom.config.contact_damage)),"spore boundary: "+("just outside the floor circle is safe" if outside else "just inside the floor circle takes damage"))
	mushroom.awakened=false
	mushroom.phase="approach"
	mushroom.take_damage(1,Vector2.RIGHT)
	check(mushroom.awakened and mushroom.disordered and mushroom.get_attack_preview().is_empty(),"a spell wakes a mushroom and breaks its control seal without a hidden delayed hit")
	for stage in [3,6]:
		room.load_sector(stage)
		await frames()
		freeze()
		check(room.props.is_empty() and room.enemies.is_empty(),"rest stop%d contains friends and stalls, not arbitrary falling cases" % stage)
	room.load_sector(4)
	await frames()
	freeze()
	var reading_books := 0
	for enemy in room.enemies:
		if enemy.role=="book" and enemy is LivingStageEnemy: reading_books+=1
	check(reading_books==5 and room.props.size()>=6,"the old reading room continues the book patrol rather than recycling an unrelated slime wave")
	room.load_sector(5)
	await frames()
	freeze()
	var promenade_beds := PackedVector2Array()
	for enemy in room.enemies:
		if enemy.role=="mushroom": promenade_beds.append(enemy.formation_home)
	check(promenade_beds==world_points(room.backdrop_painter.live_mushroom_positions(true)) and room.props.is_empty(),"the ordered garden path carries the awakened crop convoy onward, without library furniture")
	room.load_sector(7)
	check(RouteFixture.reach_boss(room),"archive seals lead through both defender groups before the book")
	await frames()
	freeze()
	check(room.enemies[-1] is PerfectExaminer and room.enemies[-1].health.maximum==180,"archive story enemies preserve the sentient-book boss and barrier rules")
	room.free()
	await frames()
	if FileAccess.file_exists(profile_path): DirAccess.remove_absolute(profile_path)
	print("LIVING STAGES RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
