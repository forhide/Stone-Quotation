extends SceneTree

# Verify that denser assets preserve the authored atlas geometry and source
# identities. The graphical atlas proof separately exercises engine cropping.
var checks := 0
var failures := 0
func check(ok: bool,message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func run() -> void:
 var backgrounds := [ArchiveBackdrop.STORAGE,ArchiveBackdrop.LIBRARY,ArchiveBackdrop.GARDEN,ArchiveBackdrop.ARCHIVE]
 for texture: Texture2D in backgrounds:
  var image := texture.get_image()
  check(texture is PortableCompressedTexture2D and image.get_size()==Vector2i(3840,2560),"painted room keeps its3840px source: "+texture.resource_path.get_file())
  check(HiResArt.logical_size(texture)==Vector2(1536,1024),"HD room retains its original crop coordinate space: "+texture.resource_path.get_file())
 var atlases := [WizardCatVisual.ACTION_SHEET,AnimalCast.SHEET,GrimoireArt.SHEET]
 var logical := [Vector2(1536,1024),Vector2(1536,1024),Vector2(1254,1254)]
 for i in range(atlases.size()):
  var texture: Texture2D=atlases[i]
  var image := texture.get_image()
  check(HiResArt.logical_size(texture)==logical[i] and texture.get_size()==logical[i]*2.0,"HD character atlas doubles detail while keeping logical region dimensions: "+texture.resource_path.get_file())
  check(image.has_mipmaps(),"scaled character atlas contains real mip levels: "+texture.resource_path.get_file())
 for rect: Rect2i in WizardCatVisual.POSE_RECTS:
  check(Rect2(Vector2.ZERO,logical[0]).encloses(Rect2(rect)),"each full-body cat pose remains within the original atlas bounds")
 for id: String in AnimalCast.REGIONS:
  var icon := AnimalCast.icon(id)
  check(icon is AtlasTexture and icon.get_size()==AnimalCast.region(id).size and Rect2(Vector2.ZERO,logical[1]).encloses(AnimalCast.region(id)),"animal portrait retains its original identity and crop: "+id)
 for pose: String in GrimoireArt.REGIONS:
  var icon := GrimoireArt.icon(pose)
  check(icon is AtlasTexture and icon.get_size()==GrimoireArt.region(pose).size and Rect2(Vector2.ZERO,logical[2]).encloses(GrimoireArt.region(pose)),"sentient book retains its original expression crop: "+pose)
 check(HiResArt.logical_size(WizardCatVisual.WALK_SHEET)==WizardCatVisual.WALK_SHEET.get_size(),"non-Portable walk frames keep their native coordinate space")
 var walk_image := WizardCatVisual.WALK_SHEET.get_image()
 check(walk_image.has_mipmaps(),"existing painted walk frames generate real mip levels too")
 # A static high-density shelf cache must preserve all previous collision and
 # display dimensions, not turn into a larger gameplay obstacle.
 var holder := Node2D.new()
 root.add_child(holder)
 var shelf := ArcaneShelf.new()
 shelf.room=holder
 shelf.set_process(false)
 holder.add_child(shelf)
 check(holder.get_meta("shelf_art_cache").size==Vector2i(1440,480),"procedural shelf detail is cached at3x once per room")
 check((shelf.standing_texture.get_size()*shelf.body.scale).is_equal_approx(ArcaneShelf.STANDING_SIZE),"painted shelf has a readable three-quarter body above its floor contact")
 check(shelf.fallen_texture.get_size().x>=500 and shelf.fallen_texture.get_size().y>=500 and shelf.fallen_texture.atlas==EnchantedArt.PROPS,"fallen shelf uses its own detailed painted atlas crop")
 check(not shelf.body.is_physics_interpolated() and not shelf.flame.is_physics_interpolated(),"render-clock shelf shaking avoids a second local interpolation path")
 holder.queue_free()
 await process_frame
 print("HD ART RESULT: %d checks, %d failures" % [checks,failures])
 quit(1 if failures else 0)
