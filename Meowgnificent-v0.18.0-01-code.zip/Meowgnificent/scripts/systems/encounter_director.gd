class_name EncounterDirector
extends Node2D

# One bounded group at a time. Between groups the player explores toward a
# visible seal; no enemies appear simply because a hidden timer elapsed.
signal encounter_requested(definition: Dictionary)
signal encounter_cleared(index: int)
signal route_completed
signal changed

const CANONICAL_BOUNDS := Rect2(100,160,1080,535)
const TRIGGER_RADIUS := 150.0
const CANCEL_RADIUS := 215.0
const REST_SECONDS := 0.7
const WINDUP_SECONDS := 1.1
const SAFE_SPAWN_DISTANCE := 150.0
const MIN_SEPARATION := 52.0
const MAX_GROUP_SIZE := 8

var stage_index := 0
var index := 0
var state := "complete"
var world_bounds := CANONICAL_BOUNDS
var stage: Dictionary = {}
var definitions: Array[Dictionary] = []
var elapsed := 0.0
var ambient_time := 0.0
var rest_elapsed := 0.0
var _pending: Dictionary = {}
var _spawn_points := PackedVector2Array()

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	z_index=-1

func configure(source: Dictionary, area_index: int, bounds: Rect2) -> void:
	stage=source.duplicate(true)
	stage_index=area_index
	world_bounds=bounds
	index=0
	elapsed=0.0
	ambient_time=0.0
	rest_elapsed=0.0
	_pending.clear()
	_spawn_points.clear()
	definitions.clear()
	if str(stage.get("kind",""))!="shop":
		var series: Array=stage.get("encounters",[])
		if series.is_empty(): series=[{}]
		for entry in series:
			var definition: Dictionary=stage.duplicate(true)
			definition.erase("encounters")
			definition.merge(entry,true)
			definition["name"]=str(entry.get("name",stage.get("name","Encounter")))
			definition["boss_encounter"]=bool(entry.get("boss_encounter",str(stage.get("kind",""))=="final" and series.size()==1))
			definition["hp"]=maxi(1,roundi(float(stage.get("hp",40))*float(entry.get("hp_scale",1.0))))
			definition["anchor"]=entry.get("anchor",[640,430]).duplicate()
			definitions.append(definition)
	state="complete" if definitions.is_empty() else "active"
	visible=false
	changed.emit()
	queue_redraw()

func is_complete() -> bool:
	return state=="complete"

func current_definition() -> Dictionary:
	if definitions.is_empty(): return {}
	return (_pending if not _pending.is_empty() else definitions[index]).duplicate(true)

func waypoint() -> Vector2:
	if definitions.is_empty(): return map_point(Vector2(1136,430))
	var anchor: Array=definitions[index].anchor
	return map_point(Vector2(float(anchor[0]),float(anchor[1])))

func map_point(point: Vector2) -> Vector2:
	return world_bounds.position+(point-CANONICAL_BOUNDS.position)*world_bounds.size/CANONICAL_BOUNDS.size

func canonical_point(point: Vector2) -> Vector2:
	return CANONICAL_BOUNDS.position+(point-world_bounds.position)*CANONICAL_BOUNDS.size/world_bounds.size

func finish_current() -> bool:
	if state!="active": return is_complete()
	encounter_cleared.emit(index)
	_pending.clear()
	_spawn_points.clear()
	elapsed=0.0
	rest_elapsed=0.0
	if index>=definitions.size()-1:
		state="complete"
		visible=false
		changed.emit()
		route_completed.emit()
		queue_redraw()
		return true
	index+=1
	state="waiting"
	visible=true
	changed.emit()
	queue_redraw()
	return false

func tick(delta: float, player_position: Vector2, playing: bool) -> void:
	if not playing or state not in ["waiting","windup"]: return
	# A long stalled frame must not consume the entire visible arrival warning.
	var step := clampf(delta,0.0,0.1)
	ambient_time+=step
	rest_elapsed+=step
	if state=="waiting":
		if rest_elapsed>=REST_SECONDS and player_position.distance_to(waypoint())<=TRIGGER_RADIUS:
			_prepare_arrival(player_position)
			state="windup"
			elapsed=0.0
			changed.emit()
	elif player_position.distance_to(waypoint())>CANCEL_RADIUS:
		_cancel_arrival()
	else:
		# Entering an actual landing circle repositions the preview and restarts
		# its full warning, so no reinforcement can materialize on the cat.
		var obstructed := false
		for point in _spawn_points:
			if point.distance_to(player_position)<SAFE_SPAWN_DISTANCE*0.65:
				obstructed=true
				break
		if obstructed:
			_prepare_arrival(player_position)
			elapsed=0.0
		else:
			elapsed+=step
			if elapsed>=WINDUP_SECONDS:
				state="active"
				visible=false
				changed.emit()
				encounter_requested.emit(current_definition())
	queue_redraw()

func _cancel_arrival() -> void:
	state="waiting"
	elapsed=0.0
	_pending.clear()
	_spawn_points.clear()
	changed.emit()

func _prepare_arrival(player_position: Vector2) -> void:
	_pending=definitions[index].duplicate(true)
	_spawn_points.clear()
	var source: Array=_pending.positions
	var safe_positions: Array=[]
	for i in range(source.size()):
		var point := map_point(Vector2(float(source[i][0]),float(source[i][1])))
		point=_safe_spawn(point,player_position,i)
		_spawn_points.append(point)
		var local := canonical_point(point)
		safe_positions.append([local.x,local.y])
	_pending["positions"]=safe_positions

func _safe_spawn(original: Vector2, player_position: Vector2, ordinal: int) -> Vector2:
	var allowed := world_bounds.grow(-40.0)
	var limit := allowed.end-Vector2(0.01,0.01)
	var first := original.clamp(allowed.position,limit)
	if _is_clear(first,player_position): return first
	var best := first
	var best_score := -INF
	# Fixed deterministic candidates, evaluated only when arming a new group.
	for ring in range(4):
		for spoke in range(20):
			var angle := float(spoke)*TAU/20.0+float(ordinal)*0.47
			var candidate := (waypoint()+Vector2.from_angle(angle)*(190.0+ring*65.0)).clamp(allowed.position,limit)
			if not _is_clear(candidate,player_position): continue
			var score := -candidate.distance_squared_to(original)
			if score>best_score:
				best=candidate
				best_score=score
	if best_score==-INF:
		# Extra furniture can exhaust a local ring near a wall. Search the
		# remaining floor only while arming a group, never during combat ticks.
		for y in range(int(allowed.position.y)+24,int(limit.y),64):
			for x in range(int(allowed.position.x)+24,int(limit.x),64):
				var candidate := Vector2(x,y)
				if not _is_clear(candidate,player_position): continue
				var score := -candidate.distance_squared_to(original)
				if score>best_score:
					best=candidate
					best_score=score
	return best

func _is_clear(point: Vector2, player_position: Vector2) -> bool:
	if point.distance_to(player_position)<SAFE_SPAWN_DISTANCE: return false
	for other in _spawn_points:
		if point.distance_to(other)<MIN_SEPARATION: return false
	for shelf in stage.get("shelves",[]):
		if point.distance_to(map_point(Vector2(float(shelf[0]),float(shelf[1]))))<76.0: return false
	for prop: Dictionary in stage.get("furnishings",[]):
		if point.distance_to(map_point(Vector2(float(prop.at[0]),float(prop.at[1]))))<78.0: return false
	return true

func snapshot() -> Dictionary:
	return {"index":index,"total":definitions.size(),"state":state,"name":str(definitions[index].name) if not definitions.is_empty() else "",
		"target":waypoint(),"progress":clampf(elapsed/WINDUP_SECONDS,0.0,1.0),"stage":stage_index,"spawn_points":_spawn_points.duplicate()}

func _draw() -> void:
	if state not in ["waiting","windup"]: return
	var center := waypoint()
	var breath := 1.0+sin(ambient_time*2.2)*0.015
	EnchantedArt.stamp(self,"seal",center,Vector2(160,96)*breath,0.88)
	var caption := GameLocale.text("Next encounter") if state=="waiting" else GameLocale.text("Magic gathering…")
	# Use the bundled Korean-capable face, including on clean desktop installs.
	var width := GameLocale.TITLE_FONT.get_string_size(caption,HORIZONTAL_ALIGNMENT_LEFT,-1,15).x
	StorybookTag.draw_tag(self,caption,center+Vector2(0,-64),Vector2(maxf(151,width+32),35),15,Color("b19abd"))
	if state!="windup": return
	var progress := clampf(elapsed/WINDUP_SECONDS,0.0,1.0)
	for point in _spawn_points:
		EnchantedArt.stamp(self,"seal",point,Vector2(62,38),0.48+progress*0.4)
		draw_set_transform(point,0,Vector2(1,0.55))
		draw_arc(Vector2.ZERO,25,-PI/2,-PI/2+TAU*progress,24,Color("fff1cd"),2.5,true)
		draw_set_transform(Vector2.ZERO)
