extends Node

signal changed(locale: String)
const SUPPORTED := ["ko", "en"]
const STORY_FONT: Font = preload("res://art/fonts/GowunDodum-Regular.ttf")
var current := "ko"
var settings_path := "user://settings-v1.cfg"
var save_error := false
var translations: Dictionary = {}

func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	ThemeDB.fallback_font=STORY_FONT
	var display_font: Font=preload("res://art/fonts/Jua-Regular.ttf")
	display_font.fallbacks=[STORY_FONT]
	translations=JSON.parse_string(FileAccess.get_file_as_string("res://data/locales/ko.json"))
	var korean := Translation.new()
	korean.locale="ko"
	for key: String in translations: korean.add_message(key,str(translations[key]))
	TranslationServer.add_translation(korean)
	if OS.has_environment("MEOW_SETTINGS_PATH"): settings_path=OS.get_environment("MEOW_SETTINGS_PATH")
	current=load_language(settings_path)
	var override := OS.get_environment("MEOW_LANGUAGE")
	if OS.has_feature("web") and Engine.has_singleton("JavaScriptBridge"):
		var bridge: Object=Engine.get_singleton("JavaScriptBridge")
		var requested: Variant=bridge.call("eval","new URLSearchParams(window.location.search).get('lang') || ''")
		if requested is String and requested in SUPPORTED: override=requested
	if override in SUPPORTED: current=override
	TranslationServer.set_locale(current)

func load_language(path: String) -> String:
	var config := ConfigFile.new()
	if config.load(path)==OK:
		var saved := str(config.get_value("preferences","language","ko"))
		if saved in SUPPORTED: return saved
	return "ko"

func set_language(value: String, persist: bool=true) -> bool:
	if value not in SUPPORTED: return false
	current=value
	TranslationServer.set_locale(current)
	save_error=false
	if persist:
		var config := ConfigFile.new()
		config.load(settings_path)
		config.set_value("preferences","language",current)
		save_error=config.save(settings_path)!=OK
	changed.emit(current)
	return not save_error

func text(source: String) -> String:
	return str(TranslationServer.translate(source))

func story_text(page: Dictionary) -> String:
	return str(page.get("text_en",page.get("text",""))) if current=="en" else str(page.get("text",""))
