class_name WizardCatVisual
extends Node2D

const ACTION_SHEET: Texture2D = preload("res://art/hd/pastel_meme_actions.res")
const CLEAN_ACTIONS: Texture2D = preload("res://art/characters/collarless_actions.png")
const CLEAN_WALK: Texture2D = preload("res://art/characters/collarless_walk.png")
const BELL_CENTRES := [Vector2(0.453,0.605),Vector2(0.412,0.608),Vector2(0.645,0.615),Vector2(0.438,0.492),Vector2(0.480,0.607),Vector2(0.5,0.5)]
const WALK_BELLS := [Vector2(0.450,0.583),Vector2(0.448,0.583),Vector2(0.458,0.587),Vector2(0.456,0.594),Vector2(0.443,0.605),Vector2(0.456,0.586)]
# Six distinct full-body key poses; small margins keep neighboring cells out.
const POSE_RECTS: Array[Rect2i] = [Rect2i(65,6,437,501),Rect2i(569,8,429,499),Rect2i(1065,33,453,474),Rect2i(44,520,500,454),Rect2i(563,513,450,460),Rect2i(1058,554,455,423)]
# A fixed fine grid articulates the short feet without rebuilding the mesh.
const WALK_SHEET: Texture2D = preload("res://art/characters/meme_walk.png")
const WALK_RECTS: Array[Rect2i] = [Rect2i(62,9,437,497),Rect2i(552,9,429,499),Rect2i(1036,8,430,496),Rect2i(63,514,439,491),Rect2i(555,518,434,476),Rect2i(1039,514,436,487)]
# Face-centred pivots keep authored poses aligned while their hats sway.
const WALK_PIVOTS := [Vector2(0.495,1),Vector2(0.489,1),Vector2(0.497,1),Vector2(0.491,1),Vector2(0.484,1),Vector2(0.478,1)]
const COLS := 12
const ROWS := 16
var cat: WizardCat
var sprite: MeshInstance2D
var equipment_visual: CatEquipmentVisual
var motion_material: ShaderMaterial
var mesh_pose := -1
var mesh_facing := 0.0
var elapsed := 0.0
var active_pose := 0
var gait := 0.0
var pose_age := 0.0
var walk_frame := -1
var walking := false
var art_key := ""
var body_offset := Vector2.ZERO
var skill_echo: MeshInstance2D
var skill_echo_material: ShaderMaterial
var skill_blend_remaining := 0.0
var skill_render_remaining := 0.0
var skill_serial := -1
var skill_was_active := false
const SKILL_BLEND_SECONDS := 0.085

func _ready() -> void:
	physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	cat=get_parent() as WizardCat
	# Whole painted walk frames replace the detached belly/paw crop rig.
	sprite=MeshInstance2D.new()
	sprite.texture=ACTION_SHEET
	sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	var vertices := PackedVector2Array()
	var coordinates := PackedVector2Array()
	var indices := PackedInt32Array()
	for y in range(ROWS+1):
		for x in range(COLS+1):
			var uv := Vector2(float(x)/COLS,float(y)/ROWS)
			vertices.append(Vector2((uv.x-0.5)*160,(uv.y-1)*180))
			coordinates.append(uv)
	for y in range(ROWS):
		for x in range(COLS):
			var a := y*(COLS+1)+x
			indices.append_array(PackedInt32Array([a,a+1,a+COLS+1,a+1,a+COLS+2,a+COLS+1]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX]=vertices
	arrays[Mesh.ARRAY_TEX_UV]=coordinates
	arrays[Mesh.ARRAY_INDEX]=indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays,[],{},Mesh.ARRAY_FLAG_USE_2D_VERTICES)
	mesh.custom_aabb=AABB(Vector3(-200,-200,-1),Vector3(400,400,2))
	sprite.mesh=mesh
	motion_material=ShaderMaterial.new()
	motion_material.shader=preload("res://scripts/player/cat_motion.gdshader")
	sprite.material=motion_material
	add_child(sprite)
	# One cached copy bridges whole-body casting poses for85ms. Walking frames
	# remain crisp; no crop rig, particle system or mesh rebuild is involved.
	skill_echo=MeshInstance2D.new()
	skill_echo.mesh=mesh
	skill_echo_material=ShaderMaterial.new()
	skill_echo_material.shader=motion_material.shader
	skill_echo.material=skill_echo_material
	skill_echo.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	skill_echo.visible=false
	sprite.add_child(skill_echo)
	update_mesh()
	equipment_visual=CatEquipmentVisual.new()
	add_child(equipment_visual)

func choose_pose() -> int:
	if cat.roll_time>0: return 5
	if cat.hit_reaction>0 or cat.health.current<=0: return 4
	if cat.skill_pose_time>0:
		var remaining := cat.skill_pose_time if skill_serial!=cat.skill_pose_serial else skill_render_remaining
		return 1 if remaining>0.43 else 2
	if cat.cast_prepare>0: return 1
	if cat.cast_pose>0:
		return 3 if cat.cast_outcome!="success" else 2
	return 0

func _process(delta: float) -> void:
	var animating := cat.active or cat.presentation_scale>1.0
	if skill_serial!=cat.skill_pose_serial:
		skill_serial=cat.skill_pose_serial
		skill_render_remaining=cat.skill_pose_time
	if animating:
		skill_render_remaining=maxf(0,skill_render_remaining-delta)
		skill_blend_remaining=maxf(0,skill_blend_remaining-delta)
		elapsed+=delta
		gait=move_toward(gait,clampf(cat.ground_speed/float(cat.config.speed),0,1),delta*6)
		pose_age+=delta
	var next := choose_pose()
	if next!=active_pose:
		active_pose=next
		pose_age=0
	scale=Vector2.ONE*cat.presentation_scale
	if cat.roll_time>0:
		position=Vector2(0,-36)
		rotation=cat.roll_spin
	else:
		position=Vector2.ZERO
		# The body stays over the planted feet; only the hat lags behind a step.
		rotation=0
		if active_pose==1: rotation-=cat.cast_aim.x*0.09
		if active_pose==2: rotation+=cat.cast_aim.x*0.12*cat.cast_pose
		if active_pose==3: rotation-=cat.cast_aim.x*0.16*cat.cast_pose
		if active_pose==4: rotation+=sin(elapsed*37)*0.07*minf(1,cat.hit_reaction*4)
		if cat.skill_pose_time>0 and active_pose in [1,2]:
			# Q gathers both paws, releases with a broad flourish, then settles.
			# The feet remain fixed; a failed skill never reuses the stumble pose.
			var skill_t := 1.0-skill_render_remaining/WizardCat.SKILL_POSE_SECONDS
			var flourish := sin(clampf((skill_t-0.1)/0.8,0,1)*PI)
			rotation=cat.skill_pose_direction.x*(-0.045 if active_pose==1 else 0.075*flourish)
	walking=active_pose==0 and cat.ground_speed>1.0 and cat.active
	walk_frame=GroundedCatGait.frame_for(cat.walk_distance) if walking else -1
	# Weight transfer is authored with attached legs; no detached paw offsets.
	body_offset=Vector2.ZERO
	update_mesh()
	if skill_blend_remaining>0 and active_pose in [0,1,2,3]:
		var blend := smoothstep(0,1,1.0-skill_blend_remaining/SKILL_BLEND_SECONDS)
		sprite.self_modulate.a=blend
		skill_echo.self_modulate.a=1.0-blend
		skill_echo.visible=true
	else:
		sprite.self_modulate.a=1
		skill_echo.visible=false
	skill_was_active=cat.skill_pose_time>0
	queue_redraw()

func update_mesh() -> void:
	# The indexed mesh is immutable. Only small GPU uniforms change per frame.
	var next_key := "walk:%d" % walk_frame if walking else "pose:%d" % active_pose
	if next_key!=art_key:
		if not art_key.is_empty() and mesh_pose!=active_pose and mesh_pose in [0,1,2,3] and active_pose in [0,1,2,3]:
			skill_echo.texture=sprite.texture
			for parameter in ["frame_uv","pose_size","pose_pivot","motion","pose","pose_amount","facing","body_offset","clean_neck_sheet","bell_uv","replace_collar"]:
				skill_echo_material.set_shader_parameter(parameter,motion_material.get_shader_parameter(parameter))
			skill_blend_remaining=SKILL_BLEND_SECONDS
		var rect := WALK_RECTS[walk_frame] if walking else POSE_RECTS[active_pose]
		var factor := float(cat.config.get("sprite_height",168.0))*0.86/510.0
		if active_pose==5: factor*=0.78
		var sheet: Texture2D=WALK_SHEET if walking else ACTION_SHEET
		sprite.texture=sheet
		var sheet_size := HiResArt.logical_size(sheet)
		motion_material.set_shader_parameter("frame_uv",Vector4(rect.position.x/sheet_size.x,rect.position.y/sheet_size.y,rect.size.x/sheet_size.x,rect.size.y/sheet_size.y))
		# Fixed overall height avoids scale pumping between the six drawings.
		motion_material.set_shader_parameter("pose_size",Vector2(rect.size.x,501 if walking else rect.size.y)*factor)
		motion_material.set_shader_parameter("pose_pivot",WALK_PIVOTS[walk_frame] if walking else Vector2(0.5,1))
		motion_material.set_shader_parameter("pose",active_pose)
		motion_material.set_shader_parameter("clean_neck_sheet",CLEAN_WALK if walking else CLEAN_ACTIONS)
		var bell: Vector2=WALK_BELLS[walk_frame] if walking else BELL_CENTRES[active_pose]
		motion_material.set_shader_parameter("bell_uv",Vector4(bell.x,bell.y,0.068,0.068))
		mesh_pose=active_pose
		art_key=next_key
	var facing := -1.0 if active_pose in [1,2,3] and cat.cast_aim.x<0 else 1.0
	if facing!=mesh_facing:
		motion_material.set_shader_parameter("facing",facing)
		mesh_facing=facing
	var step := cat.walk_distance/GroundedCatGait.CYCLE_DISTANCE*TAU
	# Hat lag follows the same planted-foot phase instead of an unrelated
	# velocity clock, which previously kept wiggling between the steps.
	motion_material.set_shader_parameter("motion",Vector4(sin(elapsed*2.8),sin(step),sin(step-0.65),gait))
	motion_material.set_shader_parameter("pose_amount",cat.cast_pose)
	motion_material.set_shader_parameter("body_offset",body_offset)
	var soot := minf(1.0,cat.soot_time/0.6)
	motion_material.set_shader_parameter("soot_amount",soot)
	skill_echo_material.set_shader_parameter("soot_amount",soot)
	var replacing := equipment_visual!=null and not str(equipment_visual.equipment.collar).is_empty() and active_pose!=5
	motion_material.set_shader_parameter("replace_collar",replacing)
	skill_echo_material.set_shader_parameter("replace_collar",replacing)

func collar_anchor() -> Vector2:
	var bell: Vector2=WALK_BELLS[walk_frame] if walking else BELL_CENTRES[active_pose]
	var extent: Vector2=motion_material.get_shader_parameter("pose_size")
	var pivot: Vector2=motion_material.get_shader_parameter("pose_pivot")
	var p := (bell-pivot)*extent+Vector2(0,3)
	var belly := sin(bell.y*PI)
	p.x*=1.0+belly*0.009*sin(elapsed*2.8)
	p.x*=lerpf(1.0,0.94,smoothstep(0.50,0.72,bell.y))
	p.y+=sin(elapsed*2.8)*0.65*belly
	p.y-=extent.y*0.03*(1.0-clampf((bell.y-0.5)/0.5,0,1))
	if active_pose==1:
		p.x*=1.0+0.05*belly
		p.y+=belly*3.0
	elif active_pose==2: p.x+=(1.0-bell.y)*4.0*cat.cast_pose
	elif active_pose==3: p.x-=(1.0-bell.y)*5.0*cat.cast_pose
	return p

func _draw() -> void:
	if cat==null: return
	if cat.soot_time>0:
		EnchantedArt.stamp(self,"soot",Vector2(sin(elapsed*3)*4,-147),Vector2(58,52),minf(0.65,cat.soot_time*0.5))
	if cat.roll_time>0 or cat.skill_pose_time>0: return
	var charging := cat.cast_prepare>0
	if charging or cat.cast_pose>0.05:
		var power := 0.65 if charging else cat.cast_pose
		var facing := 1.0 if cat.cast_aim.x>=0 else -1.0
		var point := Vector2(-49,-87) if active_pose==1 else Vector2(51,-61)
		point.x*=facing
		# Gather the same living element at the raised paw before it leaves.
		# This is presentation only: the controller keeps its original0.12s
		# anticipation and the projectile keeps its real collision trajectory.
		var gathering := clampf(1.0-cat.cast_prepare/0.12,0.0,1.0)
		var extent := lerpf(0.18,0.55,gathering) if charging else power*0.46
		ElementalFlightInk.draw(self,cat.cast_element,point,Vector2.ZERO,elapsed,extent,cat.cast_outcome)
