class_name StorybookTag
extends RefCounted

# These are deliberately vellum interface captions, rather than lettering
# pasted over a perspective wooden object. One cached style per accent.
static var _styles: Dictionary = {}

static func draw_tag(canvas: CanvasItem, caption: String, center: Vector2, extent: Vector2, font_size: int=15, accent: Color=Color("a28baf")) -> void:
	var key := accent.to_html()
	if not _styles.has(key):
		var style := StyleBoxFlat.new()
		style.bg_color=Color("fff8e7")
		style.border_color=accent.lightened(0.34)
		style.set_border_width_all(1)
		style.set_corner_radius_all(10)
		style.shadow_color=Color(0.31,0.25,0.23,0.13)
		style.shadow_size=3
		style.shadow_offset=Vector2(0,2)
		_styles[key]=style
	var bounds := Rect2(center-extent*0.5,extent)
	canvas.draw_style_box(_styles[key],bounds)
	var font := GameLocale.TITLE_FONT
	var width := font.get_string_size(caption,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x
	var baseline := center+Vector2(-width*0.5,(font.get_ascent(font_size)-font.get_descent(font_size))*0.5)
	canvas.draw_string(font,baseline+Vector2(0,0.7),caption,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color("fffdf5"))
	canvas.draw_string(font,baseline,caption,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,Color("725c50"))
