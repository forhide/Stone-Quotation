class_name StudyRank
extends Control

var learned := 0
var limit := 8
var ink := Color("a590b5")

func _ready() -> void:
	custom_minimum_size=Vector2(64,20)
	mouse_filter=Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var spacing := minf(7.0,60.0/maxi(1,limit))
	for i in range(limit):
		var at := Vector2(3+i*spacing,size.y*0.5)
		draw_circle(at,2.1,ink if i<learned else Color("ddd4d5"),true,-1,true)
		if i<learned: draw_circle(at+Vector2(-0.4,-0.5),0.65,Color("fff7df"),true,-1,true)
