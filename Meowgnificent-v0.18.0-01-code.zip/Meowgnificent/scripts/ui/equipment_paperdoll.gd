class_name EquipmentPaperdoll
extends Control

class WornInk extends Node2D:
	var host: EquipmentPaperdoll
	func _draw() -> void: host._draw_attachments(self)

var equipment: Dictionary={"wand":"","collar":"","charm":""}
var body: Sprite2D
var body_material: ShaderMaterial
var worn_ink: WornInk
const FEET := Vector2(205,340)

func _init() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS

func _ready() -> void:
	var source: Rect2=WizardCatVisual.POSE_RECTS[0]
	body=Sprite2D.new()
	body.texture=WizardCatVisual.ACTION_SHEET
	body.region_enabled=true
	body.region_rect=source
	var factor := 292.0/source.size.y
	body.scale=Vector2.ONE*factor
	body.position=FEET-Vector2(0,146)
	body_material=ShaderMaterial.new()
	body_material.shader=preload("res://scripts/player/collar_replacement.gdshader")
	var sheet := HiResArt.logical_size(WizardCatVisual.ACTION_SHEET)
	body_material.set_shader_parameter("frame_uv",Vector4(source.position.x/sheet.x,source.position.y/sheet.y,source.size.x/sheet.x,source.size.y/sheet.y))
	body_material.set_shader_parameter("clean_neck_sheet",WizardCatVisual.CLEAN_ACTIONS)
	body.material=body_material
	add_child(body)
	worn_ink=WornInk.new()
	worn_ink.host=self
	add_child(worn_ink)
	_sync_body()

func set_equipment(value: Dictionary) -> void:
	equipment=value.duplicate(true)
	if is_node_ready(): _sync_body()
	queue_redraw()

func _sync_body() -> void:
	body_material.set_shader_parameter("replace_collar",EquipmentArt.slot_for(str(equipment.get("collar","")))=="collar")
	worn_ink.queue_redraw()

func get_equipment() -> Dictionary:
	return equipment.duplicate(true)

func _draw() -> void:
	draw_set_transform(FEET+Vector2(0,3),0,Vector2(1,0.24))
	draw_circle(Vector2.ZERO,65,Color(0.52,0.50,0.37,0.12))
	draw_set_transform(Vector2.ZERO)
	for line in [[Vector2(72,64),Vector2(132,92)],[Vector2(73,263),Vector2(181,230)],[Vector2(333,263),Vector2(285,245)]]:
		draw_line(line[0],line[1],Color("d5c6a7"),2,true)

func _draw_attachments(canvas: CanvasItem) -> void:
	var source: Rect2=WizardCatVisual.POSE_RECTS[0]
	var extent := source.size*(292.0/source.size.y)
	var scale_factor := 292.0/(source.size.y*168.0*0.86/510.0)
	for slot in ["collar","charm","wand"]:
		var id := str(equipment.get(slot,""))
		var texture := EquipmentArt.worn_icon(id)
		if texture==null: continue
		var layout := EquipmentArt.attachment_layout(id)
		var target: Vector2={"wand":Vector2(40,-47),"collar":Vector2.ZERO,"charm":Vector2(-24,-114)}[slot]
		var at := FEET+target*scale_factor
		if slot=="collar": at=FEET+(WizardCatVisual.BELL_CENTRES[0]-Vector2(0.5,1))*extent
		var item_size: Vector2=Vector2(layout.extent)*scale_factor*(0.80 if slot=="wand" else 1.0)
		canvas.draw_set_transform(at,float(layout.angle))
		canvas.draw_texture_rect(texture,Rect2(-item_size*0.5,item_size),false)
		canvas.draw_set_transform(Vector2.ZERO)
