class_name RoomFurnishing
extends Node2D

# World-space painted sizes and actual floor contacts. The upper part of a
# cabinet can overlap a passer-by; only its feet occupy navigable floor.
const SPECS := {
	"cart":{"size":Vector2(116,104),"floor":Rect2(-47,-19,94,42)},
	"planter":{"size":Vector2(106,117),"floor":Rect2(-39,-19,78,40)},
	"crate":{"size":Vector2(112,105),"floor":Rect2(-45,-23,90,46)},
	"barrel":{"size":Vector2(94,120),"floor":Rect2(-34,-21,68,44)},
	"chest":{"size":Vector2(111,103),"floor":Rect2(-43,-20,86,42)}
}
var kind := "crate"
var body: Sprite2D

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	var spec: Dictionary=SPECS[kind]
	body=Sprite2D.new()
	body.texture=EnchantedArt.part(kind)
	body.scale=Vector2(spec.size)/body.texture.get_size()
	body.position=Vector2(0,-float(spec.size.y)*0.5+18)
	add_child(body)

func floor_rect() -> Rect2:
	var rect: Rect2=SPECS[kind].floor
	return Rect2(position+rect.position,rect.size)

func _draw() -> void:
	var extent: Vector2=SPECS[kind].size
	draw_set_transform(Vector2(3,12),0,Vector2(1,0.34))
	draw_circle(Vector2.ZERO,extent.x*0.42,Color(0.33,0.27,0.24,0.12),true,-1,true)
	draw_set_transform(Vector2.ZERO)
