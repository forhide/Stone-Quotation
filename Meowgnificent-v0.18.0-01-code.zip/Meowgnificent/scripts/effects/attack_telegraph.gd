class_name AttackTelegraph
extends Node2D

# Floor ink, shared by familiars and the examiner. The outline always shows
# the complete footprint; only the ink inside it fills as the attack charges.
# One SDF-shaded quad draws the fill, rim, arrows and countdown together.
# No emitter, viewport texture, per-line draw calls, or mesh allocation.
var enemy: Node2D
var ink_material := ShaderMaterial.new()
var _cached_path := PackedVector2Array()
var _cached_radius := -1.0
var _cached_beam := false
var _quad := Rect2()
var _progress := -1.0
var _striking := false

func _init() -> void:
	ink_material.shader=preload("res://scripts/effects/attack_telegraph.gdshader")
	ink_material.set_shader_parameter("direction_ink",preload("res://art/fx/warning_flourish.png"))
	ink_material.set_shader_parameter("direction_region",Vector4(0.06764374,0.28184893,0.87034949,0.35851184))
	material=ink_material

func _draw() -> void:
	if not is_instance_valid(enemy): return
	var preview: Dictionary = enemy.get_attack_preview()
	if preview.is_empty(): return
	var path: PackedVector2Array = preview.path
	var radius := float(preview.radius)
	var progress := float(preview.progress)
	var striking := bool(preview.striking)
	var beam := bool(preview.get("beam",false))
	if path!=_cached_path or radius!=_cached_radius or beam!=_cached_beam:
		_cache_geometry(path,radius,beam)
	if progress!=_progress:
		ink_material.set_shader_parameter("progress",progress)
		_progress=progress
	if striking!=_striking:
		ink_material.set_shader_parameter("striking",striking)
		_striking=striking
	draw_rect(_quad,Color.WHITE)

func _cache_geometry(path: PackedVector2Array, radius: float, beam: bool) -> void:
	_cached_path=path.duplicate()
	_cached_radius=radius
	_cached_beam=beam
	_quad=Rect2(path[0],Vector2.ZERO)
	for point in path: _quad=_quad.expand(point)
	_quad=_quad.grow(radius+3.0)
	var last := path[-1]
	var third := path[2] if path.size()>2 else last
	var fourth := path[3] if path.size()>3 else last
	ink_material.set_shader_parameter("path_01",Vector4(path[0].x,path[0].y,path[1].x,path[1].y))
	ink_material.set_shader_parameter("path_23",Vector4(third.x,third.y,fourth.x,fourth.y))
	ink_material.set_shader_parameter("path_count",path.size())
	ink_material.set_shader_parameter("radius",radius)
	ink_material.set_shader_parameter("beam",beam)
	ink_material.set_shader_parameter("total_length",path_length(path))
	var first := point_at(path,0.38)
	var second := point_at(path,0.72)
	var dir_first := tangent_at(path,0.38)
	var dir_second := tangent_at(path,0.72)
	ink_material.set_shader_parameter("arrow_centres",Vector4(first.x,first.y,second.x,second.y))
	ink_material.set_shader_parameter("arrow_directions",Vector4(dir_first.x,dir_first.y,dir_second.x,dir_second.y))

static func dash_path(origin: Vector2, direction: Vector2, distance: float, arena: Rect2) -> PackedVector2Array:
	# Enemy movement clamps each axis at the arena edge. Include each wall
	# crossing so a diagonal warning follows the same slide, not a false chord.
	var times: Array[float] = [0.0,distance]
	for axis in range(2):
		if absf(direction[axis])<0.0001: continue
		var edge := arena.end[axis] if direction[axis]>0 else arena.position[axis]
		var crossing := (edge-origin[axis])/direction[axis]
		if crossing>0 and crossing<distance: times.append(crossing)
	times.sort()
	var points := PackedVector2Array()
	for travel in times:
		var point := (origin+direction*travel).clamp(arena.position,arena.end)
		if points.is_empty() or points[-1].distance_squared_to(point)>0.001:
			points.append(point)
	# Geometry2D needs at least two points, also when a foe faces a corner.
	if points.size()==1: points.append(points[0]+direction*0.01)
	return points

static func path_length(path: PackedVector2Array) -> float:
	var total := 0.0
	for i in range(1,path.size()): total+=path[i-1].distance_to(path[i])
	return total

static func path_until(path: PackedVector2Array, fraction: float) -> PackedVector2Array:
	var remaining := path_length(path)*clampf(fraction,0.0,1.0)
	var result := PackedVector2Array([path[0]])
	for i in range(1,path.size()):
		var length := path[i-1].distance_to(path[i])
		if remaining<=length:
			if remaining>0.001: result.append(path[i-1].lerp(path[i],remaining/maxf(length,0.001)))
			break
		result.append(path[i])
		remaining-=length
	return result

static func point_at(path: PackedVector2Array, fraction: float) -> Vector2:
	return path_until(path,fraction)[-1]

static func tangent_at(path: PackedVector2Array, fraction: float) -> Vector2:
	var remaining := path_length(path)*clampf(fraction,0.0,1.0)
	for i in range(1,path.size()):
		var length := path[i-1].distance_to(path[i])
		if remaining<=length: return (path[i]-path[i-1]).normalized()
		remaining-=length
	return (path[-1]-path[-2]).normalized()
