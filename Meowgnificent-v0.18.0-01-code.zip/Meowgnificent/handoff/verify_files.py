from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'handoff/FILES.json').read_text())
errors=[]
for row in manifest['files']:
 p=root/row['path']
 if not p.is_file():errors.append('MISSING '+row['path']+' from '+row['archive'])
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:errors.append('CHANGED '+row['path'])
if errors:print('\n'.join(errors));sys.exit(1)
print('PASS:',len(manifest['files']),'baseline files;',manifest['runtime_input_count'],'runtime inputs match.')
