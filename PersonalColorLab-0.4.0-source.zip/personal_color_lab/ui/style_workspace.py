"""Apply source/built-in/hybrid styles with previews and explicit safe exports."""
import base64
import copy
from io import BytesIO
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import filedialog,ttk

from PIL import Image,ImageDraw

from ..core.constants import DB_FILENAME,RAW_EXTENSIONS,app_data_dir
from ..core.database import LibraryDB
from ..core.style_dna import builtin_styles,dna_from_batch,blend_styles,load_style_file,validate_dna
from ..core.style_render import render_preview,export_jpeg,export_xmp,export_style_json
from .display import ui_pixels
from .theme import COLORS as C


def _job(events,generation,kind,request,cancel_event):
    try:
        if kind=='preview':
            result=render_preview(request['source'],request['dna'],request['strength'],request['composition'],cancel_event,request.get('base'))
        elif kind=='jpeg':
            result=export_jpeg(request['source'],request['destination'],request['dna'],request['strength'],request['composition'],cancel_event,request['fingerprint'])
        else:
            export_xmp(request['destination'],request['dna'],request['effective'],request['strength'])
            result={'path':str(request['destination'])}
        events.put(('result',generation,kind,result))
    except Exception as exc:
        events.put(('error',generation,kind,str(exc)))
    finally:
        events.put(('finished',generation,kind))


class StyleWorkspace(tk.Toplevel):
    def __init__(self,parent,initial_dna=None):
        super().__init__(parent)
        self.i18n=parent.i18n
        self._closed=False;self._busy=False;self._job_kind=None
        self._events=queue.Queue();self._cancel=threading.Event();self._threads=[]
        self._generation=0;self._pending=False;self._debounce=None;self._resize_after=None
        self._composition_code='color_only'
        self.source=None;self.preview=None;self.active_dna=None
        self._styles={};self._choices={};self._photo_names=[]
        self._labels=[];self._buttons=[]
        self.primary=tk.StringVar();self.secondary=tk.StringVar()
        self.strength=tk.DoubleVar(value=70);self.mix=tk.DoubleVar(value=30)
        self.composition=tk.StringVar();self.name=tk.StringVar();self.status=tk.StringVar()
        dp=lambda x:ui_pixels(self,x)
        self.geometry(f'{dp(1160)}x{dp(850)}');self.minsize(dp(1010),dp(760))
        self.configure(background=C['bg']);self.protocol('WM_DELETE_WINDOW',self.close)
        self.transient(parent)
        self._build();self._load_styles(initial_dna);self.translate()
        self.bind('<Configure>',self._fit_layout)
        self._poll_id=self.after(60,self._poll)
        self._raise_after=self.after(60,self.lift)
        self._set_status('style_choose_prompt')

    def _label(self,parent,key,style='Muted.TLabel'):
        label=ttk.Label(parent,style=style,text=self.i18n.t(key))
        self._labels.append((label,key));return label

    def _button(self,parent,key,command,primary=False):
        button=ttk.Button(parent,text=self.i18n.t(key),command=command,style='Primary.TButton' if primary else 'Secondary.TButton')
        self._buttons.append((button,key));return button

    def _build(self):
        dp=lambda x:ui_pixels(self,x)
        self.columnconfigure(0,weight=1);self.rowconfigure(2,weight=1)
        top=ttk.Frame(self,style='Lab.TFrame',padding=(dp(24),dp(18)))
        top.grid(row=0,column=0,sticky='ew');top.columnconfigure(0,weight=1)
        self._label(top,'style_title','Title.TLabel').grid(row=0,column=0,sticky='w')
        self.choose_btn=self._button(top,'style_choose_photo',self.choose_photo,True)
        self.choose_btn.grid(row=0,column=1,sticky='e')
        self.file_label=ttk.Label(top,style='Muted.TLabel')
        self.file_label.grid(row=1,column=0,columnspan=2,sticky='w',pady=(dp(8),0))
        controls=ttk.Frame(self,style='Lab.TFrame',padding=(dp(24),0,dp(24),dp(12)))
        controls.grid(row=1,column=0,sticky='ew')
        for col in range(4):controls.columnconfigure(col,weight=1,uniform='style_controls')
        self._label(controls,'style_primary').grid(row=0,column=0,columnspan=2,sticky='w')
        self._label(controls,'style_strength').grid(row=0,column=2,columnspan=2,sticky='w',padx=dp(16))
        self.primary_combo=ttk.Combobox(controls,textvariable=self.primary,state='readonly',style='Lab.TCombobox')
        self.primary_combo.grid(row=1,column=0,columnspan=2,sticky='ew',pady=(dp(4),dp(9)))
        self.primary_combo.bind('<<ComboboxSelected>>',self._selection_changed)
        strength_frame=ttk.Frame(controls,style='Lab.TFrame')
        strength_frame.grid(row=1,column=2,columnspan=2,sticky='ew',padx=(dp(16),0));strength_frame.columnconfigure(0,weight=1)
        self.strength_slider=ttk.Scale(strength_frame,from_=0,to=100,variable=self.strength,command=self._schedule_preview,style='Lab.Horizontal.TScale')
        self.strength_slider.grid(row=0,column=0,sticky='ew')
        self.strength_label=ttk.Label(strength_frame,style='Muted.TLabel',width=5)
        self.strength_label.grid(row=0,column=1,padx=(dp(8),0))
        self._label(controls,'style_secondary').grid(row=2,column=0,columnspan=2,sticky='w')
        self._label(controls,'style_mix').grid(row=2,column=2,columnspan=2,sticky='w',padx=dp(16))
        self.secondary_combo=ttk.Combobox(controls,textvariable=self.secondary,state='readonly',style='Lab.TCombobox')
        self.secondary_combo.grid(row=3,column=0,columnspan=2,sticky='ew',pady=(dp(4),dp(9)))
        self.secondary_combo.bind('<<ComboboxSelected>>',self._schedule_preview)
        mix_frame=ttk.Frame(controls,style='Lab.TFrame');mix_frame.grid(row=3,column=2,columnspan=2,sticky='ew',padx=(dp(16),0));mix_frame.columnconfigure(0,weight=1)
        self.mix_slider=ttk.Scale(mix_frame,from_=0,to=100,variable=self.mix,command=self._schedule_preview,style='Lab.Horizontal.TScale')
        self.mix_slider.grid(row=0,column=0,sticky='ew')
        self.mix_label=ttk.Label(mix_frame,style='Muted.TLabel',width=5);self.mix_label.grid(row=0,column=1,padx=(dp(8),0))
        self._label(controls,'style_composition').grid(row=4,column=0,sticky='w')
        self.composition_combo=ttk.Combobox(controls,textvariable=self.composition,state='readonly',style='Lab.TCombobox')
        self.composition_combo.grid(row=4,column=1,columnspan=2,sticky='ew',padx=dp(10))
        self.composition_combo.bind('<<ComboboxSelected>>',self._schedule_preview)
        self.import_btn=self._button(controls,'style_import',self.import_style)
        self.import_btn.grid(row=4,column=3,sticky='e')
        previews=tk.Frame(self,background=C['bg'],padx=dp(24))
        previews.grid(row=2,column=0,sticky='nsew');previews.rowconfigure(1,weight=1)
        self.image_labels={}
        for col,key in enumerate(('original','styled')):
            previews.columnconfigure(col,weight=1,uniform='images')
            caption=ttk.Label(previews,style='Heading.TLabel',text=self.i18n.t('style_'+key))
            caption.grid(row=0,column=col,sticky='w',padx=(0,dp(12)),pady=(0,dp(7)))
            self._labels.append((caption,'style_'+key))
            frame=tk.Frame(previews,background=C['inset'])
            frame.grid(row=1,column=col,sticky='nsew',padx=(0,dp(10)) if col==0 else (dp(10),0))
            frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
            label=tk.Label(frame,background=C['inset'],foreground=C['subtle'],font='LabBody')
            label.grid(row=0,column=0,sticky='nsew');self.image_labels[key]=label
        info=ttk.Frame(self,style='Lab.TFrame',padding=(dp(24),dp(10),dp(24),0))
        info.grid(row=3,column=0,sticky='ew');info.columnconfigure(0,weight=1)
        self.info_label=ttk.Label(info,style='Muted.TLabel',wraplength=dp(1080),justify='left')
        self.info_label.grid(row=0,column=0,sticky='ew')
        self.xmp_notice=self._label(info,'style_xmp_notice')
        self.xmp_notice.configure(wraplength=dp(1080))
        self.xmp_notice.grid(row=1,column=0,sticky='ew',pady=(dp(4),0))
        footer=ttk.Frame(self,style='Lab.TFrame',padding=(dp(24),dp(12),dp(24),dp(16)))
        footer.grid(row=4,column=0,sticky='ew');footer.columnconfigure(1,weight=1)
        self._label(footer,'style_name').grid(row=0,column=0,sticky='w',padx=(0,dp(10)))
        self.name_entry=ttk.Entry(footer,textvariable=self.name,style='Lab.TEntry')
        self.name_entry.grid(row=0,column=1,sticky='ew')
        self.save_btn=self._button(footer,'style_save_recipe',self.save_recipe)
        self.save_btn.grid(row=0,column=2,padx=dp(8))
        self.json_btn=self._button(footer,'style_export_recipe',self.export_recipe)
        self.json_btn.grid(row=0,column=3)
        self.status_label=ttk.Label(footer,textvariable=self.status,style='Muted.TLabel',wraplength=dp(530))
        self.status_label.grid(row=1,column=0,columnspan=2,sticky='w',pady=(dp(12),0))
        self.jpeg_btn=self._button(footer,'style_export_jpeg',lambda:self.export('jpeg'),True)
        self.jpeg_btn.grid(row=1,column=2,padx=dp(8),pady=(dp(12),0))
        self.xmp_btn=self._button(footer,'style_export_xmp',lambda:self.export('xmp'))
        self.xmp_btn.grid(row=1,column=3,pady=(dp(12),0))

    def _load_styles(self,initial_dna=None):
        self._styles={f'builtin:{dna["name"]}':dna for dna in builtin_styles()}
        self._source_names={}
        path=app_data_dir()/DB_FILENAME
        if path.exists():
            try:
                with LibraryDB(path) as db:
                    for row in db.list_source_profiles():
                        record=db.get_source_profile(row['id'])
                        try:dna=dna_from_batch(record['payload'],row['name'])
                        except (ValueError,KeyError):continue
                        key=f'analysis:{row["id"]}';self._styles[key]=dna;self._source_names[key]=row['name']
                    for row in db.list_style_presets():
                        record=db.get_style_preset(row['id'])
                        key=f'saved:{row["id"]}';self._styles[key]=record['dna'];self._source_names[key]=row['name']
            except Exception as exc:
                self._set_status('style_error',detail=str(exc))
        if initial_dna:
            self._styles['incoming']=copy.deepcopy(validate_dna(initial_dna))
            self._source_names['incoming']=initial_dna['name']
        self._primary_key='incoming' if initial_dna else next(iter(self._styles))
        self._secondary_key=None

    def translate(self):
        t=self.i18n.t;self.title(t('style_title'))
        for widget,key in self._labels+self._buttons:widget.configure(text=t(key))
        self._choices={};labels=[];seen={}
        for key,dna in self._styles.items():
            name=t('style_preset_'+dna['name']) if key.startswith('builtin:') else self._source_names.get(key,dna['name'])
            label=f'{t("style_category_"+dna["category"])} · {name}'
            seen[label]=seen.get(label,0)+1
            if seen[label]>1:label+=f' ({seen[label]})'
            self._choices[label]=key;labels.append(label)
        self.primary_combo.configure(values=labels);self.secondary_combo.configure(values=[t('style_none'),*labels])
        self.primary.set(next(label for label,key in self._choices.items() if key==self._primary_key))
        self.secondary.set(next((label for label,key in self._choices.items() if key==self._secondary_key),t('style_none')))
        self.composition_combo.configure(values=[t('style_color_only'),t('style_suggestions'),t('style_apply_crop')])
        self.composition.set(t('style_'+self._composition_code))
        self.file_label.configure(text=self.source.name if self.source else t('style_choose_prompt'))
        default=self._selected_dna()['name']
        if not self.name.get() or self.name.get()==getattr(self,'_default_name',''):
            self.name.set(default)
        self._default_name=default
        if not self.preview:
            for label in self.image_labels.values():label.configure(text=t('style_empty'))
        self._controls()
        if self.preview is not None:
            self._schedule_preview()

    def _selection_changed(self,event=None):
        self._primary_key=self._choices.get(self.primary.get(),self._primary_key)
        self._default_name=self._selected_dna()['name']
        self.name.set(self._default_name);self._schedule_preview()

    def _selected_dna(self):
        self._primary_key=self._choices.get(self.primary.get(),self._primary_key)
        self._secondary_key=self._choices.get(self.secondary.get())
        primary=copy.deepcopy(self._styles[self._primary_key])
        if self._primary_key.startswith('builtin:'):primary['name']=self.i18n.t('style_preset_'+primary['name'])
        if self._secondary_key:
            secondary=copy.deepcopy(self._styles[self._secondary_key])
            value=max(0,min(1,self.mix.get()/100))
            return blend_styles([primary,secondary],[1-value,value],self.i18n.t('style_hybrid_name',name=primary['name']))
        return primary

    def _composition(self):
        t=self.i18n.t
        for key in ('color_only','suggestions','apply_crop'):
            if self.composition.get()==t('style_'+key):
                self._composition_code=key
                break
        return self._composition_code

    def choose_photo(self):
        extensions={'.jpg','.jpeg'}|RAW_EXTENSIONS
        patterns=tuple('*'+x for x in sorted(extensions))+tuple('*'+x.upper() for x in sorted(extensions))
        chosen=filedialog.askopenfilename(parent=self,title=self.i18n.t('style_choose_photo'),filetypes=[(self.i18n.t('style_photo_files'),patterns)])
        if not chosen:return
        self.source=Path(chosen).resolve();self.preview=None
        self.file_label.configure(text=self.source.name);self._schedule_preview()

    def _controls(self):
        self.strength_label.configure(text=f'{round(self.strength.get())}%');self.mix_label.configure(text=f'{round(self.mix.get())}%')
        ready=bool(self.preview is not None and not self._busy and self._preview_generation==self._generation)
        for button in (self.jpeg_btn,self.xmp_btn):button.configure(state='normal' if ready else 'disabled')
        exporting=self._busy and self._job_kind!='preview'
        for combo in (self.primary_combo,self.secondary_combo,self.composition_combo):combo.configure(state='disabled' if exporting else 'readonly')
        for widget in (self.choose_btn,self.import_btn,self.save_btn,self.json_btn,self.strength_slider,self.mix_slider):widget.configure(state='disabled' if exporting else 'normal')

    def _set_status(self,key,**kwargs):
        self._status_key=key;self._status_kwargs=kwargs;self.status.set(self.i18n.t(key,**kwargs))

    def _schedule_preview(self,*args):
        if self._closed:return
        self._generation+=1
        if self._debounce:self.after_cancel(self._debounce)
        self._debounce=self.after(180,self.start_preview)
        self._controls()

    def start_preview(self):
        if self._debounce:
            self.after_cancel(self._debounce);self._debounce=None
        if self._closed or self.source is None:return
        if self._busy:self._pending=True;return
        try:dna=self._selected_dna()
        except Exception as exc:self._set_status('style_error',detail=str(exc));return
        request={'source':self.source,'dna':dna,'strength':max(0,min(1,self.strength.get()/100)),
                 'composition':self._composition(),'base':self.preview}
        self.active_dna=dna;self._start_job('preview',request)

    def _start_job(self,kind,request):
        self._busy=True;self._job_kind=kind;self._cancel=threading.Event()
        self._set_status('style_rendering' if kind=='preview' else 'style_exporting')
        self._threads=[t for t in self._threads if t.is_alive()]
        thread=threading.Thread(target=_job,args=(self._events,self._generation,kind,request,self._cancel),daemon=True)
        self._threads.append(thread);thread.start();self._controls()

    def _poll(self):
        if self._closed:return
        while True:
            try:event=self._events.get_nowait()
            except queue.Empty:break
            _,generation,kind,*details=event
            if event[0]=='result' and generation==self._generation:
                if kind=='preview':
                    self.preview=details[0];self._preview_generation=generation;self._show_preview()
                    self._set_status('style_preview_ready')
                else:self._set_status('style_exported',name=Path(details[0]['path']).name)
            elif event[0]=='error' and generation==self._generation:
                if kind=='preview':self.preview=None
                self._set_status('style_error',detail=details[0])
            elif event[0]=='finished':
                self._busy=False;self._job_kind=None;self._controls()
                if self._pending or generation!=self._generation:
                    self._pending=False;self.start_preview()
        self._poll_id=self.after(60,self._poll)

    def _show_preview(self):
        t=self.i18n.t;p=self.preview;dp=lambda x:ui_pixels(self,x)
        for side,array in (('original',p['original']),('styled',p['rendered'])):
            image=Image.fromarray(array)
            if side=='original' and p['composition']=='suggestions' and p['composition_box']:
                ImageDraw.Draw(image).rectangle(p['composition_box'],outline=C['accent'],width=max(2,image.width//240))
            label=self.image_labels[side]
            image.thumbnail((max(dp(160),label.winfo_width()-dp(8)),max(dp(80),label.winfo_height()-dp(8))),Image.Resampling.LANCZOS)
            stream=BytesIO();image.save(stream,format='PNG')
            name=f'pcl-style-{id(self)}-{side}'
            encoded=base64.b64encode(stream.getvalue()).decode('ascii')
            if name in self._photo_names:self.tk.call(name,'configure','-data',encoded)
            else:self.tk.call('image','create','photo',name,'-data',encoded);self._photo_names.append(name)
            self.image_labels[side].configure(image=name,text='')
        dna=self.active_dna
        evidence=t('style_builtin_notice') if dna['kind']=='builtin' else t('style_hybrid_notice') if dna['kind']=='hybrid' else t('style_evidence',count=dna['sample_count'])
        info=[evidence,t('style_lighting',value=t('style_'+p['measurement']['lighting']))]
        if p['clipping_after']-p['clipping_before']>.03:info.append(t('style_clipping_notice'))
        if dna['kind']=='reference' or dna['confidence']<.35:info.append(t('style_reference_notice'))
        if p['composition']!='color_only' and not p['composition_box']:info.append(t('style_no_composition'))
        self.info_label.configure(text=' · '.join(info))

    def _fit_layout(self,event):
        if self._closed or event.widget is not self:return
        self.info_label.configure(wraplength=max(1,event.width-ui_pixels(self,48)))
        self.xmp_notice.configure(wraplength=max(1,event.width-ui_pixels(self,48)))
        if self._resize_after:self.after_cancel(self._resize_after)
        self._resize_after=self.after(120,self._redraw_images)

    def _redraw_images(self):
        self._resize_after=None
        if not self._closed and self.preview is not None:self._show_preview()

    def export(self,kind):
        if self._busy or self.preview is None or self._preview_generation!=self._generation:return
        suffix='.jpg' if kind=='jpeg' else '.xmp'
        chosen=filedialog.asksaveasfilename(parent=self,title=self.i18n.t('style_export_'+kind),defaultextension=suffix,
            initialfile=self.source.stem+('_pcl.jpg' if kind=='jpeg' else '_pcl_preset.xmp'),filetypes=[(self.i18n.t('style_export_'+kind),'*'+suffix)])
        if not chosen:return
        request={'source':self.source,'destination':Path(chosen),'dna':copy.deepcopy(self.active_dna),
                 'strength':self.preview['strength'],'composition':self.preview['composition'],
                 'fingerprint':self.preview['source_fingerprint'],'effective':copy.deepcopy(self.preview['effective'])}
        self._start_job(kind,request)

    def save_recipe(self):
        try:
            dna=self._selected_dna();dna['name']=self.name.get().strip();validate_dna(dna)
            with LibraryDB(app_data_dir()/DB_FILENAME) as db:identifier=db.save_style_preset(dna['name'],dna)
            key=f'saved:{identifier}';self._styles[key]=dna;self._source_names[key]=dna['name']
            self._primary_key=key;self._secondary_key=None;self.translate()
            self._set_status('style_recipe_saved',name=dna['name'])
        except Exception as exc:self._set_status('style_error',detail=str(exc))

    def export_recipe(self):
        chosen=filedialog.asksaveasfilename(parent=self,title=self.i18n.t('style_export_recipe'),defaultextension='.json',initialfile='personal-color-lab-style.json',filetypes=[(self.i18n.t('style_recipe_files'),'*.json')])
        if not chosen:return
        try:
            dna=self._selected_dna();dna['name']=self.name.get().strip();export_style_json(chosen,dna)
            self._set_status('style_exported',name=Path(chosen).name)
        except Exception as exc:self._set_status('style_error',detail=str(exc))

    def import_style(self):
        chosen=filedialog.askopenfilename(parent=self,title=self.i18n.t('style_import'),filetypes=[(self.i18n.t('style_recipe_files'),'*.json')])
        if not chosen:return
        try:
            dna=load_style_file(chosen);key=f'imported:{len(self._styles)}'
            self._styles[key]=dna;self._source_names[key]=dna['name'];self._primary_key=key;self._secondary_key=None
            self.translate();self._schedule_preview()
        except Exception as exc:self._set_status('style_error',detail=str(exc))

    def close(self):
        if self._closed:return
        self._closed=True;self._cancel.set()
        self.after_cancel(self._poll_id)
        self.after_cancel(self._raise_after)
        if self._debounce:self.after_cancel(self._debounce)
        if self._resize_after:self.after_cancel(self._resize_after)
        for name in self._photo_names:self.tk.call('image','delete',name)
        self._photo_names.clear();super().destroy()
        self.preview=None;self.active_dna=None;self._threads.clear();self._labels.clear();self._buttons.clear();self.image_labels.clear()
        for key in ('primary','secondary','strength','mix','composition','name','status','choose_btn','file_label','primary_combo','secondary_combo','strength_slider','strength_label','mix_slider','mix_label','composition_combo','import_btn','info_label','xmp_notice','name_entry','save_btn','json_btn','status_label','jpeg_btn','xmp_btn'):
            setattr(self,key,None)

    def destroy(self):self.close()
