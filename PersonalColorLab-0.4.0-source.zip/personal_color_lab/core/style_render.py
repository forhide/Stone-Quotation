"""Bounded-memory CPU style rendering and source-preserving exports."""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import cv2
import numpy as np
from PIL import Image, ImageCms

from .alignment import _read_rgb
from .constants import RAW_EXTENSIONS, JPEG_EXTENSIONS
from .edit_reverse import file_fingerprint
from .style_dna import BANDS, GRID, ZONES, lighting_key, validate_dna

LUMA = np.array([.2126, .7152, .0722], dtype=np.float32)
HUE_CENTERS = np.array([0, 30, 60, 120, 180, 240, 285, 330], dtype=np.float32)


def read_photo(path, max_dimension=1200):
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.suffix.lower() not in RAW_EXTENSIONS | JPEG_EXTENSIONS:
        raise ValueError('Choose a JPEG or supported RAW photo.')
    pixels, dimensions, warnings = _read_rgb(path, max_dimension)
    if 'icc_conversion_failed' in warnings:
        raise ValueError('The embedded color profile cannot be verified.')
    return pixels, dimensions


def _measure(pixels):
    # Statistics are bounded independently of full-resolution export size.
    h, w = pixels.shape[:2]
    preview = cv2.resize(pixels, (max(1, round(w * min(1, 1000/max(h,w)))), max(1, round(h * min(1, 1000/max(h,w))))), interpolation=cv2.INTER_AREA)
    rgb = preview.astype(np.float32)/255
    luma = rgb @ LUMA
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    zones = {}
    masks = {'shadows': luma < .25, 'midtones': (luma >= .25)&(luma < .75), 'highlights': luma >= .75}
    for zone, mask in masks.items():
        if mask.mean() > .02:
            zones[zone] = np.mean(lab[mask, 1:], axis=0).tolist()
    quantiles = np.quantile(luma, [.05,.25,.5,.75,.95]).tolist()
    return {'quantiles': quantiles, 'saturation': float(hsv[:,:,1].mean()), 'zones': zones,
            'lighting': lighting_key(quantiles[2])}


def _effective(dna, measurement):
    if dna['kind'] == 'hybrid':
        children = [(_effective(c['dna'], measurement), c['weight']) for c in dna['components']]
        effective = copy.deepcopy(children[0][0])
        for key in ('tone_curve','lab_shift'):
            effective[key] = sum(np.array(d[key])*w for d,w in children).tolist()
        for channel in ('red','green','blue'):
            effective['channel_curves'][channel]=sum(np.array(d['channel_curves'][channel])*w for d,w in children).tolist()
        for key in ('exposure_ev','saturation_scale','vibrance','grain_amount'):
            effective[key] = sum(d[key]*w for d,w in children)
        for zone in ZONES:
            effective['zone_shifts'][zone] = sum(np.array(d['zone_shifts'][zone])*w for d,w in children).tolist()
        for band in BANDS:
            effective['hsl'][band] = {k:sum(d['hsl'][band][k]*w for d,w in children) for k in ('hue','saturation','lightness')}
        ratios = [(d['composition']['aspect_ratio'],w) for d,w in children if d['composition']['aspect_ratio']]
        effective['composition']['aspect_ratio'] = max(ratios,key=lambda p:p[1])[0] if ratios else None
        return effective
    effective = copy.deepcopy(dna)
    target = dna['scene_targets'].get(measurement['lighting'], dna['reference_target'])
    if target:
        # Limit distribution matching to protect a new scene from large shifts.
        x = np.array(measurement['quantiles'])
        y = np.array(target['quantiles'])
        unique, indices = np.unique(x, return_index=True)
        if len(unique) < 3:
            centre = float(x[2])
            desired = float(np.clip(y[2], centre-.2, centre+.2))
            curve = np.interp(GRID, [0, max(.001,min(.999,centre)),1], [0,desired,1])
        else:
            desired = np.clip(y, x-.2, x+.2)
            desired = np.clip(np.maximum.accumulate(desired), 0, 1)
            curve = np.interp(GRID, [0,*unique.tolist(),1], [0,*desired[indices].tolist(),1])
        effective['tone_curve'] = np.maximum.accumulate(np.clip(curve,0,1)).tolist()
        effective['saturation_scale'] = float(np.clip(target['saturation']/max(.08,measurement['saturation']),.65,1.4))
        for zone in ZONES:
            if zone in target['zones'] and zone in measurement['zones']:
                effective['zone_shifts'][zone] = np.clip((np.array(target['zones'][zone])-measurement['zones'][zone])*.5,-6,6).tolist()
    return effective


def prepare_style(pixels, dna):
    validate_dna(dna)
    measurement = _measure(pixels)
    return _effective(dna, measurement), measurement


def composition_box(width, height, aspect_ratio):
    if aspect_ratio is None:
        return None
    if width/height > aspect_ratio:
        new_width, new_height = round(height*aspect_ratio), height
    else:
        new_width, new_height = width, round(width/aspect_ratio)
    left, top = (width-new_width)//2, (height-new_height)//2
    return [left,top,left+new_width,top+new_height]


def _tile(pixels, effective, strength, row_offset):
    original = pixels.astype(np.float32)/255
    rgb = original.copy()
    if effective['exposure_ev']:
        linear = np.where(rgb <= .04045, rgb/12.92, ((rgb+.055)/1.055)**2.4)
        linear *= 2**effective['exposure_ev']
        rgb = np.where(linear <= .0031308, linear*12.92, 1.055*np.maximum(linear,0)**(1/2.4)-.055)
    luma = rgb @ LUMA
    fitted = np.interp(np.clip(luma,0,1), GRID, effective['tone_curve']).astype(np.float32)
    ratio = np.divide(fitted, luma, out=np.ones_like(fitted), where=luma>.0001)
    rgb = np.clip(rgb*ratio[:,:,None],0,1)
    # Lifted black curves remain meaningful without dividing zero-valued pixels.
    rgb += np.maximum(fitted-luma*ratio,0)[:,:,None]
    rgb = np.clip(rgb,0,1)
    for index,channel in enumerate(('red','green','blue')):
        rgb[:,:,index]=np.interp(rgb[:,:,index],GRID,effective['channel_curves'][channel])
    hsv = cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV)
    sat = hsv[:,:,1].copy()
    hsv[:,:,1] *= effective['saturation_scale']*(1+effective['vibrance']*(1-sat))
    hue, chromatic = hsv[:,:,0].copy(), sat>.03
    for band, centre in zip(BANDS,HUE_CENTERS):
        values = effective['hsl'][band]
        if not any(values.values()):
            continue
        distance = np.abs((hue-centre+180)%360-180)
        weight = np.maximum(0,1-distance/40)*chromatic
        hsv[:,:,0] += weight*values['hue']
        hsv[:,:,1] *= 1+weight*values['saturation']
        hsv[:,:,2] += weight*values['lightness']
    hsv[:,:,0] %= 360
    hsv[:,:,1:] = np.clip(hsv[:,:,1:],0,1)
    rgb = cv2.cvtColor(hsv,cv2.COLOR_HSV2RGB)
    lab = cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB)
    luma = np.clip(rgb @ LUMA,0,1)
    zone_weights = {'shadows':np.clip((.5-luma)*2,0,1), 'highlights':np.clip((luma-.5)*2,0,1)}
    zone_weights['midtones'] = 1-zone_weights['shadows']-zone_weights['highlights']
    color_shift = np.zeros_like(lab[:,:,1:]) + effective['lab_shift']
    for zone in ZONES:
        color_shift += zone_weights[zone][:,:,None]*np.array(effective['zone_shifts'][zone],dtype=np.float32)
    lab[:,:,1:] += color_shift*np.sqrt(np.maximum(0,np.sin(np.pi*luma)))[:,:,None]
    rgb = cv2.cvtColor(lab,cv2.COLOR_LAB2RGB)
    if effective['grain_amount']:
        yy,xx = np.indices(rgb.shape[:2],dtype=np.uint64)
        global_y=yy+row_offset
        noise = (((xx*374761393+global_y*668265263+1274126177)^((xx+global_y)*2246822519)) & 65535).astype(np.float32)/65535-.5
        rgb += noise[:,:,None]*effective['grain_amount']*3
    rgb = original+(np.clip(rgb,0,1)-original)*strength
    return np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)


def apply_pixels(pixels, effective, strength=1., composition='color_only', cancel_event=None):
    validate_dna(effective)
    if not isinstance(strength,(int,float)) or isinstance(strength,bool) or not math.isfinite(strength) or not 0<=strength<=1:
        raise ValueError('Style strength must be between zero and one.')
    if composition not in {'color_only','suggestions','apply_crop'}:
        raise ValueError('Invalid composition choice.')
    if pixels.dtype!=np.uint8 or pixels.ndim!=3 or pixels.shape[2]!=3:
        raise ValueError('Invalid source RGB image.')
    neutral=(np.array_equal(effective['tone_curve'],GRID) and all(np.array_equal(c,GRID) for c in effective['channel_curves'].values())
        and effective['exposure_ev']==0 and effective['saturation_scale']==1 and effective['vibrance']==0
        and effective['grain_amount']==0 and not any(effective['lab_shift'])
        and not any(any(v) for v in effective['zone_shifts'].values())
        and not any(any(v.values()) for v in effective['hsl'].values()))
    output=pixels.copy() if strength==0 or neutral else np.empty_like(pixels)
    if strength and not neutral:
        rows=max(1,160_000//pixels.shape[1])
        for top in range(0,pixels.shape[0],rows):
            if cancel_event is not None and cancel_event.is_set():
                raise ValueError('Style operation cancelled.')
            output[top:top+rows]=_tile(pixels[top:top+rows],effective,strength,top)
    box=composition_box(pixels.shape[1],pixels.shape[0],effective['composition']['aspect_ratio'])
    if composition=='apply_crop' and box:
        output=output[box[1]:box[3],box[0]:box[2]].copy()
    return output,box


def render_preview(path,dna,strength=1.,composition='color_only',cancel_event=None,base=None):
    path=Path(path).expanduser().resolve(strict=True)
    before=file_fingerprint(path)
    if base and base.get('source_fingerprint')==before:
        original,dimensions=base['original'],base['original_dimensions']
        measurement=base['measurement']
        effective=_effective(validate_dna(dna),measurement)
    else:
        original,dimensions=read_photo(path)
        effective,measurement=prepare_style(original,dna)
    rendered,box=apply_pixels(original,effective,strength,composition,cancel_event)
    if file_fingerprint(path)!=before:
        raise ValueError('Input changed during style preview.')
    def clipping(image):
        return float(np.mean(np.any((image<=1)|(image>=254),axis=2)))
    return {'original':original,'rendered':rendered,'effective':effective,'measurement':measurement,
            'source_fingerprint':before,'original_dimensions':list(dimensions),'composition_box':box,
            'clipping_before':clipping(original),'clipping_after':clipping(rendered),
            'style_name':dna['name'],'strength':strength,'composition':composition}


def _write_new(path,writer):
    path=Path(path).expanduser().resolve()
    created=False
    try:
        with path.open('xb') as stream:
            created=True
            writer(stream)
    except Exception:
        if created:
            path.unlink(missing_ok=True)
        raise
    return path


def export_jpeg(source,destination,dna,strength=1.,composition='color_only',cancel_event=None,expected_fingerprint=None):
    source=Path(source).expanduser().resolve(strict=True)
    destination=Path(destination).expanduser().resolve()
    if destination==source or destination.suffix.lower() not in JPEG_EXTENSIONS:
        raise ValueError('Export must be a new JPEG copy.')
    before=file_fingerprint(source)
    if expected_fingerprint and before!=expected_fingerprint:
        raise ValueError('Input changed since preview; preview again.')
    preview,_=read_photo(source)
    effective,_=prepare_style(preview,dna)
    full,dimensions=read_photo(source,max_dimension=1_000_000)
    rendered,box=apply_pixels(full,effective,strength,composition,cancel_event)
    if file_fingerprint(source)!=before:
        raise ValueError('Input changed during export.')
    if cancel_event is not None and cancel_event.is_set():
        raise ValueError('Style operation cancelled.')
    profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    _write_new(destination,lambda stream:Image.fromarray(rendered).save(stream,format='JPEG',quality=95,subsampling=0,icc_profile=profile))
    return {'path':str(destination),'dimensions':[rendered.shape[1],rendered.shape[0]],'source_unchanged':True,'gps_exported':False,'composition_applied':bool(composition=='apply_crop' and box)}


def export_style_json(destination,dna):
    validate_dna(dna)
    encoded=json.dumps(dna,ensure_ascii=False,allow_nan=False,indent=2).encode('utf-8')
    return _write_new(destination,lambda stream:stream.write(encoded))


def export_xmp(destination,dna,effective,strength=1.):
    """Export a Lightroom-importable preset for the supported global subset.

    This is an approximate portable recipe, not a reproduction of our Lab/HSV
    renderer. Composition and unavailable local masks are never exported.
    """
    validate_dna(dna)
    if not isinstance(strength,(int,float)) or isinstance(strength,bool) or not 0<=strength<=1:
        raise ValueError('Invalid export strength.')
    import uuid
    rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#';crs='http://ns.adobe.com/camera-raw-settings/1.0/'
    ET.register_namespace('rdf',rdf);ET.register_namespace('crs',crs)
    root=ET.Element('{adobe:ns:meta/}xmpmeta')
    description=ET.SubElement(ET.SubElement(root,'{'+rdf+'}RDF'),'{'+rdf+'}Description')
    attrs={'PresetType':'Normal','UUID':uuid.uuid4().hex.upper(),'SupportsColor':'True','SupportsMonochrome':'True','SupportsHighDynamicRange':'False','SupportsNormalDynamicRange':'True','SupportsSceneReferred':'True','SupportsOutputReferred':'True','Version':'15.0','ProcessVersion':'11.0','HasSettings':'True','Exposure2012':f"{effective['exposure_ev']*strength:.4f}",'Saturation':str(round((effective['saturation_scale']-1)*100*strength)),'Vibrance':str(round(effective['vibrance']*100*strength)),'ToneCurveName2012':'Custom'}
    for band in BANDS:
        values=effective['hsl'][band]
        attrs['HueAdjustment'+band.title()]=str(round(np.clip(values['hue']/0.3*strength,-100,100)))
        attrs['SaturationAdjustment'+band.title()]=str(round(values['saturation']*100*strength))
        attrs['LuminanceAdjustment'+band.title()]=str(round(np.clip(values['lightness']*500*strength,-100,100)))
    for zone,label in (('shadows','Shadow'),('midtones','Midtone'),('highlights','Highlight')):
        a,b=np.array(effective['zone_shifts'][zone])+effective['lab_shift']
        color=np.array([[[60,a*3,b*3]]],dtype=np.float32)
        hue=float(cv2.cvtColor(cv2.cvtColor(color,cv2.COLOR_LAB2RGB),cv2.COLOR_RGB2HSV)[0,0,0])
        attrs['ColorGrade'+label+'Hue']=f'{hue:.3f}'
        attrs['ColorGrade'+label+'Sat']=str(round(min(100,math.hypot(a,b)*2*strength)))
    attrs['ColorGradeBlending']='50'
    attrs['GrainAmount']=str(round(min(100,effective['grain_amount']/.0002*strength)))
    attrs['ConvertToGrayscale']='True' if effective['saturation_scale']==0 and strength==1 else 'False'
    if dna['kind']=='recorded_xmp':
        # Absolute camera WB belongs to the supplied recipe, not a recovered
        # offset from the new image; interpolate from As Shot only at full use.
        for key in ('Temperature','Tint'):
            if key in dna['recorded_parameters'] and strength==1:
                attrs[key]=str(round(dna['recorded_parameters'][key]))
                attrs['WhiteBalance']='Custom'
    for key,value in attrs.items():description.set('{'+crs+'}'+key,value)
    name=ET.SubElement(description,'{'+crs+'}Name')
    alt=ET.SubElement(name,'{'+rdf+'}Alt')
    ET.SubElement(alt,'{'+rdf+'}li',{'{http://www.w3.org/XML/1998/namespace}lang':'x-default'}).text=dna['name']
    seq=ET.SubElement(ET.SubElement(description,'{'+crs+'}ToneCurvePV2012'),'{'+rdf+'}Seq')
    curve=GRID+(np.array(effective['tone_curve'])-GRID)*strength
    for x,y in zip(GRID,curve):ET.SubElement(seq,'{'+rdf+'}li').text=f'{round(x*255)}, {round(y*255)}'
    for channel in ('red','green','blue'):
        curve=GRID+(np.array(effective['channel_curves'][channel])-GRID)*strength
        seq=ET.SubElement(ET.SubElement(description,'{'+crs+'}ToneCurvePV2012'+channel.title()),'{'+rdf+'}Seq')
        for x,y in zip(GRID,curve):ET.SubElement(seq,'{'+rdf+'}li').text=f'{round(x*255)}, {round(y*255)}'
    encoded=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    return _write_new(destination,lambda stream:stream.write(encoded))
