"""Build self-contained Windows setup.exe and macOS .pkg installers.

Prepare verified resources with download_runtimes.py/download_wheels.py first.
No target runtime executes during cross builds; native smoke tests are separate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import stat
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

from download_runtimes import RUNTIMES, sha256
from download_wheels import TARGETS, compatible_tag, read_requirements
from flat_pkg import build_flat_package

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from personal_color_lab.core.constants import APP_VERSION

APP_NAME = 'Personal Color Lab'
BUNDLE_ID = 'org.personalcolorlab.desktop'


def copy_runtime(source: Path, destination: Path) -> None:
    """Omit developer/test/debug files and build-time network package installers."""
    def ignored(directory, names):
        return [name for name in names if name in {'__pycache__', 'test', 'tests', 'ensurepip', 'pip', 'pip3', 'pip3.13', 'include', 'Scripts'}
                or name.startswith(('pip-', '_test', 'test_')) or name.endswith(('.pdb', '.lib', '.a', '.pyc'))]
    shutil.copytree(source, destination, symlinks=True, ignore=ignored)


def install_wheel(wheel: Path, site_packages: Path) -> None:
    """Extract binary wheels without executing pip or a foreign Python runtime."""
    with zipfile.ZipFile(wheel) as archive:
        for info in archive.infolist():
            path = Path(info.filename)
            if path.is_absolute() or '..' in path.parts or stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError(f'Unsafe wheel entry: {info.filename}')
            if info.is_dir():
                continue
            parts = path.parts
            if parts[0].endswith('.data'):
                if len(parts) < 3 or parts[1] not in ('purelib', 'platlib'):
                    raise ValueError(f'Unsupported wheel data scheme: {info.filename}')
                path = Path(*parts[2:])
            output = site_packages / path
            output.parent.mkdir(parents=True, exist_ok=True)
            if output.exists() and output.read_bytes() != archive.read(info):
                raise ValueError(f'Conflicting installed wheel file: {path}')
            output.write_bytes(archive.read(info))
            output.chmod(0o755 if info.external_attr >> 16 & 0o111 else 0o644)


def stage(target: str, resources: Path, work: Path) -> Path:
    runtime = resources / 'runtimes' / target
    origin = json.loads((runtime / 'runtime-origin.json').read_text(encoding='utf-8'))
    if origin['sha256'] != RUNTIMES[target][1] or origin['target'] != target:
        raise ValueError('Unexpected runtime identity')
    manifest = json.loads((resources / 'wheels/wheel-lock.json').read_text(encoding='utf-8'))
    if manifest['requirements_sha256'] != sha256(ROOT / 'requirements.lock'):
        raise ValueError('Wheel manifest does not match current requirements.lock')
    wheels = manifest['targets'][target]['wheels']
    pins = read_requirements(ROOT / 'requirements.lock')
    if {entry['project']: entry['version'] for entry in wheels} != pins:
        raise ValueError('Wrong wheel versions')
    payload = work / 'payload'
    payload.mkdir(parents=True)
    if target.startswith('macos'):
        app = payload / f'{APP_NAME}.app'
        contents = app / 'Contents'
        app_resources = contents / 'Resources'
        private_runtime = app_resources / 'runtime'
        site_packages = private_runtime / 'lib/python3.13/site-packages'
        (contents / 'MacOS').mkdir(parents=True)
        info = {'CFBundleName': APP_NAME, 'CFBundleDisplayName': APP_NAME,
                'CFBundleIdentifier': BUNDLE_ID, 'CFBundlePackageType': 'APPL',
                'CFBundleExecutable': APP_NAME, 'CFBundleVersion': APP_VERSION,
                'CFBundleIconFile': 'PersonalColorLab.icns',
                'CFBundleShortVersionString': APP_VERSION,
                'LSMinimumSystemVersion': TARGETS[target]['minimum_macos'],
                'NSHighResolutionCapable': True, 'CFBundleLocalizations': ['en', 'ko']}
        (contents / 'Info.plist').write_bytes(plistlib.dumps(info))
        app_resources.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / 'personal_color_lab/assets/app-icon.icns', app_resources / 'PersonalColorLab.icns')
        launcher = contents / 'MacOS' / APP_NAME
        launcher.write_text('#!/bin/sh\nset -eu\nCONTENTS_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)\nexec "$CONTENTS_DIR/Resources/runtime/bin/python3.13" -I -B "$CONTENTS_DIR/Resources/launch.py" "$@"\n', encoding='utf-8')
        launcher.chmod(0o755)
    else:
        app_resources = payload
        private_runtime = payload / 'runtime'
        site_packages = private_runtime / 'Lib/site-packages'
    copy_runtime(runtime, private_runtime)
    site_packages.mkdir(parents=True, exist_ok=True)
    for entry in wheels:
        wheel = resources / 'wheels' / target / entry['filename']
        if sha256(wheel) != entry['sha256'] or wheel.stat().st_size != entry['size']:
            raise ValueError(f"Wheel integrity failure: {wheel.name}")
        if not any(compatible_tag(tag, target) for tag in entry['tags']):
            raise ValueError(f"Wrong wheel architecture: {wheel.name}")
        install_wheel(wheel, site_packages)
    shutil.copytree(ROOT / 'personal_color_lab', site_packages / 'personal_color_lab',
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    (app_resources / 'launch.py').write_text('from personal_color_lab.main import main\nraise SystemExit(main())\n', encoding='utf-8')
    shutil.copytree(resources / 'licenses' / target, app_resources / 'licenses/python-native')
    (app_resources / 'THIRD_PARTY_NOTICES.txt').write_text(
        'This application includes CPython (python-build-standalone), Tcl/Tk, Pillow, NumPy, OpenCV and rawpy/LibRaw.\n'
        'Full native runtime notices: licenses/python-native/licenses.\n'
        'Python license: runtime/LICENSE.txt (Windows) or runtime/lib/python3.13/LICENSE.txt (macOS).\n'
        'Wheel licenses and bundled native library notices remain in runtime site-packages *.dist-info and cv2.\n'
        'rawpy and LibRaw notices: rawpy-*.dist-info/licenses/LICENSE and LICENSE.LibRaw in site-packages.\n'
        'The runtime and dependencies are private to this app. No Python installation or network download is needed.\n', encoding='utf-8')
    (app_resources / 'INSTALLATION.txt').write_text(
        f'{APP_NAME} {APP_VERSION}\nRAW + JPG, RAW + XMP, and reference JPG analysis, adaptive style previews, mixing, and new JPG/XMP/JSON exports. English default; Korean available in the app.\n'
        'Original photos are never modified. Inferred Lightroom values are approximate.\n'
        'User library/settings: ~/.personal_color_lab or PERSONAL_COLOR_LAB_DATA_DIR.\n'
        'Close the app before updating. Uninstall preserves this user data.\n', encoding='utf-8')
    (app_resources / 'build-manifest.json').write_text(json.dumps({
        'app_version': APP_VERSION, 'target': target, 'runtime': origin,
        'wheels': wheels, 'signed': False, 'native_validation': 'pending',
    }, indent=2) + '\n', encoding='utf-8')
    # macOS installs payloads as root: source files with local mode 0600 must
    # become readable by the ordinary desktop user. Preserve executable bits.
    for path in [payload, *payload.rglob('*')]:
        if not path.is_symlink():
            path.chmod(0o755 if path.is_dir() or path.stat().st_mode & 0o111 else 0o644)
    return payload


def nsis_compile(command: str, script: Path, definitions: dict[str, str]) -> None:
    # NSIS uses /D on Windows and -D on POSIX; arguments are passed directly.
    prefix = '/D' if os.name == 'nt' else '-D'
    subprocess.run([command, *[f'{prefix}{key}={value}' for key, value in definitions.items()], str(script)], check=True)


def build_windows(payload: Path, destination: Path, work: Path, makensis: str) -> None:
    icon = str(ROOT / 'personal_color_lab/assets/app-icon.ico')
    nsis_compile(makensis, ROOT / 'packaging/windows/launcher.nsi', {'OUTPUT': str(payload / f'{APP_NAME}.exe'), 'ICON': icon})
    deletes = work / 'uninstall-files.nsh'
    files = sorted(path for path in payload.rglob('*') if path.is_file())
    directories = sorted((path for path in payload.rglob('*') if path.is_dir()), key=lambda p: len(p.parts), reverse=True)
    def quote(path):
        relative = str(path.relative_to(payload)).replace('/', '\\')
        if '"' in relative or '$' in relative or '\n' in relative:
            raise ValueError('Unsafe NSIS payload filename')
        return '"$INSTDIR\\' + relative + '"'
    deletes.write_text('\n'.join([f'Delete {quote(path)}' for path in files] + [f'RMDir {quote(path)}' for path in directories]) + '\n', encoding='utf-8')
    nsis_compile(makensis, ROOT / 'packaging/windows/setup.nsi', {
        'VERSION': APP_VERSION, 'OUTPUT': str(destination), 'PAYLOAD': str(payload), 'DELETE_MANIFEST': str(deletes), 'ICON': icon})


def distribution(target: str, destination: Path, identifier: str) -> None:
    settings = TARGETS[target]
    doc = ET.Element('installer-gui-script', {'minSpecVersion': '2'})
    ET.SubElement(doc, 'title').text = APP_NAME
    ET.SubElement(doc, 'options', {'customize': 'never', 'require-scripts': 'false',
                                 'hostArchitectures': settings['architecture']})
    ET.SubElement(doc, 'domains', {'enable_anywhere': 'false', 'enable_currentUserHome': 'false', 'enable_localSystem': 'true'})
    volume = ET.SubElement(doc, 'volume-check')
    allowed = ET.SubElement(volume, 'allowed-os-versions')
    ET.SubElement(allowed, 'os-version', {'min': settings['minimum_macos']})
    outline = ET.SubElement(doc, 'choices-outline')
    ET.SubElement(outline, 'line', {'choice': 'default'})
    choice = ET.SubElement(doc, 'choice', {'id': 'default', 'visible': 'false', 'title': APP_NAME})
    ET.SubElement(choice, 'pkg-ref', {'id': identifier})
    # The fragment denotes a component embedded in this product archive.
    # A bare relative URL makes Apple Installer look for an external package.
    ET.SubElement(doc, 'pkg-ref', {'id': identifier, 'version': APP_VERSION, 'onConclusion': 'none'}).text = '#application.pkg'
    ET.ElementTree(doc).write(destination, encoding='utf-8', xml_declaration=True)


def build_mac(target: str, payload: Path, destination: Path, work: Path, mkbom: str | None) -> None:
    identifier = BUNDLE_ID + '.' + target
    dist = work / 'Distribution'
    distribution(target, dist, identifier)
    if sys.platform == 'darwin':
        components = work / 'components.plist'
        subprocess.run(['pkgbuild', '--analyze', '--root', str(payload), str(components)], check=True)
        data = plistlib.loads(components.read_bytes())
        for bundle in data:
            bundle['BundleIsRelocatable'] = False
            bundle['BundleOverwriteAction'] = 'upgrade'
        components.write_bytes(plistlib.dumps(data))
        subprocess.run(['pkgbuild', '--root', str(payload), '--install-location', '/Applications',
                        '--component-plist', str(components), '--identifier', identifier,
                        '--version', APP_VERSION, str(work / 'application.pkg')], check=True)
        subprocess.run(['productbuild', '--distribution', str(dist), '--package-path', str(work), str(destination)], check=True)
    else:
        if not mkbom:
            raise ValueError('Cross-building macOS requires mkbom (bomutils); native macOS uses pkgbuild.')
        build_flat_package(payload, dist, destination, work / 'flat', APP_VERSION, identifier, mkbom)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', choices=list(TARGETS), required=True)
    parser.add_argument('--resources-dir', type=Path, default=ROOT / 'build/installer-resources')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'dist/installers')
    parser.add_argument('--makensis', default=shutil.which('makensis'))
    parser.add_argument('--mkbom', default=shutil.which('mkbom'))
    args = parser.parse_args()
    work = ROOT / 'build/installers' / args.target
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output_dir = args.output_dir.resolve()
    payload = stage(args.target, args.resources_dir.resolve(), work)
    suffix = '-setup.exe' if args.target.startswith('windows') else '.pkg'
    artifact = output_dir / f'PersonalColorLab-{APP_VERSION}-{args.target}{suffix}'
    if args.target.startswith('windows'):
        if not args.makensis:
            parser.error('NSIS 3.11+ makensis is required for Windows installers.')
        build_windows(payload, artifact, work, args.makensis)
    else:
        build_mac(args.target, payload, artifact, work, args.mkbom)
    artifact.with_suffix(artifact.suffix + '.sha256').write_text(f'{sha256(artifact)}  {artifact.name}\n', encoding='utf-8')
    print(f'Created {artifact} ({artifact.stat().st_size:,} bytes); native validation is a separate step.')


if __name__ == '__main__':
    main()
