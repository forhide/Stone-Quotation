# Codex Handoff - Personal Color Lab V0.4.0

Personal Color Lab is a PC desktop photo-style application for Windows and macOS. Mobile is outside scope. Runtime processing is local, CPU-supported, network-free, original-preserving and GPS-free. Default UI is English with selectable Korean.

Choose folder → select RAW/JPG, RAW/XMP or JPG references → review and analyze → save evidence → Apply style → choose a new JPG/RAW → adjust strength or mix → preview → export a new JPG, global XMP preset or portable style JSON. Direct JPG-pair analysis also opens Apply style. The 12 builtins contain derived parameters only.

DNA adapters retain the distinction between observed transformations, recorded controls and final visual appearance. Reference transfer adapts tone and saturation to the current image and may use supported low/mid/high-key groups; these are measured luminance buckets, not face/subject/scene AI. Color transfer from image pairs uses residual color after fitted tone correction to avoid double application. Composition is an optional centered aspect-ratio guide/crop on the copy, not perspective or subject-aware composition.

XMP exports are Lightroom-importable presets covering supported global tone/RGB curves, exposure, saturation, HSL and grading. Rendering is approximate and differs from Adobe; masks, unavailable profiles and unsupported controls are not reconstructed. Imported XMP input values remain evidence, not proof of RAW association.

SQLite schema 3 adds bounded analysis_cache and style_presets to schema-2 source_profiles. Migration preserves old rows. Content cache keys include mode, algorithm, schema and input SHA-256; corrupt records are evicted. Current app/algorithm 0.4.0, analysis/profile/DNA payload schema 1. Old 0.3.0 source snapshots remain usable as historical evidence. New libraries cannot be opened by older schema-2 apps; back up the data directory before downgrading.

Tk workers receive plain paths/data/queues only. Preview generations prevent stale export, decoded source pixels are reused for adjustments, tiled full-resolution rendering bounds temporary calculations, and originals are checked before/after reading. Exports create exclusive new files; JPEGs strip EXIF/GPS and include sRGB ICC. Similar JPEGs are flagged without automatic exclusion.

Build/validation: see INSTALLERS.md and VALIDATION.md. Windows setup and Apple Silicon/Intel packages bundle private Python and four locked native wheels. Distribution must keep #application.pkg and pass required-data/reference/identity/BOM/byte checks. Native Windows/Mac hardware, Retina and Apple signing/notarization remain unverified. No credentials are present or required for runtime.

## Development environment

Read AGENTS.md, README.md, DEVELOPMENT_CONTEXT.md, INSTALLERS.md and VALIDATION.md. Work in the extracted /workspace/Personal-Color-Lab source folder. Preserve the unrelated Stone-Quotation main; separate personal-color-lab-downloads-v* branches are authorized for download delivery. No new worktree is needed. Use .venv-desktop, Python 3.13.5/Tk 8.6.16 and locked dependencies. Native installers use verified private CPython 3.13.16 and CPU-matching wheels. Start Tk with run_app.py on a native display; use tools/run_gui_tests.py and local Xvfb for headless tests. Do not invent web previews or request app credentials.

The user reported missing Mac installation data on M1 after Gatekeeper override. Keep the embedded #application.pkg fix and tools/package_references.py checks. Successful native Apple Installer execution is still unverified. Removed repeated privacy labels should not return. Keep useful evidence/limitations and localized strings.

Next: evaluate real camera RAWs, varied references/XMP and confidence; verify actual Lightroom preset import, native OS install/display and Retina; sign/notarize. Extend scene/local-region models only locally with CPU fallback. Never claim exact recovered sliders or Adobe rendering.
