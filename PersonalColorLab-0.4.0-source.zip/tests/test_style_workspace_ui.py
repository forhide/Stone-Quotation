"""Exercise style application controls, persistence and safe exports on real Tk."""
import hashlib
import threading
import time
import numpy as np
from PIL import Image
import pytest
from test_source_workflow_ui import desktop, _pump, _inputs, _open, _analyze, pytestmark
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.constants import DB_FILENAME, app_data_dir
from personal_color_lab.core.style_dna import load_style_file


def ready(window):
    return window.preview is not None and not window._busy and window._debounce is None and window._preview_generation==window._generation


@pytest.mark.parametrize('language',['en','ko'])
def test_style_preview_strength_hybrid_exports_and_recipe_reopening(desktop, monkeypatch, language):
    app,root=desktop;app.lang.set(language);app.change_language()
    photo=root/'photo.jpg';Image.fromarray(np.random.default_rng(2).integers(20,230,(180,270,3),dtype='uint8')).save(photo)
    before=hashlib.sha256(photo.read_bytes()).hexdigest()
    window=app.open_style_workspace()
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',lambda **kw:str(photo))
    window.choose_btn.invoke();_pump(app,lambda:ready(window))
    assert len(window._styles)==12
    assert str(window.jpeg_btn.cget('state'))=='normal'
    window.strength.set(0);window._schedule_preview();_pump(app,lambda:ready(window))
    assert np.array_equal(window.preview['original'],window.preview['rendered'])
    window.strength.set(70);window.secondary.set(list(window._choices)[2]);window._schedule_preview();_pump(app,lambda:ready(window))
    assert window.active_dna['kind']=='hybrid'
    outputs=iter([root/'edited.jpg',root/'recipe.xmp',root/'recipe.json'])
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.asksaveasfilename',lambda **kw:str(next(outputs)))
    window.jpeg_btn.invoke();_pump(app,lambda:not window._busy)
    window.xmp_btn.invoke();_pump(app,lambda:not window._busy)
    window.name.set('My mixed style');window.json_btn.invoke()
    assert Image.open(root/'edited.jpg').size==(270,180)
    assert (root/'recipe.xmp').is_file()
    assert load_style_file(root/'recipe.json')['kind']=='hybrid'
    window.save_btn.invoke();_pump(app,lambda:ready(window))
    with LibraryDB(app_data_dir()/DB_FILENAME) as db:assert db.list_style_presets()[0]['name']=='My mixed style'
    window.close();reopened=app.open_style_workspace()
    assert 'My mixed style' in reopened._source_names.values()
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',lambda **kw:str(root/'recipe.json'))
    reopened.import_btn.invoke();assert reopened._primary_key.startswith('imported:')
    assert hashlib.sha256(photo.read_bytes()).hexdigest()==before


@pytest.mark.parametrize('mode',['raw_jpg','raw_xmp','reference_jpg'])
def test_each_analysis_source_opens_style_workspace(desktop,mode):
    app,root=desktop;folder=_inputs(root/mode,mode);workflow=_open(app,folder,mode)
    _analyze(app,workflow);workflow.apply_btn.invoke()
    window=app._style_workspaces[-1]
    assert window._primary_key=='incoming'
    assert window._styles['incoming']['sample_count']>0
    window.source=next(folder.glob('*.jpg')) if mode=='reference_jpg' else next(folder.glob('*.dng'))
    window._schedule_preview();_pump(app,lambda:ready(window))
    assert window.preview['source_fingerprint']


@pytest.mark.parametrize('desktop',[1,1.5,2],indirect=True)
@pytest.mark.parametrize('language',['en','ko'])
def test_style_controls_remain_visible_at_minimum_size(desktop,language):
    app,_=desktop;app.lang.set(language);app.change_language();window=app.open_style_workspace()
    width,height=window.minsize();window.geometry(f'{width}x{height}');app.update()
    for control in (window.choose_btn,window.primary_combo,window.composition_combo,window.name_entry,window.jpeg_btn,window.xmp_btn):
        assert control.winfo_x()>=0
        assert control.winfo_rootx()+control.winfo_width()<=window.winfo_rootx()+window.winfo_width()
        assert control.winfo_rooty()+control.winfo_height()<=window.winfo_rooty()+window.winfo_height()


def test_close_during_style_worker_has_no_tk_callbacks(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(160,120),'orange').save(photo)
    from personal_color_lab.ui import style_workspace as module
    render=module.render_preview;started=threading.Event();release=threading.Event()
    def held(*args,**kwargs):
        started.set();assert release.wait(5);return render(*args,**kwargs)
    monkeypatch.setattr(module,'render_preview',held)
    window=app.open_style_workspace();window.source=photo;window.start_preview()
    _pump(app,started.is_set);threads=list(window._threads);window.close();release.set()
    for thread in threads:thread.join(5);assert not thread.is_alive()
    app.update();assert not app._closed
