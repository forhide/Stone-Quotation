"""Black-box desktop release test using X11 events, screenshots, and OCR."""
import argparse, ctypes, json, os, pathlib, re, subprocess, time
from PIL import ImageGrab, Image
p=argparse.ArgumentParser();p.add_argument('--platform',choices=['linux','windows'],required=True);p.add_argument('--release',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
x=ctypes.CDLL('libX11.so.6');xt=ctypes.CDLL('libXtst.so.6')
x.XOpenDisplay.argtypes=[ctypes.c_char_p];x.XOpenDisplay.restype=ctypes.c_void_p
x.XStringToKeysym.argtypes=[ctypes.c_char_p];x.XStringToKeysym.restype=ctypes.c_ulong
x.XKeysymToKeycode.argtypes=[ctypes.c_void_p,ctypes.c_ulong];x.XKeysymToKeycode.restype=ctypes.c_uint
x.XSetInputFocus.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];x.XFlush.argtypes=[ctypes.c_void_p]
xt.XTestFakeKeyEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong];xt.XTestFakeMotionEvent.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_ulong]
class XMessageData(ctypes.Union):
 _fields_=[('b',ctypes.c_char*20),('s',ctypes.c_short*10),('l',ctypes.c_long*5)]
class XMessage(ctypes.Structure):
 _fields_=[('type',ctypes.c_int),('serial',ctypes.c_ulong),('send_event',ctypes.c_int),('display',ctypes.c_void_p),('window',ctypes.c_ulong),('message_type',ctypes.c_ulong),('format',ctypes.c_int),('data',XMessageData)]
class XEvent(ctypes.Union):
 _fields_=[('message',XMessage),('padding',ctypes.c_long*24)]
x.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];x.XInternAtom.restype=ctypes.c_ulong
x.XSendEvent.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_long,ctypes.POINTER(XEvent)]
d=x.XOpenDisplay(b':77');assert d,'X11 unavailable';held=set();results=[]
def close_window(window):
 event=XEvent();event.message.type=33;event.message.display=d;event.message.window=window
 event.message.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);event.message.format=32
 event.message.data.l[0]=x.XInternAtom(d,b'WM_DELETE_WINDOW',0);event.message.data.l[1]=0
 x.XSendEvent(d,window,0,0,ctypes.byref(event));x.XFlush(d)
def down(name):
 xt.XTestFakeKeyEvent(d,x.XKeysymToKeycode(d,x.XStringToKeysym(name.encode())),1,0);x.XFlush(d);held.add(name)
def up(name):
 xt.XTestFakeKeyEvent(d,x.XKeysymToKeycode(d,x.XStringToKeysym(name.encode())),0,0);x.XFlush(d);held.discard(name)
def key(name):down(name);time.sleep(.04);up(name)
def aim(q):xt.XTestFakeMotionEvent(d,0,int(q[0]),int(q[1]),0);x.XFlush(d)
def screenshot(name):
 im=ImageGrab.grab(xdisplay=':77').crop((0,0,1280,800));path=a.output/(name+'.png');im.save(path);return im,path
def ocr(name):
 _,path=screenshot(name);return subprocess.run(['tesseract',str(path),'stdout','--psm','11'],capture_output=True,text=True,check=True).stdout.lower()
def check(ok,name):
 results.append({'check':name,'passed':bool(ok)});print(('PASS: ' if ok else 'FAIL: ')+name,flush=True);assert ok,name

def targets(im):
 pixels=im.load();points=set();centers=[]
 for gy in range(50,164):
  for gx in range(36,288):
   r,g,b=pixels[gx*4,gy*4][:3]
   if (120<r<180 and g>r+35 and b>r+8 and g>180) or (abs(r-110)<7 and abs(g-102)<7 and abs(b-139)<7) or (abs(r-126)<7 and abs(g-155)<7 and abs(b-164)<7):points.add((gx,gy))
 while points:
  todo=[points.pop()];component=[]
  while todo:
   q=todo.pop();component.append(q)
   for dy in [-1,0,1]:
    for dx in [-1,0,1]:
     z=(q[0]+dx,q[1]+dy)
     if z in points:points.remove(z);todo.append(z)
  if len(component)>4:centers.append((sum(q[0] for q in component)*4/len(component),sum(q[1] for q in component)*4/len(component)+12))
 return centers

env=os.environ.copy();env.update(DISPLAY=':77',XDG_CACHE_HOME=str(a.output/'cache'),XDG_DATA_HOME=str(a.output/'data'))
exe=a.release/('Meowgnificent.exe' if a.platform=='windows' else 'Meowgnificent.x86_64');log=a.output/'engine.log'
flags=['--audio-driver','Dummy','--position','0,0','--resolution','1280x800','--max-fps','60','--log-file',str(log)]
if a.platform=='windows':flags[-1]='Z:'+str(log).replace('/','\\');cmd=['/workspace/Meowgnificent/.local/wine-test.sh',str(exe),*flags]
else:cmd=[str(exe),*flags]
stdout=(a.output/'process.log').open('w');process=subprocess.Popen(cmd,cwd=a.release,env=env,stdout=stdout,stderr=subprocess.STDOUT)
try:
 start=time.monotonic();ready=False
 while time.monotonic()-start<90:
  if process.poll() is not None:raise RuntimeError('Release exited at startup; see process.log')
  tree=subprocess.run(['xwininfo','-display',':77','-root','-tree'],capture_output=True,text=True,check=True).stdout
  ids=re.findall(r'(0x[0-9a-f]+) "Meowgnificent the wizard cat[^\"]*"',tree)
  if ids:
   x.XSetInputFocus(d,int(ids[-1],16),1,0);x.XFlush(d)
   if 'minor magical incident' in ocr('intro'):ready=True;break
  time.sleep(.2)
 check(ready,'extracted release renders start menu')
 key('Return');time.sleep(.25);aim((1050,455));down('d');key('Shift_L');time.sleep(.12);up('d')
 roll_feedback=ocr('roll-input')
 check('roll' in roll_feedback and 'reco' in roll_feedback,'Shift plus movement performs a roll with recovery')
 key('Escape');time.sleep(.15)
 check('taking a catnap' in ocr('pause'),'Enter starts and Escape pauses executable')
 key('Return');time.sleep(.1);key('r');time.sleep(.4)
 check('minor magical incident' in ocr('restart'),'R restores clean start menu')
 key('Return');time.sleep(.15);key('F3');down('space');start=time.monotonic();cleared=False
 while time.monotonic()-start<70:
  im,_=screenshot('combat');found=targets(im)
  if found:aim(min(found,key=lambda q:(q[0]-640)**2+(q[1]-455)**2));key('F3')
  else:
   up('space')
   if 'accidentally excellent' in ocr('victory'):cleared=True;break
   down('space')
  time.sleep(.09)
 up('space');check(cleared,'aimed debug-overreaction combat clears all five enemies')
 key('Return');time.sleep(.4);check('minor magical incident' in ocr('victory-retry'),'victory retry restores start menu')
 key('Return');time.sleep(.2);start=time.monotonic();defeated=False
 while time.monotonic()-start<60:
  if 'brief interruption' in ocr('defeat'):defeated=True;break
  time.sleep(.4)
 check(defeated,'enemy contact defeats idle player')
 key('Return');time.sleep(.4);check('minor magical incident' in ocr('defeat-retry'),'defeat retry restores start menu')
 close_window(int(ids[-1],16));process.wait(timeout=15)
 check(process.returncode==0,'window close exits normally')
 text=log.read_text(errors='replace')+(a.output/'process.log').read_text(errors='replace');check('Godot Engine' in text and 'SCRIPT ERROR' not in text and 'ERROR:' not in text,'session has no engine/script errors')
finally:
 for name in list(held):up(name)
 if process.poll() is None:process.terminate()
 try:process.wait(timeout=5)
 except subprocess.TimeoutExpired:process.kill();process.wait()
 stdout.close();(a.output/'results.json').write_text(json.dumps({'platform':a.platform,'checks':results},indent=2))
