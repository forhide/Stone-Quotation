class_name ArchiveBackdrop
extends Node2D

var time := 0.0

func _draw() -> void:
	var floor_rect := Rect2(80,128,1120,580)
	draw_style_box(styled(Color("0d1421"),Color("273346"),20),Rect2(69,118,1142,595))
	draw_style_box(styled(Color("212d3b"),Color("59606a"),10),floor_rect)
	draw_rect(Rect2(100,157,1080,538),Color("2c3946"))
	# Staggered stone slabs: deterministic, with no generated assets.
	for row in range(8):
		for col in range(14):
			var x := 102+col*83-(41 if row%2 else 0)
			var tile := Rect2(x,160+row*67,79,63).intersection(Rect2(101,159,1078,535))
			if tile.has_area():
				var shade := 0.015*sin(float(row*23+col*17))
				draw_style_box(styled(Color(0.18+shade,0.23+shade,0.28+shade),Color("33424e"),3),tile)
	# Brass examination ring.
	var center := Vector2(640,420)
	draw_arc(center,160,0,TAU,100,Color(0.71,0.62,0.42,0.16),2,true)
	draw_arc(center,145,0,TAU,100,Color(0.71,0.62,0.42,0.10),1,true)
	for i in range(12):
		var angle := TAU*i/12
		var p := center+Vector2.from_angle(angle)*153
		draw_line(p-Vector2.from_angle(angle)*4,p+Vector2.from_angle(angle)*4,Color(0.71,0.62,0.42,0.28),2,true)
	for x in [128,320,875,1060]:
		draw_shelf(Vector2(x,155))
	for p in [Vector2(128,240),Vector2(1150,240),Vector2(128,649),Vector2(1150,649)]:
		draw_candle(p)
	# Floor books and a welcome mat are purely decorative.
	for p in [Vector2(200,540),Vector2(1080,445),Vector2(870,215)]:
		draw_style_box(styled(Color("845d64"),Color("b59683"),2),Rect2(p,Vector2(24,16)))
		draw_line(p+Vector2(5,1),p+Vector2(5,15),Color("d1b28b"),2)
	draw_style_box(styled(Color("3e4655"),Color("9d895f"),3),Rect2(572,656,136,35))

func styled(color: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	return style

func draw_shelf(p: Vector2) -> void:
	draw_style_box(styled(Color("403337"),Color("8b7260"),3),Rect2(p.x,p.y-38,92,39))
	var colors := [Color("788f83"),Color("8f666b"),Color("c0a67a"),Color("646b93")]
	for i in range(9):
		var h := 18+int(abs(sin(i*7.0+p.x))*12)
		draw_rect(Rect2(p.x+5+i*9,p.y-h-5,7,h),colors[i%4])
		draw_line(Vector2(p.x+6+i*9,p.y-11),Vector2(p.x+10+i*9,p.y-11),Color("d5bc8b"),1)
	draw_rect(Rect2(p.x,p.y-4,92,5),Color("987d60"))

func draw_candle(p: Vector2) -> void:
	draw_circle(p-Vector2(0,25),27,Color(1,0.76,0.4,0.035))
	draw_circle(p-Vector2(0,25),15,Color(1,0.76,0.4,0.05))
	draw_style_box(styled(Color("e8c999"),Color("9d7958"),2),Rect2(p.x-5,p.y-26,10,23))
	draw_circle(p-Vector2(0,30),4+sin(time*5+p.x)*0.6,Color("ffda8b"))
