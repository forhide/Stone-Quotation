class_name CandleSlime
extends Node2D

signal defeated(enemy: CandleSlime)
var config: Dictionary
var health: CombatHealth
var target: WizardCat
var bounds: Rect2
var cooldown := 0.0
var hit_flash := 0.0
var time := 0.0
var knockback := Vector2.ZERO
var active := true
var role := "candle"
var phase := "approach"
var phase_time := 0.0
var attack_direction := Vector2.RIGHT
var attack_hit := false
var candle_style: StyleBoxFlat

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	config = settings
	target = player
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	health.died.connect(func(): defeated.emit(self); queue_free())
	time = position.x

func _physics_process(delta: float) -> void:
	if not active or not is_instance_valid(target) or not target.active or health.current<=0:
		return
	time += delta
	cooldown = maxf(0,cooldown-delta)
	hit_flash = maxf(0,hit_flash-delta)
	phase_time = maxf(0,phase_time-delta)
	var to_player := target.position-position
	match phase:
		"approach":
			var reach := 230.0 if role=="broom" else (150.0 if role=="bat" else 85.0)
			if to_player.length()<reach and cooldown<=0:
				phase="windup"
				phase_time=0.72 if role!="bat" else 0.5
				attack_direction=to_player.normalized()
				attack_hit=false
			else:
				var speed := float(config.speed)*(1.25 if role=="bat" else 0.8 if role=="broom" else 1.0)
				position+=to_player.normalized()*speed*delta
		"windup":
			if phase_time<=0:
				phase="attack"
				phase_time=0.38 if role=="broom" else 0.3
		"attack":
			position+=attack_direction*(500 if role=="broom" else 390 if role=="bat" else 210)*delta
			if not attack_hit and position.distance_to(target.position)<float(config.radius)+float(target.config.radius):
				target.take_damage(int(config.contact_damage),position)
				attack_hit=true
			if phase_time<=0:
				phase="recover"
				phase_time=0.85
		"recover":
			if phase_time<=0:
				phase="approach"
				cooldown=0.25
	position+=knockback*delta
	position=position.clamp(bounds.position+Vector2.ONE*20,bounds.end-Vector2.ONE*20)
	knockback=knockback.move_toward(Vector2.ZERO,delta*550)
	queue_redraw()

func take_damage(amount: int, direction: Vector2) -> void:
	if health.damage(amount):
		hit_flash=0.15
		knockback=direction*240
		# A hit interrupts the telegraph: a clumsy roll can rescue a bad cast.
		phase="recover"
		phase_time=0.6

func _draw() -> void:
	if phase=="windup":
		var length := 205.0 if role=="broom" else 125.0 if role=="bat" else 78.0
		var tip := attack_direction*length
		draw_line(Vector2.ZERO,tip,Color(1,0.35,0.27,0.14),38,true)
		draw_line(Vector2.ZERO,tip,Color(1,0.55,0.38,0.7),2,true)
		draw_arc(Vector2.ZERO,32,0,TAU,32,Color("ffad75"),2,true)
		draw_string(ThemeDB.fallback_font,Vector2(-4,-76),"!",HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color("ffbc7e"))
	elif phase=="recover":
		draw_arc(Vector2(0,-52),12,time*5,time*5+4,12,Color("c2d5df"),2,true)
	draw_set_transform(Vector2(0,5),0,Vector2(1,0.35))
	draw_circle(Vector2.ZERO,25,Color(0,0,0,0.3))
	draw_set_transform(Vector2.ZERO)
	if role=="broom":
		var lean := attack_direction.x*0.2 if phase=="attack" else sin(time*3)*0.04
		draw_set_transform(Vector2(0,-5),lean)
		draw_line(Vector2(0,-56),Vector2(0,-12),Color("ad875e"),6,true)
		for i in range(7):
			draw_line(Vector2((i-3)*2,-22),Vector2((i-3)*5,3),Color("d9bc78"),4,true)
		draw_rect(Rect2(-12,-42,24,18),Color("7e9ba4"))
		draw_line(Vector2(-8,-33),Vector2(8,-33),Color("222c39"),3)
	elif role=="bat":
		var lift := -30+sin(time*8)*4
		for side in [-1,1]:
			draw_colored_polygon(PackedVector2Array([Vector2(0,lift),Vector2(side*36,lift-12-sin(time*12)*8),Vector2(side*24,lift+10),Vector2(side*12,lift+3)]),Color("a292c1"))
		draw_circle(Vector2(0,lift),12,Color("6e668b"))
		draw_circle(Vector2(-4,lift-2),2,Color("ffcc91"))
		draw_circle(Vector2(4,lift-2),2,Color("ffcc91"))
	else:
		draw_set_transform(Vector2(0,-12),sin(time*4)*0.08,Vector2(1.15,0.85+sin(time*4)*0.08))
		draw_circle(Vector2.ZERO,21,Color("fff4d7") if hit_flash>0 else Color("92bcac"))
		draw_circle(Vector2(-6,-4),3,Color("243c42"))
		draw_circle(Vector2(6,-4),3,Color("243c42"))
		draw_line(Vector2(-3,5),Vector2(3,5),Color("3b5f5d"),2)
		draw_set_transform(Vector2.ZERO)
		draw_style_box(_candle_style(),Rect2(-6,-47,12,23))
		draw_circle(Vector2(0,-53),8+sin(time*10),Color(1,0.65,0.28,0.18))
		draw_circle(Vector2(sin(time*5)*2,-53),4,Color("ffd88a"))
	draw_set_transform(Vector2.ZERO)
	if hit_flash>0:
		draw_arc(Vector2(0,-20),26,0,TAU,20,Color("fff4d7"),3,true)
	if health.current<health.maximum:
		draw_line(Vector2(-20,-66),Vector2(20,-66),Color("283b43"),3)
		draw_line(Vector2(-20,-66),Vector2(-20+40*float(health.current)/health.maximum,-66),Color("c8e0b4"),3)

func _candle_style() -> StyleBoxFlat:
	if candle_style!=null: return candle_style
	var style := StyleBoxFlat.new()
	style.bg_color=Color("e6ce9b")
	style.set_corner_radius_all(3)
	candle_style=style
	return style
