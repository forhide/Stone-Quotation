"""Independently unpack a cross-built .pkg and compare every staged app byte."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from package_references import validate_component_metadata, validate_product_references


def snapshot(root: Path) -> dict:
    result = {}
    for path in [root, *root.rglob('*')]:
        name = '.' if path == root else path.relative_to(root).as_posix()
        info = path.lstat()
        mode = stat.S_IMODE(info.st_mode)
        if path.is_symlink():
            assert path.resolve().is_relative_to(root.resolve()), 'Escaping app link'
            result[name] = ('link', mode, os.readlink(path))
        elif path.is_dir():
            result[name] = ('directory', mode)
        else:
            result[name] = ('file', mode, hashlib.sha256(path.read_bytes()).hexdigest())
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifact', type=Path, required=True)
    parser.add_argument('--payload-dir', type=Path, required=True)
    parser.add_argument('--bsdtar', default=shutil.which('bsdtar'), required=False)
    parser.add_argument('--lsbom', default=shutil.which('lsbom'), required=False)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    if not args.bsdtar or not args.lsbom:
        parser.error('Independent verification needs bsdtar and lsbom')
    with tempfile.TemporaryDirectory(prefix='pcl-pkg-verify-') as temporary:
        work = Path(temporary)
        archive, payload = work / 'archive', work / 'payload'
        archive.mkdir()
        payload.mkdir()
        subprocess.run([args.bsdtar, '-xf', str(args.artifact.resolve()), '-C', str(archive)], check=True)
        references = validate_product_references(archive)
        if len(references) != 1:
            raise ValueError('This app verifier expects exactly one embedded component.')
        reference = references[0]
        component = reference['path']
        if component.is_file():
            nested = archive / 'component'
            nested.mkdir()
            subprocess.run([args.bsdtar, '-xf', str(component), '-C', str(nested)], check=True)
            component = nested
        info = validate_component_metadata(reference, component)
        subprocess.run([args.bsdtar, '-xpf', str(component / 'Payload'), '-C', str(payload)], check=True)
        actual, expected = snapshot(payload), snapshot(args.payload_dir)
        if actual != expected:
            changed = sorted(name for name in actual.keys() | expected.keys() if actual.get(name) != expected.get(name))
            raise AssertionError(f'Archive payload differs from staging: {changed[:10]}')
        bom_lines = subprocess.check_output([args.lsbom, str(component / 'Bom')], text=True).splitlines()
        assert len(bom_lines) == len(actual), 'BOM file count differs'
        bom = {line.split('\t')[0].removeprefix('./'): line.split('\t')[1:] for line in bom_lines}
        assert set(bom) == set(actual), 'BOM filenames differ from the complete payload'
        assert all(line.split('\t')[2] == '0/80' for line in bom_lines), 'BOM ownership must be root/admin'
        for name, values in bom.items():
            assert int(values[0], 8) & 0o7777 == actual[name][1], f'BOM mode differs: {name}'
        assert int(info.find('payload').get('numberOfFiles')) == len(actual)
        report = {'ok': True, 'artifact': args.artifact.name, 'identifier': info.get('identifier'),
                  'entry_count': len(actual), 'checks': ['embedded_component_resolution', 'distribution_component_identity', 'required_installation_data', 'xar_extraction_checksums', 'cpio_bytes', 'file_modes', 'internal_symlinks', 'bom_complete_paths_modes_ownership', 'package_info_count'],
                  'native_macos_installation': 'not executed'}
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(report))


if __name__ == '__main__':
    main()
