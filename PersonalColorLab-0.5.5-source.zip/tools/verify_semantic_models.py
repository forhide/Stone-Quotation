"""Verify real local recognition with external OpenCV test-only fixtures.

Supply a directory containing messi5.jpg and basketball1.png downloaded from
OpenCV samples/data. These photos are never bundled or redistributed by PCL.
The tool makes no network calls and records hashes/evidence without pictures.
"""
from pathlib import Path
import argparse
import hashlib
import json
import socket
import sys
import time
import tempfile
import numpy as np
from PIL import Image
if '--installed' not in sys.argv:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from personal_color_lab.core.scene_analysis import analyze_scene
from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core.semantic_models import verify_models
from personal_color_lab.core.style_render import render_preview
from personal_color_lab.core.style_dna import builtin_styles,dna_from_batch,dna_from_pair
from personal_color_lab.core.source_workflow import analyze_inputs,discover_inputs
from personal_color_lab.core.edit_reverse import analyze_pair


def denied(*a,**kw):raise AssertionError('Recognition attempted network access')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installed',action='store_true',help='Use the installed private runtime package without prepending source paths')
    parser.add_argument('--reference-dir',required=True,type=Path)
    parser.add_argument('--report',required=True,type=Path)
    args=parser.parse_args();socket.socket=denied;socket.create_connection=denied
    manifest=verify_models();checks=[]
    for name,minimum_people in [('messi5.jpg',1),('basketball1.png',2)]:
        path=args.reference_dir/name;before=hashlib.sha256(path.read_bytes()).hexdigest()
        pixels=np.array(Image.open(path).convert('RGB'));start=time.monotonic();scene=analyze_scene(pixels)
        report=scene['report'];people=[x for x in report['objects'] if x['class_code']=='person']
        assert len(people)>=minimum_people and report['faces']
        assert .02<report['region_fractions']['person']<.7
        assert report['region_fractions']['background']>.2
        with tempfile.TemporaryDirectory(prefix='pcl-semantic-photo-') as directory:
            compatible=path
            if path.suffix.lower() not in {'.jpg','.jpeg'}:
                compatible=Path(directory)/'fixture.jpg';Image.fromarray(pixels).save(compatible,quality=99,subsampling=0)
            preview=render_preview(compatible,builtin_styles()[4],recognition=True)
        assert preview['scene']['report']['scene_tags']==['people']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==before
        checks.append({'fixture':name,'fixture_sha256':before,'detected_classes':list(dict.fromkeys(x['class_code'] for x in report['objects'])),
                       'people':len(people),'faces':len(report['faces']),'person_fraction':report['region_fractions']['person'],
                       'elapsed_seconds':round(time.monotonic()-start,3),'source_unchanged':True})
    with tempfile.TemporaryDirectory(prefix='pcl-semantic-learning-') as directory:
        root=Path(directory);references=root/'references';references.mkdir()
        person_pixels=np.array(Image.open(args.reference_dir/'messi5.jpg').convert('RGB'))
        for i in range(3):
            altered=np.clip(person_pixels.astype(float)*(.97+i*.015)+[4,0,-3],0,255).astype('uint8')
            Image.fromarray(altered).save(references/f'reference-{i}.jpg',quality=98,subsampling=0)
        batch=analyze_inputs(discover_inputs(references,'reference_jpg')['items'],'reference_jpg')
        assert batch['status']=='ok'
        learned=dna_from_batch(batch,'External person-region validation')
        assert learned['semantic_profile']['regions']['person']['sample_count']==3
        new_photo=root/'new-photo.jpg';Image.open(args.reference_dir/'basketball1.png').convert('RGB').save(new_photo,quality=99,subsampling=0)
        regional=render_preview(new_photo,learned,recognition=True,protect_faces=False)
        global_only=render_preview(new_photo,learned,recognition=False)
        difference=float(np.abs(regional['rendered'].astype(float)-global_only['rendered'].astype(float)).mean())
        assert difference>.1
        original=root/'original.jpg';Image.fromarray(person_pixels).save(original,quality=98,subsampling=0)
        edited=root/'edited.jpg';Image.fromarray(np.clip(person_pixels.astype(float)*1.05+[4,0,-3],0,255).astype('uint8')).save(edited,quality=98,subsampling=0)
        pair=analyze_pair(original,edited);assert pair['status']=='ok' and pair['semantic']['status']=='ok'
        pair_style=dna_from_pair(pair,'Observed regional edit')
        assert 'person' in pair_style['semantic_profile']['regions']
        checks.append({'check':'learned_region_application','distinct_reference_encodings':3,'reference_diversity':'same-scene controlled variants; not a diversity benchmark',
                       'person_reference_samples':3,'new_photo_region_vs_global_mean_difference':round(difference,4),
                       'pair_region_transform':True,'temporary_photos_removed':True})
        monochrome_references=root/'monochrome-references';monochrome_references.mkdir()
        gray_pixels=np.asarray(Image.fromarray(person_pixels).convert('L').convert('RGB'))
        for i in range(3):
            variant=np.clip(gray_pixels.astype(float)+i*2,0,255).astype('uint8')
            Image.fromarray(variant).save(monochrome_references/f'gray-{i}.jpg',quality=98,subsampling=0)
        gray_batch=analyze_inputs(discover_inputs(monochrome_references,'reference_jpg')['items'],'reference_jpg')
        assert gray_batch['status']=='ok'
        gray_reference_style=dna_from_batch(gray_batch,'Observed monochrome references')
        gray_edited=root/'monochrome-edited.jpg'
        Image.fromarray(gray_pixels).save(gray_edited,quality=98,subsampling=0)
        gray_pair=analyze_pair(original,gray_edited);assert gray_pair['status']=='ok'
        gray_pair_style=dna_from_pair(gray_pair,'Observed monochrome pair')
        assert gray_reference_style['saturation_scale']==gray_pair_style['saturation_scale']==0
        # OpenCV's basketball fixture is achromatic; applying B&W to it cannot
        # verify desaturation. Make a separate colorful, mirrored soccer copy.
        new_color_photo=root/'new-color-photo.jpg'
        Image.fromarray(person_pixels).transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(new_color_photo,quality=99,subsampling=0)
        gray_reference_preview=render_preview(new_color_photo,gray_reference_style,recognition=True)
        gray_pair_preview=render_preview(new_color_photo,gray_pair_style,recognition=True)
        reference_spread=int(np.ptp(gray_reference_preview['rendered'].astype(int),axis=2).max())
        pair_spread=int(np.ptp(gray_pair_preview['rendered'].astype(int),axis=2).max())
        assert reference_spread<=1 and pair_spread<=1,(reference_spread,pair_spread)
        assert np.ptp(gray_pair_preview['original'].astype(int),axis=2).max()>30
        checks.append({'check':'learned_monochrome_application','distinct_reference_encodings':3,
                       'reference_diversity':'same-scene controlled gray variants; not a diversity benchmark',
                       'reference_max_rgb_channel_spread':reference_spread,'pair_max_rgb_channel_spread':pair_spread,
                       'target_fixture':'messi5.jpg','target_derivation':'new mirrored color copy',
                       'color_target_photo':True,'recognition_enabled':True,'face_protection_enabled':True,
                       'temporary_photos_removed':True})
    result={'ok':True,'app_version':APP_VERSION,'execution':'installed_runtime' if args.installed else 'source_runtime','model_bundle':'OpenCV Zoo pinned 47534e27','verified_model_bytes':sum(e['size'] for e in manifest['models']),
            'runtime_network':'denied','backend':'opencv_dnn_cpu','fixtures_redistributed':False,'checks':checks,
            'limits':'Two person/face fixtures validate real execution, not all-class accuracy, sky segmentation or Lightroom equivalence.'}
    args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':main()
