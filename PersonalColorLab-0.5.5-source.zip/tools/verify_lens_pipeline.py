"""Check the offline installed optical pipeline using generated Bayer DNGs.

These sensor charts contain invented equipment EXIF to exercise actual metadata
extraction and published profile selection. They are not photographs or camera
calibration evidence. No fixture is downloaded, and no source photo is used.
Run with --installed under the app's private Python (-I -B) to prevent the
source checkout from satisfying imports in an installed-runtime diagnostic.
"""
from __future__ import annotations

import argparse
from contextlib import AbstractContextManager
from io import BytesIO
import hashlib
import json
from pathlib import Path
import socket
import struct
import sys
import tempfile
import threading
import xml.etree.ElementTree as ET

import cv2
import numpy as np
from PIL import Image, ImageCms
import rawpy

if "--installed" not in sys.argv:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core.lens_correction import distortion_coordinates
from personal_color_lab.core.lens_metadata import read_lens_metadata
from personal_color_lab.core.lens_profiles import (
    equipment_catalog, lens_bundle_id, resolve_lens_profile,
    validate_lens_override, verify_lens_profiles,
)
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.style_render import export_jpeg, export_xmp, read_photo, render_preview
from personal_color_lab.core.synthetic_raw import write_test_dng


EQUIPMENT = {
    "camera_make": "Canon", "camera_model": "Canon EOS 5D Mark II",
    "lens_make": "Canon", "lens_model": "Canon EF 17-40mm f/4L USM",
    "focal_length_mm": 17., "aperture": 8.,
}
OVERRIDE = {key: EQUIPMENT[key] for key in (
    "camera_make", "camera_model", "lens_make", "lens_model", "focal_length_mm")}
SONY = {
    "camera_make": "SONY", "camera_model": "ILCE-7CR", "lens_make": "Sony",
    "lens_model": "FE 16-35mm F2.8 GM II", "focal_length_mm": 24., "aperture": 8.,
}


def denied(*args, **kwargs):
    raise AssertionError("Optical processing attempted network access")


def fingerprint(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _assert_private_fields_absent(data):
    forbidden = ("gps", "latitude", "longitude", "serial", "owner", "artist", "copyright")
    if isinstance(data, dict):
        for key, value in data.items():
            assert not any(word in str(key).lower() for word in forbidden), key
            _assert_private_fields_absent(value)
    elif isinstance(data, list):
        for value in data:
            _assert_private_fields_absent(value)


def _add_synthetic_gps(path):
    """Add valid, invented location EXIF without moving any sensor pixels.

    A replacement top-level IFD retains the original absolute offsets. The
    parser must skip its GPS IFD; the JPEG copy must contain no source EXIF.
    These diagnostic values describe no user or source photograph.
    """
    data = bytearray(path.read_bytes())
    assert data[:4] == b"II\x2a\0"
    original_ifd = struct.unpack_from("<I", data, 4)[0]
    count = struct.unpack_from("<H", data, original_ifd)[0]
    entries = [bytes(data[original_ifd + 2 + i * 12:original_ifd + 14 + i * 12])
               for i in range(count)]
    gps_offset = len(data)
    # Latitude ref plus a three-component rational latitude proves that the
    # fixture has a real GPS pointer, rather than only asserting an empty EXIF.
    gps_table = bytearray(struct.pack("<H", 2))
    gps_table.extend(struct.pack("<HHI4s", 1, 2, 2, b"N\0\0\0"))
    gps_table.extend(struct.pack("<HHII", 2, 5, 3, gps_offset + 2 + 24 + 4))
    gps_table.extend(struct.pack("<I", 0))
    gps_table.extend(struct.pack("<IIIIII", 1, 1, 2, 1, 3, 1))
    data.extend(gps_table)
    entries.append(struct.pack("<HHII", 0x8825, 4, 1, gps_offset))
    entries.sort(key=lambda entry: struct.unpack_from("<H", entry)[0])
    replacement_ifd = len(data)
    data.extend(struct.pack("<H", len(entries)) + b"".join(entries) + struct.pack("<I", 0))
    struct.pack_into("<I", data, 4, replacement_ifd)
    path.write_bytes(data)


class RawCalls(AbstractContextManager):
    """Observe actual LibRaw development without replacing decoded pixels."""

    def __init__(self):
        self.calls = []

    def __enter__(self):
        factory = rawpy.RawPy
        observer = self

        class ObservedRaw:
            def __init__(self):
                self.raw = factory()

            def __enter__(self):
                self.raw.__enter__()
                return self

            def __exit__(self, *args):
                return self.raw.__exit__(*args)

            def __getattr__(self, name):
                return getattr(self.raw, name)

            def postprocess(self, **kwargs):
                output = self.raw.postprocess(**kwargs)
                observer.calls.append({"half_size": kwargs.get("half_size", False),
                                       "dimensions": [int(output.shape[1]), int(output.shape[0])]})
                return output

        self.factory = factory
        rawpy.RawPy = ObservedRaw
        return self

    def __exit__(self, *args):
        rawpy.RawPy = self.factory


class CancelRemap(AbstractContextManager):
    def __init__(self, event):
        self.event = event
        self.calls = 0

    def __enter__(self):
        original = cv2.remap
        observer = self

        def remap(*args, **kwargs):
            result = original(*args, **kwargs)
            observer.calls += 1
            observer.event.set()
            return result

        self.original = original
        cv2.remap = remap
        return self

    def __exit__(self, *args):
        cv2.remap = self.original


def cancelled(operation):
    try:
        operation()
    except ValueError as exc:
        assert "cancel" in str(exc).lower(), str(exc)
    else:
        raise AssertionError("A cancelled optical operation completed")


def _generated(root, name, equipment=EQUIPMENT, *, orientation=1,
               width=1296, height=864, embedded_geometry=False):
    return write_test_dng(root / name, width=width, height=height, orientation=orientation,
                          equipment=equipment, embedded_geometry=embedded_geometry)


def check_metadata_and_geometry(root, manifest):
    source = _generated(root, "matched-gps.dng", orientation=6)
    _add_synthetic_gps(source)
    before = fingerprint(source)
    equipment = read_lens_metadata(source)
    for key, value in EQUIPMENT.items():
        assert equipment[key] == value, (key, equipment[key], value)
    assert equipment["orientation"] == 6 and equipment["metadata_status"] == "ok"
    assert equipment["metadata_extractor"] == "exifread"
    assert equipment["crop_factor"] is None
    _assert_private_fields_absent(equipment)
    profile = resolve_lens_profile(equipment)
    assert profile["available"] and profile["status"] == "matched"
    assert profile["bundle_id"] == manifest["bundle_id"] == lens_bundle_id()
    assert profile["crop_factor_source"] == "lensfun_camera_database"
    metadata = {}
    full, dimensions = read_photo(source, max_dimension=1_000_000,
                                  lens_correction=True, decode_metadata=metadata)
    plain, plain_dimensions = read_photo(source, max_dimension=1_000_000)
    assert dimensions == plain_dimensions == (864, 1296)
    assert not np.array_equal(full, plain)
    report = metadata["lens_correction"]
    assert report["requested"] and report["applied"] and report["status"] == "corrected"
    assert report["border"] == "fit" and report["valid_fraction"] == 1.
    assert report["output_size"] == list(dimensions)
    assert report["crop_scale"] >= 1 and report["retained_linear_fraction"] == 1 / report["crop_scale"]
    assert report["profile"]["database_source"] == manifest["source"]
    for _, map_x, map_y, scale in distortion_coordinates(*dimensions, profile, border="fit"):
        assert np.isfinite(map_x).all() and np.isfinite(map_y).all()
        assert map_x.min() >= 0 and map_x.max() <= dimensions[0] - 1
        assert map_y.min() >= 0 and map_y.max() <= dimensions[1] - 1
        assert scale == report["crop_scale"]
    assert fingerprint(source) == before
    return source, full, report, {
        "check": "real_metadata_exact_profile_and_valid_full_geometry",
        "equipment": equipment, "fixture_sha256": before,
        "fixture_contains_invented_gps_ifd": True,
        "private_metadata_excluded": True, "output_dimensions": list(dimensions),
        "correction": report, "fit_samples_all_inside_original": True,
        "pixels_changed_by_matched_distortion": True, "source_unchanged": True,
    }


def check_preview_and_export(root, source, full, report):
    before = fingerprint(source)
    dna = identity_dna()
    preview = render_preview(source, dna, lens_correction=True)
    height, width = full.shape[:2]
    factor = min(1., 1200 / max(width, height))
    derived = (cv2.resize(full, (max(1, round(width * factor)), max(1, round(height * factor))),
                          interpolation=cv2.INTER_AREA) if factor < 1 else full)
    assert np.array_equal(preview["original"], derived)
    assert np.array_equal(preview["original"], preview["rendered"])
    assert preview["lens_correction"]["crop_scale"] == report["crop_scale"]
    destination = root / "corrected-neutral.jpg"
    with RawCalls() as calls:
        exported = export_jpeg(source, destination, dna, expected_fingerprint=before,
                               lens_correction=True)
    assert calls.calls == [{"half_size": False, "dimensions": [width, height]}], calls.calls
    assert exported["dimensions"] == [width, height] and exported["lens_correction"]["applied"]
    assert exported["lens_correction"]["crop_scale"] == report["crop_scale"]
    assert exported["source_unchanged"] and exported["gps_exported"] is False
    stream = BytesIO()
    icc = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
    Image.fromarray(full).save(stream, format="JPEG", quality=95, subsampling=0, icc_profile=icc)
    with Image.open(BytesIO(stream.getvalue())) as expected, Image.open(destination) as actual:
        assert actual.size == (width, height) and not actual.getexif()
        assert np.array_equal(np.asarray(actual), np.asarray(expected))
        assert actual.info.get("icc_profile")
        embedded_profile = ImageCms.ImageCmsProfile(BytesIO(actual.info["icc_profile"]))
        assert "srgb" in ImageCms.getProfileName(embedded_profile).lower()
    xmp = root / "color-only-preset.xmp"
    export_xmp(xmp, dna, preview["effective"])
    description = ET.parse(xmp).find(".//{http://www.w3.org/1999/02/22-rdf-syntax-ns#}Description")
    assert description is not None
    for key in description.attrib:
        local_name = key.rsplit("}", 1)[-1].lower()
        assert not any(word in local_name for word in ("lens", "distortion", "perspective", "crop", "gps")), key
    assert fingerprint(source) == before
    return {"check": "precise_preview_and_single_decode_full_jpeg",
            "native_postprocess_calls": len(calls.calls), "full_baseline_decode": True,
            "preview_equals_area_resize_of_corrected_full_pixels": True,
            "neutral_style_preserves_corrected_pixels_exactly": True,
            "jpeg_matches_independently_encoded_corrected_pixels": True,
            "output_dimensions": [width, height], "source_unchanged": True,
            "source_gps_exif_stripped": True, "srgb_profile_embedded": True,
            "xmp_contains_color_recipe_without_optics_or_crop": True}


def check_cache_and_manual_selection(root, source):
    dna = identity_dna()
    with RawCalls() as calls:
        off = render_preview(source, dna)
        on = render_preview(source, dna, base=off, lens_correction=True)
        stable = render_preview(source, dna, base=on, lens_correction=True)
    assert len(calls.calls) == 2
    assert stable["original"] is on["original"] and not np.array_equal(off["original"], on["original"])
    with RawCalls() as calls:
        manual = render_preview(source, dna, base=stable, lens_correction=True, lens_override=OVERRIDE)
        manual_same = render_preview(source, dna, base=manual, lens_correction=True,
                                     lens_override=dict(reversed(list(OVERRIDE.items()))))
        camera_override = dict(OVERRIDE, camera_model="Canon EOS 7D")
        different_camera = render_preview(source, dna, base=manual_same, lens_correction=True,
                                          lens_override=camera_override)
        focal_override = dict(camera_override, focal_length_mm=40.)
        different_focal = render_preview(source, dna, base=different_camera, lens_correction=True,
                                         lens_override=focal_override)
        reset = render_preview(source, dna, base=different_focal, lens_correction=True)
    assert len(calls.calls) == 4
    assert manual_same["original"] is manual["original"]
    assert different_camera["lens_correction"]["applied"] and different_focal["lens_correction"]["applied"]
    assert not np.array_equal(manual["original"], different_camera["original"])
    assert not np.array_equal(different_camera["original"], different_focal["original"])
    assert np.array_equal(reset["original"], on["original"])
    assert different_camera["equipment"]["camera_model"] == EQUIPMENT["camera_model"]
    assert different_focal["equipment"]["focal_length_mm"] == EQUIPMENT["focal_length_mm"]
    assert different_focal["lens_correction"]["selected_equipment"] == focal_override
    assert different_focal["lens_correction"]["selection_source"] == "manual"
    assert validate_lens_override(OVERRIDE) == OVERRIDE
    second_equipment = dict(EQUIPMENT, camera_model="Canon EOS 7D", lens_model="Synthetic uncalibrated lens")
    second = _generated(root, "second-camera.dng", second_equipment, orientation=6)
    second_before = fingerprint(second)
    with RawCalls() as calls:
        second_manual = render_preview(second, dna, base=manual, lens_correction=True, lens_override=OVERRIDE)
    assert len(calls.calls) == 1 and second_manual["lens_correction"]["applied"]
    assert second_manual["equipment"]["camera_model"] == second_equipment["camera_model"]
    assert second_manual["equipment"]["lens_model"] == second_equipment["lens_model"]
    assert second_manual["lens_correction"]["selected_equipment"] == OVERRIDE
    assert fingerprint(second) == second_before
    fast_source = _generated(root, "fast-lens.dng", width=2592, height=1728)
    with RawCalls() as calls:
        strict = render_preview(fast_source, dna, lens_correction=True)
        fast = render_preview(fast_source, dna, base=strict, lens_correction=True, raw_quality="interactive")
        fast_same = render_preview(fast_source, dna, base=fast, lens_correction=True, raw_quality="interactive")
        strict_again = render_preview(fast_source, dna, base=fast_same, lens_correction=True)
    assert [item["half_size"] for item in calls.calls] == [False, True, False]
    assert fast["raw_decode"]["preview_is_approximation"] and fast["lens_correction"]["applied"]
    assert fast_same["original"] is fast["original"]
    assert np.array_equal(strict["original"], strict_again["original"])
    return {"check": "optical_and_manual_selection_cache_invalidation",
            "on_off_changes_invalidate_pixels": True, "same_plan_reuses_pixels": True,
            "manual_override_camera_and_focal_changes_invalidate_pixels": True,
            "dictionary_order_does_not_invalidate_same_selection": True,
            "automatic_reset_restores_exact_pixels": True,
            "two_raw_sources_never_share_cached_pixels": True,
            "manual_selection_preserves_actual_camera_lens_and_focal_metadata": True,
            "quality_change_redecodes_sensor": True, "fast_preview_remains_explicit_approximation": True}


def check_orientation(root):
    transforms = {1: lambda image: image, 2: lambda image: image[:, ::-1],
                  3: lambda image: np.rot90(image, 2), 4: lambda image: image[::-1],
                  5: lambda image: np.transpose(image, (1, 0, 2)),
                  6: lambda image: np.rot90(image, -1),
                  7: lambda image: np.transpose(image, (1, 0, 2))[::-1, ::-1],
                  8: lambda image: np.rot90(image)}
    reference = None
    observations = []
    for orientation, transform in transforms.items():
        source = _generated(root, f"optical-orientation-{orientation}.dng",
                            orientation=orientation, width=648, height=432)
        before = fingerprint(source)
        pixels, dimensions, metadata = decode_raw(source, max_dimension=1000, lens_correction=True)
        assert metadata["lens_correction"]["applied"] and metadata["lens_correction"]["valid_fraction"] == 1.
        if orientation == 1:
            reference = pixels
        expected = transform(reference)
        difference = np.abs(pixels.astype(int) - expected.astype(int))
        error = int(difference.max())
        mean_error = float(difference.mean())
        # Float32 absolute map coordinates can land on opposite sides of an
        # OpenCV 1/32-pixel interpolation boundary after a reflection. Permit
        # only sparse rounding differences and record the actual maximum.
        assert error <= 8 and mean_error < .001, (orientation, error, mean_error)
        expected_dimensions = (432, 648) if orientation >= 5 else (648, 432)
        assert dimensions == expected_dimensions and fingerprint(source) == before
        observations.append({"tiff_orientation": orientation,
                             "output_dimensions": list(dimensions),
                             "corrected_pixel_transform_max_byte_error": error,
                             "corrected_pixel_transform_mean_byte_error": mean_error,
                             "fit_sample_fraction": metadata["lens_correction"]["valid_fraction"]})
    return {"check": "corrected_rotations_and_mirrors", "observations": observations}


def check_unsupported_and_embedded(root):
    source = _generated(root, "sony-a7cr-gm-ii.dng", SONY)
    before = fingerprint(source)
    metadata = read_lens_metadata(source)
    for key, value in SONY.items():
        assert metadata[key] == value
    _assert_private_fields_absent(metadata)
    profile = resolve_lens_profile(metadata)
    assert not profile["available"] and profile["status"] == "lens_not_found"
    assert profile["lens_model"] == SONY["lens_model"]
    catalog = equipment_catalog("Sony", "ILCE-7CR")
    assert any(camera["camera_model"] == "ILCE-7CR" for camera in catalog["cameras"])
    assert any(lens["lens_model"] == "FE 16-35mm f/2.8 GM" for lens in catalog["lenses"])
    assert not any(lens["lens_model"] == SONY["lens_model"] for lens in catalog["lenses"])
    plain = render_preview(source, identity_dna())
    requested = render_preview(source, identity_dna(), base=plain, lens_correction=True)
    assert not requested["lens_correction"]["applied"]
    assert requested["lens_correction"]["status"] == "lens_not_found"
    assert np.array_equal(plain["original"], requested["original"])
    assert fingerprint(source) == before
    embedded = _generated(root, "embedded-optics.dng", embedded_geometry=True)
    embedded_before = fingerprint(embedded)
    detected = read_lens_metadata(embedded)
    assert detected["embedded_dng_opcodes_present"] and detected["embedded_distortion"]
    plain = render_preview(embedded, identity_dna())
    automatic = render_preview(embedded, identity_dna(), base=plain, lens_correction=True)
    manual = render_preview(embedded, identity_dna(), base=automatic,
                            lens_correction=True, lens_override=OVERRIDE)
    for preview in (automatic, manual):
        assert not preview["lens_correction"]["applied"]
        assert preview["lens_correction"]["status"] == "embedded_correction"
        assert np.array_equal(plain["original"], preview["original"])
    assert fingerprint(embedded) == embedded_before
    return {"check": "unsupported_equipment_and_embedded_geometry_fallback",
            "sony_equipment_detected": {key: metadata[key] for key in SONY},
            "sony_camera_present_in_database": True,
            "gm_ii_calibration_status": profile["status"],
            "first_generation_gm_exists_but_is_never_substituted": True,
            "unsupported_pixels_exactly_unchanged": True,
            "embedded_opcode_blocks_automatic_and_manual_additional_warp": True,
            "embedded_opcode_is_a_guard_not_claim_of_successful_development": True,
            "sources_unchanged": True}


def check_cancellation(root, source):
    before = fingerprint(source)
    event = threading.Event()
    event.set()
    first = root / "cancelled-before-optics.jpg"
    with RawCalls() as calls:
        cancelled(lambda: decode_raw(source, cancel_event=event, lens_correction=True))
        cancelled(lambda: render_preview(source, identity_dna(), cancel_event=event, lens_correction=True))
        cancelled(lambda: export_jpeg(source, first, identity_dna(), cancel_event=event, lens_correction=True))
    assert not calls.calls and not first.exists()
    event.clear()
    during = root / "cancelled-during-optics.jpg"
    with RawCalls() as calls, CancelRemap(event) as maps:
        cancelled(lambda: export_jpeg(source, during, identity_dna(), cancel_event=event, lens_correction=True))
    assert len(calls.calls) == 1 and maps.calls == 1
    assert not during.exists() and not list(root.glob(".pcl-export-*.tmp"))
    assert fingerprint(source) == before
    return {"check": "cooperative_optical_cancellation",
            "pre_cancel_skips_native_development": True,
            "cancel_after_first_actual_remap_tile_stops_output": True,
            "native_postprocess_calls_before_tile_cancellation": len(calls.calls),
            "remap_tiles_before_cancellation": maps.calls,
            "no_partial_output": True, "source_unchanged": True,
            "native_libraw_call_is_not_interruptible": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--installed", action="store_true", help="Import only the installed runtime package")
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    if args.installed and not sys.flags.isolated:
        parser.error("Installed checks require the private runtime's isolated Python (-I -B)")
    socket.socket = denied
    socket.create_connection = denied
    socket.getaddrinfo = denied
    manifest = verify_lens_profiles()
    assert manifest["source"]["license"] == "CC-BY-SA-3.0"
    with tempfile.TemporaryDirectory(prefix="pcl-lens-validation-") as directory:
        root = Path(directory)
        source, full, correction, first_check = check_metadata_and_geometry(root, manifest)
        source_before = fingerprint(source)
        checks = [first_check, check_preview_and_export(root, source, full, correction)]
        del full
        checks.extend([check_cache_and_manual_selection(root, source), check_orientation(root),
                       check_unsupported_and_embedded(root), check_cancellation(root, source)])
        assert fingerprint(source) == source_before
    result = {
        "ok": True, "app_version": APP_VERSION,
        "execution": "installed_runtime" if args.installed else "source_runtime",
        "runtime_network": "denied", "fixtures": "generated deterministic Bayer CFA DNGs with invented equipment EXIF",
        "python_isolated": bool(sys.flags.isolated),
        "user_photos_used": False, "temporary_files_removed": True,
        "rawpy_version": str(rawpy.__version__), "libraw_version": list(rawpy.libraw_version),
        "lens_database": {"bundle_id": manifest["bundle_id"], "source": manifest["source"],
                          "stats": manifest["stats"], "all_asset_hashes_verified": True,
                          "license_bytes_verified": True},
        "checks": checks,
        "limits": (
            "Generated ordinary Bayer charts exercise metadata, matching and rendering, not physical camera/lens calibration. "
            "Only centered rectilinear radial distortion is supported; full active camera sensor geometry is assumed. "
            "Digital sensor crop modes and reduced active sensor areas are not validated by these charts. "
            "No vignetting, chromatic aberration, perspective correction, Adobe equivalence or native Mac installation claim. "
            "The current database has no FE 16-35mm F2.8 GM II calibration; no first-generation GM substitution is made. "
            "Optical geometry is not exported to XMP; its global color recipe remains approximate."
        ),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, allow_nan=False))


if __name__ == "__main__":
    main()
