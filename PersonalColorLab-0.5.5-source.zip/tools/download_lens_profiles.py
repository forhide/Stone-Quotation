"""Prepare the pinned Lensfun database at build time; never imported by the app."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SOURCE_COMMIT = '43f9e001ab66c4fcdd4f400463f13b72f94b2288'
PINNED_MANIFEST = ROOT / 'personal_color_lab/assets/lensfun/manifest.json'


def prepare(destination, *, verify_only=False):
    from personal_color_lab.core.lens_profiles import verify_lens_profiles
    expected_bytes = PINNED_MANIFEST.read_bytes()
    manifest = json.loads(expected_bytes)
    if manifest.get('source', {}).get('commit') != SOURCE_COMMIT:
        raise ValueError('Lens database pin differs from the reviewed source.')
    destination = Path(destination)
    if not verify_only:
        destination.mkdir(parents=True, exist_ok=True)
        for entry in manifest['files']:
            relative = Path(entry['filename'])
            if (relative.is_absolute() or '..' in relative.parts
                    or not (relative.as_posix().startswith('db/') and relative.suffix == '.xml'
                            or relative.as_posix() == 'COPYING.CC_BY-SA_3.0')):
                raise ValueError('Unexpected pinned lens asset path.')
            target = destination / relative
            if target.is_file() and not target.is_symlink():
                data = target.read_bytes()
                if len(data) == entry['size'] and hashlib.sha256(data).hexdigest() == entry['sha256']:
                    continue
            url = f'https://raw.githubusercontent.com/lensfun/lensfun/{SOURCE_COMMIT}/data/{relative.as_posix()}'
            request = urllib.request.Request(url, headers={'User-Agent': 'PersonalColorLab-build/0.5.4'})
            with urllib.request.urlopen(request, timeout=30) as response:
                data = response.read(entry['size'] + 1)
            if len(data) != entry['size'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
                raise ValueError('Downloaded lens asset failed official source size/hash verification.')
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.is_symlink():
                raise ValueError('Lens asset destination must be a regular file.')
            temporary = target.with_name(target.name + '.partial')
            with temporary.open('xb') as stream:
                stream.write(data)
            temporary.replace(target)
        (destination / 'manifest.json').write_bytes(expected_bytes)
    verified = verify_lens_profiles(destination)
    return {'ok': True, 'commit': SOURCE_COMMIT, 'bundle_id': verified['bundle_id'],
            'stats': verified['stats'], 'runtime_downloads': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=PINNED_MANIFEST.parent)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(prepare(args.output_dir, verify_only=args.verify_only)))


if __name__ == '__main__':
    main()
