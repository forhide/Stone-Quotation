"""Build-only, offline reproduction from pinned local Microsoft TinyCLIP inputs."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from personal_color_lab.core.photo_scene_models import MODEL_SHA256,LICENSE_SHA256,verify_scene_models
CHECKPOINT_SHA256='3d9f86a556cd13acc1aa6cc18495a79ffd1f58b6f17a552400bdefd244c3a92c'
COMMIT='4a13c4091e78f9abd2160e7e01c02e48c1cf8fb9'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--microsoft-source',type=Path,required=True)
    parser.add_argument('--checkpoint',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();source=args.microsoft_source.resolve();output=args.output.resolve()
    if output==ROOT/'personal_color_lab/assets/photo_scene' or output.exists():
        raise ValueError('Use a new separate output directory; production assets are never replaced.')
    if digest(args.checkpoint)!=CHECKPOINT_SHA256:raise ValueError('Unexpected upstream checkpoint')
    head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
    if head!=COMMIT:raise ValueError('Unexpected Microsoft source revision')
    subprocess.run(['git','-C',str(source),'diff','--exit-code','HEAD','--','TinyCLIP/src'],check=True)
    license_path=source/'TinyCLIP/LICENSE'
    if digest(license_path)!=LICENSE_SHA256:raise ValueError('Unexpected Microsoft license')
    import numpy as np
    import torch
    import onnx
    from onnx import TensorProto,numpy_helper,helper
    sys.path.insert(0,str(source/'TinyCLIP/src'))
    import open_clip
    torch.set_num_threads(1)
    model,_,_=open_clip.create_model_and_transforms('TinyCLIP-ViT-8M-16-Text-3M',pretrained=str(args.checkpoint))
    model.eval().float()
    for block in model.visual.transformer.resblocks:block.attn.use_naive_compute=True
    output.mkdir(parents=True)
    temporary=output/'image-fp32-build-only.onnx'
    dummy=torch.from_numpy(np.random.default_rng(55).normal(size=(1,3,224,224)).astype(np.float32))
    torch.onnx.export(model.visual,dummy,str(temporary),input_names=['image'],output_names=['embedding'],opset_version=13,dynamo=False,do_constant_folding=True)
    converted=onnx.load(temporary);nodes=[];extra=[]
    for initializer in converted.graph.initializer:
        array=numpy_helper.to_array(initializer)
        if initializer.data_type!=TensorProto.FLOAT or array.size<10000 or array.ndim<2:continue
        original=initializer.name
        scale=np.maximum(np.max(np.abs(array),axis=tuple(range(1,array.ndim)),keepdims=True)/127,1e-12).astype(np.float32)
        quantized=np.round(array/scale).clip(-127,127).astype(np.int8)
        initializer.CopyFrom(numpy_helper.from_array(quantized,name=original+'_int8_storage'))
        extra.extend([numpy_helper.from_array(scale.reshape(-1),name=original+'_scale'),numpy_helper.from_array(np.zeros(scale.size,dtype=np.int8),name=original+'_zero')])
        nodes.append(helper.make_node('DequantizeLinear',[initializer.name,original+'_scale',original+'_zero'],[original],name=original+'_decode',axis=0))
    previous=list(converted.graph.node);converted.graph.ClearField('node');converted.graph.node.extend(nodes+previous);converted.graph.initializer.extend(extra)
    onnx.checker.check_model(converted);onnx.save(converted,output/'encoder.onnx')
    if digest(output/'encoder.onnx')!=MODEL_SHA256:raise ValueError('Conversion differs from pinned production model; inspect the build environment.')
    assets=ROOT/'personal_color_lab/assets/photo_scene';prompts=json.loads((assets/'prompts.json').read_text())
    tokenizer=open_clip.get_tokenizer('TinyCLIP-ViT-8M-16-Text-3M');vectors=[]
    with torch.no_grad():
        for sign in ('positive','negative'):
            row=[]
            for entry in prompts.values():
                features=model.encode_text(tokenizer(entry[sign]));features=features/features.norm(dim=-1,keepdim=True)
                mean=features.mean(dim=0);row.append((mean/mean.norm()).numpy())
            vectors.append(row)
    np.save(output/'prompt-vectors.npy',np.array(vectors,np.float32))
    shutil.copy2(license_path,output/'LICENSE.txt')
    for name in ('prompts.json','manifest.json','README.md'):shutil.copy2(assets/name,output/name)
    verify_scene_models(output);temporary.unlink()
    print(json.dumps({'ok':True,'upstream_commit':head,'assets_verified':True,'output':str(output)}))

if __name__=='__main__':main()
