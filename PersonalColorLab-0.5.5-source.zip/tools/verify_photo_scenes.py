"""Real CPU scene execution plus all learning routes, without network access.

External fixtures astronaut.png and coffee.png are test-only inputs. No photos
are copied into the report or installed app. These are execution fixtures,
not a broad scene-classification accuracy benchmark.
"""
from pathlib import Path
import argparse,copy,hashlib,json,socket,sys,tempfile,time,threading
if '--installed' not in sys.argv:sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import cv2
import numpy as np
from PIL import Image
from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core.photo_scene_models import verify_scene_models,bundle_id
from personal_color_lab.core.photo_scene import classify_photo,with_scene_override
from personal_color_lab.core.source_workflow import discover_inputs,analyze_inputs,set_scene_override
from personal_color_lab.core.style_dna import dna_from_batch,validate_dna,load_style_file
from personal_color_lab.core.style_render import render_preview,export_jpeg,export_style_json
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.analysis_control import AnalysisCancelledError

def denied(*args,**kwargs):raise AssertionError('Scene processing attempted network access')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--installed',action='store_true');parser.add_argument('--reference-dir',type=Path,required=True);parser.add_argument('--report',type=Path,required=True);args=parser.parse_args()
 socket.socket=denied;socket.create_connection=denied
 manifest=verify_scene_models();checks=[];fixture_pixels={}
 for name,expected in [('astronaut.png','portrait'),('coffee.png','food')]:
  path=args.reference_dir/name;before=sha(path);pixels=np.array(Image.open(path).convert('RGB'));start=time.monotonic();report=classify_photo(pixels)
  assert report['status']=='ok' and expected in report['labels'],report
  assert report['bundle_id']==bundle_id() and sha(path)==before
  checks.append({'check':'actual_visual_'+expected,'fixture':name,'fixture_sha256':before,'automatic_labels':report['labels'],'uncertain':report['uncertain'],'seconds':round(time.monotonic()-start,4),'source_unchanged':True,'scores':'uncalibrated similarity estimates'})
  fixture_pixels[expected]=pixels
 with tempfile.TemporaryDirectory(prefix='pcl-scene-diagnostic-') as directory:
  root=Path(directory);source_hashes={};learned={}
  for mode in ('reference_jpg','raw_jpg','raw_xmp'):
   folder=root/mode;folder.mkdir()
   for index in range(6):
    if mode=='reference_jpg':
     pixels=np.clip(fixture_pixels['food' if index<3 else 'portrait'].astype(float)+(index%3)*3,0,255).astype('uint8');Image.fromarray(pixels).save(folder/f'photo-{index}.jpg',quality=98,subsampling=0)
    else:
     raw=write_test_dng(folder/f'photo-{index}.dng',seed=17+index)
     if mode=='raw_jpg':
      pixels,_,_=decode_raw(raw);Image.fromarray(np.clip(pixels.astype(float)*(.85 if index<3 else 1.18)+([4,1,-2] if index<3 else [-2,1,4]),0,255).astype('uint8')).save(folder/f'photo-{index}.jpg',quality=99,subsampling=0)
     else:
      exposure='.7' if index<3 else '-.6'
      (folder/f'photo-{index}.xmp').write_text(f'<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" crs:Exposure2012="{exposure}" crs:Contrast2012="12" crs:Temperature="6500"/>')
   source_hashes.update({path:sha(path) for path in folder.iterdir()})
   items=discover_inputs(folder,mode)['items']
   for item in items:item['scene_override']=['night','food'] if int(Path(item['original_path']).stem.split('-')[-1])<3 else ['day','portrait']
   with LibraryDB(root/f'{mode}.db') as db:
    batch=analyze_inputs(items,mode,cache=db);assert batch['status']=='ok' and batch['counts']['successful']==6,batch
    assert all(row['payload']['photo_scene']['status']=='ok' for row in batch['results'])
    again=analyze_inputs(items,mode,cache=db);assert again['performance']['cache_hits']==6
    identifier=db.save_source_profile(mode,batch);assert db.get_source_profile(identifier)['payload']==batch
   if mode=='raw_xmp':
    assert all(row['payload']['provenance']['raw_decoded'] is False and row['payload']['provenance']['scene_baseline']['decoded'] is True for row in batch['results'])
   dna=dna_from_batch(batch,mode);assert dna['schema_version']==3 and set(dna['scene_profile']['categories'])=={'night','food','day','portrait'},dna['scene_profile']
   assert all(category['sample_count']==3 for category in dna['scene_profile']['categories'].values())
   target=root/f'{mode}-target.jpg';Image.fromarray(fixture_pixels['food']).save(target,quality=99,subsampling=0);source_hashes[target]=sha(target)
   preview=render_preview(target,dna,scene_override=['night','food']);assert preview['scene_style']['status']=='adapted'
   common=render_preview(target,dna,base=preview,scene_override=[]);assert common['scene_style']['status']=='global'
   assert not np.array_equal(preview['rendered'],common['rendered'])
   destination=root/f'{mode}-export.jpg';exported=export_jpeg(target,destination,dna,scene_override=['night','food']);assert exported['scene_style']['status']=='adapted'
   style_path=root/f'{mode}-style.json';export_style_json(style_path,dna);assert load_style_file(style_path)==dna
   changed=set_scene_override(batch,items[0]['id'],[]);assert batch['summary']['scene_stats']['categories']['night']['sample_count']==3 and changed['summary']['scene_stats']['categories']['night']['sample_count']==2
   sparse=dna_from_batch(changed,'Sparse');assert 'night' not in sparse['scene_profile']['categories']
   checks.append({'check':'learn_and_apply_'+mode,'unique_originals':6,'manual_categories':['night','food'],'source_model_evidence':'real bundled classifier','cache_hits':6,'saved_profile_roundtrip':True,'category_json_roundtrip':True,'scene_and_common_pixels_differ':True,'jpeg_category_recipe_applied':True,'two_samples_use_global_fallback':True,'diversity':'controlled generated RAWs / similar reference encodings; not a diverse photo library'})
   learned[mode]=dna
  old=copy.deepcopy(learned['raw_xmp']);old.pop('scene_profile');old.update(schema_version=2,engine_version='0.5.0');snapshot=copy.deepcopy(old)
  upgraded=validate_dna(old);assert upgraded['schema_version']==3 and not upgraded['scene_profile']['enabled'] and old==snapshot
  event=threading.Event();event.set()
  try:classify_photo(fixture_pixels['food'],cancel_event=event)
  except AnalysisCancelledError:pass
  else:raise AssertionError('Pre-cancelled classifier ran')
  assert all(sha(path)==before for path,before in source_hashes.items())
  checks.append({'check':'legacy_privacy_and_cancellation','legacy_upgrade_nonmutating':True,'original_hashes_unchanged':True,'pre_cancel_raises':True,'no_photos_in_report':True})
 result={'ok':True,'app_version':APP_VERSION,'execution':'installed_runtime' if args.installed else 'source_runtime','python_isolated':bool(sys.flags.isolated),'runtime_network':'denied','backend':'opencv_dnn_cpu','model_bundle_id':bundle_id(),'verified_asset_bytes':sum(x['size'] for x in manifest['assets'].values()),'fixtures_redistributed':False,'temporary_files_removed':True,'checks':checks,'limits':'Two visual development fixtures and controlled source variants verify execution and contracts; no all-category, native-camera, aesthetic quality or classification accuracy guarantee.'}
 args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
