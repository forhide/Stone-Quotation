"""Validate offline product/component resolution before comparing app bytes.

Extracting an XAR proves archive integrity, but not that Apple Installer can
resolve its Distribution references. Embedded components use fragment URLs.
"""
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET


def validate_product_references(archive: Path) -> list[dict]:
    """Return resolvable embedded components; reject external/missing packages."""
    archive = Path(archive).resolve(strict=True)
    distribution = ET.parse(archive / 'Distribution').getroot()
    if distribution.tag != 'installer-gui-script':
        raise ValueError('Invalid macOS installer Distribution root.')
    definitions = {}
    for ref in distribution.findall('pkg-ref'):
        identifier = ref.get('id')
        if not identifier:
            raise ValueError('Package reference has no identifier.')
        definitions.setdefault(identifier, []).append(ref)
    if not definitions:
        raise ValueError('Distribution has no component package references.')
    choices = distribution.findall('./choice/pkg-ref')
    if not choices:
        raise ValueError('Distribution choices select no component packages.')
    for choice in choices:
        if choice.get('id') not in definitions:
            raise ValueError('Installer choice references an undefined component.')
    resolved = []
    for identifier, refs in definitions.items():
        locations = {(ref.text or '').strip() for ref in refs if (ref.text or '').strip()}
        if len(locations) != 1:
            raise ValueError(f'Component {identifier} needs one unambiguous package location.')
        location = locations.pop()
        url = urlsplit(location)
        if url.scheme or url.netloc or url.path or url.query or not url.fragment or not location.startswith('#'):
            raise ValueError(f'Component {identifier} must use an embedded fragment URL, not {location!r}.')
        name = unquote(url.fragment)
        relative = PurePosixPath(name)
        if not name or '\\' in name or '\x00' in name or relative.is_absolute() or any(part in {'.', '..'} for part in relative.parts):
            raise ValueError('Unsafe embedded component path.')
        component = (archive / name).resolve()
        if not component.is_relative_to(archive) or not component.exists():
            raise ValueError(f'Embedded component is missing from the product archive: {name}.')
        versions = {ref.get('version') for ref in refs if ref.get('version')}
        if len(versions) > 1:
            raise ValueError('Conflicting component package versions.')
        resolved.append({'identifier': identifier, 'name': name, 'path': component,
                         'version': next(iter(versions), None)})
    return resolved


def validate_component_metadata(reference: dict, component: Path) -> ET.Element:
    """Check a resolved directory after extracting a nested flat component."""
    for name in ('PackageInfo', 'Bom', 'Payload'):
        member = Path(component) / name
        if not member.is_file() or member.stat().st_size == 0:
            raise ValueError(f'Embedded component is missing required installation data: {name}.')
    info = ET.parse(Path(component) / 'PackageInfo').getroot()
    if info.tag != 'pkg-info' or info.get('identifier') != reference['identifier']:
        raise ValueError('Distribution and component identifiers do not match.')
    if reference.get('version') and info.get('version') != reference['version']:
        raise ValueError('Distribution and component versions do not match.')
    if info.find('payload') is None:
        raise ValueError('Component PackageInfo has no payload declaration.')
    return info
