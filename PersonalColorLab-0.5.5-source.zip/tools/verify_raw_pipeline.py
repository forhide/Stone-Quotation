"""Exercise the installed offline RAW/style pipeline with generated sensor data.

No camera photographs are downloaded or redistributed. A deterministic Bayer
DNG validates actual LibRaw execution, orientation, approximation provenance,
preview reuse, strict full-resolution exports and cancellation. This does not
calibrate real cameras, X-Trans/Foveon sensors or Lightroom color rendering.
"""
from __future__ import annotations

import argparse
from contextlib import AbstractContextManager
import hashlib
import json
from pathlib import Path
import socket
import statistics
import sys
import tempfile
import threading
import time

import cv2
import numpy as np
from PIL import Image
import rawpy

if "--installed" not in sys.argv:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.style_dna import builtin_styles, identity_dna
from personal_color_lab.core.style_render import export_jpeg, render_preview
from personal_color_lab.core.synthetic_raw import write_test_dng


def denied(*args, **kwargs):
    raise AssertionError("RAW/style processing attempted network access")


def fingerprint(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class RawCalls(AbstractContextManager):
    """Observe native calls without changing parameters or returned pixels."""

    def __init__(self, cancel_after_postprocess=None):
        self.calls = []
        self.cancel_after_postprocess = cancel_after_postprocess

    def __enter__(self):
        factory = rawpy.RawPy
        observer = self

        class ObservedRaw:
            def __init__(self):
                self.raw = factory()

            def __enter__(self):
                self.raw.__enter__()
                return self

            def __exit__(self, *args):
                return self.raw.__exit__(*args)

            def __getattr__(self, name):
                return getattr(self.raw, name)

            def postprocess(self, **kwargs):
                output = self.raw.postprocess(**kwargs)
                observer.calls.append({"half_size": kwargs.get("half_size", False),
                                       "dimensions": [int(output.shape[1]), int(output.shape[0])]})
                if observer.cancel_after_postprocess is not None:
                    observer.cancel_after_postprocess.set()
                return output

        self.factory = factory
        rawpy.RawPy = ObservedRaw
        return self

    def __exit__(self, *args):
        rawpy.RawPy = self.factory


def cancelled(operation):
    try:
        operation()
    except ValueError as exc:
        assert "cancel" in str(exc).lower(), str(exc)
    else:
        raise AssertionError("A cancelled operation completed")


def approximation_metrics(baseline, interactive):
    assert baseline.shape == interactive.shape
    difference = np.abs(baseline.astype(np.float32) - interactive.astype(np.float32))
    squared = float(np.mean(difference ** 2))
    labs = [cv2.cvtColor(pixels.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
            for pixels in (baseline, interactive)]
    delta = np.linalg.norm(labs[0] - labs[1], axis=2)
    metrics = {"rgb_mean_absolute_byte_error": round(float(difference.mean()), 6),
               "rgb_p95_byte_error": float(np.quantile(difference, .95)),
               "rgb_max_byte_error": float(difference.max()),
               "delta_e76_median": round(float(np.median(delta)), 6),
               "delta_e76_p95": round(float(np.quantile(delta, .95)), 6),
               "delta_e76_max": round(float(delta.max()), 6),
               "psnr_db": round(float(10 * np.log10(255 ** 2 / squared)), 6) if squared else None}
    # Bounds apply only to this generated, mainly smooth chart. Fine color
    # edges can have substantially greater local differences: record the max.
    assert metrics["rgb_mean_absolute_byte_error"] < 2
    assert metrics["rgb_p95_byte_error"] <= 4
    assert metrics["delta_e76_p95"] < 5
    return metrics


def check_orientation(root):
    transforms = {1: lambda image: image, 3: lambda image: np.rot90(image, 2),
                  5: lambda image: np.transpose(image, (1, 0, 2)),
                  6: lambda image: np.rot90(image, -1), 8: lambda image: np.rot90(image)}
    reference = None
    fast_reference = None
    observations = []
    for orientation, transform in transforms.items():
        path = write_test_dng(root / f"orientation-{orientation}.dng", width=960,
                              height=640, orientation=orientation)
        before = fingerprint(path)
        baseline, dimensions, _ = decode_raw(path, max_dimension=1000)
        fast, fast_dimensions, fast_metadata = decode_raw(path, max_dimension=256, quality="interactive")
        fallback, fallback_dimensions, fallback_metadata = decode_raw(path, max_dimension=1000, quality="interactive")
        if orientation == 1:
            reference, fast_reference = baseline, fast
        assert np.array_equal(baseline, transform(reference))
        fast_transform_error = int(np.max(np.abs(fast.astype(int) - transform(fast_reference).astype(int))))
        assert fast_transform_error <= 1
        expected = (640, 960) if orientation in (5, 6, 8) else (960, 640)
        assert dimensions == fast_dimensions == fallback_dimensions == expected
        assert np.array_equal(fallback, baseline)
        assert fast_metadata["quality_used"] == "interactive_half_size"
        assert fast_metadata["full_sensor_size"] == list(expected)
        assert fallback_metadata["quality_used"] == "baseline"
        assert fallback_metadata["preview_is_approximation"] is False
        assert fingerprint(path) == before
        observations.append({"tiff_orientation": orientation, "oriented_full_dimensions": list(expected),
                             "strict_pixel_transform_exact": True,
                             "interactive_pixel_transform_max_error": fast_transform_error,
                             "unavailable_half_size_resolution_falls_back": True})
    return {"check": "orientation_and_resolution_fallback", "observations": observations}


def check_pipeline(root, width, height, repetitions):
    raw = write_test_dng(root / "generated-sensor.dng", width=width, height=height, orientation=6)
    before = fingerprint(raw)
    times = {"baseline": [], "interactive": []}
    decoded = {}
    # Warm both paths; alternate sample order to reduce ordering bias. These
    # are same-process, warm-file-cache timings, not native OS benchmarks.
    for quality in times:
        decode_raw(raw, max_dimension=1200, quality=quality)
    for sample in range(repetitions):
        order = ("baseline", "interactive") if sample % 2 == 0 else ("interactive", "baseline")
        for quality in order:
            start = time.perf_counter()
            decoded[quality] = decode_raw(raw, max_dimension=1200, quality=quality)
            times[quality].append(time.perf_counter() - start)
    baseline, dimensions, metadata = decoded["baseline"]
    interactive, fast_dimensions, fast_metadata = decoded["interactive"]
    assert dimensions == fast_dimensions == (height, width)
    assert metadata["quality_used"] == "baseline" and metadata["half_size"] is False
    assert fast_metadata["quality_used"] == "interactive_half_size" and fast_metadata["half_size"] is True
    assert fast_metadata["preview_is_approximation"] is True
    assert fast_metadata["embedded_preview_used"] is False
    assert metadata["white_balance_source"] == fast_metadata["white_balance_source"] == "camera"
    assert metadata["gamma"] == fast_metadata["gamma"] == [2.4, 12.92]
    assert "gps" not in json.dumps([metadata, fast_metadata]).lower()
    medians = {quality: statistics.median(samples) for quality, samples in times.items()}
    checks = [{"check": "generated_sensor_strict_vs_interactive", "fixture_sha256": before,
               "sensor_dimensions": [width, height], "oriented_full_dimensions": list(dimensions),
               "comparison_dimensions": [int(baseline.shape[1]), int(baseline.shape[0])],
               "quality": approximation_metrics(baseline, interactive),
               "median_seconds": {quality: round(value, 6) for quality, value in medians.items()},
               "baseline_to_interactive_speed_ratio": round(medians["baseline"] / medians["interactive"], 3),
               "repetitions": repetitions, "timing": "same process; warm native paths and file cache; alternating order"}]
    neutral = identity_dna()
    with RawCalls() as calls:
        preview = render_preview(raw, neutral, raw_quality="baseline")
    assert len(calls.calls) == 1 and calls.calls[0]["half_size"] is False
    assert np.array_equal(preview["original"], preview["rendered"])
    with RawCalls() as calls:
        fast_preview = render_preview(raw, neutral, raw_quality="interactive", base=preview)
    assert len(calls.calls) == 1 and calls.calls[0]["half_size"] is True
    assert fast_preview["raw_decode"]["preview_is_approximation"] is True
    with RawCalls() as calls:
        strict_again = render_preview(raw, neutral, raw_quality="baseline", base=fast_preview)
    assert len(calls.calls) == 1 and calls.calls[0]["half_size"] is False
    assert np.array_equal(strict_again["original"], preview["original"])
    with RawCalls() as calls:
        render_preview(raw, builtin_styles()[4], base=strict_again, raw_quality="baseline")
    assert not calls.calls
    checks.append({"check": "neutral_preview_and_base_reuse", "neutral_pixels_exact": True,
                   "quality_changes_invalidate_decoded_base": True,
                   "same_quality_style_change_reuses_decoded_base": True})
    for name, dna in (("neutral", neutral), ("monochrome", builtin_styles()[3])):
        destination = root / f"{name}.jpg"
        with RawCalls() as calls:
            exported = export_jpeg(raw, destination, dna, expected_fingerprint=before)
        assert len(calls.calls) == 1, calls.calls
        assert calls.calls[0]["half_size"] is False
        assert calls.calls[0]["dimensions"] == [height, width]
        assert exported["dimensions"] == [height, width]
        assert exported["source_unchanged"] is True and exported["gps_exported"] is False
        with Image.open(destination) as image:
            assert image.size == (height, width) and not image.getexif()
            assert image.info.get("icc_profile")
            if name == "monochrome":
                spread = int(np.ptp(np.asarray(image.convert("RGB")).astype(int), axis=2).max())
                assert spread <= 1, spread
        assert fingerprint(raw) == before
        checks.append({"check": f"full_resolution_{name}_export", "dimensions": [height, width],
                       "native_postprocess_calls": len(calls.calls), "baseline_full_sensor_decode": True,
                       "gps_exif_removed": True, "srgb_profile_embedded": True, "source_unchanged": True})
    event = threading.Event()
    event.set()
    with RawCalls() as calls:
        cancelled(lambda: decode_raw(raw, cancel_event=event))
        cancelled(lambda: render_preview(raw, neutral, cancel_event=event))
        cancelled(lambda: export_jpeg(raw, root / "cancelled-before.jpg", neutral, cancel_event=event))
    assert not calls.calls and not (root / "cancelled-before.jpg").exists()
    event.clear()
    with RawCalls(cancel_after_postprocess=event) as calls:
        cancelled(lambda: export_jpeg(raw, root / "cancelled-after.jpg", neutral, cancel_event=event))
    assert len(calls.calls) == 1 and not (root / "cancelled-after.jpg").exists()
    assert not list(root.glob(".pcl-export-*.tmp"))
    assert fingerprint(raw) == before
    checks.append({"check": "cancellation_and_source_preservation", "pre_cancel_skips_native_decode": True,
                   "cancel_after_native_decode_stops_export": True, "no_partial_output": True,
                   "source_unchanged": True, "native_libraw_call_is_not_interruptible": True})
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--installed", action="store_true", help="Use only the installed runtime package")
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--sensor-width", type=int, default=3200)
    parser.add_argument("--sensor-height", type=int, default=2400)
    parser.add_argument("--repetitions", type=int, default=3)
    args = parser.parse_args()
    if (not 2400 <= args.sensor_width <= 6000 or not 1600 <= args.sensor_height <= 4000
            or args.sensor_width % 2 or args.sensor_height % 2 or not 1 <= args.repetitions <= 9):
        parser.error("Use even sensor dimensions within 2400..6000 by 1600..4000 and 1..9 repetitions")
    socket.socket = denied
    socket.create_connection = denied
    with tempfile.TemporaryDirectory(prefix="pcl-raw-validation-") as directory:
        root = Path(directory)
        checks = [check_orientation(root)]
        checks.extend(check_pipeline(root, args.sensor_width, args.sensor_height, args.repetitions))
    result = {"ok": True, "app_version": APP_VERSION,
              "execution": "installed_runtime" if args.installed else "source_runtime",
              "runtime_network": "denied", "fixture": "generated deterministic Bayer CFA DNG",
              "user_photos_used": False, "temporary_files_removed": True,
              "rawpy_version": str(rawpy.__version__), "libraw_version": list(rawpy.libraw_version),
              "checks": checks,
              "limits": "Synthetic ordinary Bayer sensor only; not camera/X-Trans/Foveon calibration, Lightroom equivalence, native Mac installation or a whole-app speed claim."}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, allow_nan=False))


if __name__ == "__main__":
    main()
