"""Build-only download of pinned OpenCV Zoo ONNX assets; never used at runtime."""
from pathlib import Path
import hashlib
import json
import urllib.request

ROOT = Path(__file__).resolve().parents[1] / 'personal_color_lab/assets/models'
COMMIT = '47534e27c9851bb1128ccc0102f1145e27f23f98'
MODELS = (
    ('nanodet', 'object_detection_nanodet', 'object_detection_nanodet_2022nov_int8bq.onnx'),
    ('humanseg', 'human_segmentation_pphumanseg', 'human_segmentation_pphumanseg_2023mar_int8bq.onnx'),
    ('yunet', 'face_detection_yunet', 'face_detection_yunet_2023mar.onnx'),
)


def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    entries = []
    for identifier, folder, filename in MODELS:
        relative = f'models/{folder}/{filename}'
        with urllib.request.urlopen(f'https://raw.githubusercontent.com/opencv/opencv_zoo/{COMMIT}/{relative}', timeout=30) as response:
            pointer = response.read(1024).decode()
        digest = next(line.split(':', 1)[1] for line in pointer.splitlines() if line.startswith('oid sha256:'))
        size = int(next(line.split()[1] for line in pointer.splitlines() if line.startswith('size ')))
        with urllib.request.urlopen(f'https://raw.githubusercontent.com/opencv/opencv_zoo/{COMMIT}/models/{folder}/LICENSE', timeout=30) as response:
            license_data = response.read(100_000)
        license_name = identifier + '-LICENSE.txt'
        (ROOT / license_name).write_bytes(license_data)
        entries.append({'id': identifier, 'filename': identifier + '.onnx', 'sha256': digest, 'size': size,
                        'upstream': f'https://media.githubusercontent.com/media/opencv/opencv_zoo/{COMMIT}/{relative}',
                        'upstream_commit': COMMIT, 'license': license_name,
                        'license_sha256': hashlib.sha256(license_data).hexdigest()})
    (ROOT / 'manifest.json').write_text(json.dumps({'schema_version': 1, 'models': entries}, indent=2) + '\n')
    (ROOT / 'NOTICE.txt').write_text('NanoDet/PPHumanSeg and adapted decoding: Apache License 2.0. YuNet: MIT License.\nUpstream commit ' + COMMIT + '. Model-specific license notices are retained.\nPPHumanSeg: Copyright (C) 2021 Shenzhen Institute of Artificial Intelligence and Robotics for Society.\nNanoDet: RangiLyu/nanodet and OpenCV decoder contributor Sri Siddarth Chakaravarthy (GSoC 2022).\nYuNet: Shiqi Yu and OpenCV contributors. Face detection only; no identity recognition or embeddings.\n')
    import sys
    if '--metadata-only' in sys.argv:
        return
    for entry in entries:
        destination = ROOT / entry['filename']
        if destination.exists() and destination.stat().st_size == entry['size'] and hashlib.sha256(destination.read_bytes()).hexdigest() == entry['sha256']:
            continue
        with urllib.request.urlopen(entry['upstream'], timeout=45) as response:
            data = response.read(entry['size'] + 1)
        if len(data) != entry['size'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise ValueError('Official Git LFS SHA-256/size mismatch: ' + entry['id'])
        destination.write_bytes(data)
        print('Verified', entry['id'], entry['size'], flush=True)


if __name__ == '__main__':
    main()
