"""Verified, offline Lensfun camera/lens identities and distortion profiles.

The database is distributed separately under CC BY-SA 3.0, with its original
XML and attribution intact. Matching deliberately uses exact identities and
published aliases, rather than guessing from a focal range or numeric lens ID.
Only rectilinear radial distortion is supported; vignetting/TCA are untouched.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import threading
import unicodedata
import xml.etree.ElementTree as ET


LENS_ROOT = Path(__file__).resolve().parents[1] / 'assets/lensfun'
SUPPORTED_MODELS = {'poly3': ('k1',), 'poly5': ('k1', 'k2'), 'ptlens': ('a', 'b', 'c')}
_LOCK = threading.RLock()
_DATABASE_CACHE = {}


class LensProfileUnavailableError(ValueError):
    """A bundled lens database cannot be verified or safely interpreted."""


def _digest(data):
    return hashlib.sha256(data).hexdigest()


def _valid_digest(value):
    return isinstance(value, str) and bool(re.fullmatch(r'[0-9a-f]{64}', value))


def _regular(root, relative):
    path = Path(relative)
    if (not isinstance(relative, str) or path.is_absolute() or '..' in path.parts
            or not path.parts or any(part in ('', '.') for part in path.parts)):
        raise LensProfileUnavailableError('Invalid bundled lens asset path.')
    result = root / path
    if any((root / Path(*path.parts[:i])).is_symlink() for i in range(1, len(path.parts) + 1)):
        raise LensProfileUnavailableError('Bundled lens assets must be regular files.')
    if not result.is_file():
        raise LensProfileUnavailableError('Bundled lens asset is missing.')
    return result


def verify_lens_profiles(root=None):
    """Hash the complete installed XML/license bundle, without any network path."""
    root = Path(root or LENS_ROOT)
    try:
        if root.is_symlink():
            raise ValueError('Lens database directory must be regular.')
        manifest = json.loads(_regular(root, 'manifest.json').read_text(encoding='utf-8'))
        if type(manifest.get('schema_version')) is not int or manifest['schema_version'] != 1:
            raise ValueError('Unsupported lens database manifest.')
        entries = manifest['files']
        if not isinstance(entries, list) or not 2 <= len(entries) <= 250:
            raise ValueError('Invalid lens database inventory.')
        names = [entry['filename'] for entry in entries]
        if len(names) != len(set(names)) or 'COPYING.CC_BY-SA_3.0' not in names:
            raise ValueError('Lens database attribution is missing.')
        xml_names = {name for name in names if name.startswith('db/') and name.endswith('.xml')}
        if not xml_names or xml_names != {str(path.relative_to(root)).replace('\\', '/') for path in (root / 'db').glob('*.xml')}:
            raise ValueError('Lens database XML inventory differs from its manifest.')
        for entry in entries:
            size = entry['size']
            if type(size) is not int or not 1 <= size <= 10_000_000 or not _valid_digest(entry['sha256']):
                raise ValueError('Invalid lens asset checksum or length.')
            path = _regular(root, entry['filename'])
            if path.stat().st_size != size or _digest(path.read_bytes()) != entry['sha256']:
                raise ValueError('Lens asset checksum mismatch.')
        database = _parse_database(root, manifest)
        return dict(manifest, bundle_id=database['bundle_id'], stats={
            'xml_files': len(xml_names), 'camera_entries': len(database['cameras']),
            'lens_entries': len(database['lenses']),
            'distortion_calibrations': sum(len(calibration['points']) for lens in database['lenses']
                                          for calibration in lens['calibrations']),
            'asset_bytes': sum(entry['size'] for entry in entries),
        })
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        if isinstance(exc, LensProfileUnavailableError):
            raise
        raise LensProfileUnavailableError('The bundled lens profiles are unavailable or corrupt.') from exc


def _signature(root):
    paths = [_regular(root, 'manifest.json')]
    paths.extend(sorted((root / 'db').glob('*.xml')))
    paths.append(_regular(root, 'COPYING.CC_BY-SA_3.0'))
    return tuple((str(path), path.stat().st_size, path.stat().st_mtime_ns,
                  path.stat().st_ctime_ns, path.stat().st_ino, path.is_symlink()) for path in paths)


def _number(value, default=None):
    if value is None or value == '':
        return default
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return number if math.isfinite(number) else None


def _aspect(value, default=1.5):
    if not value:
        return default
    values = value.split(':')
    if len(values) == 2:
        first, second = (_number(part) for part in values)
        result = first / second if first and second and first > 0 and second > 0 else None
    else:
        result = _number(value)
    return max(result, 1 / result) if result and result > 0 else None


def _texts(node, tag):
    return tuple(dict.fromkeys(child.text.strip() for child in node.findall(tag) if child.text and child.text.strip()))


def _key(text):
    if not isinstance(text, str):
        return ''
    value = unicodedata.normalize('NFKC', text).casefold().strip()
    value = value.replace('–', '-').replace('−', '-')
    # f2.8 and f/2.8 are notation variants, not alternate optical identities.
    value = re.sub(r'\bf\s*(?=\d)', 'f/', value)
    return re.sub(r'\s+', '', value)


def _maker_key(text):
    value = _key(text)
    return {'nikoncorporation': 'nikon', 'nikoncorp.': 'nikon',
            'olympusimagingcorp.': 'olympus', 'olympuscorporation': 'olympus',
            'olympusopticalco.,ltd': 'olympus', 'eastmankodakcompany': 'kodak',
            'canoninc.': 'canon', 'sonycorporation': 'sony',
            'ricohimagingcompany,ltd.': 'ricoh'}.get(value, value)


def _model_keys(model, makers):
    result = {_key(model)}
    for maker in makers:
        prefix = _key(maker)
        if prefix and _key(model).startswith(prefix):
            result.add(_key(model)[len(prefix):])
    return result - {''}


def _parse_database(root, manifest):
    cameras, lenses, mounts = [], [], {}
    bundle_id = _digest(json.dumps(sorted((entry['filename'], entry['sha256']) for entry in manifest['files']),
                                   separators=(',', ':')).encode())
    for entry in manifest['files']:
        filename = entry['filename']
        if not filename.startswith('db/') or not filename.endswith('.xml'):
            continue
        data = (root / filename).read_bytes()
        if b'<!ENTITY' in data:
            raise LensProfileUnavailableError('XML entity declarations are unsupported.')
        try:
            document = ET.fromstring(data)
        except ET.ParseError as exc:
            raise LensProfileUnavailableError('Cannot parse bundled lens database.') from exc
        if document.tag != 'lensdatabase':
            raise LensProfileUnavailableError('Unexpected lens database format.')
        for node in document.findall('mount'):
            name = node.findtext('name')
            if name:
                mounts.setdefault(name.strip(), set()).update(_texts(node, 'compat'))
        for node in document.findall('camera'):
            makers, models = _texts(node, 'maker'), _texts(node, 'model')
            crop = _number(node.findtext('cropfactor'))
            if not makers or not models or not crop or not .3 <= crop <= 30:
                continue
            cameras.append({'makers': makers, 'models': models, 'mount': node.findtext('mount', '').strip(),
                            'crop_factor': crop, 'aspect': _aspect(node.findtext('aspect-ratio'), None),
                            'variant': node.findtext('variant', '').strip()})
        for node in document.findall('lens'):
            makers, models = _texts(node, 'maker'), _texts(node, 'model')
            crop = _number(node.findtext('cropfactor'))
            aspect = _aspect(node.findtext('aspect-ratio'))
            if not makers or not models or not crop or not .3 <= crop <= 30 or not aspect:
                continue
            calibrations = []
            for calibration in node.findall('calibration'):
                calibration_crop = _number(calibration.get('cropfactor'), crop)
                calibration_aspect = _aspect(calibration.get('aspect-ratio'), aspect)
                points = []
                for distortion in calibration.findall('distortion'):
                    model = distortion.get('model', '')
                    focal = _number(distortion.get('focal'))
                    real_focal = _number(distortion.get('real-focal'), focal)
                    fields = SUPPORTED_MODELS.get(model, ())
                    coefficients = [_number(distortion.get(field), 0.) for field in fields]
                    valid = (model in SUPPORTED_MODELS and focal and .5 <= focal <= 2000
                             and real_focal and .5 <= real_focal <= 2000
                             and all(value is not None and abs(value) <= 10 for value in coefficients))
                    points.append({'model': model, 'focal': focal, 'real_focal': real_focal,
                                   'coefficients': coefficients, 'valid': bool(valid)})
                calibrations.append({'crop_factor': calibration_crop, 'aspect': calibration_aspect, 'points': points})
            identifier = _digest((filename + '\n' + '\n'.join(makers + models)
                                  + '\n' + ET.tostring(node, encoding='unicode')).encode())
            lenses.append({'makers': makers, 'models': models, 'mounts': _texts(node, 'mount'),
                           'type': node.findtext('type', 'rectilinear').strip(),
                           'calibrations': calibrations, 'profile_id': identifier, 'source_file': filename,
                           'noncentral': node.find('center') is not None})
    return {'cameras': cameras, 'lenses': lenses, 'mounts': mounts,
            'bundle_id': bundle_id, 'source': manifest.get('source', {})}


def _database(root=None):
    root = Path(root or LENS_ROOT)
    if root.is_symlink():
        raise LensProfileUnavailableError('Lens database directory must be regular.')
    root = root.resolve()
    with _LOCK:
        signature = _signature(root)
        cached = _DATABASE_CACHE.get(str(root))
        if cached and cached[0] == signature:
            return cached[1]
        manifest = verify_lens_profiles(root)
        database = _parse_database(root, manifest)
        if _signature(root) != signature:
            raise LensProfileUnavailableError('Bundled lens data changed during verification.')
        # At most the shipped bundle plus a few validation/test roots are kept.
        if len(_DATABASE_CACHE) >= 8:
            _DATABASE_CACHE.clear()
        _DATABASE_CACHE[str(root)] = signature, database
        return database


def lens_bundle_id(root=None):
    return _database(root)['bundle_id']


def _selection_name(value):
    if (not isinstance(value, str) or not value.strip() or len(value) > 200
            or any(unicodedata.category(character).startswith('C') for character in value)):
        raise ValueError('Camera/lens selection names must be bounded printable text.')
    return value.strip()


def validate_lens_override(value):
    """Validate explicit manual equipment identity without inventing a profile.

    All four identity fields are required. Optional focal length replaces EXIF
    only when explicitly supplied; None/omission retains the detected focal.
    Unknown identities are permitted as honest selections, then the resolver
    returns an unavailable profile. Additional metadata (including GPS/serials)
    is rejected. This validator never loads a database or accesses the network.
    """
    if value is None:
        return None
    identity = ('camera_make', 'camera_model', 'lens_make', 'lens_model')
    if (not isinstance(value, dict) or set(value) - set(identity) - {'focal_length_mm'}
            or any(field not in value for field in identity)):
        raise ValueError('Manual equipment selection requires exact camera and lens identity fields.')
    result = {field: _selection_name(value[field]) for field in identity}
    if value.get('focal_length_mm') is not None:
        focal = value['focal_length_mm']
        numeric = _number(focal)
        if (isinstance(focal, bool) or not isinstance(focal, (int, float))
                or numeric is None or not .5 <= numeric <= 2000):
            raise ValueError('Manual focal length must be finite and between 0.5 and 2000 mm.')
        result['focal_length_mm'] = numeric
    return result


def equipment_for_selection(raw_metadata, override):
    """Return whitelisted metadata with explicit manual identity provenance.

    Embedded-correction flags and orientation survive a manual selection: a
    chosen lens does not make uncertain embedded geometric instructions safe.
    Neither the original metadata nor the caller's override is modified.
    """
    if not isinstance(raw_metadata, dict):
        raise ValueError('Detected equipment metadata must be a dictionary.')
    fields = ('schema_version', 'metadata_extractor', 'extractor_version',
              'camera_make', 'camera_model', 'lens_make', 'lens_model',
              'focal_length_mm', 'aperture', 'crop_factor', 'crop_factor_source',
              'orientation', 'embedded_dng_opcodes_present', 'embedded_distortion',
              'metadata_status', 'metadata_sources', 'warnings')
    result = {field: raw_metadata[field] for field in fields if field in raw_metadata}
    sources = raw_metadata.get('metadata_sources')
    result['metadata_sources'] = {field: source for field, source in sources.items() if field in fields} if isinstance(sources, dict) else {}
    warnings = raw_metadata.get('warnings')
    result['warnings'] = list(warnings) if isinstance(warnings, list) else []
    selected = validate_lens_override(override)
    if selected is not None:
        result.update(selected)
        result['metadata_sources'].update({field: 'manual' for field in selected})
        result['metadata_status'] = 'manual_selection'
    return result


def _equipment_label(maker, model):
    return model if _key(model).startswith(_key(maker)) else maker + ' ' + model


def equipment_catalog(camera_make=None, camera_model=None, *, root=None):
    """List published identities for an offline manual equipment selector.

    Canonical models retain all version suffixes. In particular an absent
    Sony FE 16-35mm F2.8 GM II never substitutes the first-generation GM. With
    an exact chosen camera, lens choices are restricted to compatible mounts.
    `calibrated` states whether supported distortion data covers that sensor;
    the selected RAW focal length is still validated later by the resolver.
    Database errors propagate, allowing the UI to show an unavailable catalog.
    """
    if camera_make is not None:
        camera_make = _selection_name(camera_make)
    if camera_model is not None:
        camera_model = _selection_name(camera_model)
    database = _database(root)
    cameras = database['cameras']
    camera_list = []
    seen_cameras = set()
    for camera in cameras:
        if camera_make and _maker_key(camera_make) not in {_maker_key(value) for value in camera['makers']}:
            continue
        maker, model = camera['makers'][0], camera['models'][0]
        if (maker, model) in seen_cameras:
            continue
        seen_cameras.add((maker, model))
        camera_list.append({'camera_make': maker, 'camera_model': model,
                            'label': _equipment_label(maker, model)})
    selected_cameras = ([camera for camera in cameras if _identity_matches(camera_make, camera_model, camera)]
                        if camera_make and camera_model else None)
    allowed_mounts = None
    if selected_cameras is not None:
        allowed_mounts = set()
        for camera in selected_cameras:
            allowed_mounts.update({camera['mount']} | database['mounts'].get(camera['mount'], set()))
    lens_list = []
    seen_lenses = {}
    for lens in database['lenses']:
        if allowed_mounts is not None and not allowed_mounts.intersection(lens['mounts']):
            continue
        calibrated = lens['type'] in ('rectilinear', '') and not lens['noncentral'] and any(
            calibration['points'] and all(point['valid'] for point in calibration['points'])
            and len({point['model'] for point in calibration['points']}) == 1
            and calibration['crop_factor'] and calibration['aspect']
            and (selected_cameras is None or any(camera['crop_factor'] / calibration['crop_factor'] >= .96
                                                 for camera in selected_cameras))
            for calibration in lens['calibrations'])
        maker, model = lens['makers'][0], lens['models'][0]
        if (maker, model) in seen_lenses:
            # Duplicate optical identities remain ambiguous in the resolver.
            seen_lenses[(maker, model)]['calibrated'] = False
            continue
        entry = {'lens_make': maker, 'lens_model': model,
                 'label': _equipment_label(maker, model), 'calibrated': bool(calibrated)}
        seen_lenses[(maker, model)] = entry
        lens_list.append(entry)
    camera_list.sort(key=lambda item: item['label'].casefold())
    lens_list.sort(key=lambda item: item['label'].casefold())
    return {'cameras': camera_list, 'lenses': lens_list, 'bundle_id': database['bundle_id']}


def _identity_matches(maker, model, item):
    if maker and _maker_key(maker) not in {_maker_key(value) for value in item['makers']}:
        return False
    query = _model_keys(model, item['makers'] + ((maker,) if maker else ()))
    return bool(query & set().union(*(_model_keys(value, item['makers']) for value in item['models'])))


def _hermite(values, t):
    """Standard cubic Hermite basis; published Lensfun neighbor convention."""
    previous, lower, upper, following = values
    left_tangent = upper - lower if previous is None else (upper - previous) / 2
    right_tangent = upper - lower if following is None else (following - lower) / 2
    return ((2 * t**3 - 3 * t**2 + 1) * lower + (t**3 - 2 * t**2 + t) * left_tangent
            + (-2 * t**3 + 3 * t**2) * upper + (t**3 - t**2) * right_tangent)


def _interpolate(points, focal):
    if not points or any(not point['valid'] for point in points):
        return None, 'unsupported'
    if len({point['model'] for point in points}) != 1:
        return None, 'unsupported'
    ordered = sorted(points, key=lambda point: point['focal'])
    if len({point['focal'] for point in ordered}) != len(ordered):
        return None, 'ambiguous'
    for point in ordered:
        if math.isclose(point['focal'], focal, rel_tol=0., abs_tol=1e-5):
            return dict(point, interpolation='exact', calibration_focals=[point['focal']]), None
    # Unlike Lensfun's endpoint fallback, never extrapolate unmeasured fields.
    if focal < ordered[0]['focal'] or focal > ordered[-1]['focal']:
        return None, 'focal_out_of_range'
    upper = next(index for index, point in enumerate(ordered) if point['focal'] > focal)
    neighbors = [ordered[upper - 2] if upper >= 2 else None, ordered[upper - 1], ordered[upper],
                 ordered[upper + 1] if upper + 1 < len(ordered) else None]
    t = (focal - neighbors[1]['focal']) / (neighbors[2]['focal'] - neighbors[1]['focal'])
    coefficients = [_hermite([point['coefficients'][index] * point['focal'] if point else None for point in neighbors], t) / focal
                    for index in range(len(neighbors[1]['coefficients']))]
    real_focal = _hermite([point['real_focal'] if point else None for point in neighbors], t)
    if not all(math.isfinite(value) and abs(value) <= 10 for value in coefficients) or not .5 <= real_focal <= 2000:
        return None, 'unsupported'
    return {'model': ordered[0]['model'], 'focal': focal, 'real_focal': real_focal,
            'coefficients': coefficients, 'interpolation': 'lensfun_focal_scaled_hermite',
            'calibration_focals': [point['focal'] for point in neighbors if point]}, None


def resolve_lens_profile(metadata, *, root=None):
    """Resolve a verified exact camera/lens pair or return a safe skip reason.

    Approximate EXIF 35mm/focal crop ratios are deliberately ignored. Camera
    crop comes from the exact camera database entry. Embedded DNG opcode lists
    are not interpreted and prevent a second, potentially duplicate correction.
    """
    if not isinstance(metadata, dict):
        raise ValueError('Camera/lens metadata must be a dictionary.')
    result = {'available': False, 'status': 'metadata_missing', 'applied': False,
              'camera_make': metadata.get('camera_make'), 'camera_model': metadata.get('camera_model'),
              'lens_make': metadata.get('lens_make'), 'lens_model': metadata.get('lens_model'),
              'focal_length_mm': _number(metadata.get('focal_length_mm')), 'corrections': ['distortion'],
              'orientation': metadata.get('orientation'), 'bundle_id': None}
    if (metadata.get('embedded_dng_opcodes_present') or metadata.get('embedded_distortion')
            or metadata.get('embedded_correction_metadata_present')):
        return dict(result, status='embedded_correction')
    if not all(isinstance(metadata.get(field), str) and metadata[field].strip()
               for field in ('camera_make', 'camera_model', 'lens_model')) or not result['focal_length_mm']:
        return result
    try:
        database = _database(root)
    except (LensProfileUnavailableError, OSError, ValueError) as exc:
        return dict(result, status='database_unavailable', error=type(exc).__name__)
    result['bundle_id'] = database['bundle_id']
    cameras = [camera for camera in database['cameras']
               if _identity_matches(metadata['camera_make'], metadata['camera_model'], camera)]
    if not cameras:
        return dict(result, status='camera_not_found')
    geometries = {(camera['mount'], camera['crop_factor'], camera['aspect'], camera['variant']) for camera in cameras}
    if len(geometries) != 1 or any(camera['variant'] for camera in cameras):
        return dict(result, status='ambiguous')
    camera = cameras[0]
    compatible = {camera['mount']} | database['mounts'].get(camera['mount'], set())
    lenses = [lens for lens in database['lenses']
              if _identity_matches(metadata.get('lens_make'), metadata['lens_model'], lens)]
    if not lenses:
        return dict(result, status='lens_not_found')
    lenses = [lens for lens in lenses if compatible & set(lens['mounts'])]
    if not lenses:
        return dict(result, status='mount_mismatch')
    if len(lenses) != 1:
        return dict(result, status='ambiguous')
    lens = lenses[0]
    result.update({'camera_make': camera['makers'][0], 'camera_model': camera['models'][0],
                   'lens_make': lens['makers'][0], 'lens_model': lens['models'][0], 'camera_mount': camera['mount'],
                   'camera_crop_factor': camera['crop_factor'], 'camera_aspect': camera['aspect'],
                   'crop_factor_source': 'lensfun_camera_database', 'profile_id': lens['profile_id'],
                   'geometry_assumption': 'full_active_camera_sensor',
                   'source_file': lens['source_file'], 'database_source': database['source']})
    if lens['type'] not in ('rectilinear', '') or lens['noncentral']:
        return dict(result, status='unsupported')
    sets = [calibration for calibration in lens['calibrations'] if calibration['points']
            and calibration['crop_factor'] and calibration['aspect']
            and camera['crop_factor'] / calibration['crop_factor'] >= .96]
    if not sets:
        return dict(result, status='uncalibrated')
    calibration = min(sets, key=lambda item: camera['crop_factor'] / item['crop_factor'])
    if sum(item['crop_factor'] == calibration['crop_factor'] for item in sets) != 1:
        return dict(result, status='ambiguous')
    point, reason = _interpolate(calibration['points'], result['focal_length_mm'])
    if reason:
        return dict(result, status=reason)
    result.update({'available': True, 'status': 'matched', 'distortion_model': point['model'],
                   'coefficients': point['coefficients'], 'calibration_crop_factor': calibration['crop_factor'],
                   'calibration_aspect': calibration['aspect'], 'real_focal_length_mm': point['real_focal'],
                   'interpolation': point['interpolation'], 'calibration_focals': point['calibration_focals']})
    return result
