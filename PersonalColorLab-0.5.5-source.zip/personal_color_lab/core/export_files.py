"""Write completed exports as new files without touching existing outputs.

Encoding happens in a private sibling file. Publication uses an exclusive
rename on Windows or an exclusive hard link where supported. Filesystems
without hard links use an exclusive, cancellable copy of the completed data.
The fallback never replaces another file, and ordinary failure/cancellation
removes only the file created by this operation.
"""
from __future__ import annotations

import errno
import os
from pathlib import Path
import tempfile


class ExportCancelledError(ValueError):
    """The user stopped an export before publication completed."""


def _check_cancel(cancel_event):
    if cancel_event is not None and cancel_event.is_set():
        raise ExportCancelledError('Style operation cancelled.')


def _remove_owned(path, identity):
    try:
        current = path.stat(follow_symlinks=False)
        if (current.st_dev, current.st_ino) == identity:
            path.unlink()
    except FileNotFoundError:
        pass


def _publish_copy(temporary, destination, cancel_event):
    """Fallback for FAT/exFAT and other filesystems without hard links."""
    identity = None
    try:
        with destination.open('xb') as output:
            info = os.fstat(output.fileno())
            identity = (info.st_dev, info.st_ino)
            with temporary.open('rb') as source:
                while True:
                    _check_cancel(cancel_event)
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
            output.flush()
            _check_cancel(cancel_event)
    except BaseException:
        if identity is not None:
            _remove_owned(destination, identity)
        raise


def write_new(path, writer, cancel_event=None):
    destination = Path(path).expanduser().absolute()
    _check_cancel(cancel_event)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(errno.EEXIST, os.strerror(errno.EEXIST), str(destination))
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w+b', dir=destination.parent,
                                         prefix='.pcl-export-', suffix='.tmp', delete=False) as stream:
            temporary = Path(stream.name)
            writer(stream)
            stream.flush()
            _check_cancel(cancel_event)
        # Final name appears only after encoding has completed. A concurrent
        # creator wins without ever having its file replaced by this export.
        if os.name == 'nt':
            _check_cancel(cancel_event)
            os.rename(temporary, destination)
        else:
            _check_cancel(cancel_event)
            try:
                os.link(temporary, destination)
            except OSError as exc:
                unsupported = {errno.EPERM, errno.EXDEV, errno.ENOSYS,
                               errno.EOPNOTSUPP, errno.ENOTSUP}
                if exc.errno not in unsupported:
                    raise
                _publish_copy(temporary, destination, cancel_event)
        return destination
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
