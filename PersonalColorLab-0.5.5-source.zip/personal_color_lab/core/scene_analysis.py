"""Object evidence, person segmentation and face protection from local ONNX.

COCO object boxes are regions of interest, not instance segmentation. People
use PP-HumanSeg pixels. Face ellipses are detection-based protection guides.
No names, identities, face embeddings or original image arrays are persisted.
"""
from __future__ import annotations
import math
import cv2
import numpy as np
from .semantic_models import infer, detect_faces, bundle_id, ModelUnavailableError
from .analysis_control import AnalysisCancelledError

CLASSES = tuple('person,bicycle,car,motorcycle,airplane,bus,train,truck,boat,traffic_light,fire_hydrant,stop_sign,parking_meter,bench,bird,cat,dog,horse,sheep,cow,elephant,bear,zebra,giraffe,backpack,umbrella,handbag,tie,suitcase,frisbee,skis,snowboard,sports_ball,kite,baseball_bat,baseball_glove,skateboard,surfboard,tennis_racket,bottle,wine_glass,cup,fork,knife,spoon,bowl,banana,apple,sandwich,orange,broccoli,carrot,hot_dog,pizza,donut,cake,chair,couch,potted_plant,bed,dining_table,toilet,tv,laptop,mouse,remote,keyboard,cell_phone,microwave,oven,toaster,sink,refrigerator,book,clock,vase,scissors,teddy_bear,hair_drier,toothbrush'.split(','))
REGIONS = ('person','face','food','animal','vehicle','plant','background')
GROUPS = {'food':set(range(46,56)), 'animal':set(range(14,24)), 'vehicle':set(range(1,9)), 'plant':{58}}
MODEL_VERSION = 'opencv-zoo-47534e27-int8bq-v1'
_REGION_METHODS = {r: 'person_segmentation' if r == 'person' else 'face_detection_ellipse' if r == 'face' else 'remaining_background' if r == 'background' else 'object_box_roi' for r in REGIONS}


def _cancel(event):
    if event is not None and event.is_set():
        raise AnalysisCancelledError('Recognition cancelled.')


def decode_objects(outputs, threshold=.45):
    if len(outputs) != 6:
        raise ValueError('Unexpected NanoDet outputs')
    boxes, scores, classes = [], [], []
    for stride, class_output, distance_output in zip((8,16,32), outputs[::2], outputs[1::2]):
        cls = class_output.reshape(-1,80)
        distances = distance_output.reshape(-1,4,8).astype(np.float32)
        if not np.isfinite(cls).all() or not np.isfinite(distances).all() or cls.min() < 0 or cls.max() > 1:
            raise ValueError('Nonfinite model output')
        dim = 416//stride
        if len(cls) != dim*dim or len(distances) != len(cls):
            raise ValueError('Unexpected anchor dimensions')
        identifiers = cls.argmax(axis=1);confidence=cls.max(axis=1)
        selected = np.flatnonzero(confidence>=threshold)
        if not len(selected):
            continue
        # The score threshold is independent of box regression. Decode only
        # surviving anchors, while validating *all* model outputs above.
        distances = distances[selected]
        distances -= distances.max(axis=2,keepdims=True)
        probabilities = np.exp(distances); probabilities /= probabilities.sum(axis=2,keepdims=True)
        distances = (probabilities @ np.arange(8,dtype=np.float32))*stride
        yy,xx = np.divmod(selected,dim)
        centers=np.column_stack([xx*stride+(stride-1)*.5,yy*stride+(stride-1)*.5])
        for j,i in enumerate(selected):
            left,top = centers[j]-distances[j,:2];right,bottom=centers[j]+distances[j,2:]
            box=np.clip([left,top,right,bottom],0,416)/416
            if box[2]-box[0]<.01 or box[3]-box[1]<.01:continue
            boxes.append(box.tolist());scores.append(float(confidence[i]));classes.append(int(identifiers[i]))
    keep=[]
    for identifier in set(classes):
        selected=[i for i,c in enumerate(classes) if c==identifier]
        xywh=[[boxes[i][0],boxes[i][1],boxes[i][2]-boxes[i][0],boxes[i][3]-boxes[i][1]] for i in selected]
        indices=cv2.dnn.NMSBoxes(xywh,[scores[i] for i in selected],threshold,.5)
        keep.extend(selected[int(i)] for i in np.asarray(indices).reshape(-1))
    keep=sorted(keep,key=lambda i:scores[i],reverse=True)[:32]
    return [{'class_id':classes[i],'class_code':CLASSES[classes[i]],'confidence':scores[i],'box':boxes[i]} for i in keep]


def _roi_mask(detections, identifiers, shape):
    height,width=shape;mask=np.zeros(shape,dtype=np.float32)
    populated=False
    for item in detections:
        if item['class_id'] not in identifiers:continue
        x1,y1,x2,y2=item['box'];left,top=round(x1*width),round(y1*height);right,bottom=round(x2*width),round(y2*height)
        mask[top:bottom,left:right]=np.maximum(mask[top:bottom,left:right],item['confidence'])
        populated=populated or (right>left and bottom>top)
    if not populated:
        return mask
    return cv2.GaussianBlur(mask,(0,0),max(1,min(shape)*.012))


def scene_tags(objects, faces):
    ids={item['class_id'] for item in objects}
    tags=[]
    if 0 in ids or faces:tags.append('people')
    if ids & GROUPS['animal']:tags.append('animals')
    if ids & GROUPS['food']:tags.append('food')
    if ids & GROUPS['vehicle']:tags.append('vehicles')
    if ids & {56,57,59,60,62,68,69,71,72}:tags.append('interior_objects')
    if ids & {9,10,11,12}:tags.append('street_objects')
    if 58 in ids:tags.append('plants')
    return tags


def analyze_scene(pixels, cancel_event=None):
    if pixels.dtype != np.uint8 or pixels.ndim != 3 or pixels.shape[2]!=3:
        raise ValueError('Recognition requires RGB pixels')
    _cancel(cancel_event)
    expected_bundle = bundle_id()
    height,width=pixels.shape[:2];scale=min(1,640/max(height,width))
    rgb=cv2.resize(pixels,(max(1,round(width*scale)),max(1,round(height*scale))),interpolation=cv2.INTER_AREA)
    bgr=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
    small=cv2.resize(bgr,(416,416)).astype(np.float32)
    small=(small-np.array([103.53,116.28,123.675],np.float32))/np.array([57.375,57.12,58.395],np.float32)
    objects=decode_objects(infer('nanodet',cv2.dnn.blobFromImage(small)))
    _cancel(cancel_event)
    face_rows=detect_faces(bgr);faces=[];face_mask=np.zeros(rgb.shape[:2],np.float32)
    if face_rows is not None:
        for row in sorted(face_rows,key=lambda r:float(r[-1]),reverse=True)[:16]:
            x,y,w,h=map(float,row[:4]);confidence=float(row[-1])
            if not all(math.isfinite(v) for v in (x,y,w,h,confidence)) or not .85<=confidence<=1 or w<=0 or h<=0:continue
            box=np.clip([x/rgb.shape[1],y/rgb.shape[0],(x+w)/rgb.shape[1],(y+h)/rgb.shape[0]],0,1).tolist()
            if box[0]>=box[2] or box[1]>=box[3]:continue
            faces.append({'confidence':confidence,'box':box})
            cv2.ellipse(face_mask,(round(x+w*.5),round(y+h*.53)),(max(1,round(w*.44)),max(1,round(h*.48))),0,0,360,confidence,-1)
    masks={group:_roi_mask(objects,ids,rgb.shape[:2]) for group,ids in GROUPS.items()}
    masks['face']=cv2.GaussianBlur(face_mask,(0,0),max(1,min(rgb.shape[:2])*.009)) if faces else face_mask
    masks['person']=np.zeros(rgb.shape[:2],np.float32)
    if any(item['class_id']==0 for item in objects) or faces:
        _cancel(cancel_event)
        human_input=cv2.resize(rgb,(192,192)).astype(np.float32)/127.5-1
        output=infer('humanseg',cv2.dnn.blobFromImage(human_input))[0]
        if output.shape != (2,192,192) or not np.isfinite(output).all():raise ValueError('Unexpected person mask')
        if output.min()<0 or output.max()>1 or not np.allclose(output.sum(axis=0),1,atol=.02):
            values=output-output.max(axis=0,keepdims=True);values=np.exp(values);output=values/values.sum(axis=0,keepdims=True)
        probability=cv2.resize(output[1],(rgb.shape[1],rgb.shape[0]),interpolation=cv2.INTER_LINEAR)
        # Only supported confident pixels; feathered edges do not use hard boxes.
        masks['person']=cv2.GaussianBlur(np.clip((probability-.45)/.45,0,1),(0,0),1.2)
    # Avoid allocating a stacked six-region tensor just to take its maximum.
    foreground=np.zeros(rgb.shape[:2],np.float32)
    for region in REGIONS:
        if region!='background':
            np.maximum(foreground,masks[region],out=foreground)
    masks['background']=1-foreground
    _cancel(cancel_event)
    if bundle_id() != expected_bundle:
        raise ModelUnavailableError('Recognition model bundle changed during analysis.')
    fractions={key:float(np.mean(mask>.5)) for key,mask in masks.items()}
    report={'schema_version':1,'model_version':MODEL_VERSION,'bundle_id':expected_bundle,'backend':'opencv_dnn_cpu',
            'objects':objects,'faces':faces,'scene_tags':scene_tags(objects,faces),'region_fractions':fractions,
            'region_methods':dict(_REGION_METHODS)}
    return {'report':report,'masks':masks}


def region_appearance(pixels, scene):
    masks=scene['masks'];height,width=next(iter(masks.values())).shape
    source=pixels if pixels.shape[:2]==(height,width) else cv2.resize(pixels,(width,height),interpolation=cv2.INTER_AREA)
    rgb=source.astype(np.float32)/255
    luma=rgb@np.array([.2126,.7152,.0722],np.float32);lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB);hsv=cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV)
    zone_masks=[('shadows',luma<.25),('midtones',(luma>=.25)&(luma<.75)),('highlights',luma>=.75)]
    result={}
    for region,mask in masks.items():
        selected=mask>.65;count=np.count_nonzero(selected);fraction=float(count/selected.size)
        if count<128 or fraction<.015:continue
        zones={}
        for name,zone in zone_masks:
            support=selected&zone
            if support.sum()>=32:zones[name]=np.mean(lab[support,1:],axis=0).tolist()
        result[region]={'target':{'quantiles':np.quantile(luma[selected],[.05,.25,.5,.75,.95]).tolist(),
                       'saturation':float(hsv[selected,1].mean()),'zones':zones},'fraction':fraction}
    return result


def analyze_evidence(pixels, corrected=None, edited=None, valid_mask=None, cancel_event=None):
    try:
        _cancel(cancel_event)
        scene=analyze_scene(pixels,cancel_event=cancel_event) if cancel_event is not None else analyze_scene(pixels)
        report=scene['report'];report['status']='ok'
        report['coordinate_space']='registered_comparison' if edited is not None else 'oriented_image'
        if valid_mask is not None:
            if valid_mask.ndim != 2 or not np.isfinite(valid_mask).all():
                raise ValueError('Invalid registered overlap mask')
            shape=next(iter(scene['masks'].values())).shape
            valid=cv2.resize((valid_mask>0).astype(np.float32),(shape[1],shape[0]),interpolation=cv2.INTER_NEAREST)
            scene['masks']={key:mask*valid for key,mask in scene['masks'].items()}
            report['region_fractions']={key:float(np.mean(mask>.5)) for key,mask in scene['masks'].items()}
        if edited is None:report['region_appearance']=region_appearance(pixels,scene)
        else:
            from .style_regions import regional_transforms
            report['region_transforms']=regional_transforms(pixels,corrected,edited,scene)
        _cancel(cancel_event)
        return report
    except AnalysisCancelledError:
        raise
    except (ModelUnavailableError,cv2.error,ValueError,OSError):
        return {'schema_version':1,'status':'unavailable','reason':'local_model_unavailable','model_version':MODEL_VERSION}


def validate_semantic_report(report):
    """Validate persisted derived evidence without retaining masks or pixels."""
    def number(value, low, high):
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and low <= value <= high

    def box(value):
        return (isinstance(value, list) and len(value) == 4 and all(number(v, 0, 1) for v in value)
                and value[0] < value[2] and value[1] < value[3])

    def target(value):
        if not isinstance(value, dict) or set(value) != {'quantiles', 'saturation', 'zones'}:
            return False
        quantiles, zones = value['quantiles'], value['zones']
        return (isinstance(quantiles, list) and len(quantiles) == 5
                and all(number(v, 0, 1) for v in quantiles) and quantiles == sorted(quantiles)
                and number(value['saturation'], 0, 1) and isinstance(zones, dict)
                and not set(zones) - {'shadows', 'midtones', 'highlights'}
                and all(isinstance(v, list) and len(v) == 2 and all(number(c, -128, 128) for c in v) for v in zones.values()))

    if not isinstance(report, dict) or type(report.get('schema_version')) is not int or report['schema_version'] != 1:
        raise ValueError('Invalid semantic evidence schema')
    if not isinstance(report.get('model_version'), str) or not report['model_version']:
        raise ValueError('Missing semantic model version')
    if report.get('status') == 'unavailable':
        if set(report) != {'schema_version', 'status', 'reason', 'model_version'} or report['reason'] != 'local_model_unavailable':
            raise ValueError('Invalid unavailable semantic evidence')
        return
    required = {'schema_version', 'status', 'model_version', 'bundle_id', 'backend', 'objects', 'faces',
                'scene_tags', 'region_fractions', 'region_methods', 'coordinate_space'}
    if report.get('status') != 'ok' or set(report) not in (required | {'region_appearance'}, required | {'region_transforms'}):
        raise ValueError('Invalid semantic evidence fields')
    identity = report['bundle_id']
    if not isinstance(identity, str) or len(identity) != 64 or any(c not in '0123456789abcdef' for c in identity):
        raise ValueError('Invalid semantic model identity')
    if report['backend'] != 'opencv_dnn_cpu' or report['coordinate_space'] not in {'oriented_image', 'registered_comparison'}:
        raise ValueError('Invalid semantic evidence coordinates or backend')
    objects, faces = report['objects'], report['faces']
    if not isinstance(objects, list) or len(objects) > 32 or not isinstance(faces, list) or len(faces) > 16:
        raise ValueError('Invalid semantic detections')
    for item in objects:
        if (not isinstance(item, dict) or set(item) != {'class_id', 'class_code', 'confidence', 'box'}
                or type(item['class_id']) is not int or not 0 <= item['class_id'] < len(CLASSES)
                or item['class_code'] != CLASSES[item['class_id']] or not number(item['confidence'], .45, 1) or not box(item['box'])):
            raise ValueError('Invalid object evidence')
    for item in faces:
        if not isinstance(item, dict) or set(item) != {'confidence', 'box'} or not number(item['confidence'], .85, 1) or not box(item['box']):
            raise ValueError('Invalid face evidence')
    if report['scene_tags'] != scene_tags(objects, faces) or report['region_methods'] != _REGION_METHODS:
        raise ValueError('Inconsistent semantic evidence methods')
    fractions = report['region_fractions']
    if not isinstance(fractions, dict) or set(fractions) != set(REGIONS) or not all(number(v, 0, 1) for v in fractions.values()):
        raise ValueError('Invalid semantic region coverage')
    field = 'region_appearance' if 'region_appearance' in report else 'region_transforms'
    values = report[field]
    if not isinstance(values, dict) or set(values) - set(REGIONS):
        raise ValueError('Invalid semantic region measurements')
    for value in values.values():
        if field == 'region_appearance':
            if not isinstance(value, dict) or set(value) != {'target', 'fraction'} or not target(value['target']) or not number(value['fraction'], .015, 1):
                raise ValueError('Invalid semantic region appearance')
        else:
            if not isinstance(value, dict) or set(value) != {'tone_curve', 'saturation_scale', 'lab_shift'}:
                raise ValueError('Invalid semantic region transform')
            curve, shift = value['tone_curve'], value['lab_shift']
            if (not isinstance(curve, list) or len(curve) != 33 or not all(number(v, 0, 1) for v in curve)
                    or curve != sorted(curve) or not number(value['saturation_scale'], 0, 1.5)
                    or not isinstance(shift, list) or len(shift) != 2 or not all(number(v, -8, 8) for v in shift)):
                raise ValueError('Invalid semantic regional adjustment')
