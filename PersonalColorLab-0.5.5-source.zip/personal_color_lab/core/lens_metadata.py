"""Read a small equipment whitelist from RAW headers, entirely offline.

No pixel data, thumbnails, GPS, dates, owners, serial numbers or complete EXIF
dictionary are returned. Missing/ambiguous lens names stay missing: a numeric
maker lens ID is not sufficient evidence to select an optical calibration.
"""
from __future__ import annotations

from functools import lru_cache
import math
from pathlib import Path
import re
import struct
import unicodedata

from .analysis_control import AnalysisCancelledError, check_cancel
from .constants import RAW_EXTENSIONS


MAX_METADATA_BYTES = 2 * 1024 * 1024
MAX_METADATA_OPERATIONS = 24_000
MAX_IFD_ENTRIES = 1024
MAX_IFDS = 16
MAX_TEXT_BYTES = 512
MAX_NAME_LENGTH = 160
_CANON_UUID = bytes.fromhex("85c0b687820f11e08111f4ce462b6a48")
_TEXT_TAGS = {0x010F, 0x0110, 0xA433, 0xA434, 0x0095}
_NUMERIC_TAGS = {0x0112, 0x829D, 0x9202, 0x920A, 0xA405}
_POINTER_TAGS = {0x8769, 0x014A}
_OPCODE_TAGS = {0xC740, 0xC741, 0xC74E}
_EQUIPMENT_TAGS = _TEXT_TAGS | _NUMERIC_TAGS | _POINTER_TAGS | _OPCODE_TAGS | {0x927C}
_UNKNOWN_NAMES = {"unknown", "unspecified", "none", "n/a", "not available", "manual lens", "lens"}


class _MetadataLimit(ValueError):
    pass


class _BoundedReader:
    """Count sparse header reads; sensor bytes are never read wholesale."""

    def __init__(self, file_handle, size: int, cancel_event):
        self.file_handle = file_handle
        self.size = size
        self.cancel_event = cancel_event
        self.bytes_read = 0
        self.operations = 0

    def _operation(self):
        check_cancel(self.cancel_event)
        self.operations += 1
        if self.operations > MAX_METADATA_OPERATIONS:
            raise _MetadataLimit("Metadata operation limit exceeded")

    def seek(self, offset: int, whence: int = 0):
        self._operation()
        if whence == 1:
            offset += self.tell()
        elif whence == 2:
            offset += self.size
        elif whence != 0:
            raise ValueError("Invalid metadata seek")
        if not isinstance(offset, int) or offset < 0 or offset > self.size:
            raise ValueError("Metadata pointer outside file")
        return self.file_handle.seek(offset)

    def tell(self):
        return self.file_handle.tell()

    def read(self, size: int = -1):
        self._operation()
        if not isinstance(size, int) or size < 0 or size > MAX_METADATA_BYTES - self.bytes_read:
            raise _MetadataLimit("Metadata read limit exceeded")
        if self.tell() + size > self.size:
            raise ValueError("Truncated metadata")
        data = self.file_handle.read(size)
        self.bytes_read += len(data)
        if len(data) != size:
            raise ValueError("Truncated metadata")
        return data


class _Segment:
    """Give TIFF-relative offsets their own validated container boundary."""

    def __init__(self, reader: _BoundedReader, start: int, size: int):
        if start < 0 or size < 0 or start + size > reader.size:
            raise ValueError("Invalid metadata segment")
        self.reader, self.start, self.size = reader, start, size
        self.position = 0

    def seek(self, offset: int, whence: int = 0):
        if whence == 1:
            offset += self.position
        elif whence == 2:
            offset += self.size
        elif whence != 0:
            raise ValueError("Invalid segment seek")
        if not isinstance(offset, int) or offset < 0 or offset > self.size:
            raise ValueError("Metadata pointer outside segment")
        self.position = offset
        self.reader.seek(self.start + offset)
        return offset

    def tell(self):
        return self.position

    def read(self, size: int = -1):
        if size < 0 or self.position + size > self.size:
            raise ValueError("Truncated metadata segment")
        self.reader.seek(self.start + self.position)
        value = self.reader.read(size)
        self.position += len(value)
        return value


def _empty() -> dict:
    return {
        "schema_version": 1,
        "metadata_extractor": "exifread",
        "extractor_version": None,
        "camera_make": None, "camera_model": None,
        "lens_make": None, "lens_model": None,
        "focal_length_mm": None, "aperture": None,
        # A 35mm-equivalent focal length may describe digital cropping or be
        # rounded. It is not a validated physical sensor crop factor.
        "crop_factor": None, "crop_factor_source": None,
        "orientation": None,
        "embedded_dng_opcodes_present": False,
        "embedded_distortion": False,
        "metadata_status": "unavailable",
        "metadata_sources": {}, "warnings": [],
    }


def _warning(result: dict, code: str):
    if code not in result["warnings"]:
        result["warnings"].append(code)


def _name(value) -> str | None:
    if not isinstance(value, str) or len(value) > MAX_TEXT_BYTES:
        return None
    value = " ".join("".join(c if not unicodedata.category(c).startswith("C") else " " for c in value).split())
    if not value or len(value) > MAX_NAME_LENGTH:
        return None
    if (value.casefold() in _UNKNOWN_NAMES
            or re.match(r"(?:unknown|unrecognized|unspecified)\b", value, re.I)
            or re.fullmatch(r"(?:0x[0-9a-f]+|[\d\W]+)", value, re.I)):
        return None
    return value


def _number(value, minimum: float, maximum: float) -> float | None:
    # ExifRead's float fields contain a one-item struct tuple inside the
    # values list; rationals use its Ratio class. Accept either bounded form.
    for _ in range(2):
        if not isinstance(value, (list, tuple)):
            break
        if len(value) != 1:
            return None
        value = value[0]
    if isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError, ZeroDivisionError, OverflowError):
        return None
    return number if math.isfinite(number) and minimum <= number <= maximum else None


@lru_cache(maxsize=1)
def _header_class():
    # Pinned ExifRead's header implementation understands rational values and
    # vendor byte order. Filter *before* its normal tag decoding; the public
    # process_file() would also traverse GPS and other unwanted metadata.
    from exifread.core.exif_header import ExifHeader
    from exifread.tags.fields import FIELD_DEFINITIONS, FieldType

    class EquipmentHeader(ExifHeader):
        def __init__(self, stream, endian, result):
            super().__init__(stream, endian, 0, 0, strict=True, detailed=True)
            self.result = result
            self.ifd_visits = 0
            self.visited_ifds = set()
            self.maker_note = None

        def dump_ifd(self, ifd, ifd_name, tag_dict=None, relative=0, stop_tag="UNDEF"):
            key = self.offset + ifd
            if key in self.visited_ifds:
                _warning(self.result, "metadata_ifd_loop")
                return
            self.ifd_visits += 1
            if self.ifd_visits > MAX_IFDS:
                raise _MetadataLimit("Too many metadata IFDs")
            self.visited_ifds.add(key)
            entries = self.s2n(ifd, 2)
            if entries > MAX_IFD_ENTRIES:
                raise _MetadataLimit("Too many metadata entries")
            return super().dump_ifd(ifd, ifd_name, tag_dict, relative, stop_tag)

        def _process_tag(self, ifd, ifd_name, tag_entry, entry, tag, tag_name, relative, stop_tag):
            if tag not in _EQUIPMENT_TAGS:
                return
            # A MakerNote IFD uses a different tag namespace. Only Canon's
            # explicit ASCII LensModel is read, never numeric lens-ID tables.
            if ifd_name == "MakerNote" and tag != 0x0095:
                return
            field_type_id = self.s2n(entry + 2, 2)
            count = self.s2n(entry + 4, 4)
            if count == 0:
                return
            if tag in _OPCODE_TAGS:
                if field_type_id in (1, 7):
                    self.result["embedded_dng_opcodes_present"] = True
                    offset = entry + 8 if count <= 4 else self.s2n(entry + 8, 4)
                    self._inspect_opcodes(offset, count)
                return
            if tag in _TEXT_TAGS and (field_type_id != 2 or count > MAX_TEXT_BYTES):
                _warning(self.result, "equipment_text_invalid")
                return
            if tag in _NUMERIC_TAGS and (count != 1 or field_type_id not in (3, 4, 5, 10, 11, 12)):
                _warning(self.result, "equipment_number_invalid")
                return
            if tag in _POINTER_TAGS and (field_type_id != 4 or count > MAX_IFDS):
                _warning(self.result, "equipment_pointer_invalid")
                return
            if tag == 0x927C:
                # Remember its span without copying the blob into a tag dict.
                if field_type_id not in (1, 7) or count > 256 * 1024:
                    _warning(self.result, "maker_note_unsupported")
                    return
                offset = entry + 8 if count <= 4 else self.s2n(entry + 8, 4)
                self.maker_note = (offset, count)
                return
            try:
                field_type = FieldType(field_type_id)
                type_length = FIELD_DEFINITIONS[field_type][0]
            except (ValueError, KeyError):
                _warning(self.result, "equipment_field_invalid")
                return
            if count * type_length > MAX_TEXT_BYTES:
                _warning(self.result, "equipment_field_invalid")
                return
            super()._process_tag(ifd, ifd_name, tag_entry, entry, tag, tag_name, relative, stop_tag)

        def _inspect_opcodes(self, offset, count):
            # DNG opcode list framing is big endian regardless of TIFF order.
            # Inspect IDs only. Presence does not prove LibRaw applied them.
            if count < 4 or count > 256 * 1024:
                _warning(self.result, "embedded_dng_opcodes_unreadable")
                return
            stream = self.file_handle
            try:
                stream.seek(self.offset + offset)
                opcode_count = int.from_bytes(stream.read(4), "big")
                if opcode_count > 128:
                    raise _MetadataLimit("DNG opcode count limit")
                remaining = count - 4
                for _ in range(opcode_count):
                    if remaining < 16:
                        raise ValueError("Invalid DNG opcode list")
                    opcode_id, _, _, payload_size = struct.unpack(">IIII", stream.read(16))
                    remaining -= 16
                    if payload_size > remaining:
                        raise ValueError("Invalid DNG opcode size")
                    if opcode_id in (1, 2):  # WarpRectilinear / WarpFisheye
                        self.result["embedded_distortion"] = True
                    stream.seek(payload_size, 1)
                    remaining -= payload_size
                if remaining:
                    raise ValueError("Trailing DNG opcode bytes")
            except AnalysisCancelledError:
                raise
            except (ValueError, OSError, struct.error):
                _warning(self.result, "embedded_dng_opcodes_unreadable")

    return EquipmentHeader


def _values(header, *keys):
    for key in keys:
        tag = header.tags.get(key)
        if tag is not None:
            return tag.values
    return None


def _merge(header, result: dict, source: str):
    fields = {
        "camera_make": _name(_values(header, "Image Make")),
        "camera_model": _name(_values(header, "Image Model")),
        "lens_make": _name(_values(header, "EXIF LensMake", "Image LensMake")),
        "lens_model": _name(_values(header, "EXIF LensModel", "Image LensModel")),
        "focal_length_mm": _number(_values(header, "EXIF FocalLength", "Image FocalLength"), 0.1, 5000),
        "aperture": _number(_values(header, "EXIF FNumber", "Image FNumber"), 0.3, 128),
    }
    if fields["aperture"] is None:
        apex = _number(_values(header, "EXIF ApertureValue", "Image ApertureValue"), -3.5, 14)
        if apex is not None:
            fields["aperture"] = _number(2 ** (apex / 2), 0.3, 128)
    orientation = _number(_values(header, "Image Orientation", "EXIF Orientation"), 1, 8)
    if orientation is not None and orientation.is_integer():
        fields["orientation"] = int(orientation)
    for key, value in fields.items():
        if value is not None and result[key] is None:
            result[key] = value
            result["metadata_sources"][key] = source
    if result["lens_model"] is None:
        lens = _name(_values(header, "MakerNote LensModel"))
        if lens is not None:
            result["lens_model"] = lens
            result["metadata_sources"]["lens_model"] = "canon_makernote"


def _parse_tiff(stream: _Segment, result: dict, source: str, *, exif_only=False):
    stream.seek(0)
    header_bytes = stream.read(8)
    endian = header_bytes[:2]
    # Olympus ORF and Panasonic RW2 retain the classic TIFF IFD layout while
    # replacing its magic word. BigTIFF is intentionally unsupported.
    if endian not in (b"II", b"MM"):
        raise ValueError("Unsupported equipment TIFF header")
    order = "<" if endian == b"II" else ">"
    magic, first_ifd = struct.unpack(order + "HI", header_bytes[2:])
    if magic not in (42, 0x4F52, 0x5352, 85):
        raise ValueError("Unsupported equipment TIFF layout")
    header = _header_class()(stream, chr(endian[0]), result)
    try:
        header.dump_ifd(first_ifd, "EXIF" if exif_only else "Image")
        if not exif_only:
            exif_pointer = _values(header, "Image ExifOffset")
            if exif_pointer:
                header.dump_ifd(int(exif_pointer[0]), "EXIF")
            sub_ifds = _values(header, "Image SubIFDs") or []
            for index, offset in enumerate(sub_ifds):
                header.dump_ifd(int(offset), f"EXIF SubIFD{index}")
        make = _name(_values(header, "Image Make")) or result["camera_make"]
        if make == "Canon" and header.maker_note and result["lens_model"] is None:
            from exifread.tags.makernote import canon
            offset, size = header.maker_note
            if size >= 2:
                header.dump_ifd(offset, "MakerNote", {0x0095: canon.TAGS[0x0095]})
    finally:
        # Preserve fields already validated if a later optional sub-IFD is bad.
        _merge(header, result, source)


def _jpeg_tiff_segment(reader: _BoundedReader, start: int, size: int):
    stream = _Segment(reader, start, size)
    if stream.read(2) != b"\xff\xd8":
        raise ValueError("Invalid RAF embedded JPEG metadata")
    for _ in range(128):
        marker = stream.read(2)
        if marker[0] != 255:
            raise ValueError("Invalid JPEG metadata marker")
        if marker[1] in (0xD9, 0xDA):
            break
        if marker[1] == 0xFF:
            stream.seek(-1, 1)
            continue
        if marker[1] in (0x01, *range(0xD0, 0xD9)):
            continue
        length = int.from_bytes(stream.read(2), "big")
        if length < 2 or stream.tell() + length - 2 > stream.size:
            raise ValueError("Invalid JPEG metadata segment length")
        payload = stream.tell()
        if marker[1] == 0xE1 and length >= 16 and stream.read(6) == b"Exif\0\0":
            return _Segment(reader, start + payload + 6, length - 8)
        stream.seek(payload + length - 2)
    return None


def _parse_raf(reader: _BoundedReader, result: dict):
    reader.seek(28)
    camera = reader.read(32).split(b"\0", 1)[0]
    try:
        camera = _name(camera.decode("ascii"))
    except UnicodeDecodeError:
        camera = None
    # The format itself identifies FUJIFILM, but do not invent a camera model.
    result["camera_make"] = "FUJIFILM"
    result["metadata_sources"]["camera_make"] = "raf_camera_header"
    if camera:
        result["camera_model"] = camera
        result["metadata_sources"]["camera_model"] = "raf_camera_header"
    reader.seek(84)
    jpeg_start, jpeg_size = struct.unpack(">II", reader.read(8))
    if jpeg_size:
        segment = _jpeg_tiff_segment(reader, jpeg_start, jpeg_size)
        if segment:
            _parse_tiff(segment, result, "raf_embedded_exif")


def _parse_cr3(reader: _BoundedReader, result: dict):
    boxes_seen = 0
    metadata_boxes = []

    def boxes(start, end, depth=0):
        nonlocal boxes_seen
        if depth > 4:
            raise _MetadataLimit("CR3 metadata nesting limit")
        offset = start
        while offset + 8 <= end:
            boxes_seen += 1
            if boxes_seen > 512:
                raise _MetadataLimit("CR3 metadata box limit")
            reader.seek(offset)
            size, kind = struct.unpack(">I4s", reader.read(8))
            header_size = 8
            if size == 1:
                size = struct.unpack(">Q", reader.read(8))[0]
                header_size = 16
            elif size == 0:
                size = end - offset
            if size < header_size or offset + size > end:
                raise ValueError("Invalid CR3 metadata box")
            payload, payload_size = offset + header_size, size - header_size
            if kind == b"moov" and depth == 0:
                boxes(payload, offset + size, depth + 1)
            elif kind == b"uuid" and depth == 1 and payload_size >= 16:
                reader.seek(payload)
                if reader.read(16) == _CANON_UUID:
                    boxes(payload + 16, offset + size, depth + 1)
            elif kind in (b"CMT1", b"CMT2") and depth == 2:
                if len(metadata_boxes) >= 4:
                    raise _MetadataLimit("Duplicate CR3 metadata boxes")
                metadata_boxes.append((kind, payload, payload_size))
            # CMT3 maker notes, CMT4 GPS, XMP uuid, tracks and mdat are skipped.
            offset += size
        if offset != end:
            raise ValueError("Truncated CR3 metadata box")

    boxes(0, reader.size)
    for kind, start, size in sorted(metadata_boxes, key=lambda item: item[0]):
        _parse_tiff(_Segment(reader, start, size), result,
                    "cr3_cmt1" if kind == b"CMT1" else "cr3_cmt2", exif_only=kind == b"CMT2")


def read_lens_metadata(path: Path, *, cancel_event=None) -> dict:
    """Return bounded, JSON-safe camera/lens facts; errors do not block RAWs.

    Standard TIFF EXIF (including TIFF-family RAW, ORF and RW2), RAF's embedded
    JPEG EXIF, and Canon CR3 CMT1/CMT2 are supported. A camera/lens without a
    trustworthy textual LensModel remains partial. Sensor crop calibration is
    deliberately delegated to the bundled, validated camera/profile database.
    No metadata extractor can guarantee support for every camera firmware.
    """
    check_cancel(cancel_event)
    result = _empty()
    try:
        import exifread
        result["extractor_version"] = str(exifread.__version__)
    except ImportError:
        _warning(result, "equipment_reader_unavailable")
        return result
    try:
        path = Path(path).expanduser()
        if path.suffix.lower() not in RAW_EXTENSIONS:
            _warning(result, "equipment_input_not_raw")
            return result
        with path.open("rb") as file_handle:
            reader = _BoundedReader(file_handle, path.stat().st_size, cancel_event)
            header = reader.read(min(16, reader.size))
            if header[:2] in (b"II", b"MM"):
                _parse_tiff(_Segment(reader, 0, reader.size), result, "raw_exif")
            elif header.startswith(b"FUJIFILMCCD-RAW "):
                _parse_raf(reader, result)
            elif header[4:12] == b"ftypcrx ":
                _parse_cr3(reader, result)
            else:
                _warning(result, "equipment_container_unsupported")
    except AnalysisCancelledError:
        raise
    except _MetadataLimit:
        _warning(result, "equipment_metadata_limit")
    except Exception:
        # Metadata is auxiliary. Keep a decodable sensor available even if a
        # vendor's optional EXIF structures are malformed or unsupported.
        _warning(result, "equipment_metadata_unreadable")
    check_cancel(cancel_event)
    if result["lens_model"] is None:
        _warning(result, "lens_model_unavailable")
    if result["focal_length_mm"] is None:
        _warning(result, "lens_focal_length_unavailable")
    if all(result[key] is not None for key in ("camera_make", "camera_model", "lens_model", "focal_length_mm")):
        result["metadata_status"] = "ok"
    elif any(result[key] is not None for key in ("camera_make", "camera_model", "lens_model", "focal_length_mm")):
        result["metadata_status"] = "partial"
    return result
