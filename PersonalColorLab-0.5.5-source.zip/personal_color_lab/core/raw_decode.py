"""Read camera RAW pixels locally using an explicit, reproducible baseline.

A RAW file has no single finished appearance. This development is a comparison
baseline, not a reconstruction of the camera JPEG or of Lightroom defaults.
Only decoding parameters and a bounded equipment whitelist are returned;
location, serial numbers and complete camera metadata are never copied.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import cv2
import numpy as np

from .constants import RAW_EXTENSIONS
from .analysis_control import AnalysisCancelledError, check_cancel

MAX_RAW_PIXELS = 120_000_000


class RawDecodeError(ValueError):
    """A sensor file cannot be safely developed into the documented baseline."""


def _sensor_size(sizes) -> tuple[int, int]:
    """Validate header dimensions before LibRaw allocates/unpacks sensor data."""
    dimensions = (sizes.raw_width, sizes.raw_height, sizes.width, sizes.height)
    if any(not isinstance(value, int) or isinstance(value, bool) or value < 1 for value in dimensions):
        raise RawDecodeError("RAW image has invalid sensor dimensions.")
    if sizes.raw_width * sizes.raw_height > MAX_RAW_PIXELS or sizes.width * sizes.height > MAX_RAW_PIXELS:
        raise RawDecodeError("RAW image exceeds the supported 120 megapixel decode limit.")
    width, height = sizes.width, sizes.height
    # LibRaw flip is a bit field; transpose is bit 4, including mirrored TIFF
    # orientations 5 and 7 as well as the common rotations 6 and 8.
    if sizes.flip & 4:
        width, height = height, width
    return int(width), int(height)


def _can_half_size(raw, rawpy, sizes, max_dimension: int) -> bool:
    """Use the four-CFA-cell preview only for ordinary RGB Bayer geometry."""
    if (raw.raw_type != rawpy.RawType.Flat or raw.num_colors != 3
            or not isinstance(sizes.flip, int) or sizes.flip not in range(8)
            or not np.isfinite(sizes.pixel_aspect) or sizes.pixel_aspect != 1.0
            or (sizes.iwidth, sizes.iheight) != (sizes.width, sizes.height)
            or sizes.width % 2 or sizes.height % 2
            or max_dimension > max(sizes.width, sizes.height) // 2):
        return False
    pattern = raw.raw_pattern
    if pattern is None or pattern.shape != (2, 2):
        return False
    description = raw.color_desc
    try:
        indices = [int(index) for index in pattern.flat]
        if any(index < 0 or index >= len(description) for index in indices):
            return False
        colors = [description[index] for index in indices]
    except (IndexError, TypeError, ValueError):
        return False
    return (sorted(colors) == sorted(b"RGGB")
            and ((colors[0] == colors[3] == ord('G'))
                 or (colors[1] == colors[2] == ord('G'))))


def decode_raw(path: Path, max_dimension: int = 1400, *, quality: str = "baseline",
               cancel_event=None, lens_correction: bool = False,
               lens_override=None) -> tuple[np.ndarray, tuple[int, int], dict[str, Any]]:
    """Return bounded uint8 sRGB pixels, oriented full size, and safe provenance.

The input is read only. LibRaw applies the stored orientation and sensor black /
white levels, then develops with camera WB, sRGB output and no automatic
    brightness. Baseline mode remains full AHD development followed by AREA
    resizing. Explicit interactive mode can develop a large ordinary Bayer
    sensor at half resolution for a quicker approximate display, with truthful
    provenance. It is never an analysis/export substitute or an embedded JPEG.
    Unsupported sensor layouts retain baseline development. Native LibRaw calls
    cannot be interrupted; cancellation is checked before/after those calls.
    Optional optical correction uses only a verified local lens profile before
    preview resampling. Reverse analysis retains the uncorrected default.
"""
    if not isinstance(max_dimension, int) or isinstance(max_dimension, bool) or max_dimension < 32:
        raise ValueError("max_dimension must be an integer of at least 32")
    if not isinstance(quality, str) or quality not in ("baseline", "interactive"):
        raise ValueError("quality must be 'baseline' or 'interactive'")
    if type(lens_correction) is not bool:
        raise ValueError("lens_correction must be a boolean")
    if lens_override is not None:
        from .lens_profiles import validate_lens_override
        lens_override = validate_lens_override(lens_override)
    check_cancel(cancel_event)
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.suffix.lower() not in RAW_EXTENSIONS:
        raise ValueError("A supported camera RAW file is required.")
    try:
        import rawpy
    except ImportError as exc:
        raise ValueError("RAW decoder is unavailable; install the complete desktop application.") from exc

    try:
        # imread() combines open_file() and unpack(). Separating them lets us
        # reject an oversized/invalid sensor before allocating its pixel data.
        with rawpy.RawPy() as raw:
            raw.open_file(str(path))
            _sensor_size(raw.sizes)
            check_cancel(cancel_event)
            raw.unpack()
            check_cancel(cancel_event)
            sizes = raw.sizes
            sensor_size = _sensor_size(sizes)
            half_size = quality == "interactive" and _can_half_size(raw, rawpy, sizes, max_dimension)
            camera_wb = np.asarray(raw.camera_whitebalance[:3], dtype=np.float64)
            has_camera_wb = bool(camera_wb.size == 3 and np.isfinite(camera_wb).all() and (camera_wb > 0).all())
            rgb = raw.postprocess(
                use_camera_wb=True,
                use_auto_wb=False,
                no_auto_bright=True,
                bright=1.0,
                exp_shift=1.0,
                exp_preserve_highlights=0.0,
                no_auto_scale=False,
                adjust_maximum_thr=0.0,
                output_color=rawpy.ColorSpace.sRGB,
                output_bps=8,
                gamma=(2.4, 12.92),
                demosaic_algorithm=rawpy.DemosaicAlgorithm.AHD,
                highlight_mode=rawpy.HighlightMode.Clip,
                fbdd_noise_reduction=rawpy.FBDDNoiseReductionMode.Off,
                median_filter_passes=0,
                half_size=half_size,
            )
            check_cancel(cancel_event)
    except (AnalysisCancelledError, RawDecodeError):
        raise
    except (rawpy.LibRawError, OSError, RuntimeError, ValueError) as exc:
        raise RawDecodeError(f"Cannot decode RAW image: {path.name}") from exc

    if not isinstance(rgb, np.ndarray) or rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8 or min(rgb.shape[:2]) < 1:
        raise RawDecodeError(f"RAW decoder returned invalid RGB pixels: {path.name}")
    original_size = sensor_size if half_size else (int(rgb.shape[1]), int(rgb.shape[0]))
    decoded_size = (int(rgb.shape[1]), int(rgb.shape[0]))
    if half_size and decoded_size != (original_size[0] // 2, original_size[1] // 2):
        # Do not present guessed full dimensions for an undocumented layout.
        raise RawDecodeError(f"RAW preview geometry does not match its sensor: {path.name}")
    # Optical geometry is separate from the reverse-learning RAW baseline.
    # Correct the developed full/half sensor BEFORE its final preview resize,
    # so the precise preview and the exported full-resolution copy share the
    # same measurement image and object-mask geometry. Only equipment fields
    # are read; no complete EXIF dictionary or GPS data is retained.
    from .lens_metadata import read_lens_metadata
    equipment = read_lens_metadata(path, cancel_event=cancel_event)
    lens_report = {'requested': lens_correction, 'applied': False,
                   'available': False, 'status': 'disabled', 'bundle_id': None,
                   'selection_source': 'manual' if lens_override else 'automatic'}
    if lens_correction:
        from .lens_profiles import equipment_for_selection, resolve_lens_profile
        from .lens_correction import correct_lens_distortion
        selected = equipment_for_selection(equipment, lens_override)
        profile = resolve_lens_profile(selected)
        rgb, correction = correct_lens_distortion(rgb, profile, border='fit',
                                                  cancel_event=cancel_event)
        lens_report.update(correction)
        lens_report.update(available=profile['available'],
                           selected_equipment={key: selected.get(key) for key in
                                               ('camera_make', 'camera_model', 'lens_make',
                                                'lens_model', 'focal_length_mm')},
                           profile=profile)
    check_cancel(cancel_event)
    factor = min(1.0, max_dimension / max(decoded_size))
    if factor < 1:
        rgb = cv2.resize(rgb, (max(1, round(decoded_size[0] * factor)), max(1, round(decoded_size[1] * factor))), interpolation=cv2.INTER_AREA)
    check_cancel(cancel_event)
    metadata = {
        "decoder": "rawpy_libraw",
        "rawpy_version": str(rawpy.__version__),
        "libraw_version": ".".join(str(part) for part in rawpy.libraw_version),
        "baseline": "fixed_camera_wb_srgb",
        "baseline_is_original_edit_history": False,
        "camera_white_balance_requested": True,
        "white_balance_source": "camera" if has_camera_wb else "libraw_daylight_fallback",
        "auto_white_balance": False,
        "auto_brightness": False,
        "brightness_multiplier": 1.0,
        "exposure_multiplier": 1.0,
        "sensor_black_white_normalization": True,
        "scene_maximum_adjustment": False,
        "output_color_space": "sRGB",
        "gamma": [2.4, 12.92],
        "output_bits": 8,
        "demosaic": "Bayer_half_size" if half_size else "AHD",
        "quality_requested": quality,
        "quality_used": "interactive_half_size" if half_size else "baseline",
        "half_size": half_size,
        "preview_is_approximation": half_size,
        "full_sensor_size": list(original_size),
        "highlight_mode": "clip",
        "orientation_applied": True,
        "embedded_preview_used": False,
        "equipment": equipment,
        "lens_correction": lens_report,
        "warnings": (["raw_baseline_interpretation"]
                     + ([] if has_camera_wb else ["raw_camera_white_balance_unavailable"])
                     + (["raw_interactive_preview_approximation"] if half_size else [])),
    }
    return np.ascontiguousarray(rgb), original_size, metadata
