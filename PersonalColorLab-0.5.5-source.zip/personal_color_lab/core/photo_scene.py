"""Offline photo scene evidence and explicit reviewed classification.

Scores are similarity-derived estimates, never calibrated probabilities.
Original images and location metadata are not retained in these reports.
"""
from __future__ import annotations
import copy
import math
import numpy as np
import cv2
from .analysis_control import AnalysisCancelledError

TAXONOMY_VERSION = 1
MODEL_VERSION = 'tinyclip-8m-int8-scene-v1'
CLASSIFIER_VERSION = MODEL_VERSION
AXES = {
    'time': ('day', 'golden_hour', 'blue_hour', 'night'),
    'environment': ('indoor', 'outdoor'),
    'subject': ('portrait', 'landscape', 'city', 'architecture', 'food', 'still_life', 'animals'),
    'lighting': ('natural_light', 'warm_artificial', 'neon', 'mixed_light'),
    'exposure': ('low_light', 'backlit', 'high_dynamic_range', 'strong_highlights'),
}
SCENE_AXES = AXES
LABELS = tuple(label for labels in AXES.values() for label in labels)
SCENE_LABELS = LABELS
LABEL_AXES = {label: axis for axis, labels in AXES.items() for label in labels}
_EXCLUSIVE = ('time', 'environment')
_EVIDENCE_SOURCES = {'reference_jpg', 'original_raw', 'original_jpg', 'raw_xmp_baseline', 'source_photo', 'registered_original'}
_WARNING_CODES = {'local_model_unavailable', 'classifier_uncertain', 'source_decode_unavailable', 'source_color_unavailable', 'insufficient_image_evidence', 'uncalibrated_scores', 'empty_valid_region', 'scene_manual_assignment_conflict'}


def validate_scene_override(value):
    """Return a canonical complete replacement; None retains automatic labels."""
    if value is None:
        return None
    if not isinstance(value, list) or len(value) > len(LABELS):
        raise ValueError('Invalid scene labels')
    if any(not isinstance(label, str) or label not in LABEL_AXES for label in value) or len(set(value)) != len(value):
        raise ValueError('Unknown or duplicate scene label')
    for axis in _EXCLUSIVE:
        if sum(label in AXES[axis] for label in value) > 1:
            raise ValueError('Scene time and environment selections are exclusive')
    selected = set(value)
    return [label for label in LABELS if label in selected]

normalize_scene_labels = validate_scene_override
validate_scene_labels = validate_scene_override


def unknown_photo_scene(reason='local_model_unavailable', *, evidence_source=None):
    warning = reason if reason in _WARNING_CODES else 'insufficient_image_evidence'
    report = {'schema_version': 1, 'status': 'unavailable', 'model_version': MODEL_VERSION,
              'bundle_id': None, 'source': 'automatic', 'labels': [], 'automatic_labels': [],
              'scores': {}, 'uncertain': True, 'warnings': [warning]}
    if evidence_source in _EVIDENCE_SOURCES:
        report['evidence'] = {'image_source': evidence_source}
    return report

unknown_scene_report = unknown_photo_scene


def validate_scene_report(report):
    if not isinstance(report, dict):
        raise ValueError('Invalid scene report')
    required = {'schema_version', 'status', 'model_version', 'bundle_id', 'source', 'labels', 'automatic_labels', 'scores', 'uncertain', 'warnings'}
    if set(report) not in (required, required | {'evidence'}) or type(report['schema_version']) is not int or report['schema_version'] != 1:
        raise ValueError('Invalid scene report fields')
    if report['status'] not in {'ok', 'unavailable'} or report['source'] not in {'automatic', 'manual'} or not isinstance(report['model_version'], str) or not 1 <= len(report['model_version']) <= 80:
        raise ValueError('Invalid scene provenance')
    bundle = report['bundle_id']
    if bundle is not None and (not isinstance(bundle, str) or len(bundle) != 64 or any(c not in '0123456789abcdef' for c in bundle)):
        raise ValueError('Invalid scene model identity')
    if report['status'] == 'ok' and bundle is None:
        raise ValueError('Available scene evidence needs a model identity')
    for name in ('labels', 'automatic_labels'):
        if not isinstance(report[name],list) or validate_scene_override(report[name]) != report[name]:
            raise ValueError('Noncanonical scene labels')
    if report['source'] == 'automatic' and report['labels'] != report['automatic_labels']:
        raise ValueError('Automatic scene labels disagree')
    if report['status'] == 'unavailable' and (report['automatic_labels'] or report['scores'] or bundle is not None):
        raise ValueError('Unavailable automatic scene evidence must be empty')
    scores = report['scores']
    if not isinstance(scores, dict) or set(scores) - set(LABELS) or any(not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v) or not 0 <= v <= 1 for v in scores.values()):
        raise ValueError('Invalid scene similarity estimates')
    if any(label not in scores for label in report['automatic_labels']):
        raise ValueError('Automatic labels require similarity evidence')
    if type(report['uncertain']) is not bool:
        raise ValueError('Invalid scene uncertainty')
    warnings = report['warnings']
    if not isinstance(warnings, list) or len(warnings) > 8 or any(not isinstance(code,str) or code not in _WARNING_CODES for code in warnings) or len(set(warnings)) != len(warnings):
        raise ValueError('Invalid scene warning')
    evidence = report.get('evidence', {})
    if not isinstance(evidence, dict) or set(evidence) - {'image_source', 'method', 'semantic_used', 'score_kind'}:
        raise ValueError('Invalid scene evidence')
    if 'image_source' in evidence and evidence['image_source'] not in _EVIDENCE_SOURCES:
        raise ValueError('Invalid scene image source')
    if 'method' in evidence and evidence['method'] != 'trained_image_text_similarity':
        raise ValueError('Invalid scene classification method')
    if 'score_kind' in evidence and evidence['score_kind'] != 'uncalibrated_similarity':
        raise ValueError('Invalid scene score interpretation')
    if 'semantic_used' in evidence and type(evidence['semantic_used']) is not bool:
        raise ValueError('Invalid semantic support flag')
    return report

validate_photo_scene = validate_scene_report


def with_scene_override(report, labels):
    validate_scene_report(report)
    canonical = validate_scene_override(labels)
    result = copy.deepcopy(report)
    result['labels'] = list(result['automatic_labels']) if canonical is None else canonical
    result['source'] = 'automatic' if canonical is None else 'manual'
    validate_scene_report(result)
    return result

apply_scene_override = with_scene_override


def classifier_bundle_id():
    from .photo_scene_models import bundle_id
    return bundle_id()


def classify_photo(rgb, *, semantic_report=None, cancel_event=None, evidence_source=None, valid_mask=None):
    if cancel_event is not None and cancel_event.is_set():
        raise AnalysisCancelledError('Scene classification cancelled.')
    if not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3 or min(rgb.shape[:2]) < 1:
        raise ValueError('Scene classification requires RGB pixels')
    try:
        from .photo_scene_models import classify_embedding
        return _classify(rgb, semantic_report=semantic_report, cancel_event=cancel_event, evidence_source=evidence_source, valid_mask=valid_mask)
    except AnalysisCancelledError:
        raise
    except (ImportError, OSError, ValueError, cv2.error):
        return unknown_photo_scene('local_model_unavailable', evidence_source=evidence_source)

classify_photo_scene = classify_photo


def _classify(rgb, *, semantic_report=None, cancel_event=None, evidence_source=None, valid_mask=None):
    from .photo_scene_models import classify_embedding
    if valid_mask is not None:
        if (not isinstance(valid_mask,np.ndarray) or valid_mask.shape!=rgb.shape[:2]
                or not np.issubdtype(valid_mask.dtype,np.number) and valid_mask.dtype!=np.bool_
                or not np.isfinite(valid_mask).all()):raise ValueError('Invalid scene valid region')
        yy,xx=np.nonzero(valid_mask>0)
        if not len(xx):return unknown_photo_scene('empty_valid_region',evidence_source=evidence_source)
        rgb=rgb[yy.min():yy.max()+1,xx.min():xx.max()+1]
    # Empty or uniform files contain no visual category evidence. Brightness
    # alone is never used to decide whether the scene is day or night.
    sampled=rgb[::max(1,rgb.shape[0]//128),::max(1,rgb.shape[1]//128)]
    if min(rgb.shape[:2])<16 or float(np.std(sampled.astype(np.float32),axis=(0,1)).max())<3:
        return unknown_photo_scene('insufficient_image_evidence',evidence_source=evidence_source)
    similarity,bundle=classify_embedding(rgb,cancel_event)
    if similarity.shape!=(2,len(LABELS)) or not np.isfinite(similarity).all():raise ValueError('Invalid model similarity')
    positive,negative=similarity
    estimates=1/(1+np.exp(-np.clip((positive-negative)*40,-20,20)))
    scores={label:round(float(estimates[i]),6) for i,label in enumerate(LABELS)}
    cosine=dict(zip(LABELS,positive.tolist()))
    selected=set();semantic_used=False
    # Exclusive axes require a visible margin; ambiguous scenes abstain.
    environment=sorted(AXES['environment'],key=lambda label:scores[label],reverse=True)
    if scores[environment[0]]>=.65 and scores[environment[0]]-scores[environment[1]]>=.2 and cosine[environment[0]]>=.16:
        selected.add(environment[0])
    subjects=sorted(AXES['subject'],key=lambda label:cosine[label],reverse=True)
    compatible={'food':{'still_life'},'still_life':{'food'},'city':{'architecture'},'architecture':{'city'}}
    for label in subjects[:3]:
        if (label==subjects[0] or label in compatible.get(subjects[0],set())) and scores[label]>=.68 and cosine[label]>=.18 and cosine[label]>=cosine[subjects[0]]-.025:
            selected.add(label)
    if semantic_report is not None:
        from .scene_analysis import validate_semantic_report
        try:
            validate_semantic_report(semantic_report)
            if semantic_report.get('status')=='ok':
                fractions=semantic_report['region_fractions']
                supported={}
                if semantic_report['faces'] and fractions['person']>=.04:supported['portrait']=.92
                for region,label in [('food','food'),('animal','animals')]:
                    if fractions[region]>=.04:supported[label]=.86
                for label,estimate in supported.items():
                    scores[label]=max(scores[label],estimate);selected.add(label);semantic_used=True
        except (ValueError,TypeError,KeyError):
            pass
    # A photograph of a room does not establish clock time. Time estimates
    # use visual outdoor evidence and explicit review remains available.
    if 'outdoor' in selected:
        time=sorted(AXES['time'],key=lambda label:scores[label],reverse=True)
        if scores[time[0]]>=.7 and cosine[time[0]]>=.17 and scores[time[0]]-scores[time[1]]>=.12:
            selected.add(time[0])
    for label in AXES['lighting']:
        if scores[label]>=.77 and cosine[label]>=.18:selected.add(label)
    luma=sampled.astype(np.float32)@np.array([.2126,.7152,.0722],np.float32)/255.
    low,high=np.percentile(luma,[5,95]);median=float(np.median(luma))
    exposure_gates={'low_light':median<.24,'backlit':high-low>.45,
                    'high_dynamic_range':low<.14 and high>.8,
                    'strong_highlights':float(np.mean(luma>.92))>.015}
    for label in AXES['exposure']:
        if scores[label]>=.77 and cosine[label]>=.18 and exposure_gates[label]:selected.add(label)
    labels=[label for label in LABELS if label in selected]
    uncertain=not labels or not any(label in selected for label in AXES['subject']) or not any(label in selected for label in AXES['environment'])
    warnings=['uncalibrated_scores']+(['classifier_uncertain'] if uncertain else [])
    report={'schema_version':1,'status':'ok','model_version':MODEL_VERSION,'bundle_id':bundle,
            'source':'automatic','labels':labels,'automatic_labels':list(labels),'scores':scores,
            'uncertain':uncertain,'warnings':warnings,
            'evidence':{'method':'trained_image_text_similarity','semantic_used':semantic_used,'score_kind':'uncalibrated_similarity'}}
    if evidence_source in _EVIDENCE_SOURCES:report['evidence']['image_source']=evidence_source
    if cancel_event is not None and cancel_event.is_set():raise AnalysisCancelledError('Scene classification cancelled.')
    return validate_scene_report(report)
