"""Whole-photo scene recipes around a common, bounded personal style.

Scene labels describe the photograph, independently of object-region masks.
Each label learns the same renderer controls from at least three distinct
original content hashes. No photo, path, EXIF, mask or hash is retained here.
Small, repetitive or uncertain subsets contribute less; multiple labels share
an axis budget and a total budget instead of adding independent full presets.
"""
from __future__ import annotations

import copy
import math
from statistics import median

import numpy as np

SCENE_PROFILE_VERSION = 1
MAX_CATEGORIES = 24
RECIPE_FIELDS = ('tone_curve', 'channel_curves', 'exposure_ev', 'saturation_scale',
                 'vibrance', 'lab_shift', 'zone_shifts', 'hsl', 'grain_amount',
                 'reference_target', 'recorded_parameters')
_ZONES = ('shadows', 'midtones', 'highlights')
_BANDS = ('red', 'orange', 'yellow', 'green', 'aqua', 'blue', 'purple', 'magenta')
_HEX = set('0123456789abcdef')


def _taxonomy():
    # Imported lazily: the classifier can use common analysis helpers without
    # pulling the style renderer or loading its model at import time.
    from .photo_scene import TAXONOMY_VERSION, LABEL_AXES
    return TAXONOMY_VERSION, LABEL_AXES


def empty_scene_profile():
    version, _ = _taxonomy()
    return {'schema_version': SCENE_PROFILE_VERSION, 'enabled': False,
            'taxonomy_version': version, 'classifier_versions': [], 'coverage': {}, 'categories': {}}


def _hash_valid(value):
    return isinstance(value, str) and len(value) == 64 and not set(value) - _HEX


def _curve_valid(curve, number):
    return (isinstance(curve, list) and len(curve) == 33
            and all(number(v, 0, 1) for v in curve) and curve == sorted(curve))


def _shift_valid(value, number):
    return isinstance(value, list) and len(value) == 2 and all(number(v, -12, 12) for v in value)


def _validate_recipe(recipe, target_valid, number):
    if not isinstance(recipe, dict) or set(recipe) != set(RECIPE_FIELDS):
        raise ValueError('Invalid scene recipe fields.')
    if not _curve_valid(recipe['tone_curve'], number):
        raise ValueError('Invalid scene tone curve.')
    curves = recipe['channel_curves']
    if (not isinstance(curves, dict) or set(curves) != {'red', 'green', 'blue'}
            or not all(_curve_valid(v, number) for v in curves.values())):
        raise ValueError('Invalid scene channel curves.')
    for field, low, high in (('exposure_ev', -3, 3), ('saturation_scale', 0, 2),
                             ('vibrance', -1, 1), ('grain_amount', 0, .04)):
        if not number(recipe[field], low, high):
            raise ValueError('Invalid scene control.')
    zones = recipe['zone_shifts']
    if (not _shift_valid(recipe['lab_shift'], number) or not isinstance(zones, dict)
            or set(zones) != set(_ZONES) or not all(_shift_valid(v, number) for v in zones.values())):
        raise ValueError('Invalid scene color shifts.')
    hsl = recipe['hsl']
    if not isinstance(hsl, dict) or set(hsl) != set(_BANDS):
        raise ValueError('Invalid scene hue bands.')
    for value in hsl.values():
        if (not isinstance(value, dict) or set(value) != {'hue', 'saturation', 'lightness'}
                or not number(value['hue'], -45, 45) or not number(value['saturation'], -1, 1)
                or not number(value['lightness'], -.3, .3)):
            raise ValueError('Invalid scene hue controls.')
    if recipe['reference_target'] is not None and not target_valid(recipe['reference_target']):
        raise ValueError('Invalid scene appearance target.')
    from .xmp_analysis import _NUMERIC
    params = recipe['recorded_parameters']
    if not isinstance(params, dict):
        raise ValueError('Invalid scene recorded parameters.')
    for key, value in params.items():
        if key not in _NUMERIC or key.startswith('Crop') or not number(value, *_NUMERIC[key][:2]):
            raise ValueError('Invalid scene recorded control.')


def validate_scene_profile(profile, target_valid, number):
    version, axes = _taxonomy()
    if (not isinstance(profile, dict) or set(profile) != set(empty_scene_profile())
            or type(profile['schema_version']) is not int or profile['schema_version'] != SCENE_PROFILE_VERSION
            or type(profile['enabled']) is not bool or profile['taxonomy_version'] != version):
        raise ValueError('Invalid scene style schema.')
    versions, categories, coverage = profile['classifier_versions'], profile['categories'], profile['coverage']
    if (not isinstance(versions, list) or len(versions) > 4 or len(versions) != len(set(versions))
            or any(not isinstance(v, str) or not 1 <= len(v) <= 100 for v in versions)
            or not isinstance(categories, dict) or len(categories) > MAX_CATEGORIES or set(categories) - set(axes)
            or not isinstance(coverage, dict) or set(coverage) - set(axes)
            or any(type(count) is not int or not 0 <= count <= 1_000_000 for count in coverage.values())):
        raise ValueError('Invalid scene style provenance.')
    if not profile['enabled'] and (categories or versions or coverage):
        raise ValueError('Disabled scene styles cannot contain learned recipes.')
    for label, value in categories.items():
        fields = {'axis', 'sample_count', 'confidence', 'diversity', 'shrinkage',
                  'manual_count', 'monochrome', 'evidence', 'bundle_ids', 'recipe'}
        if not isinstance(value, dict) or set(value) != fields or value['axis'] != axes[label]:
            raise ValueError('Invalid scene category recipe.')
        count, manual = value['sample_count'], value['manual_count']
        if (type(count) is not int or not 3 <= count <= 1_000_000 or coverage.get(label) != count
                or type(manual) is not int or not 0 <= manual <= count
                or not number(value['confidence'], 0, 1) or not number(value['diversity'], 0, 1)
                or not number(value['shrinkage'], 0, 1)
                or not math.isclose(value['shrinkage'], count / (count + 4.0), rel_tol=1e-10)
                or type(value['monochrome']) is not bool
                or value['evidence'] not in {'reference_appearance', 'observed_transform', 'recorded_xmp'}):
            raise ValueError('Invalid scene category support.')
        bundles = value['bundle_ids']
        if (not isinstance(bundles, list) or len(bundles) > 4 or len(bundles) != len(set(bundles))
                or any(not _hash_valid(b) for b in bundles) or count > manual and not bundles):
            raise ValueError('Missing scene classifier provenance.')
        _validate_recipe(value['recipe'], target_valid, number)
        if ((value['evidence'] == 'reference_appearance') != (value['recipe']['reference_target'] is not None)
                or value['evidence'] != 'recorded_xmp' and value['recipe']['recorded_parameters']):
            raise ValueError('Scene recipe does not match its evidence route.')
        if value['monochrome'] and value['recipe']['saturation_scale'] != 0:
            raise ValueError('Inconsistent scene monochrome intent.')


def _labels(record):
    """Return validated label confidence and provenance without mutating evidence."""
    _, axes = _taxonomy()
    payload = record.get('payload', {})
    report = payload.get('photo_scene')
    override = record.get('scene_override', record.get('item', {}).get('scene_override'))
    if override is not None:
        from .photo_scene import validate_scene_override
        labels = validate_scene_override(override)
        return {label: 1.0 for label in labels}, True, None, None
    if not isinstance(report, dict):
        return {}, False, None, None
    from .photo_scene import validate_photo_scene
    validate_photo_scene(report)
    manual = report.get('source') == 'manual'
    bundle = report.get('bundle_id')
    if not manual and not _hash_valid(bundle):
        return {}, False, None, report.get('model_version')
    scores = report.get('scores', {})
    labels = {label: 1.0 if manual else float(scores[label]) for label in report.get('labels', []) if label in axes}
    return labels, manual, bundle, report.get('model_version')


def _diversity(payloads):
    """Dampen near duplicates only when actual perceptual fingerprints exist."""
    hashes = [p.get('provenance', {}).get('perceptual_hash') for p in payloads]
    known = [_hash_valid(value) for value in hashes]
    if not all(known):
        return 1.0
    centers = []
    for value in hashes:
        bits = int(value, 16)
        # A bounded comparison budget avoids quadratic work on large folders.
        if not any((bits ^ previous).bit_count() <= 10 for previous in centers[-128:]):
            centers.append(bits)
    return len(centers) / len(payloads)


def learn_scene_profile(batch, global_builder):
    """Use actual route evidence; RAW/XMP never substitutes a rendered appearance."""
    profile = empty_scene_profile()
    profile['enabled'] = True
    _, axes = _taxonomy()
    records, grouped = [], {}
    # Prefer a manually reviewed occurrence of the same original. A second
    # edited output or sidecar does not turn one source photograph into two.
    valid = [r for r in batch.get('results', []) if r.get('status') == 'ok' and isinstance(r.get('payload'), dict)]
    if batch.get('mode') == 'reference_jpg':
        from .reference_analysis import _valid_reference
        valid = [r for r in valid if _valid_reference(r['payload'])]
    for record in valid:
        payload = record['payload']
        fingerprint = payload.get('provenance', {}).get('input_fingerprints', {}).get('original')
        if not _hash_valid(fingerprint):
            continue
        grouped.setdefault(fingerprint, []).append(record)
    for group in grouped.values():
        edited = {r['payload'].get('provenance', {}).get('input_fingerprints', {}).get('edited') for r in group}
        # Several genuinely different edits of one original are not several
        # independent preferences. Leave the conflicting source out of scene
        # learning instead of arbitrarily selecting its first edit.
        if len(edited) > 1:
            continue
        group.sort(key=lambda r: (r.get('scene_override', r.get('item', {}).get('scene_override')) is None
                                 and (r['payload'].get('photo_scene') or {}).get('source') != 'manual'))
        record = group[0]
        labels, manual, bundle, version = _labels(record)
        records.append((record, labels, manual, bundle))
        if version is not None and version not in profile['classifier_versions']:
            profile['classifier_versions'].append(version)
    # Unknown or mixed excessive classifier versions do not silently discard
    # provenance. Manual review can still build a clean, supported category.
    if len(profile['classifier_versions']) > 4:
        raise ValueError('Too many scene classifier versions in one style.')
    evidence = ('reference_appearance' if batch.get('mode') == 'reference_jpg'
                else 'recorded_xmp' if batch.get('mode') == 'raw_xmp' else 'observed_transform')
    for label, axis in axes.items():
        subset = [item for item in records if label in item[1]]
        if subset:
            profile['coverage'][label] = len(subset)
        if len(subset) < 3:
            continue
        bundles = sorted({item[3] for item in subset if item[3] is not None})
        if len(bundles) > 4:
            continue
        subset_batch = {'mode': batch.get('mode'), 'results': [item[0] for item in subset]}
        recipe_dna = global_builder(subset_batch, 'Scene subset')
        count = recipe_dna['sample_count']
        if count < 3:
            continue
        values = [item[0]['payload'].get('confidence', 0) for item in subset]
        source_confidence = median(float(v) if isinstance(v, (float, int)) and not isinstance(v, bool)
                                   and math.isfinite(v) and 0 <= v <= 1 else 0.0 for v in values)
        label_confidence = median(item[1][label] for item in subset)
        confidence = float(np.clip(source_confidence * label_confidence, 0, 1))
        profile['categories'][label] = {
            'axis': axis, 'sample_count': len(subset), 'confidence': confidence,
            'diversity': _diversity([item[0]['payload'] for item in subset]),
            'shrinkage': len(subset) / (len(subset) + 4.0),
            'manual_count': sum(item[2] for item in subset), 'monochrome': recipe_dna['saturation_scale'] == 0,
            'evidence': evidence, 'bundle_ids': bundles,
            'recipe': {key: copy.deepcopy(recipe_dna[key]) for key in RECIPE_FIELDS}}
    return profile


def _mix_target(global_target, weighted):
    if global_target is None:
        return None
    targets = [(recipe['reference_target'], weight) for recipe, weight in weighted
               if recipe['reference_target'] is not None]
    result = copy.deepcopy(global_target)
    for field in ('quantiles', 'saturation'):
        base = np.asarray(global_target[field], dtype=np.float64)
        mixed = base + sum((np.asarray(target[field]) - base) * weight for target, weight in targets)
        result[field] = (np.maximum.accumulate(np.clip(mixed, 0, 1)).tolist() if field == 'quantiles'
                         else float(np.clip(mixed, 0, 1)))
    for zone, shift in global_target['zones'].items():
        base = np.asarray(shift)
        result['zones'][zone] = np.clip(base + sum((np.asarray(target['zones'].get(zone, shift)) - base) * weight
                                                  for target, weight in targets), -128, 128).tolist()
    return result


def _mix_recipe(dna, weighted):
    result = copy.deepcopy(dna)
    for field in ('tone_curve', 'lab_shift'):
        base = np.asarray(dna[field])
        mixed = base + sum((np.asarray(recipe[field]) - base) * weight for recipe, weight in weighted)
        result[field] = (np.maximum.accumulate(np.clip(mixed, 0, 1)).tolist() if field == 'tone_curve'
                         else np.clip(mixed, -12, 12).tolist())
    for channel in ('red', 'green', 'blue'):
        base = np.asarray(dna['channel_curves'][channel])
        mixed = base + sum((np.asarray(recipe['channel_curves'][channel]) - base) * weight for recipe, weight in weighted)
        result['channel_curves'][channel] = np.maximum.accumulate(np.clip(mixed, 0, 1)).tolist()
    for field, low, high in (('exposure_ev', -3, 3), ('saturation_scale', 0, 2),
                             ('vibrance', -1, 1), ('grain_amount', 0, .04)):
        base = dna[field]
        result[field] = float(np.clip(base + sum((recipe[field] - base) * weight for recipe, weight in weighted), low, high))
    for zone in _ZONES:
        base = np.asarray(dna['zone_shifts'][zone])
        result['zone_shifts'][zone] = np.clip(base + sum((np.asarray(recipe['zone_shifts'][zone]) - base) * weight
                                                       for recipe, weight in weighted), -12, 12).tolist()
    for band in _BANDS:
        for control, low, high in (('hue', -45, 45), ('saturation', -1, 1), ('lightness', -.3, .3)):
            base = dna['hsl'][band][control]
            result['hsl'][band][control] = float(np.clip(base + sum((recipe['hsl'][band][control] - base) * weight
                                                                  for recipe, weight in weighted), low, high))
    result['reference_target'] = _mix_target(dna['reference_target'], weighted)
    from .xmp_analysis import _NUMERIC
    for key, base in dna['recorded_parameters'].items():
        result['recorded_parameters'][key] = float(np.clip(
            base + sum((recipe['recorded_parameters'].get(key, base) - base) * weight for recipe, weight in weighted),
            *_NUMERIC[key][:2]))
    return result


def adapt_scene_style(dna, measurement, photo_scene=None):
    """Return a recipe before reference-distribution adaptation and its evidence.

    ``measurement`` belongs to the renderer; this step never mistakes measured
    brightness for day/night or performs an additional appearance adaptation.
    """
    del measurement
    evidence = {'status': 'disabled', 'matched_categories': [], 'monochrome': 'global' if dna['saturation_scale'] == 0 else 'conservative_color',
                'components': []}
    if dna['kind'] == 'hybrid':
        result = copy.deepcopy(dna)
        for component in result['components']:
            component['dna'], child = adapt_scene_style(component['dna'], None, photo_scene)
            evidence['components'].append({'weight': component['weight'], 'evidence': child})
        evidence['status'] = 'hybrid'
        child_intents = [child['evidence']['monochrome'] for child in evidence['components']]
        if all(intent != 'conservative_color' for intent in child_intents):
            evidence['monochrome'] = ('supported_scene' if 'supported_scene' in child_intents else 'global')
        return result, evidence
    profile = dna.get('scene_profile', empty_scene_profile())
    if not profile['enabled']:
        return copy.deepcopy(dna), evidence
    result = copy.deepcopy(dna)
    # New scene learning uses its global fallback, including underrepresented
    # and unclassified photographs. Object recipes still operate in masks.
    result['scene_targets'] = {}
    result['semantic_profile']['contexts'] = {}
    result['warnings'] = [w for w in result['warnings'] if not w.startswith('monochrome_context_')]
    evidence['status'] = 'global'
    if photo_scene is None:
        return result, evidence
    labels, manual, bundle, _ = _labels({'payload': {'photo_scene': photo_scene}})
    candidates = []
    for label, label_confidence in labels.items():
        category = profile['categories'].get(label)
        if category is None or (not manual and category['manual_count'] != category['sample_count']
                                and bundle not in category['bundle_ids']):
            continue
        weight = category['confidence'] * category['diversity'] * category['shrinkage'] * label_confidence
        if weight <= 0:
            continue
        candidates.append((label, category, weight))
    if not candidates:
        return result, evidence
    axis_totals = {}
    for _, category, weight in candidates:
        axis_totals[category['axis']] = axis_totals.get(category['axis'], 0) + weight
    # No category combination can apply several complete presets at once.
    normalized = [(label, category, weight * min(1, .65 / axis_totals[category['axis']]))
                  for label, category, weight in candidates]
    total = sum(weight for _, _, weight in normalized)
    scale = min(1, .8 / total)
    normalized = [(label, category, weight * scale) for label, category, weight in normalized]
    result = _mix_recipe(result, [(category['recipe'], weight) for _, category, weight in normalized])
    evidence['status'] = 'adapted'
    evidence['matched_categories'] = [
        {'label': label, 'axis': category['axis'], 'weight': weight,
         'sample_count': category['sample_count'], 'confidence': category['confidence']}
        for label, category, weight in normalized]
    # A supported all-gray category can coexist with a colorful global style.
    # Any matched color category keeps a conservative mixture rather than
    # silently allowing one category to erase another category's intent.
    scene_monochrome = all(category['monochrome'] for _, category, _ in normalized)
    strong_labels = all(labels[label] >= .6 for label, _, _ in normalized)
    if dna['saturation_scale'] == 0 or (scene_monochrome and strong_labels):
        result['saturation_scale'] = 0.0
        result['lab_shift'] = [0.0, 0.0]
        result['zone_shifts'] = {zone: [0.0, 0.0] for zone in _ZONES}
        evidence['monochrome'] = 'global' if dna['saturation_scale'] == 0 else 'supported_scene'
    return result, evidence
