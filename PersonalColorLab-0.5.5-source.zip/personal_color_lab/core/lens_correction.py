"""Non-destructive, tiled inverse sampling for Lensfun radial distortion.

Equations and coordinate conventions are documented by Lensfun/PanoTools.
This independent NumPy implementation preserves Lensfun's focal-length scale:
poly3/PTLens include the published d normalization; poly5 does not. There are
no optical coefficients invented from camera or lens names, and no downloads.
"""
from __future__ import annotations

import math

import cv2
import numpy as np

from .analysis_control import check_cancel

MAX_CORRECTION_PIXELS = 120_000_000
MAX_FIT_SCALE = 2.0
MAP_TILE_PIXELS = 256_000


class LensCorrectionError(ValueError):
    """A profile cannot safely map the requested image geometry."""


def _polynomial(profile):
    """Radial multiplier coefficients, ascending powers of calibration r."""
    model = profile.get('distortion_model')
    coefficients = profile.get('coefficients')
    expected = {'poly3': 1, 'poly5': 2, 'ptlens': 3}.get(model)
    if (expected is None or not isinstance(coefficients, (list, tuple)) or len(coefficients) != expected
            or any(isinstance(value, bool) or not isinstance(value, (int, float))
                   or not math.isfinite(value) or abs(value) > 10 for value in coefficients)):
        raise LensCorrectionError('Unsupported or invalid distortion coefficients.')
    if model == 'poly3':
        k1, = coefficients
        d = 1 - k1
        if d <= .05:
            raise LensCorrectionError('Singular distortion normalization.')
        return np.array([1., 0., k1 / d**3])
    if model == 'poly5':
        k1, k2 = coefficients
        return np.array([1., 0., k1, 0., k2])
    a, b, c = coefficients
    d = 1 - a - b - c
    if d <= .05:
        raise LensCorrectionError('Singular distortion normalization.')
    return np.array([1., c / d**2, b / d**3, a / d**4])


def _normalization(profile, width, height):
    camera_crop = profile.get('camera_crop_factor')
    calibration_crop = profile.get('calibration_crop_factor')
    aspect = profile.get('calibration_aspect')
    for value in (camera_crop, calibration_crop, aspect):
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or value <= 0:
            raise LensCorrectionError('Invalid lens calibration geometry.')
    if not .3 <= camera_crop <= 30 or not .3 <= calibration_crop <= 30 or not 1 <= aspect <= 4:
        raise LensCorrectionError('Unsupported lens calibration geometry.')
    if camera_crop / calibration_crop < .96:
        raise LensCorrectionError('Camera sensor extends beyond the calibrated lens field.')
    camera_aspect = profile.get('camera_aspect')
    if camera_aspect is not None:
        if (isinstance(camera_aspect, bool) or not isinstance(camera_aspect, (int, float))
                or not math.isfinite(camera_aspect) or camera_aspect < 1
                or not math.isclose(max(width, height) / min(width, height), camera_aspect, rel_tol=.015)):
            raise LensCorrectionError('Image aspect differs from the calibrated camera sensor.')
    # The Hugin r=1 radius is the calibration sensor's half short edge.
    # Current pixel pitch follows the current camera sensor's diagonal. This
    # also covers a full-frame calibration used on a smaller camera sensor.
    return 2 * calibration_crop / camera_crop * math.hypot(aspect, 1) / math.hypot(width, height)


def _extrema_values(polynomial, maximum):
    derivative = np.polynomial.polynomial.polyder(polynomial)
    roots = np.polynomial.polynomial.polyroots(derivative) if len(derivative) > 1 else ()
    samples = [0., maximum]
    samples.extend(float(root.real) for root in roots if abs(root.imag) < 1e-8 and 0 < root.real < maximum)
    return np.polynomial.polynomial.polyval(samples, polynomial)


def _validate_radial(polynomial, maximum):
    # A positive tangential multiplier and radial derivative guarantee that
    # the map does not fold. They also prove that coordinate extrema occur on
    # image edges, making a complete edge scan sufficient for border fitting.
    radial_derivative = polynomial * np.arange(1, len(polynomial) + 1)
    multipliers = _extrema_values(polynomial, maximum)
    derivatives = _extrema_values(radial_derivative, maximum)
    if (not np.isfinite(multipliers).all() or not np.isfinite(derivatives).all()
            or float(multipliers.min()) <= .05 or float(derivatives.min()) <= .05):
        raise LensCorrectionError('Distortion profile folds or collapses this image geometry.')
    if float(np.max(multipliers)) > 4:
        raise LensCorrectionError('Distortion profile exceeds the supported correction range.')


def _map_coordinates(x, y, width, height, norm, polynomial, scale):
    center_x, center_y = (width - 1) / 2, (height - 1) / 2
    dx, dy = (x - center_x) / scale, (y - center_y) / scale
    radius = np.hypot(dx, dy) * norm
    multiplier = np.polynomial.polynomial.polyval(radius, polynomial)
    return center_x + dx * multiplier, center_y + dy * multiplier


def _fit_scale(width, height, norm, polynomial, cancel_event):
    # Every pixel center on all four edges, not a guessed corner-only crop.
    x = np.concatenate((np.arange(width), np.arange(width), np.zeros(height), np.full(height, width - 1)))
    y = np.concatenate((np.zeros(width), np.full(width, height - 1), np.arange(height), np.arange(height)))

    def fits(scale):
        check_cancel(cancel_event)
        mapped_x, mapped_y = _map_coordinates(x, y, width, height, norm, polynomial, scale)
        return (float(mapped_x.min()) >= -1e-7 and float(mapped_y.min()) >= -1e-7
                and float(mapped_x.max()) <= width - 1 + 1e-7 and float(mapped_y.max()) <= height - 1 + 1e-7)

    if fits(1.):
        return 1.
    if not fits(MAX_FIT_SCALE):
        raise LensCorrectionError('Required distortion edge crop exceeds the supported limit.')
    lower, upper = 1., MAX_FIT_SCALE
    for _ in range(30):
        middle = (lower + upper) / 2
        if fits(middle):
            upper = middle
        else:
            lower = middle
    # A tiny numerical guard keeps OpenCV's float32 maps inside the sensor.
    return min(MAX_FIT_SCALE, upper * (1 + 1e-7))


def distortion_coordinates(width, height, profile, *, border='keep', cancel_event=None):
    """Yield bounded row maps for diagnostics; no full-frame float maps kept.

    The input RGB is already LibRaw-oriented. Centered radial distortion
    commutes with all TIFF rotations/reflections, with pixel-centered geometry.
    Non-centered and fisheye profiles are rejected by the profile resolver.
    """
    if (type(width) is not int or type(height) is not int or min(width, height) < 2
            or width * height > MAX_CORRECTION_PIXELS or border not in ('keep', 'fit')):
        raise ValueError('Invalid correction dimensions or border policy.')
    # OpenCV's remap uses signed 16-bit image coordinates internally.
    if max(width, height) >= 32767:
        raise LensCorrectionError('Image dimensions exceed the supported sampling geometry.')
    check_cancel(cancel_event)
    polynomial = _polynomial(profile)
    norm = _normalization(profile, width, height)
    _validate_radial(polynomial, math.hypot((width - 1) / 2, (height - 1) / 2) * norm)
    scale = _fit_scale(width, height, norm, polynomial, cancel_event) if border == 'fit' else 1.
    rows = max(1, min(height, MAP_TILE_PIXELS // width))
    x = np.arange(width, dtype=np.float64)[None, :]
    for start in range(0, height, rows):
        check_cancel(cancel_event)
        stop = min(height, start + rows)
        y = np.arange(start, stop, dtype=np.float64)[:, None]
        map_x, map_y = _map_coordinates(x, y, width, height, norm, polynomial, scale)
        yield start, np.asarray(map_x, dtype=np.float32), np.asarray(map_y, dtype=np.float32), scale


def correct_lens_distortion(rgb, profile, *, border='fit', cancel_event=None):
    """Correct matched rectilinear distortion, preserving resolution/aspect.

    Fit uses the smallest centered zoom >=1 that retains valid original pixels
    everywhere; its edge crop is reported explicitly. Keep retains the original
    field of view and uses black outside the source, never fabricated texture.
    Unavailable profiles return the original array with a truthful skip report.
    The input is never modified. No vignetting, TCA or perspective correction.
    """
    if (not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.ndim != 3
            or rgb.shape[2] != 3 or min(rgb.shape[:2]) < 2 or rgb.shape[0] * rgb.shape[1] > MAX_CORRECTION_PIXELS):
        raise ValueError('Lens correction requires bounded uint8 RGB pixels.')
    if not isinstance(profile, dict) or border not in ('fit', 'keep'):
        raise ValueError('Invalid lens correction profile or border policy.')
    check_cancel(cancel_event)
    report = {'applied': False, 'status': profile.get('status', 'metadata_missing'), 'border': border,
              'profile_id': profile.get('profile_id'), 'bundle_id': profile.get('bundle_id'),
              'crop_scale': 1., 'retained_linear_fraction': 1., 'edge_crop_applied': False,
              'corrections': ['distortion'], 'output_size': [rgb.shape[1], rgb.shape[0]],
              'orientation_applied': True}
    if not profile.get('available'):
        return rgb, report
    height, width = rgb.shape[:2]
    try:
        # Iterate once so invalid/folded geometry fails before destination alloc.
        maps = distortion_coordinates(width, height, profile, border=border, cancel_event=cancel_event)
        first = next(maps)
    except LensCorrectionError:
        return rgb, dict(report, status='unsafe_geometry')
    output = np.empty_like(rgb)
    valid_count = 0
    valid_bounds = [width, height, -1, -1]
    scale = first[3]

    def sample(tile):
        nonlocal valid_count
        start, map_x, map_y, _ = tile
        stop = start + map_x.shape[0]
        valid = (map_x >= 0) & (map_y >= 0) & (map_x <= width - 1) & (map_y <= height - 1)
        all_valid = bool(valid.all())
        if border == 'fit' and not all_valid:
            raise LensCorrectionError('Fitted correction has invalid sensor coordinates.')
        if all_valid:
            # Fit guarantees this case; avoid two full index arrays per tile.
            valid_count += valid.size
            valid_bounds[0] = 0
            valid_bounds[1] = min(valid_bounds[1], start)
            valid_bounds[2] = width - 1
            valid_bounds[3] = max(valid_bounds[3], stop - 1)
        else:
            valid_count += int(valid.sum())
            nonzero_y, nonzero_x = np.nonzero(valid)
            if len(nonzero_x):
                valid_bounds[0] = min(valid_bounds[0], int(nonzero_x.min()))
                valid_bounds[1] = min(valid_bounds[1], start + int(nonzero_y.min()))
                valid_bounds[2] = max(valid_bounds[2], int(nonzero_x.max()))
                valid_bounds[3] = max(valid_bounds[3], start + int(nonzero_y.max()))
        check_cancel(cancel_event)
        output[start:stop] = cv2.remap(rgb, map_x, map_y, cv2.INTER_LINEAR,
                                      borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))
        check_cancel(cancel_event)

    try:
        sample(first)
        for tile in maps:
            sample(tile)
    except LensCorrectionError:
        return rgb, dict(report, status='unsafe_geometry')
    report.update({'applied': True, 'status': 'corrected', 'distortion_model': profile['distortion_model'],
                   'crop_scale': scale, 'retained_linear_fraction': 1 / scale,
                   'edge_crop_applied': scale > 1 + 1e-6, 'valid_fraction': valid_count / (width * height),
                   'valid_bounds': valid_bounds, 'sampling': 'bilinear_tiled_inverse_map',
                   'valid_bounds_semantics': 'bounding_box_of_valid_samples',
                   'focal_length_scale': 'lensfun_focal_preserving'})
    return output, report
