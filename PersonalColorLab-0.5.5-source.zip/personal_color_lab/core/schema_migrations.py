"""Additive migrations for the local library, including untouched V0.1 rows."""

import sqlite3


CURRENT_SCHEMA_VERSION = 3

# Original V0.1 schema: fresh and existing libraries share one upgrade path.
SCHEMA = '''
CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    ext TEXT NOT NULL,
    kind TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    width INTEGER,
    height INTEGER,
    capture_time TEXT,
    camera TEXT,
    lens TEXT,
    fingerprint TEXT,
    imported_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS pairs (
    id INTEGER PRIMARY KEY,
    original_path TEXT NOT NULL,
    edited_path TEXT NOT NULL,
    pair_type TEXT NOT NULL,
    confidence REAL NOT NULL,
    reasons TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(original_path, edited_path, pair_type)
);
CREATE TABLE IF NOT EXISTS scene_tags (
    photo_path TEXT PRIMARY KEY,
    day REAL, night REAL, indoor REAL, outdoor REAL,
    portrait REAL, landscape REAL, food REAL, street REAL,
    architecture REAL, still_life REAL,
    FOREIGN KEY(photo_path) REFERENCES photos(path)
);
CREATE TABLE IF NOT EXISTS edit_analysis (
    id INTEGER PRIMARY KEY,
    original_path TEXT,
    edited_path TEXT,
    source_type TEXT,
    confidence REAL,
    payload_json TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS styles (
    id INTEGER PRIMARY KEY,
    style_name TEXT UNIQUE NOT NULL,
    source_type TEXT NOT NULL,
    global_dna_json TEXT,
    tone_dna_json TEXT,
    color_dna_json TEXT,
    composition_dna_json TEXT,
    dataset_size INTEGER DEFAULT 0,
    coverage_json TEXT,
    confidence REAL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
'''


class SchemaMigrationError(RuntimeError):
    """The library schema cannot be safely used by this application version."""


def _add_versioned_analysis(conn: sqlite3.Connection) -> None:
    columns = {row[1] for row in conn.execute('PRAGMA table_info(edit_analysis)')}
    for name, kind in (
        ('schema_version', 'INTEGER'),
        ('algorithm_version', 'TEXT'),
        ('status', 'TEXT'),
        ('updated_at', 'TEXT'),
    ):
        if name not in columns:
            conn.execute(f'ALTER TABLE edit_analysis ADD COLUMN {name} {kind}')
    # Legacy/sparse rows remain outside the unique index. Their payloads are
    # never guessed, rewritten, or discarded.
    conn.execute('''
        CREATE UNIQUE INDEX IF NOT EXISTS edit_analysis_pair_version
        ON edit_analysis(original_path, edited_path, schema_version, algorithm_version)
        WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
    ''')
    conn.execute('''
        CREATE INDEX IF NOT EXISTS edit_analysis_pair_latest
        ON edit_analysis(original_path, edited_path, updated_at DESC, id DESC)
        WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
    ''')


def _add_source_profiles(conn: sqlite3.Connection) -> None:
    conn.execute('''
        CREATE TABLE source_profiles (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            mode TEXT NOT NULL CHECK(mode IN ('raw_jpg', 'raw_xmp', 'reference_jpg')),
            payload_json TEXT NOT NULL,
            created_at_utc TEXT NOT NULL,
            updated_at_utc TEXT NOT NULL
        )
    ''')
    conn.execute('''
        CREATE INDEX source_profiles_latest
        ON source_profiles(updated_at_utc DESC, id DESC)
    ''')


def _add_style_runtime(conn: sqlite3.Connection) -> None:
    conn.execute('''CREATE TABLE analysis_cache (
        cache_key TEXT PRIMARY KEY, payload_json TEXT NOT NULL,
        accessed_at_utc TEXT NOT NULL
    )''')
    conn.execute('CREATE INDEX analysis_cache_lru ON analysis_cache(accessed_at_utc)')
    conn.execute('''CREATE TABLE style_presets (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL, dna_json TEXT NOT NULL,
        created_at_utc TEXT NOT NULL, updated_at_utc TEXT NOT NULL
    )''')


def migrate_schema(conn: sqlite3.Connection) -> None:
    """Create or upgrade a library atomically; refuse unknown newer schemas."""
    version = conn.execute('PRAGMA user_version').fetchone()[0]
    if version > CURRENT_SCHEMA_VERSION:
        raise SchemaMigrationError(
            f'Library schema {version} is newer than supported schema '
            f'{CURRENT_SCHEMA_VERSION}.'
        )
    if conn.in_transaction:
        raise SchemaMigrationError('Cannot migrate a library inside an active transaction.')
    conn.execute('PRAGMA journal_mode=WAL')
    if version == CURRENT_SCHEMA_VERSION:
        return
    # SQLite does not implicitly begin a transaction for DDL statements.
    # Explicit BEGIN prevents a failed ALTER/index from leaving a half-upgrade.
    try:
        conn.execute('BEGIN IMMEDIATE')
        if version < 1:
            for statement in SCHEMA.split(';'):
                if statement.strip():
                    conn.execute(statement)
            _add_versioned_analysis(conn)
        if version < 2:
            _add_source_profiles(conn)
        if version < 3:
            _add_style_runtime(conn)
        conn.execute(f'PRAGMA user_version={CURRENT_SCHEMA_VERSION}')
        conn.commit()
    except sqlite3.DatabaseError as exc:
        conn.rollback()
        raise SchemaMigrationError(
            'Library schema migration failed; existing records were preserved.'
        ) from exc
    except Exception:
        conn.rollback()
        raise
