"""Perceptual color shifts from registered sRGB photo pairs, entirely local."""

from __future__ import annotations

import cv2
import numpy as np

from .tone_analysis import _sample_pair

_HUE_BANDS = {
    "red": (345, 15),
    "orange": (15, 45),
    "yellow": (45, 75),
    "green": (75, 165),
    "aqua": (165, 195),
    "blue": (195, 255),
    "purple": (255, 285),
    "magenta": (285, 345),
}


def _hue_components(original_hsv: np.ndarray, edited_hsv: np.ndarray) -> tuple:
    """Reusable supported circular evidence for global and eight hue bands."""
    usable = (
        (original_hsv[:, 1] >= 0.08)
        & (edited_hsv[:, 1] >= 0.08)
        & (original_hsv[:, 2] >= 0.03)
        & (edited_hsv[:, 2] >= 0.03)
    )
    radians = np.deg2rad(edited_hsv[:, 0] - original_hsv[:, 0])
    weights = np.minimum(original_hsv[:, 1], edited_hsv[:, 1])
    return usable, weights, np.cos(radians) * weights, np.sin(radians) * weights


def _hue_delta(original_hsv: np.ndarray, edited_hsv: np.ndarray, selected: np.ndarray,
               components: tuple | None = None) -> float | None:
    """Circular signed hue shift; achromatic/ambiguous evidence has no hue."""
    usable, weights, weighted_x, weighted_y = components or _hue_components(original_hsv, edited_hsv)
    usable = usable & selected
    if not np.any(usable):
        return None
    support = float(weights[usable].sum())
    x = float(weighted_x[usable].sum() / support)
    y = float(weighted_y[usable].sum() / support)
    if np.hypot(x, y) < 0.1:
        return None
    return float(np.rad2deg(np.arctan2(y, x)))


def _direction(value: float, positive: str, negative: str) -> str:
    if abs(value) < 1.5:
        return "neutral"
    return positive if value > 0 else negative


def analyze_color(original_rgb: np.ndarray, edited_rgb: np.ndarray, mask: np.ndarray) -> dict:
    """Measure CIELAB, HSV/HSL and hue-band behavior over valid overlap pixels.

    Lab uses L*=0..100 and signed a*/b* units; mean_delta_e is CIE76.
    HSV/HSL S/V/L use 0..1, hue deltas are circular degrees. White balance/tint
    reports a tendency only from sufficiently supported original neutral pixels.
    Confidence is a heuristic evidence score, not a calibrated probability.
    """
    original, edited = _sample_pair(original_rgb, edited_rgb, mask)
    count = len(original)
    result = {
        "sample_count": count,
        "lab": {"delta_l": None, "delta_a": None, "delta_b": None, "mean_delta_e": None},
        "hsv": {"hue_delta_degrees": None, "saturation_delta": None, "value_delta": None},
        "hsl": {"hue_delta_degrees": None, "saturation_delta": None, "lightness_delta": None},
        "achromatic_evidence": {"sample_count": 0, "original_chromatic_fraction": 0.0,
                                "edited_achromatic_fraction": 0.0},
        "hue_bands": {},
        "wb_tint": {
            "temperature_direction": "uncertain",
            "tint_direction": "uncertain",
            "confidence": 0.0,
            "neutral_sample_count": 0,
            "delta_a": None,
            "delta_b": None,
        },
        "limitations": [
            "color_lab_cie76",
            "color_hue_neutral_undefined",
            "color_wb_tint_approximation",
            "color_wb_tint_confounders",
            "analysis_confidence_heuristic",
        ],
    }
    if not count:
        result["hue_bands"] = {
            band: {
                "hue_delta_degrees": None,
                "saturation_delta": None,
                "lightness_delta": None,
                "sample_count": 0,
                "confidence": 0.0,
            }
            for band in _HUE_BANDS
        }
        result["limitations"].append("no_valid_overlap")
        return result

    original_cv = original.astype(np.float32).reshape(-1, 1, 3)
    edited_cv = edited.astype(np.float32).reshape(-1, 1, 3)
    original_lab = cv2.cvtColor(original_cv, cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float64)
    edited_lab = cv2.cvtColor(edited_cv, cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float64)
    original_hsv = cv2.cvtColor(original_cv, cv2.COLOR_RGB2HSV).reshape(-1, 3).astype(np.float64)
    edited_hsv = cv2.cvtColor(edited_cv, cv2.COLOR_RGB2HSV).reshape(-1, 3).astype(np.float64)
    original_hls = cv2.cvtColor(original_cv, cv2.COLOR_RGB2HLS).reshape(-1, 3).astype(np.float64)
    edited_hls = cv2.cvtColor(edited_cv, cv2.COLOR_RGB2HLS).reshape(-1, 3).astype(np.float64)
    original_chroma = np.sqrt(original_lab[:, 1] ** 2 + original_lab[:, 2] ** 2)
    edited_chroma = np.sqrt(edited_lab[:, 1] ** 2 + edited_lab[:, 2] ** 2)
    edited_low = np.minimum(np.minimum(edited[:, 0], edited[:, 1]), edited[:, 2])
    edited_high = np.maximum(np.maximum(edited[:, 0], edited[:, 1]), edited[:, 2])
    lab_delta = edited_lab - original_lab
    mean_lab_delta = np.mean(lab_delta, axis=0)
    result["lab"] = {
        "delta_l": float(mean_lab_delta[0]),
        "delta_a": float(mean_lab_delta[1]),
        "delta_b": float(mean_lab_delta[2]),
        "mean_delta_e": float(np.mean(np.sqrt(lab_delta[:, 0] ** 2 + lab_delta[:, 1] ** 2 + lab_delta[:, 2] ** 2))),
    }
    all_pixels = np.ones(count, dtype=np.bool_)
    hue_components = _hue_components(original_hsv, edited_hsv)
    hue_delta = _hue_delta(original_hsv, edited_hsv, all_pixels, hue_components)
    result["hsv"] = {
        "hue_delta_degrees": hue_delta,
        "saturation_delta": float(np.mean(edited_hsv[:, 1] - original_hsv[:, 1])),
        "value_delta": float(np.mean(edited_hsv[:, 2] - original_hsv[:, 2])),
    }
    result["hsl"] = {
        "hue_delta_degrees": hue_delta,
        "saturation_delta": float(np.mean(edited_hls[:, 2] - original_hls[:, 2])),
        "lightness_delta": float(np.mean(edited_hls[:, 1] - original_hls[:, 1])),
    }
    # Full desaturation is an observed edit only when colorful source pixels
    # become overwhelmingly achromatic. Exclude clipping and retain aggregate
    # support so a gray wall, snow scene or sepia edit does not imply B&W intent.
    usable=(original_hsv[:,2]>.03)&(original_hsv[:,2]<.98)&(edited_hsv[:,2]>.03)&(edited_hsv[:,2]<.98)
    usable_count=int(usable.sum())
    if usable_count:
        source_chromatic=(original_hsv[:,1]>=.08)&(original_chroma>=3)
        edited_achromatic=((edited_high-edited_low)<=2/255)&(edited_chroma<=1.5)
        result['achromatic_evidence']={'sample_count':usable_count,
            'original_chromatic_fraction':float(source_chromatic[usable].mean()),
            'edited_achromatic_fraction':float(edited_achromatic[usable].mean())}

    chromatic = (original_hsv[:, 1] >= 0.08) & (original_hsv[:, 2] >= 0.03)
    original_hue = original_hsv[:, 0]
    for name, (lower, upper) in _HUE_BANDS.items():
        in_band = (
            ((original_hue >= lower) | (original_hue < upper))
            if lower > upper else ((original_hue >= lower) & (original_hue < upper))
        )
        selected = chromatic & in_band
        band_count = int(np.count_nonzero(selected))
        band_hue = _hue_delta(original_hsv, edited_hsv, selected, hue_components)
        result["hue_bands"][name] = {
            "hue_delta_degrees": band_hue,
            "saturation_delta": float(np.mean(edited_hls[selected, 2] - original_hls[selected, 2])) if band_count else None,
            "lightness_delta": float(np.mean(edited_hls[selected, 1] - original_hls[selected, 1])) if band_count else None,
            "sample_count": band_count,
            "confidence": float(min(1.0, band_count / 256.0)),
        }

    neutral = (
        (original_chroma <= 12.0)
        & (original_lab[:, 0] >= 15.0)
        & (original_lab[:, 0] <= 90.0)
        & (edited_lab[:, 0] >= 15.0)
        & (edited_lab[:, 0] <= 95.0)
        & (edited_high < 254 / 255)
    )
    neutral_count = int(np.count_nonzero(neutral))
    result["wb_tint"]["neutral_sample_count"] = neutral_count
    if neutral_count:
        neutral_delta = lab_delta[neutral, 1:3]
        median_delta = np.median(neutral_delta, axis=0)
        spread = float(np.median(np.linalg.norm(neutral_delta - median_delta, axis=1)))
        coverage = min(1.0, neutral_count / count / 0.05)
        support = min(1.0, neutral_count / 256.0)
        confidence = float(0.7 * support * coverage / (1.0 + spread / 5.0))
        wb = result["wb_tint"]
        wb["delta_a"], wb["delta_b"] = float(median_delta[0]), float(median_delta[1])
        wb["confidence"] = confidence
        if neutral_count >= 64 and confidence >= 0.2:
            wb["temperature_direction"] = _direction(wb["delta_b"], "warmer", "cooler")
            wb["tint_direction"] = _direction(wb["delta_a"], "magenta", "green")
        else:
            result["limitations"].append("color_wb_tint_insufficient_neutrals")
    else:
        result["limitations"].append("color_wb_tint_no_neutrals")
    return result
