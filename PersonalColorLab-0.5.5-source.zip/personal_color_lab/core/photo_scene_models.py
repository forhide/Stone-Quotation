"""Pinned TinyCLIP image encoder and precomputed text vectors, CPU only.

No text encoder, Torch, model download, HTTP client or remote inference is
needed by the installed application. Native forwards are serialized.
"""
from pathlib import Path
from io import BytesIO
import hashlib
import json
import threading
import cv2
import numpy as np
from PIL import Image
from .analysis_control import AnalysisCancelledError

MODEL_ROOT=Path(__file__).resolve().parents[1]/'assets/photo_scene'
MODEL_SHA256='3f44bd17204d6d9fe352526744f4453d84fc137114869d0a3e3311dd0a348601'
LICENSE_SHA256='583acc0d9c74def18ec24e56964421bf1fac1fa2d60451e75e6681d5ae58a3f6'
PROMPTS_SHA256='9c98044ca9ccc45eaa3e8fcd9659d28c35e6b489d25a38268d834e19a0f84ca2'
VECTORS_SHA256='5251d16bfc6843039ff7014276caa03bb047b8daf995999470b5e1fe1886fe46'
_LOCK=threading.RLock()
_SIGNATURE=None
_MANIFEST=None
_NET=None
_VECTORS=None
_BUNDLE=None
_FILES=('manifest.json','encoder.onnx','prompt-vectors.npy','prompts.json','LICENSE.txt')

class SceneModelUnavailableError(ValueError):
    """A required local model asset is missing or fails verification."""


def verify_scene_models(root=None):
    from .photo_scene import LABELS,TAXONOMY_VERSION,MODEL_VERSION
    root=Path(root or MODEL_ROOT)
    try:
        for filename in _FILES:
            path=root/filename
            if path.is_symlink() or not path.is_file():raise ValueError('Missing regular local asset')
        manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
        if (manifest.get('schema_version')!=1 or type(manifest['schema_version']) is not int
                or manifest.get('model_version')!=MODEL_VERSION or manifest.get('taxonomy_version')!=TAXONOMY_VERSION
                or manifest.get('labels')!=list(LABELS) or manifest.get('input_size')!=224
                or manifest.get('embedding_size')!=512):raise ValueError('Unsupported scene model manifest')
        pins={'encoder.onnx':MODEL_SHA256,'LICENSE.txt':LICENSE_SHA256,
              'prompts.json':PROMPTS_SHA256,'prompt-vectors.npy':VECTORS_SHA256}
        if set(manifest.get('assets',{}))!=set(pins):raise ValueError('Unexpected scene assets')
        for filename,digest in pins.items():
            entry=manifest['assets'][filename];path=root/filename
            if (digest is None or entry.get('sha256')!=digest or type(entry.get('size')) is not int
                    or not 1<=entry['size']<=10_000_000 or path.stat().st_size!=entry['size']
                    or hashlib.sha256(path.read_bytes()).hexdigest()!=digest):raise ValueError('Scene asset integrity failure')
        prompts=json.loads((root/'prompts.json').read_text(encoding='utf-8'))
        if list(prompts)!=list(LABELS):raise ValueError('Invalid prompt catalogue')
        vectors=np.load(BytesIO((root/'prompt-vectors.npy').read_bytes()),allow_pickle=False)
        if vectors.dtype!=np.float32 or vectors.shape!=(2,len(LABELS),512) or not np.isfinite(vectors).all():raise ValueError('Invalid prompt vectors')
        if not np.allclose(np.linalg.norm(vectors,axis=2),1.,atol=1e-5):raise ValueError('Unnormalized prompt vectors')
        return manifest
    except (OSError,ValueError,TypeError,KeyError,AttributeError) as exc:
        raise SceneModelUnavailableError('The bundled scene classifier is unavailable or corrupt. Reinstall the complete application.') from exc


def _signature():
    root=Path(MODEL_ROOT);result=[str(root.resolve())]
    for filename in _FILES:
        path=root/filename
        if path.is_symlink() or not path.is_file():raise SceneModelUnavailableError('Missing local scene model')
        stat=path.stat();result.append((stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns,stat.st_ino))
    return tuple(result)


def _verified():
    global _SIGNATURE,_MANIFEST,_NET,_VECTORS,_BUNDLE
    signature=_signature()
    if signature!=_SIGNATURE or _MANIFEST is None:
        manifest=verify_scene_models()
        if _signature()!=signature:raise SceneModelUnavailableError('Scene model changed during verification')
        _NET=None;_VECTORS=None
        _BUNDLE=hashlib.sha256(json.dumps([(key,manifest['assets'][key]['sha256']) for key in sorted(manifest['assets'])],separators=(',',':')).encode()).hexdigest()
        _MANIFEST=manifest;_SIGNATURE=signature
    return _MANIFEST


def bundle_id():
    with _LOCK:
        _verified();return _BUNDLE


def _check_cancel(cancel_event):
    if cancel_event is not None and cancel_event.is_set():raise AnalysisCancelledError('Scene classification cancelled.')


def classify_embedding(rgb,cancel_event=None):
    """Return normalized similarities and the identity used for this forward."""
    global _NET,_VECTORS
    _check_cancel(cancel_event)
    # Match upstream CLIP bicubic short-edge resize then centered 224 crop.
    image=Image.fromarray(rgb);width,height=image.size
    if width>height*8:
        left=(width-height*8)//2;image=image.crop((left,0,left+height*8,height))
    elif height>width*8:
        top=(height-width*8)//2;image=image.crop((0,top,width,top+width*8))
    width,height=image.size
    scale=224/min(width,height)
    image=image.resize((max(224,int(width*scale)),max(224,int(height*scale))),Image.Resampling.BICUBIC)
    left=(image.width-224)//2;top=(image.height-224)//2
    pixels=np.asarray(image.crop((left,top,left+224,top+224)),dtype=np.float32)/255.
    pixels=(pixels-np.array([.48145466,.4578275,.40821073],np.float32))/np.array([.26862954,.26130258,.27577711],np.float32)
    blob=np.ascontiguousarray(pixels.transpose(2,0,1)[None])
    with _LOCK:
        _verified();_check_cancel(cancel_event)
        if _NET is None:
            _NET=cv2.dnn.readNetFromONNX(str(Path(MODEL_ROOT)/'encoder.onnx'))
            _NET.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV);_NET.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
            _VECTORS=np.load(Path(MODEL_ROOT)/'prompt-vectors.npy',allow_pickle=False)
        _NET.setInput(blob);embedding=_NET.forward().reshape(-1)
        _check_cancel(cancel_event)
        norm=np.linalg.norm(embedding)
        if embedding.shape!=(512,) or not np.isfinite(embedding).all() or norm<=1e-12:raise SceneModelUnavailableError('Invalid local scene embedding')
        embedding=embedding/norm
        return _VECTORS@embedding,_BUNDLE
