"""Cooperative cancellation for local photo analysis checkpoints."""


class AnalysisCancelledError(ValueError):
    """The current photo has no completed evidence to retain."""


def check_cancel(cancel_event):
    if cancel_event is not None and cancel_event.is_set():
        raise AnalysisCancelledError('Photo analysis cancelled.')
