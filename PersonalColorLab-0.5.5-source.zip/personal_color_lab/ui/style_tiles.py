"""Bounded photo-based style previews, computed without any Tk objects."""
from __future__ import annotations

import cv2
from PIL import Image
import numpy as np

from ..core.style_regions import style_distances
from ..core.style_render import _scene_effective, _render_regions, apply_pixels, _check_cancel


def build_style_tiles(preview, styles, cancel_event=None, limit=3, strength=.7):
    """Use the same measured source and local masks as the main preview.

    Photos/models are never decoded or inferred again. Results remain small
    arrays/plain data for the UI thread to present with native text labels.
    """
    _check_cancel(cancel_event)
    scene=preview.get('scene');report=scene['report'] if scene else None
    # Rank and render the same category-adapted recipe. Classification and
    # manual category evidence belong to the original photograph, not to the
    # thumbnail or a style's already colored output.
    prepared={}
    for key,dna in styles.items():
        _check_cancel(cancel_event)
        if dna['kind']=='hybrid':continue
        prepared[key]=_scene_effective(dna,preview['measurement'],preview.get('photo_scene'),report)
    choices=style_distances(preview['measurement'],{key:item[0] for key,item in prepared.items()},report)[:limit]
    pixels=preview['original'];height,width=pixels.shape[:2]
    scale=min(1.,224/max(height,width))
    source=cv2.resize(pixels,(max(1,round(width*scale)),max(1,round(height*scale))),interpolation=cv2.INTER_AREA)
    tiles=[]
    for key,distance,supported in choices:
        _check_cancel(cancel_event)
        dna,effective,evidence=prepared[key]
        if scene:
            rendered=_render_regions(source,effective,dna,strength,scene,.7,True,cancel_event,measurement=preview['measurement'])
        else:
            rendered=apply_pixels(source,effective,strength,cancel_event=cancel_event)[0]
        image=Image.fromarray(rendered)
        # A centered crop produces equally sized tiles, independently of photo
        # orientation. It changes the thumbnail view, never the export crop.
        ratio=1.4
        if image.width/image.height>ratio:
            length=round(image.height*ratio);left=(image.width-length)//2
            image=image.crop((left,0,left+length,image.height))
        else:
            length=round(image.width/ratio);top=(image.height-length)//2
            image=image.crop((0,top,image.width,top+length))
        image=image.resize((70,50),Image.Resampling.LANCZOS)
        tiles.append({'key':key,'distance':distance,'supported':bool(supported or evidence['matched_categories']),
                      'scene_style':evidence,'pixels':np.asarray(image).copy()})
    _check_cancel(cancel_event)
    return tiles
