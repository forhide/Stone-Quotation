"""Folder-to-style desktop workflow. Background jobs never own Tk objects."""

import math
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from ..core.constants import DB_FILENAME, JPEG_EXTENSIONS, RAW_EXTENSIONS, app_data_dir
from ..core.database import LibraryDB
from ..core.source_workflow import analyze_inputs, discover_inputs
from .display import ui_pixels
from .pair_inspector import analysis_text
from .scene_editor import SceneEditor, scene_labels_text, scene_report_lines, scene_summary_lines
from .theme import COLORS as C

MODES = ('raw_jpg', 'raw_xmp', 'reference_jpg')


def _number(value, digits=3):
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int, float)) and math.isfinite(value):
        return f'{value:.{digits}f}'.rstrip('0').rstrip('.') or '0'
    return None


def _metric(t, label, value, unit=''):
    rendered = _number(value)
    if rendered is None:
        rendered = str(value) if isinstance(value, str) else t('not_available')
    return t('metric_line', label=t(label), value=f'{rendered}{unit}')


def _appearance_lines(t, appearance):
    lines = []
    for title, section, key in (
        ('source_mean_luminance', 'luminance', 'mean'),
        ('source_contrast_span', 'luminance', 'contrast_span'),
        ('source_mean_saturation', 'saturation', 'mean'),
        ('source_lab_a', 'lab', 'mean_a'), ('source_lab_b', 'lab', 'mean_b'),
    ):
        lines.append(_metric(t, title, (appearance.get(section) or {}).get(key)))
    lines.extend(['', t('source_zonal_colors')])
    for zone, values in (appearance.get('tonal_zones') or {}).items():
        if not values.get('support_fraction'):
            continue
        lines.append(t('source_zone_line', zone=t('source_zone_' + zone), fraction=round(values['support_fraction'] * 100), a=_number(values.get('mean_a')), b=_number(values.get('mean_b'))))
    lines.extend(['', t('source_hue_coverage')])
    for hue, values in (appearance.get('hue_bands') or {}).items():
        if values.get('support_fraction', 0) >= 0.01:
            lines.append(t('source_hue_line', hue=t('channel_' + hue) if t('channel_' + hue) != 'channel_' + hue else t('source_hue_' + hue), fraction=round(values['support_fraction'] * 100), saturation=_number(values.get('saturation'))))
    return lines


def _warnings(i18n, payload):
    keys = ['source_warning_' + warning for warning in payload.get('warnings', [])]
    messages = [i18n.t(key) for key in keys if key in i18n.messages]
    invalid = payload.get('invalid_parameters') or []
    if invalid:
        messages.append(i18n.t('source_invalid_parameters', names=', '.join(i18n.t('source_param_' + name) if 'source_param_' + name in i18n.messages else name for name in invalid)))
    return list(dict.fromkeys(messages))


def _scene_reports_by_fingerprint(batch):
    reports = {}
    for result in (batch or {}).get('results', []):
        payload = result.get('payload') or {}
        fingerprint = payload.get('provenance', {}).get('input_fingerprints', {}).get('original')
        if result.get('status') == 'ok' and fingerprint and payload.get('photo_scene'):
            reports[fingerprint] = payload['photo_scene']
    return reports


def source_summary_text(i18n, batch):
    """Readable, localized evidence; a saved style is an analysis snapshot."""
    t = i18n.t
    mode, summary = batch.get('mode'), batch.get('summary') or {}
    lines = [t('source_batch_summary'), '']
    count = summary.get('sample_count', batch.get('counts', {}).get('successful', 0))
    lines.append(t('source_result_count', count=count))
    if count:
        lines.extend(scene_summary_lines(i18n, summary.get('scene_stats')))
        if any('scene_manual_assignment_conflict' in (row.get('payload') or {}).get('photo_scene', {}).get('warnings', [])
               for row in batch.get('results', [])):
            lines.append(t('scene_conflict_help'))
    semantic_count=sum(1 for row in batch.get('results',[]) if (row.get('payload') or {}).get('semantic',{}).get('status')=='ok')
    if semantic_count:lines.append(t('source_semantic_samples',count=semantic_count))
    performance=batch.get('performance')
    if performance:
        lines.append(t('source_performance',cached=performance['cache_hits'],duplicates=performance['avoided_duplicate_decodes'],seconds=f"{performance['elapsed_seconds']:.1f}"))
    if not count:
        lines.append(t('source_empty_summary'))
        return '\n'.join(lines)
    if mode == 'reference_jpg':
        lines.extend(['', t('source_appearance_notice'), '', t('source_sample_count', count=count)])
        duplicates = summary.get('duplicate_count', 0)
        if duplicates:
            lines.append(t('source_duplicate_count', count=duplicates))
        tendencies = summary.get('tendencies') or summary.get('appearance', {}).get('tendencies') or {}
        for key, value in tendencies.items():
            if key in ('brightness', 'contrast', 'saturation', 'temperature'):
                lines.append(t('metric_line', label=t('source_' + key), value=t('source_' + str(value))))
        lines.extend(['', t('source_reference_metrics'), *_appearance_lines(t, summary.get('appearance') or {})])
        consistency = summary.get('consistency') or {}
        lines.extend(['', t('source_consistency', value=t('source_consistency_' + consistency.get('level', 'insufficient')))])
        lines.append(t('source_reference_confidence', value=round(summary.get('confidence', 0) * 100)))
        if count < 5:
            lines.extend(['', t('source_reference_limit')])
        outliers = summary.get('outliers') or []
        if outliers:
            lines.extend(['', t('source_outliers', names=', '.join(Path(row['original_path']).name for row in outliers))])
        for group in summary.get('similar_groups',[]):
            lines.extend(['',t('source_near_duplicates',names=', '.join(Path(path).name for path in group['paths']))])
    elif mode == 'raw_jpg':
        lines.extend(['', t('source_pair_summary'), t('source_raw_notice'), ''])
        for label, key, unit in (
            ('exposure_ev', 'exposure_ev_median', ' EV'),
            ('luminance_delta', 'brightness_delta_median', ''),
            ('contrast_delta', 'contrast_delta_median', ''),
        ):
            lines.append(_metric(t, label, summary.get(key), unit))
        for title, key in (('temperature_tendency', 'temperature_counts'), ('tint_tendency', 'tint_counts')):
            for direction, amount in (summary.get(key) or {}).items():
                lines.append(t('metric_line', label=t(title), value=f'{t("direction_" + direction)} · {amount}'))
    else:
        lines.extend(['', t('source_xmp_notice'), '', t('source_xmp_summary')])
        for name, values in (summary.get('parameters') or {}).items():
            if isinstance(values, dict) and 'median' in values:
                value = _number(values['median'])
                span = f'{_number(values.get("min"))} … {_number(values.get("max"))}'
                value = f'{value}  ({span}; n={values.get("count", 0)})'
            else:
                value = ', '.join(str(v) for v in values.get('values', [])) if isinstance(values, dict) else str(values)
            lines.append(t('metric_line', label=t('source_param_' + name) if 'source_param_' + name in i18n.messages else name, value=value))
        lines.append(_metric(t, 'source_tone_curves', summary.get('tone_curve_count')))
    warnings = _warnings(i18n, summary)
    for result in batch.get('results', []):
        if mode == 'raw_xmp':
            warnings.extend(_warnings(i18n, result.get('payload') or {}))
    if warnings:
        lines.extend(['', t('source_notes'), *dict.fromkeys(warnings)])
    return '\n'.join(lines)


def source_result_text(i18n, result):
    t = i18n.t
    item, payload = result.get('item') or {}, result.get('payload') or {}
    mode = item.get('source_type', payload.get('source_type'))
    lines = [Path(item.get('original_path') or '').name]
    if item.get('edited_path'):
        lines.append(Path(item['edited_path']).name)
    if result.get('status') == 'duplicate':
        lines.extend(['', t('scene_duplicate_help')])
        return '\n'.join(lines)
    if result.get('status') != 'ok':
        code = result.get('error_code') or payload.get('status') or result.get('status', 'failed')
        key = 'source_error_' + str(code)
        lines.extend(['', t(key if key in i18n.messages else 'source_failure_help')])
        return '\n'.join(lines)
    lines.extend(scene_report_lines(i18n, payload.get('photo_scene')))
    if mode == 'reference_jpg':
        appearance = payload.get('appearance') or {}
        lines.extend(['', t('source_appearance_notice'), ''])
        for key, value in (appearance.get('tendencies') or {}).items():
            if key in ('brightness', 'contrast', 'saturation', 'temperature'):
                lines.append(t('metric_line', label=t('source_' + key), value=t('source_' + str(value))))
        lines.extend(['', *_appearance_lines(t, appearance)])
    elif mode == 'raw_xmp':
        lines.extend(['', t('source_xmp_notice'), '', t('source_parameters')])
        units = payload.get('parameter_units') or {}
        for name, value in (payload.get('parameters') or {}).items():
            label = t('source_param_' + name) if 'source_param_' + name in i18n.messages else name
            rendered = t('source_true' if value else 'source_false') if isinstance(value, bool) else _number(value) or str(value)
            unit_name = units.get(name)
            unit = t('source_unit_' + unit_name) if unit_name and unit_name not in {'boolean', 'enum'} else ''
            lines.append(t('metric_line', label=label, value=f'{rendered} {unit}'.strip()))
        for name, points in (payload.get('tone_curves') or {}).items():
            lines.extend(['', f'{t("source_tone_curves")} · {name}', ' → '.join(str(point) for point in points)])
    else:
        text = analysis_text(i18n, payload)
        text = text.replace(t('inferred_analysis'), t('source_raw_notice'))
        # The shared renderer is also used for JPEG pairs. Its source label must
        # not misrepresent a RAW rendering as an original camera JPEG.
        text = text.replace(t('analysis_provenance', version=payload.get('algorithm_version', '0.2.0')), '')
        lines.extend(['', text])
    semantic=payload.get('semantic',{})
    if semantic.get('status')=='ok':
        objects=list(dict.fromkeys(t('object_'+item['class_code']) for item in semantic.get('objects',[])))
        if objects:lines.extend(['',t('source_objects_detected',objects=', '.join(objects[:10]))])
    warnings = _warnings(i18n, payload)
    if warnings:
        lines.extend(['', t('source_notes'), *warnings])
    return '\n'.join(lines)


def _scan_job(events, folder, mode, recursive):
    try:
        events.put(('discovered', discover_inputs(folder, mode, recursive=recursive)))
    except Exception as exc:
        events.put(('error', str(exc)))
    finally:
        events.put(('finished',))


def _analysis_job(events, items, mode, cancel_event, db_path):
    try:
        def progress(done, total, filename):
            events.put(('progress', done, total, filename))
        with LibraryDB(db_path) as cache:
            events.put(('analyzed', analyze_inputs(items, mode, progress=progress, cancel_event=cancel_event,cache=cache)))
    except Exception as exc:
        events.put(('error', str(exc)))
    finally:
        events.put(('finished',))


class SourceWorkflow(tk.Toplevel):
    """Three input routes, review, analysis and persistent named styles."""

    def __init__(self, parent, folder=None, *, mode=None, recursive=True, profiles=False):
        super().__init__(parent)
        self.i18n = parent.i18n
        self.folder = Path(folder) if folder else None
        self.recursive = recursive
        self.mode = mode if mode in MODES else 'reference_jpg'
        self._auto_mode = mode is None
        self._mode_explicit = mode in MODES
        self._events = queue.Queue()
        self._cancel_event = threading.Event()
        self._threads = []
        self._closed = False
        self._busy = False
        self._job = None
        self._pending_mode = None
        self._items = {}
        self._included = set()
        self._results = {}
        self._scene_reports = {}
        self._profiles = {}
        self._scene_dialog = None
        self.batch = None
        self._status_key = 'source_next'
        self._status_kwargs = {}
        self._result_help_key = 'source_result_help'
        self._labels = []
        self._buttons = []
        self.mode_cards = {}
        self.phase_labels = {}
        self.style_name = tk.StringVar(value='')
        self.progress = tk.DoubleVar(value=0)
        self.status = tk.StringVar(value='')
        dp = lambda value: ui_pixels(self, value)
        self.configure(background=C['bg'])
        self.geometry(f'{dp(1090)}x{dp(820)}')
        self.minsize(dp(940), dp(740))
        self.protocol('WM_DELETE_WINDOW', self.close)
        self._build()
        self.translate()
        self.reload_profiles()
        self._poll_id = self.after(60, self._poll)
        if profiles:
            self.tabs.select(self.profiles_tab)
        elif self.folder:
            self.start_scan(auto_mode=self._auto_mode)

    def _label(self, parent, key, *, font='LabBody', color='text', **kwargs):
        label = tk.Label(parent, text=self.i18n.t(key), font=font, foreground=C[color], background=parent.cget('background'), **kwargs)
        self._labels.append((label, key))
        return label

    def _button(self, parent, key, command, primary=False):
        button = ttk.Button(parent, text=self.i18n.t(key), command=command, style='Primary.TButton' if primary else 'Secondary.TButton')
        self._buttons.append((button, key))
        return button

    def _build(self):
        dp = lambda value: ui_pixels(self, value)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        top = tk.Frame(self, background=C['bg'], padx=dp(24), pady=dp(17))
        top.grid(row=0, column=0, sticky='ew')
        top.columnconfigure(0, weight=1)
        self.heading_label = self._label(top, 'source_title', font='LabTitle')
        self.heading_label.grid(row=0, column=0, sticky='w')
        self.folder_btn = self._button(top, 'source_choose_folder', self.choose_folder)
        self.folder_btn.configure(style='Quiet.TButton')
        self.folder_btn.grid(row=0, column=1, rowspan=2, sticky='ne', padx=(dp(16), 0))
        self._label(top, 'source_subtitle', color='muted', wraplength=dp(680), justify='left').grid(row=1, column=0, sticky='w', pady=(dp(5), dp(0)))
        self.folder_label = tk.Label(top, font='LabSmall', background=C['bg'], foreground=C['subtle'], anchor='w', justify='left', wraplength=dp(1000))
        self.folder_label.grid(row=2, column=0, columnspan=2, sticky='ew', pady=(dp(9), 0))
        phases = self.phases_frame = tk.Frame(top, background=C['bg'])
        phases.grid(row=3, column=0, columnspan=2, sticky='ew', pady=(dp(13), 0))
        for index, phase in enumerate(('source', 'review', 'result')):
            phases.columnconfigure(index, weight=1)
            label = self._label(phases, 'source_phase_' + phase, font='LabSmall', color='muted', anchor='w')
            label.grid(row=0, column=index, sticky='ew')
            self.phase_labels[phase] = label
        modes = self.modes_frame = tk.Frame(self, background=C['bg'], padx=dp(24))
        modes.grid(row=1, column=0, sticky='ew')
        self.mode_buttons = {}
        for index, mode in enumerate(MODES):
            modes.columnconfigure(index, weight=1, uniform='modes')
            card = tk.Frame(modes, background=C['surface'], highlightbackground=C['border'],
                            highlightthickness=dp(1), padx=dp(9), pady=dp(9))
            card.grid(row=0, column=index, sticky='nsew', padx=(0, dp(8)) if index < 2 else 0)
            card.columnconfigure(0, weight=1)
            button = self._button(card, 'source_mode_' + mode, lambda selected=mode: self.set_mode(selected))
            button.configure(padding=(dp(10), dp(8)))
            button.grid(row=0, column=0, sticky='ew')
            description = self._label(card, 'source_route_' + mode, font='LabSmall', color='muted',
                                      anchor='w', justify='left', wraplength=dp(255))
            description.grid(row=1, column=0, sticky='ew', pady=(dp(7), 0))
            # The full source card is clickable; keyboard selection remains
            # on its native ttk button.
            for target in (card, description):
                target.bind('<Button-1>', lambda event, selected=mode: self.set_mode(selected))
            self.mode_buttons[mode] = button
            self.mode_cards[mode] = card
        self.mode_hint = tk.Label(modes, font='LabSmall', background=C['bg'], foreground=C['muted'], anchor='w', justify='left', wraplength=dp(990))
        self.mode_hint.grid(row=1, column=0, columnspan=3, sticky='ew', pady=(dp(10), dp(14)))
        self.tabs = ttk.Notebook(self)
        self.tabs.grid(row=2, column=0, sticky='nsew', padx=dp(24))
        self.review_tab = tk.Frame(self.tabs, background=C['surface'], padx=dp(12), pady=dp(12))
        self.result_tab = tk.Frame(self.tabs, background=C['surface'], padx=dp(12), pady=dp(12))
        self.profiles_tab = tk.Frame(self.tabs, background=C['surface'], padx=dp(12), pady=dp(12))
        for tab in (self.review_tab, self.result_tab, self.profiles_tab):
            self.tabs.add(tab)
            tab.columnconfigure(0, weight=1)
        self.tabs.bind('<<NotebookTabChanged>>', self._tab_changed)
        self.review_tab.rowconfigure(0, weight=1)
        self.review_tree = self._tree(self.review_tab, ('include', 'file', 'companion', 'scene', 'state'), row=0)
        for key, width in (('include', 55), ('file', 215), ('companion', 205), ('scene', 190), ('state', 160)):
            self.review_tree.column(key, width=dp(width), minwidth=dp(40 if key == 'include' else 120), stretch=key != 'include', anchor='center' if key == 'include' else 'w')
        self.review_tree.bind('<<TreeviewSelect>>', self._review_selected)
        self.review_tree.bind('<Double-1>', self._review_activate)
        self.review_tree.bind('<space>', lambda event: self.toggle_selected())
        self.review_tree.bind('<Return>', lambda event: self.edit_review_scene())
        self.review_hint = tk.Label(self.review_tab, font='LabSmall', background=C['surface'], foreground=C['muted'], anchor='w', justify='left', wraplength=dp(950))
        self.review_hint.grid(row=1, column=0, sticky='ew', pady=(dp(8), dp(8)))
        review_actions = tk.Frame(self.review_tab, background=C['surface'])
        review_actions.grid(row=2, column=0, sticky='ew')
        self.toggle_btn = self._button(review_actions, 'source_toggle', self.toggle_selected)
        self.toggle_btn.pack(side='left')
        self.resolve_btn = self._button(review_actions, 'source_resolve', self.resolve_selected)
        self.resolve_btn.pack(side='left', padx=dp(8))
        self.review_scene_btn = self._button(review_actions, 'scene_edit', self.edit_review_scene)
        self.review_scene_btn.pack(side='left')
        self.result_tab.rowconfigure(3, weight=1)
        self.result_heading = self._label(self.result_tab, 'source_result_heading', font='LabHeading')
        self.result_heading.grid(row=0, column=0, sticky='w', pady=(0, dp(12)))
        self.cards_frame = tk.Frame(self.result_tab, background=C['surface'])
        self.cards_frame.grid(row=1, column=0, sticky='ew')
        self.cards = {}
        for index, key in enumerate(('brightness', 'contrast', 'saturation', 'temperature')):
            self.cards_frame.columnconfigure(index, weight=1, uniform='tendency')
            card = tk.Frame(self.cards_frame, background=C['elevated'], padx=dp(11), pady=dp(10))
            card.grid(row=0, column=index, sticky='nsew', padx=(0, dp(8)) if index < 3 else 0)
            self._label(card, 'source_' + key, font='LabSmall', color='muted').pack(anchor='w')
            value = tk.Label(card, font='LabHeading', background=C['elevated'], foreground=C['accent'], anchor='w')
            value.pack(anchor='w', pady=(dp(6), 0))
            self.cards[key] = value
        self.palette = tk.Canvas(self.result_tab, height=dp(24), background=C['surface'], highlightthickness=0)
        self.palette.grid(row=2, column=0, sticky='ew', pady=(dp(10), dp(10)))
        self.palette.bind('<Configure>', lambda event: self._draw_palette())
        result_body = tk.Frame(self.result_tab, background=C['surface'])
        result_body.grid(row=3, column=0, sticky='nsew')
        result_body.columnconfigure(0, weight=1)
        # Both sections shrink on small windows; the details must retain a
        # readable viewport instead of the file list taking all available space.
        result_body.rowconfigure(0, weight=1, minsize=dp(60))
        result_body.rowconfigure(1, weight=3, minsize=dp(90))
        self.tk.call('ttk::style', 'configure', 'Source.Lab.Treeview', '-rowheight', dp(30))
        self.result_tree = self._tree(result_body, ('file', 'scene', 'state'), row=0, height=2)
        self.result_tree.configure(style='Source.Lab.Treeview')
        self.result_tree.column('file', width=dp(475))
        self.result_tree.column('scene', width=dp(215))
        self.result_tree.column('state', width=dp(170), stretch=False)
        self.result_tree.bind('<<TreeviewSelect>>', self._result_selected)
        self.result_tree.bind('<Double-1>', lambda event: self.edit_result_scene())
        text_box = tk.Frame(result_body, background=C['surface'])
        text_box.grid(row=1, column=0, sticky='nsew', pady=(dp(8), 0))
        text_box.columnconfigure(0, weight=1)
        text_box.rowconfigure(0, weight=1)
        self.details = tk.Text(text_box, wrap='word', font='LabBody', background=C['surface'], foreground=C['text'], insertbackground=C['text'], relief='flat', borderwidth=0, padx=dp(6), pady=dp(6), height=5, state='disabled')
        self.details.grid(row=0, column=0, sticky='nsew')
        scrollbar = ttk.Scrollbar(text_box, orient='vertical', style='Lab.Vertical.TScrollbar', command=self.details.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')
        self.details.configure(yscrollcommand=scrollbar.set)
        save_bar = tk.Frame(self.result_tab, background=C['surface'])
        save_bar.grid(row=4, column=0, sticky='ew', pady=(dp(10), 0))
        save_bar.columnconfigure(1, weight=1)
        self.result_help = self._label(save_bar, 'source_result_help', font='LabSmall', color='muted',
                                       anchor='w', justify='left', wraplength=dp(930))
        self.result_help.grid(row=0, column=0, columnspan=4, sticky='ew', pady=(0, dp(8)))
        self.result_scene_btn = self._button(save_bar, 'scene_edit', self.edit_result_scene)
        self.result_scene_btn.grid(row=2, column=0, sticky='w', pady=(dp(8), 0))
        self.result_scene_hint = self._label(save_bar, 'scene_result_help', font='LabSmall', color='muted',
                                              anchor='w', justify='left', wraplength=dp(700))
        self.result_scene_hint.grid(row=2, column=1, columnspan=3, sticky='w', padx=(dp(12), 0), pady=(dp(8), 0))
        self._label(save_bar, 'source_save_name', font='LabSmall', color='muted').grid(row=1, column=0, padx=(0, dp(12)))
        self.name_entry = ttk.Entry(save_bar, textvariable=self.style_name, style='Lab.TEntry')
        self.name_entry.grid(row=1, column=1, sticky='ew')
        self.name_entry.bind('<Return>', lambda event: self.save_profile())
        self.save_btn = self._button(save_bar, 'source_save', self.save_profile)
        self.save_btn.grid(row=1, column=2, padx=(dp(10), 0))
        self.apply_btn=self._button(save_bar,'style_apply',self.apply_batch,primary=True)
        self.apply_btn.grid(row=1,column=3,padx=(dp(8),0))
        self.profiles_tab.rowconfigure(0, weight=1)
        self.profiles_tree = self._tree(self.profiles_tab, ('name', 'mode', 'date'), row=0)
        for key, width in (('name', 440), ('mode', 200), ('date', 225)):
            self.profiles_tree.column(key, width=dp(width))
        self.profiles_tree.bind('<Double-1>', lambda event: self.open_profile())
        self.profiles_tree.bind('<Return>', lambda event: self.open_profile())
        self.profiles_tree.bind('<<TreeviewSelect>>', lambda event: self._controls())
        self.profiles_hint = self._label(self.profiles_tab, 'source_no_profiles', font='LabSmall', color='muted')
        self.profiles_hint.grid(row=1, column=0, sticky='w', pady=dp(10))
        self.open_profile_btn = self._button(self.profiles_tab, 'source_open_profile', self.open_profile)
        self.open_profile_btn.grid(row=2, column=0, sticky='e')
        profile_actions=tk.Frame(self.profiles_tab,background=C['surface'])
        profile_actions.grid(row=2,column=0,sticky='w')
        self.rename_btn=self._button(profile_actions,'source_rename',self.rename_profile)
        self.rename_btn.pack(side='left')
        self.delete_btn=self._button(profile_actions,'source_delete',self.delete_profile)
        self.delete_btn.pack(side='left',padx=dp(8))
        footer = tk.Frame(self, background=C['bg'], padx=dp(24), pady=dp(14))
        footer.grid(row=3, column=0, sticky='ew')
        footer.columnconfigure(0, weight=1)
        self.status_label = tk.Label(footer, textvariable=self.status, font='LabSmall', background=C['bg'], foreground=C['muted'], anchor='w', justify='left', wraplength=dp(540))
        self.status_label.grid(row=0, column=0, sticky='ew', padx=(0, dp(12)))
        self.refresh_btn = self._button(footer, 'source_refresh', self.start_scan)
        self.refresh_btn.grid(row=0, column=1, padx=(0, dp(8)))
        self.analyze_btn = self._button(footer, 'source_analyze', self.start_analysis, primary=True)
        self.analyze_btn.grid(row=0, column=2)
        self.cancel_btn = self._button(footer, 'source_cancel', self.cancel)
        self.cancel_btn.grid(row=0, column=3, padx=(dp(8), 0))
        self.cancel_btn.grid_remove()
        self.progressbar = ttk.Progressbar(footer, variable=self.progress, maximum=100, style='Lab.Horizontal.TProgressbar')
        self.progressbar.grid(row=1, column=0, columnspan=4, sticky='ew', pady=(dp(10), 0))
        self.progressbar.grid_remove()
        self._set_details(self.i18n.t('source_result_empty'))

    def _tree(self, parent, columns, row, height=6):
        container = tk.Frame(parent, background=C['surface'])
        container.grid(row=row, column=0, sticky='nsew')
        container.columnconfigure(0, weight=1)
        container.rowconfigure(0, weight=1)
        tree = ttk.Treeview(container, columns=columns, show='headings', style='Lab.Treeview', height=height, selectmode='extended')
        tree.grid(row=0, column=0, sticky='nsew')
        scrollbar = ttk.Scrollbar(container, orient='vertical', style='Lab.Vertical.TScrollbar', command=tree.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')
        tree.configure(yscrollcommand=scrollbar.set)
        tree.tag_configure('excluded', foreground=C['subtle'])
        tree.tag_configure('warning', foreground=C['warning'])
        return tree

    def translate(self):
        t = self.i18n.t
        self.title(t('source_title'))
        for widget, key in self._labels + self._buttons:
            widget.configure(text=t(key))
        self.result_help.configure(text=t(self._result_help_key))
        self.folder_label.configure(text=t('source_folder', path=str(self.folder)) if self.folder else '')
        self.mode_hint.configure(text=t('source_hint_' + self.mode))
        for mode, button in self.mode_buttons.items():
            button.configure(style='Primary.TButton' if mode == self.mode else 'Secondary.TButton')
            self.mode_cards[mode].configure(highlightbackground=C['accent'] if mode == self.mode else C['border'])
        for tab, key in ((self.review_tab, 'source_review'), (self.result_tab, 'source_result'), (self.profiles_tab, 'source_profiles')):
            self.tabs.tab(tab, text=t(key))
        for column, key in (('include', 'source_include'), ('file', 'source_file'), ('companion', 'source_companion'), ('scene', 'scene_heading'), ('state', 'source_state')):
            self.review_tree.heading(column, text=t(key))
        for column, key in (('file', 'source_file'), ('scene', 'scene_heading'), ('state', 'source_state')):
            self.result_tree.heading(column, text=t(key))
        for column, key in (('name', 'source_profile_name'), ('mode', 'source_profile_mode'), ('date', 'source_profile_date')):
            self.profiles_tree.heading(column, text=t(key))
        for row, item in self._items.items():
            self._update_review_row(row, item)
        self._render_batch(select=False)
        self._review_selected()
        self._set_status(self._status_key, **self._status_kwargs)
        self._controls()
        if self._profiles:
            self._render_profiles()
        if self._scene_dialog is not None:
            self._scene_dialog.translate()

    def _set_status(self, key, **kwargs):
        self._status_key, self._status_kwargs = key, kwargs
        self.status.set(self.i18n.t(key, **kwargs))

    def _tab_changed(self, event=None):
        if not self._closed and self.winfo_exists():
            self._controls()

    def _sync_navigation(self):
        selected = self.tabs.select()
        review = selected == str(self.review_tab)
        result = selected == str(self.result_tab)
        self.heading_label.configure(text=self.i18n.t('source_profiles' if selected == str(self.profiles_tab) else 'source_title'))
        phase = 'result' if result else 'review' if self.folder else 'source'
        for key, label in self.phase_labels.items():
            label.configure(foreground=C['accent'] if key == phase else C['muted'])
        self.phases_frame.grid_remove() if selected == str(self.profiles_tab) else self.phases_frame.grid()
        # Source selection matters on the review page. Once analysis is
        # finished, the saved style and its next action get the whole viewport.
        self.modes_frame.grid() if review else self.modes_frame.grid_remove()
        self.refresh_btn.grid() if review else self.refresh_btn.grid_remove()
        self.analyze_btn.grid() if review or self._job == 'analysis' else self.analyze_btn.grid_remove()
        self.folder_btn.configure(text=self.i18n.t('source_choose_folder' if self.folder else 'choose_folder'))
        self.status_label.configure(wraplength=ui_pixels(self, 540 if review else 980))

    def _controls(self):
        for widget in (*self.mode_buttons.values(), self.folder_btn, self.refresh_btn, self.toggle_btn, self.resolve_btn, self.rename_btn, self.delete_btn, self.review_scene_btn, self.result_scene_btn):
            widget.configure(state='disabled' if self._busy else 'normal')
        self.refresh_btn.configure(state='normal' if self.folder and not self._busy else 'disabled')
        self.analyze_btn.configure(state='normal' if self._included and not self._busy else 'disabled')
        if self._included:
            key = 'source_analyze_count' if self.mode == 'reference_jpg' else 'source_analyze_pairs'
            self.analyze_btn.configure(text=self.i18n.t(key, count=len(self._included)))
        else:
            self.analyze_btn.configure(text=self.i18n.t('source_analyze'))
        has_results = bool(self.batch and any(row.get('status') == 'ok' for row in self.batch.get('results', [])))
        self.save_btn.configure(state='normal' if has_results and not self._busy else 'disabled')
        self.apply_btn.configure(state='normal' if has_results and not self._busy else 'disabled')
        selected_result = self.result_tree.selection()
        selected_record = self._results.get(selected_result[0]) if selected_result else None
        editable_result = bool(selected_record and selected_record.get('status') in ('ok', 'duplicate')
                               and (selected_record.get('item') or {}).get('id')
                               and (selected_record.get('status') == 'ok' or self._scene_report_for_result(selected_record)))
        self.result_scene_btn.configure(state='normal' if editable_result and not self._busy else 'disabled')
        self.result_scene_btn.grid() if has_results else self.result_scene_btn.grid_remove()
        self.result_scene_hint.grid() if has_results else self.result_scene_hint.grid_remove()
        profile_selected = bool(self.profiles_tree.selection())
        for widget in (self.open_profile_btn, self.rename_btn, self.delete_btn):
            widget.configure(state='normal' if profile_selected and not self._busy else 'disabled')
        if self._busy:
            self.progressbar.grid()
            self.cancel_btn.grid() if self._job == 'analysis' else self.cancel_btn.grid_remove()
        else:
            self.progressbar.grid_remove()
            self.cancel_btn.grid_remove()
            selected = self.review_tree.selection()
            self.toggle_btn.configure(state='normal' if any(self._items[row]['status'] == 'ready' for row in selected) else 'disabled')
            self.resolve_btn.configure(state='normal' if len(selected) == 1 and self.mode != 'reference_jpg' else 'disabled')
            self.review_scene_btn.configure(state='normal' if len(selected) == 1 and self._items[selected[0]].get('status') == 'ready' else 'disabled')
        self._sync_navigation()

    def choose_folder(self):
        if self._busy:
            return
        chosen = filedialog.askdirectory(parent=self, initialdir=str(self.folder) if self.folder else None)
        if not chosen:
            return
        folder = Path(chosen).expanduser()
        if not folder.is_dir():
            self._set_status('folder_not_selected')
            return
        self.folder = folder
        self.folder_label.configure(text=self.i18n.t('source_folder', path=str(folder)))
        self.start_scan(auto_mode=not self._mode_explicit)

    def set_mode(self, mode, *, automatic=False):
        if self._busy or mode not in MODES:
            return
        if self._scene_dialog is not None:
            self._scene_dialog.close()
        self.mode = mode
        self._auto_mode = False
        if not automatic:
            self._mode_explicit = True
        self.batch = None
        self._items.clear()
        self._included.clear()
        self.review_tree.delete(*self.review_tree.get_children())
        self.translate()
        if self.folder:
            self.start_scan()

    def start_scan(self, auto_mode=False):
        if self._busy or not self.folder:
            return
        if self._scene_dialog is not None:
            self._scene_dialog.close()
        self._busy, self._job = True, 'scan'
        self.batch = None
        self._result_help_key = 'source_result_help'
        self._items.clear()
        self._included.clear()
        self.review_tree.delete(*self.review_tree.get_children())
        self._render_batch()
        self.tabs.select(self.review_tab)
        self.progress.set(0)
        self._set_status('source_scanning')
        self._controls()
        # An initial JPG scan also returns extension counts, used once to offer
        # the appropriate source without asking the user to identify filenames.
        self._auto_mode = bool(auto_mode)
        self._start_thread(_scan_job, self._events, self.folder, self.mode, self.recursive)

    def _start_thread(self, target, *args):
        self._threads = [thread for thread in self._threads if thread.is_alive()]
        thread = threading.Thread(target=target, args=args, daemon=True)
        self._threads.append(thread)
        thread.start()

    def _receive_discovery(self, discovery):
        counts = discovery.get('counts') or {}
        if self._auto_mode:
            self._auto_mode = False
            preferred = 'raw_xmp' if counts.get('raw') and counts.get('xmp') else 'raw_jpg' if counts.get('raw') and counts.get('jpg') else 'reference_jpg'
            if preferred != self.mode:
                # Start the dependent rescan only after this worker completes.
                self._pending_mode = preferred
                return
        for index, item in enumerate(discovery.get('items') or []):
            row = str(index)
            self._items[row] = dict(item)
            if item.get('status') == 'ready':
                self._included.add(row)
            self.review_tree.insert('', 'end', iid=row)
            self._update_review_row(row, item)
        self._update_review_status()
        self.style_name.set(self.i18n.t('source_default_name', name=self.folder.name))
        self._review_selected()

    def _update_review_row(self, row, item):
        t = self.i18n.t
        status = item.get('status', 'unmatched')
        state_key = 'source_' + status if status != 'ready' or row in self._included else 'source_excluded'
        scene = scene_labels_text(self.i18n, item.get('photo_scene'), override=item.get('scene_override'))
        self.review_tree.item(row, values=(t('source_yes') if row in self._included else t('source_no'), Path(item.get('original_path') or '').name, Path(item['edited_path']).name if item.get('edited_path') else t('source_no'), scene, t(state_key)), tags=('warning',) if status != 'ready' else ('excluded',) if row not in self._included else ())

    def _update_review_status(self):
        if not self._items:
            self._set_status('source_no_files')
        else:
            unresolved = sum(item.get('status') != 'ready' for item in self._items.values())
            self._set_status('source_ready_count', included=len(self._included), unresolved=unresolved)
        self._controls()

    def _review_selected(self, event=None):
        selected = self.review_tree.selection()
        item = self._items.get(selected[0]) if selected else None
        if item and item.get('status') != 'ready':
            key = 'source_reason_missing_raw' if item.get('reason') == 'missing_raw' else 'source_reason_ambiguous' if item['status'] == 'ambiguous' else 'source_reason_unmatched'
        else:
            key = 'source_next'
        self.review_hint.configure(text=self.i18n.t(key))
        self._controls()

    def toggle_selected(self):
        if self._busy:
            return
        selected = [row for row in self.review_tree.selection() if self._items[row].get('status') == 'ready']
        include = not all(row in self._included for row in selected)
        for row in selected:
            self._included.add(row) if include else self._included.discard(row)
            self._update_review_row(row, self._items[row])
        self._update_review_status()

    def _review_activate(self, event):
        if self.review_tree.identify_column(event.x) == '#4':
            row = self.review_tree.identify_row(event.y)
            if row:
                self.review_tree.selection_set(row)
                self.edit_review_scene()
        else:
            self.toggle_selected()

    def resolve_selected(self):
        selected = self.review_tree.selection()
        if self._busy or len(selected) != 1 or self.mode == 'reference_jpg':
            return
        item = self._items[selected[0]]
        jpeg = self.mode == 'raw_jpg'
        missing_raw = item.get('reason') == 'missing_raw'
        title = self.i18n.t('source_choose_raw' if missing_raw else 'source_choose_jpg' if jpeg else 'source_choose_xmp', name=Path(item['original_path']).name)
        extensions = RAW_EXTENSIONS if missing_raw else JPEG_EXTENSIONS if jpeg else {'.xmp'}
        patterns = tuple('*' + ext for ext in sorted(extensions)) + tuple('*' + ext.upper() for ext in sorted(extensions))
        filetypes = [(self.i18n.t('source_raw_files' if missing_raw else 'jpeg_files' if jpeg else 'source_xmp_files'), patterns)]
        chosen = filedialog.askopenfilename(parent=self, title=title, filetypes=filetypes)
        if not chosen:
            return
        path = Path(chosen).resolve()
        if not path.is_file() or path.suffix.lower() not in extensions:
            self._set_status('source_invalid_match')
            return
        if missing_raw:
            item.update(original_path=str(path), edited_path=item['original_path'])
        else:
            item['edited_path'] = str(path)
        item.update(status='ready', reason='manual_selection')
        self._included.add(selected[0])
        self._update_review_row(selected[0], item)
        self._update_review_status()
        self._review_selected()

    def start_analysis(self):
        if self._busy or not self._included:
            return
        if self._scene_dialog is not None:
            self._scene_dialog.close()
        items = [dict(item) for row, item in self._items.items() if row in self._included]
        self._busy, self._job = True, 'analysis'
        self.batch = None
        self._result_help_key = 'source_result_help'
        self._render_batch()
        self._cancel_event = threading.Event()
        self.cancel_btn.configure(state='normal')
        self.progress.set(0)
        self._set_status('source_analyzing', done=0, total=len(items), name='')
        self._controls()
        self._start_thread(_analysis_job, self._events, items, self.mode, self._cancel_event,app_data_dir()/DB_FILENAME)

    def edit_review_scene(self):
        """Select plain labels before analysis; the worker never owns Tk state."""
        selected = self.review_tree.selection()
        if self._busy or len(selected) != 1:
            return
        row = selected[0]
        item = self._items.get(row)
        if not item or item.get('status') != 'ready':
            return
        def apply(labels):
            if self._closed or self._busy or self._items.get(row) is not item:
                return
            item['scene_override'] = None if labels is None else list(labels)
            self._update_review_row(row, item)
            self._set_status('scene_review_updated')
        self._open_scene_editor(item, item.get('photo_scene'), apply)

    def edit_result_scene(self):
        """Rebuild scene evidence from the saved measurements, without decoding."""
        selected = self.result_tree.selection()
        if self._busy or len(selected) != 1 or not self.batch:
            return
        result = self._results.get(selected[0])
        if not result or result.get('status') not in ('ok', 'duplicate'):
            return
        report = self._scene_report_for_result(result)
        if result.get('status') == 'duplicate' and not report:
            return
        item = result.get('item') or {}
        item_id = item.get('id')
        if not item_id:
            self._set_status('scene_legacy_review')
            return
        original_batch = self.batch
        def apply(labels):
            if self._closed or self._busy or self.batch is not original_batch:
                return
            from ..core.source_workflow import set_scene_override
            try:
                self.batch = set_scene_override(self.batch, item_id, labels)
                self._scene_reports = _scene_reports_by_fingerprint(self.batch)
                updated_by_id = {(row.get('item') or {}).get('id'): row for row in self.batch['results']}
                for review_row, review_item in self._items.items():
                    updated = updated_by_id.get(review_item.get('id'))
                    if updated:
                        review_item['scene_override'] = (updated.get('item') or {}).get('scene_override')
                        review_item['photo_scene'] = self._scene_report_for_result(updated)
                        self._update_review_row(review_row, review_item)
                self._result_help_key = 'scene_changed_save'
                self._render_batch(select=False)
                self._set_status('scene_result_updated')
            except (ValueError, TypeError, KeyError) as exc:
                self._set_status('source_error', detail=str(exc))
        self._open_scene_editor(item, report, apply)

    def _scene_report_for_result(self, result):
        report = (result.get('payload') or {}).get('photo_scene')
        if report:
            return report
        fingerprint = (result.get('item') or {}).get('scene_original_fingerprint')
        return self._scene_reports.get(fingerprint)

    def _open_scene_editor(self, item, report, on_apply):
        if self._scene_dialog is not None:
            self._scene_dialog.close()
        self._scene_dialog = SceneEditor(self, Path(item.get('original_path') or '').name,
                                        report, item.get('scene_override'), on_apply)

    def cancel(self):
        if self._busy and self._job == 'analysis':
            self._cancel_event.set()
            self.cancel_btn.configure(state='disabled')
            self._set_status('source_cancelling')

    def _poll(self):
        if self._closed:
            return
        while True:
            try:
                event = self._events.get_nowait()
            except queue.Empty:
                break
            if event[0] == 'discovered':
                self._receive_discovery(event[1])
            elif event[0] == 'analyzed':
                self.batch = event[1]
                self._scene_reports = _scene_reports_by_fingerprint(self.batch)
                review_by_id = {item.get('id'): (row, item) for row, item in self._items.items()}
                for result in self.batch.get('results', []):
                    result_item = result.get('item') or {}
                    review = review_by_id.get(result_item.get('id'))
                    if review:
                        review_row, review_item = review
                        review_item['photo_scene'] = self._scene_report_for_result(result)
                        if 'scene_override' in result_item:
                            review_item['scene_override'] = result_item['scene_override']
                        self._update_review_row(review_row, review_item)
                self._render_batch()
                self.tabs.select(self.result_tab)
                counts = self.batch.get('counts') or {}
                ok = counts.get('successful', sum(row.get('status') == 'ok' for row in self.batch.get('results', [])))
                failed = counts.get('failed', 0)
                self._set_status('source_cancelled' if self.batch.get('status') == 'cancelled' else 'source_finished', ok=ok, failed=failed)
            elif event[0] == 'progress':
                self.progress.set(event[1] / max(1, event[2]) * 100)
                if not self._cancel_event.is_set():
                    self._set_status('source_analyzing', done=event[1], total=event[2], name=Path(event[3]).name)
            elif event[0] == 'error':
                self._set_status('source_error', detail=event[1])
            elif event[0] == 'finished':
                self._busy, self._job = False, None
                self._controls()
                if self._pending_mode:
                    mode, self._pending_mode = self._pending_mode, None
                    self.set_mode(mode, automatic=True)
        self._poll_id = self.after(60, self._poll)

    def _set_details(self, text):
        self.details.configure(state='normal')
        self.details.delete('1.0', 'end')
        self.details.insert('1.0', text)
        self.details.configure(state='disabled')

    def _render_batch(self, select=True):
        previous = self.result_tree.selection() if not select else ()
        self.result_tree.delete(*self.result_tree.get_children())
        self._results.clear()
        self._scene_reports = _scene_reports_by_fingerprint(self.batch)
        t = self.i18n.t
        self.result_help.configure(text=t(self._result_help_key))
        summary = self.batch.get('summary', {}) if self.batch else {}
        tendencies = summary.get('tendencies') or (summary.get('appearance') or {}).get('tendencies') or {}
        has_results = bool(self.batch and any(row.get('status') == 'ok' for row in self.batch.get('results', [])))
        is_reference = bool(has_results and self.batch.get('mode') == 'reference_jpg')
        self.result_heading.grid() if has_results else self.result_heading.grid_remove()
        self.result_help.grid() if has_results else self.result_help.grid_remove()
        self.cards_frame.grid() if is_reference else self.cards_frame.grid_remove()
        self.palette.grid() if is_reference else self.palette.grid_remove()
        for key, value in self.cards.items():
            value.configure(text=t('source_' + str(tendencies[key])) if key in tendencies else t('summary_not_measured'))
        if not self.batch:
            self._set_details(t('source_result_empty'))
            self._draw_palette()
            return
        self.result_tree.insert('', 'end', iid='summary', values=(t('source_batch_summary'), '', ''))
        for index, result in enumerate(self.batch.get('results', [])):
            row = f'result-{index}'
            self._results[row] = result
            item = result.get('item') or {}
            key = 'source_result_ok' if result.get('status') == 'ok' else 'source_result_duplicate' if result.get('status') == 'duplicate' else 'source_result_failed'
            if result.get('status') == 'ok' and item.get('source_type') == 'raw_xmp' and _warnings(self.i18n, result.get('payload') or {}):
                key = 'source_result_partial'
            if item.get('scene_status') == 'needs_scene_review':
                key = 'scene_conflict_state'
            scene = scene_labels_text(self.i18n, self._scene_report_for_result(result), override=item.get('scene_override')) if result.get('status') in ('ok', 'duplicate') else ''
            self.result_tree.insert('', 'end', iid=row, values=(Path(item.get('original_path') or '').name, scene, t(key)), tags=() if key == 'source_result_ok' else ('warning',))
        selected = previous[0] if previous and self.result_tree.exists(previous[0]) else 'summary'
        self.result_tree.selection_set(selected)
        self.result_tree.focus(selected)
        self.result_tree.see(selected)
        self._result_selected()

    def _result_selected(self, event=None):
        selected = self.result_tree.selection()
        if not selected or not self.batch:
            return
        result = self._results.get(selected[0])
        text = source_result_text(self.i18n, result) if result else source_summary_text(self.i18n, self.batch)
        if result and result.get('status') == 'duplicate':
            text += '\n' + '\n'.join(scene_report_lines(self.i18n, self._scene_report_for_result(result)))
        self._set_details(text)
        self._draw_palette(result)
        self._controls()

    def _draw_palette(self, result=None):
        if self._closed:
            return
        self.palette.delete('all')
        if not self.batch or self.batch.get('mode') != 'reference_jpg':
            return
        summary = self.batch.get('summary') or {}
        colors = (result.get('payload') or {}).get('appearance', {}).get('palette', []) if result else summary.get('palette') or summary.get('appearance', {}).get('palette', [])
        width, height = max(1, self.palette.winfo_width()), max(1, self.palette.winfo_height())
        left = 0
        total = sum(max(0, color.get('fraction', 0)) for color in colors)
        for index, color in enumerate(colors):
            fill = color.get('hex', '')
            if len(fill) != 7 or not fill.startswith('#'):
                continue
            try:
                int(fill[1:], 16)
            except ValueError:
                continue
            right = width if index == len(colors) - 1 else left + width * max(0, color.get('fraction', 0)) / max(total, 1e-9)
            self.palette.create_rectangle(left, 0, right, height, fill=fill, outline='')
            left = right

    def save_profile(self):
        if self._busy or not self.batch:
            return
        name = self.style_name.get().strip()
        if not name:
            self._set_status('source_name_required')
            self.name_entry.focus_set()
            return
        try:
            with LibraryDB(app_data_dir() / DB_FILENAME) as db:
                db.save_source_profile(name, self.batch)
            self.reload_profiles()
            self._set_status('source_saved', name=name)
            self._result_help_key = 'source_saved_next'
            self.result_help.configure(text=self.i18n.t('source_saved_next'))
        except Exception as exc:
            self._set_status('source_error', detail=str(exc))

    def apply_batch(self):
        if self._busy or not self.batch:
            return
        from ..core.style_dna import dna_from_batch
        try:
            dna=dna_from_batch(self.batch,self.style_name.get().strip() or self.i18n.t('source_batch_summary'))
            self.master.open_style_workspace(initial_dna=dna)
        except Exception as exc:
            self._set_status('source_error',detail=str(exc))

    def rename_profile(self):
        rows=self.profiles_tree.selection()
        if self._busy or not rows:
            return
        record=self._profiles[rows[0]]
        name=simpledialog.askstring(self.i18n.t('source_rename'),self.i18n.t('source_save_name'),initialvalue=record['name'],parent=self)
        if name is None:
            return
        try:
            with LibraryDB(app_data_dir()/DB_FILENAME) as db:
                db.rename_source_profile(record['id'],name)
            self.reload_profiles()
        except Exception as exc:
            self._set_status('source_error',detail=str(exc))

    def delete_profile(self):
        rows=self.profiles_tree.selection()
        if self._busy or not rows:
            return
        record=self._profiles[rows[0]]
        if not messagebox.askyesno(self.i18n.t('source_delete'),self.i18n.t('source_delete_confirm',name=record['name']),parent=self):
            return
        try:
            with LibraryDB(app_data_dir()/DB_FILENAME) as db:
                db.delete_source_profile(record['id'])
            self.reload_profiles()
        except Exception as exc:
            self._set_status('source_error',detail=str(exc))

    def reload_profiles(self):
        try:
            # Opening an empty library should not create a database merely to
            # render the launch screen.
            path = app_data_dir() / DB_FILENAME
            rows = []
            if path.exists():
                with LibraryDB(path) as db:
                    rows = db.list_source_profiles()
            self._profiles = {str(row['id']): row for row in rows}
            self._render_profiles()
        except Exception as exc:
            self._set_status('source_error', detail=str(exc))
        self._controls()

    def _render_profiles(self):
        previous = self.profiles_tree.selection()
        self.profiles_tree.delete(*self.profiles_tree.get_children())
        for row, profile in self._profiles.items():
            stamp = profile.get('updated_at_utc') or profile.get('created_at_utc') or ''
            self.profiles_tree.insert('', 'end', iid=row, values=(profile['name'], self.i18n.t('source_mode_' + profile['mode']), stamp[:19].replace('T', ' ')))
        if previous and self.profiles_tree.exists(previous[0]):
            self.profiles_tree.selection_set(previous[0])
            self.profiles_tree.focus(previous[0])
            self.profiles_tree.see(previous[0])
        self.profiles_hint.grid_remove() if self._profiles else self.profiles_hint.grid()

    def open_profile(self):
        selected = self.profiles_tree.selection()
        if self._busy or not selected:
            return
        if self._scene_dialog is not None:
            self._scene_dialog.close()
        try:
            with LibraryDB(app_data_dir() / DB_FILENAME) as db:
                record = db.get_source_profile(self._profiles[selected[0]]['id'])
            if not record:
                self.reload_profiles()
                return
            self.batch = record['payload']
            self.mode = self.batch['mode']
            self._items.clear()
            self._included.clear()
            self.review_tree.delete(*self.review_tree.get_children())
            self.style_name.set(record['name'])
            self._result_help_key = 'source_saved_next'
            self.translate()
            self.tabs.select(self.result_tab)
            self._set_status('source_profile_snapshot')
        except Exception as exc:
            self._set_status('source_error', detail=str(exc))

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._scene_dialog is not None:
            self._scene_dialog.close()
        self._cancel_event.set()
        self.after_cancel(self._poll_id)
        super().destroy()
        # Drop every Python Tcl owner on this thread before a later worker can
        # trigger cyclic GC. Workers contain only queues, events and plain data.
        self.style_name = self.progress = self.status = None
        self._labels.clear()
        self._buttons.clear()
        self.mode_buttons.clear()
        self.mode_cards.clear()
        self.phase_labels.clear()
        self.cards.clear()
        self._threads.clear()
        self._scene_reports.clear()
        for name in ('heading_label', 'folder_btn', 'modes_frame', 'phases_frame', 'result_heading', 'result_help', 'folder_label', 'mode_hint', 'tabs', 'review_tab', 'result_tab', 'profiles_tab', 'review_tree', 'review_hint', 'toggle_btn', 'resolve_btn', 'review_scene_btn', 'result_scene_btn', 'result_scene_hint', 'cards_frame', 'palette', 'result_tree', 'details', 'name_entry', 'save_btn', 'apply_btn', 'rename_btn', 'delete_btn', 'profiles_tree', 'profiles_hint', 'open_profile_btn', 'status_label', 'refresh_btn', 'analyze_btn', 'cancel_btn', 'progressbar'):
            setattr(self, name, None)

    def destroy(self):
        self.close()
