"""Photo scene review with explicit automatic reset and plain-data callbacks."""
import tkinter as tk
import math
from tkinter import ttk

from .display import ui_pixels
from .theme import COLORS as C


def _label(i18n, label):
    return i18n.t('scene_label_' + label)


def scene_labels_text(i18n, report=None, *, override=None):
    """A short scene description, without presenting model estimates as facts."""
    if override is not None:
        labels = override or ['unknown']
        return i18n.t('scene_manual_short', labels=' · '.join(_label(i18n, label) for label in labels))
    if not report:
        return i18n.t('scene_automatic_pending')
    labels = report.get('labels') or ['unknown']
    text = ' · '.join(_label(i18n, label) for label in labels)
    return i18n.t('scene_manual_short', labels=text) if report.get('source') == 'manual' else text


def scene_report_lines(i18n, report):
    if not report:
        return ['', i18n.t('scene_heading'), i18n.t('scene_legacy_notice')]
    lines = ['', i18n.t('scene_heading'), scene_labels_text(i18n, report)]
    lines.append(i18n.t('scene_manual_notice' if report.get('source') == 'manual' else 'scene_automatic_notice'))
    if not report.get('labels'):
        lines.append(i18n.t('scene_unclassified_help'))
    predictions = []
    scores = report.get('scores') or {}
    labels = report.get('automatic_labels') or []
    for label in labels:
        score = scores.get(label)
        if isinstance(score, (int, float)) and not isinstance(score, bool) and math.isfinite(score) and 0 <= score <= 1:
            predictions.append(i18n.t('scene_prediction_item', label=_label(i18n, label), score=round(score * 100)))
    lines.append(i18n.t('scene_prediction_estimates', predictions=' · '.join(predictions))
                 if predictions else i18n.t('scene_prediction_none'))
    if 'scene_manual_assignment_conflict' in report.get('warnings', []):
        lines.append(i18n.t('scene_conflict_help'))
    return lines


def scene_summary_lines(i18n, stats):
    if not isinstance(stats, dict):
        return ['', i18n.t('scene_legacy_notice')]
    lines = ['', i18n.t('scene_coverage_heading'),
             i18n.t('scene_coverage_count', classified=stats.get('classified_count', 0),
                    total=stats.get('sample_count', 0), manual=stats.get('manual_count', 0))]
    for label, category in stats.get('categories', {}).items():
        if not isinstance(category, dict):
            continue
        count = category.get('sample_count', 0)
        if not count:
            continue
        eligible = category.get('style_sample_count', count)
        support = i18n.t('scene_support_low' if category.get('underrepresented', eligible < 3) else 'scene_support_ready')
        if eligible != count:
            lines.append(i18n.t('scene_support_filtered_line', label=_label(i18n, label), count=count,
                                eligible=eligible, support=support))
        else:
            lines.append(i18n.t('scene_support_line', label=_label(i18n, label), count=count, support=support))
    if stats.get('excluded_edit_conflict_count'):
        lines.append(i18n.t('scene_edit_evidence_conflict'))
    if stats.get('unclassified_count'):
        lines.append(i18n.t('scene_unknown_count', count=stats['unclassified_count']))
    lines.append(i18n.t('scene_learning_help'))
    return lines


class SceneEditor(tk.Toplevel):
    """The dialog owns all Tk state; its callback receives only None or labels."""

    def __init__(self, parent, filename, report, override, on_apply):
        super().__init__(parent)
        self.parent_workspace = parent
        self.i18n = parent.i18n
        self.on_apply = on_apply
        self._report = dict(report or {})
        self._closed = False
        self._labels = []
        self._buttons = []
        self._subject_buttons = {}
        self._vars = {}
        self._time_labels = {}
        self._environment_labels = {}
        self.time_selection = tk.StringVar(self)
        self.environment_selection = tk.StringVar(self)
        self.message = tk.StringVar(self)
        self.configure(background=C['bg'])
        self.transient(parent)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.bind('<Escape>', lambda event: self.close())
        dp = lambda value: ui_pixels(parent, value)
        self.geometry(f'{dp(660)}x{dp(620)}')
        self.minsize(dp(570), dp(560))
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        header = tk.Frame(self, background=C['bg'], padx=dp(22), pady=dp(18))
        header.grid(row=0, sticky='ew')
        header.columnconfigure(0, weight=1)
        self._label(header, 'scene_editor_title', 'LabHeading').grid(row=0, sticky='w')
        tk.Label(header, text=filename, background=C['bg'], foreground=C['muted'],
                 font='LabSmall', wraplength=dp(590), anchor='w').grid(row=1, sticky='ew', pady=(dp(5), dp(7)))
        self._label(header, 'scene_editor_help', wraplength=dp(590), color='muted').grid(row=2, sticky='ew')
        self.estimate_label = tk.Label(header, background=C['bg'], foreground=C['muted'], font='LabSmall',
                                       wraplength=dp(590), anchor='w', justify='left')
        self.estimate_label.grid(row=3, sticky='ew', pady=(dp(9), 0))
        viewport = tk.Frame(self, background=C['surface'])
        viewport.grid(row=1, sticky='nsew', padx=dp(22))
        viewport.columnconfigure(0, weight=1)
        viewport.rowconfigure(0, weight=1)
        self._body_canvas = tk.Canvas(viewport, background=C['surface'], highlightthickness=0,
                                      borderwidth=0, width=dp(540), height=dp(310))
        self._body_canvas.grid(row=0, column=0, sticky='nsew')
        scrollbar = ttk.Scrollbar(viewport, orient='vertical', style='Lab.Vertical.TScrollbar',
                                  command=self._body_canvas.yview)
        scrollbar.grid(row=0, column=1, sticky='ns')
        self._body_canvas.configure(yscrollcommand=scrollbar.set)
        body = tk.Frame(self._body_canvas, background=C['surface'], padx=dp(18), pady=dp(14))
        window = self._body_canvas.create_window((0, 0), window=body, anchor='nw')
        body.bind('<Configure>', lambda event: self._body_canvas.configure(scrollregion=self._body_canvas.bbox('all')))
        self._body_canvas.bind('<Configure>', lambda event: self._body_canvas.itemconfigure(window, width=event.width))
        body.columnconfigure(0, weight=1)
        self.body = body
        # The canonical axes are loaded here so the UI cannot invent labels
        # that are absent from the local classifier's validation contract.
        from ..core.photo_scene import AXES
        self._axes = AXES
        for row, (axis, labels) in enumerate(self._axes.items()):
            group = tk.Frame(body, background=C['surface'])
            group.grid(row=row, sticky='ew', pady=(0, dp(12)))
            group.columnconfigure(0, weight=1)
            self._label(group, 'scene_axis_' + axis, 'LabSmall', color='muted').grid(row=0, sticky='w', pady=(0, dp(5)))
            if axis in ('time', 'environment'):
                selection = self.time_selection if axis == 'time' else self.environment_selection
                combo = ttk.Combobox(group, textvariable=selection, state='readonly', style='Lab.TCombobox')
                combo.grid(row=1, sticky='ew')
                if axis == 'time':
                    self.time_combo = combo
                else:
                    self.environment_combo = combo
            else:
                choices = tk.Frame(group, background=C['surface'])
                choices.grid(row=1, sticky='ew')
                for column in range(3):
                    choices.columnconfigure(column, weight=1)
                for index, label in enumerate(labels):
                    var = tk.BooleanVar(self, value=False)
                    self._vars[label] = var
                    button = ttk.Checkbutton(choices, variable=var, style='Lab.TCheckbutton')
                    button.grid(row=index // 3, column=index % 3, sticky='w', pady=dp(2))
                    self._subject_buttons[label] = button
                    self._buttons.append((button, 'scene_label_' + label))
        footer = tk.Frame(self, background=C['bg'], padx=dp(22), pady=dp(16))
        footer.grid(row=2, sticky='ew')
        footer.columnconfigure(1, weight=1)
        self.message_label = tk.Label(footer, textvariable=self.message, background=C['bg'], foreground=C['warning'],
                                      font='LabSmall', wraplength=dp(590), justify='left')
        self.message_label.grid(row=0, column=0, columnspan=3, sticky='ew', pady=(0, dp(8)))
        self.auto_button = ttk.Button(footer, command=self.use_automatic, style='Secondary.TButton')
        self.auto_button.grid(row=1, column=0)
        self.apply_button = ttk.Button(footer, command=self.apply_selection, style='Primary.TButton')
        self.apply_button.grid(row=1, column=2)
        self._buttons.extend([(self.auto_button, 'scene_use_automatic'), (self.apply_button, 'scene_apply_selection')])
        self.translate()
        selected = list(override if override is not None else self._report.get('labels', []))
        time = next((label for label in self._axes.get('time', ()) if label in selected), None)
        self.time_selection.set(self.i18n.t('scene_unspecified') if time is None else _label(self.i18n, time))
        environment = next((label for label in self._axes.get('environment', ()) if label in selected), None)
        self.environment_selection.set(self.i18n.t('scene_unspecified') if environment is None else _label(self.i18n, environment))
        for label, var in self._vars.items():
            var.set(label in selected)
        def bind_scroll(widget):
            widget.bind('<MouseWheel>', self._scroll, add='+')
            widget.bind('<Button-4>', self._scroll, add='+')
            widget.bind('<Button-5>', self._scroll, add='+')
            for child in widget.winfo_children():
                bind_scroll(child)
        bind_scroll(viewport)
        self.grab_set()

    def _scroll(self, event):
        if self._closed:
            return
        direction = -1 if getattr(event, 'num', None) == 4 or getattr(event, 'delta', 0) > 0 else 1
        self._body_canvas.yview_scroll(direction, 'units')
        return 'break'

    def _label(self, parent, key, font='LabBody', *, color='text', **kwargs):
        widget = tk.Label(parent, text=self.i18n.t(key), font=font, foreground=C[color],
                          background=parent.cget('background'), anchor='w', justify='left', **kwargs)
        self._labels.append((widget, key))
        return widget

    def translate(self):
        current_time = self._time_labels.get(self.time_selection.get())
        current_environment = self._environment_labels.get(self.environment_selection.get())
        self.title(self.i18n.t('scene_editor_title'))
        for widget, key in self._labels + self._buttons:
            widget.configure(text=self.i18n.t(key))
        self._time_labels = {self.i18n.t('scene_unspecified'): None,
                             **{_label(self.i18n, label): label for label in self._axes.get('time', ())}}
        self.time_combo.configure(values=tuple(self._time_labels))
        self.time_selection.set(self.i18n.t('scene_unspecified') if current_time is None else _label(self.i18n, current_time))
        self._environment_labels = {self.i18n.t('scene_unspecified'): None,
                                    **{_label(self.i18n, label): label for label in self._axes.get('environment', ())}}
        self.environment_combo.configure(values=tuple(self._environment_labels))
        self.environment_selection.set(self.i18n.t('scene_unspecified') if current_environment is None else _label(self.i18n, current_environment))
        self.estimate_label.configure(text='\n'.join(scene_report_lines(self.i18n, self._report)[2:])
                                      if self._report else self.i18n.t('scene_automatic_pending_help'))

    def selected_labels(self):
        time = self._time_labels.get(self.time_selection.get())
        environment = self._environment_labels.get(self.environment_selection.get())
        labels = ([time] if time else []) + ([environment] if environment else []) + [label for label, var in self._vars.items() if var.get()]
        from ..core.photo_scene import validate_scene_override
        return validate_scene_override(labels)

    def apply_selection(self):
        try:
            labels = self.selected_labels()
        except (ValueError, TypeError):
            self.message.set(self.i18n.t('scene_invalid_selection'))
            return
        self.on_apply(labels)
        self.close()

    def use_automatic(self):
        self.on_apply(None)
        self.close()

    def close(self):
        if self._closed:
            return
        self._closed = True
        if getattr(self.parent_workspace, '_scene_dialog', None) is self:
            self.parent_workspace._scene_dialog = None
        self.grab_release()
        super().destroy()
        self.on_apply = self.parent_workspace = None
        self.time_selection = self.environment_selection = self.message = None
        self._vars.clear()
        self._labels.clear()
        self._buttons.clear()
        self._subject_buttons.clear()
        self.body = self.time_combo = self.environment_combo = self.estimate_label = self.message_label = None
        self._body_canvas = None
        self.auto_button = self.apply_button = None
        # A closed dialog may remain in a caller frame; release its Tcl owner
        # on the UI thread rather than during later worker cyclic collection.
        self.master = self.tk = None

    def destroy(self):
        self.close()
