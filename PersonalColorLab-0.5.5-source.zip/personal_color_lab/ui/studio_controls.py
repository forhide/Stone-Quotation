"""Small native-vector controls for the desktop style studio."""
from __future__ import annotations

import math
import tkinter as tk

from .display import ui_pixels
from .theme import COLORS as C


class StudioSlider(tk.Canvas):
    """Horizontal, keyboard-accessible scale without platform theme chrome.

    The source of truth remains a Tk variable on the UI thread. External
    variable writes redraw the control without issuing a user command; a
    pointer/key action or ``set`` issues one command only when the value moves.
    """

    def __init__(self,master,*,from_=0,to=100,variable=None,command=None,
                 orient='horizontal',style=None,length=None,**kwargs):
        if orient not in ('horizontal',tk.HORIZONTAL):
            raise ValueError('StudioSlider supports horizontal orientation.')
        self._from=self._finite(from_);self._to=self._finite(to)
        self._command=command;self._writing=False;self._trace=None
        self._closed=False;self._dragging=False;self._drag_offset=0.
        self._style=style
        kwargs.setdefault('width',length if length is not None else ui_pixels(master,200))
        kwargs.setdefault('height',ui_pixels(master,28))
        kwargs.setdefault('background',C['surface'])
        kwargs.setdefault('borderwidth',0);kwargs.setdefault('highlightthickness',0)
        kwargs.setdefault('takefocus',True);kwargs.setdefault('cursor','hand2')
        super().__init__(master,**kwargs)
        self._normal_takefocus=self.cget('takefocus')
        self._variable=variable if variable is not None else tk.DoubleVar(master=self,value=self._from)
        self._value=self._from
        self._trace=self._variable.trace_add('write',self._variable_changed)
        self._variable_changed()
        self.bind('<Configure>',self._redraw)
        self.bind('<FocusIn>',self._redraw);self.bind('<FocusOut>',self._redraw)
        self.bind('<ButtonPress-1>',self._press)
        self.bind('<B1-Motion>',self._motion);self.bind('<ButtonRelease-1>',self._release)
        for key in ('Left','Right','Up','Down','Home','End','Prior','Next'):
            self.bind('<KeyPress-'+key+'>',self._key)
        self.bind('<Destroy>',self._destroyed,add='+')
        if str(super().cget('state'))=='disabled':
            super().configure(takefocus=False,cursor='arrow')
        self._redraw()

    @staticmethod
    def _finite(value):
        try:result=float(value)
        except (TypeError,ValueError,OverflowError):raise ValueError('Invalid slider value.') from None
        if not math.isfinite(result):raise ValueError('Invalid slider value.')
        return result

    def _clamp(self,value):
        return max(min(self._from,self._to),min(max(self._from,self._to),value))

    def _variable_changed(self,*args):
        if self._writing or self._closed:return
        try:value=self._clamp(self._finite(self._variable.get()))
        except (tk.TclError,ValueError):value=self._value
        self._value=value
        self._writing=True
        try:
            # Clamp untrusted/programmatic writes without a recursive trace.
            try:current=float(self._variable.get())
            except (tk.TclError,TypeError,ValueError):current=None
            if current!=value:self._variable.set(value)
        finally:self._writing=False
        self._redraw()

    def get(self):
        return self._value

    def set(self,value):
        if self._closed or str(super().cget('state'))=='disabled':return
        value=self._clamp(self._finite(value))
        changed=value!=self._value
        if not changed:return
        self._value=value;self._writing=True
        try:self._variable.set(value)
        finally:self._writing=False
        self._redraw()
        if self._command is not None:self._command(str(value))

    def _geometry(self):
        width=max(1,self.winfo_width());height=max(1,self.winfo_height())
        if width<=1:width=max(1,int(float(super().cget('width'))))
        if height<=1:height=max(1,int(float(super().cget('height'))))
        margin=min(ui_pixels(self,10),width/2)
        return margin,max(margin,width-margin),height/2

    def _position(self):
        left,right,y=self._geometry()
        fraction=0. if self._from==self._to else (self._value-self._from)/(self._to-self._from)
        return left+(right-left)*fraction,y

    def _redraw(self,event=None):
        if self._closed:return
        left,right,y=self._geometry();x,_=self._position()
        disabled=str(super().cget('state'))=='disabled'
        self.delete('all')
        self.create_line(left,y,right,y,fill=C['border'],width=max(2,ui_pixels(self,3)),capstyle=tk.ROUND,tags='track')
        if x>left:
            self.create_line(left,y,x,y,fill=C['subtle'] if disabled else C['accent'],
                             width=max(2,ui_pixels(self,3)),capstyle=tk.ROUND,tags='progress')
        radius=max(3,ui_pixels(self,5))
        if not disabled and self.focus_get()==self:
            halo=radius+max(2,ui_pixels(self,3))
            self.create_oval(x-halo,y-halo,x+halo,y+halo,fill='',outline=C['accent'],width=max(1,ui_pixels(self,1)),tags='focus')
        self.create_oval(x-radius,y-radius,x+radius,y+radius,
                         fill=C['subtle'] if disabled else C['text'],outline='',tags='thumb')

    def _pointer(self,x):
        left,right,_=self._geometry()
        fraction=0. if right==left else max(0.,min(1.,(x-left)/(right-left)))
        self.set(self._from+(self._to-self._from)*fraction)

    def _press(self,event):
        if str(super().cget('state'))=='disabled':return 'break'
        self.focus_set();self._dragging=True
        thumb,_=self._position()
        self._drag_offset=event.x-thumb if abs(event.x-thumb)<=ui_pixels(self,9) else 0.
        self._pointer(event.x-self._drag_offset)
        return 'break'

    def _motion(self,event):
        if self._dragging:self._pointer(event.x-self._drag_offset)
        return 'break'

    def _release(self,event):
        if self._dragging:self._pointer(event.x-self._drag_offset)
        self._dragging=False
        return 'break'

    def _key(self,event):
        if str(super().cget('state'))=='disabled':return 'break'
        span=self._to-self._from
        if event.keysym=='Home':value=self._from
        elif event.keysym=='End':value=self._to
        else:
            steps={'Left':-1,'Down':-1,'Right':1,'Up':1,'Prior':10,'Next':-10}
            value=self._value+span/100*steps[event.keysym]
        self.set(value)
        return 'break'

    def configure(self,cnf=None,**kwargs):
        options=dict(cnf or {}) if isinstance(cnf,dict) else {}
        options.update(kwargs)
        if not options:return super().configure(cnf)
        if 'from_' in options:self._from=self._finite(options.pop('from_'))
        if 'from' in options:self._from=self._finite(options.pop('from'))
        if 'to' in options:self._to=self._finite(options.pop('to'))
        if 'command' in options:self._command=options.pop('command')
        if 'style' in options:self._style=options.pop('style')
        if 'variable' in options:
            self._clear_trace();self._variable=options.pop('variable')
            self._trace=self._variable.trace_add('write',self._variable_changed)
        if options.get('state')=='disabled':
            self._dragging=False;options.setdefault('takefocus',False);options.setdefault('cursor','arrow')
        elif options.get('state')=='normal':
            options.setdefault('takefocus',self._normal_takefocus);options.setdefault('cursor','hand2')
        result=super().configure(**options) if options else None
        self._variable_changed()
        return result

    config=configure

    def cget(self,key):
        if key in ('from','from_'):return self._from
        if key=='to':return self._to
        if key=='variable':return str(self._variable)
        if key=='command':return self._command
        if key=='style':return self._style
        return super().cget(key)

    def _clear_trace(self):
        if self._trace is not None:
            try:self._variable.trace_remove('write',self._trace)
            except tk.TclError:pass
            self._trace=None

    def _destroyed(self,event):
        if event.widget==self:
            self._release_owners()

    def _release_owners(self):
        self._clear_trace();self._closed=True;self._dragging=False;self._command=None
        # Removing a Tcl trace alone leaves a Python Variable -> Tk root owner.
        # Drop it here on the UI thread, including when another widget destroys
        # this Canvas. External variables remain owned by their callers.
        self._variable=None

    def destroy(self):
        self._release_owners()
        super().destroy()


class StudioToggle(tk.Frame):
    """A native-label Boolean control with a compact vector switch."""

    def __init__(self,master,*,variable=None,command=None,text='',style=None,
                 state='normal',font='LabBody',**kwargs):
        if state not in ('normal','disabled'):raise ValueError('Invalid toggle state.')
        self._state=state;self._command=command;self._style=style
        self._trace=None;self._writing=False;self._closed=False;self._value=False
        kwargs.setdefault('background',C['surface']);kwargs.setdefault('borderwidth',0)
        kwargs.setdefault('highlightthickness',0);kwargs.setdefault('takefocus',True)
        kwargs.setdefault('cursor','hand2')
        super().__init__(master,**kwargs)
        self._normal_takefocus=super().cget('takefocus')
        dp=lambda value:ui_pixels(self,value)
        background=super().cget('background')
        self._label=tk.Label(self,text=text,font=font,foreground=C['muted'],background=background,
                             anchor='w',justify='left',wraplength=dp(200),borderwidth=0,
                             padx=0,pady=0,takefocus=False,cursor='hand2')
        self._label.grid(row=0,column=0,sticky='ew',pady=dp(6))
        self._switch=tk.Canvas(self,width=dp(36),height=dp(22),background=background,
                               borderwidth=0,highlightthickness=0,takefocus=False,cursor='hand2')
        self._switch.grid(row=0,column=1,sticky='e',padx=(dp(10),0),pady=dp(5))
        self.columnconfigure(0,weight=1)
        self._variable=variable if variable is not None else tk.BooleanVar(master=self,value=False)
        self._trace=self._variable.trace_add('write',self._variable_changed)
        for widget in (self,self._label,self._switch):
            widget.bind('<Button-1>',self._click)
        self.bind('<KeyPress-space>',self._key);self.bind('<KeyPress-Return>',self._key)
        self.bind('<FocusIn>',self._redraw);self.bind('<FocusOut>',self._redraw)
        self.bind('<Configure>',self._resize_label)
        self.bind('<Destroy>',self._destroyed,add='+')
        self._update_state();self._variable_changed()

    def _variable_changed(self,*args):
        if self._writing or self._closed:return
        try:self._value=bool(self._variable.get())
        except tk.TclError:
            self._writing=True
            try:self._variable.set(self._value)
            finally:self._writing=False
        self._redraw()

    def invoke(self):
        if self._closed or self._state=='disabled':return ''
        self._value=not self._value;self._writing=True
        try:self._variable.set(self._value)
        finally:self._writing=False
        self._redraw()
        result=self._command() if self._command is not None else ''
        return '' if result is None else result

    def _click(self,event):
        if self._state!='disabled':self.focus_set();self.invoke()
        return 'break'

    def _key(self,event):
        self.invoke()
        return 'break'

    def _resize_label(self,event):
        if not self._closed and event.widget==self:
            available=max(ui_pixels(self,20),event.width-ui_pixels(self,46))
            self._label.configure(wraplength=available)

    def _pill(self,left,top,right,bottom,color,tag):
        radius=(bottom-top)/2
        self._switch.create_oval(left,top,left+2*radius,bottom,fill=color,outline='',tags=tag)
        self._switch.create_rectangle(left+radius,top,right-radius,bottom,fill=color,outline='',tags=tag)
        self._switch.create_oval(right-2*radius,top,right,bottom,fill=color,outline='',tags=tag)

    def _redraw(self,event=None):
        if self._closed:return
        dp=lambda value:ui_pixels(self,value)
        self._switch.delete('all')
        disabled=self._state=='disabled'
        if not disabled and self.focus_get()==self:
            self._pill(dp(1),dp(1),dp(35),dp(21),C['text'],'focus')
        track=C['border'] if disabled or not self._value else C['accent']
        self._pill(dp(2),dp(2),dp(34),dp(20),track,'track')
        x=dp(25 if self._value else 11);y=dp(11);radius=max(2,dp(6))
        color=C['subtle'] if disabled or not self._value else C['accent_text']
        self._switch.create_oval(x-radius,y-radius,x+radius,y+radius,fill=color,outline='',tags='thumb')

    def _update_state(self):
        disabled=self._state=='disabled'
        super().configure(takefocus=False if disabled else self._normal_takefocus,
                          cursor='arrow' if disabled else 'hand2')
        self._label.configure(foreground=C['subtle'] if disabled else C['muted'],
                              cursor='arrow' if disabled else 'hand2')
        self._switch.configure(cursor='arrow' if disabled else 'hand2')

    def configure(self,cnf=None,**kwargs):
        options=dict(cnf or {}) if isinstance(cnf,dict) else {}
        options.update(kwargs)
        if not options:
            if cnf in ('text','state','font','style','variable','command'):
                value=self.cget(cnf);return (cnf,cnf,cnf,None,value)
            return super().configure(cnf)
        if 'state' in options:
            state=options.pop('state')
            if state not in ('normal','disabled'):raise ValueError('Invalid toggle state.')
            self._state=state
        if 'text' in options:self._label.configure(text=options.pop('text'))
        if 'font' in options:self._label.configure(font=options.pop('font'))
        if 'command' in options:self._command=options.pop('command')
        if 'style' in options:self._style=options.pop('style')
        if 'variable' in options:
            self._clear_trace();self._variable=options.pop('variable')
            self._trace=self._variable.trace_add('write',self._variable_changed)
        background=options.get('background',options.get('bg'))
        result=super().configure(**options) if options else None
        if background is not None:
            self._label.configure(background=background);self._switch.configure(background=background)
        self._update_state();self._variable_changed()
        return result

    config=configure

    def cget(self,key):
        if key=='state':return self._state
        if key in ('text','font'):return self._label.cget(key)
        if key=='variable':return str(self._variable)
        if key=='command':return self._command
        if key=='style':return self._style
        return super().cget(key)

    def _clear_trace(self):
        if self._trace is not None:
            try:self._variable.trace_remove('write',self._trace)
            except tk.TclError:pass
            self._trace=None

    def _destroyed(self,event):
        if event.widget==self:
            self._release_owners()

    def _release_owners(self):
        self._clear_trace();self._closed=True;self._command=None
        self._variable=None
        # Label/Canvas retain their parent; retaining them after destruction
        # creates a dead-widget cycle that a future analysis worker may collect.
        self._label=None;self._switch=None

    def destroy(self):
        self._release_owners()
        super().destroy()
