"""Skip unused recognition work while preserving measured scene evidence."""
import cv2
import numpy as np
import pytest
import threading

from personal_color_lab.core import scene_analysis as scene
from personal_color_lab.core.analysis_control import AnalysisCancelledError


def model_outputs():
    outputs=[]
    for stride in (8,16,32):
        anchors=(416//stride)**2
        outputs.extend([np.zeros((1,anchors,80),np.float32),
                        np.zeros((1,anchors,32),np.float32)])
    return outputs


def test_decoder_only_regresses_candidates_without_changing_threshold_or_geometry(monkeypatch):
    outputs=model_outputs()
    # One isolated candidate at each pyramid level. Uniform distance logits
    # have an expected distance of 3.5 cells in every direction.
    for level,(stride,identifier) in enumerate(zip((8,16,32),(0,53,2))):
        dimension=416//stride
        anchor=dimension*6+6
        outputs[level*2][0,anchor,identifier]=.5
        # An adjacent low-score anchor must remain excluded from regression.
        outputs[level*2][0,anchor+1,identifier]=.44
    rows=[]
    exponential=np.exp
    def measured(values,*a,**kw):
        rows.append(values.shape)
        return exponential(values,*a,**kw)
    monkeypatch.setattr(scene.np,'exp',measured)
    objects=scene.decode_objects(outputs)
    assert rows==[(1,4,8)]*3
    assert {item['class_code'] for item in objects}=={'person','pizza','car'}
    for item in objects:
        stride={0:8,53:16,2:32}[item['class_id']]
        center=6*stride+(stride-1)*.5
        expected=np.clip([center-3.5*stride]*2+[center+3.5*stride]*2,0,416)/416
        assert item['box']==expected.tolist()


@pytest.mark.parametrize('invalid', ['nonfinite_distance','wrong_anchor_count'])
def test_non_candidate_output_corruption_is_still_rejected(invalid):
    outputs=model_outputs()
    if invalid=='nonfinite_distance':
        outputs[1][0,0,0]=np.nan
    else:
        outputs[1]=outputs[1][:,:-1]
    with pytest.raises(ValueError):
        scene.decode_objects(outputs)


def test_empty_object_regions_return_exact_zero_without_filtering(monkeypatch):
    monkeypatch.setattr(scene.cv2,'GaussianBlur',lambda *a,**kw:pytest.fail('Blurred an empty ROI'))
    unrelated=[{'class_id':0,'confidence':.9,'box':[.1,.1,.8,.9]}]
    result=scene._roi_mask(unrelated,scene.GROUPS['food'],(240,360))
    assert result.dtype==np.float32 and result.shape==(240,360)
    assert not result.any()


def test_supported_object_roi_retains_confidence_and_feathered_edges():
    item={'class_id':53,'confidence':.9,'box':[.2,.2,.7,.8]}
    result=scene._roi_mask([item],scene.GROUPS['food'],(120,180))
    hard=np.zeros((120,180),np.float32)
    hard[24:96,36:126]=.9
    expected=cv2.GaussianBlur(hard,(0,0),1.44)
    assert np.array_equal(result,expected)
    assert 0<result[24,36]<.9 and result[60,90]==pytest.approx(.9,abs=1e-6)


def test_region_measurements_retain_independent_zone_and_saturation_statistics():
    pixels=np.empty((30,60,3),np.uint8)
    pixels[:,:20]=[30,15,40]
    pixels[:,20:40]=[110,150,120]
    pixels[:,40:]=[240,245,250]
    masks={'person':np.ones((30,60),np.float32),
           'background':np.zeros((30,60),np.float32)}
    observed=scene.region_appearance(pixels,{'masks':masks})
    rgb=pixels.astype(np.float32)/255
    luma=rgb@np.array([.2126,.7152,.0722],np.float32)
    lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB)
    hsv=cv2.cvtColor(rgb,cv2.COLOR_RGB2HSV)
    assert set(observed)=={'person'}
    target=observed['person']['target']
    assert observed['person']['fraction']==1
    assert target['quantiles']==np.quantile(luma,[.05,.25,.5,.75,.95]).tolist()
    assert target['saturation']==float(hsv[:,:,1].mean())
    for name,selected in [('shadows',luma<.25),('midtones',(luma>=.25)&(luma<.75)),('highlights',luma>=.75)]:
        assert target['zones'][name]==lab[selected,1:].mean(axis=0).tolist()


@pytest.mark.parametrize('stage',['before_forward','after_object_forward','after_measurements'])
def test_cancelled_recognition_evidence_is_not_persisted_as_model_failure(monkeypatch,stage):
    event=threading.Event()
    pixels=np.full((120,180,3),128,np.uint8)
    if stage=='before_forward':
        event.set()
        monkeypatch.setattr(scene,'bundle_id',lambda:pytest.fail('Loaded models after cancellation'))
    elif stage=='after_object_forward':
        def forward(*a,**kw):
            event.set()
            return model_outputs()
        monkeypatch.setattr(scene,'infer',forward)
        monkeypatch.setattr(scene,'detect_faces',lambda *a:pytest.fail('Continued inference after cancellation'))
    else:
        measure=scene.region_appearance
        def measured(*a,**kw):
            result=measure(*a,**kw)
            event.set()
            return result
        monkeypatch.setattr(scene,'region_appearance',measured)
    with pytest.raises(AnalysisCancelledError,match='Recognition cancelled'):
        scene.analyze_evidence(pixels,cancel_event=event)
