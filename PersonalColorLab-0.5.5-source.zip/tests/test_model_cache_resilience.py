"""Optional caches and changing local model assets cannot corrupt evidence."""
import copy
import json
import shutil
import socket

import numpy as np
import pytest
from PIL import Image

from personal_color_lab.core import scene_analysis, semantic_models, source_workflow
from personal_color_lab.core.analysis_cache import cache_key
from personal_color_lab.core.database import AnalysisValidationError, LibraryDB


def photo_items(tmp_path, duplicate=False):
    folder = tmp_path / 'photos'
    folder.mkdir()
    Image.new('RGB', (180, 120), (105, 130, 160)).save(folder / 'a.jpg')
    if duplicate:
        shutil.copyfile(folder / 'a.jpg', folder / 'b.jpg')
    return source_workflow.discover_inputs(folder, 'reference_jpg')['items']


@pytest.mark.parametrize('operation', ['read', 'write'])
def test_optional_cache_errors_preserve_success_counts_and_duplicate_evidence(tmp_path, operation):
    class FailingCache:
        def get_cached_analysis(self, key):
            if operation == 'read':
                raise RuntimeError('Cache temporarily locked')
            return None

        def cache_analysis(self, key, payload):
            if operation == 'write':
                raise RuntimeError('Cache write unavailable')

    batch = source_workflow.analyze_inputs(photo_items(tmp_path, duplicate=True), 'reference_jpg', cache=FailingCache())
    assert batch['status'] == 'ok'
    assert batch['counts'] == {'total': 2, 'processed': 2, 'successful': 1, 'failed': 0,
                               'skipped': 0, 'cancelled': 0, 'duplicates': 1}
    assert [row['status'] for row in batch['results']] == ['ok', 'duplicate']
    assert batch['summary']['sample_count'] == 1
    assert batch['performance']['cache_errors'] == 1
    with LibraryDB(tmp_path / 'db.sqlite') as db:
        assert db.save_source_profile('Retained evidence', batch) > 0


def test_cache_reuses_global_evidence_without_models_then_retries_after_repair(tmp_path, monkeypatch):
    items = photo_items(tmp_path)
    unavailable = lambda *a, **kw: (_ for _ in ()).throw(semantic_models.ModelUnavailableError('Missing local model'))
    with LibraryDB(tmp_path / 'db.sqlite') as db:
        with monkeypatch.context() as context:
            context.setattr(semantic_models, 'bundle_id', unavailable)
            context.setattr(scene_analysis, 'bundle_id', unavailable)
            first = source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)
            assert first['results'][0]['payload']['semantic']['status'] == 'unavailable'
            context.setattr(source_workflow, 'analyze_reference', lambda *a: pytest.fail('Decoded valid cached global evidence'))
            reused = source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)
            assert reused['performance']['cache_hits'] == 1
            assert reused['results'][0]['payload']['appearance'] == first['results'][0]['payload']['appearance']
        repaired = source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)
        assert repaired['performance']['cache_hits'] == 0
        assert repaired['results'][0]['payload']['semantic']['status'] == 'ok'
        assert repaired['results'][0]['payload']['semantic']['bundle_id'] == semantic_models.bundle_id()


def test_cache_refreshes_semantics_from_a_different_model_bundle(tmp_path):
    items = photo_items(tmp_path)
    with LibraryDB(tmp_path / 'db.sqlite') as db:
        first = source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)
        payload = copy.deepcopy(first['results'][0]['payload'])
        payload['semantic']['bundle_id'] = 'a' * 64
        key = cache_key('reference_jpg', payload['provenance']['input_fingerprints'])
        db.cache_analysis(key, payload)
        refreshed = source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)
        assert refreshed['performance']['cache_hits'] == 0
        assert refreshed['results'][0]['payload']['semantic']['bundle_id'] == semantic_models.bundle_id()


@pytest.mark.parametrize('damage', ['missing_identity', 'coverage', 'pixel_array', 'wrong_class'])
def test_invalid_cached_semantics_are_evicted_before_style_learning(tmp_path, damage):
    with LibraryDB(tmp_path / 'db.sqlite') as db:
        batch = source_workflow.analyze_inputs(photo_items(tmp_path), 'reference_jpg', cache=db)
        payload = copy.deepcopy(batch['results'][0]['payload'])
        semantic = payload['semantic']
        if damage == 'missing_identity':
            semantic.pop('bundle_id')
        elif damage == 'coverage':
            semantic['region_fractions']['person'] = 5
        elif damage == 'pixel_array':
            semantic['masks'] = [[[0, 0, 0]]]
        else:
            semantic['objects'] = [{'class_id': 80, 'class_code': 'invented', 'confidence': .9, 'box': [0, 0, 1, 1]}]
        key = cache_key('reference_jpg', payload['provenance']['input_fingerprints'])
        with pytest.raises(AnalysisValidationError):
            db.cache_analysis(key, payload)
        db.conn.execute('UPDATE analysis_cache SET payload_json=? WHERE cache_key=?', (json.dumps(payload), key))
        db.conn.commit()
        assert db.get_cached_analysis(key) is None
        batch['results'][0]['payload'] = payload
        with pytest.raises(AnalysisValidationError):
            db.save_source_profile('Invalid semantic evidence', batch)


@pytest.fixture
def isolated_bundle(tmp_path, monkeypatch):
    root = tmp_path / 'models'
    shutil.copytree(semantic_models.MODEL_ROOT, root)
    monkeypatch.setattr(semantic_models, 'MODEL_ROOT', root)
    monkeypatch.setattr(semantic_models, '_MODELS', {})
    monkeypatch.setattr(semantic_models, '_SIGNATURES', {})
    monkeypatch.setattr(semantic_models, '_BUNDLE_MANIFEST', None)
    monkeypatch.setattr(semantic_models, '_BUNDLE_SIGNATURE', None)
    monkeypatch.setattr(semantic_models, '_BUNDLE_ID', None)
    return root


def test_cached_network_cannot_hide_deleted_bundle_manifest(isolated_bundle):
    semantic_models.infer('nanodet', np.zeros((1, 3, 416, 416), np.float32))
    assert semantic_models._MODELS
    (isolated_bundle / 'manifest.json').unlink()
    with pytest.raises(semantic_models.ModelUnavailableError):
        semantic_models.bundle_id()
    with pytest.raises(semantic_models.ModelUnavailableError):
        semantic_models.infer('nanodet', np.zeros((1, 3, 416, 416), np.float32))
    evidence = scene_analysis.analyze_evidence(np.full((120, 180, 3), 128, np.uint8))
    assert evidence['status'] == 'unavailable'


def test_cached_network_cannot_hide_removed_license(isolated_bundle):
    semantic_models.infer('nanodet', np.zeros((1, 3, 416, 416), np.float32))
    (isolated_bundle / 'humanseg-LICENSE.txt').unlink()
    with pytest.raises(semantic_models.ModelUnavailableError):
        semantic_models.bundle_id()


def test_bundle_metadata_change_invalidates_all_cached_networks(isolated_bundle):
    semantic_models.infer('nanodet', np.zeros((1, 3, 416, 416), np.float32))
    semantic_models.infer('humanseg', np.zeros((1, 3, 192, 192), np.float32))
    identity = semantic_models.bundle_id()
    assert set(semantic_models._MODELS) == {'nanodet', 'humanseg'}
    manifest_path = isolated_bundle / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    manifest['review_marker'] = 'Changed metadata, same valid model bytes'
    manifest_path.write_text(json.dumps(manifest))
    assert semantic_models.bundle_id() == identity
    assert semantic_models._MODELS == {}


def test_manifest_cannot_verify_a_different_filename_than_loaded(isolated_bundle):
    manifest_path = isolated_bundle / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    shutil.copyfile(isolated_bundle / 'nanodet.onnx', isolated_bundle / 'other.onnx')
    manifest['models'][0]['filename'] = 'other.onnx'
    manifest_path.write_text(json.dumps(manifest))
    with pytest.raises(semantic_models.ModelUnavailableError):
        semantic_models.bundle_id()


def test_model_bundle_change_during_analysis_is_withheld(monkeypatch):
    calls = iter(['a' * 64, 'b' * 64])
    monkeypatch.setattr(scene_analysis, 'bundle_id', lambda: next(calls))
    evidence = scene_analysis.analyze_evidence(np.full((120, 180, 3), 128, np.uint8))
    assert evidence['status'] == 'unavailable'


def test_registered_semantic_coverage_uses_only_valid_overlap(monkeypatch):
    pixels = np.full((120, 180, 3), 128, np.uint8)
    masks = {region: np.ones((120, 180), np.float32) if region == 'background' else np.zeros((120, 180), np.float32)
             for region in scene_analysis.REGIONS}
    scene = {'report': {'schema_version': 1, 'model_version': scene_analysis.MODEL_VERSION,
                       'bundle_id': 'a' * 64, 'backend': 'opencv_dnn_cpu', 'objects': [], 'faces': [], 'scene_tags': [],
                       'region_fractions': {region: float(region == 'background') for region in scene_analysis.REGIONS},
                       'region_methods': dict(scene_analysis._REGION_METHODS)}, 'masks': masks}
    monkeypatch.setattr(scene_analysis, 'analyze_scene', lambda *a: copy.deepcopy(scene))
    valid = np.zeros((120, 180), bool)
    valid[:, :90] = True
    evidence = scene_analysis.analyze_evidence(pixels, pixels, pixels, valid)
    assert evidence['status'] == 'ok'
    assert evidence['region_fractions']['background'] == .5
    scene_analysis.validate_semantic_report(evidence)


def test_bundle_checks_and_cache_repair_never_open_network(tmp_path, monkeypatch):
    def denied(*a, **kw):
        pytest.fail('Recognition or cache attempted a network operation')

    monkeypatch.setattr(socket, 'socket', denied)
    monkeypatch.setattr(socket, 'create_connection', denied)
    assert len(semantic_models.bundle_id()) == 64
    items = photo_items(tmp_path)
    with LibraryDB(tmp_path / 'db.sqlite') as db:
        assert source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)['status'] == 'ok'
        assert source_workflow.analyze_inputs(items, 'reference_jpg', cache=db)['performance']['cache_hits'] == 1
