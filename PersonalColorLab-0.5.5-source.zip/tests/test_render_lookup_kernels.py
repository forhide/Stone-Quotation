"""Precision and bounded-work contracts for fixed-grid CPU render kernels."""
import copy

import numpy as np
import pytest

from personal_color_lab.core import style_render
from personal_color_lab.core.style_dna import GRID, identity_dna


def test_uniform_curve_interpolation_matches_double_precision_reference():
    rng=np.random.default_rng(533)
    grid=GRID.astype(np.float32)
    # Include exact nodes, adjacent representable values, and clamping points.
    probes=np.r_[rng.uniform(-.2,1.2,8192).astype(np.float32),grid,
                 np.nextafter(grid,np.float32(-np.inf)),
                 np.nextafter(grid,np.float32(np.inf))]
    for _ in range(40):
        curve=np.maximum.accumulate(rng.uniform(0,1,33))
        expected=np.interp(probes,GRID,curve).astype(np.float32)
        actual=style_render._curve_pixels(probes,style_render._curve_coefficients(curve))
        assert np.array_equal(actual,expected)


@pytest.mark.parametrize('exposure',[-3.,-1.2,-.04,.04,.6,2.2,3.])
def test_source_exposure_table_preserves_each_srgb_level(exposure):
    dna=identity_dna();dna['exposure_ev']=exposure
    source=np.arange(256,dtype=np.uint8)
    rgb=source.astype(np.float32)/255
    linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
    linear*=2**exposure
    expected=np.where(linear<=.0031308,linear*12.92,1.055*np.maximum(linear,0)**(1/2.4)-.055)
    actual=style_render._render_plan(dna)['exposure_lut'][source]
    assert np.array_equal(actual,expected)


def test_channel_lookup_keeps_source_unmodified_and_retains_partial_strength():
    source=np.stack([np.arange(256,dtype=np.uint8)]*3,axis=1)[None,:,:]
    before=source.copy();dna=identity_dna()
    dna['channel_curves']['red']=np.clip(GRID*1.13,0,1).tolist()
    dna['channel_curves']['blue']=np.maximum.accumulate(np.clip(GRID*.89+.025,0,1)).tolist()
    original=source.astype(np.float32)/255;expected=original.copy()
    for index,channel in enumerate(('red','green','blue')):
        expected[:,:,index]=np.interp(original[:,:,index],GRID,dna['channel_curves'][channel])
    expected=np.rint(np.clip(original+(expected-original)*.63,0,1)*255).astype(np.uint8)
    actual=style_render.apply_pixels(source,dna,.63)[0]
    assert np.array_equal(actual,expected)
    assert np.array_equal(source,before)


def test_nonidentity_tone_does_not_apply_source_channel_table():
    dna=identity_dna()
    dna['tone_curve']=np.maximum.accumulate(np.clip(GRID*.91+.035,0,1)).tolist()
    dna['channel_curves']['red']=np.clip(GRID*1.12,0,1).tolist()
    assert not style_render._render_plan(dna)['channel_luts']
    dna['tone_curve']=GRID.tolist();dna['exposure_ev']=.2
    assert not style_render._render_plan(dna)['channel_luts']


def test_prepared_coefficients_are_owned_and_zero_zones_are_skipped():
    dna=identity_dna();dna['lab_shift']=[2.,-3.]
    dna['zone_shifts']['shadows']=[1.,-.5]
    plan=style_render._render_plan(dna);before=copy.deepcopy(plan)
    dna['tone_curve'][0]=.1;dna['lab_shift'][0]=7.;dna['zone_shifts']['shadows'][0]=4.
    assert len(plan['zone_shifts'])==1 and plan['zone_shifts'][0][0]=='shadows'
    assert np.array_equal(plan['lab_shift'],before['lab_shift'])
    assert np.array_equal(plan['zone_shifts'][0][1],before['zone_shifts'][0][1])
    assert np.array_equal(plan['tone_coefficients'][0],before['tone_coefficients'][0])
