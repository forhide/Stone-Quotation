"""Scene review belongs to the source photo across all offline input routes."""
import copy
import hashlib
import shutil
import socket
import threading

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core import alignment, source_workflow, xmp_analysis
from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.source_workflow import analyze_inputs, discover_inputs, set_scene_override
from personal_color_lab.core.synthetic_raw import write_test_dng


def _xmp(path, exposure='.6'):
    path.write_text(
        '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
        'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
        f'crs:Exposure2012="{exposure}" crs:Contrast2012="-12"/>', encoding='utf-8')
    return path


def _sources(tmp_path, mode):
    if mode == 'reference_jpg':
        Image.new('RGB', (160, 100), (160, 110, 80)).save(tmp_path / 'scene.jpg')
    else:
        raw = write_test_dng(tmp_path / 'scene.dng')
        if mode == 'raw_xmp':
            _xmp(tmp_path / 'scene.xmp')
        else:
            pixels, _, _ = decode_raw(raw)
            Image.fromarray(np.clip(pixels.astype(float) * .68 + [3, 0, 0], 0, 255).astype('uint8')).save(
                tmp_path / 'scene_edit.jpg', quality=99)
    return discover_inputs(tmp_path, mode)['items']


class MemoryCache:
    """Return the same stored object to catch accidental shared-cache writes."""
    def __init__(self):
        self.entries = {}

    def get_cached_analysis(self, key):
        return self.entries.get(key)

    def cache_analysis(self, key, payload):
        self.entries[key] = copy.deepcopy(payload)


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
def test_manual_scene_review_preserves_automatic_evidence_without_changing_originals(tmp_path, monkeypatch, mode):
    items = _sources(tmp_path, mode)
    paths = [path for path in tmp_path.iterdir() if path.is_file()]
    before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    monkeypatch.setattr(socket, 'socket', lambda *a, **kw: pytest.fail('Scene analysis opened a network connection'))
    items[0]['scene_override'] = ['night', 'portrait']
    batch = analyze_inputs(items, mode)
    assert batch['status'] == 'ok'
    report = batch['results'][0]['payload']['photo_scene']
    assert report['source'] == 'manual' and set(report['labels']) == {'night', 'portrait'}
    assert 'automatic_labels' in report and 'scores' in report
    assert batch['summary']['scene_stats']['categories']['portrait']['manual_count'] == 1
    assert batch['summary']['scene_stats']['categories']['night']['sample_count'] == 1
    snapshot = copy.deepcopy(batch)
    automatic = set_scene_override(batch, items[0]['id'], None)
    assert batch == snapshot
    assert automatic['results'][0]['payload']['photo_scene']['source'] == 'automatic'
    assert automatic['results'][0]['payload']['photo_scene']['labels'] == report['automatic_labels']
    excluded = set_scene_override(batch, items[0]['id'], [])
    assert excluded['results'][0]['payload']['photo_scene']['source'] == 'manual'
    assert excluded['results'][0]['payload']['photo_scene']['labels'] == []
    assert excluded['summary']['scene_stats']['unclassified_count'] == 1
    assert {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths} == before


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
def test_review_assignments_never_enter_file_analysis_cache(tmp_path, monkeypatch, mode):
    items = _sources(tmp_path, mode)
    cache = MemoryCache()
    items[0]['scene_override'] = ['day', 'food']
    first = analyze_inputs(items, mode, cache=cache)
    assert first['status'] == 'ok'
    cached_snapshot = copy.deepcopy(cache.entries)
    cached_report = next(iter(cache.entries.values()))['photo_scene']
    assert cached_report['source'] == 'automatic'
    items[0]['scene_override'] = ['night', 'portrait']
    engine = {'raw_jpg': 'analyze_pair', 'raw_xmp': 'analyze_raw_xmp', 'reference_jpg': 'analyze_reference'}[mode]
    monkeypatch.setattr(source_workflow, engine, lambda *a, **kw: pytest.fail('Reviewed a cached photo by decoding again'))
    second = analyze_inputs(items, mode, cache=cache)
    assert second['performance']['cache_hits'] == 1 and second['status'] == 'ok'
    assert set(second['results'][0]['payload']['photo_scene']['labels']) == {'night', 'portrait'}
    assert cache.entries == cached_snapshot
    items[0]['scene_override'] = None
    restored = analyze_inputs(items, mode, cache=cache)
    assert restored['results'][0]['payload']['photo_scene']['labels'] == cached_report['automatic_labels']


def test_pair_scene_observes_uncorrected_original_and_reuses_raw_decode(tmp_path, monkeypatch):
    from personal_color_lab.core import photo_scene
    items = _sources(tmp_path, 'raw_jpg')
    native_decode, classifier = alignment.decode_raw, photo_scene.classify_photo
    decoded, observed = [], []

    def decode(*args, **kwargs):
        result = native_decode(*args, **kwargs)
        decoded.append(result[0].copy())
        return result

    def classify(pixels, **kwargs):
        observed.append((pixels.copy(), kwargs))
        return classifier(pixels, **kwargs)

    monkeypatch.setattr(alignment, 'decode_raw', decode)
    monkeypatch.setattr(photo_scene, 'classify_photo', classify)
    batch = analyze_inputs(items, 'raw_jpg')
    assert batch['status'] == 'ok' and len(decoded) == len(observed) == 1
    with Image.open(items[0]['edited_path']) as edited:
        edited_mean = np.asarray(edited).mean()
    assert observed[0][0].mean() > edited_mean + 15
    assert observed[0][1]['evidence_source'] == 'original_raw'
    assert observed[0][1]['semantic_report']['status'] in {'ok', 'unavailable'}
    assert observed[0][1]['valid_mask'] is None
    assert np.array_equal(observed[0][0], decoded[0])


def test_raw_xmp_scene_uses_fixed_baseline_without_rendering_recorded_controls(tmp_path, monkeypatch):
    from personal_color_lab.core import photo_scene, raw_decode
    items = _sources(tmp_path, 'raw_xmp')
    _xmp(tmp_path / 'scene.xmp', exposure='4.5')
    native_decode, classifier = raw_decode.decode_raw, photo_scene.classify_photo
    decoding, observed = [], []

    def decode(*args, **kwargs):
        decoding.append((args, kwargs))
        return native_decode(*args, **kwargs)

    def classify(pixels, **kwargs):
        observed.append((pixels.copy(), kwargs))
        return classifier(pixels, **kwargs)

    monkeypatch.setattr(raw_decode, 'decode_raw', decode)
    monkeypatch.setattr(photo_scene, 'classify_photo', classify)
    result = analyze_inputs(items, 'raw_xmp')['results'][0]['payload']
    assert result['parameters']['Exposure2012'] == 4.5 and result['confidence_scope'] == 'recorded_xmp_parameters'
    assert len(decoding) == len(observed) == 1
    assert decoding[0][0][1] == 1024 and decoding[0][1]['quality'] == 'baseline'
    assert observed[0][1]['evidence_source'] == 'raw_xmp_baseline'
    assert result['provenance']['raw_decoded'] is False
    assert result['provenance']['scene_baseline']['decoded'] is True
    assert result['provenance']['scene_baseline']['xmp_settings_rendered'] is False


def test_undecodable_raw_keeps_recorded_xmp_controls_with_unknown_scene(tmp_path):
    raw = tmp_path / 'unavailable.nef'
    raw.write_bytes(b'Not a sensor image; recorded controls remain meaningful.')
    sidecar = _xmp(tmp_path / 'unavailable.xmp')
    result = xmp_analysis.analyze_raw_xmp(raw, sidecar)
    assert result['status'] == 'ok' and result['parameters']['Exposure2012'] == .6
    assert result['photo_scene']['labels'] == []
    assert result['provenance']['scene_baseline']['decoded'] is False
    assert 'scene_raw_unavailable' in result['warnings']


def test_cancel_during_raw_xmp_scene_never_returns_or_caches_partial_payload(tmp_path, monkeypatch):
    from personal_color_lab.core import raw_decode
    items = _sources(tmp_path, 'raw_xmp')
    stop, cache = threading.Event(), MemoryCache()

    def cancel(*args, **kwargs):
        stop.set()
        raise AnalysisCancelledError('Scene decode cancelled.')

    monkeypatch.setattr(raw_decode, 'decode_raw', cancel)
    batch = analyze_inputs(items, 'raw_xmp', cancel_event=stop, cache=cache)
    assert batch['status'] == 'cancelled' and batch['counts']['processed'] == 0
    assert batch['counts']['failed'] == 0 and batch['counts']['cancelled'] == 1
    assert batch['results'] == [] and cache.entries == {}


def test_same_original_with_two_sidecars_has_one_scene_support_and_consistent_review(tmp_path):
    raw = write_test_dng(tmp_path / 'scene.dng')
    first, second = _xmp(tmp_path / 'first.xmp'), _xmp(tmp_path / 'second.xmp', '1.2')
    item = next(row for row in discover_inputs(tmp_path, 'raw_xmp')['items'] if row['original_path'] == str(raw))
    one = dict(item, id='one', edited_path=str(first), status='ready', scene_override=['night', 'portrait'])
    two = dict(item, id='two', edited_path=str(second), status='ready', scene_override=None)
    batch = analyze_inputs([one, two], 'raw_xmp')
    assert batch['counts']['successful'] == 2
    assert batch['summary']['scene_stats']['sample_count'] == 1
    assert batch['summary']['scene_stats']['categories']['portrait']['sample_count'] == 1
    assert batch['summary']['scene_stats']['categories']['portrait']['style_sample_count'] == 0
    assert batch['summary']['scene_stats']['style_eligible_count'] == 0
    assert batch['summary']['scene_stats']['excluded_edit_conflict_count'] == 1
    assert 'scene_edit_evidence_conflict' in batch['summary']['warnings']
    assert all(set(row['payload']['photo_scene']['labels']) == {'night', 'portrait'} for row in batch['results'])
    revised = set_scene_override(batch, 'two', ['day', 'landscape'])
    assert all(set(row['payload']['photo_scene']['labels']) == {'day', 'landscape'} for row in revised['results'])
    assert revised['summary']['scene_stats']['categories']['landscape']['sample_count'] == 1


def test_conflicting_manual_categories_for_same_raw_require_review_and_keep_core_evidence(tmp_path):
    raw = write_test_dng(tmp_path / 'scene.dng')
    first, second = _xmp(tmp_path / 'first.xmp'), _xmp(tmp_path / 'second.xmp', '1.2')
    item = next(row for row in discover_inputs(tmp_path, 'raw_xmp')['items'] if row['original_path'] == str(raw))
    items = [dict(item, id='one', edited_path=str(first), status='ready', scene_override=['day']),
             dict(item, id='two', edited_path=str(second), status='ready', scene_override=['night'])]
    batch = analyze_inputs(items, 'raw_xmp')
    assert batch['counts']['successful'] == 2 and batch['summary']['scene_stats']['sample_count'] == 1
    assert all(row['item']['scene_status'] == 'needs_scene_review' for row in batch['results'])
    assert all(row['payload']['parameters']['Contrast2012'] == -12 for row in batch['results'])
    assert all(row['payload']['photo_scene']['labels'] == [] for row in batch['results'])
    assert batch['summary']['scene_stats']['categories'] == {}
    resolved = set_scene_override(batch, 'one', ['night', 'portrait'])
    assert all('scene_status' not in row['item'] for row in resolved['results'])
    assert all('scene_manual_assignment_conflict' not in row['payload']['photo_scene']['warnings'] for row in resolved['results'])


def test_duplicate_photo_review_updates_unique_evidence_without_decoding(tmp_path, monkeypatch):
    items = _sources(tmp_path, 'reference_jpg')
    shutil.copyfile(tmp_path / 'scene.jpg', tmp_path / 'copy.jpg')
    items = discover_inputs(tmp_path, 'reference_jpg')['items']
    batch = analyze_inputs(items, 'reference_jpg')
    duplicate = next(row for row in batch['results'] if row['status'] == 'duplicate')
    assert duplicate['item']['scene_original_fingerprint']
    monkeypatch.setattr(source_workflow, 'analyze_reference', lambda *a, **kw: pytest.fail('Review decoded a photo'))
    revised = set_scene_override(batch, duplicate['item']['id'], ['night', 'portrait'])
    unique = next(row for row in revised['results'] if row['status'] == 'ok')
    assert set(unique['payload']['photo_scene']['labels']) == {'night', 'portrait'}
    assert all(set(row['item']['scene_override']) == {'night', 'portrait'} for row in revised['results'])
    assert revised['summary']['scene_stats']['sample_count'] == 1
    assert revised['summary']['scene_stats']['categories']['portrait']['style_sample_count'] == 1


def test_duplicate_manual_conflicts_keep_one_global_measurement_until_review(tmp_path):
    _sources(tmp_path, 'reference_jpg')
    shutil.copyfile(tmp_path / 'scene.jpg', tmp_path / 'copy.jpg')
    items = discover_inputs(tmp_path, 'reference_jpg')['items']
    items[0]['scene_override'], items[1]['scene_override'] = ['day'], ['night']
    batch = analyze_inputs(items, 'reference_jpg')
    assert batch['counts']['successful'] == 1 and batch['counts']['duplicates'] == 1
    assert all(row['item']['scene_status'] == 'needs_scene_review' for row in batch['results'])
    assert next(row['payload'] for row in batch['results'] if row['status'] == 'ok')['photo_scene']['labels'] == []
    assert batch['summary']['scene_stats']['unclassified_count'] == 1


@pytest.mark.parametrize('labels', [['invented'], ['day', 'night'], 'portrait', [True]])
def test_invalid_scene_assignment_is_rejected_without_corrupting_counts(tmp_path, labels):
    items = _sources(tmp_path, 'reference_jpg')
    items[0]['scene_override'] = labels
    batch = analyze_inputs(items, 'reference_jpg')
    assert batch['counts']['successful'] == 0 and batch['counts']['failed'] == 1
    assert batch['counts']['processed'] == 1 and batch['results'][0]['payload'] is None
