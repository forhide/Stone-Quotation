"""Real review controls must change the applied recipe and reuse photo work."""
import copy
import numpy as np
from PIL import Image
import pytest
from test_source_workflow_ui import desktop,_pump,pytestmark
from test_style_workspace_ui import ready
from test_scene_render import _profile
from personal_color_lab.core import photo_scene,style_render

@pytest.mark.parametrize('language',['en','ko'])
def test_scene_review_changes_pixels_without_redecode_then_resets_on_new_photo(desktop,monkeypatch,language):
    app,root=desktop;app.lang.set(language);app.change_language()
    paths=[]
    for index in range(2):
        path=root/f'photo-{index}.jpg';pixels=np.random.default_rng(index).integers(30,220,(120,180,3),dtype='uint8');Image.fromarray(pixels).save(path);paths.append(path)
    calls=[];reads=[]
    def classify(*args,**kwargs):
        calls.append(1);report=photo_scene.unknown_photo_scene('controlled_contract');report.update(status='ok',bundle_id='a'*64);return report
    original_read=style_render.read_photo
    def read(*args,**kwargs):reads.append(1);return original_read(*args,**kwargs)
    monkeypatch.setattr(photo_scene,'classify_photo',classify);monkeypatch.setattr(photo_scene,'classifier_bundle_id',lambda:'a'*64)
    monkeypatch.setattr(style_render,'read_photo',read)
    studio=app.open_style_workspace(_profile());studio.recognition.set(False);studio.source=paths[0];studio._schedule_preview();_pump(app,lambda:ready(studio))
    common=studio.preview['rendered'].copy()
    studio.scene_review_btn.invoke();dialog=studio._scene_dialog
    dialog.time_selection.set(app.i18n.t('scene_label_night'));dialog._vars['portrait'].set(True);dialog.apply_button.invoke()
    _pump(app,lambda:ready(studio))
    assert reads==calls==[1]
    assert studio.preview['photo_scene']['labels']==['night','portrait']
    assert {m['label'] for m in studio.preview['scene_style']['matched_categories']}=={'night','portrait'}
    assert app.i18n.t('scene_label_night') in studio.photo_scene_label.cget('text')
    assert app.i18n.t('scene_label_portrait') in studio.scene_style_label.cget('text')
    assert not np.array_equal(common,studio.preview['rendered'])
    studio.scene_review_btn.invoke();studio._scene_dialog.auto_button.invoke();_pump(app,lambda:ready(studio))
    assert studio._scene_override is None and np.array_equal(common,studio.preview['rendered'])
    studio._apply_scene_selection([]);_pump(app,lambda:ready(studio))
    assert studio.preview['photo_scene']['source']=='manual' and studio.preview['photo_scene']['labels']==[]
    assert reads==calls==[1]
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',lambda **kw:str(paths[1]))
    studio.scene_review_btn.invoke();old=studio._scene_dialog;studio.choose_photo();_pump(app,lambda:ready(studio))
    assert old._closed and old.tk is None
    assert studio._scene_override is None and studio._scene_dialog is None
    assert len(reads)==len(calls)==2
    generation=studio._generation;app.lang.set('ko' if language=='en' else 'en');app.change_language()
    assert studio._generation==generation and len(calls)==2
