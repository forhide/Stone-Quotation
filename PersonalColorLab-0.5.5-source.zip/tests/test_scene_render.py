"""Whole-photo category recipes, separate from local object-region effects.

Classifier outputs below are controlled contract fixtures. Accuracy against
real photographs and the bundled local model is checked by release tools.
"""
from io import BytesIO
import copy

import numpy as np
from PIL import Image, ImageCms
import pytest

from personal_color_lab.core import alignment, photo_scene, scene_analysis, semantic_models, style_render
from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.edit_reverse import file_fingerprint
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.scene_styles import RECIPE_FIELDS, empty_scene_profile
from personal_color_lab.core.style_dna import blend_styles, identity_dna, validate_dna
from personal_color_lab.core.synthetic_raw import write_test_dng


def _profile():
    dna=identity_dna('Reviewed scene controls','recorded_xmp','my_style')
    dna['sample_count']=24
    dna['recorded_parameters']={'Temperature':6500.,'Tint':0.}
    profile=empty_scene_profile();profile['enabled']=True
    for label,ev,color,temperature in (
        ('day',-.4,[0.,-3.],5500.),('night',.8,[2.,4.],8000.),
        ('portrait',.2,[1.,0.],6500.),('food',.1,[0.,2.],6500.)):
        recipe={key:copy.deepcopy(dna[key]) for key in RECIPE_FIELDS}
        recipe.update(exposure_ev=ev,lab_shift=color,
                      recorded_parameters={'Temperature':temperature,'Tint':color[0]*3})
        profile['categories'][label]={'axis':photo_scene.LABEL_AXES[label],
            'sample_count':8,'confidence':1.,'diversity':1.,'shrinkage':8/12,
            'manual_count':8,'monochrome':False,'evidence':'recorded_xmp',
            'bundle_ids':[],'recipe':recipe}
        profile['coverage'][label]=8
    dna['scene_profile']=profile
    return validate_dna(dna)


def _automatic(bundle='a'*64):
    report=photo_scene.unknown_photo_scene('controlled_contract')
    if bundle is not None:report.update(status='ok',source='automatic',bundle_id=bundle)
    return report


@pytest.fixture
def controlled_classifier(monkeypatch):
    state={'bundle':'a'*64,'calls':[]}
    def classify(pixels,semantic_report=None,cancel_event=None):
        state['calls'].append(pixels.copy())
        return _automatic(state['bundle'])
    monkeypatch.setattr(photo_scene,'classifier_bundle_id',lambda:state['bundle'])
    monkeypatch.setattr(photo_scene,'classify_photo',classify)
    return state


@pytest.fixture
def photo(tmp_path):
    path=tmp_path/'source.jpg'
    y,x=np.indices((96,144))
    pixels=np.stack([60+x%100,50+y%100,80+(x+y)%100],axis=2).astype('uint8')
    Image.fromarray(pixels).save(path,quality=98,subsampling=0)
    return path


def _labels(result):
    return {entry['label'] for entry in result['scene_style']['matched_categories']}


def test_manual_categories_reuse_automatic_evidence_and_decoded_pixels(photo,monkeypatch,controlled_classifier):
    read=style_render.read_photo;reads=[]
    def counted(*args,**kwargs):
        reads.append(1);return read(*args,**kwargs)
    monkeypatch.setattr(style_render,'read_photo',counted)
    dna=_profile()
    first=style_render.render_preview(photo,dna)
    night=style_render.render_preview(photo,dna,base=first,scene_override=['night','portrait'])
    day=style_render.render_preview(photo,dna,base=night,scene_override=['day'])
    neutral=style_render.render_preview(photo,dna,0.,base=day,scene_override=['night'])
    assert reads==[1] and len(controlled_classifier['calls'])==1
    assert first['scene_style']['status']=='global'
    assert night['photo_scene']['source']=='manual'
    assert night['photo_scene']['automatic_labels']==first['photo_scene']['automatic_labels']
    assert _labels(night)=={'night','portrait'} and _labels(day)=={'day'}
    assert night['effective']['exposure_ev']>0>day['effective']['exposure_ev']
    assert not np.array_equal(day['rendered'],night['rendered'])
    assert np.array_equal(neutral['rendered'],neutral['original'])
    assert dna==_profile()


def test_explicit_empty_selection_and_restore_automatic_use_shared_global(photo,controlled_classifier):
    dna=_profile()
    first=style_render.render_preview(photo,dna,scene_override=['night'])
    empty=style_render.render_preview(photo,dna,base=first,scene_override=[])
    automatic=style_render.render_preview(photo,dna,base=empty)
    assert empty['photo_scene']['source']=='manual' and empty['photo_scene']['labels']==[]
    assert automatic['photo_scene']['source']=='automatic'
    assert empty['scene_style']['status']==automatic['scene_style']['status']=='global'
    assert np.array_equal(empty['rendered'],automatic['rendered'])
    assert len(controlled_classifier['calls'])==1


def test_classifier_bundle_or_report_schema_change_reclassifies_without_redecode(photo,monkeypatch,controlled_classifier):
    read=style_render.read_photo;reads=[]
    def counted(*args,**kwargs):
        reads.append(1);return read(*args,**kwargs)
    monkeypatch.setattr(style_render,'read_photo',counted)
    dna=_profile();first=style_render.render_preview(photo,dna,scene_override=['night'])
    controlled_classifier['bundle']='b'*64
    changed=style_render.render_preview(photo,dna,base=first,scene_override=['night'])
    broken=copy.deepcopy(changed);broken['automatic_photo_scene']['schema_version']=0
    repaired=style_render.render_preview(photo,dna,base=broken,scene_override=['night'])
    assert reads==[1] and len(controlled_classifier['calls'])==3
    assert repaired['photo_scene']['bundle_id']=='b'*64 and _labels(repaired)=={'night'}
    assert np.array_equal(repaired['rendered'],first['rendered'])


def test_manual_scene_recipe_survives_missing_classifier_and_recovery(photo,controlled_classifier):
    dna=_profile();first=style_render.render_preview(photo,dna,scene_override=['night'])
    controlled_classifier['bundle']=None
    unavailable=style_render.render_preview(photo,dna,base=first,scene_override=['night'])
    assert unavailable['photo_scene']['bundle_id'] is None
    assert unavailable['photo_scene']['source']=='manual' and _labels(unavailable)=={'night'}
    assert np.array_equal(unavailable['rendered'],first['rendered'])
    controlled_classifier['bundle']='b'*64
    recovered=style_render.render_preview(photo,dna,base=unavailable,scene_override=['night'])
    assert recovered['photo_scene']['bundle_id']=='b'*64 and len(controlled_classifier['calls'])==3


@pytest.mark.parametrize('override',['night',False,{},('night',),['unrecognized_scene'],[1]])
def test_invalid_scene_selection_does_not_hash_or_decode(tmp_path,monkeypatch,override):
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *a:pytest.fail('Hashed invalid categories'))
    monkeypatch.setattr(style_render,'read_photo',lambda *a,**k:pytest.fail('Decoded invalid categories'))
    with pytest.raises(ValueError):
        style_render.render_preview(tmp_path/'unused.dng',identity_dna(),scene_override=override)
    with pytest.raises(ValueError):
        style_render.export_jpeg(tmp_path/'unused.dng',tmp_path/'out.jpg',identity_dna(),scene_override=override)


def test_multilabel_deltas_are_bounded_and_global_fallback_ignores_brightness_groups(photo,controlled_classifier):
    dna=_profile()
    dna['scene_profile']['coverage']['landscape']=2
    dna['reference_target']={'quantiles':[.1,.25,.5,.75,.9],'saturation':.25,'zones':{}}
    dna['scene_targets']['low_key']={'quantiles':[.2,.45,.8,.95,1.],'saturation':.8,'zones':{}}
    dna['semantic_profile']={'bundle_id':'a'*64,'regions':{},'contexts':{
        'food':{'sample_count':8,'target':dna['scene_targets']['low_key']}}}
    result=style_render.render_preview(photo,dna,scene_override=['night','portrait','food'])
    weights=[entry['weight'] for entry in result['scene_style']['matched_categories']]
    assert sum(weights)<=.8+1e-12 and _labels(result)=={'night','portrait','food'}
    unsupported=style_render.render_preview(photo,dna,base=result,scene_override=['landscape'])
    plain=copy.deepcopy(dna);plain['scene_targets']={};plain['semantic_profile']['contexts']={}
    expected,_=style_render.prepare_style(unsupported['original'],plain)
    assert unsupported['scene_style']['status']=='global' and unsupported['effective']==expected


def test_hybrid_components_each_use_the_chosen_scene_before_mixing(photo,controlled_classifier):
    first=_profile();second=_profile();second['name']='Second shared style'
    second['scene_profile']['categories']['night']['recipe']['exposure_ev']=-.4
    hybrid=blend_styles([first,second],[.25,.75])
    result=style_render.render_preview(photo,hybrid,scene_override=['night'])
    a=style_render.render_preview(photo,first,base=result,scene_override=['night'])
    b=style_render.render_preview(photo,second,base=result,scene_override=['night'])
    assert result['effective']['exposure_ev']==pytest.approx(.25*a['effective']['exposure_ev']+.75*b['effective']['exposure_ev'])
    assert result['scene_style']['status']=='hybrid'
    assert len(result['scene_style']['components'])==2


@pytest.mark.parametrize('hybrid',[False,True])
def test_object_region_replacement_uses_the_scene_adapted_component_baseline(tmp_path,monkeypatch,controlled_classifier,hybrid):
    source=tmp_path/'neutral.jpg';Image.new('RGB',(120,80),(120,120,120)).save(source)
    masks={region:np.zeros((80,120),np.float32) for region in REGIONS};masks['food'][:]=1
    scene={'report':{'bundle_id':'a'*64,'scene_tags':['food']},'masks':masks}
    monkeypatch.setattr(semantic_models,'bundle_id',lambda:'a'*64)
    monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *a:copy.deepcopy(scene))
    dna=_profile()
    dna['semantic_profile']={'bundle_id':'a'*64,'contexts':{},'regions':{'food':{
        'sample_count':3,'evidence':'observed_transform','target':None,
        'tone_curve':np.linspace(0,1,33).tolist(),'saturation_scale':1.,'lab_shift':[0.,0.]}}}
    if hybrid:dna=blend_styles([dna],[1.])
    whole=style_render.render_preview(source,dna,scene_override=['night'])
    replaced=style_render.render_preview(source,dna,base=whole,scene_override=['night'],
                                        recognition=True,object_strength=1.,protect_faces=False)
    assert not np.array_equal(whole['rendered'],whole['original'])
    assert np.array_equal(replaced['rendered'],replaced['original'])


def test_supported_monochrome_scene_and_partial_strength_preserve_intent(photo,controlled_classifier):
    dna=_profile();category=dna['scene_profile']['categories']['night']
    category['monochrome']=True;category['recipe']['saturation_scale']=0.
    full=style_render.render_preview(photo,dna,scene_override=['night'])
    partial=style_render.render_preview(photo,dna,.4,base=full,scene_override=['night'])
    assert full['effective']['saturation_scale']==0.
    assert full['scene_style']['monochrome']=='supported_scene'
    assert np.ptp(full['rendered'].astype(int),axis=2).max()==0
    assert np.ptp(partial['rendered'].astype(int),axis=2).max()>0


def test_photo_style_thumbnails_use_the_same_reviewed_category_without_new_inference(photo,monkeypatch,controlled_classifier):
    from personal_color_lab.ui.style_tiles import build_style_tiles
    dna=_profile();category=dna['scene_profile']['categories']['night']
    category['monochrome']=True;category['recipe']['saturation_scale']=0.
    night=style_render.render_preview(photo,dna,scene_override=['night'])
    day=style_render.render_preview(photo,dna,base=night,scene_override=['day'])
    before=day['original'].copy()
    monkeypatch.setattr(style_render,'read_photo',lambda *a,**k:pytest.fail('Decoded thumbnail source'))
    monkeypatch.setattr(photo_scene,'classify_photo',lambda *a,**k:pytest.fail('Classified a thumbnail'))
    monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *a,**k:pytest.fail('Recognized thumbnail regions'))
    night_tile=build_style_tiles(night,{'personal':dna},strength=1.)[0]
    day_tile=build_style_tiles(day,{'personal':dna},strength=1.)[0]
    assert np.ptp(night_tile['pixels'].astype(int),axis=2).max()==0
    assert np.ptp(day_tile['pixels'].astype(int),axis=2).max()>0
    assert night_tile['supported'] and day_tile['supported']
    assert {m['label'] for m in night_tile['scene_style']['matched_categories']}=={'night'}
    assert {m['label'] for m in day_tile['scene_style']['matched_categories']}=={'day'}
    assert np.array_equal(day['original'],before)


def test_jpeg_export_and_xmp_use_the_adapted_scene_recipe(photo,tmp_path,controlled_classifier):
    dna=_profile();before=file_fingerprint(photo)
    preview=style_render.render_preview(photo,dna,scene_override=['night','portrait'])
    full,_=style_render.read_photo(photo,max_dimension=1_000_000)
    expected,_=style_render.apply_pixels(full,preview['effective'])
    stream=BytesIO();profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    Image.fromarray(expected).save(stream,format='JPEG',quality=95,subsampling=0,icc_profile=profile)
    with Image.open(BytesIO(stream.getvalue())) as image:expected_jpeg=np.array(image)
    output=tmp_path/'styled.jpg'
    exported=style_render.export_jpeg(photo,output,dna,scene_override=['night','portrait'])
    with Image.open(output) as image:
        assert np.array_equal(np.array(image),expected_jpeg)
        assert image.info['icc_profile'] and not image.getexif()
    assert _labels(exported)=={'night','portrait'} and file_fingerprint(photo)==before
    xmp=tmp_path/'scene.xmp';style_render.export_xmp(xmp,dna,preview['effective'])
    from personal_color_lab.core.xmp_analysis import _parse_xml,_read_settings
    parameters,_,_,_,_=_read_settings(_parse_xml(xmp.read_bytes()))
    assert parameters['Exposure2012']==pytest.approx(preview['effective']['exposure_ev'],abs=.0001)
    assert parameters['Temperature']==round(preview['effective']['recorded_parameters']['Temperature'])
    assert parameters['Temperature']!=dna['recorded_parameters']['Temperature']


def test_raw_export_classifies_the_precision_preview_after_one_sensor_decode(tmp_path,monkeypatch,controlled_classifier):
    source=write_test_dng(tmp_path/'sensor.dng',width=2880,height=1920,orientation=6)
    dna=_profile();before=file_fingerprint(source)
    fast=style_render.render_preview(source,dna,raw_quality='interactive',scene_override=['night'])
    assert fast['raw_decode']['half_size']
    strict=style_render.render_preview(source,dna,scene_override=['night'])
    calls=[];decode=alignment.decode_raw
    def counted(*args,**kwargs):
        calls.append((args[1],kwargs.get('quality')));return decode(*args,**kwargs)
    monkeypatch.setattr(alignment,'decode_raw',counted)
    result=style_render.export_jpeg(source,tmp_path/'styled.jpg',dna,scene_override=['night'])
    assert calls==[(1_000_000,'baseline')]
    assert np.array_equal(controlled_classifier['calls'][-1],strict['original'])
    assert not np.array_equal(controlled_classifier['calls'][-1],fast['original'])
    assert result['dimensions']==strict['original_dimensions']
    assert file_fingerprint(source)==before and result['source_unchanged'] and not result['gps_exported']


def test_classifier_cancellation_never_falls_back_or_publishes_output(photo,tmp_path,monkeypatch):
    calls=[]
    def cancelled(*args,**kwargs):
        calls.append(1);raise AnalysisCancelledError('Classification cancelled.')
    monkeypatch.setattr(photo_scene,'classify_photo',cancelled)
    target=tmp_path/'out.jpg'
    with pytest.raises(AnalysisCancelledError):
        style_render.export_jpeg(photo,target,_profile(),scene_override=['night'])
    assert calls==[1] and not target.exists() and not list(tmp_path.glob('.pcl-export-*.tmp'))
