"""Radial geometry, orientation, recovery, bounded memory and border contracts."""
from threading import Event

import cv2
import numpy as np
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.lens_correction import correct_lens_distortion, distortion_coordinates


def _plan(model='poly3', coefficients=(-.03,), **changes):
    values = {'available': True, 'status': 'matched', 'distortion_model': model,
              'coefficients': list(coefficients), 'camera_crop_factor': 1.,
              'calibration_crop_factor': 1., 'calibration_aspect': 1.5,
              'profile_id': 'fixture', 'bundle_id': 'fixture-bundle'}
    values.update(changes)
    return values


def _maps(width, height, plan, border='keep'):
    tiles = list(distortion_coordinates(width, height, plan, border=border))
    return np.vstack([tile[1] for tile in tiles]), np.vstack([tile[2] for tile in tiles]), tiles[0][3]


@pytest.mark.parametrize('model,coefficients', [('poly3', [0]), ('poly5', [0, 0]), ('ptlens', [0, 0, 0])])
def test_zero_distortion_exact_identity_and_no_source_mutation(model, coefficients):
    pixels = np.random.default_rng(3).integers(0, 256, (123, 185, 3), np.uint8)
    before = pixels.copy()
    result, report = correct_lens_distortion(pixels, _plan(model, coefficients))
    assert np.array_equal(result, before)
    assert np.array_equal(pixels, before)
    assert report['crop_scale'] == 1 and report['valid_fraction'] == 1
    assert not report['edge_crop_applied']


@pytest.mark.parametrize('model,coefficients', [('poly3', [-.04]), ('poly5', [-.04, .01]), ('ptlens', [.01, -.04, .015])])
def test_maps_match_independent_lensfun_focal_preserving_equations(model, coefficients):
    width, height = 600, 400
    map_x, map_y, scale = _maps(width, height, _plan(model, coefficients))
    points = [(0, 0), (599, 399), (217, 163), (299, 199)]
    for x, y in points:
        # The calibration 3:2 and actual 600:400 image make r=1 equal
        # half-height at the sensor outer rim (not height-1).
        dx, dy = x - 299.5, y - 199.5
        radius = np.hypot(dx, dy) / 200
        if model == 'poly3':
            k, = coefficients
            factor = 1 + k * radius**2 / (1 - k)**3
        elif model == 'poly5':
            k1, k2 = coefficients
            factor = 1 + k1 * radius**2 + k2 * radius**4
        else:
            a, b, c = coefficients
            d = 1 - a - b - c
            factor = 1 + a * radius**3 / d**4 + b * radius**2 / d**3 + c * radius / d**2
        assert map_x[y, x] == pytest.approx(299.5 + dx * factor, abs=3e-5)
        assert map_y[y, x] == pytest.approx(199.5 + dy * factor, abs=3e-5)
    assert scale == 1.


def test_full_frame_profile_scales_for_crop_sensor_and_calibration_aspect():
    full_x, full_y, _ = _maps(600, 400, _plan())
    crop_x, crop_y, _ = _maps(600, 400, _plan(camera_crop_factor=1.5))
    # Poly3 distortion strength is quadratic in physical sensor radius.
    assert (crop_x[-1, -1] - 599) / (full_x[-1, -1] - 599) == pytest.approx(1 / 1.5**2, abs=1e-6)
    assert (crop_y[-1, -1] - 399) / (full_y[-1, -1] - 399) == pytest.approx(1 / 1.5**2, abs=1e-6)
    four_thirds_x, _, _ = _maps(600, 400, _plan(calibration_aspect=4 / 3))
    ratio = ((4 / 3)**2 + 1) / (1.5**2 + 1)
    assert (four_thirds_x[-1, -1] - 599) / (full_x[-1, -1] - 599) == pytest.approx(ratio, abs=2e-6)


@pytest.mark.parametrize('transform,matrix', [
    (lambda image: image, [[1, 0], [0, 1]]),
    (lambda image: image[:, ::-1], [[-1, 0], [0, 1]]),
    (lambda image: image[::-1, ::-1], [[-1, 0], [0, -1]]),
    (lambda image: image[::-1], [[1, 0], [0, -1]]),
    (lambda image: image.transpose(1, 0, 2), [[0, 1], [1, 0]]),
    (lambda image: np.rot90(image, 3), [[0, -1], [1, 0]]),
    (lambda image: image.transpose(1, 0, 2)[::-1, ::-1], [[0, -1], [-1, 0]]),
    (lambda image: np.rot90(image), [[0, 1], [-1, 0]]),
])
def test_centered_radial_correction_commutes_with_all_tiff_orientations(transform, matrix):
    pixels = np.random.default_rng(4).integers(0, 256, (160, 240, 3), np.uint8)
    corrected, _ = correct_lens_distortion(pixels, _plan('ptlens', [.01, -.04, .015]))
    oriented_pixels = np.ascontiguousarray(transform(pixels))
    oriented, _ = correct_lens_distortion(oriented_pixels, _plan('ptlens', [.01, -.04, .015]))
    base_x, base_y, _ = _maps(240, 160, _plan('ptlens', [.01, -.04, .015]))
    oriented_x, oriented_y, _ = _maps(oriented_pixels.shape[1], oriented_pixels.shape[0], _plan('ptlens', [.01, -.04, .015]))
    base_vectors = np.dstack((base_x - 119.5, base_y - 79.5, np.zeros_like(base_x)))
    expected_vectors = transform(base_vectors)[..., :2] @ np.asarray(matrix).T
    actual_vectors = np.dstack((oriented_x - (oriented_pixels.shape[1] - 1) / 2,
                               oriented_y - (oriented_pixels.shape[0] - 1) / 2))
    assert np.allclose(actual_vectors, expected_vectors, atol=2e-5, rtol=0)
    # OpenCV uses a 1/32-pixel interpolation table. Float32 absolute-coordinate
    # rounding at table boundaries may differ for a few high-frequency pixels
    # under reflections, although the physical maps commute geometrically.
    difference = np.abs(oriented.astype(np.int16) - transform(corrected).astype(np.int16))
    assert difference.max() <= 8 and difference.mean() < .001


def test_pincushion_fit_removes_invalid_borders_without_fabricated_pixels_and_minimizes_zoom():
    image = np.full((240, 360, 3), 211, np.uint8)
    kept, keep_report = correct_lens_distortion(image, _plan(coefficients=[.035]), border='keep')
    fitted, fit_report = correct_lens_distortion(image, _plan(coefficients=[.035]), border='fit')
    assert kept.min() == 0 and keep_report['valid_fraction'] < 1
    assert np.all(fitted == 211) and fit_report['valid_fraction'] == 1
    assert fit_report['crop_scale'] > 1 and fit_report['edge_crop_applied']
    assert fit_report['retained_linear_fraction'] == 1 / fit_report['crop_scale']
    # Independent corner radial equation gives the limiting fit for this
    # increasing polynomial; scale just below the result must exceed bounds.
    scale = fit_report['crop_scale'] * (1 - 1e-5)
    radius = np.hypot(179.5, 119.5) / 120 / scale
    factor = 1 + .035 * radius**2 / (1 - .035)**3
    assert 179.5 / scale * factor > 179.5


def test_barrel_profile_does_not_add_an_unnecessary_crop():
    pixels = np.full((200, 300, 3), 127, np.uint8)
    _, report = correct_lens_distortion(pixels, _plan(coefficients=[-.025]))
    assert report['crop_scale'] == 1 and report['valid_fraction'] == 1


def test_curved_grid_is_restored_using_independent_inverse_radial_generation():
    width, height = 600, 400
    y, x = np.indices((height, width), dtype=np.float64)
    dx, dy = x - 299.5, y - 199.5
    radius_distorted = np.hypot(dx, dy) / 200
    # Solve distorted_radius=undistorted_radius*(1+k*r^2/d^3)
    # independently by Newton to draw a known straight-grid scene through a
    # synthetic barrel lens. Test then uses production forward lookup to undo.
    k, d = -.04, 1.04
    radius_undistorted = radius_distorted.copy()
    for _ in range(12):
        radius_undistorted -= (radius_undistorted * (1 + k * radius_undistorted**2 / d**3) - radius_distorted) / (1 + 3 * k * radius_undistorted**2 / d**3)
    factor = np.divide(radius_undistorted, radius_distorted, out=np.ones_like(radius_distorted), where=radius_distorted > 0)
    ideal_x, ideal_y = 299.5 + dx * factor, 199.5 + dy * factor
    lines = (np.sin(ideal_x * np.pi / 50)**2 < .02) | (np.sin(ideal_y * np.pi / 50)**2 < .02)
    curved = np.repeat(np.where(lines, 240, 20).astype(np.uint8)[..., None], 3, axis=2)
    result, report = correct_lens_distortion(curved, _plan(coefficients=[k]), border='keep')
    assert report['applied']
    # A column at known undistorted x=150 should stay a bright vertical line;
    # uncorrected curved data misses that column over substantial row ranges.
    rows = slice(40, 360)
    assert np.mean(result[rows, 150, 0]) > 215
    assert np.mean(curved[rows, 150, 0]) < 150


@pytest.mark.parametrize('plan', [_plan(coefficients=[-.8]), _plan(coefficients=[.99]),
    _plan('ptlens', [.4, .4, .4]), _plan('poly5', [float('nan'), 0]), _plan('acm', [0]),
    _plan(camera_crop_factor=float('inf'))])
def test_unsafe_profiles_return_original_pixels_with_explicit_skip(plan):
    image = np.full((180, 270, 3), 127, np.uint8)
    result, report = correct_lens_distortion(image, plan)
    assert result is image and not report['applied'] and report['status'] == 'unsafe_geometry'


def test_known_camera_aspect_mismatch_and_uncovered_sensor_do_not_guess_a_crop():
    pixels = np.full((200, 300, 3), 127, np.uint8)
    for plan in (_plan(camera_aspect=4 / 3), _plan(camera_crop_factor=1., calibration_crop_factor=2.)):
        result, report = correct_lens_distortion(pixels, plan)
        assert result is pixels and report['status'] == 'unsafe_geometry'
    _, report = correct_lens_distortion(pixels, _plan(camera_aspect=1.5))
    assert report['applied']


def test_sampling_dimension_limit_is_a_safe_skip_before_destination_allocation():
    pixels = np.zeros((2, 32767, 3), np.uint8)
    result, report = correct_lens_distortion(pixels, _plan(coefficients=[0]))
    assert result is pixels and report['status'] == 'unsafe_geometry'


def test_unavailable_profile_and_cancellation_never_produce_partial_result(monkeypatch):
    image = np.full((500, 750, 3), 127, np.uint8)
    result, report = correct_lens_distortion(image, {'available': False, 'status': 'lens_not_found'})
    assert result is image and report['status'] == 'lens_not_found'
    event = Event()
    event.set()
    with pytest.raises(AnalysisCancelledError):
        correct_lens_distortion(image, _plan(), cancel_event=event)
    event.clear()
    original_remap = cv2.remap
    calls = []
    def cancelled_remap(*args, **kwargs):
        calls.append(args[1].shape)
        result = original_remap(*args, **kwargs)
        event.set()
        return result
    monkeypatch.setattr(cv2, 'remap', cancelled_remap)
    with pytest.raises(AnalysisCancelledError):
        correct_lens_distortion(image, _plan(), cancel_event=event)
    assert len(calls) == 1
    assert np.all(image == 127)


def test_map_memory_is_bounded_and_tiles_cover_whole_image_without_seams(monkeypatch):
    import personal_color_lab.core.lens_correction as correction
    pixels = np.random.default_rng(5).integers(0, 256, (200, 300, 3), np.uint8)
    expected, _ = correct_lens_distortion(pixels, _plan())
    monkeypatch.setattr(correction, 'MAP_TILE_PIXELS', 300 * 7)
    tiles = list(distortion_coordinates(300, 200, _plan()))
    assert len(tiles) == 29
    assert all(tile[1].size <= 2100 and tile[2].size <= 2100 for tile in tiles)
    result, _ = correct_lens_distortion(pixels, _plan())
    assert np.array_equal(result, expected)
