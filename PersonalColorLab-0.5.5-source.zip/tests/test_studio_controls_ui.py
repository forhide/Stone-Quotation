"""Native Tk interaction and lifecycle for the vector studio slider."""
import gc
import sys
import threading
import tkinter as tk
import weakref

import pytest

from test_source_workflow_ui import desktop,pytestmark
from personal_color_lab.ui.display import ui_pixels
from personal_color_lab.ui.studio_controls import StudioSlider,StudioToggle


def _slider(app,value=35,**kwargs):
    window=tk.Toplevel(app);window.geometry('360x110')
    variable=tk.DoubleVar(master=app,value=value);commands=[]
    slider=StudioSlider(window,variable=variable,command=commands.append,**kwargs)
    slider.pack(fill='x',padx=15,pady=20);app.update()
    return window,slider,variable,commands


def test_track_click_drag_and_thumb_click_preserve_binding(desktop):
    app,_=desktop;window,slider,variable,commands=_slider(app)
    left,right,y=slider._geometry()
    slider.event_generate('<ButtonPress-1>',x=round(left+.75*(right-left)),y=round(y))
    slider.event_generate('<ButtonRelease-1>',x=round(left+.75*(right-left)),y=round(y))
    app.update();assert variable.get()==pytest.approx(75,abs=.3)
    assert len(commands)==1
    x,_=slider._position();previous=variable.get()
    slider.event_generate('<ButtonPress-1>',x=round(x+3),y=round(y))
    app.update();assert variable.get()==previous
    slider.event_generate('<B1-Motion>',x=round(left+.45*(right-left)+3),y=round(y))
    slider.event_generate('<ButtonRelease-1>',x=round(left+.45*(right-left)+3),y=round(y))
    app.update();assert variable.get()==pytest.approx(45,abs=.5)
    assert float(commands[-1])==slider.get()
    window.destroy()


def test_keyboard_arrows_home_end_and_pages(desktop):
    app,_=desktop;window,slider,variable,commands=_slider(app)
    slider.focus_force();app.update()
    for key,expected in [('Right',36),('Up',37),('Left',36),('Down',35),
                         ('Prior',45),('Next',35),('Home',0),('End',100)]:
        slider.event_generate('<KeyPress-'+key+'>');app.update()
        assert variable.get()==expected
    assert len(commands)==8
    assert slider.find_withtag('focus')
    window.destroy()


def test_disabled_control_ignores_pointer_keys_and_set(desktop):
    app,_=desktop;window,slider,variable,commands=_slider(app)
    slider.focus_force();app.update();slider.configure(state='disabled');app.update()
    assert str(slider.cget('state'))=='disabled' and not slider.find_withtag('focus')
    left,right,y=slider._geometry()
    slider.event_generate('<ButtonPress-1>',x=round(right),y=round(y))
    slider.event_generate('<B1-Motion>',x=round(left),y=round(y))
    slider.event_generate('<ButtonRelease-1>',x=round(left),y=round(y))
    slider.event_generate('<KeyPress-End>');slider.set(80);app.update()
    assert variable.get()==35 and commands==[]
    slider.configure(state='normal');slider.set(80)
    assert variable.get()==80 and len(commands)==1
    window.destroy()


def test_variable_writes_clamp_redraw_and_trace_removal(desktop):
    app,_=desktop;window,slider,variable,commands=_slider(app)
    before=list(variable.trace_info());assert len(before)==1
    variable.set(500);app.update()
    assert slider.get()==100 and variable.get()==100 and commands==[]
    variable.set(float('nan'));app.update()
    assert slider.get()==100 and variable.get()==100
    replacement=tk.DoubleVar(master=app,value=23)
    slider.configure(variable=replacement)
    assert variable.trace_info()==[] and slider.get()==23
    window.destroy();app.update()
    assert replacement.trace_info()==[]
    replacement.set(40);app.update()  # No call into a destroyed Canvas.


@pytest.mark.parametrize('desktop',[1,2],indirect=True)
def test_slider_scales_track_thumb_and_touch_height(desktop):
    app,_=desktop;window,slider,variable,commands=_slider(app)
    assert slider.winfo_height()>=ui_pixels(slider,28)
    thumb=slider.coords(slider.find_withtag('thumb')[0])
    assert thumb[2]-thumb[0]==2*ui_pixels(slider,5)
    assert float(slider.itemcget(slider.find_withtag('track')[0],'width'))==ui_pixels(slider,3)
    assert slider.itemcget(slider.find_withtag('thumb')[0],'outline')==''
    window.destroy()


def test_descending_and_fixed_ranges_have_safe_bounds(desktop):
    app,_=desktop;window,slider,variable,commands=_slider(app,value=80,from_=100,to=0)
    slider.focus_force();app.update();slider.event_generate('<KeyPress-Right>');app.update()
    assert slider.get()==79
    slider.set(-50);assert variable.get()==0
    slider.configure(from_=4,to=4);assert variable.get()==4
    slider.event_generate('<ButtonPress-1>',x=100,y=14)
    slider.event_generate('<ButtonRelease-1>',x=100,y=14)
    app.update();assert slider.get()==4
    window.destroy()


def _toggle(app,value=False,**kwargs):
    window=tk.Toplevel(app);window.geometry('310x130')
    variable=tk.BooleanVar(master=app,value=value);commands=[]
    toggle=StudioToggle(window,variable=variable,text='Recognize photo objects',
                        command=lambda:(commands.append(variable.get()),'toggled')[1],**kwargs)
    toggle.pack(fill='x',padx=20,pady=20);app.update()
    return window,toggle,variable,commands


def test_toggle_invoke_click_and_keyboard_update_one_boolean_binding(desktop):
    app,_=desktop;window,toggle,variable,commands=_toggle(app)
    assert toggle.invoke()=='toggled' and variable.get()
    toggle._label.event_generate('<Button-1>',x=20,y=5);app.update()
    assert not variable.get()
    toggle._switch.event_generate('<Button-1>',x=15,y=10);app.update()
    assert variable.get()
    toggle.focus_force();app.update()
    toggle.event_generate('<KeyPress-space>');app.update();assert not variable.get()
    toggle.event_generate('<KeyPress-Return>');app.update();assert variable.get()
    assert commands==[True,False,True,False,True]
    assert toggle._switch.find_withtag('focus')
    assert toggle.cget('font')=='LabBody'
    window.destroy()


def test_toggle_disabled_translation_background_and_external_value(desktop):
    app,_=desktop;window,toggle,variable,commands=_toggle(app)
    toggle.configure(text='인물의 자연스러운 피부색 유지',bg='#242B33',state='disabled')
    app.update();assert toggle.cget('text')=='인물의 자연스러운 피부색 유지'
    assert toggle.cget('state')=='disabled'
    assert toggle._label.cget('background')==toggle._switch.cget('background')=='#242B33'
    toggle.focus_force();app.update()
    assert toggle.invoke()==''
    toggle.event_generate('<KeyPress-space>')
    toggle._label.event_generate('<Button-1>',x=20,y=5);app.update()
    assert not variable.get() and commands==[]
    variable.set(True);app.update()
    assert toggle._value and commands==[]
    assert not toggle._switch.find_withtag('focus')
    toggle.configure(state='normal');toggle.invoke();assert not variable.get()
    assert commands==[False]
    toggle.configure(command=lambda:None)
    assert toggle.invoke()=='' and variable.get()
    window.destroy()


def test_toggle_variable_trace_and_parent_destroy_leave_no_tk_callbacks(desktop):
    app,_=desktop;window,toggle,variable,commands=_toggle(app)
    assert len(variable.trace_info())==1
    replacement=tk.BooleanVar(master=app,value=True)
    toggle.configure(variable=replacement)
    assert variable.trace_info()==[] and toggle._value
    replacement.set(False);app.update()
    assert not toggle._value and commands==[]
    window.destroy();app.update()
    assert replacement.trace_info()==[]
    replacement.set(True);variable.set(True);app.update()


def test_destroy_releases_variable_owners_before_worker_garbage_collection(desktop,monkeypatch):
    app,_=desktop
    gc.collect()  # Clear unrelated old test cycles on the current UI thread.
    window=tk.Toplevel(app)
    external_number=tk.DoubleVar(master=app,value=31)
    external_bool=tk.BooleanVar(master=app,value=True)
    controls=[StudioSlider(window),StudioToggle(window),
              StudioSlider(window,variable=external_number),StudioToggle(window,variable=external_bool)]
    owned_refs=[weakref.ref(control._variable) for control in controls[:2]]
    widget_refs=[weakref.ref(control) for control in controls]
    for control in controls:
        control.pack()
        # Model a retained dead-widget cycle collected by a later photo worker.
        control._later_collect_cycle=control
    del control
    app.update();window.destroy();app.update()
    assert all(control._variable is None for control in controls)
    assert controls[1]._label is None and controls[1]._switch is None
    assert controls[3]._label is None and controls[3]._switch is None
    assert all(reference() is None for reference in owned_refs)
    # Cleanup removes our references and traces, not the caller's variable.
    external_number.set(41);external_bool.set(False)
    assert external_number.get()==41 and not external_bool.get()
    assert external_number.trace_info()==external_bool.trace_info()==[]
    app.close()
    del controls,window,external_number,external_bool
    unraisable=[]
    monkeypatch.setattr(sys,'unraisablehook',lambda report:unraisable.append((report.exc_type,str(report.exc_value))))
    worker=threading.Thread(target=gc.collect)
    worker.start();worker.join(8)
    assert not worker.is_alive() and unraisable==[]
    assert all(reference() is None for reference in widget_refs)
