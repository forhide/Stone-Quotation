"""Monochrome evidence must transfer without confusing mixed or toned photos."""
import copy

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.color_analysis import analyze_color
from personal_color_lab.core.edit_reverse import analyze_pair
from personal_color_lab.core.reference_analysis import analyze_reference
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.style_dna import dna_from_batch,dna_from_pair,identity_dna,validate_dna
from personal_color_lab.core.style_regions import learn_profile,regional_transforms
from personal_color_lab.core.style_render import _effective,_measure,_render_regions,apply_pixels,render_preview
from personal_color_lab.core.scene_analysis import REGIONS


def _pixels(seed=6):
    rng=np.random.default_rng(seed)
    pixels=cv2.GaussianBlur(rng.integers(30,220,(180,280,3),dtype='uint8'),(5,5),0)
    for _ in range(60):
        x,y=rng.integers([10,10],[270,170])
        cv2.circle(pixels,(int(x),int(y)),5,tuple(int(c) for c in rng.integers(40,230,3)),-1)
    return pixels


def _gray(pixels):
    return cv2.cvtColor(cv2.cvtColor(pixels,cv2.COLOR_RGB2GRAY),cv2.COLOR_GRAY2RGB)


def _write(path,pixels):
    Image.fromarray(pixels).save(path,quality=98,subsampling=0)
    return path


def _batch(payloads):
    return {'mode':'reference_jpg','results':[{'status':'ok','payload':p} for p in payloads]}


@pytest.mark.parametrize('raw_source',[False,True])
def test_color_pair_to_black_and_white_transfers_full_desaturation(tmp_path,raw_source):
    if raw_source:
        source=write_test_dng(tmp_path/'original.dng')
        pixels=decode_raw(source)[0]
    else:
        source=_write(tmp_path/'original.jpg',_pixels())
        pixels=np.asarray(Image.open(source))
    edited=_write(tmp_path/'edited.jpg',_gray(pixels))
    payload=analyze_pair(source,edited)
    assert payload['status']=='ok'
    evidence=payload['color']['achromatic_evidence']
    assert evidence['sample_count']>=256 and evidence['original_chromatic_fraction']>=.05
    assert evidence['edited_achromatic_fraction']>=.99
    dna=dna_from_pair(payload,'B&W edits')
    assert dna['saturation_scale']==0 and dna['lab_shift']==[0.,0.]
    rendered=render_preview(source,dna)['rendered']
    assert np.ptp(rendered.astype(int),axis=2).max()<=1


def test_gray_natural_source_and_sepia_edit_do_not_claim_monochrome_intent(tmp_path):
    colored=_pixels()
    mostly_gray=_gray(colored);mostly_gray[:8,:8]=[160,90,90]
    source=_write(tmp_path/'natural-gray.jpg',mostly_gray)
    edited=_write(tmp_path/'gray-edit.jpg',_gray(mostly_gray))
    payload=analyze_pair(source,edited);assert payload['status']=='ok'
    assert payload['color']['achromatic_evidence']['original_chromatic_fraction']<.05
    assert dna_from_pair(payload,'Natural gray')['saturation_scale']>0
    source=_write(tmp_path/'colored.jpg',colored)
    sepia=np.clip(_gray(colored).astype(float)*[1.13,1.,.86],0,255).astype('uint8')
    payload=analyze_pair(source,_write(tmp_path/'sepia.jpg',sepia));assert payload['status']=='ok'
    assert payload['color']['achromatic_evidence']['edited_achromatic_fraction']<.99
    assert dna_from_pair(payload,'Sepia edits')['saturation_scale']>0


def test_gray_reference_set_transfers_monochrome_but_mixed_or_sepia_sets_do_not(tmp_path):
    payloads=[analyze_reference(_write(tmp_path/f'gray-{i}.jpg',_gray(_pixels(i+40)))) for i in range(3)]
    source=_write(tmp_path/'source.jpg',_pixels())
    gray_style=dna_from_batch(_batch(payloads),'Monochrome references')
    assert gray_style['saturation_scale']==0
    rendered=render_preview(source,gray_style)['rendered']
    assert np.ptp(rendered.astype(int),axis=2).max()<=1
    colored=analyze_reference(_write(tmp_path/'colored-reference.jpg',_pixels(78)))
    mixed=dna_from_batch(_batch([*payloads,colored]),'Mixed references')
    assert mixed['saturation_scale']>0
    assert np.ptp(render_preview(source,mixed)['rendered'].astype(int),axis=2).max()>10
    sepia=np.clip(_gray(_pixels()).astype(float)*[1.13,1.,.86],0,255).astype('uint8')
    sepia_style=dna_from_batch(_batch([analyze_reference(_write(tmp_path/'sepia.jpg',sepia))]),'Sepia')
    assert sepia_style['saturation_scale']>0


def test_clipped_or_insufficient_color_evidence_is_not_supported():
    source=np.full((40,50,3),[250,160,120],dtype='uint8')
    edited=np.full_like(source,255)
    assert analyze_color(source,edited,np.ones(source.shape[:2],bool))['achromatic_evidence']['sample_count']==0
    source=_pixels()[:8,:8];edited=_gray(source)
    report=analyze_color(source,edited,np.ones(source.shape[:2],bool))
    assert report['achromatic_evidence']['sample_count']<256


def test_pure_gray_reference_context_can_coexist_with_color_global_style(tmp_path):
    from personal_color_lab.core.style_dna import _appearance_target
    payloads=[]
    for i in range(3):
        item=analyze_reference(_write(tmp_path/f'gray-food-{i}.jpg',_gray(_pixels(i+80))))
        target=_appearance_target(item['appearance'])
        item['semantic']={'status':'ok','bundle_id':'a'*64,'scene_tags':['food'],
                          'region_appearance':{'food':{'target':target,'fraction':.5}}}
        payloads.append(item)
    colored=analyze_reference(_write(tmp_path/'color-portrait.jpg',_pixels()))
    colored['semantic']={'status':'ok','bundle_id':'a'*64,'scene_tags':['people'],'region_appearance':{}}
    style=dna_from_batch(_batch([*payloads,colored]),'Mixed contexts')
    assert style['saturation_scale']==1
    assert 'monochrome_context_food' in style['warnings']
    assert style['semantic_profile']['regions']['food']['saturation_scale']==0
    pixels=_pixels();measurement=_measure(pixels)
    food=_effective(style,measurement,{'bundle_id':'a'*64,'scene_tags':['food']})
    people=_effective(style,measurement,{'bundle_id':'a'*64,'scene_tags':['people']})
    assert food['saturation_scale']==0 and people['saturation_scale']>0
    assert np.ptp(apply_pixels(pixels,food)[0].astype(int),axis=2).max()<=1
    mixed_food=copy.deepcopy(colored);mixed_food['semantic']['scene_tags']=['food']
    mixed_food['semantic']['region_appearance']={'food':{'target':_appearance_target(colored['appearance']),'fraction':.5}}
    mixed=dna_from_batch(_batch([*payloads,mixed_food]),'Mixed food')
    assert 'monochrome_context_food' not in mixed['warnings']
    assert mixed['semantic_profile']['regions']['food']['saturation_scale']>0
    assert _effective(mixed,measurement,{'bundle_id':'a'*64,'scene_tags':['food']})['saturation_scale']>0


def test_observed_region_can_be_monochrome_without_graying_unrelated_pixels():
    pixels=_pixels();edited=pixels.copy();edited[:,:140]=_gray(pixels[:,:140])
    masks={r:np.zeros(pixels.shape[:2],np.float32) for r in REGIONS}
    masks['food'][:,:140]=1;masks['background']=1-masks['food']
    scene={'report':{'bundle_id':'a'*64,'scene_tags':['food']},'masks':masks}
    transforms=regional_transforms(pixels,pixels,edited,scene)
    assert transforms['food']['saturation_scale']==0 and transforms['food']['lab_shift']==[0.,0.]
    evidence={'semantic':{'status':'ok','bundle_id':'a'*64,'region_transforms':transforms,'scene_tags':['food']},
              'provenance':{'input_fingerprints':{'original':'b'*64,'edited':'c'*64}}}
    style=identity_dna();style['semantic_profile']=learn_profile([evidence],'jpg_jpg',None)
    validate_dna(style)
    result=_render_regions(pixels,identity_dna(),style,1.,scene,1.,False,None)
    assert np.ptp(result[:,:130].astype(int),axis=2).max()<=1
    assert np.array_equal(result[:,150:],pixels[:,150:])
