"""Optical geometry participates in RAW display/export and every pixel cache."""
from io import BytesIO
import copy
import threading

import cv2
import numpy as np
from PIL import Image, ImageCms
import pytest

from personal_color_lab.core import alignment, lens_profiles, scene_analysis, semantic_models, style_render
from personal_color_lab.core.edit_reverse import file_fingerprint
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.synthetic_raw import write_test_dng


EQUIPMENT={'camera_make':'Canon','camera_model':'Canon EOS 5D Mark II',
           'lens_make':'Canon','lens_model':'Canon EF 17-40mm f/4L USM',
           'focal_length_mm':17.,'aperture':8.}
OVERRIDE={key:EQUIPMENT[key] for key in ('camera_make','camera_model','lens_make','lens_model','focal_length_mm')}


def _scene(shape):
    masks={key:np.zeros(shape,np.float32) for key in REGIONS}
    masks['food'][:,:shape[1]//2]=1
    masks['background']=1-masks['food']
    return {'report':{'bundle_id':'a'*64,'scene_tags':['food']},'masks':masks}


def _style(kind):
    dna=identity_dna()
    if kind=='reference':
        dna['kind']='reference'
        dna['reference_target']={'quantiles':[.1,.3,.5,.7,.9],'saturation':.25,
                                 'zones':{'midtones':[2.,-3.]}}
    elif kind=='regions':
        dna['semantic_profile']={'bundle_id':'a'*64,'contexts':{},'regions':{'food':{
            'sample_count':1,'evidence':'observed_transform','target':None,
            'tone_curve':np.clip(np.linspace(0,1,33)+.12,0,1).tolist(),
            'saturation_scale':.8,'lab_shift':[1.,-1.]}}}
    return dna


@pytest.fixture(params=[1,6],ids=['landscape','rotated'])
def sensor(tmp_path,request):
    return write_test_dng(tmp_path/'lens.dng',width=1296,height=864,
                          orientation=request.param,equipment=EQUIPMENT)


@pytest.mark.parametrize('kind',['neutral','reference','regions'])
def test_corrected_sensor_export_develops_once_and_matches_precise_preview(sensor,tmp_path,monkeypatch,kind):
    """Real Bayer pixels use an actual published camera/lens calibration."""
    before=file_fingerprint(sensor)
    metadata={}
    preview,dimensions=style_render.read_photo(sensor,lens_correction=True,decode_metadata=metadata)
    full,full_dimensions=style_render.read_photo(sensor,max_dimension=1_000_000,lens_correction=True)
    uncorrected,_=style_render.read_photo(sensor,max_dimension=1_000_000)
    height,width=full.shape[:2]
    factor=min(1.,1200/max(width,height))
    derived=cv2.resize(full,(round(width*factor),round(height*factor)),interpolation=cv2.INTER_AREA)
    assert np.array_equal(preview,derived)
    assert dimensions==full_dimensions==(full.shape[1],full.shape[0])
    assert metadata['lens_correction']['applied']
    assert metadata['lens_correction']['bundle_id']==lens_profiles.lens_bundle_id()
    assert metadata['equipment']['lens_model']==EQUIPMENT['lens_model']
    assert not np.array_equal(full,uncorrected)
    dna=_style(kind);effective,measurement=style_render.prepare_style(preview,dna)
    recognition=kind=='regions'
    if recognition:
        scene=_scene((216,324))
        monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *args:copy.deepcopy(scene))
        effective=style_render._effective(dna,measurement,scene['report'])
        expected=style_render._render_regions(full,effective,dna,.8,scene,.7,True,None,measurement=measurement)
    else:
        expected,_=style_render.apply_pixels(full,effective,.8)
    stream=BytesIO();profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    Image.fromarray(expected).save(stream,format='JPEG',quality=95,subsampling=0,icc_profile=profile)
    with Image.open(BytesIO(stream.getvalue())) as image:
        expected_jpeg=np.array(image)
    calls=[];decode=alignment.decode_raw
    def counted(*args,**kwargs):
        calls.append((args[1],kwargs.get('quality'),kwargs.get('lens_correction',False)))
        return decode(*args,**kwargs)
    monkeypatch.setattr(alignment,'decode_raw',counted)
    output=tmp_path/'styled.jpg'
    result=style_render.export_jpeg(sensor,output,dna,.8,recognition=recognition,lens_correction=True)
    assert calls==[(1_000_000,'baseline',True)]
    assert result['lens_correction_requested'] and result['lens_correction']['applied']
    assert result['equipment']['camera_model']==EQUIPMENT['camera_model']
    assert result['dimensions']==list(dimensions)
    assert result['source_unchanged'] and file_fingerprint(sensor)==before
    with Image.open(output) as image:
        assert np.array_equal(np.array(image),expected_jpeg)
        assert image.info['icc_profile'] and not image.getexif()


def test_preview_cache_includes_optical_mode_quality_and_current_verified_bundle(tmp_path,monkeypatch):
    source=tmp_path/'lens.dng';source.write_bytes(b'unchanged synthetic input')
    state={'bundle':'b'*64};reads=[];scenes=[]
    monkeypatch.setattr(style_render,'_lens_profile_bundle_id',lambda:state['bundle'])
    monkeypatch.setattr(semantic_models,'bundle_id',lambda:'a'*64)
    def read(*args,raw_quality='baseline',decode_metadata=None,lens_correction=False,**kwargs):
        reads.append((lens_correction,raw_quality,state['bundle']))
        level=90+int(lens_correction)*10+int(raw_quality=='interactive')
        if state['bundle']=='c'*64:level+=20
        if state['bundle'] is None:level=90
        decode_metadata.update({'equipment':dict(EQUIPMENT),'lens_correction':{
            'requested':lens_correction,'applied':bool(lens_correction and state['bundle']),
            'status':'database_unavailable' if lens_correction and state['bundle'] is None else 'matched',
            'bundle_id':state['bundle'] if lens_correction else None}})
        return np.full((40,60,3),level,dtype=np.uint8),(600,400)
    def scene(pixels,*args):
        scenes.append(int(pixels[0,0,0]))
        return _scene(pixels.shape[:2])
    monkeypatch.setattr(style_render,'read_photo',read)
    monkeypatch.setattr(scene_analysis,'analyze_scene',scene)
    dna=identity_dna()
    off=style_render.render_preview(source,dna,recognition=True)
    off_same=style_render.render_preview(source,dna,base=off,recognition=True)
    on=style_render.render_preview(source,dna,base=off_same,recognition=True,lens_correction=True)
    on_same=style_render.render_preview(source,dna,base=on,recognition=True,lens_correction=True)
    fast=style_render.render_preview(source,dna,base=on_same,recognition=True,lens_correction=True,raw_quality='interactive')
    state['bundle']='c'*64
    replaced=style_render.render_preview(source,dna,base=fast,recognition=True,lens_correction=True,raw_quality='interactive')
    state['bundle']=None
    fallback=style_render.render_preview(source,dna,base=replaced,recognition=True,lens_correction=True,raw_quality='interactive')
    fallback_again=style_render.render_preview(source,dna,base=fallback,recognition=True,lens_correction=True,raw_quality='interactive')
    state['bundle']='c'*64
    repaired=style_render.render_preview(source,dna,base=fallback_again,recognition=True,lens_correction=True,raw_quality='interactive')
    plain=style_render.render_preview(source,dna,base=repaired,recognition=True)
    assert len(reads)==len(scenes)==8
    assert scenes==[90,100,101,121,90,90,121,110]
    assert on['lens_profile_bundle_id']=='b'*64 and replaced['lens_profile_bundle_id']=='c'*64
    assert fallback['lens_profile_bundle_id'] is None and not fallback['lens_correction']['applied']
    assert repaired['lens_correction']['applied']
    assert not plain['lens_correction_requested']


def test_missing_camera_metadata_can_reuse_only_a_verified_uncorrected_cache(tmp_path,monkeypatch):
    source=tmp_path/'lens.dng';source.write_bytes(b'unchanged synthetic input')
    calls=[];monkeypatch.setattr(style_render,'_lens_profile_bundle_id',lambda:'b'*64)
    def read(*args,decode_metadata=None,**kwargs):
        calls.append(1)
        decode_metadata.update({'equipment':{},'lens_correction':{'requested':True,'applied':False,
                                'status':'metadata_missing','bundle_id':None}})
        return np.full((40,60,3),110,dtype=np.uint8),(600,400)
    monkeypatch.setattr(style_render,'read_photo',read)
    first=style_render.render_preview(source,identity_dna(),lens_correction=True)
    same=style_render.render_preview(source,identity_dna(),base=first,lens_correction=True)
    assert calls==[1] and same['lens_profile_bundle_id']=='b'*64
    assert not same['lens_correction']['applied']


def test_unknown_lens_retains_exact_uncorrected_pixels_and_records_the_skip(tmp_path):
    equipment=dict(EQUIPMENT,lens_model='Synthetic lens with no calibration')
    source=write_test_dng(tmp_path/'unknown.dng',width=1296,height=864,equipment=equipment)
    plain=style_render.render_preview(source,identity_dna())
    requested=style_render.render_preview(source,identity_dna(),base=plain,lens_correction=True)
    assert requested['lens_correction_requested'] and not requested['lens_correction']['applied']
    assert requested['lens_correction']['status']=='lens_not_found'
    assert np.array_equal(plain['original'],requested['original'])
    assert requested['equipment']['lens_model']==equipment['lens_model']


def test_missing_database_drops_corrected_cache_and_recovers_without_photo_changes(sensor,tmp_path,monkeypatch):
    before=file_fingerprint(sensor)
    plain=style_render.render_preview(sensor,identity_dna())
    corrected=style_render.render_preview(sensor,identity_dna(),base=plain,lens_correction=True)
    assert corrected['lens_correction']['applied']
    original_root=lens_profiles.LENS_ROOT
    monkeypatch.setattr(lens_profiles,'LENS_ROOT',tmp_path/'missing-profiles')
    fallback=style_render.render_preview(sensor,identity_dna(),base=corrected,lens_correction=True)
    assert not fallback['lens_correction']['applied']
    assert fallback['lens_correction']['status']=='database_unavailable'
    assert fallback['lens_profile_bundle_id'] is None
    assert np.array_equal(plain['original'],fallback['original'])
    monkeypatch.setattr(lens_profiles,'LENS_ROOT',original_root)
    repaired=style_render.render_preview(sensor,identity_dna(),base=fallback,lens_correction=True)
    assert repaired['lens_correction']['applied']
    assert np.array_equal(corrected['original'],repaired['original'])
    assert file_fingerprint(sensor)==before


def test_manual_selection_and_focal_changes_invalidate_sensor_cache_without_rewriting_metadata(sensor,monkeypatch):
    before=file_fingerprint(sensor);calls=[];decode=alignment.decode_raw
    def counted(*args,**kwargs):
        calls.append(copy.deepcopy(kwargs.get('lens_override')))
        return decode(*args,**kwargs)
    monkeypatch.setattr(alignment,'decode_raw',counted)
    automatic=style_render.render_preview(sensor,identity_dna(),lens_correction=True)
    manual=style_render.render_preview(sensor,identity_dna(),base=automatic,
                                      lens_correction=True,lens_override=OVERRIDE)
    same=style_render.render_preview(sensor,identity_dna(),base=manual,
                                    lens_correction=True,lens_override=dict(reversed(list(OVERRIDE.items()))))
    longer=dict(OVERRIDE,focal_length_mm=40.)
    changed=style_render.render_preview(sensor,identity_dna(),base=same,
                                       lens_correction=True,lens_override=longer)
    reset=style_render.render_preview(sensor,identity_dna(),base=changed,lens_correction=True)
    assert calls==[None,OVERRIDE,longer,None]
    assert np.array_equal(automatic['original'],manual['original'])
    assert not np.array_equal(manual['original'],changed['original'])
    assert np.array_equal(automatic['original'],reset['original'])
    assert changed['lens_override']==longer and reset['lens_override'] is None
    assert changed['equipment']['focal_length_mm']==17.
    assert changed['lens_correction']['profile']['focal_length_mm']==40.
    assert changed['lens_correction']['selection_source']=='manual'
    assert changed['lens_correction']['selected_equipment']==longer
    assert file_fingerprint(sensor)==before


def test_manual_profile_corrects_missing_tags_and_exports_with_original_equipment_preserved(tmp_path,monkeypatch):
    original=dict(EQUIPMENT,lens_model='Synthetic lens with no calibration')
    source=write_test_dng(tmp_path/'manual.dng',width=1296,height=864,equipment=original)
    before=file_fingerprint(source)
    unavailable=style_render.render_preview(source,identity_dna(),lens_correction=True)
    selected=style_render.render_preview(source,identity_dna(),base=unavailable,
                                         lens_correction=True,lens_override=OVERRIDE)
    assert not unavailable['lens_correction']['applied'] and selected['lens_correction']['applied']
    assert selected['equipment']['lens_model']==original['lens_model']
    assert selected['lens_correction']['profile']['lens_model']==OVERRIDE['lens_model']
    assert not np.array_equal(unavailable['original'],selected['original'])
    calls=[];decode=alignment.decode_raw
    def counted(*args,**kwargs):
        calls.append(copy.deepcopy(kwargs))
        return decode(*args,**kwargs)
    monkeypatch.setattr(alignment,'decode_raw',counted)
    exported=style_render.export_jpeg(source,tmp_path/'selected.jpg',identity_dna(),
                                      lens_correction=True,lens_override=OVERRIDE)
    assert len(calls)==1 and calls[0]['quality']=='baseline' and calls[0]['lens_override']==OVERRIDE
    assert exported['lens_correction']['applied'] and exported['lens_override']==OVERRIDE
    assert exported['equipment']['lens_model']==original['lens_model']
    assert exported['lens_correction']['profile']['lens_model']==OVERRIDE['lens_model']
    assert exported['lens_correction']['selection_source']=='manual'
    assert file_fingerprint(source)==before


def test_manual_gm_ii_selection_never_substitutes_the_first_generation_profile(sensor):
    override={'camera_make':'Sony','camera_model':'ILCE-7M3','lens_make':'Sony',
              'lens_model':'FE 70-200mm f/2.8 GM OSS II','focal_length_mm':70.}
    plain=style_render.render_preview(sensor,identity_dna())
    requested=style_render.render_preview(sensor,identity_dna(),base=plain,
                                          lens_correction=True,lens_override=override)
    assert requested['lens_override']==override
    assert not requested['lens_correction']['applied']
    assert requested['lens_correction']['status'] in ('lens_not_found','uncalibrated')
    assert requested['lens_correction']['profile']['lens_model']==override['lens_model']
    assert np.array_equal(plain['original'],requested['original'])


def test_manual_selection_preserves_embedded_correction_guard(tmp_path):
    source=write_test_dng(tmp_path/'embedded.dng',width=1296,height=864,
                          equipment=EQUIPMENT,embedded_geometry=True)
    plain=style_render.render_preview(source,identity_dna())
    requested=style_render.render_preview(source,identity_dna(),base=plain,
                                          lens_correction=True,lens_override=OVERRIDE)
    assert not requested['lens_correction']['applied']
    assert requested['lens_correction']['status']=='embedded_correction'
    assert np.array_equal(plain['original'],requested['original'])


def test_jpeg_ignores_optical_toggle_and_never_consults_profiles(tmp_path,monkeypatch):
    source=tmp_path/'photo.jpg';Image.new('RGB',(60,40),(80,100,120)).save(source)
    monkeypatch.setattr(style_render,'_lens_profile_bundle_id',lambda:pytest.fail('Consulted RAW profiles for JPEG'))
    first=style_render.render_preview(source,identity_dna())
    same=style_render.render_preview(source,identity_dna(),base=first,lens_correction=True)
    assert np.array_equal(first['original'],same['original'])
    assert not same['lens_correction_requested'] and same['lens_correction'] is None and same['equipment'] is None
    plain=tmp_path/'plain.jpg';toggled=tmp_path/'toggled.jpg'
    style_render.export_jpeg(source,plain,identity_dna())
    result=style_render.export_jpeg(source,toggled,identity_dna(),lens_correction=True)
    assert plain.read_bytes()==toggled.read_bytes()
    assert not result['lens_correction_requested'] and result['lens_correction'] is None


@pytest.mark.parametrize('value',[None,0,1,'auto',[]])
def test_invalid_optical_toggle_fails_before_hash_or_decode(tmp_path,monkeypatch,value):
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *a:pytest.fail('Hashed invalid optical choice'))
    monkeypatch.setattr(style_render,'_lens_profile_bundle_id',lambda:pytest.fail('Consulted invalid optical choice'))
    monkeypatch.setattr(style_render,'_read_rgb',lambda *a,**k:pytest.fail('Decoded invalid optical choice'))
    with pytest.raises(ValueError,match='lens correction'):
        style_render.read_photo(tmp_path/'unused.dng',lens_correction=value)
    with pytest.raises(ValueError,match='lens correction'):
        style_render.render_preview(tmp_path/'unused.dng',identity_dna(),lens_correction=value)
    with pytest.raises(ValueError,match='lens correction'):
        style_render.export_jpeg(tmp_path/'unused.dng',tmp_path/'out.jpg',identity_dna(),lens_correction=value)


@pytest.mark.parametrize('override',[False,[],{},dict(OVERRIDE,gps_latitude=37.),dict(OVERRIDE,focal_length_mm=True)])
@pytest.mark.parametrize('enabled',[False,True])
def test_invalid_manual_selection_fails_before_io_even_when_correction_is_disabled(tmp_path,monkeypatch,override,enabled):
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *a:pytest.fail('Hashed invalid manual selection'))
    monkeypatch.setattr(style_render,'_lens_profile_bundle_id',lambda:pytest.fail('Verified invalid manual selection'))
    monkeypatch.setattr(style_render,'_read_rgb',lambda *a,**k:pytest.fail('Decoded invalid manual selection'))
    with pytest.raises(ValueError):
        style_render.read_photo(tmp_path/'unused.dng',lens_correction=enabled,lens_override=override)
    with pytest.raises(ValueError):
        style_render.render_preview(tmp_path/'unused.dng',identity_dna(),lens_correction=enabled,lens_override=override)
    with pytest.raises(ValueError):
        style_render.export_jpeg(tmp_path/'unused.dng',tmp_path/'out.jpg',identity_dna(),
                                 lens_correction=enabled,lens_override=override)


def test_cancelled_optical_requests_never_verify_decode_or_publish(tmp_path,monkeypatch):
    stop=threading.Event();stop.set()
    monkeypatch.setattr(style_render,'_lens_profile_bundle_id',lambda:pytest.fail('Verified a cancelled request'))
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *a:pytest.fail('Hashed a cancelled request'))
    monkeypatch.setattr(style_render,'_read_rgb',lambda *a,**k:pytest.fail('Decoded a cancelled request'))
    with pytest.raises(ValueError,match='cancelled'):
        style_render.render_preview(tmp_path/'unused.dng',identity_dna(),cancel_event=stop,lens_correction=True)
    output=tmp_path/'out.jpg'
    with pytest.raises(ValueError,match='cancelled'):
        style_render.export_jpeg(tmp_path/'unused.dng',output,identity_dna(),cancel_event=stop,lens_correction=True)
    assert not output.exists() and not list(tmp_path.glob('.pcl-export-*.tmp'))
