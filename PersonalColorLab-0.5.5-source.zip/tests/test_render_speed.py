"""Quality and bounded-work contracts for the faster CPU render path."""
import copy
from collections import Counter

import cv2
import numpy as np
import pytest

from personal_color_lab.core import style_render,style_regions
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.style_dna import builtin_styles,identity_dna,blend_styles


def test_accelerated_complex_recipe_retains_v051_rendered_pixels():
    # V0.5.1 output recorded before changing the rendering algorithm. Exercise
    # exposure, tone/RGB curves, HSV/HSL, Lab zones, grain and partial strength.
    dna=identity_dna()
    dna.update(exposure_ev=.6,saturation_scale=.8,vibrance=.2,lab_shift=[1.,2.],grain_amount=.004)
    dna['tone_curve']=np.maximum.accumulate(np.clip(np.linspace(0,1,33)*.92+.035,0,1)).tolist()
    dna['channel_curves']['red']=np.clip(np.linspace(0,1,33)*1.08,0,1).tolist()
    dna['hsl']['red']={'hue':4.,'saturation':-.15,'lightness':.015}
    dna['zone_shifts']['shadows']=[-2.,-3.]
    pixels=np.random.default_rng(721).integers(0,256,(5,6,3),dtype='uint8')
    expected=np.array([
        [[195,247,146],[188,174,252],[209,120,161],[74,133,182],[246,136,242],[91,69,196]],
        [[63,131,200],[250,64,248],[111,90,156],[178,139,49],[57,251,163],[212,251,134]],
        [[181,198,39],[238,71,154],[200,222,212],[128,167,69],[204,63,241],[233,163,41]],
        [[117,66,56],[164,253,71],[129,183,28],[252,167,142],[112,242,243],[47,147,251]],
        [[193,231,249],[231,230,184],[134,178,109],[94,250,168],[176,223,39],[205,217,149]]],dtype='uint8')
    result=style_render.apply_pixels(pixels,dna,.7)[0]
    # Different native SIMD implementations may round a channel by one level.
    assert np.abs(result.astype(np.int16)-expected).max()<=1


def test_unused_rgb_curves_and_hsv_conversion_are_skipped(monkeypatch):
    pixels=np.random.default_rng(81).integers(20,235,(80,120,3),dtype='uint8')
    style=identity_dna();style['lab_shift']=[2.,3.]
    calls=[];convert=cv2.cvtColor
    monkeypatch.setattr(cv2,'cvtColor',lambda image,code,*args,**kwargs:(calls.append(code),convert(image,code,*args,**kwargs))[1])
    monkeypatch.setattr(np,'interp',lambda *args,**kwargs:pytest.fail('Interpolated an unchanged tone/channel curve'))
    output=style_render.apply_pixels(pixels,style,.8)[0]
    assert calls==[cv2.COLOR_RGB2LAB,cv2.COLOR_LAB2RGB]
    assert np.any(output!=pixels)


def test_identity_tone_still_maps_positive_exposure_clipping():
    pixels=np.array([[[240,120,60],[120,240,60],[30,60,240]]],dtype='uint8')
    style=identity_dna();style['exposure_ev']=2.
    output=style_render.apply_pixels(pixels,style)[0]
    expected=np.array([[[255,218,114],[155,255,81],[64,118,255]]],dtype='uint8')
    assert np.abs(output.astype(np.int16)-expected).max()<=1


def test_grain_only_does_not_mutate_original_or_partial_strength():
    pixels=np.random.default_rng(91).integers(20,235,(81,129,3),dtype='uint8');before=pixels.copy()
    style=identity_dna();style['grain_amount']=.03
    complete=style_render.apply_pixels(pixels,style,1.)[0]
    partial=style_render.apply_pixels(pixels,style,.4)[0]
    expected=np.rint(before.astype(float)+(complete.astype(float)-before)*.4)
    assert np.array_equal(pixels,before)
    assert np.any(complete!=before)
    assert np.abs(partial.astype(float)-expected).max()<=1


def _regional_fixture(hybrid):
    styles=[copy.deepcopy(builtin_styles()[0]),copy.deepcopy(builtin_styles()[4])]
    for style in styles:
        style['semantic_profile']['bundle_id']='a'*64
        for region in ['background','person','food']:
            style['semantic_profile']['regions'][region]={'sample_count':1,'evidence':'observed_transform','target':None,
                'tone_curve':np.clip(np.linspace(0,1,33)+.06,0,1).tolist(),'saturation_scale':.85,'lab_shift':[2.,-1.]}
    style=blend_styles(styles,[.6,.4]) if hybrid else styles[0]
    masks={region:np.zeros((80,120),np.float32) for region in REGIONS}
    masks['background'][:,:40]=1;masks['person'][:,40:80]=1;masks['food'][:,80:]=1
    scene={'report':{'bundle_id':'a'*64,'scene_tags':['people','food']},'masks':masks}
    pixels=np.random.default_rng(17).integers(20,230,(820,400,3),dtype='uint8')
    return pixels,style,scene


@pytest.mark.parametrize('hybrid',[False,True])
def test_component_baselines_render_once_per_bounded_tile(monkeypatch,hybrid):
    pixels,style,scene=_regional_fixture(hybrid)
    effective,measurement=style_render.prepare_style(pixels,style)
    tile=style_render._tile;calls=[]
    def track(source,recipe,strength,row_offset,plan=None):
        calls.append((id(recipe),source.shape[0]*source.shape[1],bool(recipe['semantic_profile']['regions'])))
        return tile(source,recipe,strength,row_offset,plan)
    monkeypatch.setattr(style_render,'_tile',track)
    result=style_render._render_regions(pixels,effective,style,.8,scene,.7,False,None,measurement=measurement)
    assert result.shape==pixels.shape and np.any(result!=pixels)
    assert max(size for _,size,_ in calls)<=160_000
    baselines=Counter(key for key,_,baseline in calls if baseline)
    expected_tiles=3
    assert len(baselines)==(3 if hybrid else 1)
    assert set(baselines.values())=={expected_tiles}


def test_reused_mask_coordinates_preserve_exact_interpolation():
    mask=np.random.default_rng(19).uniform(0,1,(13,21)).astype(np.float32)
    for top,rows in [(0,9),(9,17),(26,11)]:
        coordinates=style_regions.mask_tile_coordinates(mask.shape,57,37,top,rows)
        direct=style_regions.resized_mask_tile(mask,57,37,top,rows)
        reused=style_regions.resized_mask_tile(mask,57,37,top,rows,coordinates)
        assert np.array_equal(direct,reused)
        assert coordinates[0].shape==(rows,57)


def test_face_hue_protection_converts_only_supported_rectangle(monkeypatch):
    original=np.full((100,200,3),[170,110,80],dtype='uint8')
    styled=np.full_like(original,[150,100,140]);before=styled.copy()
    mask=np.zeros((100,200),np.float32);mask[32:42,71:86]=1
    shapes=[];convert=cv2.cvtColor
    def track(image,code,*args,**kwargs):
        shapes.append(image.shape[:2]);return convert(image,code,*args,**kwargs)
    monkeypatch.setattr(cv2,'cvtColor',track)
    protected=style_regions.protect_face_colors(original,styled,mask)
    assert shapes==[(10,15)]*3
    assert np.array_equal(protected[mask==0],before[mask==0])
    assert np.any(protected[mask>0]!=before[mask>0])
    assert np.array_equal(styled,before)
