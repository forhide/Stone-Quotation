"""Persisted scene review and support cannot contradict successful analyses."""
import copy
from PIL import Image
import pytest
from personal_color_lab.core.database import LibraryDB,AnalysisValidationError
from personal_color_lab.core.source_workflow import discover_inputs,analyze_inputs,set_scene_override

@pytest.mark.parametrize('corruption',['mode','labels','hash','coverage','coverage_bool','coverage_extra','privacy'])
def test_scene_snapshot_rejects_inconsistent_or_private_evidence(tmp_path,corruption):
    folder=tmp_path/'photos';folder.mkdir();Image.new('RGB',(100,70),'orange').save(folder/'one.jpg')
    items=discover_inputs(folder,'reference_jpg')['items'];items[0]['scene_override']=['night','food']
    batch=analyze_inputs(items,'reference_jpg');assert batch['status']=='ok'
    with LibraryDB(tmp_path/'data.db') as db:
        saved=db.save_source_profile('Reviewed',batch)
        assert db.get_source_profile(saved)['payload']==batch
        bad=copy.deepcopy(batch);row=bad['results'][0]
        if corruption=='mode':row['item']['scene_override']=None
        elif corruption=='labels':row['item']['scene_override']=['day','food']
        elif corruption=='hash':row['item']['scene_original_fingerprint']='a'*64
        elif corruption=='coverage':bad['summary']['scene_stats']['sample_count']+=1
        elif corruption=='coverage_bool':bad['summary']['scene_stats']['sample_count']=True
        elif corruption=='coverage_extra':bad['summary']['scene_stats']['unverified']=1
        else:row['payload']['photo_scene']['evidence']={'latitude':37.}
        with pytest.raises(AnalysisValidationError):db.save_source_profile('Bad',bad)
        assert db.list_source_profiles()[0]['name']=='Reviewed'
        automatic=set_scene_override(batch,items[0]['id'],None)
        second=db.save_source_profile('Automatic',automatic)
        assert db.get_source_profile(second)['payload']['results'][0]['payload']['photo_scene']['source']=='automatic'
