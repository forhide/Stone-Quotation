"""Real scene review, snapshot edits and persistence through every input route."""
import hashlib
import os
from pathlib import Path
import time

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.constants import DB_FILENAME
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.ui.app import App
from personal_color_lab.ui.source_workflow import SourceWorkflow
from personal_color_lab.ui.scene_editor import scene_report_lines

pytestmark = pytest.mark.skipif(os.name != 'nt' and not os.environ.get('DISPLAY'),
                                reason='Requires a desktop display or the Xvfb test runner')


def _pump(app, ready, seconds=30):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        app.update()
        if ready():
            app.update_idletasks()
            return
        time.sleep(.01)
    raise AssertionError('Scene review did not finish')


@pytest.fixture
def desktop(tmp_path, monkeypatch):
    monkeypatch.setenv('PERSONAL_COLOR_LAB_DATA_DIR', str(tmp_path / 'data'))
    from personal_color_lab.core import photo_scene
    def unavailable(pixels, **kwargs):
        return photo_scene.unknown_photo_scene('classification_unavailable',
                                               evidence_source=kwargs.get('evidence_source', 'reference_jpg'))
    # Source measurements, RAW decoding, aggregation and DB validation stay
    # real. Only classifier availability is controlled to verify that manual
    # review remains useful when the recognition bundle is unavailable.
    monkeypatch.setattr(photo_scene, 'classify_photo', unavailable)
    app = App()
    callbacks = []
    app.report_callback_exception = lambda kind, value, tb: callbacks.append((kind, str(value)))
    yield app, tmp_path
    if not app._closed:
        app.close()
    assert not callbacks, callbacks


def _inputs(folder, mode):
    folder.mkdir()
    if mode == 'reference_jpg':
        y, x = np.indices((160, 240))
        pixels = np.stack((65 + x // 3, 60 + y // 3, 40 + x // 5), axis=2).astype('uint8')
        Image.fromarray(pixels).save(folder / 'photo.jpg', quality=95)
    else:
        path = write_test_dng(folder / 'photo.dng')
        if mode == 'raw_jpg':
            pixels, _, _ = decode_raw(path)
            pixels = np.clip(pixels.astype(float) * 1.07 + [4, 1, -2], 0, 255).astype('uint8')
            Image.fromarray(pixels).save(folder / 'photo.jpg', quality=98, subsampling=0)
        else:
            (folder / 'photo.xmp').write_text(
                '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
                'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
                'crs:Exposure2012="0.5" crs:Contrast2012="12" />')
    return folder


def _open(app, folder, mode):
    window = SourceWorkflow(app, folder, mode=mode)
    app._source_workflows.append(window)
    _pump(app, lambda: not window._busy)
    return window


def _select(dialog, i18n, *, time_label=None, environment=None, subjects=()):
    dialog.time_selection.set(i18n.t('scene_label_' + time_label) if time_label else i18n.t('scene_unspecified'))
    dialog.environment_selection.set(i18n.t('scene_label_' + environment) if environment else i18n.t('scene_unspecified'))
    for label, var in dialog._vars.items():
        var.set(label in subjects)


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
@pytest.mark.parametrize('language', ['en', 'ko'])
def test_scene_review_all_routes_edit_saved_snapshot_and_restore_auto(desktop, monkeypatch, mode, language):
    app, tmp_path = desktop
    app.lang.set(language)
    app.change_language()
    folder = _inputs(tmp_path / 'photos', mode)
    before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()}
    window = _open(app, folder, mode)
    assert str(window.review_scene_btn.cget('state')) == 'disabled'
    window.review_tree.selection_set('0')
    window._review_selected()
    window.review_scene_btn.invoke()
    dialog = window._scene_dialog
    assert dialog is not None
    _select(dialog, app.i18n, time_label='night', environment='outdoor', subjects=('portrait', 'food'))
    dialog.apply_button.invoke()
    assert window._scene_dialog is None
    assert set(window._items['0']['scene_override']) == {'night', 'outdoor', 'portrait', 'food'}
    assert app.i18n.t('scene_label_night') in window.review_tree.set('0', 'scene')
    window.start_analysis()
    _pump(app, lambda: not window._busy)
    batch = window.batch
    assert batch['status'] == 'ok', batch
    report = batch['results'][0]['payload']['photo_scene']
    assert report['source'] == 'manual'
    assert set(report['labels']) == {'night', 'outdoor', 'portrait', 'food'}
    assert report['automatic_labels'] == []
    text = window.details.get('1.0', 'end')
    assert app.i18n.t('scene_coverage_heading') in text
    assert app.i18n.t('scene_support_low') in text
    window.style_name.set('Scene review ' + mode)
    window.save_profile()
    assert window._status_key == 'source_saved', window.status.get()
    with LibraryDB(tmp_path / 'data' / DB_FILENAME) as db:
        saved = db.list_source_profiles()[0]
        saved_payload = db.get_source_profile(saved['id'])['payload']
    window.close()
    app.open_saved_styles()
    reopened = app._source_workflows[-1]
    reopened.profiles_tree.selection_set(str(saved['id']))
    reopened.open_profile()
    assert reopened.batch == saved_payload
    reopened.result_tree.selection_set('result-0')
    reopened._result_selected()
    assert str(reopened.result_scene_btn.cget('state')) == 'normal'
    def no_reanalysis(*args, **kwargs):
        raise AssertionError('Scene correction must reuse saved measurements')
    monkeypatch.setattr('personal_color_lab.ui.source_workflow.analyze_inputs', no_reanalysis)
    reopened.result_scene_btn.invoke()
    dialog = reopened._scene_dialog
    _select(dialog, app.i18n, time_label='day', environment='indoor', subjects=('still_life',))
    dialog.apply_button.invoke()
    updated = reopened.batch
    assert updated is not saved_payload
    assert set(updated['results'][0]['payload']['photo_scene']['labels']) == {'day', 'indoor', 'still_life'}
    assert set(saved_payload['results'][0]['payload']['photo_scene']['labels']) == {'night', 'outdoor', 'portrait', 'food'}
    assert 'night' not in updated['summary']['scene_stats']['categories']
    assert reopened._status_key == 'scene_result_updated'
    reopened.save_profile()
    with LibraryDB(tmp_path / 'data' / DB_FILENAME) as db:
        persisted = next(row for row in db.list_source_profiles() if row['name'] == 'Scene review ' + mode)
        assert db.get_source_profile(persisted['id'])['payload'] == updated
    reopened.result_scene_btn.invoke()
    reopened._scene_dialog.auto_button.invoke()
    auto_report = reopened.batch['results'][0]['payload']['photo_scene']
    assert auto_report['source'] == 'automatic'
    assert auto_report['labels'] == []
    assert reopened.batch['results'][0]['item']['scene_override'] is None
    assert reopened.batch['summary']['scene_stats']['unclassified_count'] == 1
    assert before == {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()}


def test_scene_editor_empty_manual_assignment_and_locale_change_preserve_selection(desktop):
    app, tmp_path = desktop
    window = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'), 'reference_jpg')
    window.review_tree.selection_set('0')
    window.edit_review_scene()
    dialog = window._scene_dialog
    _select(dialog, app.i18n, time_label='blue_hour', environment='outdoor', subjects=('portrait', 'architecture'))
    app.lang.set('ko')
    app.change_language()
    assert dialog.time_selection.get() == app.i18n.t('scene_label_blue_hour')
    assert dialog.environment_selection.get() == app.i18n.t('scene_label_outdoor')
    assert set(dialog.selected_labels()) == {'blue_hour', 'outdoor', 'portrait', 'architecture'}
    _select(dialog, app.i18n)
    dialog.apply_selection()
    assert window._items['0']['scene_override'] == []
    assert app.i18n.t('scene_label_unknown') in window.review_tree.set('0', 'scene')
    window.edit_review_scene()
    window._scene_dialog.use_automatic()
    assert window._items['0']['scene_override'] is None
    assert window.review_tree.set('0', 'scene') == app.i18n.t('scene_automatic_pending')


def test_prediction_scores_are_explicitly_estimates_and_kept_after_manual_review(desktop):
    app, _ = desktop
    report = {'source': 'manual', 'labels': ['night', 'portrait'],
              'automatic_labels': ['day', 'portrait'], 'scores': {'day': .79, 'portrait': .83}}
    rendered = '\n'.join(scene_report_lines(app.i18n, report))
    assert app.i18n.t('scene_manual_notice') in rendered
    assert app.i18n.t('scene_prediction_item', label=app.i18n.t('scene_label_day'), score=79) in rendered
    assert 'not calibrated probabilities' in rendered


def test_conflicting_scene_assignments_are_visible_and_one_review_updates_all_edits(desktop):
    app, tmp_path = desktop
    folder = tmp_path / 'shared-raw'
    first = folder / 'first'
    second = folder / 'second'
    first.mkdir(parents=True)
    second.mkdir()
    raw = write_test_dng(first / 'photo.dng')
    (second / 'photo.dng').write_bytes(raw.read_bytes())
    for parent, exposure in ((first, '.5'), (second, '.8')):
        (parent / 'photo.xmp').write_text(
            '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
            'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
            f'crs:Exposure2012="{exposure}" />')
    window = _open(app, folder, 'raw_xmp')
    assert len(window._included) == 2
    for row, time_label in (('0', 'day'), ('1', 'night')):
        window.review_tree.selection_set(row)
        window.edit_review_scene()
        _select(window._scene_dialog, app.i18n, time_label=time_label, subjects=('portrait',))
        window._scene_dialog.apply_selection()
    window.start_analysis()
    _pump(app, lambda: not window._busy)
    original = window.batch
    assert original['counts']['successful'] == 2
    assert app.i18n.t('scene_conflict_help') in window.details.get('1.0', 'end')
    for row in ('result-0', 'result-1'):
        assert window.result_tree.set(row, 'state') == app.i18n.t('scene_conflict_state')
    assert all(item['scene_override'] == [] for item in window._items.values())
    window.result_tree.selection_set('result-1')
    window._result_selected()
    window.edit_result_scene()
    _select(window._scene_dialog, app.i18n, time_label='night', subjects=('portrait',))
    window._scene_dialog.apply_selection()
    assert all(set(result['payload']['photo_scene']['labels']) == {'night', 'portrait'}
               for result in window.batch['results'])
    assert all(set(item['scene_override']) == {'night', 'portrait'} for item in window._items.values())
    assert all('scene_status' not in result['item'] for result in window.batch['results'])
    assert all(result['item']['scene_status'] == 'needs_scene_review' for result in original['results'])
    assert window.batch['summary']['scene_stats']['sample_count'] == 1
    window.result_tree.selection_set('summary')
    window._result_selected()
    assert app.i18n.t('scene_edit_evidence_conflict') in window.details.get('1.0', 'end')
    assert app.i18n.t('scene_support_filtered_line', label=app.i18n.t('scene_label_night'), count=1, eligible=0,
                      support=app.i18n.t('scene_support_low')) in window.details.get('1.0', 'end')


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_scene_editor_actions_fit_small_window_and_subjects_remain_scrollable(desktop, language):
    app, tmp_path = desktop
    app.lang.set(language)
    app.change_language()
    window = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'), 'reference_jpg')
    window.review_tree.selection_set('0')
    window.edit_review_scene()
    dialog = window._scene_dialog
    width, height = dialog.minsize()
    dialog.geometry(f'{width}x{height}')
    app.update()
    for widget in (dialog.auto_button, dialog.apply_button, dialog.time_combo, dialog.environment_combo):
        x = widget.winfo_rootx() - dialog.winfo_rootx()
        y = widget.winfo_rooty() - dialog.winfo_rooty()
        assert widget.winfo_ismapped()
        assert 0 <= x <= dialog.winfo_width() - widget.winfo_width()
        assert 0 <= y <= dialog.winfo_height() - widget.winfo_height()
    dialog._body_canvas.yview_moveto(1.)
    app.update()
    last = dialog._subject_buttons['strong_highlights']
    assert last.winfo_rooty() >= dialog._body_canvas.winfo_rooty()
    assert last.winfo_rooty() + last.winfo_height() <= dialog._body_canvas.winfo_rooty() + dialog._body_canvas.winfo_height()
    last.invoke()
    assert 'strong_highlights' in dialog.selected_labels()
    window.close()
    app.update()
    assert dialog._closed and dialog.time_selection is None and dialog.environment_selection is None
    assert dialog._body_canvas is None and dialog._vars == {}
