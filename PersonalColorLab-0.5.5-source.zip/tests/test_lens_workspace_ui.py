"""Real Tk equipment selection and non-destructive RAW optical correction."""
import gc
import hashlib
import threading
import tkinter as tk
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image
import pytest

from test_source_workflow_ui import desktop, _pump, pytestmark
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.synthetic_raw import write_test_dng


SONY = {'camera_make': 'Sony', 'camera_model': 'ILCE-7CR', 'lens_make': 'Sony',
        'lens_model': 'FE 16-35mm F2.8 GM II', 'focal_length_mm': 16., 'aperture': 2.8}
CANON_CAMERA = 'Canon EOS 5D Mark II'
CANON_LENS = 'Canon EF 17-40mm f/4L USM'


def ready(window):
    return (window.preview is not None and not window._busy and window._debounce is None
            and window._preview_generation == window._generation)


def open_raw(app, root, monkeypatch):
    source = write_test_dng(root / 'sony.dng', width=960, height=640, equipment=SONY)
    window = app.open_style_workspace(initial_dna=identity_dna())
    window.recognition.set(False)
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',
                        lambda **kwargs: str(source))
    window.choose_btn.invoke()
    _pump(app, lambda: ready(window))
    return window, source


def select_canon(app, window, focal):
    window.lens_manual_btn.invoke()
    dialog = window._lens_dialog
    dialog.camera.set(CANON_CAMERA)
    dialog.camera_combo.event_generate('<<ComboboxSelected>>')
    app.update()
    assert CANON_LENS in dialog._lens_items
    dialog.lens.set(CANON_LENS)
    dialog.lens_combo.event_generate('<<ComboboxSelected>>')
    dialog.focal.set(str(focal))
    app.update()
    assert str(dialog.apply_button.cget('state')) == 'normal'
    dialog.apply_button.invoke()
    assert dialog._closed and window._lens_dialog is None
    _pump(app, lambda: ready(window))
    return window.preview


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_exact_sony_equipment_is_shown_without_first_generation_substitution(desktop, monkeypatch, language):
    app, root = desktop
    app.lang.set(language); app.change_language()
    window, source = open_raw(app, root, monkeypatch)
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    assert window.lens_correction.get() and window.preview['lens_correction_requested']
    assert window.preview['equipment']['camera_model'] == SONY['camera_model']
    assert window.preview['equipment']['lens_model'] == SONY['lens_model']
    assert window.preview['lens_correction']['selected_equipment']['lens_model'] == SONY['lens_model']
    assert not window.preview['lens_correction']['applied']
    assert window.preview['lens_correction']['status'] == 'lens_not_found'
    assert SONY['camera_model'] in window.lens_info.cget('text')
    assert SONY['lens_model'] in window.lens_info.cget('text')
    assert app.i18n.t('lens_profile_missing') in window.lens_info.cget('text')
    assert window.lens_toggle.winfo_ismapped() and window.lens_manual_btn.winfo_ismapped()
    assert window.xmp_notice.cget('text') == app.i18n.t('style_lens_xmp_notice')
    window.lens_manual_btn.invoke()
    dialog = window._lens_dialog
    assert dialog.camera.get() == 'Sony ILCE-7CR'
    assert dialog._lens_items[dialog.lens.get()]['lens_model'].endswith('GM II')
    assert not dialog._lens_items[dialog.lens.get()]['calibrated']
    assert dialog.message.get() == app.i18n.t('lens_profile_missing')
    dialog.apply_button.invoke(); _pump(app, lambda: ready(window))
    assert dialog._closed and window.preview['lens_override']['lens_model'].endswith('GM II')
    assert not window.preview['lens_correction']['applied']
    assert window.preview['lens_correction']['status'] == 'lens_not_found'
    assert window.preview['equipment']['lens_model'] == SONY['lens_model']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before


def test_same_photo_manual_focal_changes_geometry_preserves_detected_equipment_and_cache(desktop, monkeypatch):
    app, root = desktop
    window, source = open_raw(app, root, monkeypatch)
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    automatic = window.preview
    wide = select_canon(app, window, 17)
    tele = select_canon(app, window, 40)
    assert wide['lens_correction']['applied'] and tele['lens_correction']['applied']
    assert wide['lens_correction']['selection_source'] == tele['lens_correction']['selection_source'] == 'manual'
    assert wide['lens_correction']['selected_equipment']['focal_length_mm'] == 17
    assert tele['lens_correction']['selected_equipment']['focal_length_mm'] == 40
    assert wide['equipment'] == tele['equipment'] == automatic['equipment']
    assert wide['equipment']['lens_model'] == SONY['lens_model']
    assert not np.array_equal(wide['original'], automatic['original'])
    assert not np.array_equal(tele['original'], wide['original'])
    assert wide['style_tiles'] is not automatic['style_tiles']
    assert tele['style_tiles'] is not wide['style_tiles']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before


def test_dialog_search_selection_and_automatic_reset_restore_original_pixels(desktop, monkeypatch):
    app, root = desktop
    window, _ = open_raw(app, root, monkeypatch)
    automatic = window.preview
    window.lens_manual_btn.invoke()
    dialog = window._lens_dialog
    dialog.camera_combo.focus_force(); app.update()
    dialog.camera.set('5D Mark II')
    dialog.camera_combo.event_generate('<KeyRelease>', keysym='I'); app.update()
    assert 'Canon EOS 5D Mark II' in dialog.camera_combo.cget('values')
    assert str(dialog.apply_button.cget('state')) == 'disabled'
    dialog.camera.set(CANON_CAMERA)
    dialog.camera_combo.event_generate('<<ComboboxSelected>>'); app.update()
    dialog.lens_combo.focus_force(); app.update()
    dialog.lens.set('17-40')
    dialog.lens_combo.event_generate('<KeyRelease>', keysym='0'); app.update()
    assert CANON_LENS in dialog.lens_combo.cget('values')
    dialog.lens.set(CANON_LENS)
    dialog.lens_combo.event_generate('<<ComboboxSelected>>'); app.update()
    dialog.focal.set('17'); dialog.apply_button.invoke(); _pump(app, lambda: ready(window))
    assert window.preview['lens_correction']['applied']
    window.lens_manual_btn.invoke(); dialog = window._lens_dialog
    dialog.use_automatic(); _pump(app, lambda: ready(window))
    assert window._lens_override is None and window.preview['lens_override'] is None
    assert window.preview['lens_correction']['selection_source'] == 'automatic'
    assert not window.preview['lens_correction']['applied']
    assert np.array_equal(window.preview['original'], automatic['original'])


@pytest.mark.parametrize('focal', ['nan', '0', '2001', 'not a number'])
def test_invalid_manual_focal_keeps_dialog_open_without_changing_preview(desktop, monkeypatch, focal):
    app, root = desktop
    window, _ = open_raw(app, root, monkeypatch)
    previous = window.preview
    window.lens_manual_btn.invoke(); dialog = window._lens_dialog
    dialog.camera.set(CANON_CAMERA); dialog.camera_combo.event_generate('<<ComboboxSelected>>'); app.update()
    dialog.lens.set(CANON_LENS); dialog.lens_combo.event_generate('<<ComboboxSelected>>'); app.update()
    dialog.focal.set(focal); dialog.apply_button.invoke()
    assert not dialog._closed and window.preview is previous and window._lens_override is None
    assert dialog.message.get() == app.i18n.t('lens_invalid_selection')
    dialog.close()


@pytest.mark.parametrize('replacement', ['raw', 'jpeg'])
def test_new_photo_clears_photo_specific_override_and_closes_selection_dialog(desktop, monkeypatch, replacement):
    app, root = desktop
    window, _ = open_raw(app, root, monkeypatch)
    select_canon(app, window, 17)
    if replacement == 'raw':
        path = write_test_dng(root / 'second.dng', width=960, height=640, equipment=SONY, seed=81)
    else:
        path = root / 'second.jpg'; Image.new('RGB', (240, 160), 'orange').save(path)
    window.lens_manual_btn.invoke(); dialog = window._lens_dialog
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename', lambda **kwargs: str(path))
    window.choose_btn.invoke()
    assert dialog._closed and window._lens_dialog is None and window._lens_override is None
    _pump(app, lambda: ready(window))
    assert window.preview['lens_override'] is None
    if replacement == 'raw':
        assert not window.preview['lens_correction']['applied']
    else:
        assert not window.preview['lens_correction_requested'] and window.preview['equipment'] is None
        assert not window.lens_toggle.winfo_ismapped() and not window.lens_manual_btn.winfo_ismapped()


def test_locale_switch_updates_lens_notice_without_redecoding(desktop, monkeypatch):
    app, root = desktop
    window, _ = open_raw(app, root, monkeypatch)
    preview = select_canon(app, window, 17)
    generation = window._generation
    app.lang.set('ko'); app.change_language(); app.update()
    assert window.preview is preview and window._generation == generation and window._debounce is None
    assert app.i18n.t('lens_manual_mode') in window.lens_info.cget('text')
    assert app.i18n.t('lens_applied', zoom=round((preview['lens_correction']['crop_scale']-1)*100, 1)) in window.lens_info.cget('text')
    assert window.xmp_notice.cget('text') == app.i18n.t('style_lens_xmp_notice')


@pytest.mark.parametrize('kind', ['jpeg', 'xmp'])
def test_export_locks_optical_controls_and_keeps_manual_selection(desktop, monkeypatch, kind):
    from personal_color_lab.ui import style_workspace as module
    app, root = desktop
    window, source = open_raw(app, root, monkeypatch)
    preview = select_canon(app, window, 17)
    destination = root / ('corrected.jpg' if kind == 'jpeg' else 'global.xmp')
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    operation = module.export_jpeg if kind == 'jpeg' else module.export_xmp
    started, release = threading.Event(), threading.Event()
    seen = []
    def held(*args, **kwargs):
        seen.append(kwargs); started.set(); assert release.wait(10)
        return operation(*args, **kwargs)
    monkeypatch.setattr(module, 'export_jpeg' if kind == 'jpeg' else 'export_xmp', held)
    monkeypatch.setattr(module.filedialog, 'asksaveasfilename', lambda **kwargs: str(destination))
    try:
        (window.jpeg_btn if kind == 'jpeg' else window.xmp_btn).invoke()
        _pump(app, started.is_set)
        assert str(window.lens_toggle.cget('state')) == 'disabled'
        assert str(window.lens_manual_btn.cget('state')) == 'disabled'
        selection = dict(window._lens_override)
        window._redraw_images(); app.lang.set('ko'); app.change_language(); app.update()
        window.choose_lens_equipment()
        assert window._lens_dialog is None and window._lens_override == selection
    finally:
        release.set()
    _pump(app, lambda: not window._busy)
    assert destination.is_file() and window.preview is preview
    assert str(window.lens_toggle.cget('state')) == 'normal'
    assert str(window.lens_manual_btn.cget('state')) == 'normal'
    if kind == 'jpeg':
        assert seen[0]['lens_correction'] and seen[0]['lens_override'] == selection
        with Image.open(destination) as result:
            assert result.size == (960, 640) and not result.getexif()
    else:
        xml = ET.parse(destination)
        attributes = next(node.attrib for node in xml.iter() if node.tag.endswith('Description'))
        assert not any('LensProfile' in name or 'Distortion' in name for name in attributes)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before


def test_worker_lens_requests_are_plain_data_and_close_clears_dialog_owners(desktop, monkeypatch):
    from personal_color_lab.ui import style_workspace as module
    app, root = desktop
    window, _ = open_raw(app, root, monkeypatch)
    select_canon(app, window, 17)
    job = module._job
    started, release = threading.Event(), threading.Event()
    requests = []
    def plain(value):
        assert not isinstance(value, (tk.Variable, tk.Misc))
        if isinstance(value, dict):
            for child in value.values(): plain(child)
        elif isinstance(value, (tuple, list)):
            for child in value: plain(child)
    def held(events, generation, kind, request, cancel_event):
        plain(request); requests.append(request)
        started.set(); assert release.wait(10)
        return job(events, generation, kind, request, cancel_event)
    monkeypatch.setattr(module, '_job', held)
    window._schedule_preview(); _pump(app, started.is_set)
    window.lens_manual_btn.invoke(); dialog = window._lens_dialog
    assert dialog is not None
    threads = list(window._threads)
    try:
        window.close()
        assert dialog._closed and dialog.on_apply is None and dialog.parent_workspace is None
        assert dialog.camera is None and dialog.lens is None and dialog.focal is None
        assert window.lens_correction is None and window._lens_override is None
    finally:
        release.set()
    for thread in threads:
        thread.join(10); assert not thread.is_alive()
    gc.collect(); app.update()
    assert requests[0]['lens_correction'] is True
    assert requests[0]['lens_override']['focal_length_mm'] == 17
    assert not app._closed
