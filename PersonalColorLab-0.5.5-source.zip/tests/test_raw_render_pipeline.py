"""RAW export develops one sensor baseline without changing adaptive output."""
from io import BytesIO
import copy
import threading

import cv2
import numpy as np
from PIL import Image, ImageCms
import pytest

from personal_color_lab.core import alignment, scene_analysis, semantic_models, style_render
from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.edit_reverse import file_fingerprint
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.style_dna import builtin_styles, identity_dna
from personal_color_lab.core.synthetic_raw import write_test_dng


@pytest.fixture(params=[1,6],ids=['landscape','rotated'])
def sensor(tmp_path,request):
    return write_test_dng(tmp_path/'sensor.dng',width=1280,height=864,orientation=request.param)


def _style(kind):
    if kind=='crop':
        return builtin_styles()[4]
    dna=identity_dna()
    if kind=='reference':
        dna['kind']='reference'
        dna['reference_target']={'quantiles':[.1,.3,.5,.7,.9],'saturation':.25,
                                 'zones':{'midtones':[2.,-3.]}}
    elif kind=='monochrome':
        dna['saturation_scale']=0.
    elif kind=='regions':
        dna['semantic_profile']={'bundle_id':'a'*64,'contexts':{},'regions':{'food':{
            'sample_count':1,'evidence':'observed_transform','target':None,
            'tone_curve':np.clip(np.linspace(0,1,33)+.12,0,1).tolist(),
            'saturation_scale':.8,'lab_shift':[1.,-1.]}}}
    return dna


def _scene(shape):
    masks={key:np.zeros(shape,np.float32) for key in REGIONS}
    masks['food'][:,:shape[1]//2]=1
    masks['background']=1-masks['food']
    return {'report':{'bundle_id':'a'*64,'scene_tags':['food']},'masks':masks}


@pytest.mark.parametrize('kind',['neutral','reference','monochrome','crop','regions'])
def test_single_sensor_export_matches_the_two_decode_baseline(sensor,tmp_path,monkeypatch,kind):
    # These are real LibRaw reads of a generated Bayer sensor, including EXIF
    # orientation. The old pipeline independently developed these two sizes.
    preview,_=style_render.read_photo(sensor)
    full,dimensions=style_render.read_photo(sensor,max_dimension=1_000_000)
    height,width=full.shape[:2]
    factor=min(1.,1200/max(width,height))
    derived=cv2.resize(full,(round(width*factor),round(height*factor)),interpolation=cv2.INTER_AREA)
    assert np.array_equal(derived,preview)
    dna=_style(kind);composition='apply_crop' if kind=='crop' else 'color_only'
    effective,measurement=style_render.prepare_style(preview,dna)
    recognition=kind=='regions'
    if recognition:
        scene=_scene((216,320))
        monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *args:copy.deepcopy(scene))
        effective=style_render._effective(dna,measurement,scene['report'])
        expected=style_render._render_regions(full,effective,dna,.8,scene,.7,True,None,measurement=measurement)
    else:
        expected,_=style_render.apply_pixels(full,effective,.8,composition)
    stream=BytesIO()
    profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    Image.fromarray(expected).save(stream,format='JPEG',quality=95,subsampling=0,icc_profile=profile)
    expected_jpeg=np.array(Image.open(BytesIO(stream.getvalue())))
    before=file_fingerprint(sensor)
    calls=[];decode=alignment.decode_raw
    def counted(*args,**kwargs):
        calls.append((args[1],kwargs.get('quality')))
        return decode(*args,**kwargs)
    monkeypatch.setattr(alignment,'decode_raw',counted)
    output=tmp_path/'styled.jpg'
    result=style_render.export_jpeg(sensor,output,dna,.8,composition,recognition=recognition)
    assert calls==[(1_000_000,'baseline')]
    assert result['dimensions']==[expected.shape[1],expected.shape[0]]
    assert result['source_unchanged'] and file_fingerprint(sensor)==before
    with Image.open(output) as image:
        assert np.array_equal(np.array(image),expected_jpeg)
        assert image.info['icc_profile']
        assert not image.getexif()
    if composition=='color_only':
        assert result['dimensions']==list(dimensions)


def test_jpeg_export_keeps_decoder_preview_sampling_and_verified_color_profile(tmp_path,monkeypatch):
    source=tmp_path/'camera.jpg'
    pixels=np.random.default_rng(77).integers(20,230,(960,1600,3),dtype=np.uint8)
    profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    exif=Image.Exif();exif[274]=6
    Image.fromarray(pixels).save(source,quality=95,exif=exif,icc_profile=profile)
    read=style_render.read_photo;calls=[]
    def tracked(*args,**kwargs):
        calls.append(kwargs.get('max_dimension',1200))
        return read(*args,**kwargs)
    monkeypatch.setattr(style_render,'read_photo',tracked)
    result=style_render.export_jpeg(source,tmp_path/'copy.jpg',identity_dna())
    assert calls==[1200,1_000_000]
    assert result['dimensions']==[960,1600]


def test_preview_cache_never_crosses_raw_development_modes(tmp_path,monkeypatch):
    source=tmp_path/'sensor.dng';source.write_bytes(b'unchanged synthetic input')
    calls=[]
    def read(*args,raw_quality='baseline',decode_metadata=None,**kwargs):
        calls.append(raw_quality)
        decode_metadata.update({'development_quality':raw_quality})
        pixels=np.full((40,60,3),110 if raw_quality=='baseline' else 111,dtype=np.uint8)
        return pixels,(600,400)
    monkeypatch.setattr(style_render,'read_photo',read)
    first=style_render.render_preview(source,identity_dna())
    same=style_render.render_preview(source,identity_dna(),base=first)
    fast=style_render.render_preview(source,identity_dna(),base=same,raw_quality='interactive')
    stable=style_render.render_preview(source,identity_dna(),base=fast,raw_quality='interactive')
    strict=style_render.render_preview(source,identity_dna(),base=stable)
    assert calls==['baseline','interactive','baseline']
    assert first['raw_quality']=='baseline' and fast['raw_decode']['development_quality']=='interactive'
    assert np.array_equal(strict['original'],first['original'])
    assert not np.array_equal(fast['original'],first['original'])


@pytest.mark.parametrize('quality',['fast',None,False,[]])
def test_invalid_preview_quality_fails_before_hash_or_decode(tmp_path,monkeypatch,quality):
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *args:pytest.fail('Hashed invalid quality'))
    monkeypatch.setattr(style_render,'read_photo',lambda *args,**kwargs:pytest.fail('Decoded invalid quality'))
    with pytest.raises(ValueError,match='quality'):
        style_render.render_preview(tmp_path/'unused.dng',identity_dna(),raw_quality=quality)


def test_raw_decode_cancellation_never_publishes_an_export(tmp_path,monkeypatch):
    source=tmp_path/'sensor.dng';source.write_bytes(b'synthetic input')
    stop=threading.Event()
    def cancelled(*args,**kwargs):
        stop.set()
        return np.full((64,96,3),128,dtype=np.uint8),(96,64),{'warnings':[]}
    monkeypatch.setattr(alignment,'decode_raw',cancelled)
    output=tmp_path/'copy.jpg'
    with pytest.raises(ValueError,match='cancelled'):
        style_render.export_jpeg(source,output,identity_dna(),cancel_event=stop)
    assert not output.exists() and not list(tmp_path.glob('.pcl-export-*.tmp'))


def test_jpeg_preview_has_no_raw_provenance(tmp_path):
    source=tmp_path/'photo.jpg';Image.new('RGB',(60,40),(80,100,120)).save(source)
    result=style_render.render_preview(source,identity_dna())
    assert result['raw_decode'] is None


def test_recognition_cache_falls_back_then_recovers_when_models_return(tmp_path,monkeypatch):
    source=tmp_path/'photo.jpg';Image.new('RGB',(60,40),(80,100,120)).save(source)
    calls=[]
    def analyze(*args):
        calls.append(1)
        return _scene((40,60))
    monkeypatch.setattr(semantic_models,'bundle_id',lambda:'a'*64)
    monkeypatch.setattr(scene_analysis,'analyze_scene',analyze)
    style=builtin_styles()[0]
    first=style_render.render_preview(source,style,recognition=True)
    assert calls==[1] and not first['recognition_unavailable']
    same=style_render.render_preview(source,style,base=first,recognition=True)
    assert calls==[1]
    def missing():
        raise semantic_models.ModelUnavailableError('Missing local model')
    monkeypatch.setattr(semantic_models,'bundle_id',missing)
    fallback=style_render.render_preview(source,style,base=same,recognition=True)
    expected=style_render.render_preview(source,style,base=same,recognition=False)
    assert fallback['recognition_unavailable'] and fallback['scene'] is None
    assert np.array_equal(fallback['rendered'],expected['rendered'])
    monkeypatch.setattr(semantic_models,'bundle_id',lambda:'a'*64)
    repaired=style_render.render_preview(source,style,base=fallback,recognition=True)
    assert calls==[1,1] and not repaired['recognition_unavailable']


def test_unavailable_recognition_export_matches_the_global_output(tmp_path,monkeypatch):
    source=tmp_path/'photo.jpg';Image.new('RGB',(60,40),(80,100,120)).save(source)
    def missing():
        raise semantic_models.ModelUnavailableError('Missing local model')
    monkeypatch.setattr(semantic_models,'bundle_id',missing)
    style=builtin_styles()[0]
    first=tmp_path/'global.jpg';second=tmp_path/'fallback.jpg'
    plain=style_render.export_jpeg(source,first,style,recognition=False)
    fallback=style_render.export_jpeg(source,second,style,recognition=True)
    assert not plain['recognition_unavailable'] and fallback['recognition_unavailable']
    with Image.open(first) as left,Image.open(second) as right:
        assert np.array_equal(np.array(left),np.array(right))


def test_recognition_cancellation_does_not_turn_into_a_global_preview(tmp_path,monkeypatch):
    source=tmp_path/'photo.jpg';Image.new('RGB',(60,40),(80,100,120)).save(source)
    monkeypatch.setattr(semantic_models,'bundle_id',lambda:'a'*64)
    def cancelled(*args):
        raise AnalysisCancelledError('Recognition cancelled.')
    monkeypatch.setattr(scene_analysis,'analyze_scene',cancelled)
    with pytest.raises(AnalysisCancelledError):
        style_render.render_preview(source,identity_dna(),recognition=True)
    output=tmp_path/'out.jpg'
    with pytest.raises(AnalysisCancelledError):
        style_render.export_jpeg(source,output,identity_dna(),recognition=True)
    assert not output.exists()
