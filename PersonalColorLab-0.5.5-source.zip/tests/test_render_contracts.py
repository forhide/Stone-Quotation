"""Public rendering contracts across recognition, cancellation and resolution."""
import copy
import threading

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core import scene_analysis, style_render
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.style_dna import builtin_styles, identity_dna,blend_styles
from personal_color_lab.core.style_regions import protect_face_colors


def _scene(shape, region='face'):
    masks={key:np.zeros(shape,np.float32) for key in REGIONS}
    masks[region][:,:shape[1]//2]=1
    masks['background']=1-masks[region]
    return {'report':{'bundle_id':'a'*64,'scene_tags':['people'] if region=='face' else ['food']},'masks':masks}


def test_recognized_neutral_style_has_no_face_color_roundtrip_drift(tmp_path,monkeypatch):
    pixels=np.random.default_rng(44).integers(20,230,(120,180,3),dtype='uint8')
    source=tmp_path/'source.jpg';Image.fromarray(pixels).save(source,quality=98,subsampling=0)
    monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *args:_scene(pixels.shape[:2]))
    result=style_render.render_preview(source,identity_dna(),recognition=True,protect_faces=True)
    assert np.array_equal(result['rendered'],result['original'])


def test_face_protection_preserves_unchanged_pixels_and_neutral_source_hues():
    original=np.random.default_rng(52).integers(20,230,(120,180,3),dtype='uint8')
    original[:,90:]=128
    styled=original.copy();styled[:60,:50]=[160,100,150]
    styled[:,90:]=[90,100,140]
    protected=protect_face_colors(original,styled,np.ones(original.shape[:2],np.float32))
    assert np.array_equal(protected[60:,:90],styled[60:,:90])
    assert np.array_equal(protected[:,90:],styled[:,90:])
    assert np.any(protected[:60,:50]!=styled[:60,:50])


def test_face_protection_keeps_achromatic_styled_pixels_exactly_gray():
    original=np.random.default_rng(53).integers(20,230,(120,180,3),dtype='uint8')
    values=np.tile(np.arange(20,200,dtype='uint8'),(120,1))
    styled=np.repeat(values[:,:,None],3,axis=2)
    protected=protect_face_colors(original,styled,np.ones(styled.shape[:2],np.float32))
    assert np.array_equal(protected,styled)


@pytest.mark.parametrize('recognition',[False,True])
@pytest.mark.parametrize('composition',['invalid',[],None])
def test_invalid_composition_fails_before_photo_decode(tmp_path,monkeypatch,recognition,composition):
    source=tmp_path/'source.jpg';Image.new('RGB',(40,60),(90,100,110)).save(source)
    monkeypatch.setattr(style_render,'read_photo',lambda *a,**k:pytest.fail('Decoded invalid request'))
    with pytest.raises(ValueError,match='composition'):
        style_render.render_preview(source,identity_dna(),recognition=recognition,composition=composition)
    output=tmp_path/'out.jpg'
    with pytest.raises(ValueError,match='composition'):
        style_render.export_jpeg(source,output,identity_dna(),recognition=recognition,composition=composition)
    assert not output.exists()


@pytest.mark.parametrize('strength',[0.,1.])
def test_cancelled_neutral_pixel_operation_is_not_reported_as_success(strength):
    stop=threading.Event();stop.set()
    with pytest.raises(ValueError,match='cancelled'):
        style_render.apply_pixels(np.full((30,40,3),120,dtype='uint8'),identity_dna(),strength,cancel_event=stop)


@pytest.mark.parametrize('recognition',[False,True])
@pytest.mark.parametrize('strength',[0.,1.])
def test_cancelled_preview_and_export_do_no_hashing_or_decoding(tmp_path,monkeypatch,recognition,strength):
    source=tmp_path/'source.jpg';Image.new('RGB',(40,60),(90,100,110)).save(source)
    stop=threading.Event();stop.set()
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *a:pytest.fail('Hashed a cancelled request'))
    monkeypatch.setattr(style_render,'read_photo',lambda *a,**k:pytest.fail('Decoded a cancelled request'))
    with pytest.raises(ValueError,match='cancelled'):
        style_render.render_preview(source,identity_dna(),strength,cancel_event=stop,recognition=recognition)
    output=tmp_path/'out.jpg'
    with pytest.raises(ValueError,match='cancelled'):
        style_render.export_jpeg(source,output,identity_dna(),strength,cancel_event=stop,recognition=recognition)
    assert not output.exists()


def test_recognition_without_supported_local_effects_skips_region_measurement(monkeypatch):
    pixels=np.full((100,150,3),120,dtype='uint8');scene=_scene(pixels.shape[:2],'food')
    monkeypatch.setattr(scene_analysis,'region_appearance',lambda *a:pytest.fail('Measured regions without recipes'))
    style=builtin_styles()[0];effective,_=style_render.prepare_style(pixels,style)
    expected=style_render.apply_pixels(pixels,effective,.7)[0]
    result=style_render._render_regions(pixels,effective,style,.7,scene,.7,True,None)
    assert np.array_equal(result,expected)


def test_full_resolution_semantic_export_preserves_preview_region_behavior(tmp_path,monkeypatch):
    height,width=1600,2400
    yy,xx=np.indices((height,width),dtype=np.float32)
    channel=np.rint(35+145*(xx/width*.65+yy/height*.35)).astype('uint8')
    pixels=np.stack([channel,channel,channel],axis=2)
    source=tmp_path/'source.jpg';Image.fromarray(pixels).save(source,quality=98,subsampling=0)
    scene=_scene((320,480),'food')
    monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *a:copy.deepcopy(scene))
    style=identity_dna()
    style['semantic_profile']={'bundle_id':'a'*64,'contexts':{},'regions':{'food':{
        'sample_count':1,'evidence':'observed_transform','target':None,
        'tone_curve':np.clip(np.linspace(0,1,33)+.12,0,1).tolist(),
        'saturation_scale':1.,'lab_shift':[0.,0.]}}}
    preview=style_render.render_preview(source,style,.8,recognition=True,object_strength=1.,protect_faces=False)
    output=tmp_path/'styled.jpg'
    style_render.export_jpeg(source,output,style,.8,recognition=True,object_strength=1.,protect_faces=False,
                            expected_fingerprint=preview['source_fingerprint'])
    with Image.open(output) as image:
        assert image.size==(width,height)
        exported=np.asarray(image)
    assert exported[:,:width//2-10].mean()>pixels[:,:width//2-10].mean()+15
    assert np.abs(exported[:,width//2+10:].astype(float)-pixels[:,width//2+10:]).mean()<1
    downsampled=cv2.resize(exported,(preview['rendered'].shape[1],preview['rendered'].shape[0]),interpolation=cv2.INTER_AREA)
    assert np.abs(downsampled.astype(float)-preview['rendered']).mean()<1


@pytest.mark.parametrize('hybrid',[False,True])
def test_region_replacement_uses_the_same_adaptation_as_the_global_preview(hybrid):
    # Bounded previews and full pixels have different sampling distributions.
    # A full-weight neutral region still must cancel its component's *actual*
    # adapted global effect, rather than a newly recomputed global baseline.
    original=np.full((120,180,3),128,dtype='uint8')
    preview=np.full_like(original,80)
    style=identity_dna('Reference','reference','reference')
    style['reference_target']={'quantiles':[.2,.4,.7,.8,.9],'saturation':0.,'zones':{'midtones':[0.,0.]}}
    style['semantic_profile']={'bundle_id':'a'*64,'contexts':{},'regions':{'food':{
        'sample_count':1,'evidence':'observed_transform','target':None,
        'tone_curve':np.linspace(0,1,33).tolist(),'saturation_scale':1.,'lab_shift':[0.,0.]}}}
    if hybrid:style=blend_styles([style],[1.])
    scene=_scene(original.shape[:2],'food');scene['masks']['food'][:,:]=1
    scene['masks']['background'][:,:]=0
    measurement=style_render._measure(preview)
    effective=style_render._effective(style,measurement,scene['report'])
    assert style_render.apply_pixels(original,effective)[0].mean()>original.mean()+20
    result=style_render._render_regions(original,effective,style,1.,scene,1.,False,None,measurement=measurement)
    assert np.array_equal(result,original)
