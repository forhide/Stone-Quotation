"""RAW read safety and explicitly approximate interactive CFA development."""
from pathlib import Path
from threading import Event
from types import SimpleNamespace

import cv2
import numpy as np
import pytest
import rawpy

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.raw_decode import MAX_RAW_PIXELS, _can_half_size, decode_raw
from raw_fixtures import write_test_dng


def _old_baseline(path, maximum):
    """Previous released AHD pixels, independent of the new decoder control flow."""
    with rawpy.imread(str(path)) as raw:
        pixels = raw.postprocess(
            use_camera_wb=True, use_auto_wb=False, no_auto_bright=True,
            bright=1.0, exp_shift=1.0, exp_preserve_highlights=0.0,
            no_auto_scale=False, adjust_maximum_thr=0.0,
            output_color=rawpy.ColorSpace.sRGB, output_bps=8,
            gamma=(2.4, 12.92), demosaic_algorithm=rawpy.DemosaicAlgorithm.AHD,
            highlight_mode=rawpy.HighlightMode.Clip,
            fbdd_noise_reduction=rawpy.FBDDNoiseReductionMode.Off,
            median_filter_passes=0, half_size=False,
        )
    h, w = pixels.shape[:2]
    factor = min(1., maximum / max(w, h))
    if factor < 1:
        pixels = cv2.resize(pixels, (round(w * factor), round(h * factor)), interpolation=cv2.INTER_AREA)
    return pixels


@pytest.mark.parametrize("orientation", range(1, 9))
def test_metadata_first_baseline_remains_exact_and_interactive_full_geometry_is_correct(tmp_path, orientation):
    source = write_test_dng(tmp_path / "sensor.dng", width=640, height=480, orientation=orientation)
    before = source.read_bytes()
    baseline, dimensions, metadata = decode_raw(source, max_dimension=120)
    interactive, fast_dimensions, fast_metadata = decode_raw(source, max_dimension=120, quality="interactive")
    assert np.array_equal(baseline, _old_baseline(source, 120))
    assert dimensions == fast_dimensions == ((480, 640) if orientation >= 5 else (640, 480))
    assert baseline.shape == interactive.shape
    assert metadata["quality_used"] == "baseline"
    assert metadata["demosaic"] == "AHD"
    assert not metadata["half_size"] and not metadata["preview_is_approximation"]
    assert fast_metadata["quality_requested"] == "interactive"
    assert fast_metadata["quality_used"] == "interactive_half_size"
    assert fast_metadata["demosaic"] == "Bayer_half_size"
    assert fast_metadata["half_size"] and fast_metadata["preview_is_approximation"]
    assert fast_metadata["full_sensor_size"] == list(dimensions)
    assert not fast_metadata["embedded_preview_used"]
    assert "raw_interactive_preview_approximation" in fast_metadata["warnings"]
    assert float(np.abs(baseline.astype(float) - interactive).mean()) < 1.5
    assert source.read_bytes() == before


def _sizes(**changes):
    values = dict(raw_width=640, raw_height=480, width=640, height=480,
                  iwidth=640, iheight=480, flip=0, pixel_aspect=1.)
    values.update(changes)
    return SimpleNamespace(**values)


@pytest.mark.parametrize("change", [
    {"raw_type": rawpy.RawType.Stack},
    {"num_colors": 4},
    {"raw_pattern": np.zeros((6, 6), dtype=np.uint8)},
    {"raw_pattern": None},
    {"raw_pattern": np.array([[0, 0], [0, 0]])},
    {"raw_pattern": np.array([[0, 9], [2, 3]])},
    {"raw_pattern": np.array([[0, 2], [1, 3]])},
    {"raw_pattern": np.array([[0, -1], [1, 2]])},
    {"color_desc": b"CMYG"},
])
def test_non_bayer_sensor_types_do_not_enter_half_size_mode(change):
    values = dict(raw_type=rawpy.RawType.Flat, num_colors=3,
                  raw_pattern=np.array([[0, 1], [3, 2]]), color_desc=b"RGBG")
    values.update(change)
    assert not _can_half_size(SimpleNamespace(**values), rawpy, _sizes(), 120)


@pytest.mark.parametrize("change", [
    {"pixel_aspect": 1.25}, {"pixel_aspect": float("nan")},
    {"iwidth": 600}, {"iheight": 470}, {"width": 639}, {"height": 479},
    {"flip": -1}, {"flip": 8},
])
def test_unusual_geometry_does_not_enter_half_size_mode(change):
    sensor = SimpleNamespace(raw_type=rawpy.RawType.Flat, num_colors=3,
                             raw_pattern=np.array([[0, 1], [3, 2]]), color_desc=b"RGBG")
    assert not _can_half_size(sensor, rawpy, _sizes(**change), 120)


def test_small_raw_and_full_export_request_keep_ahd(tmp_path):
    source = write_test_dng(tmp_path / "sensor.dng", width=480, height=360)
    for maximum in (300, 1_000_000):
        baseline, dimensions, _ = decode_raw(source, maximum)
        interactive, fast_dimensions, metadata = decode_raw(source, maximum, quality="interactive")
        assert dimensions == fast_dimensions == (480, 360)
        assert np.array_equal(baseline, interactive)
        assert metadata["quality_requested"] == "interactive"
        assert metadata["quality_used"] == "baseline"
        assert metadata["demosaic"] == "AHD"
        assert not metadata["preview_is_approximation"]


def _fake_raw(monkeypatch, sizes=None, event=None, cancel_stage=None):
    calls = []
    sensor_sizes = sizes or _sizes()

    class Raw:
        sizes = sensor_sizes
        camera_whitebalance = [1., 1., 1., 0.]

        def __enter__(self):
            calls.append("enter")
            return self

        def __exit__(self, *args):
            calls.append("close")

        def open_file(self, path):
            calls.append("open")
            if cancel_stage == "open":
                event.set()

        def unpack(self):
            calls.append("unpack")
            if cancel_stage == "unpack":
                event.set()

        def postprocess(self, **options):
            calls.append("postprocess")
            if cancel_stage == "postprocess":
                event.set()
            return np.zeros((480, 640, 3), dtype=np.uint8)

    monkeypatch.setattr(rawpy, "RawPy", Raw)
    return calls


@pytest.mark.parametrize("change,match", [
    ({"raw_width": 13_000, "raw_height": 10_000}, "120 megapixel"),
    ({"width": 13_000, "height": 10_000}, "120 megapixel"),
    ({"raw_width": 0}, "invalid sensor dimensions"),
    ({"height": -1}, "invalid sensor dimensions"),
])
def test_invalid_headers_are_rejected_before_sensor_unpack(tmp_path, monkeypatch, change, match):
    source = tmp_path / "sensor.dng"
    source.write_bytes(b"test sensor header")
    calls = _fake_raw(monkeypatch, sizes=_sizes(**change))
    with pytest.raises(ValueError, match=match):
        decode_raw(source)
    assert calls == ["enter", "open", "close"]


@pytest.mark.parametrize("stage", ("open", "unpack", "postprocess"))
def test_cancellation_between_native_calls_is_not_masked(tmp_path, monkeypatch, stage):
    source = tmp_path / "sensor.dng"
    source.write_bytes(b"test sensor header")
    event = Event()
    calls = _fake_raw(monkeypatch, event=event, cancel_stage=stage)
    with pytest.raises(AnalysisCancelledError, match="cancelled"):
        decode_raw(source, cancel_event=event)
    assert calls[-1] == "close"
    if stage == "open":
        assert "unpack" not in calls
    if stage != "postprocess":
        assert "postprocess" not in calls


def test_cancelled_decode_does_not_access_missing_input():
    event = Event()
    event.set()
    with pytest.raises(AnalysisCancelledError):
        decode_raw(Path("/not-a-real-camera-file.dng"), cancel_event=event)


@pytest.mark.parametrize("quality", [None, "fast", "", True, 1])
def test_invalid_quality_is_rejected_without_reading_input(quality):
    with pytest.raises(ValueError, match="quality"):
        decode_raw(Path("/not-a-real-camera-file.dng"), quality=quality)
