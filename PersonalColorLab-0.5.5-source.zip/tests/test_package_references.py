"""Regression: a readable archive may still have unresolvable Installer URLs."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import build_installers
from package_references import validate_component_metadata, validate_product_references


def product(tmp_path, target='macos-arm64'):
    archive = tmp_path / 'expanded'
    archive.mkdir()
    identifier = 'org.personalcolorlab.desktop.' + target
    build_installers.distribution(target, archive / 'Distribution', identifier)
    component = archive / 'application.pkg'
    component.mkdir()
    info = ET.Element('pkg-info', identifier=identifier, version=build_installers.APP_VERSION)
    ET.SubElement(info, 'payload', numberOfFiles='1', installKBytes='1')
    ET.ElementTree(info).write(component / 'PackageInfo')
    (component / 'Bom').write_bytes(b'test BOM')
    (component / 'Payload').write_bytes(b'test payload')
    return archive, component


@pytest.mark.parametrize('target', ['macos-arm64', 'macos-x64'])
def test_generated_distribution_resolves_embedded_installation_data(tmp_path, target):
    archive, component = product(tmp_path, target)
    root = ET.parse(archive / 'Distribution').getroot()
    assert root.find('pkg-ref').text == '#application.pkg'
    refs = validate_product_references(archive)
    assert len(refs) == 1 and refs[0]['path'] == component
    info = validate_component_metadata(refs[0], component)
    assert info.get('identifier') == 'org.personalcolorlab.desktop.' + target
    assert info.get('version') == build_installers.APP_VERSION
    assert root.find('options').get('hostArchitectures') == ('arm64' if target.endswith('arm64') else 'x86_64')


@pytest.mark.parametrize('url', ['application.pkg', './application.pkg', 'https://example.com/application.pkg',
                                  'file:///tmp/application.pkg', '#../application.pkg', '#%2e%2e/application.pkg',
                                  '#/application.pkg', '#missing.pkg', '#application.pkg?other', ''])
def test_external_unsafe_or_missing_component_links_are_rejected(tmp_path, url):
    archive, _ = product(tmp_path)
    doc = ET.parse(archive / 'Distribution')
    doc.getroot().find('pkg-ref').text = url
    doc.write(archive / 'Distribution')
    with pytest.raises(ValueError):
        validate_product_references(archive)


def test_choice_cannot_point_to_an_undefined_package(tmp_path):
    archive, _ = product(tmp_path)
    doc = ET.parse(archive / 'Distribution')
    doc.getroot().find('./choice/pkg-ref').set('id', 'missing-id')
    doc.write(archive / 'Distribution')
    with pytest.raises(ValueError, match='undefined'):
        validate_product_references(archive)


@pytest.mark.parametrize('field', ['identifier', 'version'])
def test_resolved_package_metadata_must_match_distribution(tmp_path, field):
    archive, component = product(tmp_path)
    reference = validate_product_references(archive)[0]
    doc = ET.parse(component / 'PackageInfo')
    doc.getroot().set(field, 'wrong-value')
    doc.write(component / 'PackageInfo')
    with pytest.raises(ValueError, match='do not match'):
        validate_component_metadata(reference, component)


@pytest.mark.parametrize('member', ['PackageInfo', 'Bom', 'Payload'])
def test_resolved_component_needs_all_installation_members(tmp_path, member):
    archive, component = product(tmp_path)
    reference = validate_product_references(archive)[0]
    (component / member).write_bytes(b'')
    with pytest.raises(ValueError, match='required installation data'):
        validate_component_metadata(reference, component)


def test_metadata_only_reference_can_merge_with_its_embedded_url(tmp_path):
    archive, component = product(tmp_path)
    doc = ET.parse(archive / 'Distribution')
    existing = doc.getroot().find('pkg-ref')
    ET.SubElement(doc.getroot(), 'pkg-ref', id=existing.get('id'), version=existing.get('version'))
    doc.write(archive / 'Distribution')
    refs = validate_product_references(archive)
    assert refs[0]['path'] == component


def test_symlink_cannot_resolve_an_external_package(tmp_path):
    archive, component = product(tmp_path)
    outside = tmp_path / 'outside'
    outside.mkdir()
    (archive / 'escape.pkg').symlink_to(outside, target_is_directory=True)
    doc = ET.parse(archive / 'Distribution')
    doc.getroot().find('pkg-ref').text = '#escape.pkg'
    doc.write(archive / 'Distribution')
    with pytest.raises(ValueError, match='missing'):
        validate_product_references(archive)
