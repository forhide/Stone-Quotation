"""Distinct, multilabel whole-photo learning across all source evidence routes."""
import copy
import hashlib
import json

import cv2
import numpy as np
import pytest

from personal_color_lab.core import style_dna
from personal_color_lab.core.reference_analysis import ALGORITHM_VERSION, _appearance
from personal_color_lab.core.scene_styles import adapt_scene_style, empty_scene_profile
from personal_color_lab.core.style_dna import dna_from_batch, identity_dna, validate_dna, blend_styles, load_style_file


def _hash(seed):
    return hashlib.sha256(str(seed).encode()).hexdigest()


def _manual(labels):
    from personal_color_lab.core.photo_scene import unknown_photo_scene, with_scene_override
    return with_scene_override(unknown_photo_scene('legacy_analysis'), labels)


def _record(seed, labels, mode='raw_xmp', value=0, monochrome=False):
    payload = {'status': 'ok', 'confidence': 1.0,
               'provenance': {'input_fingerprints': {'original': _hash(seed), 'edited': _hash(('edit', seed))}}}
    if mode == 'raw_xmp':
        payload.update(source_type='raw_xmp', parameters={
            'Exposure2012': value, 'Saturation': value * 20, 'Tint': value * 10,
            'Temperature': 6500 + value * 1000, 'Vibrance': value * 20,
            'HueAdjustmentRed': value * 20, 'SaturationAdjustmentRed': value * 20,
            'LuminanceAdjustmentRed': value * 20, 'GrainAmount': 10 + value * 5,
            'ColorGradeShadowHue': 90, 'ColorGradeShadowSat': 10 + value * 5,
            'ConvertToGrayscale': monochrome},
            tone_curves={'ToneCurvePV2012': [[0, 0], [128, 128 + value * 20], [255, 255]],
                         'ToneCurvePV2012Red': [[0, 0], [128, 128 + value * 15], [255, 255]]})
    elif mode in ('raw_jpg', 'jpg_jpg'):
        payload.update(source_type='inferred_raw_pair' if mode == 'raw_jpg' else 'inferred_jpg_pair',
                       tone={'estimated_exposure_ev': value, 'tone_transfer': []},
                       color={'hsv': {'saturation_delta': value * .1},
                              'lab': {'delta_a': value * 2, 'delta_b': value * 3},
                              'achromatic_evidence': {'sample_count': 1000, 'original_chromatic_fraction': .8,
                                                      'edited_achromatic_fraction': 1.0 if monochrome else .1},
                              'hue_bands': {'red': {'confidence': .8, 'hue_delta_degrees': value * 10,
                                                    'saturation_delta': value * .1, 'lightness_delta': value * .05}}})
    else:
        rng = np.random.default_rng(seed)
        pixels = rng.integers(20, 210, (40, 60, 3), dtype=np.uint8)
        pixels = np.clip(pixels.astype(float) * (1 + value * .25), 0, 255).astype(np.uint8)
        if monochrome:
            pixels = cv2.cvtColor(cv2.cvtColor(pixels, cv2.COLOR_RGB2GRAY), cv2.COLOR_GRAY2RGB)
        payload.update(source_type='reference_jpg', schema_version=1, algorithm_version=ALGORITHM_VERSION,
                       original_path=f'/not-a-real-photo/{seed}.jpg', appearance=_appearance(pixels))
        payload['provenance'].update(pixel_count=2400, perceptual_hash=_hash(('perceptual', seed)))
    return {'status': 'ok', 'payload': payload, 'scene_override': labels}


def _batch(mode='raw_xmp', night_count=3, day_count=3):
    return {'mode': mode, 'results': [
        *[_record(i, ['night'], mode, -1) for i in range(night_count)],
        *[_record(i + 100, ['day'], mode, 1) for i in range(day_count)]]}


@pytest.mark.parametrize('mode', ['raw_xmp', 'raw_jpg', 'jpg_jpg', 'reference_jpg'])
def test_all_routes_learn_distinct_supported_categories_and_common_fallback(mode):
    dna = dna_from_batch(_batch(mode), 'Personal scenes')
    assert dna['schema_version'] == 3 and dna['engine_version'] == '0.5.5'
    profile = dna['scene_profile']
    assert profile['enabled'] is True and set(profile['categories']) == {'day', 'night'}
    assert profile['categories']['night']['sample_count'] == 3
    assert profile['categories']['night']['manual_count'] == 3
    assert profile['categories']['night']['shrinkage'] == pytest.approx(3 / 7)
    assert validate_dna(dna) == dna
    day, evidence = adapt_scene_style(dna, {}, _manual(['day']))
    night, _ = adapt_scene_style(dna, {}, _manual(['night']))
    assert evidence['status'] == 'adapted'
    if mode == 'reference_jpg':
        assert day['reference_target']['quantiles'][2] > dna['reference_target']['quantiles'][2]
        assert night['reference_target']['quantiles'][2] < dna['reference_target']['quantiles'][2]
    else:
        assert night['exposure_ev'] < dna['exposure_ev'] < day['exposure_ev']
    fallback, evidence = adapt_scene_style(dna, {}, _manual([]))
    assert evidence['status'] == 'global' and fallback['reference_target'] == dna['reference_target']
    assert fallback['scene_targets'] == {} and fallback['semantic_profile']['contexts'] == {}
    assert dna['scene_profile'] == profile  # adaptation has no persistence side effect


def test_xmp_subset_uses_observed_parameters_not_global_summary_and_all_render_controls():
    batch = _batch()
    batch['summary'] = {'parameters': {'Exposure2012': {'median': 99}, 'Tint': {'median': 150}}}
    dna = dna_from_batch(batch, 'Recorded scenes')
    recipe = dna['scene_profile']['categories']['night']['recipe']
    assert recipe['exposure_ev'] == -1 and recipe['recorded_parameters']['Temperature'] == 5500
    assert recipe['recorded_parameters']['Tint'] == -10
    assert recipe['vibrance'] == -.2
    assert recipe['hsl']['red']['hue'] == -6
    assert recipe['hsl']['red']['saturation'] == -.2
    assert recipe['hsl']['red']['lightness'] == -.04
    assert recipe['tone_curve'][16] < .5 and recipe['channel_curves']['red'][16] < .5
    assert recipe['lab_shift'][0] < 0 and recipe['lab_shift'][1] < 0
    assert recipe['zone_shifts']['shadows'][1] > 0
    effective, _ = adapt_scene_style(dna, {}, _manual(['night']))
    assert effective['recorded_parameters']['Temperature'] < dna['recorded_parameters']['Temperature']
    assert effective['recorded_parameters']['Tint'] < dna['recorded_parameters']['Tint']
    assert validate_dna(effective) == effective


def test_two_or_duplicate_originals_do_not_create_a_category_even_with_different_edits():
    batch = _batch(night_count=2)
    repeated = copy.deepcopy(batch['results'][0])
    repeated['payload']['provenance']['input_fingerprints']['edited'] = _hash('another-edit')
    batch['results'].extend([repeated, copy.deepcopy(repeated), copy.deepcopy(repeated)])
    dna = dna_from_batch(batch, 'No inflated night support')
    assert 'night' not in dna['scene_profile']['categories']
    assert dna['scene_profile']['coverage']['night'] == 1
    assert dna['scene_profile']['categories']['day']['sample_count'] == 3
    fallback, evidence = adapt_scene_style(dna, {}, _manual(['night']))
    assert evidence['status'] == 'global' and fallback['exposure_ev'] == dna['exposure_ev']


def test_three_identical_content_hashes_are_one_source():
    record = _record(1, ['night'], value=-1)
    dna = dna_from_batch({'mode': 'raw_xmp', 'results': [copy.deepcopy(record) for _ in range(3)]}, 'One photograph')
    assert dna['scene_profile']['categories'] == {}
    assert dna['scene_profile']['coverage'] == {'night': 1}


def test_manual_item_assignments_rebuild_saved_evidence_without_classifier_or_decoding(monkeypatch):
    from personal_color_lab.core import photo_scene, raw_decode
    monkeypatch.setattr(photo_scene, 'classify_photo_scene', lambda *a, **kw: pytest.fail('Reclassified reviewed evidence'))
    monkeypatch.setattr(raw_decode, 'decode_raw', lambda *a, **kw: pytest.fail('Decoded reviewed evidence'))
    batch = _batch()
    for index, record in enumerate(batch['results']):
        record['item'] = {'id': str(index), 'scene_override': record.pop('scene_override')}
        record['payload']['photo_scene'] = photo_scene.unknown_photo_scene('legacy_analysis')
    before = copy.deepcopy(batch)
    learned = dna_from_batch(batch, 'Reviewed style')
    assert learned['scene_profile']['categories']['night']['manual_count'] == 3
    assert batch == before
    reviewed = copy.deepcopy(batch)
    reviewed['results'][0]['item']['scene_override'] = []
    rebuilt = dna_from_batch(reviewed, 'Reviewed style')
    assert rebuilt['name'] == learned['name'] and rebuilt['exposure_ev'] == learned['exposure_ev']
    assert rebuilt['scene_profile']['coverage']['night'] == 2
    assert 'night' not in rebuilt['scene_profile']['categories']


def test_multiple_axes_and_shared_subjects_have_bounded_weights_not_largest_count_selection():
    records = [*[_record(i, ['night', 'portrait'], value=-1) for i in range(3)],
               *[_record(i + 10, ['day', 'food'], value=1) for i in range(9)]]
    dna = dna_from_batch({'mode': 'raw_xmp', 'results': records}, 'Several categories')
    effective, evidence = adapt_scene_style(dna, {}, _manual(['night', 'portrait', 'food']))
    matched = evidence['matched_categories']
    assert {item['label'] for item in matched} == {'night', 'portrait', 'food'}
    assert sum(item['weight'] for item in matched) <= .8 + 1e-12
    for axis in {item['axis'] for item in matched}:
        assert sum(item['weight'] for item in matched if item['axis'] == axis) <= .65 + 1e-12
    assert min(dna['exposure_ev'], -1) <= effective['exposure_ev'] <= max(dna['exposure_ev'], 1)
    assert validate_dna(effective) == effective


def test_small_sample_and_near_duplicate_diversity_shrink_category_delta():
    small = dna_from_batch(_batch('reference_jpg', 3, 3), 'Small')
    more = dna_from_batch(_batch('reference_jpg', 12, 12), 'More')
    assert more['scene_profile']['categories']['night']['shrinkage'] > small['scene_profile']['categories']['night']['shrinkage']
    batch = _batch('reference_jpg')
    for record in batch['results'][:3]:
        record['payload']['provenance']['perceptual_hash'] = '0' * 64
    repeated = dna_from_batch(batch, 'Near duplicates')
    assert repeated['scene_profile']['categories']['night']['diversity'] == pytest.approx(1 / 3)
    _, a = adapt_scene_style(small, {}, _manual(['night']))
    _, b = adapt_scene_style(repeated, {}, _manual(['night']))
    assert b['matched_categories'][0]['weight'] < a['matched_categories'][0]['weight']


@pytest.mark.parametrize('mode', ['raw_xmp', 'raw_jpg', 'reference_jpg'])
def test_supported_gray_category_can_coexist_with_color_and_conflict_is_conservative(mode):
    records = [*[_record(i, ['food'], mode, -1, True) for i in range(3)],
               *[_record(i + 10, ['portrait'], mode, 1, False) for i in range(3)]]
    dna = dna_from_batch({'mode': mode, 'results': records}, 'Mixed color intent')
    assert dna['saturation_scale'] > 0
    food, evidence = adapt_scene_style(dna, {}, _manual(['food']))
    assert food['saturation_scale'] == 0 and evidence['monochrome'] == 'supported_scene'
    assert food['lab_shift'] == [0, 0] and all(value == [0, 0] for value in food['zone_shifts'].values())
    conflict, evidence = adapt_scene_style(dna, {}, _manual(['food', 'portrait']))
    assert conflict['saturation_scale'] > 0 and evidence['monochrome'] == 'conservative_color'


def test_missing_xmp_gray_metadata_cannot_claim_unanimous_gray_intent():
    records = [_record(i, ['night'], monochrome=True) for i in range(3)]
    records[0]['payload']['parameters'].pop('ConvertToGrayscale')
    dna = dna_from_batch({'mode': 'raw_xmp', 'results': records}, 'Incomplete gray intent')
    assert dna['saturation_scale'] > 0 and not dna['scene_profile']['categories']['night']['monochrome']


def test_hybrid_adapts_each_component_and_preserves_component_isolation():
    learned = dna_from_batch(_batch(), 'Scene-aware')
    fixed = identity_dna('Fixed'); fixed['exposure_ev'] = 1
    hybrid = blend_styles([learned, fixed], [.4, .6])
    before = copy.deepcopy(hybrid)
    result, evidence = adapt_scene_style(hybrid, {}, _manual(['night']))
    assert result['components'][0]['dna']['exposure_ev'] < learned['exposure_ev']
    assert result['components'][1]['dna'] == fixed
    assert hybrid == before and evidence['status'] == 'hybrid'
    assert validate_dna(result) == result


@pytest.mark.parametrize('version,engine', [(1, '0.4.0'), (2, '0.5.0')])
def test_legacy_dna_upgrade_retains_old_render_behavior_and_is_non_destructive(tmp_path, version, engine):
    legacy = identity_dna('Old recipe')
    legacy.pop('scene_profile')
    if version == 1:
        legacy.pop('semantic_profile')
    legacy.update(schema_version=version, engine_version=engine)
    legacy['scene_targets'] = {'low_key': {'quantiles': [.02, .1, .2, .4, .7], 'saturation': .2, 'zones': {}}}
    original = copy.deepcopy(legacy)
    path = tmp_path / 'old-style.json'; path.write_text(json.dumps(legacy))
    upgraded = load_style_file(path)
    adapted, evidence = adapt_scene_style(upgraded, {}, _manual(['night']))
    assert upgraded['schema_version'] == 3 and upgraded['scene_profile'] == empty_scene_profile()
    assert adapted['scene_targets'] == legacy['scene_targets'] and evidence['status'] == 'disabled'
    assert legacy == original and json.loads(path.read_text()) == original


@pytest.mark.parametrize('field,value', [
    ('enabled', 1), ('taxonomy_version', 'future'), ('classifier_versions', [1]),
    ('categories', {'arbitrary': {}}), ('coverage', {'unknown': 10}), ('coverage', {'night': True}),
    ('coverage', {'night': -1})])
def test_scene_profile_rejects_invalid_fields_and_taxonomy(field, value):
    dna = identity_dna(); dna['scene_profile'][field] = value
    with pytest.raises(ValueError): validate_dna(dna)


@pytest.mark.parametrize('field,value', [
    ('sample_count', 2), ('manual_count', 4), ('confidence', float('nan')), ('shrinkage', 1),
    ('axis', 'arbitrary'), ('monochrome', True), ('bundle_ids', ['private-path']),
    ('recipe', {'pixel_data': [1, 2, 3]})])
def test_scene_category_rejects_forged_support_controls_and_private_fields(field, value):
    dna = dna_from_batch(_batch(), 'Validated scenes')
    dna['scene_profile']['categories']['night'][field] = value
    with pytest.raises(ValueError): validate_dna(dna)


def test_scene_profile_contains_derived_controls_and_support_not_source_identity():
    dna = dna_from_batch(_batch(), 'Portable style')
    encoded = json.dumps(dna['scene_profile'])
    assert '/not-a-real-photo' not in encoded and 'input_fingerprints' not in encoded
    assert all(_hash(i) not in encoded for i in range(3))
    assert 'masks' not in encoded and 'GPS' not in encoded


def test_claimed_category_support_must_match_saved_coverage():
    dna = dna_from_batch(_batch(), 'Consistent support')
    dna['scene_profile']['coverage']['night'] = 4
    with pytest.raises(ValueError): validate_dna(dna)


@pytest.mark.parametrize('schema,engine', [(3, '0.5.0'), (2, '0.5.5'), (1, '0.5.5')])
def test_version_pairs_do_not_silently_claim_older_apps_can_read_new_styles(schema, engine):
    dna = identity_dna(); dna.update(schema_version=schema, engine_version=engine)
    with pytest.raises(ValueError): validate_dna(dna)


def test_rich_eight_component_hybrid_export_can_be_loaded_again(tmp_path):
    from personal_color_lab.core.photo_scene import LABEL_AXES
    from personal_color_lab.core.style_render import export_style_json
    records = [_record(index * 3 + sample, [label], value=.5)
               for index, label in enumerate(LABEL_AXES) for sample in range(3)]
    dna = dna_from_batch({'mode': 'raw_xmp', 'results': records}, 'All supported categories')
    assert set(dna['scene_profile']['categories']) == set(LABEL_AXES)
    hybrid = blend_styles([dna] * 8, [.125] * 8, 'Eight personal styles')
    path = tmp_path / 'rich-hybrid.json'; export_style_json(path, hybrid)
    assert 256_000 < path.stat().st_size <= 2_000_000
    assert load_style_file(path) == hybrid
