"""Real desktop routes from folder selection to measured, saved source styles."""
import hashlib
import os
from pathlib import Path
import threading
import time
import tkinter as tk

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.constants import DB_FILENAME
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.ui.app import App
from personal_color_lab.ui.source_workflow import SourceWorkflow

pytestmark = pytest.mark.skipif(os.name != 'nt' and not os.environ.get('DISPLAY'), reason='Requires a desktop display or the Xvfb test runner')


def _pump(app, ready, seconds=30):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        app.update()
        if ready():
            app.update_idletasks()
            return
        time.sleep(.01)
    raise AssertionError('Source workflow did not finish')


@pytest.fixture
def desktop(tmp_path, monkeypatch, request):
    monkeypatch.setenv('PERSONAL_COLOR_LAB_DATA_DIR', str(tmp_path / 'data'))
    density = getattr(request, 'param', None)
    if density:
        import sys
        if sys.platform == 'darwin' and density != 1:
            pytest.skip('Cocoa Retina uses logical points; synthetic X11 density is not a Retina simulation')
        if sys.platform == 'win32':
            monkeypatch.setattr('personal_color_lab.ui.display._window_dpi', lambda widget: round(density * 96))
        initialize = tk.Tk.__init__
        def init(self, *args, **kwargs):
            initialize(self, *args, **kwargs)
            self.tk.call('tk', 'scaling', density * 96 / 72)
        monkeypatch.setattr(tk.Tk, '__init__', init)
    app = App()
    callbacks = []
    app.report_callback_exception = lambda kind, value, tb: callbacks.append((kind, str(value)))
    yield app, tmp_path
    if not app._closed:
        app.close()
    assert not callbacks, callbacks


def _inputs(folder, mode):
    folder.mkdir()
    if mode == 'reference_jpg':
        y, x = np.indices((160, 240))
        Image.fromarray(np.stack((80 + x // 3, 70 + y // 3, 40 + x // 5), axis=2).astype('uint8')).save(folder / 'warm.jpg', quality=95)
        Image.fromarray(np.stack((85 + x // 3, 75 + y // 3, 45 + x // 5), axis=2).astype('uint8')).save(folder / 'warm-again.jpg', quality=95)
    else:
        raw = write_test_dng(folder / 'photo.dng')
        if mode == 'raw_jpg':
            pixels, _, _ = decode_raw(raw)
            edited = np.clip(pixels.astype(float) * 1.08 + [5, 1, -3], 0, 255).astype('uint8')
            Image.fromarray(edited).save(folder / 'photo.jpg', quality=98, subsampling=0)
        else:
            (folder / 'photo.xmp').write_text('''<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" crs:Exposure2012="0.7" crs:Contrast2012="12" crs:Temperature="999999" crs:MaskGroupBasedCorrections="present" />''')
    return folder


def _open(app, folder, mode=None):
    workflow = SourceWorkflow(app, folder, mode=mode)
    app._source_workflows.append(workflow)
    _pump(app, lambda: not workflow._busy)
    return workflow


def _analyze(app, workflow):
    assert str(workflow.analyze_btn.cget('state')) == 'normal'
    workflow.start_analysis()
    _pump(app, lambda: not workflow._busy)
    assert workflow.batch is not None
    return workflow.batch


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
@pytest.mark.parametrize('language', ['en', 'ko'])
def test_folder_routes_analyze_real_inputs_save_and_reopen(desktop, monkeypatch, mode, language):
    app, tmp_path = desktop
    app.lang.set(language)
    app.change_language()
    folder = _inputs(tmp_path / mode, mode)
    before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()}
    monkeypatch.setattr('personal_color_lab.ui.app.filedialog.askdirectory', lambda **kwargs: str(folder))
    app.choose_folder()
    workflow = app._source_workflows[-1]
    _pump(app, lambda: not workflow._busy)
    assert workflow.mode == mode
    assert len(workflow._included) == (2 if mode == 'reference_jpg' else 1)
    batch = _analyze(app, workflow)
    assert batch['status'] == 'ok', batch
    assert batch['counts']['successful'] == len(workflow._included)
    # Save is available on first completion, without selecting another widget.
    assert str(workflow.save_btn.cget('state')) == 'normal'
    assert workflow.tabs.select() == str(workflow.result_tab)
    text = workflow.details.get('1.0', 'end')
    if mode == 'reference_jpg':
        assert batch['summary']['tendencies']['temperature'] == 'warm'
        assert len(workflow.palette.find_all()) > 0
        assert workflow.cards['temperature'].cget('text') == app.i18n.t('source_warm')
        assert app.i18n.t('source_consistency_high') in text
        assert 'lightroom_estimates' not in str(batch)
        workflow.result_tree.selection_set('result-0')
        workflow._result_selected()
        assert app.i18n.t('source_appearance_notice') in workflow.details.get('1.0', 'end')
    elif mode == 'raw_xmp':
        assert batch['summary']['parameters']['Exposure2012']['median'] == .7
        assert app.i18n.t('source_warning_xmp_invalid_values_ignored') in text
        assert app.i18n.t('source_warning_xmp_local_adjustments_not_extracted') in text
        assert workflow.result_tree.set('result-0', 'state') == app.i18n.t('source_result_partial')
        workflow.result_tree.selection_set('result-0')
        workflow._result_selected()
        assert app.i18n.t('source_param_Exposure2012') in workflow.details.get('1.0', 'end')
        assert app.i18n.t('source_warning_xmp_invalid_values_ignored') in workflow.details.get('1.0', 'end')
    else:
        assert batch['summary']['brightness_delta_median'] > 0
        assert app.i18n.t('source_raw_notice') in text
    workflow.style_name.set('Autumn style ' + mode)
    workflow.save_profile()
    assert workflow._status_key == 'source_saved', workflow.status.get()
    with LibraryDB(tmp_path / 'data' / DB_FILENAME) as db:
        saved = db.list_source_profiles()
        assert len(saved) == 1
        assert db.get_source_profile(saved[0]['id'])['payload'] == batch
    workflow.close()
    app.open_saved_styles()
    reopened = app._source_workflows[-1]
    reopened.profiles_tree.selection_set(str(saved[0]['id']))
    reopened.open_profile()
    assert reopened.batch == batch
    assert reopened.mode == mode
    assert reopened._status_key == 'source_profile_snapshot'
    assert str(reopened.analyze_btn.cget('state')) == 'disabled'
    assert before == {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()}


def test_exclusion_and_mode_switch_discard_prior_results(desktop):
    app, tmp_path = desktop
    workflow = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'))
    workflow.review_tree.selection_set('0')
    workflow.toggle_selected()
    assert len(workflow._included) == 1
    batch = _analyze(app, workflow)
    assert batch['summary']['sample_count'] == 1
    assert app.i18n.t('source_consistency_insufficient') in workflow.details.get('1.0', 'end')
    workflow.set_mode('raw_xmp')
    _pump(app, lambda: not workflow._busy)
    assert workflow.batch is None
    assert not workflow._included
    assert str(workflow.save_btn.cget('state')) == 'disabled'
    assert workflow.details.get('1.0', 'end').strip() == app.i18n.t('source_result_empty')


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_conflicting_xmp_values_are_withheld_and_visible_in_results(desktop, language):
    app, tmp_path = desktop
    app.lang.set(language)
    app.change_language()
    folder = _inputs(tmp_path / 'conflicting', 'raw_xmp')
    (folder / 'photo.xmp').write_text(
        '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
        'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
        'crs:Exposure2012="0.7" crs:Contrast2012="12">'
        '<crs:Exposure2012>0.9</crs:Exposure2012></rdf:Description>')
    workflow = _open(app, folder, 'raw_xmp')
    batch = _analyze(app, workflow)
    assert 'Exposure2012' not in batch['summary']['parameters']
    assert batch['summary']['parameters']['Contrast2012']['median'] == 12
    warning = app.i18n.t('source_warning_xmp_conflicting_settings_ignored')
    assert not warning.startswith('source_warning_')
    assert warning in workflow.details.get('1.0', 'end')
    assert workflow.result_tree.set('result-0', 'state') == app.i18n.t('source_result_partial')
    workflow.result_tree.selection_set('result-0')
    workflow._result_selected()
    assert warning in workflow.details.get('1.0', 'end')


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp'])
def test_missing_raw_requires_raw_selection_and_not_another_companion(desktop, monkeypatch, mode):
    app, tmp_path = desktop
    folder = _inputs(tmp_path / 'photos', mode)
    original = folder / 'photo.dng'
    moved = original.rename(tmp_path / 'different-name.dng')
    workflow = _open(app, folder, mode)
    assert len(workflow._items) == 1
    workflow.review_tree.selection_set('0')
    workflow._review_selected()
    assert workflow._items['0']['reason'] == 'missing_raw'
    assert workflow.review_hint.cget('text') == app.i18n.t('source_reason_missing_raw')
    companion = next(folder.iterdir())
    choices = iter((str(companion), str(moved)))
    prompts = []
    def choose(**kwargs):
        prompts.append(kwargs)
        return next(choices)
    monkeypatch.setattr('personal_color_lab.ui.source_workflow.filedialog.askopenfilename', choose)
    workflow.resolve_selected()
    assert not workflow._included
    assert workflow._status_key == 'source_invalid_match'
    workflow.resolve_selected()
    assert workflow._items['0']['original_path'] == str(moved)
    assert workflow._items['0']['edited_path'] == str(companion)
    assert '*.dng' in prompts[-1]['filetypes'][0][1]
    assert _analyze(app, workflow)['counts']['successful'] == 1


def test_bad_jpg_does_not_hide_success_and_failed_batch_cannot_save(desktop):
    app, tmp_path = desktop
    folder = _inputs(tmp_path / 'photos', 'reference_jpg')
    broken = folder / 'broken.jpg'
    broken.write_bytes(b'not a JPEG')
    workflow = _open(app, folder)
    batch = _analyze(app, workflow)
    assert batch['status'] == 'partial'
    assert batch['counts']['successful'] == 2
    assert batch['counts']['failed'] == 1
    row = next(row for row, result in workflow._results.items() if result['status'] != 'ok')
    workflow.result_tree.selection_set(row)
    workflow._result_selected()
    assert app.i18n.t('source_failure_help') in workflow.details.get('1.0', 'end')
    assert str(workflow.save_btn.cget('state')) == 'normal'
    for row, item in workflow._items.items():
        if Path(item['original_path']) != broken:
            workflow._included.discard(row)
    batch = _analyze(app, workflow)
    assert batch['status'] == 'failed'
    assert str(workflow.save_btn.cget('state')) == 'disabled'


def test_cancel_retains_completed_result_and_close_during_worker_is_safe(desktop, monkeypatch):
    app, tmp_path = desktop
    workflow = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'))
    import personal_color_lab.ui.source_workflow as ui
    actual = ui.analyze_inputs
    reached, release = threading.Event(), threading.Event()
    def held_analysis(items, mode, *, progress, cancel_event, cache=None):
        def held_progress(*args):
            progress(*args)
            reached.set()
            assert release.wait(10)
        return actual(items, mode, progress=held_progress, cancel_event=cancel_event, cache=cache)
    monkeypatch.setattr(ui, 'analyze_inputs', held_analysis)
    workflow.start_analysis()
    try:
        _pump(app, reached.is_set)
        workflow.cancel()
        assert workflow._cancel_event.is_set()
        assert workflow._status_key == 'source_cancelling'
        release.set()
        _pump(app, lambda: not workflow._busy)
        assert workflow.batch['status'] == 'cancelled'
        assert workflow.batch['counts']['successful'] == 1
        assert workflow._status_key == 'source_cancelled'
        assert str(workflow.save_btn.cget('state')) == 'normal'
        reached.clear()
        release.clear()
        workflow.start_analysis()
        _pump(app, reached.is_set)
        threads = list(workflow._threads)
        workflow.close()
        release.set()
        for thread in threads:
            thread.join(10)
            assert not thread.is_alive()
        assert workflow._closed
        assert workflow.status is None
        app.update()
    finally:
        release.set()


@pytest.mark.parametrize('language', ['en', 'ko'])
@pytest.mark.parametrize('desktop', [1., 1.5, 2.], indirect=True)
def test_source_actions_fit_minimum_window_at_display_densities(desktop, language):
    app, tmp_path = desktop
    app.lang.set(language)
    app.change_language()
    workflow = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'))
    width, height = workflow.minsize()
    workflow.geometry(f'{width}x{height}')
    app.update()
    def inside(widget):
        x = widget.winfo_rootx() - workflow.winfo_rootx()
        y = widget.winfo_rooty() - workflow.winfo_rooty()
        assert widget.winfo_ismapped()
        assert 0 <= x <= workflow.winfo_width() - widget.winfo_width()
        assert 0 <= y <= workflow.winfo_height() - widget.winfo_height()
    for widget in (*workflow.mode_buttons.values(), workflow.toggle_btn, workflow.resolve_btn, workflow.analyze_btn):
        inside(widget)
    _analyze(app, workflow)
    app.update()
    for widget in (workflow.save_btn, workflow.name_entry, workflow.result_tree, workflow.details, *workflow.cards.values()):
        inside(widget)
    for widget in workflow.cards.values():
        text_width = int(app.tk.call('font', 'measure', widget.cget('font'), widget.cget('text')))
        assert text_width <= widget.winfo_width()


def test_source_navigation_shows_the_current_action_and_selected_count(desktop):
    app, tmp_path = desktop
    workflow = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'))
    app.update()
    assert workflow.analyze_btn.cget('text') == app.i18n.t('source_analyze_count', count=2)
    assert workflow.mode_cards[workflow.mode].cget('highlightbackground') == workflow.phase_labels['review'].cget('foreground')
    workflow.review_tree.selection_set('0')
    workflow.toggle_selected()
    assert workflow.analyze_btn.cget('text') == app.i18n.t('source_analyze_count', count=1)
    _analyze(app, workflow)
    app.update()
    assert not workflow.modes_frame.winfo_ismapped()
    assert not workflow.refresh_btn.winfo_ismapped()
    assert not workflow.analyze_btn.winfo_ismapped()
    assert workflow.save_btn.winfo_ismapped()
    assert workflow.apply_btn.winfo_ismapped()
    workflow.tabs.select(workflow.review_tab)
    app.update()
    assert workflow.modes_frame.winfo_ismapped()
    assert workflow.analyze_btn.winfo_ismapped()


def test_changing_language_preserves_the_selected_result_and_saved_style(desktop):
    app, tmp_path = desktop
    workflow = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'))
    _analyze(app, workflow)
    workflow.style_name.set('A personal look')
    workflow.save_profile()
    profile = next(iter(workflow._profiles))
    workflow.profiles_tree.selection_set(profile)
    workflow.result_tree.selection_set('result-0')
    workflow._result_selected()
    app.lang.set('ko')
    app.change_language()
    app.update()
    assert workflow.result_tree.selection() == ('result-0',)
    assert workflow.profiles_tree.selection() == (profile,)
    assert workflow.style_name.get() == 'A personal look'
    assert app.i18n.t('source_appearance_notice') in workflow.details.get('1.0', 'end')
    assert workflow.result_help.cget('text') == app.i18n.t('source_saved_next')


@pytest.mark.parametrize('explicit', [False, True])
def test_change_folder_detects_a_route_unless_the_user_selected_one(desktop, monkeypatch, explicit):
    app, tmp_path = desktop
    first = _inputs(tmp_path / 'references', 'reference_jpg')
    second = _inputs(tmp_path / 'recorded-settings', 'raw_xmp')
    workflow = _open(app, first)
    if explicit:
        workflow.set_mode('reference_jpg')
        _pump(app, lambda: not workflow._busy)
    prompts = []
    def choose(**kwargs):
        prompts.append(kwargs)
        return str(second)
    monkeypatch.setattr('personal_color_lab.ui.source_workflow.filedialog.askdirectory', choose)
    workflow.folder_btn.invoke()
    _pump(app, lambda: not workflow._busy)
    assert workflow.folder == second
    assert prompts[0]['parent'] is workflow
    assert prompts[0]['initialdir'] == str(first)
    assert workflow.mode == ('reference_jpg' if explicit else 'raw_xmp')
    assert workflow.tabs.select() == str(workflow.review_tab)
    assert workflow.batch is None
    assert workflow._included == (set() if explicit else {'0'})


def test_changing_folder_is_unavailable_during_analysis(desktop, monkeypatch):
    app, tmp_path = desktop
    workflow = _open(app, _inputs(tmp_path / 'photos', 'reference_jpg'))
    import personal_color_lab.ui.source_workflow as ui
    entered, release = threading.Event(), threading.Event()
    mode = workflow.mode
    def hold_analysis(*args, **kwargs):
        entered.set()
        assert release.wait(10)
        return {'status': 'cancelled', 'mode': mode, 'results': [], 'summary': {}}
    monkeypatch.setattr(ui, 'analyze_inputs', hold_analysis)
    def forbidden_dialog(**kwargs):
        pytest.fail('An active analysis cannot change its input folder')
    monkeypatch.setattr(ui.filedialog, 'askdirectory', forbidden_dialog)
    workflow.start_analysis()
    try:
        _pump(app, entered.is_set)
        assert str(workflow.folder_btn.cget('state')) == 'disabled'
        workflow.choose_folder()
    finally:
        release.set()
        _pump(app, lambda: not workflow._busy)
