"""Exact identity, focal-range and offline lens-bundle verification contracts."""
import hashlib
import json
from pathlib import Path

import pytest

from personal_color_lab.core.lens_profiles import (
    LensProfileUnavailableError, LENS_ROOT, equipment_catalog, equipment_for_selection,
    lens_bundle_id, resolve_lens_profile, validate_lens_override, verify_lens_profiles,
)


# Explicitly fictional calibration fixture for matching/interpolation tests.
_XML = '''<lensdatabase version="2">
<mount><name>Test Crop Mount</name><compat>Test Full Mount</compat></mount>
<camera><maker>Fixture</maker><model>Fixture Camera</model><model lang="en">Camera</model>
<mount>Test Crop Mount</mount><cropfactor>1.5</cropfactor></camera>
<lens><maker>Fixture</maker><model>Fixture 20-40mm f/2.8</model><mount>Test Full Mount</mount>
<cropfactor>1</cropfactor><aspect-ratio>3:2</aspect-ratio><calibration>
<distortion model="poly3" focal="20" k1="-0.04"/>
<distortion model="poly3" focal="40" k1="-0.01"/>
</calibration></lens></lensdatabase>'''


def _bundle(tmp_path, xml=_XML):
    root = tmp_path / 'profiles'
    (root / 'db').mkdir(parents=True)
    (root / 'db/test.xml').write_text(xml, encoding='utf-8')
    (root / 'COPYING.CC_BY-SA_3.0').write_text('Fictional unit-test data; not a production lens calibration.', encoding='utf-8')
    files = []
    for name in ('db/test.xml', 'COPYING.CC_BY-SA_3.0'):
        data = (root / name).read_bytes()
        files.append({'filename': name, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    (root / 'manifest.json').write_text(json.dumps({'schema_version': 1, 'files': files,
        'source': {'commit': 'a' * 40, 'url': 'https://example.invalid/fictional-unit-test'}}), encoding='utf-8')
    return root


def _metadata(**changes):
    values = {'camera_make': 'Fixture', 'camera_model': 'Camera', 'lens_make': 'Fixture',
              'lens_model': '20-40mm f2.8', 'focal_length_mm': 30, 'orientation': 6}
    values.update(changes)
    return values


def test_exact_matching_published_aliases_crop_mount_and_focal_scaled_interpolation(tmp_path):
    root = _bundle(tmp_path)
    plan = resolve_lens_profile(_metadata(crop_factor=9.9), root=root)
    assert plan['available'] and plan['status'] == 'matched'
    assert plan['camera_crop_factor'] == 1.5  # Approximate EXIF crop is ignored.
    assert plan['calibration_crop_factor'] == 1.
    assert plan['calibration_aspect'] == 1.5
    assert plan['orientation'] == 6
    # Independently specified Lensfun preconditioning: k*f, linear two-point
    # Hermite segment, then divide by requested focal. This is not mean(k).
    assert plan['coefficients'] == pytest.approx([(-.04 * 20 - .01 * 40) / 2 / 30])
    assert plan['interpolation'] == 'lensfun_focal_scaled_hermite'
    assert plan['bundle_id'] == lens_bundle_id(root)
    assert json.loads(json.dumps(plan)) == plan


@pytest.mark.parametrize('changes,status', [
    ({'focal_length_mm': 20}, 'matched'), ({'focal_length_mm': 40}, 'matched'),
    ({'focal_length_mm': 19.9}, 'focal_out_of_range'), ({'focal_length_mm': 40.1}, 'focal_out_of_range'),
    ({'camera_model': 'Camera Mark II'}, 'camera_not_found'),
    ({'camera_make': 'Other'}, 'camera_not_found'),
    ({'lens_model': '20-40mm f/4'}, 'lens_not_found'),
    ({'lens_model': '20-40mm f/2.8 II'}, 'lens_not_found'),
    ({'lens_make': 'Other'}, 'lens_not_found'),
    ({'lens_model': None}, 'metadata_missing'), ({'focal_length_mm': True}, 'metadata_missing'),
    ({'focal_length_mm': float('nan')}, 'metadata_missing'),
    ({'embedded_dng_opcodes_present': True}, 'embedded_correction'),
    ({'embedded_distortion': True}, 'embedded_correction'),
])
def test_profiles_never_guess_names_or_extrapolate(tmp_path, changes, status):
    result = resolve_lens_profile(_metadata(**changes), root=_bundle(tmp_path))
    assert result['status'] == status
    assert result['available'] == (status == 'matched')


@pytest.mark.parametrize('xml,status', [
    (_XML, 'matched'),
    (_XML.replace('<cropfactor>1</cropfactor>', '<type>fisheye</type><cropfactor>1</cropfactor>'), 'unsupported'),
    (_XML.replace('model="poly3"', 'model="acm"'), 'unsupported'),
    (_XML.replace('k1="-0.04"', 'k1="nan"'), 'unsupported'),
    (_XML.replace('k1="-0.04"', 'k1="nonsense"'), 'unsupported'),
    (_XML.replace('<cropfactor>1</cropfactor>', '<cropfactor>2</cropfactor>'), 'uncalibrated'),
    (_XML.replace('<mount>Test Full Mount</mount>', '<mount>Unrelated Mount</mount>'), 'mount_mismatch'),
    (_XML.replace('model="poly3" focal="40"', 'model="poly5" focal="40"'), 'unsupported'),
    (_XML.replace('</calibration>', '</calibration><calibration><distortion model="poly3" focal="30" k1="-.2"/></calibration>'), 'ambiguous'),
    (_XML.replace('</lens></lensdatabase>', '</lens><lens>' + _XML.split('<lens>')[1].split('</lens>')[0] + '</lens></lensdatabase>'), 'ambiguous'),
])
def test_unsupported_or_ambiguous_calibrations_are_safe_skips(tmp_path, xml, status):
    result = resolve_lens_profile(_metadata(), root=_bundle(tmp_path, xml))
    assert result['status'] == status


def test_four_neighbor_hermite_focal_preconditioning(tmp_path):
    xml = _XML.replace('<distortion model="poly3" focal="20" k1="-0.04"/>',
        '<distortion model="poly3" focal="10" k1="-0.06"/>'
        '<distortion model="poly3" focal="20" k1="-0.04"/>').replace(
        '</calibration>', '<distortion model="poly3" focal="50" k1="0.01"/></calibration>')
    result = resolve_lens_profile(_metadata(), root=_bundle(tmp_path, xml))
    # At t=.5, Hermite weights are [-1/16,9/16,9/16,-1/16].
    conditioned = (-1 / 16 * -.06 * 10 + 9 / 16 * -.04 * 20
                   + 9 / 16 * -.01 * 40 - 1 / 16 * .01 * 50)
    assert result['coefficients'] == pytest.approx([conditioned / 30])
    assert result['calibration_focals'] == [10, 20, 40, 50]


def test_cache_revalidates_tamper_and_inventory_and_license(tmp_path):
    root = _bundle(tmp_path)
    identity = lens_bundle_id(root)
    (root / 'db/test.xml').write_text(_XML.replace('-0.04', '-0.08'), encoding='utf-8')
    assert resolve_lens_profile(_metadata(), root=root)['status'] == 'database_unavailable'
    with pytest.raises(LensProfileUnavailableError):
        lens_bundle_id(root)
    (root / 'db/test.xml').write_text(_XML, encoding='utf-8')
    assert lens_bundle_id(root) == identity
    (root / 'db/extra.xml').write_text(_XML, encoding='utf-8')
    with pytest.raises(LensProfileUnavailableError):
        verify_lens_profiles(root)
    (root / 'db/extra.xml').unlink()
    (root / 'COPYING.CC_BY-SA_3.0').unlink()
    assert resolve_lens_profile(_metadata(), root=root)['status'] == 'database_unavailable'


def test_manifest_path_traversal_and_xml_entities_are_rejected(tmp_path):
    root = _bundle(tmp_path)
    manifest_path = root / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    manifest['files'][0]['filename'] = '../outside.xml'
    manifest_path.write_text(json.dumps(manifest))
    with pytest.raises(LensProfileUnavailableError):
        verify_lens_profiles(root)
    other = tmp_path / 'other'
    other.mkdir()
    root = _bundle(other, '<!DOCTYPE lensdatabase [<!ENTITY a "abc">]>' + _XML)
    with pytest.raises(LensProfileUnavailableError):
        verify_lens_profiles(root)


def test_real_official_bundle_and_known_canon_profile_are_local_and_pinned(monkeypatch):
    import socket
    monkeypatch.setattr(socket, 'socket', lambda *args, **kwargs: pytest.fail('Network must not be used'))
    manifest = verify_lens_profiles()
    assert manifest['source']['commit'] == '43f9e001ab66c4fcdd4f400463f13b72f94b2288'
    assert manifest['stats']['xml_files'] == 56
    assert manifest['stats']['camera_entries'] == 1057
    assert manifest['stats']['lens_entries'] == 1571
    assert manifest['stats']['distortion_calibrations'] == 6458
    plan = resolve_lens_profile({'camera_make': 'CANON', 'camera_model': 'EOS 5D Mark IV',
                                'lens_model': 'EF24-70mm f/2.8L II USM', 'focal_length_mm': 24})
    assert plan['available'] and plan['distortion_model'] == 'ptlens'
    assert plan['coefficients'] == [.02964, -.07853, .02943]
    assert plan['bundle_id'] == manifest['bundle_id']
    assert (LENS_ROOT / 'COPYING.CC_BY-SA_3.0').is_file()


def _override(**changes):
    values = {'camera_make': 'Fixture', 'camera_model': 'Camera',
              'lens_make': 'Fixture', 'lens_model': '20-40mm f/2.8'}
    values.update(changes)
    return values


def test_manual_selection_preserves_detected_focal_orientation_embedded_flags_and_source(tmp_path):
    metadata = _metadata(embedded_dng_opcodes_present=True, embedded_distortion=True,
                         metadata_sources={'lens_model': 'raw_exif', 'focal_length_mm': 'raw_exif'},
                         warnings=['maker_note_unsupported'], gps_latitude=12.34)
    before = json.loads(json.dumps(metadata))
    override = _override(camera_model='Fixture Camera', focal_length_mm=None)
    chosen = equipment_for_selection(metadata, override)
    assert chosen['camera_model'] == 'Fixture Camera'
    assert chosen['focal_length_mm'] == 30 and chosen['orientation'] == 6
    assert chosen['metadata_sources']['lens_model'] == 'manual'
    assert chosen['metadata_sources']['focal_length_mm'] == 'raw_exif'
    assert chosen['embedded_dng_opcodes_present'] and chosen['embedded_distortion']
    assert 'gps_latitude' not in chosen
    assert resolve_lens_profile(chosen, root=_bundle(tmp_path))['status'] == 'embedded_correction'
    chosen['warnings'].append('extra')
    chosen['metadata_sources']['lens_model'] = 'changed'
    assert metadata == before and override['focal_length_mm'] is None


def test_explicit_manual_focal_replaces_only_focal_and_can_resolve_missing_exif(tmp_path):
    metadata = {'camera_make': None, 'camera_model': None, 'lens_model': None, 'focal_length_mm': None}
    chosen = equipment_for_selection(metadata, _override(focal_length_mm=20))
    assert chosen['focal_length_mm'] == 20.
    assert chosen['metadata_sources']['focal_length_mm'] == 'manual'
    assert chosen['metadata_status'] == 'manual_selection'
    assert resolve_lens_profile(chosen, root=_bundle(tmp_path))['available']
    assert metadata['focal_length_mm'] is None
    no_focal = equipment_for_selection(metadata, _override())
    assert resolve_lens_profile(no_focal, root=tmp_path / 'missing')['status'] == 'metadata_missing'


@pytest.mark.parametrize('override', [
    {}, {'camera_make': 'Fixture'}, _override(camera_model=None), _override(lens_make=''),
    _override(lens_model='x' * 201), _override(lens_model='hidden\x00field'),
    _override(lens_model='hidden\u202efield'), _override(gps_latitude=12.34),
    _override(serial_number='private'), _override(aperture=2.8),
    _override(focal_length_mm=True), _override(focal_length_mm='24'),
    _override(focal_length_mm=float('nan')), _override(focal_length_mm=float('inf')),
    _override(focal_length_mm=0), _override(focal_length_mm=2001),
    _override(focal_length_mm=10**1000),
])
def test_manual_selection_rejects_malformed_or_private_metadata(override):
    with pytest.raises(ValueError):
        validate_lens_override(override)


def test_manual_validator_is_database_independent_and_does_not_alias_input(monkeypatch):
    import personal_color_lab.core.lens_profiles as module
    monkeypatch.setattr(module, '_database', lambda *args, **kwargs: pytest.fail('Validator must not read profiles'))
    assert validate_lens_override(None) is None
    selected = _override(lens_model=' FE 16-35mm F2.8 GM II ', focal_length_mm=24)
    result = validate_lens_override(selected)
    assert result['lens_model'] == 'FE 16-35mm F2.8 GM II' and result['focal_length_mm'] == 24.
    assert selected['lens_model'].startswith(' ')


def test_catalog_exact_identity_mount_filter_and_supported_calibration(tmp_path):
    root = _bundle(tmp_path)
    catalog = equipment_catalog(root=root)
    assert catalog['cameras'] == [{'camera_make': 'Fixture', 'camera_model': 'Fixture Camera', 'label': 'Fixture Camera'}]
    assert catalog['lenses'] == [{'lens_make': 'Fixture', 'lens_model': 'Fixture 20-40mm f/2.8',
                                 'label': 'Fixture 20-40mm f/2.8', 'calibrated': True}]
    assert equipment_catalog('Fixture', 'Camera', root=root)['lenses'] == catalog['lenses']
    assert equipment_catalog('Other', 'Unknown', root=root)['lenses'] == []
    assert equipment_catalog('Other', root=root)['cameras'] == []
    assert catalog['bundle_id'] == lens_bundle_id(root)
    assert json.loads(json.dumps(catalog)) == catalog


def test_catalog_does_not_claim_missing_or_unsupported_optical_data(tmp_path):
    root = _bundle(tmp_path, _XML.replace('model="poly3"', 'model="acm"'))
    assert not equipment_catalog('Fixture', 'Camera', root=root)['lenses'][0]['calibrated']
    other = tmp_path / 'smaller'
    other.mkdir()
    root = _bundle(other, _XML.replace('<cropfactor>1</cropfactor>', '<cropfactor>2</cropfactor>'))
    assert not equipment_catalog('Fixture', 'Camera', root=root)['lenses'][0]['calibrated']


def test_sony_a7cr_gmii_is_never_substituted_with_first_generation_gm():
    detected = {'camera_make': 'SONY', 'camera_model': 'ILCE-7CR',
                'lens_make': 'Sony', 'lens_model': 'FE 16-35mm F2.8 GM II', 'focal_length_mm': 24.}
    auto = resolve_lens_profile(detected)
    assert not auto['available'] and auto['status'] == 'lens_not_found'
    catalog = equipment_catalog('Sony', 'ILCE-7CR')
    assert any(camera['camera_model'] == 'ILCE-7CR' for camera in catalog['cameras'])
    assert not any(lens['lens_model'].endswith('GM II') and '16-35mm' in lens['lens_model'] for lens in catalog['lenses'])
    gm = next(lens for lens in catalog['lenses'] if lens['lens_model'] == 'FE 16-35mm f/2.8 GM')
    assert gm['calibrated']
    # Selecting the explicitly different first-generation lens is manual
    # identity replacement; automatic matching must never make this choice.
    manual = equipment_for_selection(detected, {'camera_make': 'Sony', 'camera_model': 'ILCE-7CR',
                                                'lens_make': 'Sony', 'lens_model': gm['lens_model']})
    assert resolve_lens_profile(manual)['available']
    assert manual['metadata_sources']['lens_model'] == 'manual'
    assert detected['lens_model'] == 'FE 16-35mm F2.8 GM II'
