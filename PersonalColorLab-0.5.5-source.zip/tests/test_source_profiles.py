"""Named source-analysis snapshots preserve evidence and survive app restarts."""

import copy
import json
import sqlite3
from contextlib import closing
from datetime import datetime, timezone

import pytest

from personal_color_lab.core.database import (
    AnalysisDataError,
    AnalysisValidationError,
    LibraryDB,
)
from personal_color_lab.core.schema_migrations import SchemaMigrationError


def profile(mode='reference_jpg', statuses=('ok',), cancelled=0):
    results = [
        {
            'item': {
                'id': f'input-{index}', 'source_type': mode,
                'original_path': f'/사진/가을 {index}.jpg' if mode == 'reference_jpg' else f'/사진/가을 {index}.nef',
                'edited_path': None if mode == 'reference_jpg' else f'/사진/가을 {index}.xmp' if mode == 'raw_xmp' else f'/사진/가을 {index}.jpg',
                'status': 'ready', 'reason': 'reference_photo' if mode == 'reference_jpg' else 'filename_match',
                'candidates': [],
            },
            'status': status,
            'payload': {'status': status, 'measurement': 0.25, 'provenance': {'originals_modified': False}}
            if status not in {'duplicate', 'skipped', 'error'} else None,
        }
        for index, status in enumerate(statuses)
    ]
    counts = {
        'total': len(results) + cancelled, 'processed': len(results),
        'successful': statuses.count('ok'),
        'failed': sum(status not in {'ok', 'duplicate', 'skipped'} for status in statuses),
        'skipped': statuses.count('skipped'), 'cancelled': cancelled,
        'duplicates': statuses.count('duplicate'),
    }
    status = ('cancelled' if cancelled else 'failed' if not counts['successful'] else
              'partial' if counts['failed'] or counts['skipped'] else 'ok')
    return {
        'schema_version': 1, 'algorithm_version': '0.3.0', 'mode': mode,
        'status': status, 'analyzed_at_utc': '2026-10-08T01:02:03.123456+00:00',
        'results': results, 'summary': {'sample_count': counts['successful']},
        'counts': counts,
        'provenance': {'originals_modified': False, 'aggregation': 'equal_per_unique_input',
                       'exact_edit_parameters': mode == 'raw_xmp'},
    }


@pytest.mark.parametrize('algorithm_version', ['0.3.0', '0.4.0', '0.5.0', '0.5.1', '0.5.2', '0.5.3', '0.5.4', '0.5.5'])
@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
def test_unicode_source_profiles_are_snapshots_and_survive_restart(tmp_path, mode, algorithm_version):
    path = tmp_path / '개인 보정.sqlite'
    payload = profile(mode)
    payload['algorithm_version'] = algorithm_version
    first_snapshot = copy.deepcopy(payload)
    with LibraryDB(path) as db:
        first = db.save_source_profile('  나의 가을 🎞  ', payload)
        assert payload == first_snapshot
        payload['results'][0]['payload']['measurement'] = 0.75
        second = db.save_source_profile('나의 가을 🎞', payload)
        assert second != first
        assert db.get_source_profile(first)['payload'] == first_snapshot
    with LibraryDB(path) as db:
        assert db.get_source_profile(first)['payload'] == first_snapshot
        latest = db.get_source_profile(second)
        assert latest['payload'] == payload
        assert latest['name'] == '나의 가을 🎞'
        assert latest['mode'] == mode
        for field in ('created_at_utc', 'updated_at_utc'):
            assert datetime.fromisoformat(latest[field]).utcoffset() == timezone.utc.utcoffset(None)
        assert latest['created_at_utc'] == latest['updated_at_utc']
        listed = db.list_source_profiles()
        assert [row['id'] for row in listed] == [second, first]
        assert all('payload' not in row for row in listed)
        assert [row['name'] for row in listed] == ['나의 가을 🎞', '나의 가을 🎞']
        assert db.get_source_profile(999999) is None


@pytest.mark.parametrize('statuses,cancelled', [
    (('ok', 'duplicate'), 0),
    (('ok', 'no_supported_settings'), 0),
    (('ok', 'alignment_failed', 'color_space_uncertain', 'analysis_failed', 'error', 'skipped', 'duplicate'), 0),
    (('ok', 'error', 'skipped', 'duplicate'), 3),
    (('ok',), 2),
])
def test_partial_and_cancelled_profiles_keep_every_result_and_exact_counts(tmp_path, statuses, cancelled):
    payload = profile('raw_xmp', statuses, cancelled)
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        row_id = db.save_source_profile('Retained evidence', payload)
        assert db.get_source_profile(row_id)['payload'] == payload


@pytest.mark.parametrize('statuses,cancelled', [
    ((), 0), ((), 2), (('error',), 0), (('skipped', 'no_supported_settings'), 3),
])
def test_batches_without_successful_samples_cannot_be_saved(tmp_path, statuses, cancelled):
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError, match='successful'):
            db.save_source_profile('Empty', profile(statuses=statuses, cancelled=cancelled))
        assert db.list_source_profiles() == []
        assert not db.conn.in_transaction


@pytest.mark.parametrize('field', ['total', 'processed', 'successful', 'failed', 'skipped', 'cancelled', 'duplicates'])
@pytest.mark.parametrize('difference', [-1, 1])
def test_no_count_can_be_incremented_or_decremented_without_matching_evidence(tmp_path, field, difference):
    payload = profile(statuses=('ok', 'ok', 'error', 'skipped', 'duplicate'), cancelled=2)
    payload['counts'][field] += difference
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError, match='counts'):
            db.save_source_profile('Wrong count', payload)
        assert db.list_source_profiles() == []


@pytest.mark.parametrize('sample_count', [0, 1, 3, True])
def test_sample_count_must_equal_successful_results(tmp_path, sample_count):
    payload = profile(statuses=('ok', 'ok'))
    payload['summary']['sample_count'] = sample_count
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError):
            db.save_source_profile('Wrong sample count', payload)


@pytest.mark.parametrize('metadata', [
    {'measurement': float('nan')}, {'measurement': float('inf')},
    {'measurement': float('-inf')}, {'measurement': (1, 2)},
    {'nested': {'GPSLatitude': [37, 1, 2]}},
    {'nested': [{'latitude': 37.0, 'longitude': 127.0}]},
    {'nested': {'gps_info': 'coordinates'}},
    {'EXIF': 'original camera metadata'}, {'raw_exif': {'Camera': 'ignored'}},
    {'raw_metadata': {'Image': 'original data'}},
    {'raw_xml': '<anything />'}, {'xmpDocument': '<anything />'},
    {'document': '<?xml version="1.0"?><x:xmpmeta />'},
    {'document': '<rdf:RDF xmlns:rdf="urn:example" />'},
])
def test_unsafe_nonfinite_or_original_metadata_is_rejected_without_writes(tmp_path, metadata):
    good = profile()
    payload = copy.deepcopy(good)
    payload['results'][0]['payload']['extra'] = metadata
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        existing = db.save_source_profile('Keep', good)
        with pytest.raises(AnalysisValidationError):
            db.save_source_profile('Reject', payload)
        assert not db.conn.in_transaction
        assert [row['id'] for row in db.list_source_profiles()] == [existing]
        assert db.get_source_profile(existing)['payload'] == good


@pytest.mark.parametrize('field,value', [
    ('schema_version', 2), ('schema_version', True),
    ('algorithm_version', 'future'), ('mode', 'unknown'),
    ('status', 'failed'), ('status', 'partial'), ('status', 'cancelled'),
    ('analyzed_at_utc', '2026-10-08T01:02:03'),
    ('analyzed_at_utc', '2026-10-08T01:02:03+09:00'),
    ('provenance', {'originals_modified': True}),
])
def test_invalid_profile_contract_is_rejected(tmp_path, field, value):
    payload = profile()
    payload[field] = value
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError):
            db.save_source_profile('Invalid', payload)
        assert db.list_source_profiles() == []


def test_cyclic_payload_and_boolean_counts_are_rejected(tmp_path):
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        payload = profile()
        payload['summary']['cycle'] = payload
        with pytest.raises(AnalysisValidationError, match='cyclic'):
            db.save_source_profile('Cycle', payload)
        payload = profile()
        payload['counts']['successful'] = True
        with pytest.raises(AnalysisValidationError, match='counts'):
            db.save_source_profile('Boolean', payload)


@pytest.mark.parametrize('name', ['', '  ', 'x' * 121, 'line\nbreak', 'null\x00character', None])
def test_profile_names_are_validated(tmp_path, name):
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError):
            db.save_source_profile(name, profile())
        assert db.list_source_profiles() == []


@pytest.mark.parametrize('profile_id', [0, -1, True, '1', 2**63])
def test_profile_ids_are_validated(tmp_path, profile_id):
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError):
            db.get_source_profile(profile_id)


@pytest.mark.parametrize('corruption', ['json', 'array', 'nan', 'gps', 'mode', 'name', 'created', 'updated', 'counts'])
def test_corrupt_snapshots_fail_cleanly_for_loading_and_listing(tmp_path, corruption):
    payload = profile()
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        row_id = db.save_source_profile('Valid', payload)
        column = 'payload_json'
        if corruption == 'json':
            value = '{broken'
        elif corruption == 'array':
            value = '[]'
        elif corruption == 'nan':
            payload['summary']['measurement'] = float('nan')
            value = json.dumps(payload)
        elif corruption == 'gps':
            payload['summary']['GPSInfo'] = 'forbidden'
            value = json.dumps(payload)
        elif corruption == 'counts':
            payload['counts']['processed'] += 1
            value = json.dumps(payload)
        elif corruption == 'mode':
            column, value = 'mode', 'raw_xmp'
        elif corruption == 'name':
            column, value = 'name', '  Unnormalized  '
        elif corruption == 'created':
            column, value = 'created_at_utc', 'not a timestamp'
        else:
            column, value = 'updated_at_utc', '2020-01-01T00:00:00+00:00'
        with db.conn:
            db.conn.execute(f'UPDATE source_profiles SET {column}=? WHERE id=?', (value, row_id))
        with pytest.raises(AnalysisDataError, match=f'row {row_id}'):
            db.get_source_profile(row_id)
        with pytest.raises(AnalysisDataError, match=f'row {row_id}'):
            db.list_source_profiles()


def test_failed_profile_insert_rolls_back_without_losing_saved_snapshots(tmp_path):
    payload = profile()
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        existing = db.save_source_profile('Keep', payload)
        db.conn.execute('''
            CREATE TRIGGER reject_profile_insert BEFORE INSERT ON source_profiles
            BEGIN SELECT RAISE(ABORT, 'simulated profile failure'); END
        ''')
        with pytest.raises(sqlite3.IntegrityError, match='simulated profile failure'):
            db.save_source_profile('Fails', payload)
        assert not db.conn.in_transaction
        assert [row['id'] for row in db.list_source_profiles()] == [existing]
        assert db.get_source_profile(existing)['payload'] == payload
        db.conn.execute('DROP TRIGGER reject_profile_insert')
        assert db.save_source_profile('Works again', payload) != existing


def test_failed_schema_two_migration_preserves_schema_one_and_existing_records(tmp_path):
    path = tmp_path / 'conflicting.sqlite'
    with closing(sqlite3.connect(path)) as conn, conn:
        conn.execute('CREATE TABLE source_profiles(legacy_value TEXT)')
        conn.execute("INSERT INTO source_profiles VALUES('keep custom legacy table')")
        conn.execute('PRAGMA user_version=1')
    with pytest.raises(SchemaMigrationError, match='migration failed'):
        LibraryDB(path)
    with closing(sqlite3.connect(path)) as conn, conn:
        assert conn.execute('PRAGMA user_version').fetchone()[0] == 1
        assert conn.execute('SELECT * FROM source_profiles').fetchall() == [('keep custom legacy table',)]
        assert conn.execute("SELECT name FROM sqlite_master WHERE type='index'").fetchall() == []
