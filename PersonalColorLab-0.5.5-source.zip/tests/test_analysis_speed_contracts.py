"""Faster local measurements retain color support and trusted input evidence."""
import hashlib
import json
import threading

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core import reference_analysis as reference
from personal_color_lab.core import source_workflow, scene_analysis
from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.color_analysis import analyze_color
from personal_color_lab.core.database import LibraryDB


def photo(path, color=(105, 135, 175)):
    Image.new('RGB', (160, 120), color).save(path, quality=95)
    return path


def test_byte_palette_and_weighted_reference_palette_keep_exact_proportions():
    colors = np.array([[230, 30, 30], [230, 30, 30], [30, 30, 230], [250, 250, 250]], np.uint8)
    palette = reference._palette(colors, np.array([.1, .1, .6, .2]))
    assert {item['hex']: item['fraction'] for item in palette} == pytest.approx({
        '#E61E1E': .2, '#1E1EE6': .6, '#FAFAFA': .2,
    })
    assert reference._palette(colors) == reference._palette(colors.astype(np.float64), np.ones(4))


def test_opposed_color_rotations_remain_ambiguous_in_global_and_red_band():
    hsv = np.full((40, 40, 3), [350, .8, .7], dtype=np.float32)
    changed = hsv.copy()
    changed[:20, :, 0] = 80
    changed[20:, :, 0] = 260
    rgb = lambda values: np.rint(cv2.cvtColor(values, cv2.COLOR_HSV2RGB)*255).astype(np.uint8)
    report = analyze_color(rgb(hsv), rgb(changed), np.ones((40, 40), bool))
    assert report['hsv']['hue_delta_degrees'] is None
    assert report['hue_bands']['red']['hue_delta_degrees'] is None
    assert report['hue_bands']['red']['sample_count'] == 1600
    json.dumps(report, allow_nan=False)


def test_expected_fingerprint_is_verified_after_analysis_and_original_untouched(tmp_path):
    path = photo(tmp_path / 'image.jpg')
    original = path.read_bytes()
    expected = hashlib.sha256(original).hexdigest()
    payload = reference.analyze_reference(path, expected_fingerprint=expected)
    assert payload['provenance']['input_fingerprints']['original'] == expected
    assert path.read_bytes() == original
    photo(path, (40, 70, 120))
    with pytest.raises(ValueError, match='changed during analysis'):
        reference.analyze_reference(path, expected_fingerprint=expected)


@pytest.mark.parametrize('fingerprint', ['', True, 'a'*63, 'G'*64, 'a'*65])
def test_invalid_expected_fingerprint_cannot_be_saved(tmp_path, fingerprint):
    with pytest.raises(ValueError, match='fingerprint'):
        reference.analyze_reference(photo(tmp_path / 'image.jpg'), expected_fingerprint=fingerprint)


def test_reference_cancelled_after_decode_skips_statistics_and_recognition(tmp_path, monkeypatch):
    path = photo(tmp_path / 'image.jpg')
    cancel = threading.Event()
    read = reference._read_rgb
    def stop_after_decode(*args):
        result = read(*args)
        cancel.set()
        return result
    monkeypatch.setattr(reference, '_read_rgb', stop_after_decode)
    monkeypatch.setattr(reference, '_appearance', lambda *a, **k: pytest.fail('Measured a cancelled photo'))
    monkeypatch.setattr(scene_analysis, 'analyze_evidence', lambda *a, **k: pytest.fail('Recognized a cancelled photo'))
    with pytest.raises(AnalysisCancelledError):
        reference.analyze_reference(path, cancel_event=cancel)


def test_batch_cancel_inside_photo_keeps_previous_evidence_without_failure(tmp_path, monkeypatch):
    photo(tmp_path / 'a.jpg')
    photo(tmp_path / 'b.jpg', (90, 85, 120))
    photo(tmp_path / 'c.jpg', (150, 95, 120))
    cancel = threading.Event()
    read = reference._read_rgb
    def stop_second(source, size):
        pixels = read(source, size)
        if source.name == 'b.jpg':
            cancel.set()
        return pixels
    monkeypatch.setattr(reference, '_read_rgb', stop_second)
    batch = source_workflow.analyze_inputs(source_workflow.discover_inputs(tmp_path, 'reference_jpg')['items'],
                                           'reference_jpg', cancel_event=cancel)
    assert batch['status'] == 'cancelled'
    assert batch['counts'] == {'total': 3, 'processed': 1, 'successful': 1, 'failed': 0,
                               'skipped': 0, 'cancelled': 2, 'duplicates': 0}
    assert len(batch['results']) == batch['summary']['sample_count'] == 1
    with LibraryDB(tmp_path / 'library.db') as db:
        assert db.save_source_profile('Retained complete evidence', batch) > 0
