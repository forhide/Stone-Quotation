"""Cancellation crosses real RAW decoding and preserves completed batch work."""
import threading

import numpy as np
from PIL import Image
import pytest
import rawpy

from personal_color_lab.core import edit_reverse,source_workflow
from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng


def _pair(folder,name,seed):
    raw=write_test_dng(folder/f'{name}.dng',seed=seed)
    pixels,_,_=decode_raw(raw)
    edited=folder/f'{name}.jpg'
    Image.fromarray(np.clip(pixels.astype(np.float32)*1.03+2,0,255).astype(np.uint8)).save(edited,quality=98,subsampling=0)
    return raw,edited


def _cancel_native_unpack(monkeypatch,stop,cancel_on=1):
    native=rawpy.RawPy
    calls={'unpack':0,'postprocess':0,'closed':0}
    class ControlledRaw:
        def __init__(self):
            self.raw=native()
        def __enter__(self):
            return self
        def __exit__(self,*args):
            self.raw.close()
            calls['closed']+=1
        def __getattr__(self,name):
            return getattr(self.raw,name)
        def unpack(self):
            self.raw.unpack()
            calls['unpack']+=1
            if calls['unpack']==cancel_on:
                stop.set()
        def postprocess(self,**kwargs):
            calls['postprocess']+=1
            assert not stop.is_set(),'Cancelled sensor was still demosaiced'
            return self.raw.postprocess(**kwargs)
    monkeypatch.setattr(rawpy,'RawPy',ControlledRaw)
    return calls


def test_pair_cancellation_after_real_sensor_unpack_skips_demosaic(tmp_path,monkeypatch):
    raw,edited=_pair(tmp_path,'photo',17)
    before={path:path.read_bytes() for path in (raw,edited)}
    stop=threading.Event()
    calls=_cancel_native_unpack(monkeypatch,stop)
    with pytest.raises(AnalysisCancelledError):
        edit_reverse.analyze_pair(raw,edited,cancel_event=stop)
    assert calls=={'unpack':1,'postprocess':0,'closed':1}
    assert all(path.read_bytes()==content for path,content in before.items())


def test_raw_pair_batch_retains_completed_evidence_when_next_sensor_is_cancelled(tmp_path,monkeypatch):
    _pair(tmp_path,'01-complete',17)
    _pair(tmp_path,'02-cancel',31)
    discovered=source_workflow.discover_inputs(tmp_path,'raw_jpg')
    assert len(discovered['items'])==2
    stop=threading.Event()
    calls=_cancel_native_unpack(monkeypatch,stop,cancel_on=2)
    batch=source_workflow.analyze_inputs(discovered['items'],'raw_jpg',cancel_event=stop)
    assert calls=={'unpack':2,'postprocess':1,'closed':2}
    assert batch['status']=='cancelled'
    assert batch['counts']['total']==2 and batch['counts']['processed']==1
    assert batch['counts']['successful']==1 and batch['counts']['failed']==0
    assert batch['counts']['cancelled']==1 and len(batch['results'])==1
    payload=batch['results'][0]['payload']
    assert payload['status']=='ok' and payload['provenance']['raw_baseline']['quality_used']=='baseline'
    assert payload['original_path'].endswith('01-complete.dng')
    with LibraryDB(tmp_path/'completed.db') as db:
        profile=db.save_source_profile('Completed RAW pair',batch)
        assert profile
        saved=db.get_source_profile(profile)
        assert saved['payload']['counts']['successful']==1
        assert saved['payload']['results'][0]['payload']['status']=='ok'


def test_pair_cancelled_after_alignment_never_starts_tone_or_object_inference(tmp_path,monkeypatch):
    raw,edited=_pair(tmp_path,'photo',17)
    stop=threading.Event();align=edit_reverse.align_images
    def cancel_after_alignment(*args,**kwargs):
        result=align(*args,**kwargs)
        stop.set()
        return result
    monkeypatch.setattr(edit_reverse,'align_images',cancel_after_alignment)
    monkeypatch.setattr(edit_reverse,'analyze_tone',lambda *args:pytest.fail('Analyzed cancelled alignment'))
    with pytest.raises(AnalysisCancelledError):
        edit_reverse.analyze_pair(raw,edited,cancel_event=stop)


def test_cancelled_pair_does_no_input_hashing_or_decoding(tmp_path,monkeypatch):
    stop=threading.Event();stop.set()
    monkeypatch.setattr(edit_reverse,'file_fingerprint',lambda *args:pytest.fail('Hashed cancelled input'))
    monkeypatch.setattr(edit_reverse,'align_images',lambda *args,**kwargs:pytest.fail('Decoded cancelled input'))
    with pytest.raises(AnalysisCancelledError):
        edit_reverse.analyze_pair(tmp_path/'absent.dng',tmp_path/'absent.jpg',cancel_event=stop)
