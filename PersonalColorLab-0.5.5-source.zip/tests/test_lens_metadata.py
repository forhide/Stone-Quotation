"""Bounded equipment EXIF extraction uses generated headers, no real photos."""
import hashlib
import json
from pathlib import Path
import struct
import sys
from threading import Event

import numpy as np
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core import lens_metadata as metadata
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng


EQUIPMENT = dict(camera_make="Canon", camera_model="Canon EOS 5D Mark II",
                 lens_make="Canon", lens_model="Canon EF 17-40mm f/4L USM",
                 focal_length_mm=17.0, aperture=4.0)


def _text(value):
    return 2, value.encode("utf8") + b"\0"


def _rational(numerator, denominator=1):
    return 5, (numerator, denominator)


def _tiff(tags=None, *, endian="<", magic=42, offset_base=0):
    tags = dict(tags or {})
    extra = bytearray()
    table = bytearray(struct.pack(endian + "H", len(tags)))
    data_start = offset_base + 8 + 2 + 12 * len(tags) + 4
    sizes = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 10: 8, 11: 4, 12: 8}
    for tag, (kind, value) in sorted(tags.items()):
        if kind == 3:
            data = struct.pack(endian + "H", value)
        elif kind == 4:
            data = struct.pack(endian + "I", value)
        elif kind in (5, 10):
            data = struct.pack(endian + ("II" if kind == 5 else "ii"), *value)
        elif kind in (11, 12):
            data = struct.pack(endian + ("f" if kind == 11 else "d"), value)
        else:
            data = value(data_start + len(extra)) if callable(value) else value
        count = len(data) // sizes[kind]
        if len(data) > 4:
            encoded = struct.pack(endian + "I", data_start + len(extra))
            extra.extend(data)
            extra.extend(b"\0" * (len(extra) % 2))
        else:
            encoded = data.ljust(4, b"\0")
        table.extend(struct.pack(endian + "HHI", tag, kind, count) + encoded)
    table.extend(struct.pack(endian + "I", 0))
    return (b"II" if endian == "<" else b"MM") + struct.pack(endian + "HI", magic, 8) + table + extra


def _tiff_with_exif(image_tags, exif_tags):
    root = _tiff({**image_tags, 0x8769: (4, 0)})
    result = bytearray(root)
    for index in range(len(image_tags) + 1):
        entry = 10 + 12 * index
        if struct.unpack_from("<H", result, entry)[0] == 0x8769:
            struct.pack_into("<I", result, entry + 8, len(root))
            break
    result.extend(_tiff(exif_tags, offset_base=len(root) - 8)[8:])
    return bytes(result)


def _equipment_tags():
    return {0x010F: _text(EQUIPMENT["camera_make"]), 0x0110: _text(EQUIPMENT["camera_model"]),
            0xA433: _text(EQUIPMENT["lens_make"]), 0xA434: _text(EQUIPMENT["lens_model"]),
            0x920A: _rational(170, 10), 0x829D: _rational(4), 0x0112: (3, 6)}


def _write(tmp_path, content, suffix=".dng"):
    path = tmp_path / ("equipment" + suffix)
    path.write_bytes(content)
    return path


def _box(kind, data, *, extended=False):
    if extended:
        return struct.pack(">I4sQ", 1, kind, len(data) + 16) + data
    return struct.pack(">I4s", len(data) + 8, kind) + data


@pytest.mark.parametrize("orientation", (1, 3, 5, 6, 8))
def test_real_generated_bayer_dng_reads_standard_equipment_and_keeps_source(tmp_path, orientation):
    source = write_test_dng(tmp_path / "camera.dng", equipment=EQUIPMENT, orientation=orientation)
    before = hashlib.sha256(source.read_bytes()).digest()
    result = metadata.read_lens_metadata(source)
    for field, value in EQUIPMENT.items():
        assert result[field] == value
    assert result["orientation"] == orientation
    assert result["metadata_status"] == "ok"
    assert result["extractor_version"] == "3.5.1"
    assert result["crop_factor"] is result["crop_factor_source"] is None
    assert not result["embedded_dng_opcodes_present"]
    pixels, _, _ = decode_raw(source, max_dimension=120)
    assert pixels.dtype == np.uint8 and pixels.ndim == 3
    assert hashlib.sha256(source.read_bytes()).digest() == before
    json.dumps(result, allow_nan=False)


def test_default_diagnostic_dng_bytes_remain_identical_to_v053(tmp_path):
    source = write_test_dng(tmp_path / "camera.dng")
    assert hashlib.sha256(source.read_bytes()).hexdigest() == "6f04c89975cf87f2ea4acf486e64a81856deeece436574e8a207457269210169"


@pytest.mark.parametrize("lens_model", ("FE 16-35mm F2.8 GM II", "FE 16-35mm F2.8 GM"))
def test_sony_a7cr_standard_raw_equipment_keeps_lens_generations_distinct(tmp_path, lens_model):
    equipment = dict(camera_make="SONY", camera_model="ILCE-7CR", lens_make="Sony",
                     lens_model=lens_model, focal_length_mm=16.0, aperture=2.8)
    source = write_test_dng(tmp_path / "sony.arw", equipment=equipment)
    result = metadata.read_lens_metadata(source)
    assert result["camera_make"] == "SONY" and result["camera_model"] == "ILCE-7CR"
    assert result["lens_model"] == lens_model
    assert result["metadata_sources"]["lens_model"] == "raw_exif"
    assert result["focal_length_mm"] == 16.0 and result["aperture"] == 2.8
    assert result["metadata_status"] == "ok"
    assert result["crop_factor"] is None


def test_numeric_sony_maker_lens_id_without_standard_model_stays_unknown(tmp_path):
    tags = _equipment_tags()
    tags[0x010F] = _text("SONY")
    tags[0x0110] = _text("ILCE-7CR")
    tags.pop(0xA434)
    # A vendor identifier alone does not distinguish calibrated lens variants.
    # Its raw bytes are not returned or interpreted as a readable lens model.
    maker = struct.pack("<HHHI", 1, 0xB027, 3, 1) + struct.pack("<H", 3300) + b"\0" * 6
    tags[0x927C] = 7, maker
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags), ".arw"))
    assert result["camera_model"] == "ILCE-7CR" and result["lens_model"] is None
    assert result["metadata_status"] == "partial"
    assert "lens_model_unavailable" in result["warnings"]
    assert "3300" not in json.dumps(result)


@pytest.mark.parametrize("suffix,endian,magic", [
    (".cr2", "<", 42), (".nef", ">", 42), (".arw", "<", 42),
    (".pef", "<", 42), (".srw", "<", 42), (".nrw", ">", 42),
    (".orf", "<", 0x4F52), (".orf", "<", 0x5352), (".rw2", "<", 85),
])
def test_tiff_family_container_headers_share_bounded_equipment_layout(tmp_path, suffix, endian, magic):
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(_equipment_tags(), endian=endian, magic=magic), suffix))
    assert result["metadata_status"] == "ok"
    assert result["lens_model"] == EQUIPMENT["lens_model"]
    assert result["focal_length_mm"] == 17.0
    assert result["orientation"] == 6


def test_raf_reads_only_embedded_exif_and_can_use_explicit_camera_header(tmp_path):
    tags = _equipment_tags()
    del tags[0x010F], tags[0x0110]
    tiff = _tiff(tags, endian=">")
    jpeg = b"\xff\xd8\xff\xe1" + struct.pack(">H", len(tiff) + 8) + b"Exif\0\0" + tiff + b"\xff\xd9"
    raf = bytearray(160)
    raf[:16] = b"FUJIFILMCCD-RAW " + b"\0"
    raf[28:33] = b"X-T50"
    struct.pack_into(">II", raf, 84, len(raf), len(jpeg))
    result = metadata.read_lens_metadata(_write(tmp_path, bytes(raf) + jpeg, ".raf"))
    assert result["camera_make"] == "FUJIFILM" and result["camera_model"] == "X-T50"
    assert result["lens_model"] == EQUIPMENT["lens_model"]
    assert result["metadata_sources"]["lens_model"] == "raf_embedded_exif"
    assert result["metadata_sources"]["camera_model"] == "raf_camera_header"


@pytest.mark.parametrize("extended", (False, True))
def test_cr3_canon_uuid_reads_cmt1_and_cmt2_skips_gps_and_pixel_payload(tmp_path, extended):
    tags = _equipment_tags()
    image = {tag: value for tag, value in tags.items() if tag in (0x010F, 0x0110, 0x0112)}
    exif = {tag: value for tag, value in tags.items() if tag not in image}
    cmt = _box(b"CMT1", _tiff(image)) + _box(b"CMT2", _tiff(exif, endian=">"))
    # Invalid CMT4/GPS framing would fail if it were parsed.
    cmt += _box(b"CMT4", b"GPS-LATITUDE-SECRET-AND-INVALID-TIFF")
    data = _box(b"ftyp", b"crx \0\0\0\0crx ")
    data += _box(b"moov", _box(b"uuid", metadata._CANON_UUID + cmt, extended=extended))
    data += _box(b"mdat", b"NEVER-PARSE-SENSOR-DATA" * 1000)
    result = metadata.read_lens_metadata(_write(tmp_path, data, ".cr3"))
    assert result["metadata_status"] == "ok"
    assert result["camera_model"] == EQUIPMENT["camera_model"]
    assert result["lens_model"] == EQUIPMENT["lens_model"]
    assert result["metadata_sources"]["camera_model"] == "cr3_cmt1"
    assert result["metadata_sources"]["focal_length_mm"] == "cr3_cmt2"
    assert "SECRET" not in json.dumps(result)


def test_canon_explicit_maker_lens_model_fallback_standard_model_wins(tmp_path):
    maker_name = "Canon EF 50mm f/1.8 II"

    def maker(offset):
        name = maker_name.encode() + b"\0"
        return struct.pack("<HHHI", 1, 0x0095, 2, len(name)) + struct.pack("<I", offset + 18) + b"\0" * 4 + name

    tags = _equipment_tags()
    tags.pop(0xA434)
    tags[0x927C] = (7, maker)
    image_tags = {tag: tags.pop(tag) for tag in (0x010F, 0x0110, 0x0112)}
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff_with_exif(image_tags, tags), ".cr2"))
    assert result["lens_model"] == maker_name
    assert result["metadata_sources"]["lens_model"] == "canon_makernote"
    tags[0xA434] = _text(EQUIPMENT["lens_model"])
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff_with_exif(image_tags, tags), ".cr2"))
    assert result["lens_model"] == EQUIPMENT["lens_model"]
    assert result["metadata_sources"]["lens_model"] == "raw_exif"


@pytest.mark.parametrize("lens", ("", "Unknown", "Unknown (124)", "0x0019", "124", "[1, 2, 3]", "Manual lens"))
def test_numeric_or_unidentified_lenses_do_not_turn_into_profile_identity(tmp_path, lens):
    tags = _equipment_tags()
    tags[0xA434] = _text(lens)
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["lens_model"] is None
    assert result["metadata_status"] == "partial"
    assert "lens_model_unavailable" in result["warnings"]


@pytest.mark.parametrize("numerator,denominator", ((0, 1), (1, 0), (1, 100), (5001, 1)))
def test_invalid_focal_rationals_are_missing_not_guessed(tmp_path, numerator, denominator):
    tags = _equipment_tags()
    tags[0x920A] = _rational(numerator, denominator)
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["focal_length_mm"] is None
    assert "lens_focal_length_unavailable" in result["warnings"]
    json.dumps(result, allow_nan=False)


@pytest.mark.parametrize("kind,value", ((11, 17.0), (12, 17.0), (11, float("nan")), (12, float("inf"))))
def test_float_equipment_numbers_are_finite_and_validated(tmp_path, kind, value):
    tags = _equipment_tags()
    tags[0x920A] = kind, value
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["focal_length_mm"] == (17.0 if value == 17.0 else None)
    json.dumps(result, allow_nan=False)


def test_apex_aperture_fallback_does_not_infer_sensor_crop_from_35mm_focal(tmp_path):
    tags = _equipment_tags()
    del tags[0x829D]
    tags[0x9202] = _rational(4)
    tags[0xA405] = (3, 26)
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["aperture"] == 4.0
    assert result["crop_factor"] is None and result["crop_factor_source"] is None


def test_private_fields_and_broken_gps_pointer_are_never_parsed_or_returned(tmp_path):
    tags = _equipment_tags()
    tags.update({0x8825: (4, 0xFFFFFFFF), 0xA435: _text("lens-serial-secret"),
                 0xA431: _text("camera-serial-secret"), 0xA430: _text("owner-secret"),
                 0x0132: _text("date-secret"), 0x8298: _text("copyright-secret")})
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["metadata_status"] == "ok" and not result["warnings"]
    assert "secret" not in json.dumps(result).lower()
    assert not any("gps" in key.lower() or "serial" in key.lower() for key in result)


def test_long_or_control_character_equipment_strings_are_bounded(tmp_path):
    tags = _equipment_tags()
    tags[0x010F] = _text("  Canon\n\t ")
    tags[0xA434] = _text("X" * (metadata.MAX_TEXT_BYTES + 1))
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["camera_make"] == "Canon"
    assert result["lens_model"] is None
    assert "equipment_text_invalid" in result["warnings"]


@pytest.mark.parametrize("content", (b"", b"II*\0", b"not-a-raw-header", b"II+\0\x08\0\0\0", b"II*\0\xff\xff\xff\xff"))
def test_malformed_or_unsupported_headers_are_nonfatal_auxiliary_metadata(tmp_path, content):
    result = metadata.read_lens_metadata(_write(tmp_path, content))
    assert result["metadata_status"] == "unavailable"
    assert result["warnings"]
    json.dumps(result, allow_nan=False)


def test_malformed_optional_ifd_retains_valid_root_equipment(tmp_path):
    tags = _equipment_tags()
    tags[0x8769] = (4, 0xFFFFFF00)
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["camera_model"] == EQUIPMENT["camera_model"]
    assert result["lens_model"] == EQUIPMENT["lens_model"]
    assert "equipment_metadata_unreadable" in result["warnings"]


def test_metadata_read_and_entry_budgets_prevent_unbounded_work(tmp_path, monkeypatch):
    tags = _equipment_tags()
    path = _write(tmp_path, _tiff(tags))
    monkeypatch.setattr(metadata, "MAX_METADATA_BYTES", 30)
    result = metadata.read_lens_metadata(path)
    assert "equipment_metadata_limit" in result["warnings"]
    monkeypatch.setattr(metadata, "MAX_METADATA_BYTES", 2 * 1024 * 1024)
    path.write_bytes(b"II*\0\x08\0\0\0" + struct.pack("<H", 65535))
    assert "equipment_metadata_limit" in metadata.read_lens_metadata(path)["warnings"]


@pytest.mark.parametrize("opcode_id", (1, 2, 6))
def test_dng_opcode_presence_is_not_confused_with_known_geometric_warp(tmp_path, opcode_id):
    tags = _equipment_tags()
    data = struct.pack(">IIIII", 1, opcode_id, 0x01030000, 1, 0)
    tags[0xC741] = (7, data)
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["embedded_dng_opcodes_present"]
    assert result["embedded_distortion"] is (opcode_id in (1, 2))


def test_real_synthetic_dng_embedded_identity_warp_is_only_a_guard(tmp_path):
    source = write_test_dng(tmp_path / "camera.dng", equipment=EQUIPMENT, embedded_geometry=True)
    result = metadata.read_lens_metadata(source)
    assert result["embedded_dng_opcodes_present"] and result["embedded_distortion"]
    assert result["metadata_status"] == "ok"


def test_malformed_opcode_list_still_signals_embedded_instructions_without_claiming_correction(tmp_path):
    tags = _equipment_tags()
    tags[0xC741] = 7, struct.pack(">IIIII", 1, 1, 0x01030000, 1, 0xFFFFFFFF)
    result = metadata.read_lens_metadata(_write(tmp_path, _tiff(tags)))
    assert result["embedded_dng_opcodes_present"]
    assert not result["embedded_distortion"]
    assert "embedded_dng_opcodes_unreadable" in result["warnings"]
    assert result["lens_model"] == EQUIPMENT["lens_model"]


def test_declared_maker_note_length_does_not_read_whole_sensor_or_blob(tmp_path, monkeypatch):
    tags = _equipment_tags()
    tags[0x927C] = 7, b"ignored-maker-note"
    payload = bytearray(_tiff(tags))
    count = struct.unpack_from("<H", payload, 8)[0]
    for index in range(count):
        entry = 10 + 12 * index
        if struct.unpack_from("<H", payload, entry)[0] == 0x927C:
            struct.pack_into("<I", payload, entry + 4, 0xFFFFFFFF)
            break
    reads = []
    original = metadata._BoundedReader.read

    def read(self, size=-1):
        reads.append(size)
        return original(self, size)

    monkeypatch.setattr(metadata._BoundedReader, "read", read)
    result = metadata.read_lens_metadata(_write(tmp_path, payload))
    assert result["lens_model"] == EQUIPMENT["lens_model"]
    assert "maker_note_unsupported" in result["warnings"]
    assert max(reads) <= metadata.MAX_TEXT_BYTES


def test_precancelled_metadata_does_not_even_open_missing_input():
    event = Event()
    event.set()
    with pytest.raises(AnalysisCancelledError):
        metadata.read_lens_metadata(Path("/missing-camera-file.dng"), cancel_event=event)


def test_cancellation_during_sparse_reads_propagates_instead_of_metadata_warning(tmp_path, monkeypatch):
    path = _write(tmp_path, _tiff(_equipment_tags()))
    event = Event()
    original = metadata._BoundedReader.read

    def read(self, size=-1):
        value = original(self, size)
        if self.operations >= 6:
            event.set()
        return value

    monkeypatch.setattr(metadata._BoundedReader, "read", read)
    with pytest.raises(AnalysisCancelledError):
        metadata.read_lens_metadata(path, cancel_event=event)
    path.rename(tmp_path / "closed-reader.dng")


def test_missing_extractor_does_not_block_baseline_raw_reader(tmp_path, monkeypatch):
    source = write_test_dng(tmp_path / "camera.dng", equipment=EQUIPMENT)
    monkeypatch.setitem(sys.modules, "exifread", None)
    result = metadata.read_lens_metadata(source)
    assert result["metadata_status"] == "unavailable"
    assert result["warnings"] == ["equipment_reader_unavailable"]
    pixels, _, _ = decode_raw(source, 120)
    assert pixels.dtype == np.uint8
