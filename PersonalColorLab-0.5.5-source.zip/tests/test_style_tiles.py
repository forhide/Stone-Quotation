"""Style suggestions preview the current photograph without decoding again."""
import copy
import threading

import numpy as np
import pytest

from personal_color_lab.core.style_dna import identity_dna,builtin_styles
from personal_color_lab.core.style_render import _measure
from personal_color_lab.ui.style_tiles import build_style_tiles


def _preview():
    pixels=np.random.default_rng(52).integers(20,220,(800,1200,3),dtype='uint8')
    return {'original':pixels,'measurement':_measure(pixels),'scene':None}


def test_style_tiles_are_bounded_photo_derived_arrays_and_keep_the_source(monkeypatch):
    from personal_color_lab.core import scene_analysis,style_render
    monkeypatch.setattr(scene_analysis,'analyze_scene',lambda *a,**k:pytest.fail('Inferred twice'))
    monkeypatch.setattr(style_render,'read_photo',lambda *a,**k:pytest.fail('Decoded twice'))
    preview=_preview();before=copy.deepcopy(preview)
    styles={str(i):style for i,style in enumerate(builtin_styles())}
    tiles=build_style_tiles(preview,styles)
    assert len(tiles)==3 and all(tile['pixels'].shape==(50,70,3) for tile in tiles)
    assert all(tile['pixels'].dtype==np.uint8 and tile['key'] in styles for tile in tiles)
    assert np.array_equal(preview['original'],before['original'])
    assert preview['measurement']==before['measurement']
    assert not np.array_equal(tiles[0]['pixels'],tiles[1]['pixels'])


def test_style_tiles_keep_monochrome_and_respect_cancel():
    preview=_preview();style=identity_dna('B&W');style['saturation_scale']=0
    tiles=build_style_tiles(preview,{'monochrome':style},strength=1.)
    assert np.ptp(tiles[0]['pixels'].astype(int),axis=2).max()==0
    stop=threading.Event();stop.set()
    with pytest.raises(ValueError,match='cancelled'):build_style_tiles(preview,{'monochrome':style},stop)
