"""Content reuse, persistence and cache corruption must preserve input identity."""
import copy
import shutil
import numpy as np
from PIL import Image
import pytest
from personal_color_lab.core.database import LibraryDB, AnalysisValidationError
from personal_color_lab.core.source_workflow import discover_inputs, analyze_inputs
from personal_color_lab.core.analysis_cache import cache_key
from personal_color_lab.core.style_dna import builtin_styles


def photos(tmp_path):
    folder=tmp_path/'photos';folder.mkdir()
    rng=np.random.default_rng(23)
    for i in range(3):
        Image.fromarray(rng.integers(20,210,(100,150,3),dtype='uint8')).save(folder/f'{i}.jpg')
    shutil.copyfile(folder/'0.jpg',folder/'duplicate.jpg')
    return folder


def test_content_cache_avoids_decoding_duplicates_and_repeated_inputs(tmp_path, monkeypatch):
    folder=photos(tmp_path)
    items=discover_inputs(folder,'reference_jpg')['items']
    with LibraryDB(tmp_path/'db.sqlite') as db:
        first=analyze_inputs(items,'reference_jpg',cache=db)
        assert first['counts']['successful']==3
        assert first['counts']['duplicates']==1
        assert first['performance']['avoided_duplicate_decodes']==1
        monkeypatch.setattr('personal_color_lab.core.source_workflow.analyze_reference',lambda *a:pytest.fail('Decoded a cached photograph'))
        again=analyze_inputs(items,'reference_jpg',cache=db)
        assert again['status']=='ok'
        assert again['performance']['cache_hits']==3
        assert again['summary']==first['summary']
        moved=tmp_path/'moved';shutil.copytree(folder,moved)
        relocated=analyze_inputs(discover_inputs(moved,'reference_jpg')['items'],'reference_jpg',cache=db)
        assert relocated['performance']['cache_hits']==3
        assert all(str(moved) in row['payload']['original_path'] for row in relocated['results'] if row['status']=='ok')


def test_invalid_cache_is_evicted_and_input_change_reanalyzed(tmp_path):
    folder=photos(tmp_path)
    items=discover_inputs(folder,'reference_jpg')['items'][:1]
    with LibraryDB(tmp_path/'db.sqlite') as db:
        result=analyze_inputs(items,'reference_jpg',cache=db)
        payload=result['results'][0]['payload'];key=cache_key('reference_jpg',payload['provenance']['input_fingerprints'])
        db.conn.execute('UPDATE analysis_cache SET payload_json=? WHERE cache_key=?',('{"status":"ok"}',key));db.conn.commit()
        assert db.get_cached_analysis(key) is None
        assert db.conn.execute('SELECT count(*) FROM analysis_cache').fetchone()[0]==0
        Image.new('RGB',(150,100),'red').save(folder/'0.jpg')
        changed=analyze_inputs(items,'reference_jpg',cache=db)
        assert changed['performance']['cache_hits']==0
        assert changed['results'][0]['payload']['provenance']['input_fingerprints']!=payload['provenance']['input_fingerprints']


@pytest.mark.parametrize('limit',[0,-1,True,5001,1.5])
def test_invalid_cache_limit_rejected(tmp_path,limit):
    folder=photos(tmp_path)
    payload=analyze_inputs(discover_inputs(folder,'reference_jpg')['items'][:1],'reference_jpg')['results'][0]['payload']
    with LibraryDB(tmp_path/'db.sqlite') as db:
        with pytest.raises(AnalysisValidationError):db.cache_analysis('a'*64,payload,limit=limit)


def test_lru_bounds_and_style_recipes_survive_reopening(tmp_path):
    folder=photos(tmp_path);path=tmp_path/'db.sqlite'
    result=analyze_inputs(discover_inputs(folder,'reference_jpg')['items'],'reference_jpg')
    with LibraryDB(path) as db:
        for row in result['results']:
            if row['status']=='ok':
                p=row['payload'];db.cache_analysis(cache_key('reference_jpg',p['provenance']['input_fingerprints']),p,limit=2)
        assert db.conn.execute('SELECT count(*) FROM analysis_cache').fetchone()[0]==2
        dna=builtin_styles()[0];identifier=db.save_style_preset('내 스타일',dna)
    with LibraryDB(path) as db:
        assert db.get_style_preset(identifier)['dna']==dna
        assert db.list_style_presets()==[{'id':identifier,'name':'내 스타일'}]
        assert db.conn.execute('PRAGMA user_version').fetchone()[0]==3


def test_cache_refuses_invalid_measurements_and_gps(tmp_path):
    folder=photos(tmp_path)
    payload=analyze_inputs(discover_inputs(folder,'reference_jpg')['items'][:1],'reference_jpg')['results'][0]['payload']
    with LibraryDB(tmp_path/'db.sqlite') as db:
        invalid=copy.deepcopy(payload);invalid['appearance']['palette'][0]['rgb'][0]=999
        with pytest.raises(AnalysisValidationError):db.cache_analysis('a'*64,invalid)
        invalid=copy.deepcopy(payload);invalid['gpsLatitude']=32
        with pytest.raises(AnalysisValidationError):db.cache_analysis('a'*64,invalid)


def test_xmp_cache_relocates_both_companion_paths(tmp_path,monkeypatch):
    folder=tmp_path/'original';folder.mkdir()
    (folder/'photo.dng').write_bytes(b'RAW association: metadata analysis does not decode')
    (folder/'photo.xmp').write_text('<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" crs:Exposure2012="0.5"/>')
    with LibraryDB(tmp_path/'db.sqlite') as db:
        first=analyze_inputs(discover_inputs(folder,'raw_xmp')['items'],'raw_xmp',cache=db)
        assert first['status']=='ok'
        moved=tmp_path/'moved';shutil.copytree(folder,moved)
        monkeypatch.setattr('personal_color_lab.core.source_workflow.analyze_raw_xmp',lambda *a:pytest.fail('Decoded cached metadata'))
        reused=analyze_inputs(discover_inputs(moved,'raw_xmp')['items'],'raw_xmp',cache=db)
        assert reused['performance']['cache_hits']==1
        assert reused['results'][0]['payload']['source_paths']=={'raw':str(moved/'photo.dng'),'xmp':str(moved/'photo.xmp')}


def test_similar_photos_are_reviewed_but_never_automatically_excluded(tmp_path):
    folder=tmp_path/'similar';folder.mkdir()
    y,x=np.indices((160,240));pixels=np.stack([40+x//2,70+y//3,80+x//4],axis=2).astype('uint8')
    Image.fromarray(pixels).save(folder/'a.jpg',quality=98)
    Image.fromarray(pixels+2).save(folder/'b.jpg',quality=98)
    batch=analyze_inputs(discover_inputs(folder,'reference_jpg')['items'],'reference_jpg')
    assert batch['counts']['successful']==2 and batch['counts']['duplicates']==0
    assert batch['summary']['similar_groups']
    assert batch['summary']['sample_count']==2


def test_cache_cannot_relabel_evidence_from_different_content(tmp_path):
    import json
    folder=photos(tmp_path);items=discover_inputs(folder,'reference_jpg')['items'][:1]
    with LibraryDB(tmp_path/'db.sqlite') as db:
        first=analyze_inputs(items,'reference_jpg',cache=db)
        payload=first['results'][0]['payload'];key=cache_key('reference_jpg',payload['provenance']['input_fingerprints'])
        wrong=copy.deepcopy(payload);wrong['provenance']['input_fingerprints']['original']='f'*64
        db.conn.execute('UPDATE analysis_cache SET payload_json=? WHERE cache_key=?',(json.dumps(wrong),key));db.conn.commit()
        repaired=analyze_inputs(items,'reference_jpg',cache=db)
        assert repaired['performance']['cache_hits']==0
        assert repaired['results'][0]['payload']['provenance']['input_fingerprints']==payload['provenance']['input_fingerprints']
