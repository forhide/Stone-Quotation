"""RAW integration tests exercise real LibRaw on a synthetic Bayer DNG."""
import hashlib
import json
from pathlib import Path
import socket

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.alignment import align_images
from personal_color_lab.core.edit_reverse import analyze_pair
from personal_color_lab.core.raw_decode import decode_raw
from raw_fixtures import write_test_dng


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _edited(raw: Path, jpg: Path) -> None:
    pixels, _, _ = decode_raw(raw)
    edited = np.clip(pixels.astype(np.float32) * 1.08 + [8, 2, -3], 0, 255).astype(np.uint8)
    Image.fromarray(edited).save(jpg, quality=98, subsampling=0)


def test_real_libraw_decode_is_bounded_oriented_and_preserves_source(tmp_path, monkeypatch):
    raw = write_test_dng(tmp_path / "sensor.dng", orientation=6)
    before = _hash(raw)

    def reject_network(*args, **kwargs):
        raise AssertionError("RAW decoding must stay offline")

    monkeypatch.setattr(socket, "socket", reject_network)
    pixels, original_size, metadata = decode_raw(raw, max_dimension=96)
    assert pixels.shape == (96, 72, 3)
    assert pixels.dtype == np.uint8
    assert original_size == (360, 480)
    assert metadata["decoder"] == "rawpy_libraw"
    assert metadata["rawpy_version"]
    assert metadata["libraw_version"]
    assert metadata["white_balance_source"] == "camera"
    assert metadata["auto_brightness"] is False
    assert metadata["auto_white_balance"] is False
    assert metadata["output_color_space"] == "sRGB"
    assert metadata["gamma"] == [2.4, 12.92]
    assert metadata["embedded_preview_used"] is False
    assert metadata["baseline_is_original_edit_history"] is False
    assert "raw_baseline_interpretation" in metadata["warnings"]
    assert "gps" not in json.dumps(metadata).lower()
    assert _hash(raw) == before


def test_raw_jpeg_pair_measures_transform_relative_to_documented_baseline(tmp_path, monkeypatch):
    raw = write_test_dng(tmp_path / "portrait.dng")
    edited = tmp_path / "finished.jpg"
    _edited(raw, edited)
    before = {"original": _hash(raw), "edited": _hash(edited)}

    def reject_network(*args, **kwargs):
        raise AssertionError("RAW analysis must stay offline")

    monkeypatch.setattr(socket, "socket", reject_network)
    result = analyze_pair(raw, edited)
    assert result["status"] == "ok", result["alignment"]
    assert result["source_type"] == "inferred_raw_pair"
    assert result["algorithm_version"] == "0.5.5"
    assert result["alignment"]["success"] is True
    assert result["alignment"]["confidence"] > 0.8
    assert result["alignment"]["original_size"] == [480, 360]
    assert result["tone"]["mean_luminance_delta"] > 0.03
    assert result["color"]["lab"]["delta_b"] > 0
    assert result["lightroom_estimates"]["available"] is True
    assert result["lightroom_estimates"]["approximate"] is True
    assert result["provenance"]["exact_xmp_parameters"] is False
    assert result["provenance"]["evidence"] == "registered_raw_baseline_and_jpeg_pixels"
    assert result["provenance"]["raw_baseline"] == result["alignment"]["original_decode"]
    assert result["provenance"]["input_fingerprints"] == before
    assert "raw_baseline_interpretation" in result["warnings"]
    assert result["confidence_scope"] == "registered_tone_color_evidence"
    json.dumps(result, allow_nan=False)
    assert before == {"original": _hash(raw), "edited": _hash(edited)}


def test_raw_jpeg_geometry_failure_withholds_photometric_estimates(tmp_path):
    raw = write_test_dng(tmp_path / "first.dng", seed=17)
    unrelated = write_test_dng(tmp_path / "second.dng", seed=94)
    edited = tmp_path / "second.jpg"
    _edited(unrelated, edited)
    result = analyze_pair(raw, edited)
    assert result["status"] == "alignment_failed"
    assert result["alignment"]["success"] is False
    assert result["confidence"] == 0
    assert result["tone"] == result["color"] == {}
    assert result["lightroom_estimates"]["available"] is False
    assert "raw_baseline_interpretation" in result["warnings"]


def test_raw_alignment_preserves_full_oriented_coordinates_with_bounded_decode(tmp_path):
    raw = write_test_dng(tmp_path / "rotated.dng", orientation=6)
    edited = tmp_path / "edited.jpg"
    _edited(raw, edited)
    result = align_images(raw, edited, max_dimension=240)
    assert result.metadata["success"]
    assert result.metadata["original_size"] == result.metadata["edited_size"] == [360, 480]
    assert max(result.original_aligned.shape[:2]) == 240
    assert result.metadata["scale"] == pytest.approx(1.0, abs=0.01)
    assert result.metadata["rotation_degrees"] == pytest.approx(0.0, abs=0.3)


@pytest.mark.parametrize("contents", [b"not a camera RAW", b"II\x2a\0\x08\0\0\0"])
def test_corrupt_or_unsupported_raw_is_rejected_without_preview_fallback(tmp_path, contents):
    raw = tmp_path / "broken.dng"
    raw.write_bytes(contents)
    before = _hash(raw)
    with pytest.raises(ValueError, match="Cannot decode RAW"):
        decode_raw(raw)
    assert _hash(raw) == before


def test_jpeg_renamed_to_raw_does_not_count_as_sensor_data(tmp_path):
    fake = tmp_path / "preview.dng"
    Image.new("RGB", (120, 90), "red").save(fake, format="JPEG")
    with pytest.raises(ValueError, match="Cannot decode RAW"):
        decode_raw(fake)


def test_pair_rejects_raw_result_and_same_file_alias(tmp_path):
    raw = write_test_dng(tmp_path / "source.dng")
    edited = tmp_path / "edited.jpg"
    _edited(raw, edited)
    with pytest.raises(ValueError, match="edited result must be JPEG"):
        analyze_pair(edited, raw)
    with pytest.raises(ValueError, match="different original and edited"):
        analyze_pair(edited, edited)
    alias = tmp_path / "alias.jpg"
    alias.hardlink_to(edited)
    with pytest.raises(ValueError, match="different original and edited"):
        analyze_pair(edited, alias)


def test_raw_changed_during_analysis_is_rejected(tmp_path, monkeypatch):
    from personal_color_lab.core import edit_reverse

    raw = write_test_dng(tmp_path / "source.dng")
    edited = tmp_path / "edited.jpg"
    _edited(raw, edited)
    align = edit_reverse.align_images

    def mutate_after_decode(*args, **kwargs):
        result = align(*args, **kwargs)
        raw.write_bytes(raw.read_bytes() + b"changed")
        return result

    monkeypatch.setattr(edit_reverse, "align_images", mutate_after_decode)
    with pytest.raises(ValueError, match="changed during analysis"):
        analyze_pair(raw, edited)


@pytest.mark.parametrize("dimension", [0, 31, True, 2.4])
def test_raw_decode_rejects_invalid_analysis_size(tmp_path, dimension):
    with pytest.raises(ValueError, match="max_dimension"):
        decode_raw(tmp_path / "unused.dng", max_dimension=dimension)
