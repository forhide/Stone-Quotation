"""Classifier boundaries and inference decisions; not an accuracy benchmark."""
import copy
import json
import shutil
import threading
import numpy as np
import pytest
from personal_color_lab.core import photo_scene as scene,photo_scene_models as models
from personal_color_lab.core.analysis_control import AnalysisCancelledError

@pytest.mark.parametrize('override',[['day','night'],['indoor','outdoor'],['food','food'],['unknown'],[False],{},'night'])
def test_invalid_manual_categories_are_rejected(override):
    with pytest.raises(ValueError):scene.validate_scene_override(override)


def test_manual_review_preserves_uncertain_automatic_evidence_without_aliases():
    original=scene.unknown_photo_scene();snapshot=copy.deepcopy(original)
    reviewed=scene.with_scene_override(original,['portrait','night'])
    assert reviewed['source']=='manual' and reviewed['labels']==['night','portrait']
    assert reviewed['scores']=={} and reviewed['automatic_labels']==[] and reviewed['status']=='unavailable'
    restored=scene.with_scene_override(reviewed,None)
    assert restored==snapshot and original==snapshot
    reviewed['labels'].clear();assert original==snapshot

@pytest.mark.parametrize('field,value',[('labels',None),('scores',{'food':float('nan')}),('scores',{'food':True}),('warnings',[{}]),('evidence',{'latitude':37}),('automatic_labels',['food']),('bundle_id','not-a-hash'),('schema_version',True)])
def test_invalid_persisted_evidence_is_rejected(field,value):
    report=scene.unknown_photo_scene();report[field]=value
    with pytest.raises(ValueError):scene.validate_scene_report(report)

@pytest.mark.parametrize('filename',['encoder.onnx','prompt-vectors.npy','prompts.json','LICENSE.txt','manifest.json'])
def test_missing_and_tampered_assets_never_run(filename,tmp_path):
    root=tmp_path/'models';shutil.copytree(models.MODEL_ROOT,root)
    assert models.verify_scene_models(root)['model_version']==scene.MODEL_VERSION
    path=root/filename;data=path.read_bytes();path.write_bytes(data[:-1]+bytes([data[-1]^1]))
    with pytest.raises(models.SceneModelUnavailableError):models.verify_scene_models(root)
    path.unlink()
    with pytest.raises(models.SceneModelUnavailableError):models.verify_scene_models(root)


def test_bright_pixels_do_not_replace_visual_night_evidence(monkeypatch):
    similarity=np.full((2,len(scene.LABELS)),.2,np.float32)
    for label in ('night','outdoor','landscape'):
        similarity[0,scene.LABELS.index(label)]=.35
    similarity[1,scene.LABELS.index('indoor')]=.35
    monkeypatch.setattr(models,'classify_embedding',lambda *a,**kw:(similarity,'a'*64))
    pixels=np.random.default_rng(1).integers(170,255,(64,96,3),dtype='uint8')
    report=scene.classify_photo(pixels)
    assert {'night','outdoor','landscape'}<=set(report['labels']) and 'day' not in report['labels']
    assert report['evidence']['score_kind']=='uncalibrated_similarity'


def test_indoor_time_abstention_and_missing_model_manual_fallback(monkeypatch):
    similarity=np.full((2,len(scene.LABELS)),.2,np.float32)
    for label in ('day','indoor','food'):similarity[0,scene.LABELS.index(label)]=.35
    similarity[1,scene.LABELS.index('outdoor')]=.35
    monkeypatch.setattr(models,'classify_embedding',lambda *a,**kw:(similarity,'a'*64))
    pixels=np.random.default_rng(2).integers(30,200,(64,96,3),dtype='uint8')
    report=scene.classify_photo(pixels)
    assert 'indoor' in report['labels'] and not set(scene.AXES['time'])&set(report['labels'])
    monkeypatch.setattr(models,'classify_embedding',lambda *a,**kw:(_ for _ in ()).throw(models.SceneModelUnavailableError()))
    unknown=scene.classify_photo(pixels);assert unknown['status']=='unavailable'
    reviewed=scene.with_scene_override(unknown,['night','food']);assert reviewed['labels']==['night','food']


def test_cancellation_and_empty_images_never_forward(monkeypatch):
    calls=[];monkeypatch.setattr(models,'classify_embedding',lambda *a,**kw:calls.append(1))
    pixels=np.zeros((40,60,3),np.uint8)
    assert scene.classify_photo(pixels)['status']=='unavailable'
    event=threading.Event();event.set()
    with pytest.raises(AnalysisCancelledError):scene.classify_photo(pixels,cancel_event=event)
    assert calls==[]


def test_automatic_labels_require_actual_similarity_evidence():
    report=scene.unknown_photo_scene();report.update(status='ok',bundle_id='a'*64,labels=['night'],automatic_labels=['night'])
    with pytest.raises(ValueError,match='similarity'):scene.validate_scene_report(report)
