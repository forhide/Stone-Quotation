"""Exports publish complete bytes and preserve competing/existing files."""
import errno
import threading
from pathlib import Path
import pytest
from personal_color_lab.core.export_files import write_new,ExportCancelledError


def test_completed_export_is_not_visible_until_encoding_finishes(tmp_path):
    destination=tmp_path/'output.jpg';entered=threading.Event();release=threading.Event();errors=[]
    def writer(stream):
        stream.write(b'first');entered.set();assert release.wait(5);stream.write(b'last')
    def run():
        try:write_new(destination,writer)
        except Exception as exc:errors.append(exc)
    worker=threading.Thread(target=run);worker.start();assert entered.wait(5)
    assert not destination.exists()
    release.set();worker.join(5)
    assert not worker.is_alive() and not errors
    assert destination.read_bytes()==b'firstlast' and sorted(p.name for p in tmp_path.iterdir())==['output.jpg']


def test_cancellation_during_encoding_removes_staging_and_final_name(tmp_path):
    stop=threading.Event();destination=tmp_path/'output.jpg'
    def writer(stream):stream.write(b'partial');stop.set()
    with pytest.raises(ExportCancelledError):write_new(destination,writer,stop)
    assert list(tmp_path.iterdir())==[]


def test_existing_or_racing_output_is_never_overwritten(tmp_path):
    destination=tmp_path/'output.json';destination.write_bytes(b'existing')
    with pytest.raises(FileExistsError):write_new(destination,lambda s:pytest.fail('Encoded existing output'))
    destination.unlink()
    def writer(stream):
        stream.write(b'our complete result');destination.write_bytes(b'other creator')
    with pytest.raises(FileExistsError):write_new(destination,writer)
    assert destination.read_bytes()==b'other creator'
    assert [p.name for p in tmp_path.iterdir()]==['output.json']


def test_encoding_exception_preserves_original_and_leaves_no_partial_export(tmp_path):
    source=tmp_path/'original.jpg';source.write_bytes(b'original')
    def writer(stream):stream.write(b'bad');raise OSError('Disk write failed')
    with pytest.raises(OSError):write_new(tmp_path/'copy.jpg',writer)
    assert source.read_bytes()==b'original' and [p.name for p in tmp_path.iterdir()]==['original.jpg']


def test_no_hardlink_filesystem_uses_completed_exclusive_copy(tmp_path,monkeypatch):
    import personal_color_lab.core.export_files as module
    if module.os.name=='nt':pytest.skip('Windows exclusive rename does not need the POSIX hardlink fallback')
    monkeypatch.setattr(module.os,'link',lambda *a,**kw:(_ for _ in ()).throw(OSError(errno.EOPNOTSUPP,'Not supported')))
    destination=tmp_path/'copy.xmp';write_new(destination,lambda stream:stream.write(b'completed'))
    assert destination.read_bytes()==b'completed' and [p.name for p in tmp_path.iterdir()]==['copy.xmp']


def test_fallback_preserves_competing_file(tmp_path,monkeypatch):
    import personal_color_lab.core.export_files as module
    if module.os.name=='nt':pytest.skip('Windows uses exclusive rename')
    monkeypatch.setattr(module.os,'link',lambda *a,**kw:(_ for _ in ()).throw(OSError(errno.EOPNOTSUPP,'Not supported')))
    stop=threading.Event();destination=tmp_path/'copy.jpg'
    def writer(stream):
        stream.write(b'completed');destination.write_bytes(b'competing')
    with pytest.raises(FileExistsError):write_new(destination,writer,stop)
    assert destination.read_bytes()==b'competing'


def test_cancel_after_jpeg_encoding_does_not_publish_copy(tmp_path,monkeypatch):
    from PIL import Image
    from personal_color_lab.core.style_render import export_jpeg
    from personal_color_lab.core.style_dna import identity_dna
    source=tmp_path/'original.jpg';Image.new('RGB',(120,80),'orange').save(source)
    before=source.read_bytes();stop=threading.Event();save=Image.Image.save
    def finish_then_cancel(self,*args,**kwargs):
        result=save(self,*args,**kwargs);stop.set();return result
    monkeypatch.setattr(Image.Image,'save',finish_then_cancel)
    with pytest.raises(ValueError,match='cancelled'):export_jpeg(source,tmp_path/'copy.jpg',identity_dna(),cancel_event=stop)
    assert source.read_bytes()==before and [p.name for p in tmp_path.iterdir()]==['original.jpg']


def test_source_change_during_encoding_does_not_publish_stale_copy(tmp_path,monkeypatch):
    from PIL import Image
    from personal_color_lab.core.style_render import export_jpeg
    from personal_color_lab.core.style_dna import identity_dna
    source=tmp_path/'original.jpg';Image.new('RGB',(120,80),'orange').save(source)
    save=Image.Image.save
    def finish_then_change(self,*args,**kwargs):
        result=save(self,*args,**kwargs)
        with source.open('ab') as stream:stream.write(b'changed by another application')
        return result
    monkeypatch.setattr(Image.Image,'save',finish_then_change)
    with pytest.raises(ValueError,match='changed'):export_jpeg(source,tmp_path/'copy.jpg',identity_dna())
    assert [p.name for p in tmp_path.iterdir()]==['original.jpg']


def test_xmp_rejects_unvalidated_effective_controls_without_creating_output(tmp_path):
    from personal_color_lab.core.style_render import export_xmp
    from personal_color_lab.core.style_dna import identity_dna
    dna=identity_dna();effective=identity_dna();effective['exposure_ev']=float('nan')
    with pytest.raises(ValueError):export_xmp(tmp_path/'bad.xmp',dna,effective)
    assert list(tmp_path.iterdir())==[]


def test_copy_fallback_cancellation_removes_only_its_partial_output(tmp_path,monkeypatch):
    import personal_color_lab.core.export_files as module
    if module.os.name=='nt':pytest.skip('Windows uses exclusive rename')
    monkeypatch.setattr(module.os,'link',lambda *a,**kw:(_ for _ in ()).throw(OSError(errno.EOPNOTSUPP,'Not supported')))
    stop=threading.Event();destination=tmp_path/'copy.jpg';original_open=Path.open
    class StopAfterWrite:
        def __init__(self,stream):self.stream=stream
        def __enter__(self):self.stream.__enter__();return self
        def __exit__(self,*args):return self.stream.__exit__(*args)
        def fileno(self):return self.stream.fileno()
        def flush(self):return self.stream.flush()
        def write(self,data):
            count=self.stream.write(data);stop.set();return count
    def opened(path,*args,**kwargs):
        result=original_open(path,*args,**kwargs)
        return StopAfterWrite(result) if path==destination and args and args[0]=='xb' else result
    monkeypatch.setattr(Path,'open',opened)
    with pytest.raises(ExportCancelledError):write_new(destination,lambda stream:stream.write(b'x'*(2*1024*1024)),stop)
    assert list(tmp_path.iterdir())==[]
