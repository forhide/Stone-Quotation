"""Alternate baseline/current recognition with identical models and inputs."""
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time
import types
sys.path.insert(0,'/workspace/Personal-Color-Lab')
import cv2
import numpy as np
from PIL import Image
from personal_color_lab.core import scene_analysis as current

root=Path('/workspace/artifacts/performance-v0.5.2')
baseline=types.ModuleType('personal_color_lab.core.baseline_scene_analysis')
baseline.__package__='personal_color_lab.core'
exec(compile((root/'baseline_scene_analysis.py').read_text(),str(root/'baseline_scene_analysis.py'),'exec'),baseline.__dict__)
results=[]
for name in ('messi5.jpg','basketball1.png','astronaut.png'):
    path=Path('/workspace/.cache/pcl-semantic-validation')/name
    pixels=np.asarray(Image.open(path).convert('RGB'))
    reference=baseline.analyze_scene(pixels)
    target=current.analyze_scene(pixels)
    assert reference['report']==target['report']
    assert all(np.array_equal(reference['masks'][key],mask) for key,mask in target['masks'].items())
    assert baseline.region_appearance(pixels,reference)==current.region_appearance(pixels,target)
    readings={key:{'scene':[],'appearance':[]} for key in ('baseline','optimized')}
    for iteration in range(15):
        order=[('baseline',baseline),('optimized',current)]
        if iteration%2:
            order.reverse()
        for key,module in order:
            start=time.perf_counter();analysis=module.analyze_scene(pixels)
            readings[key]['scene'].append(time.perf_counter()-start)
            start=time.perf_counter();module.region_appearance(pixels,analysis)
            readings[key]['appearance'].append(time.perf_counter()-start)
    medians={key:{stage:statistics.median(values) for stage,values in stages.items()} for key,stages in readings.items()}
    results.append({'fixture':name,'fixture_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'exact_report_and_masks_and_appearance':True,'readings_seconds':readings,'medians_seconds':medians,
                    'reduction_percent':{stage:100*(1-medians['optimized'][stage]/medians['baseline'][stage]) for stage in ('scene','appearance')}})
result={'opencv_threads':cv2.getNumThreads(),'repetitions_per_fixture_and_variant':15,'alternating_order':True,
        'shared_verified_models':True,'fixtures_redistributed':False,'cases':results,
        'limits':'Linux cloud CPU only; concurrent development work and host scheduling can affect timings; not a native Mac/Windows benchmark.'}
(root/'recognition-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{k:case[k] for k in ('fixture','exact_report_and_masks_and_appearance','medians_seconds','reduction_percent')} for case in results]))
