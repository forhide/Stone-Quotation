# Personal Color Lab V0.5.3 performance evidence

This archive contains measured JSON, captured baseline code, synthetic-fixture
benchmark helpers, and the exact render-kernel hash verifier. It contains no
photo, DNG, NPY, model, private camera image or binary dependency payload.
Generated input names/hashes in reports refer to local synthetic test fixtures.

Use the separately published V0.5.3 source bundle with its pinned dependencies.
Measurements were captured with Python 3.13.5, NumPy 2.3.5, OpenCV 4.14.0 and
rawpy 0.25.1/LibRaw 0.21.4 on Linux. Times vary by machine and background load.
Read PERFORMANCE.md for scope, quality differences and separate comparisons.

## Reproduce in the recorded workspace

The original capture helpers retain their recorded absolute paths:
project=/workspace/Personal-Color-Lab, baselines=/workspace/scratch,
reports=/workspace/artifacts/performance-v0.5.3,
RAW cache=/workspace/.cache/pcl-raw-validation.
Copy helpers/*.py and baselines/*.py to /workspace/scratch; copy reports/*.json
to the report directory. Preserve the reports before rerunning benchmarks.
Using the project's .venv-desktop/bin/python, run:

- /workspace/scratch/pcl_verify_kernel_hash_053.py
- /workspace/scratch/pcl_render_precision_053.py --output /tmp/pcl-render-reproduced.json
- /workspace/scratch/pcl_render_benchmark_053.py --output /tmp/pcl-render-timings.json --repeats 5
- /workspace/scratch/pcl_raw_benchmark_v053.py
- /workspace/scratch/pcl_raw_export_performance_053.py

The RAW decoder benchmark creates DNG/NPY files in its cache and rewrites its
RAW report. The RAW export benchmark regenerates a 14.2MP DNG, uses temporary
JPGs, and writes performance-v0.5.3-raw-export.json in the source project.
These outputs are not included in this archive. The helpers need no network.
To reproduce elsewhere, update project/baseline/cache/output/report constants
and recorded absolute file references to your own source and writable paths.
Helpers are research diagnostics, not installed-application entry points.

## What is compared

- RAW decoder: released V0.5.2 strict AHD vs current strict and opt-in half-size
  Bayer preview. Current strict pixels are exact; optional fast pixels differ,
  particularly on fine patterns. Baseline/postprocess defaults are preserved.
- RAW export: captured V0.5.2 two-development export function executes inside
  the current style_render namespace; both arms use CURRENT kernels and strict
  decoder. This isolates orchestration and must not be combined with render gains.
- Render: retained V0.5.2 module vs current module, shared unchanged region helpers,
  generated seed 20261012 inputs and matching output SHA values. The unused legacy
  load_baseline_regions function in the capture script is never called.
- Precision: 100 curves times 200099 sample values and 60 complete render comparisons;
  the saved input hashes and render-output hashes reproduce the report.

## Exact kernel identity

The measured-function SHA256 is
38b0b329f13f5fa50bca69e7df56b16c0d86e9eb6e3e881ac0177b2d10bfa320.
The verifier selects 12 named top-level FunctionDef nodes, preserves source order,
joins ast.get_source_segment text with one LF, and hashes UTF-8 bytes without a
trailing LF. It prints the exact function order and fails on mismatch. Internal
comments/formatting are included; imports and photo decode/preview/export
integration functions are excluded. Whole-module hashes in render reports are
integration-time snapshots and can differ after those excluded functions change.
The recorded raw-decoder hash still matches the current decoder. MANIFEST.json
records all archive evidence file sizes and SHA256 values; SHA256SUMS.txt also
covers the manifest. Native OS/camera calibration is outside this evidence.
