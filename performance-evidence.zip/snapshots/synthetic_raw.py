"""Generate a synthetic CFA DNG for packaged-runtime diagnostics.

This helper runs only during explicit self-tests. No user photo is read or copied."""
from pathlib import Path
import struct

import cv2
import numpy as np


def write_test_dng(path: Path, seed: int = 17, width: int = 480, height: int = 360, orientation: int = 1) -> Path:
    """Write a valid uncompressed Bayer DNG using only stdlib TIFF packing."""
    rng = np.random.default_rng(seed)
    scene = cv2.resize(rng.uniform(0.04, 0.65, (24, 32, 3)).astype(np.float32), (width, height), interpolation=cv2.INTER_CUBIC)
    for _ in range(70):
        x, y = int(rng.integers(0, width)), int(rng.integers(0, height))
        color = tuple(float(c) for c in rng.uniform(0.04, 0.65, 3))
        cv2.circle(scene, (x, y), int(rng.integers(3, 20)), color, 2, cv2.LINE_AA)
    # A neutral textured patch makes WB and exposure comparisons informative.
    for i in range(5):
        level = 0.06 + i * 0.08
        cv2.rectangle(scene, (width - 85, 12 + 60 * i), (width - 12, 44 + 60 * i), (level,) * 3, -1)
    linear = np.clip(scene, 0, 0.9)
    mosaic = np.empty((height, width), dtype="<u2")
    for y, x, channel in ((0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 2)):
        mosaic[y::2, x::2] = np.rint(64 + linear[y::2, x::2, channel] * (4095 - 64)).astype(np.uint16)

    def short(*values):
        return 3, len(values), struct.pack("<" + "H" * len(values), *values)

    def long(*values):
        return 4, len(values), struct.pack("<" + "I" * len(values), *values)

    def text(value):
        data = value.encode("ascii") + b"\0"
        return 2, len(data), data

    def bytes_(*values):
        return 1, len(values), bytes(values)

    def rational(*values):
        data = b"".join(struct.pack("<II", round(value * 1000000), 1000000) for value in values)
        return 5, len(values), data

    # XYZ to a linear sRGB-like camera; signed rational values are valid DNG.
    matrix = [3.2404542, -1.5371385, -0.4985314, -0.9692660, 1.8760108, 0.0415560, 0.0556434, -0.2040259, 1.0572252]
    tags = {
        254: long(0), 256: long(width), 257: long(height), 258: short(16),
        259: short(1), 262: short(32803), 271: text("Personal Color Lab"),
        272: text("Synthetic CFA"), 273: long(0), 274: short(orientation),
        277: short(1), 278: long(height), 279: long(mosaic.nbytes), 284: short(1),
        33421: short(2, 2), 33422: bytes_(0, 1, 1, 2),
        50706: bytes_(1, 4, 0, 0), 50707: bytes_(1, 1, 0, 0),
        50708: text("Personal Color Lab Synthetic CFA"), 50710: bytes_(0, 1, 2),
        50711: short(1), 50713: short(1, 1), 50714: rational(64),
        50717: long(4095), 50719: long(0, 0), 50720: long(width, height),
        50721: (10, 9, b"".join(struct.pack("<ii", round(value * 1000000), 1000000) for value in matrix)),
        50728: rational(1, 1, 1), 50778: short(21), 50829: long(0, 0, height, width),
    }
    table = bytearray(struct.pack("<H", len(tags)))
    extra = bytearray()
    extra_start = 8 + 2 + len(tags) * 12 + 4
    strip_entry = None
    for tag, (kind, count, data) in sorted(tags.items()):
        if tag == 273:
            strip_entry = len(table) + 8
        if len(data) <= 4:
            value = data.ljust(4, b"\0")
        else:
            value = struct.pack("<I", extra_start + len(extra))
            extra.extend(data)
            extra.extend(b"\0" * (len(extra) % 2))
        table.extend(struct.pack("<HHI", tag, kind, count) + value)
    table.extend(struct.pack("<I", 0))
    struct.pack_into("<I", table, strip_entry, extra_start + len(extra))
    path.write_bytes(b"II\x2a\0" + struct.pack("<I", 8) + table + extra + mosaic.tobytes())
    return path
