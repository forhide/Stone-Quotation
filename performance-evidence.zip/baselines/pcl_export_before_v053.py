def export_jpeg(source,destination,dna,strength=1.,composition='color_only',cancel_event=None,expected_fingerprint=None,recognition=False,object_strength=.7,protect_faces=True):
    _validate_render_options(strength,composition)
    _check_cancel(cancel_event)
    source=Path(source).expanduser().resolve(strict=True)
    destination=Path(destination).expanduser().absolute()
    if destination==source or destination.suffix.lower() not in JPEG_EXTENSIONS:
        raise ValueError('Export must be a new JPEG copy.')
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f'Export already exists: {destination}')
    before=file_fingerprint(source)
    if expected_fingerprint and before!=expected_fingerprint:
        raise ValueError('Input changed since preview; preview again.')
    dna=validate_dna(dna)
    if type(recognition) is not bool:raise ValueError('Invalid recognition choice')
    preview,_=read_photo(source)
    effective,measurement=prepare_style(preview,dna)
    scene=None
    if recognition:
        from .scene_analysis import analyze_scene
        scene=analyze_scene(preview,cancel_event)
        effective=_effective(dna,measurement,scene['report'])
    full,dimensions=read_photo(source,max_dimension=1_000_000)
    if scene is None:
        rendered,box=apply_pixels(full,effective,strength,composition,cancel_event)
    else:
        rendered=_render_regions(full,effective,dna,strength,scene,object_strength,protect_faces,cancel_event,measurement=measurement)
        box=composition_box(full.shape[1],full.shape[0],effective['composition']['aspect_ratio'])
        if composition=='apply_crop' and box:rendered=rendered[box[1]:box[3],box[0]:box[2]].copy()
    if file_fingerprint(source)!=before:
        raise ValueError('Input changed during export.')
    if cancel_event is not None and cancel_event.is_set():
        raise ValueError('Style operation cancelled.')
    profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    def encode(stream):
        Image.fromarray(rendered).save(stream,format='JPEG',quality=95,subsampling=0,icc_profile=profile)
        _check_cancel(cancel_event)
        if file_fingerprint(source)!=before:
            raise ValueError('Input changed during export.')
    _write_new(destination,encode,cancel_event)
    return {'path':str(destination),'dimensions':[rendered.shape[1],rendered.shape[0]],'source_unchanged':True,'gps_exported':False,'composition_applied':bool(composition=='apply_crop' and box)}
