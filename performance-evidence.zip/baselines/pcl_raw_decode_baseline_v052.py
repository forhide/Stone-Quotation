"""Read camera RAW pixels locally using an explicit, reproducible baseline.

A RAW file has no single finished appearance. This development is a comparison
baseline, not a reconstruction of the camera JPEG or of Lightroom defaults.
Only decoding parameters are returned; camera/location metadata is not copied.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import cv2
import numpy as np

from .constants import RAW_EXTENSIONS

MAX_RAW_PIXELS = 120_000_000


def decode_raw(path: Path, max_dimension: int = 1400) -> tuple[np.ndarray, tuple[int, int], dict[str, Any]]:
    """Return bounded uint8 sRGB pixels, oriented full size, and safe provenance.

The input is read only. LibRaw applies the stored orientation and sensor black /
white levels, then develops with camera WB, sRGB output and no automatic
brightness. Unsupported/corrupt files raise ValueError rather than using a
possibly already edited embedded JPEG as if it were sensor data.
"""
    if not isinstance(max_dimension, int) or isinstance(max_dimension, bool) or max_dimension < 32:
        raise ValueError("max_dimension must be an integer of at least 32")
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file() or path.suffix.lower() not in RAW_EXTENSIONS:
        raise ValueError("A supported camera RAW file is required.")
    try:
        import rawpy
    except ImportError as exc:
        raise ValueError("RAW decoder is unavailable; install the complete desktop application.") from exc

    try:
        with rawpy.imread(str(path)) as raw:
            if raw.sizes.raw_width * raw.sizes.raw_height > MAX_RAW_PIXELS:
                raise ValueError("RAW image exceeds the supported 120 megapixel decode limit.")
            camera_wb = np.asarray(raw.camera_whitebalance[:3], dtype=np.float64)
            has_camera_wb = bool(camera_wb.size == 3 and np.isfinite(camera_wb).all() and (camera_wb > 0).all())
            rgb = raw.postprocess(
                use_camera_wb=True,
                use_auto_wb=False,
                no_auto_bright=True,
                bright=1.0,
                exp_shift=1.0,
                exp_preserve_highlights=0.0,
                no_auto_scale=False,
                adjust_maximum_thr=0.0,
                output_color=rawpy.ColorSpace.sRGB,
                output_bps=8,
                gamma=(2.4, 12.92),
                demosaic_algorithm=rawpy.DemosaicAlgorithm.AHD,
                highlight_mode=rawpy.HighlightMode.Clip,
                fbdd_noise_reduction=rawpy.FBDDNoiseReductionMode.Off,
                median_filter_passes=0,
                half_size=False,
            )
    except (rawpy.LibRawError, OSError, RuntimeError, ValueError) as exc:
        raise ValueError(f"Cannot decode RAW image: {path.name}") from exc

    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8 or min(rgb.shape[:2]) < 1:
        raise ValueError(f"RAW decoder returned invalid RGB pixels: {path.name}")
    original_size = (int(rgb.shape[1]), int(rgb.shape[0]))
    factor = min(1.0, max_dimension / max(original_size))
    if factor < 1:
        rgb = cv2.resize(rgb, (max(1, round(original_size[0] * factor)), max(1, round(original_size[1] * factor))), interpolation=cv2.INTER_AREA)
    metadata = {
        "decoder": "rawpy_libraw",
        "rawpy_version": str(rawpy.__version__),
        "libraw_version": ".".join(str(part) for part in rawpy.libraw_version),
        "baseline": "fixed_camera_wb_srgb",
        "baseline_is_original_edit_history": False,
        "camera_white_balance_requested": True,
        "white_balance_source": "camera" if has_camera_wb else "libraw_daylight_fallback",
        "auto_white_balance": False,
        "auto_brightness": False,
        "brightness_multiplier": 1.0,
        "exposure_multiplier": 1.0,
        "sensor_black_white_normalization": True,
        "scene_maximum_adjustment": False,
        "output_color_space": "sRGB",
        "gamma": [2.4, 12.92],
        "output_bits": 8,
        "demosaic": "AHD",
        "highlight_mode": "clip",
        "orientation_applied": True,
        "embedded_preview_used": False,
        "warnings": ["raw_baseline_interpretation"] + ([] if has_camera_wb else ["raw_camera_white_balance_unavailable"]),
    }
    return np.ascontiguousarray(rgb), original_size, metadata
