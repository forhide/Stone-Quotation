# Global analysis performance evidence

Measured on the Linux cloud development CPU, with OpenCV using four threads. Each timing is the median of seven measured runs after one warmup. The input is a deterministic synthetic 2000 × 1333 JPEG, reduced to a 1024 × 682 reference preview; registered color analysis retains its existing deterministic 100,000-sample bound. Recognition is excluded from the reference file case to isolate this algorithm change. These are workload-specific measurements, not Windows/Mac or camera-library speed guarantees.

| Workload | Before | After | Time reduction |
| --- | ---: | ---: | ---: |
| reference_appearance_1024px | 0.2953 s | 0.1869 s | 36.7% |
| reference_palette_1024px | 0.0202 s | 0.0135 s | 33.2% |
| pair_color_2000px_100k_samples | 0.0790 s | 0.0426 s | 46.1% |
| reference_jpg_2000px_no_semantics | 0.4017 s | 0.2798 s | 30.3% |

The measured reference appearance JSON, palette colors/fractions and pair color JSON are identical: maximum numeric absolute error 0. No sampling reduction or precision change was introduced. Repeated chroma, hue eligibility and weighted circular statistics are reused; byte palette binning avoids float64 image copies and artificial unit-weight arrays; explicit three-channel extrema avoid slow strided reductions.

Python/NumPy allocations measured separately with tracemalloc peak at 78.2 → 56.0 MB for reference appearance and 47.5 → 16.9 MB for its palette. Color analysis trades 28.0 → 31.5 MB of bounded temporary allocations for cached circular evidence and less repeated work. These allocation figures exclude some native decoder/OpenCV memory and are not process RSS.

Batch reference analysis reuses its preflight SHA-256 while still hashing the actual file after measurements. Cancellation is checked between decode, appearance, recognition and final verification; unfinished photos are counted as cancelled while completed evidence remains saveable. No original photos, network dependencies or private metadata are added.

Focused regression result: 109 passed, recorded in /tmp/pcl-v052-analysis-tests.xml. New coverage includes source mutation with a supplied fingerprint, invalid fingerprints, opposed hue rotations, weighted palettes and cancellation inside a photo retaining earlier results.
