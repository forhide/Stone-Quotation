"""Verified local model assets and serialized CPU inference. No download path."""
from pathlib import Path
import hashlib
import json
import threading
import cv2

MODEL_ROOT = Path(__file__).resolve().parents[1] / 'assets/models'
IDS = ('nanodet', 'humanseg', 'yunet')
_LOCK = threading.RLock()
_MODELS = {}
_SIGNATURES = {}
_BUNDLE_MANIFEST = None
_BUNDLE_SIGNATURE = None
_BUNDLE_ID = None


class ModelUnavailableError(ValueError):
    """Local model data is missing or fails its pinned checksum."""


def verify_models(root=None):
    root = Path(root or MODEL_ROOT)
    try:
        manifest_path = root / 'manifest.json'
        if manifest_path.is_symlink():
            raise ValueError('Model manifest must be a regular local asset')
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        entries = manifest['models']
        if type(manifest['schema_version']) is not int or manifest['schema_version'] != 1 or [e['id'] for e in entries] != list(IDS):
            raise ValueError('Unsupported model manifest')
        for entry in entries:
            if (entry['filename'] != entry['id'] + '.onnx'
                    or entry['license'] != entry['id'] + '-LICENSE.txt'
                    or type(entry['size']) is not int or not 1 <= entry['size'] <= 100_000_000):
                raise ValueError('Unexpected bundled model asset')
            for field, digest, size in [('filename', entry['sha256'], entry['size']), ('license', entry['license_sha256'], None)]:
                if not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
                    raise ValueError('Invalid model checksum')
                path = root / entry[field]
                if Path(entry[field]).name != entry[field] or path.is_symlink() or not path.is_file():
                    raise ValueError('Missing local model or license')
                if size is not None and path.stat().st_size != size:
                    raise ValueError('Model size mismatch')
                if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                    raise ValueError('Model checksum mismatch')
        return manifest
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ModelUnavailableError('The bundled recognition models are unavailable or corrupt. Reinstall the complete application.') from exc


def _asset_signature():
    """Notice bundle changes without repeatedly hashing every model forward."""
    root = Path(MODEL_ROOT)
    paths = [root / 'manifest.json']
    paths.extend(root / (identifier + suffix) for identifier in IDS for suffix in ('.onnx', '-LICENSE.txt'))
    result = [str(root.resolve())]
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise ModelUnavailableError('Bundled recognition model metadata or data is missing.')
        stat = path.stat()
        result.append((stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino))
    return tuple(result)


def _verified_bundle():
    global _BUNDLE_MANIFEST, _BUNDLE_SIGNATURE, _BUNDLE_ID
    try:
        signature = _asset_signature()
        if _BUNDLE_SIGNATURE != signature or _BUNDLE_MANIFEST is None:
            manifest = verify_models()
            if _asset_signature() != signature:
                raise ModelUnavailableError('Bundled recognition models changed during verification.')
            identity = hashlib.sha256(json.dumps([(e['id'], e['sha256']) for e in manifest['models']], separators=(',', ':')).encode()).hexdigest()
            # Invalidate all networks together. Reporting a new bundle identity
            # while forwarding an older cached network would corrupt provenance.
            _MODELS.clear()
            _SIGNATURES.clear()
            _BUNDLE_MANIFEST, _BUNDLE_SIGNATURE, _BUNDLE_ID = manifest, signature, identity
        return _BUNDLE_MANIFEST
    except (OSError, ValueError, TypeError) as exc:
        if isinstance(exc, ModelUnavailableError):
            raise
        raise ModelUnavailableError('Bundled recognition model data is unavailable.') from exc


def bundle_id():
    with _LOCK:
        _verified_bundle()
        return _BUNDLE_ID


def _load(identifier):
    if identifier not in IDS:
        raise ValueError('Unknown recognition model')
    _verified_bundle()
    path = Path(MODEL_ROOT) / (identifier + '.onnx')
    if identifier not in _MODELS:
        if identifier == 'yunet':
            net = cv2.FaceDetectorYN.create(str(path), '', (320,320), .85, .3, 100, cv2.dnn.DNN_BACKEND_OPENCV, cv2.dnn.DNN_TARGET_CPU)
        else:
            net = cv2.dnn.readNetFromONNX(str(path))
            net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        _MODELS[identifier] = net
        _SIGNATURES[identifier] = _BUNDLE_SIGNATURE
    return _MODELS[identifier]


def infer(identifier, blob):
    with _LOCK:
        net = _load(identifier)
        net.setInput(blob)
        if identifier == 'nanodet':
            return net.forward(net.getUnconnectedOutLayersNames())
        return net.forward()


def detect_faces(bgr):
    with _LOCK:
        net = _load('yunet')
        net.setInputSize((bgr.shape[1], bgr.shape[0]))
        _, faces = net.detect(bgr)
        return faces
