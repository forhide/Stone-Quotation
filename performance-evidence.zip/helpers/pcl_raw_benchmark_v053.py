"""Compare released RAW baseline, header-first baseline and explicit CFA preview."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import statistics
import struct
import subprocess
import sys
from time import perf_counter

PROJECT = Path('/workspace/Personal-Color-Lab')
sys.path.insert(0, str(PROJECT))
import cv2
import numpy as np
import rawpy
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.synthetic_raw import write_test_dng

CACHE = Path('/workspace/.cache/pcl-raw-validation')
OUT = Path('/workspace/artifacts/performance-v0.5.3')


def old_decode():
    name = 'personal_color_lab.core._benchmark_released_raw'
    spec = importlib.util.spec_from_file_location(name, '/workspace/scratch/pcl_raw_decode_baseline_v052.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.decode_raw


def fine_fixture(path):
    """Sensor resolution stripes/edges stress approximate preview, not a camera."""
    width, height = 4000, 3000
    write_test_dng(path, width=width, height=height, seed=63)
    yy, xx = np.indices((height, width), dtype=np.int32)
    stripes = ((xx // 3 + yy // 7) % 2).astype(np.float32)
    gradient = xx.astype(np.float32) / width
    scene = np.stack((.10 + .52 * stripes, .12 + .30 * gradient,
                      .12 + .45 * (1 - stripes)), axis=2)
    mosaic = np.empty((height, width), dtype='<u2')
    for y, x, channel in ((0, 0, 0), (0, 1, 1), (1, 0, 1), (1, 1, 2)):
        mosaic[y::2, x::2] = np.rint(64 + scene[y::2, x::2, channel] * (4095 - 64)).astype(np.uint16)
    data = bytearray(path.read_bytes())
    ifd = struct.unpack_from('<I', data, 4)[0]
    count = struct.unpack_from('<H', data, ifd)[0]
    for index in range(count):
        offset = ifd + 2 + index * 12
        tag, kind, count, value = struct.unpack_from('<HHII', data, offset)
        if tag == 273:
            data[value:value + mosaic.nbytes] = mosaic.tobytes()
            break
    else:
        raise RuntimeError('Synthetic strip absent')
    path.write_bytes(data)


def child(args):
    source = Path(args.fixture)
    decoder = old_decode() if args.mode == 'released_baseline' else decode_raw
    quality = 'interactive' if args.mode == 'interactive_half_size' else 'baseline'
    measurements = []
    # Native import/model initialization is outside timed decode. One complete
    # warm-up is recorded separately; median is five subsequent full reads.
    start = perf_counter()
    kwargs = {} if args.mode == 'released_baseline' else {'quality': quality}
    pixels, dimensions, metadata = decoder(source, 1200, **kwargs)
    warmup = perf_counter() - start
    for _ in range(5):
        start = perf_counter()
        pixels, dimensions, metadata = decoder(source, 1200, **kwargs)
        measurements.append(perf_counter() - start)
    np.save(CACHE / f'{source.stem}-{args.mode}.npy', pixels)
    print(json.dumps({'mode': args.mode, 'warmup_seconds': warmup,
                      'seconds': measurements, 'median_seconds': statistics.median(measurements),
                      'process_peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                      'full_dimensions': list(dimensions), 'preview_shape': list(pixels.shape),
                      'decode_metadata': metadata}, allow_nan=False))


def parent():
    CACHE.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    sources = [CACHE / 'synthetic-8mp.dng', CACHE / 'synthetic-12mp.dng', CACHE / 'synthetic-fine-12mp.dng']
    if not sources[0].exists():
        write_test_dng(sources[0], width=3264, height=2448, orientation=6)
    if not sources[1].exists():
        write_test_dng(sources[1], width=4000, height=3000, orientation=1, seed=81)
    if not sources[2].exists():
        fine_fixture(sources[2])
    report = {'schema_version': 1, 'scope': 'Synthetic uncompressed RGB Bayer DNG, local Linux CPU. Native cameras/OS untested.',
              'python': platform.python_version(), 'platform': platform.platform(),
              'logical_cpu_count': os.cpu_count(), 'opencv_threads_unchanged': cv2.getNumThreads(),
              'rawpy_version': rawpy.__version__, 'libraw_version': list(rawpy.libraw_version),
              'libraw_build_flags': rawpy.flags, 'requested_preview_dimension': 1200,
              'decoder_sha256': hashlib.sha256((PROJECT / 'personal_color_lab/core/raw_decode.py').read_bytes()).hexdigest(),
              'released_decoder_sha256': hashlib.sha256(Path('/workspace/scratch/pcl_raw_decode_baseline_v052.py').read_bytes()).hexdigest(),
              'benchmark_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'interactive_is_exact_baseline': False,
              'interactive_not_default_for_analysis_or_export': True,
              'each_mode': 'one warmup plus five timed full file open/unpack/develop/resize reads in an isolated process',
              'fixtures': []}
    for source in sources:
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        results = []
        for mode in ('released_baseline', 'interactive_half_size', 'header_first_baseline'):
            output = subprocess.check_output([sys.executable, __file__, '--child', '--fixture', str(source), '--mode', mode], text=True)
            results.append(json.loads(output))
        pixels = {entry['mode']: np.load(CACHE / f'{source.stem}-{entry["mode"]}.npy') for entry in results}
        a, b = pixels['released_baseline'], pixels['interactive_half_size']
        delta = np.abs(a.astype(np.float32) - b.astype(np.float32))
        lab_a = cv2.cvtColor(a.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
        lab_b = cv2.cvtColor(b.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
        de = np.linalg.norm(lab_a - lab_b, axis=2)
        quality = {'byte_mae': float(delta.mean()), 'byte_p95': float(np.quantile(delta, .95)),
                   'byte_maximum': float(delta.max()),
                   'psnr_db': float(10 * np.log10(255 ** 2 / np.square(delta).mean())),
                   'channel_mean_delta': (b.astype(float).mean((0, 1)) - a.astype(float).mean((0, 1))).tolist(),
                   'delta_e76_median': float(np.median(de)), 'delta_e76_p95': float(np.quantile(de, .95)),
                   'delta_e76_maximum': float(de.max())}
        report['fixtures'].append({'name': source.name, 'input_sha256': before, 'input_bytes': source.stat().st_size,
                                   'source_unchanged': before == hashlib.sha256(source.read_bytes()).hexdigest(),
                                   'new_baseline_exact_previous_pixels': bool(np.array_equal(a, pixels['header_first_baseline'])),
                                   'runs': results, 'interactive_comparison': quality,
                                   'interactive_speedup_over_baseline': results[0]['median_seconds'] / results[1]['median_seconds']})
        print(source.name, results[0]['median_seconds'], results[1]['median_seconds'], quality['byte_mae'], flush=True)
    path = OUT / 'raw-decoder-benchmark.json'
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    print(path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--child', action='store_true')
    parser.add_argument('--fixture')
    parser.add_argument('--mode')
    args = parser.parse_args()
    child(args) if args.child else parent()
