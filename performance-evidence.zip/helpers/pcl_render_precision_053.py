"""Reproduce exact float32 curve and full-render comparisons without photos."""
from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import sys

import numpy as np

ROOT = Path('/workspace/Personal-Color-Lab')
sys.path.insert(0, str(ROOT))
from personal_color_lab.core import style_render
from personal_color_lab.core.style_dna import identity_dna, builtin_styles

BASELINE = Path('/workspace/scratch/pcl_style_render_v052_baseline.py')
FUNCTIONS = {'_measure', '_effective', 'prepare_style', '_is_neutral_style', '_render_plan',
             '_curve_coefficients', '_curve_pixels', '_tile', 'apply_pixels', '_render_regions',
             'measurement_lighting', 'composition_box'}


def main(destination):
    spec = importlib.util.spec_from_file_location('personal_color_lab.core._precision_v052', BASELINE)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    rng = np.random.default_rng(533)
    grid = np.linspace(0, 1, 33).astype(np.float32)
    probes = np.r_[rng.uniform(-.2, 1.2, 200000).astype(np.float32), grid,
                   np.nextafter(grid, np.float32(-np.inf)), np.nextafter(grid, np.float32(np.inf))]
    for _ in range(100):
        curve = np.maximum.accumulate(rng.uniform(0, 1, 33))
        expected = np.interp(probes, np.linspace(0, 1, 33), curve).astype(np.float32)
        actual = style_render._curve_pixels(probes, style_render._curve_coefficients(curve))
        if not np.array_equal(expected, actual):
            raise RuntimeError('Uniform-grid float32 interpolation changed.')
    pixels = rng.integers(0, 256, (259, 383, 3), dtype=np.uint8)
    recipes = builtin_styles()
    for exposure in [-3, -1.2, -.04, 0, .04, .6, 2.2, 3]:
        dna = identity_dna()
        dna.update(exposure_ev=exposure, saturation_scale=.79, vibrance=.22,
                   lab_shift=[3., -2.], grain_amount=.013)
        dna['tone_curve'] = np.maximum.accumulate(np.clip(np.linspace(0, 1, 33)*.94+.014, 0, 1)).tolist()
        dna['channel_curves']['red'] = np.clip(np.linspace(0, 1, 33)*1.09, 0, 1).tolist()
        dna['zone_shifts']['shadows'] = [-3., 1.]
        dna['hsl']['red'] = {'hue': 3., 'saturation': -.14, 'lightness': .013}
        recipes.append(dna)
    entries = []
    for index, dna in enumerate(recipes):
        for strength in [.15, .8, 1]:
            a = old.apply_pixels(pixels, dna, strength)[0]
            b = style_render.apply_pixels(pixels, dna, strength)[0]
            if not np.array_equal(a, b):
                raise RuntimeError(f'Render pixels changed for recipe {index}, strength {strength}.')
            entries.append({'recipe': index, 'strength': strength, 'exposure_ev': dna['exposure_ev'],
                            'before_sha256': hashlib.sha256(a).hexdigest(),
                            'after_sha256': hashlib.sha256(b).hexdigest(), 'maximum_channel_difference': 0})
    source = Path(style_render.__file__).read_text(encoding='utf-8')
    segments = '\n'.join(ast.get_source_segment(source, node) for node in ast.parse(source).body
                         if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS)
    report = {'baseline_version': '0.5.2', 'seed': 533, 'input_sha256': hashlib.sha256(pixels).hexdigest(),
              'dimensions': [383, 259], 'curve_count': 100, 'curve_sample_count': int(len(probes)),
              'interpolation_float32_exact': True,
              'before_render_file_sha256': hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
              'candidate_render_file_sha256': hashlib.sha256(source.encode('utf-8')).hexdigest(),
              'candidate_measured_render_functions_sha256': hashlib.sha256(segments.encode('utf-8')).hexdigest(),
              'recipes': entries}
    destination.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(destination)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('/tmp/pcl-v053-render-precision-reproduced.json'))
    args = parser.parse_args()
    main(args.output)
