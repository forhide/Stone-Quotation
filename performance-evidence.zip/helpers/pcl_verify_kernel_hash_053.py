"""Read-only verification of the render functions measured by V0.5.3 benchmarks.

Hash method: UTF-8 bytes of AST function source segments, joined with one LF,
in source-file order; there is no trailing LF. Comments/formatting within each
function are included by ast.get_source_segment. Integration and import edits
outside these functions do not affect this hash.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

SOURCE = Path('/workspace/Personal-Color-Lab/personal_color_lab/core/style_render.py')
REPORT = Path('/workspace/artifacts/performance-v0.5.3/render-comparison.json')
FUNCTIONS = {
    '_measure', '_effective', 'prepare_style', '_is_neutral_style',
    '_render_plan', '_curve_coefficients', '_curve_pixels', '_tile',
    'apply_pixels', '_render_regions', 'measurement_lighting', 'composition_box',
}

def main():
    source = SOURCE.read_text(encoding='utf-8')
    tree = ast.parse(source)
    nodes = [node for node in tree.body
             if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS]
    found = {node.name for node in nodes}
    if found != FUNCTIONS:
        raise SystemExit('Missing measured functions: ' + repr(sorted(FUNCTIONS-found)))
    segments = '\n'.join(ast.get_source_segment(source, node) for node in nodes)
    actual = hashlib.sha256(segments.encode('utf-8')).hexdigest()
    expected = json.loads(REPORT.read_text(encoding='utf-8'))['candidate_measured_render_functions_sha256']
    print(json.dumps({'source': str(SOURCE), 'functions_in_source_order': [node.name for node in nodes],
                      'expected_sha256': expected, 'actual_sha256': actual, 'matches': actual == expected}, indent=2))
    if actual != expected:
        raise SystemExit('Measured render function hash changed.')

if __name__ == '__main__':
    main()
