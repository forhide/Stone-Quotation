"""Compare the legacy two-development export with identical single-read output.

The captured V0.5.2 export function uses the same current rendering kernels and
RAW baseline in both arms; this isolates decode orchestration, not kernel gains.
"""
from pathlib import Path
import hashlib
import json
import os
import platform
import statistics
import sys
import tempfile
import time

import numpy as np
from PIL import Image

ROOT=Path('/workspace/Personal-Color-Lab')
sys.path.insert(0,str(ROOT))
from personal_color_lab.core import alignment,style_render
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.style_dna import builtin_styles


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    captured=Path('/workspace/scratch/pcl_export_before_v053.py').read_text()
    namespace=dict(vars(style_render))
    exec(compile(captured,'legacy-v052-export','exec'),namespace)
    baseline=namespace['export_jpeg']
    report={'schema_version':1,'benchmark':'RAW export decode orchestration',
            'comparison':'V0.5.2 export orchestration vs V0.5.3 single RAW development; both use current identical rendering kernels',
            'runtime':{'python':platform.python_version(),'platform':platform.platform(),'cpu_count':os.cpu_count()},
            'no_network':True,'new_dependencies':False,'iterations':3,'cases':[]}
    scratch=Path('/workspace/.cache/pcl-raw-validation');scratch.mkdir(parents=True,exist_ok=True)
    source=scratch/'synthetic-4608x3072.dng'
    write_test_dng(source,width=4608,height=3072)
    original_sha=sha(source)
    report['input']={'type':'generated uncompressed Bayer CFA DNG; not a camera corpus',
                     'sensor_dimensions':[4608,3072],'bytes':source.stat().st_size,'sha256':original_sha,
                     'orientation':1}
    decode=alignment.decode_raw
    def measure(function,path,calls):
        def counted(*args,**kwargs):
            calls.append({'max_dimension':args[1],'quality':kwargs.get('quality','baseline')})
            return decode(*args,**kwargs)
        alignment.decode_raw=counted
        start=time.perf_counter()
        try:
            function(source,path,builtin_styles()[0],.8,recognition=False)
        finally:
            alignment.decode_raw=decode
        return time.perf_counter()-start
    with tempfile.TemporaryDirectory(prefix='pcl-v053-raw-export-') as temporary:
        directory=Path(temporary)
        # Warm both paths, including LibRaw and JPEG encoder initialization.
        measure(baseline,directory/'warm-before.jpg',[])
        measure(style_render.export_jpeg,directory/'warm-after.jpg',[])
        before_times=[];after_times=[];counts_before=[];counts_after=[];pixel_checks=[]
        for index in range(3):
            before=directory/f'before-{index}.jpg';after=directory/f'after-{index}.jpg'
            calls_before=[];calls_after=[]
            if index%2:
                after_times.append(measure(style_render.export_jpeg,after,calls_after))
                before_times.append(measure(baseline,before,calls_before))
            else:
                before_times.append(measure(baseline,before,calls_before))
                after_times.append(measure(style_render.export_jpeg,after,calls_after))
            counts_before.append(calls_before);counts_after.append(calls_after)
            with Image.open(before) as first,Image.open(after) as second:
                left=np.array(first);right=np.array(second)
                pixel_checks.append({'dimensions':list(first.size),'pixels_equal':bool(np.array_equal(left,right)),
                                     'max_pixel_difference':int(np.abs(left.astype(np.int16)-right.astype(np.int16)).max()),
                                     'exif_stripped':not bool(first.getexif()) and not bool(second.getexif()),
                                     'srgb_profiles_present':bool(first.info.get('icc_profile')) and bool(second.info.get('icc_profile'))})
            if not pixel_checks[-1]['pixels_equal']:
                raise RuntimeError('Single RAW development changed encoded pixel output.')
            print(json.dumps({'iteration':index,'before_seconds':before_times[-1],'after_seconds':after_times[-1],
                              'before_decode_calls':len(calls_before),'after_decode_calls':len(calls_after)}),flush=True)
        median_before=statistics.median(before_times);median_after=statistics.median(after_times)
        report['cases'].append({'name':'14.2 megapixel full-resolution Portra-inspired JPEG export',
                                'before_seconds':before_times,'after_seconds':after_times,
                                'median_before_seconds':median_before,'median_after_seconds':median_after,
                                'speedup':median_before/median_after,
                                'time_reduction_percent':100*(1-median_after/median_before),
                                'baseline_decode_calls':counts_before,'optimized_decode_calls':counts_after,
                                'equivalence_checks':pixel_checks})
    report['source_preserved']=sha(source)==original_sha
    report['limitations']=['Cloud Linux CPU only; not measured on native Apple Silicon or Windows.',
                           'Generated Bayer DNG only; not a benchmark across real camera formats.',
                           'Recognition disabled to isolate RAW decode orchestration.',
                           'Both branches use current rendering kernels, so renderer optimizations are not included.']
    destination=ROOT/'performance-v0.5.3-raw-export.json'
    destination.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(destination,flush=True)


if __name__=='__main__':
    main()
