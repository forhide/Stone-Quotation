"""Reproducible fixed-resolution rendering benchmark; no camera files."""
import argparse, copy, hashlib, importlib.util, json, statistics, sys, time
from pathlib import Path
import cv2
import numpy as np

ROOT=Path('/workspace/Personal-Color-Lab')
sys.path.insert(0,str(ROOT))
from personal_color_lab.core import style_render
from personal_color_lab.core import style_regions
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.style_dna import builtin_styles,blend_styles

def load_baseline():
    spec=importlib.util.spec_from_file_location('personal_color_lab.core._render_v052_baseline','/workspace/scratch/pcl_style_render_v052_baseline.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def load_baseline_regions():
    spec=importlib.util.spec_from_file_location('personal_color_lab.core._regions_v051_baseline','/workspace/scratch/pcl_style_regions_v051_baseline.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def fixture(width,height):
    rng=np.random.default_rng(20261012)
    yy,xx=np.indices((height,width),dtype=np.float32)
    fields=np.stack([.12+.72*xx/width,.1+.78*yy/height,.08+.65*(xx/width*.4+yy/height*.6)],axis=2)
    return np.rint(np.clip(fields+rng.normal(0,.045,fields.shape),0,1)*255).astype('uint8')

def regional_style():
    a,b=copy.deepcopy(builtin_styles()[0]),copy.deepcopy(builtin_styles()[4])
    for dna,shift in [(a,[3.,-2.]),(b,[-2.,3.])]:
        dna['semantic_profile']['bundle_id']='a'*64
        for region,scale in [('person',.9),('food',1.05),('background',.85)]:
            dna['semantic_profile']['regions'][region]={'sample_count':2,'evidence':'observed_transform','target':None,
                'tone_curve':np.clip(np.linspace(0,1,33)+.045,0,1).tolist(),'saturation_scale':scale,'lab_shift':shift}
    return blend_styles([a,b],[.6,.4])

def scene():
    masks={key:np.zeros((240,360),np.float32) for key in REGIONS}
    masks['person'][:,80:200]=.9;masks['food'][140:,230:]=.95
    masks['face'][25:90,110:165]=.92
    masks['background']=1-np.maximum.reduce([masks[k] for k in REGIONS if k!='background'])
    return {'report':{'bundle_id':'a'*64,'scene_tags':['people','food']},'masks':masks}

def run(module, pixels, regional=False):
    dna=regional_style() if regional else builtin_styles()[0]
    if regional is False: dna.update(exposure_ev=.7); dna['channel_curves']['red']=np.clip(np.linspace(0,1,33)*1.07,0,1).tolist()
    effective,measurement=module.prepare_style(pixels,dna)
    if regional:
        before=module is not style_render
        if before:
            old_mask,old_face=style_regions.resized_mask_tile,style_regions.protect_face_colors
            baseline_regions=style_regions
            style_regions.resized_mask_tile=baseline_regions.resized_mask_tile
            style_regions.protect_face_colors=baseline_regions.protect_face_colors
        try:return module._render_regions(pixels,effective,dna,.8,scene(),.7,True,None,measurement=measurement)
        finally:
            if before:style_regions.resized_mask_tile,style_regions.protect_face_colors=old_mask,old_face
    return module.apply_pixels(pixels,effective,.8)[0]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);parser.add_argument('--repeats',type=int,default=5)
    args=parser.parse_args();cv2.setNumThreads(1)
    baseline=load_baseline();report={'seed':20261012,'opencv_threads':1,'repeats':args.repeats,
        'timing_method':'Warm each path once; alternate before/after execution order per repeat; wall-clock perf_counter; full fixed dimensions.',
        'baseline_version':'0.5.2','versions':{'numpy':np.__version__,'opencv':cv2.__version__},
        'baseline_render_sha256':hashlib.sha256(Path('/workspace/scratch/pcl_style_render_v052_baseline.py').read_bytes()).hexdigest(),
        'baseline_regions_sha256':hashlib.sha256(Path(style_regions.__file__).read_bytes()).hexdigest(),
        'candidate_render_sha256':hashlib.sha256(Path(style_render.__file__).read_bytes()).hexdigest(),
        'candidate_regions_sha256':hashlib.sha256(Path(style_regions.__file__).read_bytes()).hexdigest(),'cases':[]}
    for width,height,regional in [(1200,800,False),(1200,800,True),(4000,2600,False),(3000,2000,True)]:
        pixels=fixture(width,height);timings={};outputs={}
        modules={'before':baseline,'after':style_render};durations={'before':[],'after':[]}
        for module in modules.values():run(module,pixels,regional)
        for repeat in range(args.repeats):
            labels=['before','after'] if repeat%2==0 else ['after','before']
            for label in labels:
                start=time.perf_counter();result=run(modules[label],pixels,regional);durations[label].append(time.perf_counter()-start)
                outputs[label]=result
        for label in modules:
            timings[label]={'seconds':durations[label],'median_seconds':statistics.median(durations[label])}
        delta=np.abs(outputs['after'].astype(np.int16)-outputs['before'].astype(np.int16))
        report['cases'].append({'width':width,'height':height,'regional_hybrid':regional,'input_sha256':hashlib.sha256(pixels).hexdigest(),
            'timings':timings,'speedup':timings['before']['median_seconds']/timings['after']['median_seconds'],
            'output_before_sha256':hashlib.sha256(outputs['before']).hexdigest(),'output_after_sha256':hashlib.sha256(outputs['after']).hexdigest(),
            'maximum_channel_difference':int(delta.max()),'mean_channel_difference':float(delta.mean())})
        Path(args.output).write_text(json.dumps(report,indent=2)+'\n')
        print(report['cases'][-1],flush=True)

if __name__=='__main__':main()
