"""Local-only recognition timings on external, non-redistributed fixtures."""
import argparse
import functools
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, '/workspace/Personal-Color-Lab')
import cv2
import numpy as np
from PIL import Image
from personal_color_lab.core import scene_analysis as scene, semantic_models as models

parser = argparse.ArgumentParser()
parser.add_argument('--threads', type=int)
parser.add_argument('--label', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--repeats', type=int, default=5)
args = parser.parse_args()
if args.threads is not None:
    cv2.setNumThreads(args.threads)
stages = {}
def time_stage(name, function):
    @functools.wraps(function)
    def timed(*a, **kw):
        start = time.perf_counter()
        result = function(*a, **kw)
        stages.setdefault(name, []).append(time.perf_counter()-start)
        return result
    return timed

scene.infer = time_stage('inference', scene.infer)
scene.detect_faces = time_stage('face_detection', scene.detect_faces)
scene.decode_objects = time_stage('decode_objects', scene.decode_objects)
scene._roi_mask = time_stage('roi_mask', scene._roi_mask)
scene.region_appearance = time_stage('region_appearance', scene.region_appearance)
fixture_root = Path('/workspace/.cache/pcl-semantic-validation')
cases = []
for name in ('messi5.jpg', 'basketball1.png', 'astronaut.png'):
    path = fixture_root/name
    pixels = np.asarray(Image.open(path).convert('RGB'))
    readings = []
    appearance_readings = []
    for iteration in range(args.repeats+1):
        start = time.perf_counter()
        analysis = scene.analyze_scene(pixels)
        elapsed = time.perf_counter()-start
        start = time.perf_counter()
        appearance = scene.region_appearance(pixels, analysis)
        appearance_elapsed = time.perf_counter()-start
        readings.append(elapsed)
        appearance_readings.append(appearance_elapsed)
    cases.append({'fixture': name, 'fixture_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'cold_or_first_seconds': readings[0], 'warm_seconds': readings[1:],
                  'warm_median_seconds': statistics.median(readings[1:]),
                  'appearance_seconds': appearance_readings,
                  'appearance_warm_median_seconds': statistics.median(appearance_readings[1:]),
                  'report': analysis['report'], 'appearance': appearance,
                  'mask_hashes': {k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in analysis['masks'].items()}})
result = {'label':args.label, 'opencv_version':cv2.__version__, 'threads':cv2.getNumThreads(),
          'cases':cases, 'stages':{k:{'count':len(v), 'total_seconds':sum(v), 'median_seconds':statistics.median(v)} for k,v in stages.items()},
          'fixture_redistribution':False, 'timing_limit':'Single Linux cloud CPU runtime; not native M1/Intel/Windows performance.'}
args.output.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'label':args.label, 'threads':result['threads'], 'warm_scene':[c['warm_median_seconds'] for c in cases],
                  'warm_appearance':[c['appearance_warm_median_seconds'] for c in cases], 'stages':result['stages']}))
