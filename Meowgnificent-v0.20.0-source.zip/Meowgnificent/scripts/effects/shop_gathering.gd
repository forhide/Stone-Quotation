class_name ShopGathering
extends Node2D

# The rest stop is a little gathering with shared solid floor contacts. All feet
# stay pinned to the floor, while breathing, looking over and one-shot gestures
# add life to the same animal portraits used by the story and merchant.
const ART: Texture2D = preload("res://art/npc/picnic_market.png")
const ART_REGION := Rect2(52,85,1511,841)
const MARKET_RECT := Rect2(405,300,470,260)
const TABLE_POSITION := Vector2(640,445)
const PIP_POSITION := Vector2(868,418)
const FRIEND_POSITIONS := {"moss":Vector2(408,478),"bloop":Vector2(858,484)}
const TALK_RADIUS := 98.0
const TALK_SECONDS := 8.5
const GESTURE_SECONDS := 1.7
const HEN_POSITION := Vector2(950,363)
const HEN_FEET := HEN_POSITION+Vector2(0,20)
const HEN_HEIGHT := 72.0
const DIALOGUE_PATH := "res://data/shop_dialogue.json"
var room: Node2D
var table_foreground: Node2D
var friends: Dictionary = {}
var friend_roots: Dictionary = {}
var gestures: Dictionary = {}
var steam: Array[Line2D] = []
var elapsed := 0.0
var _steam_tick := 0.0
var stage_index := -1
var player_position := Vector2(-1000,-1000)
var near_actor := ""
var active_actor := ""
var active_line := -1
var dialogue_remaining := 0.0
var talk_debounce := 0.0
var ambient_clock := 0.0
var ambient_turn := 0
var reaction_age: Dictionary = {}
var reaction_kind: Dictionary = {}
var dialogue_indices: Dictionary = {}
var dialogue: Dictionary = {}
var conversation: ShopConversation
var speech_layer: CanvasLayer
var prompt: Label
var _language := ""
var hen_root: Node2D
var hen_sprite: Sprite2D

func _ready() -> void:
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	dialogue=JSON.parse_string(FileAccess.get_file_as_string(DIALOGUE_PATH))
	for id: String in FRIEND_POSITIONS:
		var actor := Node2D.new()
		actor.name=id.capitalize()+"AtTeaRoot"
		actor.position=FRIEND_POSITIONS[id]
		actor.scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
		add_child(actor)
		friend_roots[id]=actor
		var sprite := Sprite2D.new()
		sprite.name=id.capitalize()+"AtTea"
		sprite.texture=AnimalCast.icon(id)
		sprite.centered=false
		var factor := 101.0/sprite.texture.get_height()
		sprite.scale=Vector2.ONE*factor
		sprite.position=Vector2(-sprite.texture.get_width()*factor*0.5,-101)
		actor.add_child(sprite)
		friends[id]=sprite
	# Pip's failed dragon summon is a painted little hen with a separate
	# floor anchor. It remains part of the living gathering, not the wallpaper.
	hen_root=Node2D.new()
	hen_root.name="PicnicHenRoot"
	hen_root.position=HEN_FEET
	hen_root.scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	add_child(hen_root)
	hen_sprite=Sprite2D.new()
	hen_sprite.name="PicnicHen"
	hen_sprite.texture=WorldDetailArt.icon("hen")
	hen_sprite.centered=false
	var hen_factor := HEN_HEIGHT/hen_sprite.texture.get_height()
	hen_sprite.scale=Vector2.ONE*hen_factor
	hen_sprite.position=Vector2(-hen_sprite.texture.get_width()*hen_factor*0.5,-HEN_HEIGHT)
	hen_root.add_child(hen_sprite)
	for id: String in ["moss","bloop","pip"]:
		var accent := ShopGesture.new()
		accent.name=id.capitalize()+"Reaction"
		accent.position=_anchor(id)
		accent.z_index=3
		accent.scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
		add_child(accent)
		gestures[id]=accent
		reaction_age[id]=GESTURE_SECONDS
		reaction_kind[id]="nod"
	for offset in [-11.0,0.0,11.0]:
		var line := Line2D.new()
		line.position=Vector2(642+offset,410)
		line.width=1.7
		line.default_color=Color(1,0.97,0.88,0.58)
		line.begin_cap_mode=Line2D.LINE_CAP_ROUND
		line.end_cap_mode=Line2D.LINE_CAP_ROUND
		line.antialiased=true
		add_child(line)
		steam.append(line)
	prompt=Label.new()
	prompt.name="NearbyFriendPrompt"
	prompt.add_theme_font_override("font",GameLocale.STORY_FONT)
	prompt.add_theme_font_size_override("font_size",16)
	prompt.add_theme_color_override("font_color",Color("725f5c"))
	prompt.add_theme_color_override("font_shadow_color",Color("fff9e8"))
	prompt.add_theme_constant_override("shadow_offset_x",1)
	prompt.add_theme_constant_override("shadow_offset_y",1)
	prompt.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	prompt.position=Vector2(430,600)
	prompt.size=Vector2(420,44)
	prompt.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	var prompt_paper := StyleBoxFlat.new()
	prompt_paper.bg_color=Color("fff8e8")
	prompt_paper.border_color=Color("c6b798")
	prompt_paper.set_border_width_all(1)
	prompt_paper.set_corner_radius_all(12)
	prompt_paper.content_margin_left=18
	prompt_paper.content_margin_right=18
	prompt.add_theme_stylebox_override("normal",prompt_paper)
	prompt.mouse_filter=Control.MOUSE_FILTER_IGNORE
	prompt.z_index=15
	speech_layer=CanvasLayer.new()
	speech_layer.name="ShopSpeechOverlay"
	speech_layer.layer=5
	add_child(speech_layer)
	# This is an interaction status card in screen space, not lettering floating
	# over the animal or becoming distorted by the scrolling world's scale.
	speech_layer.add_child(prompt)
	conversation=ShopConversation.new()
	speech_layer.add_child(conversation)
	_language=GameLocale.current
	_update_steam()
	visible=false

func configure(index: int, enabled: bool) -> void:
	var changed := stage_index!=index or visible!=enabled
	stage_index=index
	visible=enabled
	for actor in friend_roots.values(): actor.visible=enabled
	if is_instance_valid(hen_root): hen_root.visible=enabled
	self_modulate=Color("fff1f6") if index==6 else Color.WHITE
	if changed:
		active_actor=""
		active_line=-1
		dialogue_remaining=0
		talk_debounce=0
		ambient_clock=0
		ambient_turn=0
		near_actor=""
		dialogue_indices.clear()
		if is_instance_valid(conversation): conversation.dismiss()
		for id: String in reaction_age:
			reaction_age[id]=GESTURE_SECONDS
			if gestures.has(id): gestures[id].update_gesture("nod",1,0)
		for id: String in friend_roots:
			friend_roots[id].rotation=0
			friend_roots[id].scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
		if is_instance_valid(hen_root):
			hen_root.rotation=0
			hen_root.scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	_ensure_table_foreground()
	_refresh_prompt()

func _ensure_table_foreground() -> void:
	if not is_instance_valid(room): return
	var actor_parent: Node2D=room.get("actors")
	if not is_instance_valid(actor_parent): return
	if not is_instance_valid(table_foreground):
		table_foreground=Node2D.new()
		table_foreground.name="PicnicTableForeground"
		table_foreground.position=WorldLayout.point(Vector2(640,512))
		table_foreground.scale=Vector2.ONE*WorldLayout.SCALE
		var sprite := Sprite2D.new()
		var texture := AtlasTexture.new()
		texture.atlas=ART
		texture.region=Rect2(330,338,990,436)
		texture.filter_clip=true
		sprite.texture=texture
		sprite.centered=false
		sprite.position=MARKET_RECT.position+(texture.region.position-ART_REGION.position)*MARKET_RECT.size/ART_REGION.size-Vector2(640,512)
		sprite.scale=MARKET_RECT.size/ART_REGION.size
		sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
		table_foreground.add_child(sprite)
		actor_parent.add_child(table_foreground)
	elif table_foreground.get_parent()!=actor_parent:
		table_foreground.reparent(actor_parent)
	table_foreground.visible=visible

func set_player_position(point: Vector2) -> void:
	player_position=WorldLayout.canonical(point)
	near_actor=nearest_interaction(point)
	_refresh_prompt()

func nearest_interaction(point: Vector2) -> String:
	if not visible: return ""
	point=WorldLayout.canonical(point)
	var result := ""
	var distance := TALK_RADIUS
	for id: String in ["pip","moss","bloop"]:
		var candidate := point.distance_to(_anchor(id))
		if candidate<distance:
			distance=candidate
			result=id
	return result

func is_pip_near(point: Vector2) -> bool:
	return visible and WorldLayout.canonical(point).distance_to(PIP_POSITION)<120

func interact(actor_id: String) -> bool:
	if not visible or not actor_id in ["moss","bloop","pip"] or talk_debounce>0: return false
	var lines := _lines(actor_id)
	if lines.is_empty(): return false
	if active_actor==actor_id: return advance_dialogue()
	active_actor=actor_id
	active_line=0
	dialogue_indices[actor_id]=0
	dialogue_remaining=TALK_SECONDS
	_show_active_line()
	return true

func _show_active_line() -> void:
	talk_debounce=0.18
	var line: Dictionary=_lines(active_actor)[active_line]
	reaction_age[active_actor]=0.0
	reaction_kind[active_actor]=str(line.get("gesture","nod"))
	_refresh_conversation()
	_refresh_prompt()

func advance_dialogue() -> bool:
	if active_actor.is_empty(): return false
	if talk_debounce>0: return true
	active_line+=1
	if active_line>=_lines(active_actor).size():
		end_dialogue()
		return false
	dialogue_indices[active_actor]=active_line
	_show_active_line()
	return true

func end_dialogue() -> void:
	active_actor=""
	active_line=-1
	dialogue_remaining=0
	dialogue_indices.clear()
	talk_debounce=0.18
	conversation.dismiss()
	_refresh_prompt()

func reaction_for(actor_id: String) -> float:
	var progress := clampf(float(reaction_age.get(actor_id,GESTURE_SECONDS))/GESTURE_SECONDS,0,1)
	return sin(progress*PI) if progress<1 else 0.0

func animate(delta: float) -> void:
	if not visible: return
	elapsed+=delta
	talk_debounce=maxf(0,talk_debounce-delta)
	ambient_clock+=delta
	if ambient_clock>=9.0 and dialogue_remaining<=0:
		ambient_clock=0.0
		var ambient_id: String=["moss","bloop","pip"][ambient_turn%3]
		reaction_age[ambient_id]=0.0
		reaction_kind[ambient_id]=str({"moss":"leaf","bloop":"bubble","pip":"feather"}[ambient_id])
		ambient_turn+=1
	for id: String in reaction_age:
		reaction_age[id]=minf(GESTURE_SECONDS,float(reaction_age[id])+delta)
	for id: String in friend_roots:
		var actor: Node2D=friend_roots[id]
		var phase := elapsed*1.8+(0.0 if id=="moss" else 1.7)
		var reaction := reaction_for(id)
		# Squash and tilt around the sole of the sprite; never translate it up.
		actor.scale=Vector2(1+sin(phase)*0.004-reaction*0.016,1+sin(phase)*0.006+reaction*0.015)*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
		var look := clampf((player_position.x-actor.position.x)/220,-1,1)
		actor.rotation=look*0.009+sin(phase*0.6)*0.003+sin(float(reaction_age[id])*9)*reaction*0.025
	if is_instance_valid(hen_root):
		# A small forward peck and Pip's feather gesture pivot about the feet.
		# Never bob the entire sprite upward: the hen should stand on the mat.
		var peck := pow(maxf(0.0,sin(elapsed*1.15-1.0)),8)
		var pip_reaction := reaction_for("pip")
		var breath := sin(elapsed*2.2)
		hen_root.rotation=-peck*0.065+sin(float(reaction_age.get("pip",GESTURE_SECONDS))*9)*pip_reaction*0.035
		hen_root.scale=Vector2(1+breath*0.004+pip_reaction*0.025,1+breath*0.006-peck*0.028-pip_reaction*0.018)*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	if not active_actor.is_empty():
		conversation.place_for_anchor(get_global_transform_with_canvas()*_anchor(active_actor))
		conversation.set_opacity(1.0)
	if _language!=GameLocale.current:
		_language=GameLocale.current
		_refresh_conversation()
		_refresh_prompt()
	_steam_tick+=delta
	if _steam_tick>=0.10:
		_steam_tick=0
		_update_steam()
		for id: String in gestures:
			var age := float(reaction_age[id])/GESTURE_SECONDS
			gestures[id].update_gesture(str(reaction_kind[id]),age,reaction_for(id))

func _anchor(id: String) -> Vector2:
	return PIP_POSITION if id=="pip" else Vector2(FRIEND_POSITIONS.get(id,TABLE_POSITION))

func _lines(id: String) -> Array:
	return dialogue.get("last_stop" if stage_index==6 else "picnic",{}).get(id,[])

func _localized(entry: Dictionary) -> String:
	return str(entry.get(GameLocale.current,entry.get("en","")))

func _ui(key: String) -> String:
	return _localized(dialogue.get("ui",{}).get(key,{}))

func _refresh_conversation() -> void:
	if not is_instance_valid(conversation) or active_actor.is_empty() or active_line<0: return
	var lines := _lines(active_actor)
	if active_line>=lines.size(): return
	var actor_name := _ui(active_actor)
	var hint := GameLocale.text("E · Next · %d / %d") % [active_line+1,lines.size()] if active_line+1<lines.size() else GameLocale.text("E · Finish conversation")
	conversation.show_line(active_actor,actor_name,_localized(lines[active_line]),hint,get_global_transform_with_canvas()*_anchor(active_actor))

func _refresh_prompt() -> void:
	if not is_instance_valid(prompt): return
	prompt.visible=visible and active_actor.is_empty() and not near_actor.is_empty()
	if not prompt.visible: return
	var id := near_actor
	if id.is_empty(): id="pip"
	prompt.text=GameLocale.text("E · Talk to %s") % _ui(id)

func _update_steam() -> void:
	for i in range(steam.size()):
		var line := steam[i]
		var points := PackedVector2Array()
		for j in range(5):
			var height := j*5.0
			points.append(Vector2(sin(elapsed*1.8+j*0.75+i)*2.1,-height))
		line.points=points

func snapshot() -> Dictionary:
	var identities: Dictionary={}
	var feet: Dictionary={}
	for id: String in friends:
		identities[id]=friends[id].texture
		feet[id]=friend_roots[id].position
	return {"visible":visible,"center":TABLE_POSITION,"rect":MARKET_RECT,"friends":identities,"clock":elapsed,"stage":stage_index,
		"feet":feet,"near_actor":near_actor,"active_actor":active_actor,"line":active_line,"talk_remaining":dialogue_remaining,
		"dialogue_visible":is_instance_valid(conversation) and conversation.visible,"prompt":prompt.text if is_instance_valid(prompt) else ""}

func _draw() -> void:
	draw_texture_rect_region(ART,MARKET_RECT,ART_REGION)
	draw_set_transform(HEN_FEET+Vector2(0,1),0,Vector2(1,0.25))
	draw_circle(Vector2.ZERO,23*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE),Color(0.37,0.31,0.29,0.10))
	draw_set_transform(Vector2.ZERO)
	# Ground contact is painted separately from breathing/gestures.
	for id: String in FRIEND_POSITIONS:
		draw_set_transform(FRIEND_POSITIONS[id]+Vector2(0,1),0,Vector2(1,0.25))
		draw_circle(Vector2.ZERO,29*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE),Color(0.37,0.31,0.29,0.12))
		draw_set_transform(Vector2.ZERO)
