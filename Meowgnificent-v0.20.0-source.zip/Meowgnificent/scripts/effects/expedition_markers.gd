class_name ExpeditionMarkers
extends Node2D

const EXIT_POSITION := Vector2(1136,430)
const SHOP_POSITION := Vector2(640,315)
const SHOP_APPROACH := Rect2(530,524,220,72)
const GATE_CLOSED: Texture2D = preload("res://art/items/archive_gate_closed.svg")
const GATE_OPEN: Texture2D = preload("res://art/items/archive_gate_open.svg")
const MERCHANT_ID := "pip"
const MERCHANT_NAME := "Pip"
const MERCHANT_TITLE := "Pip's Finds"
# Story portraits, the field merchant and the shop now share animal Pip.
const MERCHANT_ART: Texture2D = AnimalCast.SHEET
const MERCHANT_REGION: Rect2 = AnimalCast.REGIONS["pip"]
const MERCHANT_PORTRAIT_REGION: Rect2 = MERCHANT_REGION
const ROUTE_ART: Texture2D = preload("res://art/items/archive_route.svg")

class GateArt extends Node2D:
	var owner_marker: ExpeditionMarkers
	func _draw() -> void: owner_marker.paint_exit(self)

var actor_bridge: Node2D
var gate_art: GateArt
var room: Node2D
var _signature := ""
var _stage_index := 0
var _sector_name := "The Candlewick Archives"
var _kind := "combat"
var _exit_open := false
var _exit_near := false
var _shop_near := false
var merchant_root: Node2D
var merchant_sprite: Sprite2D
var merchant_time := 0.0
var gathering: ShopGathering
const EXIT_REVEAL_SECONDS := 0.55
var _exit_visible := false
var exit_reveal_age := 0.0
var exit_plate: StyleBoxFlat

func _ready() -> void:
	# Living landmarks join the room’s shared depth order.
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	scale=Vector2.ONE*WorldLayout.SCALE
	physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	z_index=-2
	exit_plate=_plate(Color("fff1d6"))
	gathering=ShopGathering.new()
	gathering.room=room
	add_child(gathering)
	_create_merchant()
	gate_art=GateArt.new()
	gate_art.owner_marker=self
	gate_art.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	gate_art.position=EXIT_POSITION
	add_child(gate_art)
	rehome_art()
	update_visuals()

func _create_merchant() -> void:
	merchant_root=Node2D.new()
	merchant_root.name="PipMerchant"
	# Pip stands beside the counter, clear of its foreground illustration.
	merchant_root.position=ShopGathering.PIP_POSITION
	add_child(merchant_root)
	merchant_sprite=Sprite2D.new()
	merchant_sprite.name="PipAndChicken"
	merchant_sprite.texture=AnimalCast.icon("pip")
	merchant_sprite.centered=false
	merchant_sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	var factor := 144.0/MERCHANT_REGION.size.y
	merchant_sprite.scale=Vector2.ONE*factor
	merchant_sprite.position=Vector2(-MERCHANT_REGION.size.x*factor*0.5,-144)
	merchant_root.add_child(merchant_sprite)
	merchant_root.scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	merchant_root.visible=false

func _process(delta: float) -> void:
	if not is_instance_valid(room) or room.state not in ["playing","conversation"]: return
	if _exit_visible and exit_reveal_age<EXIT_REVEAL_SECONDS:
		exit_reveal_age=minf(EXIT_REVEAL_SECONDS,exit_reveal_age+delta)
		if is_instance_valid(gate_art): gate_art.queue_redraw()
		queue_redraw()
	if _kind!="shop": return
	merchant_time+=delta
	# The feet stay at the same anchor. Only a barely visible breath passes
	# through the soft cape and the chicken held in Pip's arm.
	var reaction := gathering.reaction_for("pip") if is_instance_valid(gathering) else 0.0
	merchant_root.scale=Vector2(1+reaction*0.025,1+sin(merchant_time*2.2)*0.007-reaction*0.018)*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	merchant_root.rotation=sin(merchant_time*7.0)*0.035*reaction
	if is_instance_valid(gathering):
		gathering.set_player_position(room.player.position)
		gathering.animate(delta)

func is_shop_near(point: Vector2) -> bool:
	point=WorldLayout.canonical(point)
	return _kind=="shop" and SHOP_APPROACH.has_point(point)

func merchant_snapshot() -> Dictionary:
	return {"id":MERCHANT_ID,"name":MERCHANT_NAME,"species":AnimalCast.species("pip"), "visible":is_instance_valid(merchant_root) and merchant_root.visible,
		"anchor":SHOP_POSITION,"feet":merchant_root.position if is_instance_valid(merchant_root) else Vector2.ZERO,
		"texture":merchant_sprite.texture if is_instance_valid(merchant_sprite) else null,"portrait_region":MERCHANT_PORTRAIT_REGION}

func update_visuals() -> void:
	if not is_instance_valid(room) or room.run==null:
		return
	var stage_index := int(room.run.stage_index)
	var sector_name := str(room.stage_def.get("name","The Candlewick Archives"))
	var kind := str(room.stage_def.get("kind","combat"))
	var exit_open := bool(room.exit_open)
	var exit_near := false
	var shop_near := false
	var exit_visible := exit_open and stage_index<7 and kind!="final"
	if is_instance_valid(room.player):
		var local_player := WorldLayout.canonical(room.player.position)
		exit_near=local_player.distance_to(EXIT_POSITION)<86
		shop_near=kind=="shop" and SHOP_APPROACH.has_point(local_player)
	var signature := GameLocale.text("%d|%s|%s|%s|%s|%s") % [stage_index,sector_name,kind,exit_open,exit_near,shop_near]
	signature+=GameLocale.current
	if signature==_signature:
		return
	_signature=signature
	if is_instance_valid(room.get("obstacles")):
		room.obstacles.remove_static("exit_gate")
		if exit_visible:
			room.obstacles.add_static("gate",WorldLayout.rect(Rect2(EXIT_POSITION-Vector2(57,22),Vector2(114,40))),"exit_gate")
			room.player.position=room.obstacles.safe_point(room.player.position,room.bounds,17)
	if stage_index!=_stage_index or not exit_visible or not _exit_visible:
		exit_reveal_age=0.0
	_exit_visible=exit_visible
	if is_instance_valid(gate_art):
		gate_art.visible=exit_visible
		gate_art.queue_redraw()
	_stage_index=stage_index
	_sector_name=sector_name
	_kind=kind
	_exit_open=exit_open
	_exit_near=exit_near
	_shop_near=shop_near
	if is_instance_valid(merchant_root): merchant_root.visible=_kind=="shop"
	if is_instance_valid(gathering): gathering.configure(stage_index,_kind=="shop")
	queue_redraw()

func exit_snapshot() -> Dictionary:
	return {"visible":_exit_visible,"progress":clampf(exit_reveal_age/EXIT_REVEAL_SECONDS,0,1),"stage":_stage_index,"unlocked":_exit_open}

func _draw() -> void:
	pass
	if _kind=="shop":
		draw_set_transform(merchant_root.position+Vector2(0,4),0,Vector2(1,0.28))
		draw_circle(Vector2.ZERO,33*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE),Color(0.39,0.33,0.31,0.16))
		draw_set_transform(Vector2.ZERO)

func paint_exit(c: CanvasItem) -> void:
	var progress := clampf(exit_reveal_age/EXIT_REVEAL_SECONDS,0,1)
	var ease := 1.0-pow(1.0-progress,3)
	var glow := Color("e5c9ef")
	glow.a=(1.0-progress)*0.7
	if progress<1:
		c.draw_set_transform(Vector2.ZERO+Vector2(0,3),0,Vector2(1,0.3))
		c.draw_arc(Vector2.ZERO,38+progress*28,0,TAU,32,glow,3,true)
		c.draw_set_transform(Vector2.ZERO)
		for i in range(3):
			var at := Vector2.ZERO+Vector2.from_angle(-PI*0.85+i*PI*0.35)*Vector2(56,90)*(0.8+progress*0.4)+Vector2(0,-70)
			var radius := 3.5+sin(progress*PI)*2.5
			c.draw_line(at-Vector2(radius,0),at+Vector2(radius,0),glow,2,true)
			c.draw_line(at-Vector2(0,radius),at+Vector2(0,radius),glow,2,true)
	EnchantedArt.stamp(c,"portal",Vector2.ZERO+Vector2(0,-86+(1-ease)*8),Vector2(151,171),ease)
	

func _plate(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=Color("b6a092")
	style.set_border_width_all(1)
	style.set_corner_radius_all(10)
	return style

func rehome_art() -> void:
	var parent: Node=room.get("actors")
	if not is_instance_valid(parent): return
	if not is_instance_valid(actor_bridge):
		actor_bridge=Node2D.new()
		actor_bridge.name="LivingWorldDepth"
		actor_bridge.y_sort_enabled=true
		actor_bridge.physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
		actor_bridge.scale=Vector2.ONE*WorldLayout.SCALE
		parent.add_child(actor_bridge)
	elif actor_bridge.get_parent()!=parent: actor_bridge.reparent(parent)
	var roots: Array[Node2D]=[merchant_root,gate_art,gathering.hen_root]
	for friend in gathering.friend_roots.values(): roots.append(friend)
	for node in roots:
		if is_instance_valid(node) and node.get_parent()!=actor_bridge: node.reparent(actor_bridge,false)
