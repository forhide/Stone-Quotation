class_name MiscastBurst
extends Node2D

var room: Node2D
var age := 0.0
const DURATION := 1.05

func _ready() -> void:
	z_index = 20
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR

func _process(delta: float) -> void:
	if room.state != "playing":
		return
	age += delta
	if age >= DURATION:
		queue_free()
	queue_redraw()

func _draw() -> void:
	var fade := clampf((DURATION-age)/0.35,0.0,1.0)
	# One layered smoke sprite, with crooked red sparks baked into the image.
	var spread := 0.68+age*0.48
	draw_set_transform(Vector2(0,-22-age*21),sin(age*6)*0.035,Vector2.ONE*spread)
	draw_texture_rect(SpellArt.part("smoke"),Rect2(-100,-134,200,172),false,Color(1,1,1,fade))
	draw_set_transform(Vector2.ZERO)
	var center := Vector2(0,-105-age*12)
	var red := Color(0.79,0.28,0.32,fade)
	# The crossed spark and soot distinguish failure without world typography.
	draw_circle(center,13,Color(1,0.94,0.83,fade*0.98))
	draw_line(center-Vector2(6,6),center+Vector2(6,6),red,4,true)
	draw_line(center+Vector2(-6,6),center+Vector2(6,-6),red,4,true)
