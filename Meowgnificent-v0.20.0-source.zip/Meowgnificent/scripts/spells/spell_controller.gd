class_name SpellController
extends Node

signal spell_emitted(outcome: String, point: Vector2)
var config: Dictionary
var resolver := SpellOutcomeResolver.new()
var cooldown := 0.0
var player: WizardCat
var room: Node2D
var last_outcome := ""
var pending := false
var prepare_time := 0.0
var pending_direction := Vector2.RIGHT
var input_blocked_until_release := false
var pending_magic: Dictionary = {}
var pending_config: Dictionary = {}
var last_element := "fire"

func _physics_process(delta: float) -> void:
	if not player.active:
		return
	cooldown = maxf(0.0,cooldown-delta)
	if pending:
		if player.roll_time>0:
			pending=false
			pending_magic.clear()
			pending_config.clear()
			player.cast_prepare=0
			cooldown=minf(cooldown,0.2)
		else:
			prepare_time=maxf(0,prepare_time-delta)
			player.cast_prepare=prepare_time
			if prepare_time<=0:
				pending=false
				_emit_spell(pending_direction)
	if input_blocked_until_release:
		if not Input.is_action_pressed("cast"): input_blocked_until_release=false
		return
	if player.active and Input.is_action_pressed("cast"):
		cast(player.aim)

func cast(direction: Vector2) -> bool:
	if not player.active or player.roll_time>0 or player.skill_pose_time>0.18 or pending or cooldown > 0:
		return false
	cooldown = float(config.cooldown)
	last_outcome = resolver.resolve(config)
	pending=true
	prepare_time=0.12
	pending_direction=direction.normalized() if direction.length_squared()>0.001 else player.aim.normalized()
	if pending_direction.length_squared()<0.1: pending_direction=Vector2.RIGHT
	# Snapshot the actual owned tool and totals when the paw begins its cast.
	# Inventory can pause this anticipation, but cannot transform an in-flight spell.
	pending_magic=BasicMagic.for_run(room.run)
	player.cast_element=str(pending_magic.id)
	pending_config=config.duplicate(true)
	player.cast_aim=pending_direction
	player.cast_prepare=prepare_time
	return true

func _emit_spell(direction: Vector2) -> bool:
	player.cast_prepare=0
	player.cast_outcome=last_outcome
	player.cast_pose=1.0
	var spell: Dictionary=pending_config.duplicate(true) if not pending_config.is_empty() else config.duplicate(true)
	var magic: Dictionary=pending_magic.duplicate(true) if not pending_magic.is_empty() else BasicMagic.for_run(room.run)
	pending_config.clear()
	pending_magic.clear()
	last_element=str(magic.id)
	var launch := direction.normalized()
	if launch.length_squared()<0.1: launch=Vector2.RIGHT
	if room.has_method("pay_cast_cost") and not room.pay_cast_cost(last_outcome): return false
	var projectile := SpellProjectile.new()
	projectile.outcome=last_outcome
	projectile.speed=float(spell.speed)
	projectile.lifetime=float(spell.lifetime)
	projectile.damage=int(spell.success_damage)
	projectile.configure_magic(last_element)
	if last_outcome=="miscast":
		projectile.damage=int(spell.miscast_damage)
		projectile.speed*=0.72
		projectile.lifetime=1.3
		projectile.radius*=6.0/9.0
		var variant := resolver.rng.randi_range(0,2)
		if variant==2:
			# Only fire burns the floor. Other failed spells splash, skid or shove
			# the cat backward; they still create an accident that can crack a barrier.
			if last_element=="fire": room.ignite_floor(player.position)
			else:
				var puff := BasicMagicImpact.new()
				puff.element=last_element
				puff.position=player.position
				puff.size=2.0
				room.projectiles.add_child(puff)
			player.start_roll(-launch,true)
			room.aside("HOT PAWS! That was supposed to go forward." if last_element=="fire" else "Wrong way. Make it look intentional.",Color("ffac8f"),room.cast_cost(last_outcome))
			_elemental_blast(player.position,int(spell.miscast_damage),80.0,Vector2.ZERO,last_element,last_outcome)
			projectile.free()
			spell_emitted.emit(last_outcome,player.position)
			return true
		var angle := resolver.rng.randf_range(70.0,110.0) if variant==0 else 180.0
		launch=launch.rotated(deg_to_rad(angle))
		player.recoil=-launch*220
		room.aside("Wrong way. Make it look intentional.",Color("ffac8f"),room.cast_cost(last_outcome))
	elif last_outcome=="overreaction":
		projectile.damage=int(spell.overreaction_damage)
		projectile.radius*=23.0/9.0
		projectile.speed*=0.75
		player.recoil=-launch*310
		room.aside("Excellent spell. Unexpected recoil.",Color("ffdc8b"),room.cast_cost(last_outcome))
		projectile.explosion_radius=float(spell.explosion_radius)
	projectile.direction=launch
	projectile.room=room
	projectile.bounds=player.bounds
	projectile.position=player.position+launch*33
	var emitted_element := last_element
	var emitted_outcome := last_outcome
	projectile.impacted.connect(func(point: Vector2,amount: int,blast_radius: float,push: Vector2): _elemental_blast(point,amount,blast_radius,push,emitted_element,emitted_outcome))
	room.projectiles.add_child(projectile)
	spell_emitted.emit(last_outcome,player.position)
	return true

func _elemental_blast(point: Vector2,damage: int,radius: float,direction: Vector2,element: String,outcome: String) -> void:
	room.apply_blast(point,damage,radius,direction,BasicMagic.color(element),outcome,element)
