class_name PaintedProjectileArt
extends RefCounted

const SHEET: Texture2D=preload("res://art/fx/painted_projectiles.png")
const ELEMENTS := ["fire","water","ice","wind","stone","leaf","lightning","metal"]
static var _parts: Dictionary={}

static func icon(element: String,critical: bool=false) -> Texture2D:
	var index := maxi(0,ELEMENTS.find(element))+(8 if critical else 0)
	if not _parts.has(index):
		var texture := AtlasTexture.new()
		texture.atlas=SHEET
		var cell := SHEET.get_size()/4.0
		texture.region=Rect2(Vector2(index%4,index/4)*cell+Vector2(3,3),cell-Vector2(6,6))
		texture.filter_clip=true
		_parts[index]=texture
	return _parts[index]

static func draw(c: CanvasItem,element: String,at: Vector2,direction: Vector2,age: float,scale_factor: float,outcome: String) -> void:
	var critical := outcome=="overreaction"
	# Collider power and visual size have separate roles. The critical uses a
	# different authored silhouette, not a2.5x enlarged normal texture.
	var material_scale := scale_factor/(23.0/9.0) if critical else scale_factor
	var edge := (62.0 if critical else 43.0)*material_scale
	var angle := 0.0
	if element in ["metal","lightning","leaf"]: angle=direction.angle()
	elif element=="ice": angle=sin(age*2.0)*0.13
	elif element=="wind": angle=age*0.65
	elif element=="stone": angle=sin(age*3.5)*0.09
	else: angle=sin(age*5.0)*0.035
	var breathe := Vector2(1+sin(age*8)*0.025,1+cos(age*7)*0.025)
	c.draw_set_transform(at,angle,breathe)
	c.draw_texture_rect(icon(element,critical),Rect2(Vector2(-edge/2,-edge/2),Vector2(edge,edge)),false)
	c.draw_set_transform(Vector2.ZERO)
