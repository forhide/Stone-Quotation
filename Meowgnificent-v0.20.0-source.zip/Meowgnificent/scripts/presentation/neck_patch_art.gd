class_name NeckPatchArt
extends RefCounted

# Lossless runtime atlas of the exact original clean-fur pixels, not resized.
const ACTIONS: Texture2D=preload("res://art/characters/neck_patches_actions.res")
const ACTIONS_REGIONS := [{"source":Vector4(0.372998, 0.52495, 0.162471, 0.163673),"patch":Vector4(0.020833, 0.03125, 0.184896, 0.320312)},{"source":Vector4(0.331002, 0.527054, 0.16317, 0.162325),"patch":Vector4(0.354167, 0.03125, 0.182292, 0.316406)},{"source":Vector4(0.562914, 0.533755, 0.163355, 0.162447),"patch":Vector4(0.6875, 0.03125, 0.192708, 0.300781)},{"source":Vector4(0.356, 0.411894, 0.164, 0.162996),"patch":Vector4(0.020833, 0.53125, 0.213542, 0.289062)},{"source":Vector4(0.4, 0.526087, 0.164444, 0.163043),"patch":Vector4(0.354167, 0.53125, 0.192708, 0.292969)},{"source":Vector4(0.41978, 0.41844, 0.162637, 0.163121),"patch":Vector4(0.6875, 0.53125, 0.192708, 0.269531)}]
const WALK: Texture2D=preload("res://art/characters/neck_patches_walk.res")
const WALK_REGIONS := [{"source":Vector4(0.368421, 0.501006, 0.162471, 0.162978),"patch":Vector4(0.020833, 0.03125, 0.184896, 0.316406)},{"source":Vector4(0.365967, 0.501002, 0.16317, 0.162325),"patch":Vector4(0.354167, 0.03125, 0.182292, 0.316406)},{"source":Vector4(0.376744, 0.506048, 0.162791, 0.163306),"patch":Vector4(0.6875, 0.03125, 0.182292, 0.316406)},{"source":Vector4(0.375854, 0.513238, 0.164009, 0.162933),"patch":Vector4(0.020833, 0.53125, 0.1875, 0.3125)},{"source":Vector4(0.361751, 0.523109, 0.163594, 0.163866),"patch":Vector4(0.354167, 0.53125, 0.184896, 0.304688)},{"source":Vector4(0.373853, 0.505133, 0.162844, 0.162218),"patch":Vector4(0.6875, 0.53125, 0.184896, 0.308594)}]

static func selection(walking: bool,index: int) -> Dictionary:
 return (WALK_REGIONS if walking else ACTIONS_REGIONS)[index]
