class_name NecklaceCord
extends RefCounted

static var _curve := _make_curve()
static func _make_curve() -> PackedVector2Array:
	var points := PackedVector2Array()
	for i in range(25):
		var t := float(i)/24
		points.append(Vector2(lerpf(-19,19,t),-13+sin(t*PI)*6.5))
	return points

static func draw(canvas: CanvasItem,id: String,at: Vector2,factor: float=1.0) -> void:
	if id.is_empty(): return
	var color := Color("6b5b50")
	if "linen" in id or "velvet" in id: color=Color("bc9986")
	elif "silver" in id or "moon" in id or "frost" in id: color=Color("b7bfc8")
	elif "moss" in id or "acorn" in id: color=Color("839675")
	elif "rain" in id or "bloop" in id or "pearl" in id: color=Color("80a7ab")
	canvas.draw_set_transform(at,0,Vector2.ONE*factor)
	canvas.draw_polyline(_curve,color.darkened(0.35),3.6,true)
	canvas.draw_polyline(_curve,color,2.1,true)
	canvas.draw_circle(Vector2(0,-6.2),1.8,Color("c8b695"),true,-1,true)
	canvas.draw_set_transform(Vector2.ZERO)
