class_name RoomScenery
extends Node

# Painted border furniture occupies the floor too. These authored silhouettes
# reserve the visible shelves, pots, signs and foreground walls; rugs, paving
# and low flowers in the lawn remain walkable.
var room: Node2D
var glyphs: Array[Node2D]=[]

static func floor_rects(index: int) -> Array[Rect2]:
	var out: Array[Rect2]=[]
	if index in [2,3,5]:
		out.assign([Rect2(0,0,1280,139),Rect2(0,139,111,661),Rect2(1184,139,96,661),Rect2(0,668,1280,132),Rect2(165,139,379,49),Rect2(736,139,379,49),Rect2(112,144,54,61),Rect2(1115,144,53,61),Rect2(528,139,40,25),Rect2(731,139,42,25)])
	elif index in [1,4,7]:
		out.assign([Rect2(0,0,320,225),Rect2(320,0,240,150),Rect2(560,0,240,175),Rect2(800,0,225,205),Rect2(1025,0,255,262),Rect2(0,225,74,202),Rect2(0,427,82,373),Rect2(82,531,74,269),Rect2(156,620,98,180),Rect2(1208,375,72,425),Rect2(1160,488,48,312),Rect2(1080,586,80,214),Rect2(998,694,82,106)])
	else:
		out.assign([Rect2(0,0,304,296),Rect2(304,0,521,217),Rect2(825,0,90,230),Rect2(915,0,136,246),Rect2(1051,0,138,282),Rect2(1189,0,91,408),Rect2(0,296,121,196),Rect2(1210,408,70,108),Rect2(0,492,108,308),Rect2(108,613,56,187),Rect2(1200,516,80,284),Rect2(1144,633,56,167),Rect2(0,756,1280,44)])
	return out

func configure(index: int) -> void:
	for glyph in glyphs:
		if is_instance_valid(glyph) and not glyph.is_queued_for_deletion(): glyph.queue_free()
	glyphs.clear()
	for rect in floor_rects(index): room.obstacles.add_static("painted_scenery",WorldLayout.rect(rect))
	if index in [1,4]: _sign("library",Vector2(504,190),Vector2(67,78))
	if index in [2,5]: _sign("garden",Vector2(912,254),Vector2(60,72))
	if index in [3,6]:
		for at in [ShopGathering.PIP_POSITION,ShopGathering.FRIEND_POSITIONS.moss,ShopGathering.FRIEND_POSITIONS.bloop]:
			room.obstacles.add_static("friend",WorldLayout.rect(Rect2(at-Vector2(20,13),Vector2(40,27))))
		room.obstacles.add_static("hen",WorldLayout.rect(Rect2(ShopGathering.HEN_FEET-Vector2(12,8),Vector2(24,16))))

func _sign(id: String,center: Vector2,extent: Vector2) -> void:
	var feet := center+Vector2(0,extent.y*0.5-3)
	var root := Node2D.new()
	root.name=id.capitalize()+"WorldSign"
	root.position=WorldLayout.point(feet)
	root.scale=Vector2.ONE*WorldLayout.SCALE
	var sprite := Sprite2D.new()
	sprite.texture=WorldGlyphArt.icon(id)
	sprite.scale=extent/sprite.texture.get_size()
	sprite.position=center-feet
	sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	root.add_child(sprite)
	room.actors.add_child(root)
	glyphs.append(root)
	room.obstacles.add_static("sign",WorldLayout.rect(Rect2(feet-Vector2(15,9),Vector2(30,19))))
