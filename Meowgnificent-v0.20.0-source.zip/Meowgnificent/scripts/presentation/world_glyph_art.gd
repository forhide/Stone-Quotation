class_name WorldGlyphArt
extends RefCounted

# Authored world symbols, never translated typography pasted onto scenery.
const SHEET: Texture2D=preload("res://art/environments/painted_world_glyphs.png")
const REGIONS := {"library":Rect2(118,76,424,528),"garden":Rect2(703,72,421,533),"paving_moss":Rect2(46,717,562,419),"paving_grass":Rect2(646,719,562,416)}
static var _parts: Dictionary={}

static func icon(id: String) -> Texture2D:
	if not REGIONS.has(id): return null
	if not _parts.has(id):
		var texture := AtlasTexture.new()
		texture.atlas=SHEET
		texture.region=REGIONS[id]
		texture.filter_clip=true
		_parts[id]=texture
	return _parts[id]

static func stamp(canvas: CanvasItem,id: String,center: Vector2,extent: Vector2,tint: Color=Color.WHITE) -> void:
	canvas.draw_texture_rect(icon(id),Rect2(center-extent*0.5,extent),false,tint)
