class_name EnchantedArt
extends RefCounted

const LANDMARKS: Texture2D=preload("res://art/environments/enchanted_landmarks.png")
const PROPS: Texture2D=preload("res://art/environments/storybook_furnishings.png")
const BOOKCASES: Texture2D=preload("res://art/environments/academy_bookcases.png")
const BOOKCASE_IDS := ["shelf","fallen_shelf","fallen_back","fallen_side"]
const SUPPLIES: Texture2D=preload("res://art/environments/storybook_supplies.png")
const SUPPLY_IDS := ["crate","barrel","hatch","chest"]
const PROP_REGIONS := {"shelf":Rect2(100,20,460,575),"fallen_shelf":Rect2(627,40,627,580),"fallen_back":Rect2(0,650,620,604),"fallen_side":Rect2(627,650,627,604),"cart":Rect2(59,673,514,566),"planter":Rect2(686,658,470,552),"crate":Rect2(84,55,481,540),"barrel":Rect2(721,45,431,539),"hatch":Rect2(9,696,642,483),"chest":Rect2(705,657,504,553)}
const COMPANIONS: Texture2D=preload("res://art/fx/painted_companion_magic.png")
const EXTRA_REGIONS := {"bubble_painted":Rect2(126,9,508,485),"potion_splash":Rect2(779,1,720,491),"potion_bottle":Rect2(203,527,371,480),"feather":Rect2(783,508,683,503)}
const SPELLS: Texture2D=preload("res://art/fx/material_spells_a.png")
const SPELLS_B: Texture2D=preload("res://art/fx/material_spells_b.png")
const SKILL_REGIONS := {"fire_meteor":Rect2(2,2,623,623),"chain_lightning":Rect2(629,2,623,623),"tidal_surge":Rect2(2,629,623,623),"frost_nova":Rect2(629,629,623,623),"cyclone":Rect2(2,2,623,623),"stone_quake":Rect2(629,2,623,623),"verdant_grove":Rect2(2,629,623,623),"metal_bloom":Rect2(629,629,623,623)}
const REGIONS := {"ember":Rect2(12,151,267,276),"portal":Rect2(82,6,646,544),"seal":Rect2(782,72,698,434),"plaque":Rect2(62,608,688,361),"soot":Rect2(832,554,604,452)}
const SKILLS := ["fire_meteor","chain_lightning","tidal_surge","frost_nova","cyclone","stone_quake","verdant_grove","metal_bloom"]
static var _cache: Dictionary={}

static func part(id: String) -> Texture2D:
	if _cache.has(id): return _cache[id]
	var atlas := AtlasTexture.new()
	if EXTRA_REGIONS.has(id):
		atlas.atlas=COMPANIONS
		atlas.region=EXTRA_REGIONS[id]
	elif PROP_REGIONS.has(id):
		atlas.atlas=BOOKCASES if id in BOOKCASE_IDS else SUPPLIES if id in SUPPLY_IDS else PROPS
		atlas.region=PROP_REGIONS[id]
	elif id=="ember":
		atlas.atlas=SPELLS
		atlas.region=SKILL_REGIONS["fire_meteor"]
	elif REGIONS.has(id):
		atlas.atlas=SPELLS if id=="ember" else LANDMARKS
		atlas.region=REGIONS[id]
	else:
		var index := SKILLS.find(id)
		if index<0: return null
		atlas.atlas=SPELLS if index<4 else SPELLS_B
		atlas.region=SKILL_REGIONS[id]
	atlas.filter_clip=true
	_cache[id]=atlas
	return atlas

static func stamp(canvas: CanvasItem, id: String, at: Vector2, size: Vector2, alpha: float=1.0, angle: float=0.0, mirror: float=1.0) -> void:
	canvas.draw_set_transform(at,angle,Vector2(mirror,1))
	canvas.draw_texture_rect(part(id),Rect2(-size*0.5,size),false,Color(1,1,1,clampf(alpha,0,1)))
	canvas.draw_set_transform(Vector2.ZERO)
