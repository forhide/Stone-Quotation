class_name CandleSlime
extends Node2D

signal defeated(enemy: CandleSlime)
var obstacle_world: RoomObstacles
var config: Dictionary
var health: CombatHealth
var target: WizardCat
var bounds: Rect2
var cooldown := 0.0
var hit_flash := 0.0
var time := 0.0
var knockback := Vector2.ZERO
var active := true
var role := "candle"
var phase := "approach"
var phase_time := 0.0
var attack_direction := Vector2.RIGHT
var attack_hit := false
var attack_origin := Vector2.ZERO
var attack_floor_ink: AttackTelegraph
# Smooth HD storybook sprites and the mirrored wing share one GPU texture.
# Atlas resources are reused across rooms; no render-to-texture warmup on arrival.
const ENEMY_ATLAS: Texture2D = preload("res://art/enemies/storybook_familiars.png")
static var _art_textures: Dictionary = {}
var body_root: Node2D
var body_sprite: Sprite2D
var wing_roots: Array[Node2D] = []
var health_track: Line2D
var health_fill: Line2D
var foreground_effects: ForegroundEnemyEffects
var wet_time := 0.0
var affinity_feedback_time := 0.0
var last_affinity_element := ""
var last_affinity_reaction := "neutral"
var last_affinity_damage := 0
var last_affinity_multiplier := 1.0
var _affinity_key := ""
var _affinity_data: Dictionary = {}
var _affinity_tint := Color.WHITE

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	config = settings
	target = player
	bounds = room_bounds
	health = CombatHealth.new(int(config.hp))
	health.died.connect(_on_defeated)
	time = position.x
	health.changed.connect(_update_health)

func _physics_process(delta: float) -> void:
	_tick_affinity(delta)
	if not active or not is_instance_valid(target) or not target.active or health.current<=0:
		return
	var before_motion := position
	time += delta
	cooldown = maxf(0,cooldown-delta)
	hit_flash = maxf(0,hit_flash-delta)
	var remaining_before_tick := phase_time
	phase_time = maxf(0,phase_time-delta)
	var to_player := target.position-position
	match phase:
		"approach":
			var reach := 230.0 if role=="broom" else (150.0 if role=="bat" else 85.0)
			if to_player.length()<reach and cooldown<=0 and (not is_instance_valid(obstacle_world) or obstacle_world.clear_line(position,target.position,float(config.radius))):
				phase="windup"
				phase_time=warning_duration()
				attack_direction=to_player.normalized()
				attack_origin=position
				attack_hit=false
			else:
				var speed := float(config.speed)*(1.25 if role=="bat" else 0.8 if role=="broom" else 1.0)
				position+=(obstacle_world.steer(position,target.position,float(config.radius)) if is_instance_valid(obstacle_world) else to_player.normalized())*speed*delta
		"windup":
			attack_origin=position
			if phase_time<=0:
				phase="attack"
				phase_time=attack_duration()
		"attack":
			# The last physics tick may only contain part of the dash. Never
			# travel beyond the endpoint promised by its floor warning.
			_advance_dash(minf(delta,remaining_before_tick))
			if phase_time<=0:
				phase="recover"
				phase_time=float(config.get("attack_recovery",0.85))
		"recover":
			if phase_time<=0:
				phase="approach"
				cooldown=0.25
	position+=knockback*delta
	if is_instance_valid(obstacle_world): position=obstacle_world.sweep(before_motion,position,float(config.radius)).point
	position=position.clamp(bounds.position+Vector2.ONE*20,bounds.end-Vector2.ONE*20)
	knockback=knockback.move_toward(Vector2.ZERO,delta*550)
	queue_redraw()

func affinity_profile() -> Dictionary:
	var family := str(config.get("element_family",""))
	var key := role+":"+family
	if key!=_affinity_key:
		_affinity_key=key
		_affinity_data=ElementAffinity.profile(role,family)
		_affinity_tint=Color.WHITE.lerp(BasicMagic.color(family),0.18) if not str(_affinity_data.family).is_empty() else Color.WHITE
	return _affinity_data

func is_wet() -> bool:
	return wet_time>0.0

func affinity_snapshot() -> Dictionary:
	return {"profile":affinity_profile(),"wet_time":wet_time,"element":last_affinity_element,"reaction":last_affinity_reaction,"damage":last_affinity_damage,"multiplier":last_affinity_multiplier,"feedback_time":affinity_feedback_time}

func take_elemental_damage(amount: int, direction: Vector2, outcome: String, element: String) -> int:
	if amount<=0 or health==null or health.current<=0: return 0
	var response := ElementAffinity.response(affinity_profile(),element,is_wet())
	var before := health.current
	# Virtual dispatch is deliberate: the Grimoire predicts controlled spells
	# before any elemental state or feedback can be granted through its shield.
	take_spell_damage(ElementAffinity.damage(amount,float(response.multiplier)),direction,outcome)
	var applied := before-health.current
	if applied<=0: return 0
	last_affinity_element=element
	last_affinity_reaction=str(response.reaction)
	last_affinity_damage=applied
	last_affinity_multiplier=float(response.multiplier)
	affinity_feedback_time=0.85
	if element=="water": wet_time=ElementAffinity.WET_DURATION
	elif element=="lightning" and wet_time>0: wet_time=0.0
	queue_redraw()
	return applied

func take_spell_damage(amount: int, direction: Vector2, _outcome: String) -> void:
	take_damage(amount,direction)

func _tick_affinity(delta: float) -> void:
	# Rooted AI remains still, but its material state continues during play.
	if not is_instance_valid(target) or not target.active or health==null or health.current<=0: return
	var was_visible := wet_time>0 or affinity_feedback_time>0
	wet_time=maxf(0.0,wet_time-delta)
	affinity_feedback_time=maxf(0.0,affinity_feedback_time-delta)
	if was_visible: queue_redraw()

func _draw_affinity_feedback(canvas: CanvasItem, height: float=-92.0) -> void:
	var profile := affinity_profile()
	var family := str(profile.family)
	if not family.is_empty(): ElementAffinity.draw_icon(canvas,family,Vector2(0,height),5.5)
	if wet_time>0: ElementAffinity.draw_icon(canvas,"water",Vector2(20,height+12),4.0,0.80)
	if affinity_feedback_time<=0 or last_affinity_reaction=="neutral": return
	var alpha := minf(1.0,affinity_feedback_time*4.0)
	var at := Vector2(0,height-16-(0.85-affinity_feedback_time)*10)
	ElementAffinity.draw_icon(canvas,last_affinity_element,at,6.0,alpha)
	var up := last_affinity_reaction!="resist"
	var ink := Color(0.82,0.46,0.40,alpha) if up else Color(0.50,0.59,0.71,alpha)
	var arrow := at+Vector2(14,0)
	var sign_y := -1.0 if up else 1.0
	canvas.draw_line(arrow-Vector2(0,5*sign_y),arrow+Vector2(0,5*sign_y),ink,2.5,true)
	canvas.draw_polyline(PackedVector2Array([arrow+Vector2(-3.5,1.5*sign_y),arrow+Vector2(0,5*sign_y),arrow+Vector2(3.5,1.5*sign_y)]),ink,2.5,true)

func take_damage(amount: int, direction: Vector2) -> void:
	if amount<=0 or health.current<=0: return
	# died is synchronous: capture the final blow's direction before its echo.
	knockback=direction*240
	if health.damage(amount):
		hit_flash=0.15
		# A hit interrupts the telegraph: a clumsy roll can rescue a bad cast.
		phase="recover"
		phase_time=0.6

func _on_defeated() -> void:
	# Boss defeat already has its own authored story finale.
	if role!="examiner": EnemyDissolve.leave(self)
	defeated.emit(self)
	queue_free()

func _advance_dash(delta: float) -> void:
	# Use the warning's wall-clipped path, including a diagonal wall slide.
	# Checking only the endpoint could skip the cat during a slow frame.
	var travel := attack_speed()*maxf(delta,0.0)
	var arena := bounds.grow(-20.0)
	var path := AttackTelegraph.dash_path(position,attack_direction,travel,arena)
	position=(position+attack_direction*travel).clamp(arena.position,arena.end)
	# The ink helper supplies a0.01px synthetic line for a stationary warning.
	# Keep that rendering accommodation out of real movement/contact geometry.
	path[path.size()-1]=position
	if is_instance_valid(obstacle_world):
		var travel_path := obstacle_world.sweep(path[0],position,float(config.radius),false)
		position=travel_path.point
		path=travel_path.path
		if not travel_path.hit.is_empty():
			if role=="broom" and travel_path.hit.entry.has("shelf"):
				var shelf: Object=travel_path.hit.entry.shelf.get_ref()
				if is_instance_valid(shelf): shelf.topple(attack_direction)
			phase_time=0.0
	if attack_hit: return
	var reach_squared := contact_radius()*contact_radius()
	for i in range(1,path.size()):
		var closest := Geometry2D.get_closest_point_to_segment(target.position,path[i-1],path[i])
		if closest.distance_squared_to(target.position)<=reach_squared:
			target.take_damage(int(config.contact_damage),closest-attack_direction)
			attack_hit=true
			return

func _ready() -> void:
	_add_attack_telegraph()
	if role=="bat":
		for side in [-1,1]:
			var wing := Node2D.new()
			wing.scale.x=side
			wing.position=Vector2(side*7,-31)
			add_child(wing)
			wing_roots.append(wing)
			_add_part(wing,"bat_wing")
	body_root=Node2D.new()
	add_child(body_root)
	body_sprite=_add_part(body_root,role)
	health_track=_health_line(Color("8e7776"))
	health_fill=_health_line(Color("a5c593"))
	_update_health()
	_sync_visuals()
	if has_meta("elite"):
		var insignia := EliteInsignia.new()
		insignia.position=Vector2(0,-106)
		add_child(insignia)
	foreground_effects=ForegroundEnemyEffects.new()
	foreground_effects.enemy=self
	add_child(foreground_effects)

func _add_attack_telegraph() -> void:
	attack_floor_ink=AttackTelegraph.new()
	attack_floor_ink.enemy=self
	# Floor warnings remain below every y-sorted actor, never over its face.
	attack_floor_ink.z_index=-2
	attack_floor_ink.visible=false
	add_child(attack_floor_ink)

func _refresh_attack_telegraph() -> void:
	if attack_floor_ink==null: return
	# Elite size is an art transform; combat still uses room-space pixels.
	# Cancel inherited scale/rotation while retaining this floor layer's z.
	attack_floor_ink.global_transform=Transform2D(0.0,global_position)
	attack_floor_ink.visible=phase in ["windup","attack"]
	if attack_floor_ink.visible: attack_floor_ink.queue_redraw()

func warning_duration() -> float:
	return 0.5 if role=="bat" else 0.72

func attack_duration() -> float:
	return 0.38 if role=="broom" else 0.3

func attack_speed() -> float:
	return 500.0 if role=="broom" else 390.0 if role=="bat" else 210.0

func contact_radius() -> float:
	return float(config.radius)+float(target.config.radius)

func get_attack_preview() -> Dictionary:
	if phase not in ["windup","attack"]: return {}
	var origin := position if phase=="windup" else attack_origin
	var arena := bounds.grow(-20.0)
	var path := AttackTelegraph.dash_path(origin,attack_direction,attack_speed()*attack_duration(),arena)
	if is_instance_valid(obstacle_world): path=obstacle_world.sweep(origin,path[path.size()-1],float(config.radius),false).path
	for i in range(path.size()): path[i]-=position
	# All warnings describe danger to the player's foot-centre, including
	# their circular collider. Standing just outside a lane is always safe.
	return {"path":path,"radius":contact_radius(),"progress":1.0-clampf(phase_time/warning_duration(),0,1) if phase=="windup" else 1.0,"striking":phase=="attack"}

func _cached_art(key: String) -> Texture2D:
	if _art_textures.has(key): return _art_textures[key]
	var texture := AtlasTexture.new()
	texture.atlas=ENEMY_ATLAS
	texture.region=_atlas_region(key)
	texture.filter_clip=true
	_art_textures[key]=texture
	return texture

func _atlas_region(key: String) -> Rect2:
	match key:
		"broom": return Rect2(691,24,506,672)
		"bat": return Rect2(73,676,565,557)
		"bat_wing": return Rect2(676,769,556,365)
		_: return Rect2(38,60,599,612)

func _art_bounds(key: String) -> Rect2:
	match key:
		"broom": return Rect2(-32,-72,64,82)
		"bat": return Rect2(-18,-29,36,49)
		"bat_wing": return Rect2(-1.5,-25,52,34)
		_: return Rect2(-31,-65,62,70)

func _add_part(parent_node: Node2D, key: String) -> Sprite2D:
	var part := Sprite2D.new()
	part.texture=_cached_art(key)
	part.centered=false
	part.position=_art_bounds(key).position
	part.scale=_art_bounds(key).size/_atlas_region(key).size
	part.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	parent_node.add_child(part)
	return part

func _health_line(color: Color) -> Line2D:
	var line := Line2D.new()
	line.position=Vector2(0,-78)
	line.points=PackedVector2Array([Vector2(-20,0),Vector2(20,0)])
	line.width=3
	line.default_color=color
	line.antialiased=true
	add_child(line)
	return line

func _update_health(_current: int=0, _maximum: int=0) -> void:
	if health_track==null or health==null: return
	var damaged := health.current<health.maximum
	health_track.visible=damaged
	health_fill.visible=damaged
	if damaged:
		health_fill.points=PackedVector2Array([Vector2(-20,0),Vector2(-20+40*float(health.current)/health.maximum,0)])

func _sync_visuals() -> void:
	if body_root==null: return
	body_root.scale=Vector2.ONE
	affinity_profile()
	body_sprite.self_modulate=Color(1.28,1.18,1.1) if hit_flash>0 else _affinity_tint
	if role=="broom":
		body_root.rotation=attack_direction.x*0.2 if phase=="attack" else sin(time*3)*0.04
		body_root.position=Vector2(0,-3+sin(time*5)*0.7)
		body_root.scale=Vector2(1.04,0.94) if phase=="windup" else Vector2(0.96,1.04) if phase=="attack" else Vector2.ONE
	elif role=="bat":
		var lift := -31+sin(time*8)*4
		body_root.position=Vector2(0,lift)
		body_root.rotation=attack_direction.x*0.10 if phase=="attack" else sin(time*4)*0.035
		for i in range(wing_roots.size()):
			var side := -1.0 if i==0 else 1.0
			wing_roots[i].position=Vector2(side*7,lift)
			wing_roots[i].rotation=side*(sin(time*12)*0.22+(0.22 if phase=="windup" else -0.15 if phase=="attack" else 0.0))
			wing_roots[i].scale=Vector2(side,0.90+sin(time*12)*0.23)
	else:
		body_root.position=Vector2.ZERO
		body_root.rotation=sin(time*4)*0.045
		var squash := 0.10 if phase=="windup" else -0.06 if phase=="attack" else sin(time*4)*0.025
		body_root.scale=Vector2(1.0+squash,1.0-squash*1.2)
	_apply_hit_pose()

func _apply_hit_pose() -> void:
	if hit_flash<=0 or body_root==null: return
	var strength := clampf(hit_flash/0.15,0.0,1.0)
	# Small compression and lean give a spell some weight. The feet/root and
	# every attack collision stay on their existing world-space path.
	body_root.scale*=Vector2(1.0+0.075*strength,1.0-0.065*strength)
	body_root.rotation+=clampf(knockback.x/240.0,-1.0,1.0)*0.07*strength

func _draw() -> void:
	# Benchmarks may advance time while AI is inactive; pause itself keeps time frozen.
	_sync_visuals()
	if foreground_effects!=null: foreground_effects.queue_redraw()
	_refresh_attack_telegraph()
	draw_set_transform(Vector2(0,5),0,Vector2(1,0.30))
	draw_circle(Vector2.ZERO,25,Color(0.36,0.31,0.29,0.18))
	draw_set_transform(Vector2.ZERO)
	if role=="candle":
		var flame := body_root.transform*Vector2(sin(time*5)*1.2,-65)
		draw_circle(flame,12+sin(time*9),Color(1,0.81,0.54,0.13))

class EliteInsignia extends Node2D:
	func _draw() -> void:
		# A silhouette marker, not just a tint: important for the final examiner.
		var gold := Color("c39c63")
		draw_colored_polygon(PackedVector2Array([Vector2(-15,0),Vector2(-15,-9),Vector2(-7,-4),Vector2(0,-13),Vector2(7,-4),Vector2(15,-9),Vector2(15,0)]),Color("fff1d4"))
		draw_polyline(PackedVector2Array([Vector2(-15,0),Vector2(-15,-9),Vector2(-7,-4),Vector2(0,-13),Vector2(7,-4),Vector2(15,-9),Vector2(15,0),Vector2(-15,0)]),gold,1.5,true)
		for x in [-9,0,9]:
			draw_circle(Vector2(x,-1),1.3,gold)
		draw_colored_polygon(PackedVector2Array([Vector2(0,3),Vector2(3,6),Vector2(0,9),Vector2(-3,6)]),gold)

class ForegroundEnemyEffects extends Node2D:
	var enemy: CandleSlime

	func _draw() -> void:
		if not is_instance_valid(enemy): return
		enemy._draw_affinity_feedback(self)
		if enemy.phase=="recover":
			draw_arc(Vector2(0,-59),12,enemy.time*5,enemy.time*5+4,12,Color("8b859e"),2,true)
		if enemy.role=="candle":
			var flame := enemy.body_root.transform*Vector2(sin(enemy.time*5)*1.2,-65)
			draw_colored_polygon(PackedVector2Array([flame+Vector2(-5,2),flame+Vector2(-4,-4),flame+Vector2(sin(enemy.time*7)*2,-12),flame+Vector2(5,-2),flame+Vector2(4,5)]),Color("f1ba85"))
			draw_circle(flame+Vector2(0,1),2.8,Color("fff1d4"))
		if enemy.hit_flash>0:
			draw_arc(Vector2(0,-20),27,0,TAU,20,Color("e8ad95"),3,true)

