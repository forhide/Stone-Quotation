class_name SignatureSkillInk
extends RefCounted

# Material forms, separately moving contact shadows, highlights and impact
# tails. All source sprites are cached and no effect allocates per-frame nodes.
const KINDS := ["fire_meteor","chain_lightning","tidal_surge","frost_nova","cyclone","stone_quake","verdant_grove","metal_bloom"]
const COLORS := {"fire_meteor":Color("efad78"),"chain_lightning":Color("ead785"),"tidal_surge":Color("85c9dc"),"frost_nova":Color("a4d8e8"),"cyclone":Color("add7c4"),"stone_quake":Color("c4ae91"),"verdant_grove":Color("9ac187"),"metal_bloom":Color("b5bddb")}
const CREAM := Color("fff6dd")
const ROCKS := [Vector2(-0.34,-0.22),Vector2(0.30,-0.25),Vector2(-0.61,0.13),Vector2(0.59,0.13),Vector2(0.0,0.38)]
static var _path := PackedVector2Array()

static func draw(c: Node2D, kind: String, age: float, duration: float, delay: float, radius: float, direction: Vector2, outcome: String) -> void:
 var ink: Color=COLORS[kind]
 var ready := clampf(age/maxf(delay,0.01),0,1)
 if age<delay:
  _ellipse(c,Vector2.ZERO,Vector2(radius*0.72,radius*0.29),Color(ink,0.08+ready*0.09))
  c.draw_set_transform(Vector2.ZERO,0,Vector2(1,0.46))
  c.draw_arc(Vector2.ZERO,radius*0.78,-PI/2,-PI/2+ready*TAU,40,Color(CREAM,0.8),2.2,true)
  c.draw_set_transform(Vector2.ZERO)
  if kind=="fire_meteor":
   var landing := Vector2(80,-265)*(1-ready)
   _shadow(c,Vector2.ZERO,Vector2(radius*0.49,radius*0.18),ready*0.22)
   EnchantedArt.stamp(c,kind,landing+Vector2(12,-52),Vector2(142,166)*(0.70+ready*0.30),0.95)
  return
 var post := maxf(0,age-delay)
 var t := clampf(post/maxf(duration,0.01),0,1)
 var fade := 1.0-smoothstep(0.56,1.0,t)
 var grow := smoothstep(0,0.16,post)
 _ellipse(c,Vector2(0,2),Vector2(radius*0.84,radius*0.31),Color(ink,0.10*fade))
 # A short material corona and rising fragments tie anticipation to impact.
 # Reuse the spell atlas; fixed counts keep effects bounded on modest GPUs.
 if post<0.55 and kind!="chain_lightning":
  var element: String=["fire","lightning","water","ice","wind","stone","leaf","metal"][KINDS.find(kind)]
  var bloom := 1.0-smoothstep(0.15,0.55,post)
  for mote in range(3):
   var phase := float(mote)/3*TAU+0.4
   var point := Vector2.from_angle(phase)*Vector2(radius*0.62,radius*0.29)*(0.45+post*1.8)
   var extent := Vector2.ONE*(23+post*20)
   c.draw_texture_rect(PaintedProjectileArt.icon(element,false),Rect2(point-extent*0.5+Vector2(0,-8-post*25),extent),false,Color(1,1,1,bloom*0.68))

 match kind:
  "fire_meteor":
   _shadow(c,Vector2(4,8),Vector2(radius*0.67,radius*0.24),0.19*fade)
   _ellipse(c,Vector2.ZERO,Vector2(radius*0.7,radius*0.25),Color("ffc980",fade*0.22))
   var settling := 1.0-smoothstep(0.08,0.42,post)
   if settling>0:
    EnchantedArt.stamp(c,kind,Vector2(0,-40),Vector2(radius*1.28,radius*1.46)*(0.68+settling*0.32),fade*settling)
   EnchantedArt.stamp(c,"soot",Vector2(0,-30-post*26),Vector2(radius*1.85,radius*1.3)*(0.45+t*0.70),fade*0.55)
   c.draw_set_transform(Vector2.ZERO,0,Vector2(1,0.43))
   c.draw_arc(Vector2.ZERO,radius*(0.30+t*1.0),0,TAU,36,Color("efbf88",fade*0.82),2.8,true)
  "chain_lightning":
   _ellipse(c,Vector2.ZERO,Vector2(radius*0.6,radius*0.22),Color(ink,fade*0.16))
  "tidal_surge":
   _shadow(c,Vector2(0,10),Vector2(radius*0.72,radius*0.25),0.16*fade)
   var turn := clampf(direction.y,-1,1)*0.11
   EnchantedArt.stamp(c,kind,Vector2(0,-radius*0.36),Vector2(radius*1.85,radius*1.72)*Vector2(1+sin(age*7)*0.025,1+cos(age*6)*0.025),fade,turn,-1.0 if direction.x<0 else 1.0)
   for i in range(3):
    var droplet := Vector2(-direction.x*(0.3+i*0.24)*radius,8+sin(age*8+i)*4)
    _ellipse(c,droplet,Vector2(10,3.5)*(1-float(i)*0.18),Color(CREAM,fade*0.65))
  "frost_nova":
   for i in range(2):
    var born := maxf(0,post-float(i)*0.08)
    var lift := smoothstep(0,0.22,born)
    var point := Vector2(-0.28 if i==0 else 0.31,-0.04 if i==0 else 0.20)*radius
    var extent := Vector2(radius*1.30,radius*1.43)*(1.0 if i==0 else 0.78)
    _shadow(c,point+Vector2(2,5),Vector2(extent.x*0.37,extent.x*0.13),0.18*fade)
    EnchantedArt.stamp(c,kind,point-Vector2(0,extent.y*0.37*lift),extent*Vector2(1,lift),fade,0,-1.0 if i==1 else 1.0)
  "cyclone":
   _shadow(c,Vector2(4,5),Vector2(radius*0.56,radius*0.17),0.16*fade)
   EnchantedArt.stamp(c,kind,Vector2(sin(age*6)*3,-radius*0.67),Vector2(radius*1.48,radius*2.04)*(0.78+grow*0.22),fade,sin(age*5)*0.035)
   for i in range(3):
    var level := Vector2(sin(age*5+i)*4,-radius*(0.22+i*0.48))
    c.draw_set_transform(level,0,Vector2(1,0.23))
    c.draw_arc(Vector2.ZERO,radius*(0.24+i*0.21),age*3+i,age*3+i+PI*1.25,22,Color(CREAM,fade*0.45),1.7,true)
  "stone_quake":
   for i in range(ROCKS.size()):
    var born := maxf(0,post-i*0.065)
    var rise := smoothstep(0,0.20,born)
    var point: Vector2=ROCKS[i]*radius
    var extent := Vector2(radius*0.76,radius*(1.08 if i<2 else 0.82))
    _shadow(c,point+Vector2(3,6),Vector2(extent.x*0.40,extent.x*0.13),0.19*fade)
    if rise>0: EnchantedArt.stamp(c,kind,point-Vector2(0,extent.y*0.39*rise),extent*Vector2(1,rise),fade,0,-1.0 if i%2==1 else 1.0)
    if born<0.45: EnchantedArt.stamp(c,"soot",point+Vector2(0,-5),Vector2(53,29)*(0.65+born),fade*(1-born/0.45)*0.44)
  "verdant_grove","metal_bloom":
   var count := 2 if kind=="verdant_grove" else 3
   for i in range(count):
    var born := maxf(0,post-i*0.08)
    var rise := smoothstep(0,0.24,born)
    var side := float(i)-float(count-1)*0.5
    var point := Vector2(side*radius*0.64,(0.1+absf(side)*0.07)*radius)
    var extent := Vector2(radius*1.02,radius*1.43)
    _shadow(c,point+Vector2(2,5),Vector2(radius*0.36,radius*0.12),0.17*fade)
    var sway := sin(age*2.6+i)*0.035 if kind=="verdant_grove" else side*0.07
    if rise>0: EnchantedArt.stamp(c,kind,point-Vector2(0,extent.y*0.39*rise),extent*Vector2(1,rise),fade,sway,-1.0 if i%2==1 else 1.0)
 c.draw_set_transform(Vector2.ZERO)
 for i in range(4):
  var a := i*TAU/4+0.3
  var at := Vector2.from_angle(a)*Vector2(radius*0.68,radius*0.32)+Vector2(0,-26-post*12)
  _spark(c,at,(2.8+sin(age*5+i))*fade,Color(CREAM,fade*0.8))

static func draw_chain(c: Node2D, points: PackedVector2Array, age: float, duration: float, outcome: String) -> void:
 if points.size()<2: return
 var fade := 1.0-smoothstep(maxf(0.0,duration-0.3),duration,age)
 var ink := Color("e8d081") if outcome!="miscast" else Color("c9b6dc")
 for segment in range(1,points.size()):
  var start := points[segment-1]+Vector2(0,-20)
  var finish := points[segment]+Vector2(0,-20)
  var side := (finish-start).normalized().orthogonal()
  _path.resize(12)
  for i in range(12):
   var t := float(i)/11
   _path[i]=start.lerp(finish,t)+side*sin(t*PI)*(sin(i*7.1+age*43)*7+sin(i*3.3-age*27)*3)
  c.draw_polyline(_path,Color(ink,fade*0.16),15,true)
  c.draw_polyline(_path,Color(ink,fade*0.85),5.4,true)
  c.draw_polyline(_path,Color(CREAM,fade),2.0,true)
  c.draw_texture_rect(PaintedProjectileArt.icon("lightning",true),Rect2(finish+Vector2(-34,-38),Vector2(68,54)),false,Color(1,1,1,fade*0.88))
  _spark(c,finish,7,Color(CREAM,fade))
 c.draw_set_transform(Vector2.ZERO)

static func _ellipse(c: Node2D, at: Vector2, extent: Vector2, color: Color) -> void:
 c.draw_set_transform(at,0,extent)
 c.draw_circle(Vector2.ZERO,1,color,true,-1,true)
 c.draw_set_transform(Vector2.ZERO)

static func _shadow(c: Node2D, at: Vector2, extent: Vector2, alpha: float) -> void:
 _ellipse(c,at,extent,Color(0.34,0.28,0.29,alpha))

static func _spark(c: Node2D, at: Vector2, size: float, color: Color) -> void:
 c.draw_line(at-Vector2(size,0),at+Vector2(size,0),color,1.7,true)
 c.draw_line(at-Vector2(0,size),at+Vector2(0,size),color,1.7,true)
