class_name ShopConversation
extends Control

# The room owns E/Escape paging and pauses movement while a page is open.
# This display card itself never consumes pointer or keyboard input.
var portrait: TextureRect
var speaker: Label
var body: Label
var hint: Label
var tail_x := 180.0
var opacity := 1.0
var tail_side := false
var shadow_style: StyleBoxFlat
var card_style: StyleBoxFlat

func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	z_index=35
	size=Vector2(608,224)
	shadow_style=StyleBoxFlat.new()
	shadow_style.bg_color=Color(0.28,0.22,0.25,0.14)
	shadow_style.set_corner_radius_all(22)
	card_style=StyleBoxFlat.new()
	card_style.bg_color=Color("fff9eb")
	card_style.border_color=Color("c6ad98")
	card_style.set_border_width_all(2)
	card_style.set_corner_radius_all(22)
	portrait=TextureRect.new()
	portrait.position=Vector2(20,30)
	portrait.size=Vector2(100,128)
	portrait.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	portrait.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	portrait.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(portrait)
	speaker=_label(Vector2(144,17),Vector2(440,36),20,Color("795f62"))
	body=_label(Vector2(144,60),Vector2(440,116),18,Color("65564f"))
	body.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	hint=_label(Vector2(144,185),Vector2(440,24),13,Color("a08a81"))
	visible=false

func _label(at: Vector2, box: Vector2, font_size: int, ink: Color) -> Label:
	var label := Label.new()
	label.position=at
	label.size=box
	label.add_theme_font_override("font",GameLocale.STORY_FONT)
	label.add_theme_font_size_override("font_size",font_size)
	label.add_theme_color_override("font_color",ink)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(label)
	return label

func show_line(actor: String, actor_name: String, text: String, next_hint: String, anchor: Vector2) -> void:
	tail_side=false
	place_for_anchor(anchor)
	portrait.texture=AnimalCast.icon(actor)
	speaker.text=actor_name
	body.text=text
	hint.text=next_hint
	visible=true
	opacity=1.0
	modulate.a=1
	queue_redraw()

func place_for_anchor(anchor: Vector2) -> void:
	# Anchors arrive in screen coordinates from the enlarged scrolling world.
	# The speech card keeps its readable UI scale and stays below the top HUD.
	position=Vector2(clampf(anchor.x-size.x*0.5,24,1280-size.x-24),clampf(anchor.y-320,138,690-size.y-16))
	var next_tail := clampf(anchor.x-position.x,38,size.x-38)
	# Moving the canvas item already moves its cached drawing. Repaint only
	# when its pointer geometry changes, not on every camera-follow frame.
	if not is_equal_approx(next_tail,tail_x):
		tail_x=next_tail
		queue_redraw()

func set_opacity(value: float) -> void:
	opacity=clampf(value,0,1)
	modulate.a=opacity

func dismiss() -> void:
	visible=false

func _draw() -> void:
	draw_style_box(shadow_style,Rect2(3,5,size.x,size.y))
	draw_style_box(card_style,Rect2(Vector2.ZERO,size))
	if tail_side:
		draw_colored_polygon(PackedVector2Array([Vector2(2,70),Vector2(2,91),Vector2(-20,84)]),Color("fff9eb"))
		draw_polyline(PackedVector2Array([Vector2(1,70),Vector2(-20,84),Vector2(1,91)]),Color("c6ad98"),2,true)
	else:
		draw_colored_polygon(PackedVector2Array([Vector2(tail_x-11,size.y-2),Vector2(tail_x+8,size.y-2),Vector2(tail_x-5,size.y+15)]),Color("fff9eb"))
		draw_polyline(PackedVector2Array([Vector2(tail_x-11,size.y-1),Vector2(tail_x-5,size.y+15),Vector2(tail_x+8,size.y-1)]),Color("c6ad98"),2,true)
	draw_line(Vector2(132,27),Vector2(132,194),Color("e8d9bf"),1,true)
