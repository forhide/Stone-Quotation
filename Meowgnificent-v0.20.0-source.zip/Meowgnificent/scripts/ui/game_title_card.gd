class_name GameTitleCard
extends Control

# A dedicated brand reveal between story beats. The wordmark is authored art;
# narrative copy and the continue action remain accessible localized UI.
signal continue_requested
const LOGO: Texture2D=preload("res://art/ui/meowgnificent_wordmark.png")
var logo: TextureRect
var caption: Label
var continue_button: Button
var age := 0.0
var is_ending := false

func _ready() -> void:
	size=Vector2(1280,800)
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	logo=TextureRect.new()
	logo.texture=LOGO
	logo.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.position=Vector2(170,160)
	logo.size=Vector2(940,360)
	logo.pivot_offset=logo.size*0.5
	logo.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(logo)
	caption=Label.new()
	caption.position=Vector2(240,555)
	caption.size=Vector2(800,72)
	caption.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	caption.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	caption.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	caption.add_theme_font_override("font",GameLocale.STORY_FONT)
	caption.add_theme_font_size_override("font_size",19)
	caption.add_theme_color_override("font_color",Color("786558"))
	caption.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(caption)
	continue_button=Button.new()
	continue_button.position=Vector2(520,663)
	continue_button.size=Vector2(240,48)
	continue_button.text="Continue"
	continue_button.add_theme_font_override("font",GameLocale.TITLE_FONT)
	continue_button.add_theme_font_size_override("font_size",18)
	for state in ["normal","hover","pressed"]:
		var style := StyleBoxFlat.new()
		style.bg_color=Color("e8edda") if state=="normal" else Color("d8e6c6")
		style.border_color=Color("afbc93")
		style.set_border_width_all(1)
		style.set_corner_radius_all(18)
		style.content_margin_top=8
		style.content_margin_bottom=8
		continue_button.add_theme_stylebox_override(state,style)
	for state in ["font_color","font_hover_color","font_pressed_color"]:
		continue_button.add_theme_color_override(state,Color("66574b"))
	continue_button.pressed.connect(func(): continue_requested.emit())
	add_child(continue_button)
	hide()

func reveal(text: String,ending: bool=false) -> void:
	age=0
	is_ending=ending
	caption.text=text
	continue_button.text="The end" if ending else "Continue"
	show()
	tick(0)

func tick(delta: float) -> void:
	age+=delta
	var enter := smoothstep(0.08,0.88,age)
	logo.modulate.a=enter
	logo.scale=Vector2.ONE*lerpf(0.96,1.0,enter)
	caption.modulate.a=smoothstep(0.65,1.25,age)
	continue_button.modulate.a=smoothstep(1.05,1.5,age)
	continue_button.disabled=age<0.3
	queue_redraw()

func _draw() -> void:
	# The last shot's damaged classroom becomes the chapter's illustrated cover.
	# Soft vellum light lets the colorful CI read without a dialogue box behind it.
	draw_texture_rect(StoryConsequences.RUINS,Rect2(0,0,1280,800),false,Color("eee6df"))
	draw_rect(Rect2(0,0,1280,800),Color(1,0.97,0.89,0.82))
	var reveal := smoothstep(0.3,1.1,age)
	for i in range(5):
		var phase := age*0.7+i*1.6
		var at := Vector2(160+i*241,151+sin(i*1.8)*45)
		var radius := 2.2+sin(phase)*0.6
		draw_circle(at,radius,Color(0.80,0.66,0.38,reveal*0.28),true,-1,true)
