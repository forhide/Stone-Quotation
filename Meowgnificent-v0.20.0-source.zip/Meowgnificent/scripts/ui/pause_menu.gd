class_name ExpeditionPauseMenu
extends PanelContainer

signal resume_requested
signal restart_requested
signal main_menu_requested
var resume_button: Button
var restart_button: Button
var main_menu_button: Button

func _ready() -> void:
	position=Vector2(400,220)
	size=Vector2(480,360)
	var paper := StyleBoxFlat.new()
	paper.bg_color=Color("fff8e9")
	paper.border_color=Color("cbb798")
	paper.set_border_width_all(2)
	paper.set_corner_radius_all(22)
	paper.set_content_margin_all(24)
	paper.shadow_color=Color(0.30,0.23,0.20,0.20)
	paper.shadow_size=12
	add_theme_stylebox_override("panel",paper)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation",12)
	add_child(stack)
	var title := Label.new()
	title.text="Taking a catnap"
	title.add_theme_font_override("font",GameLocale.TITLE_FONT)
	title.add_theme_font_size_override("font_size",26)
	title.add_theme_color_override("font_color",Color("725947"))
	title.custom_minimum_size.y=44
	stack.add_child(title)
	var hint := Label.new()
	hint.text="Your expedition is paused. Starlight and studies are safe."
	hint.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_override("font",GameLocale.STORY_FONT)
	hint.add_theme_font_size_override("font_size",16)
	hint.add_theme_color_override("font_color",Color("89745f"))
	hint.custom_minimum_size=Vector2(430,56)
	stack.add_child(hint)
	resume_button=_button(stack,"Continue",Color("e0ebd1"))
	restart_button=_button(stack,"Restart expedition",Color("f5e4cf"))
	main_menu_button=_button(stack,"Main menu",Color("eee5f1"))
	resume_button.pressed.connect(func(): resume_requested.emit())
	restart_button.pressed.connect(func(): restart_requested.emit())
	main_menu_button.pressed.connect(func(): main_menu_requested.emit())
	hide()

func _button(stack: VBoxContainer,text: String,color: Color) -> Button:
	var button := Button.new()
	button.text=text
	button.custom_minimum_size.y=46
	button.add_theme_font_override("font",GameLocale.TITLE_FONT)
	button.add_theme_font_size_override("font_size",18)
	for state in ["normal","hover","pressed"]:
		var style := StyleBoxFlat.new()
		style.bg_color=color if state=="normal" else color.darkened(0.04)
		style.border_color=Color("c2ae96")
		style.set_border_width_all(1)
		style.set_corner_radius_all(12)
		button.add_theme_stylebox_override(state,style)
	for state in ["font_color","font_hover_color","font_pressed_color","font_focus_color"]: button.add_theme_color_override(state,Color("725947"))
	stack.add_child(button)
	return button

func focus_resume() -> void:
	if is_inside_tree() and visible and not is_queued_for_deletion():
		resume_button.grab_focus()
