class_name WizardHUD
extends CanvasLayer

# Warm paper windows keep the illustrated world bright and the text readable.
const INK := Color("654e45")
const MUTED := Color("7c6c60")
const PAPER := Color("fff7e6")
const LINE := Color("c9ad91")
const SAGE := Color("567b62")
const RouteCompassScript := preload("res://scripts/ui/route_compass.gd")
const ELEMENT_NAMES := {"fire":"Fire","water":"Water","ice":"Ice","wind":"Wind","stone":"Stone","leaf":"Wood","lightning":"Lightning","metal":"Metal"}

signal begin_requested
var aside: CatAside
var pause_menu: ExpeditionPauseMenu
var wave_guide: Panel
var wave_title: Label
var wave_body: Label
var room: Node2D
var health_label: Label
var health_bar: ProgressBar
var status_label: Label
var cooldown_label: Label
var primary_state: Label
var primary_bar: ColorRect
var roll_label: Label
var enemy_label: Label
var debug_label: Label
var overlay: PanelContainer
var overlay_title: Label
var overlay_body: Label
var play_button: Button
var incident_plate: Panel
var incident_label: Label
var context_label: Label
var incident_time := 0.0
var outcome_time := 0.0
var outcome := ""
var portrait: CatPortrait
var menu_portrait: CatPortrait
var stage_label: Label
var room_label: Label
var destination_label: Label
var identity_label: Label
var destination_eyebrow: Label
var wallet_label: Label
var inventory_button: Button
var settings_button: Button
var legacy_button: Button
var result_menu_button: Button
var sector_banner: SectorBanner
var route_nodes: Array[Label] = []
var observed_stage := -1
var observed_exit_open := false
var arrival_pending := true
var skill_icon: TextureRect
var skill_label: Label
var skill_state: Label
var skill_bar: ColorRect
var skill_card: Panel
var skill_normal_style: StyleBoxFlat
var skill_cast_style: StyleBoxFlat
var skill_flash_remaining := 0.0
var skill_flash_name := ""
var skill_flash_outcome := "success"
var boss_break_panel: Panel
var boss_break_remaining := 0.0
var boss_break_stage := -1
var _hud_keys: Dictionary = {}
var _skill_active := false
var route_compass: Control
var _affinity_clock := 0.0
var _affinity_weak := ""
var _affinity_resist := ""

# Text shaping and theme overrides are more expensive than reading a timer.
# Cache the inputs to each block while leaving its visual animation continuous.
func _hud_dirty(slot: String, key: Array) -> bool:
	var previous: Variant = _hud_keys.get(slot)
	if previous is Array and previous==key: return false
	_hud_keys[slot]=key
	return true

func label_at(text: String, at: Vector2, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	label.position = at
	label.add_theme_font_size_override("font_size",size)
	label.add_theme_font_override("font",GameLocale.TITLE_FONT if size>=16 else GameLocale.STORY_FONT)
	label.add_theme_color_override("font_color",color)
	add_child(label)
	return label

func _bounded_label(text: String, rect: Rect2, font_size: int, color: Color) -> Label:
	var label := label_at(text,rect.position,font_size,color)
	label.clip_text=true
	label.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	label.size=rect.size
	label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	return label

func panel_style(color: Color, border: Color, radius: int = 12) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	if radius>=12:
		style.shadow_color=Color(0.35,0.25,0.18,0.10)
		style.shadow_size=3
		style.shadow_offset=Vector2(0,2)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 20
	style.content_margin_bottom = 20
	return style

func _ready() -> void:
	var ink := INK
	var dim := MUTED
	# A soft paper header and a little mint purse tab, rather than metal panels.
	var header := Panel.new()
	header.position=Vector2(26,12)
	header.size=Vector2(1228,112)
	header.mouse_filter=Control.MOUSE_FILTER_IGNORE
	header.add_theme_stylebox_override("panel",panel_style(PAPER,Color("ddc7a9"),18))
	add_child(header)
	var purse := Panel.new()
	purse.position=Vector2(417,18)
	purse.size=Vector2(291,100)
	purse.mouse_filter=Control.MOUSE_FILTER_IGNORE
	purse.add_theme_stylebox_override("panel",panel_style(Color("e9f0df"),Color("c5d4b2"),12))
	add_child(purse)
	destination_eyebrow=_bounded_label("CURRENT DESTINATION",Rect2(52,21,340,24),13,Color("806348"))
	destination_label=_bounded_label("",Rect2(52,47,340,42),25,ink)
	identity_label=_bounded_label("Meowmalade / Arcana Academy",Rect2(52,91,340,24),13,dim)
	stage_label=_bounded_label("",Rect2(750,20,480,28),16,Color("806348"))
	stage_label.size=Vector2(480,28)
	stage_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	room_label=_bounded_label("",Rect2(750,49,480,36),21,ink)
	room_label.size=Vector2(480,36)
	room_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	enemy_label = _bounded_label("",Rect2(960,88,270,26),14,dim)
	enemy_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	var route := HBoxContainer.new()
	route.position=Vector2(750,88)
	route.mouse_filter=Control.MOUSE_FILTER_IGNORE
	route.add_theme_constant_override("separation",4)
	add_child(route)
	for index in range(room.stages.size()):
		var stop := Label.new()
		stop.custom_minimum_size=Vector2(23,20)
		stop.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		stop.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
		stop.mouse_filter=Control.MOUSE_FILTER_IGNORE
		stop.add_theme_font_size_override("font_size",11)
		stop.text="S" if str(room.stages[index].kind)=="shop" else str(index+1)
		stop.tooltip_text=GameLocale.text("Area %02d: %s") % [index+1,str(room.stages[index].name)]
		route.add_child(stop)
		route_nodes.append(stop)
	_bounded_label("Crowns / Stars",Rect2(433,21,125,23),12,Color("806348"))
	wallet_label=_bounded_label("0  /  0",Rect2(433,46,125,34),20,ink)
	route_compass=RouteCompassScript.new()
	route_compass.position=Vector2(566,22)
	add_child(route_compass)
	inventory_button=Button.new()
	inventory_button.position=Vector2(432,84)
	inventory_button.size=Vector2(260,28)
	var gear_style := panel_style(Color("d4e7c9"),Color("91aa85"),9)
	gear_style.content_margin_top=4
	gear_style.content_margin_bottom=4
	gear_style.content_margin_left=12
	gear_style.content_margin_right=12
	for button_state in ["normal","hover","pressed","disabled"]:
		inventory_button.add_theme_stylebox_override(button_state,gear_style)
	inventory_button.add_theme_font_size_override("font_size",12)
	inventory_button.add_theme_color_override("font_color",INK)
	inventory_button.add_theme_color_override("font_hover_color",INK)
	inventory_button.add_theme_color_override("font_pressed_color",INK)
	inventory_button.add_theme_color_override("font_disabled_color",Color("8c8e78"))
	inventory_button.pressed.connect(func(): room.open_inventory())
	add_child(inventory_button)
	var bottom := Panel.new()
	bottom.position = Vector2(45,690)
	bottom.size = Vector2(1190,94)
	bottom.add_theme_stylebox_override("panel",panel_style(PAPER,Color("c8b79d"),18))
	add_child(bottom)
	portrait = CatPortrait.new()
	portrait.position = Vector2(53,710)
	portrait.size = Vector2(62,62)
	add_child(portrait)
	health_label = _bounded_label("",Rect2(125,708,148,28),14,ink)
	health_bar = ProgressBar.new()
	health_bar.position = Vector2(126,746)
	health_bar.size = Vector2(136,10)
	health_bar.show_percentage = false
	health_bar.add_theme_stylebox_override("background",panel_style(Color("e5d8c9"),Color("e5d8c9"),4))
	health_bar.add_theme_stylebox_override("fill",panel_style(Color("e3a28e"),Color("e3a28e"),4))
	for kind in ["background", "fill"]:
		var bar_style := health_bar.get_theme_stylebox(kind) as StyleBoxFlat
		bar_style.content_margin_left = 0
		bar_style.content_margin_right = 0
		bar_style.content_margin_top = 0
		bar_style.content_margin_bottom = 0
	add_child(health_bar)
	# The primary spell has its own fixed footprint. Long spell names used to
	# share one unbounded line with the timer and spill into the Q-skill card.
	var primary_card := Panel.new()
	primary_card.position=Vector2(286,699)
	primary_card.size=Vector2(190,76)
	primary_card.mouse_filter=Control.MOUSE_FILTER_IGNORE
	primary_card.add_theme_stylebox_override("panel",panel_style(Color("f6ecd9"),Color("ddc7a8"),10))
	add_child(primary_card)
	cooldown_label=_bounded_label("",Rect2(296,705,170,29),16,ink)
	_bounded_label("Click / Space",Rect2(296,738,84,23),12,Color("806348"))
	primary_state=_bounded_label("",Rect2(382,738,84,23),12,Color("806348"))
	primary_state.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT
	var primary_track := ColorRect.new()
	primary_track.position=Vector2(296,766)
	primary_track.size=Vector2(170,4)
	primary_track.color=Color("e5d8bf")
	primary_track.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(primary_track)
	primary_bar=ColorRect.new()
	primary_bar.position=primary_track.position
	primary_bar.size=primary_track.size
	primary_bar.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(primary_bar)
	roll_label=_bounded_label("",Rect2(870,752,350,25),13,Color("6f6857"))
	skill_card=Panel.new()
	skill_card.position=Vector2(485,699)
	skill_card.size=Vector2(365,76)
	skill_card.mouse_filter=Control.MOUSE_FILTER_IGNORE
	skill_normal_style=panel_style(Color("eee7f2"),Color("c5b4cc"),10)
	skill_cast_style=panel_style(Color("fff0c9"),Color("bb9065"),10)
	skill_card.add_theme_stylebox_override("panel",skill_normal_style)
	add_child(skill_card)
	skill_icon=TextureRect.new()
	skill_icon.position=Vector2(494,713)
	skill_icon.size=Vector2(35,42)
	skill_icon.pivot_offset=Vector2(17.5,18.5)
	skill_icon.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	skill_icon.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	skill_icon.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(skill_icon)
	skill_label=_bounded_label("",Rect2(540,705,296,29),16,INK)
	skill_label.clip_text=true
	skill_label.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	skill_state=_bounded_label("",Rect2(541,737,295,26),14,Color("80618e"))
	var skill_track := ColorRect.new()
	skill_track.position=Vector2(541,766)
	skill_track.size=Vector2(295,4)
	skill_track.color=Color("dfd4e4")
	skill_track.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(skill_track)
	skill_bar=ColorRect.new()
	skill_bar.position=skill_track.position
	skill_bar.size=skill_track.size
	skill_bar.color=Color("ab8ab9")
	skill_bar.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(skill_bar)
	status_label = label_at("A very round cat. A very unreliable wizard.",Vector2(870,698),14,ink)
	status_label.size=Vector2(350,48)
	status_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	status_label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	status_label.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
	status_label.clip_text=true
	incident_plate=Panel.new()
	incident_plate.position=Vector2(283,128)
	incident_plate.size=Vector2(714,66)
	incident_plate.mouse_filter=Control.MOUSE_FILTER_IGNORE
	incident_plate.add_theme_stylebox_override("panel",panel_style(Color("fff7e6"),Color("d9c6ad"),10))
	add_child(incident_plate)
	incident_label = label_at("",Vector2(303,138),15,INK)
	incident_label.size=Vector2(674,46)
	incident_label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	incident_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	incident_label.add_theme_color_override("font_shadow_color",Color("fff9ed"))
	incident_label.add_theme_constant_override("shadow_offset_x",1)
	incident_label.add_theme_constant_override("shadow_offset_y",1)
	incident_label.add_theme_color_override("font_outline_color",Color("fff9ed"))
	incident_label.add_theme_constant_override("outline_size",3)
	context_label=_bounded_label("",Rect2(430,600,420,44),16,INK)
	context_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	var context_paper := panel_style(Color("fff8e8"),Color("c6b798"),12)
	context_paper.content_margin_left=18
	context_paper.content_margin_right=18
	context_paper.content_margin_top=7
	context_paper.content_margin_bottom=7
	context_label.add_theme_stylebox_override("normal",context_paper)
	context_label.hide()
	debug_label = label_at("",Vector2(820,697),11,dim)
	debug_label.hide()
	boss_break_panel=Panel.new()
	boss_break_panel.position=Vector2(365,126)
	boss_break_panel.size=Vector2(550,78)
	boss_break_panel.mouse_filter=Control.MOUSE_FILTER_IGNORE
	boss_break_panel.add_theme_stylebox_override("panel",panel_style(Color("fff1d8"),Color("c49db3"),16))
	add_child(boss_break_panel)
	var break_title := Label.new()
	break_title.position=Vector2(12,6)
	break_title.size=Vector2(526,38)
	break_title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	break_title.text="SHIELD SHATTERED!"
	break_title.add_theme_font_size_override("font_size",26)
	break_title.add_theme_color_override("font_color",Color("9f627c"))
	break_title.clip_text=true
	break_title.mouse_filter=Control.MOUSE_FILTER_IGNORE
	boss_break_panel.add_child(break_title)
	var break_hint := Label.new()
	break_hint.position=Vector2(14,46)
	break_hint.size=Vector2(522,24)
	break_hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	break_hint.text="The barrier is open. Now is your chance!"
	break_hint.add_theme_font_size_override("font_size",14)
	break_hint.add_theme_color_override("font_color",INK)
	break_hint.clip_text=true
	break_hint.mouse_filter=Control.MOUSE_FILTER_IGNORE
	boss_break_panel.add_child(break_hint)
	boss_break_panel.hide()
	var controls_back := Panel.new()
	controls_back.position=Vector2(256,653)
	controls_back.size=Vector2(768,30)
	controls_back.mouse_filter=Control.MOUSE_FILTER_IGNORE
	controls_back.add_theme_stylebox_override("panel",panel_style(Color(1.0,0.97,0.89,0.94),Color("d6c3a8"),10))
	add_child(controls_back)
	_bounded_label("WASD MOVE  ·  SHIFT ROLL  ·  Q / RMB SPECIAL  ·  I GEAR  ·  E INTERACT  ·  ESC PAUSE",Rect2(274,656,732,24),13,dim)
	overlay = PanelContainer.new()
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay.add_theme_stylebox_override("panel",panel_style(PAPER,Color("cba98c"),22))
	add_child(overlay)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation",17)
	overlay.add_child(box)
	var eyebrow := Label.new()
	eyebrow.text = "Meowgnificent"
	eyebrow.add_theme_font_size_override("font_size",24)
	eyebrow.modulate = Color("806348")
	box.add_child(eyebrow)
	menu_portrait = CatPortrait.new()
	menu_portrait.custom_minimum_size = Vector2(80,80)
	box.add_child(menu_portrait)
	overlay_title = Label.new()
	overlay_title.add_theme_font_size_override("font_size",24)
	overlay_title.add_theme_color_override("font_color",INK)
	box.add_child(overlay_title)
	overlay_body = Label.new()
	overlay_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_body.custom_minimum_size = Vector2(470,85)
	overlay_body.add_theme_font_size_override("font_size",16)
	overlay_body.add_theme_color_override("font_color",MUTED)
	box.add_child(overlay_body)
	play_button = Button.new()
	play_button.custom_minimum_size = Vector2(0,46)
	play_button.add_theme_stylebox_override("normal",panel_style(Color("d7e9c8"),Color("8da67c"),12))
	play_button.add_theme_stylebox_override("hover",panel_style(Color("e5f0d7"),Color("779266"),12))
	play_button.add_theme_stylebox_override("pressed",panel_style(Color("bed5b3"),Color("779266"),12))
	play_button.add_theme_stylebox_override("focus",panel_style(Color(0,0,0,0),Color("9a8aaa"),12))
	play_button.add_theme_color_override("font_color",INK)
	play_button.add_theme_color_override("font_hover_color",INK)
	play_button.add_theme_color_override("font_pressed_color",INK)
	play_button.pressed.connect(func(): begin_requested.emit())
	box.add_child(play_button)
	legacy_button=Button.new()
	legacy_button.text="M  ·  Legacy studies"
	legacy_button.custom_minimum_size=Vector2(0,32)
	legacy_button.add_theme_color_override("font_color",Color("775d88"))
	legacy_button.add_theme_color_override("font_hover_color",Color("634878"))
	var legacy_style := panel_style(Color("eee4f4"),Color("bdabd0"),10)
	legacy_style.content_margin_top=4
	legacy_style.content_margin_bottom=4
	for button_state in ["normal","hover","pressed"]:
		legacy_button.add_theme_stylebox_override(button_state,legacy_style)
	legacy_button.pressed.connect(func(): room.open_legacy())
	box.add_child(legacy_button)
	result_menu_button=Button.new()
	result_menu_button.text="Main menu"
	result_menu_button.custom_minimum_size.y=40
	result_menu_button.add_theme_font_override("font",GameLocale.TITLE_FONT)
	result_menu_button.add_theme_font_size_override("font_size",16)
	for state in ["font_color","font_hover_color","font_pressed_color","font_focus_color"]:
		result_menu_button.add_theme_color_override(state,INK)
	var result_style := panel_style(Color("eee5f1"),Color("c3b2c9"),10)
	for state in ["normal","hover","pressed","focus"]:
		result_menu_button.add_theme_stylebox_override(state,result_style)
	result_menu_button.pressed.connect(func(): room.return_to_menu())
	box.add_child(result_menu_button)
	result_menu_button.hide()
	show_overlay("A minor magical incident", "8 areas: little mishaps, two cozy shops, one final exam.\nEnemies drop Crowns and gear. I: equip. E: interact.\nStarlight and legacy studies survive defeat.", "Begin expedition   /   ENTER")
	overlay.position = Vector2(600,240)
	overlay.size = Vector2(550,315)
	settings_button=Button.new()
	settings_button.text="Settings"
	settings_button.tooltip_text="F10"
	settings_button.position=Vector2(1100,140)
	settings_button.size=Vector2(154,33)
	settings_button.add_theme_font_size_override("font_size",13)
	settings_button.add_theme_color_override("font_color",INK)
	settings_button.add_theme_color_override("font_hover_color",INK)
	var settings_style := panel_style(Color("eee4f4"),Color("bdabd0"),8)
	settings_style.content_margin_top=3
	settings_style.content_margin_bottom=3
	settings_style.content_margin_left=12
	settings_style.content_margin_right=12
	for state in ["normal","hover","pressed","focus"]: settings_button.add_theme_stylebox_override(state,settings_style)
	settings_button.pressed.connect(func(): room.settings.open())
	add_child(settings_button)
	sector_banner=SectorBanner.new()
	add_child(sector_banner)
	aside=CatAside.new()
	add_child(aside)
	pause_menu=ExpeditionPauseMenu.new()
	add_child(pause_menu)
	pause_menu.resume_requested.connect(func(): room.set_running(true))
	pause_menu.restart_requested.connect(func(): room.restart_expedition())
	pause_menu.main_menu_requested.connect(func(): room.return_to_menu())
	wave_guide=Panel.new()
	wave_guide.position=Vector2(350,130)
	wave_guide.size=Vector2(580,84)
	wave_guide.mouse_filter=Control.MOUSE_FILTER_IGNORE
	wave_guide.add_theme_stylebox_override("panel",panel_style(Color("f0eaf5"),Color("c4b4cf"),14))
	add_child(wave_guide)
	wave_title=_bounded_label("",Rect2(370,138,540,29),18,INK)
	wave_body=_bounded_label("",Rect2(370,174,540,28),15,MUTED)
	wave_guide.hide()


func update_route() -> void:
	for index in range(route_nodes.size()):
		var stop := route_nodes[index]
		var active: bool=index==room.run.stage_index
		var visited: bool=index<room.run.stage_index
		var shop := str(room.stages[index].kind)=="shop"
		stop.set_meta("active",active)
		stop.set_meta("visited",visited)
		stop.set_meta("shop",shop)
		var style := panel_style(Color("f1e8db"),Color("c7b49e"),6)
		style.content_margin_left=0
		style.content_margin_right=0
		style.content_margin_top=0
		style.content_margin_bottom=0
		if active:
			style.bg_color=Color("eed4a2")
			style.border_color=Color("b98e57")
		elif visited:
			style.bg_color=Color("d7e7cc")
			style.border_color=Color("9bb28c")
		stop.add_theme_stylebox_override("normal",style)
		stop.add_theme_color_override("font_color",INK if active else Color("526e53") if visited else Color("77685c"))

func sync_sector_notice(delta: float) -> void:
	var total: int=room.stages.size()
	if observed_stage!=room.run.stage_index:
		observed_stage=room.run.stage_index
		arrival_pending=true
		observed_exit_open=room.exit_open
		update_route()
	if room.state=="playing" and arrival_pending:
		sector_banner.announce_arrival(observed_stage,total,room.stage_def,room.enemies.size())
		arrival_pending=false
	elif room.state=="playing" and room.exit_open and not observed_exit_open and observed_stage+1<total:
		sector_banner.announce_clear(observed_stage,total,str(room.stages[observed_stage+1].name))
	observed_exit_open=room.exit_open
	sector_banner.tick(delta,room.state=="playing")
	if is_instance_valid(room.markers) and is_instance_valid(room.markers.gathering) and room.markers.gathering.conversation.visible:
		sector_banner.hide()

func show_overlay(title: String, body: String, button: String) -> void:
	overlay.position = Vector2(380,245)
	overlay.size = Vector2(520,315)
	overlay_title.text = title
	overlay_body.text = body
	play_button.text = button
	overlay.show()

func refresh_language(run_state: String) -> void:
	# Rebuild variable copy from game state, rather than translating a string
	# whose numbers and names have already been inserted in the old language.
	if run_state=="defeated":
		overlay_body.text=GameLocale.text("Reached area %d / 8. Crowns and gear belong to this expedition.\nYour %d Starlight and legacy studies are safe.\nM: legacy upgrades before the next attempt.") % [room.run.stage_index+1,room.profile.starlight]
	elif run_state=="cleared":
		overlay_body.text=GameLocale.text("All 8 areas cleared. %d foes, %d Crowns collected.\n%d Starlight remains for permanent legacy upgrades.\nM: legacy studies. ENTER: a fresh expedition.") % [room.run.enemies_defeated,room.run.collected_gold,room.profile.starlight]
	if is_instance_valid(sector_banner) and observed_stage>=0:
		var age := sector_banner.elapsed
		if sector_banner.mode=="arrival": sector_banner.announce_arrival(observed_stage,room.stages.size(),room.stage_def,room.enemies.size())
		elif observed_stage+1<room.stages.size(): sector_banner.announce_clear(observed_stage,room.stages.size(),str(room.stages[observed_stage+1].name))
		sector_banner.elapsed=age
	for index in range(route_nodes.size()):
		route_nodes[index].tooltip_text=GameLocale.text("Area %02d: %s") % [index+1,GameLocale.text(str(room.stages[index].name))]

func show_boss_break() -> void:
	boss_break_remaining=1.15
	boss_break_stage=room.run.stage_index

func _sync_boss_break(delta: float) -> void:
	if boss_break_stage!=room.run.stage_index: boss_break_remaining=0
	if room.state=="playing": boss_break_remaining=maxf(0,boss_break_remaining-delta)
	boss_break_panel.visible=boss_break_remaining>0 and room.state=="playing" and not sector_banner.visible
	boss_break_panel.modulate.a=minf(1.0,boss_break_remaining/0.18)

func show_incident(message: String, color: Color) -> void:
	incident_label.text=GameLocale.text(message)
	incident_label.modulate=Color.WHITE
	incident_label.add_theme_color_override("font_color",color.lerp(INK,0.78))
	incident_time=2.7

func show_outcome(result: String) -> void:
	outcome = result
	outcome_time = 1.5

func show_skill_cast(definition: Dictionary, result: String) -> void:
	if definition.is_empty(): return
	skill_flash_name=str(definition.get("name","Special skill"))
	skill_flash_outcome=result
	skill_flash_remaining=1.25
	# Special outcomes are named explicitly instead of borrowing the basic
	# spell failure presentation or a second orange impact puff.
	outcome_time=0.0
	skill_card.add_theme_stylebox_override("panel",skill_cast_style)

func clear_skill_cast() -> void:
	skill_flash_remaining=0.0
	skill_flash_name=""
	if is_instance_valid(skill_icon): skill_icon.scale=Vector2.ONE
	if is_instance_valid(skill_card): skill_card.add_theme_stylebox_override("panel",skill_normal_style)

func _process(delta: float) -> void:
	if not is_instance_valid(room.player): return
	# The tall start/result card can reach the lower shortcut strip. Keep its
	# settings action outside that card instead of covering the research button.
	settings_button.position=Vector2(1100,140 if overlay.visible else 650)
	settings_button.visible=room.state in ["intro","playing","paused","defeated","cleared"]
	var player: WizardCat=room.player
	var locale := TranslationServer.get_locale()
	aside.tick(delta,room)
	pause_menu.visible=room.state=="paused"
	var kind := str(room.stage_def.kind)
	var boss_caption := ""
	for enemy in room.enemies:
		if is_instance_valid(enemy) and enemy is PerfectExaminer and enemy.health.current>0:
			boss_caption=GameLocale.text("Try an accident") if enemy.barrier_active else GameLocale.text("EXPOSED · %.1fs") % enemy.vulnerability_time
			break
	portrait.sync_state(room.state,outcome,outcome_time,player.invulnerability)
	menu_portrait.sync_state(room.state,outcome,outcome_time,player.invulnerability)
	if _hud_dirty("health",[player.health.current,player.health.maximum,locale]):
		health_label.text=GameLocale.text("VITALITY     %d / %d") % [player.health.current,player.health.maximum]
		health_bar.max_value=player.health.maximum
		health_bar.value=player.health.current
	if _hud_dirty("stage",[room.run.stage_index,room.stages.size(),kind,str(room.stage_def.name),room.exit_open,locale,boss_caption]):
		stage_label.text=GameLocale.text("AREA %02d / %02d  ·  %s") % [room.run.stage_index+1,room.stages.size(),GameLocale.text(kind.to_upper())]
		destination_label.text=GameLocale.text(str(room.stage_def.name))
		identity_label.text=GameLocale.text("Meowmalade / Arcana Academy")
		room_label.text=GameLocale.text("PASSAGE OPEN" if room.exit_open and kind!="shop" else {"tutorial":"Practice your magic","combat":"Defeat the guardians","shop":"A peaceful stop with Pip","final":"Face the Perfect Grimoire"}.get(kind,"Continue your expedition"))
		if not boss_caption.is_empty(): room_label.text=boss_caption
	var encounter := _encounter_state()
	route_compass.sync_room(room,delta,encounter)
	_update_affinity_hint(delta)
	sync_sector_notice(delta)
	_sync_boss_break(delta)
	_update_wave_guide(encounter)
	if _hud_dirty("wallet",[room.run.gold,room.profile.starlight,room.run.inventory.size(),locale]):
		wallet_label.text=GameLocale.text("%d  /  %d") % [room.run.gold,room.profile.starlight]
		inventory_button.text=GameLocale.text("I  ·  Equipment  %d / 18") % room.run.inventory.size()
	if _hud_dirty("state",[room.state]):
		inventory_button.disabled=room.state!="playing"
		legacy_button.visible=room.state in ["intro","defeated","cleared","legacy"]
		result_menu_button.visible=room.state in ["defeated","cleared"]
	if _hud_dirty("roll",[player.roll_cooldown<=0,locale]):
		roll_label.text=GameLocale.text("SHIFT ROLL / ")+GameLocale.text("RECOVERING" if player.roll_cooldown>0 else "READY")
	if _hud_dirty("enemies",[room.exit_open,room.enemies.size(),encounter.get("index",0),encounter.get("total",1),encounter.get("state","active"),locale]):
		if room.exit_open: enemy_label.text=GameLocale.text("PASSAGE OPEN  ·  ENTER")
		elif str(encounter.get("state","active"))=="waiting": enemy_label.text=GameLocale.text("Next fight · follow the seal")
		elif str(encounter.get("state","active"))=="windup": enemy_label.text=GameLocale.text("Seal opening… get ready!")
		elif int(encounter.get("total",1))>1:
			enemy_label.text=GameLocale.text("Fight %d / %d · %d foes") % [int(encounter.get("index",0))+1,int(encounter.get("total",1)),room.enemies.size()]
		else: enemy_label.text=GameLocale.text("%02d foes  ·  passage locked") % room.enemies.size()
	var wand_id := str(room.run.equipment.get("wand",""))
	var wand_owned: bool=room.run.inventory.has(wand_id)
	var cooldown_text := "" if room.spells.cooldown<=0 else "%.1f" % room.spells.cooldown
	if _hud_dirty("cooldown",[wand_id,wand_owned,cooldown_text,locale]):
		var basic := BasicMagic.for_run(room.run)
		var basic_name := GameLocale.text(str(basic.name))
		cooldown_label.text=basic_name
		cooldown_label.tooltip_text=basic_name+"\n"+GameLocale.text(str(basic.trait))+"\n"+GameLocale.text("Weakness ↑ · Resistance ↓")
		primary_state.text=GameLocale.text("READY") if cooldown_text.is_empty() else GameLocale.text("%.1fs") % room.spells.cooldown
		if _hud_dirty("cooldown_color",[str(basic.id)]):
			cooldown_label.add_theme_color_override("font_color",BasicMagic.color(str(basic.id)).darkened(0.43))
			primary_bar.color=BasicMagic.color(str(basic.id)).darkened(0.17)
	# Continuous fill; only the short caption reshapes at tenth-second steps.
	primary_bar.size.x=170*clampf(1.0-room.spells.cooldown/maxf(0.01,float(room.spells.config.cooldown)),0,1)
	var forced: String=room.spells.resolver.forced
	if _hud_dirty("debug",[forced,locale]):
		debug_label.text=GameLocale.text("F1 NEXT: SUCCESS   F2: MISCAST   F3: OVERREACTION   |   %s") % ("RANDOM" if forced.is_empty() else forced.to_upper())
	if room.state=="playing":
		outcome_time=maxf(0.0,outcome_time-delta)
		incident_time=maxf(0.0,incident_time-delta)
		if skill_flash_remaining>0:
			skill_flash_remaining=maxf(0.0,skill_flash_remaining-delta)
			var pop := sin(clampf((1.25-skill_flash_remaining)/0.4,0,1)*PI)*0.08
			skill_icon.scale=Vector2.ONE*(1.0+pop)
			if skill_flash_remaining<=0: clear_skill_cast()
	_update_skill(wand_id,locale)
	incident_label.visible=incident_time>0 and room.state!="intro" and not sector_banner.visible
	incident_label.position.y=526 if kind=="shop" else 232 if wave_guide.visible else 138
	incident_plate.visible=incident_label.visible
	incident_plate.position.y=incident_label.position.y-10
	_update_context()
	var showing_skill := skill_flash_remaining>0
	var showing_outcome := outcome_time>0
	if _hud_dirty("status",[showing_skill,skill_flash_name if showing_skill else "",skill_flash_outcome if showing_skill else "",showing_outcome,outcome if showing_outcome else "",room.exit_open,_affinity_weak,_affinity_resist,locale]):
		status_label.modulate=Color.WHITE
		if showing_skill:
			var caption := "SKILL MISCAST · %s" if skill_flash_outcome=="miscast" else "SKILL OVERREACTION · %s" if skill_flash_outcome=="overreaction" else "SKILL · %s"
			status_label.text=GameLocale.text(caption) % GameLocale.text(skill_flash_name)
			status_label.add_theme_color_override("font_color",Color("ad5555") if skill_flash_outcome=="miscast" else Color("886092") if skill_flash_outcome=="overreaction" else Color("8d6639"))
		elif showing_outcome:
			status_label.text=GameLocale.text({"success":"Magic cast", "miscast":"Magic miscast", "overreaction":"Magic surge!"}.get(outcome,""))
			status_label.add_theme_color_override("font_color",{"success":Color("4e7857"),"miscast":Color("ad5555"),"overreaction":Color("89608b")}.get(outcome,INK))
		else:
			if not room.exit_open and not _affinity_weak.is_empty():
				status_label.text=GameLocale.text("Weak %s ↑ · Resists %s ↓") % [_affinity_weak,_affinity_resist]
			else: status_label.text=GameLocale.text("PASSAGE OPEN  /  ENTER to continue" if room.exit_open else "A very round cat. A very unreliable wizard.")
			status_label.add_theme_color_override("font_color",INK)

func _encounter_state() -> Dictionary:
	var director: Node=room.get("encounters")
	return director.snapshot() if is_instance_valid(director) and director.has_method("snapshot") else {}

func _update_context() -> void:
	var caption := ""
	if room.state=="playing" and not sector_banner.visible:
		var gathering: ShopGathering=room.markers.gathering
		var position: Vector2=room.player.position
		# The party owns an equivalent fixed UI card while an animal is nearby.
		if not gathering.prompt.visible and not gathering.conversation.visible:
			if room.exit_open and position.distance_to(WorldLayout.point(ExpeditionMarkers.EXIT_POSITION))<160:
				caption=GameLocale.text("E  ·  Next area")
			elif str(room.stage_def.kind)=="shop" and room.markers.is_shop_near(position):
				caption=GameLocale.text("E  ·  Browse shop")
			else:
				for shelf in room.props:
					if is_instance_valid(shelf) and shelf.is_cache_near(position):
						caption=GameLocale.text("E · Inspect the nook")
						break
	context_label.visible=not caption.is_empty()
	if context_label.text!=caption: context_label.text=caption

func _update_affinity_hint(delta: float) -> void:
	_affinity_clock+=delta
	if _affinity_clock<0.10: return
	_affinity_clock=0.0
	_affinity_weak=""
	_affinity_resist=""
	if room.state!="playing" or room.exit_open: return
	var nearest: Node2D
	var distance_squared := 520.0*520.0
	for enemy in room.enemies:
		if not is_instance_valid(enemy) or enemy.health.current<=0 or not enemy.has_method("affinity_profile"): continue
		var offset: Vector2=enemy.position-room.player.position
		if offset.length_squared()>distance_squared or (offset.length_squared()>1 and offset.normalized().dot(room.player.aim.normalized())<0.60): continue
		nearest=enemy
		distance_squared=offset.length_squared()
	if nearest==null: return
	var profile: Dictionary=nearest.affinity_profile()
	_affinity_weak=_element_list(profile.get("weak",[]))
	_affinity_resist=_element_list(profile.get("resist",[]))

func _element_list(elements: Array) -> String:
	var names := PackedStringArray()
	for element in elements:
		names.append(GameLocale.text(str(ELEMENT_NAMES.get(str(element),"Magic"))))
	return "/".join(names)

func _update_skill(wand_id: String="", locale: String="") -> void:
	var controller=room.get("skills")
	if controller==null: return
	if wand_id.is_empty(): wand_id=str(room.run.equipment.get("wand",""))
	if locale.is_empty(): locale=TranslationServer.get_locale()
	# Descriptions and icon resources do not change with the cooldown timer.
	if _hud_dirty("skill_info",[wand_id,room.run.inventory.has(wand_id),locale]):
		var info: Dictionary=controller.skill_info()
		_skill_active=not info.is_empty()
		skill_icon.texture=EquipmentArt.icon(wand_id)
		if _skill_active:
			skill_label.text=GameLocale.text("Q · %s") % GameLocale.text(str(info.get("name","")))
			skill_label.tooltip_text=GameLocale.text(str(info.get("description","")))+"\n"+GameLocale.text("Special skills can miscast or overreact, too.")
		else:
			skill_label.text=GameLocale.text("Q · Special skill")
			skill_label.tooltip_text=""
	var remaining: float=float(controller.cooldown_remaining)
	var remaining_text := "" if remaining<=0 else "%.1f" % remaining
	if _hud_dirty("skill_state",[_skill_active,remaining_text,skill_flash_remaining>0,locale]):
		if not _skill_active: skill_state.text=GameLocale.text("Equip a wand to unlock its skill")
		elif skill_flash_remaining>0: skill_state.text=GameLocale.text("SPECIAL CAST!")
		else: skill_state.text=GameLocale.text("RMB · READY") if remaining<=0 else GameLocale.text("RMB · %.1fs remaining") % remaining
	# The fill moves every frame even while its rounded text stays unchanged.
	skill_bar.size.x=295*clampf(1.0-remaining/maxf(0.01,float(controller.cooldown_duration)),0,1) if _skill_active else 0.0

func _update_wave_guide(encounter: Dictionary) -> void:
	var phase := str(encounter.get("state",""))
	wave_guide.visible=room.state=="playing" and phase in ["waiting","windup"] and not sector_banner.visible
	wave_title.visible=wave_guide.visible
	wave_body.visible=wave_guide.visible
	if not wave_guide.visible: return
	wave_title.text=GameLocale.text("Next battle · %d / %d") % [int(encounter.get("index",0))+1,int(encounter.get("total",1))]
	wave_body.text=GameLocale.text("Step toward the glowing seal to call the next guardians." if phase=="waiting" else "The seal is opening. Leave room for the arriving guardians!")
