class_name CatAside
extends Control

var body: Label
var remaining := 0.0
var paper: StyleBoxFlat
var anchor := Vector2.ZERO
var on_left := false

func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	size=Vector2(252,108)
	paper=StyleBoxFlat.new()
	paper.bg_color=Color("fff9e9")
	paper.border_color=Color("cbb5a1")
	paper.set_border_width_all(2)
	paper.set_corner_radius_all(18)
	paper.shadow_color=Color(0.32,0.25,0.22,0.13)
	paper.shadow_size=4
	body=Label.new()
	body.position=Vector2(15,11)
	body.size=Vector2(222,86)
	body.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	body.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	body.add_theme_font_override("font",GameLocale.STORY_FONT)
	body.add_theme_font_size_override("font_size",16)
	body.add_theme_color_override("font_color",Color("775c50"))
	body.mouse_filter=Control.MOUSE_FILTER_IGNORE
	add_child(body)
	hide()

func say(message: String,cost: int=0) -> void:
	set_meta("cost",cost)
	body.text=_caption(message,cost)
	set_meta("source",message)
	_fit_caption()
	remaining=3.0
	show()

func _fit_caption() -> void:
	var lines := 0
	for line in body.text.split("\n"):
		var width := body.get_theme_font("font").get_string_size(line,HORIZONTAL_ALIGNMENT_LEFT,-1,16).x
		lines+=maxi(1,ceili(width/222.0))
	lines=clampi(lines,1,4)
	size.y=body.get_theme_font("font").get_height(16)*lines+24
	body.size.y=size.y-22

func tick(delta: float,room: Node) -> void:
	if room.state=="playing": remaining=maxf(0,remaining-delta)
	visible=remaining>0 and room.state=="playing"
	if not visible: return
	body.text=_caption(str(get_meta("source","")),int(get_meta("cost",0)))
	_fit_caption()
	anchor=room.player.get_global_transform_with_canvas()*Vector2(0,-80*room.player.presentation_scale)
	on_left=anchor.x>920
	position=Vector2(clampf(anchor.x-282 if on_left else anchor.x+38,22,1006),clampf(anchor.y-64,216,640-size.y))
	modulate.a=minf(1,remaining/0.25)
	queue_redraw()

func _draw() -> void:
	draw_style_box(paper,Rect2(Vector2.ZERO,size))
	var x := size.x-1 if on_left else 1.0
	var middle := clampf(anchor.y-position.y,24,size.y-18)
	var tip := (anchor-position).clamp(Vector2(-34,16),Vector2(size.x+34,size.y-12))
	draw_colored_polygon(PackedVector2Array([Vector2(x,middle-9),tip,Vector2(x,middle+9)]),Color("fff9e9"))
	draw_polyline(PackedVector2Array([Vector2(x,middle-9),tip,Vector2(x,middle+9)]),Color("cbb5a1"),2,true)

func _caption(source: String,cost: int) -> String:
	return GameLocale.text(source)+(GameLocale.text("\nRecoil · -5 vitality") if cost==5 else GameLocale.text("\nMiscast · -10 vitality") if cost==10 else "")
