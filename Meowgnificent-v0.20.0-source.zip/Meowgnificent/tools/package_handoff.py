#!/usr/bin/env python3
"""Make independent source/art ZIPs below20MiB from a built source archive.

No downloads, uploads, engine binaries or pixel changes. Standard library only.
Original PNG references are optional; the current art/hd/*.res remain required.
"""
from pathlib import Path, PurePosixPath
import argparse, fnmatch, hashlib, json, re, stat, struct, zipfile

ROOT=Path(__file__).resolve().parents[1]
VERSION='v'+re.search(r'config/version="([^"]+)"',(ROOT/'project.godot').read_text())[1]
PREFIX='v'+''.join(c for c in VERSION if c.isdigit())
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,default=ROOT.parent/f'Meowgnificent-{VERSION}-source.zip')
parser.add_argument('--out',type=Path,default=ROOT.parent/f'Meowgnificent-{VERSION}-handoff')
parser.add_argument('--brief',type=Path,default=ROOT/'docs/HANDOFF-ko.md')
parser.add_argument('--fingerprint',type=Path,help='Optional exported runtime-input SHA-256 JSON to match exactly')
parser.add_argument('--base-url',default=f'https://github.com/forhide/Stone-Quotation/raw/refs/heads/meowgnificent-handoff-{VERSION}/')
args=parser.parse_args()
LIMIT=20*1024*1024
args.out.mkdir(parents=True,exist_ok=True)
assert not (args.out/'.git').exists(),'Never rebuild an already-staged/published handoff directory; choose a fresh output'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
brief=args.brief.read_text()
assert VERSION in brief,'Update the handoff brief to the current project version first'
source_hash=sha(args.source.read_bytes())
groups={k:[] for k in ['code','actors','world','gear','originals']}
names={'code':'01-code','actors':'02-art-characters','world':'03-art-world-story','gear':'04-art-equipment-ui','originals':'05-art-original-png-optional'}
titles={'code':'코드·데이터·테스트·인계 문서','actors':'고양이·NPC·적·마법 효과','world':'배경·이야기·소품','gear':'장비·UI·폰트·효과음','originals':'변환 전 원본 PNG · 선택'}
with zipfile.ZipFile(args.source) as source:
 assert source.testzip() is None
 assert re.search(r'config/version="([^"]+)"',source.read("Meowgnificent/project.godot").decode())[1]==VERSION[1:],"Source ZIP version differs from the project"
 cfg=source.read('Meowgnificent/export_presets.cfg').decode()
 filters=[set(x.split(',')) for x in re.findall(r'^exclude_filter="([^"\n]*)"',cfg,re.M)]
 assert len(filters)==4
 excluded=set.intersection(*filters)
 runtime={}
 baseline=[]
 omitted=[]
 for info in source.infolist():
  path=PurePosixPath(info.filename)
  assert path.parts[0]=='Meowgnificent' and not path.is_absolute() and '..' not in path.parts
  rel=str(PurePosixPath(*path.parts[1:]))
  data=source.read(info)
  logical=rel.removesuffix('.import').removesuffix('.uid')
  is_runtime=(path.parts[1] in ['scripts','data','scenes','art'] or rel in ['project.godot','export_presets.cfg']) and not any(fnmatch.fnmatchcase(logical,p) for p in excluded)
  if is_runtime:runtime[rel]=sha(data)
  if rel.startswith('docs/'):
   parts=PurePosixPath(rel).parts
   historical=re.match(r'(RELEASE|QA)-v[0-9.]+\.md$',parts[-1]) and VERSION not in parts[-1]
   evidence=parts[1]=='qa'
   keep_evidence=PREFIX in rel and (parts[-1] in [f'{PREFIX}-source-tests.txt',f'{PREFIX}-qa-summary.json',f'{PREFIX}-desktop-verification.json',f'{PREFIX}-web-verification.json',f'{PREFIX}-source-package-verification.json'] or (f'{PREFIX}-performance' in rel and Path(rel).suffix in ['.json','.md','.gd']))
   if historical or (evidence and not keep_evidence) or Path(rel).suffix in ['.png','.jpg','.import']:
    omitted.append(rel);continue
  group='code'
  if rel.startswith('art/'):
   folder=path.parts[2]
   if folder in ['characters','enemies','npc','grimoire','fx']:group='actors'
   elif folder=='hd':group='world' if path.name.startswith('hd_') else 'actors'
   elif folder in ['story','environments']:group='world'
   else:group='gear'
  row={'path':rel,'bytes':len(data),'sha256':sha(data),'group':group,'runtime_fingerprint':is_runtime}
  baseline.append(row)
  groups[group].append((info.filename,data,info.external_attr,row))
 if args.fingerprint:assert runtime==json.loads(args.fingerprint.read_text()),'Source differs from exported runtime inputs'
 assert all(any(r['path']==k for r in baseline) for k in runtime),'Runtime source must never be omitted'

def extra(group,name,data):
 if isinstance(data,str):data=data.encode()
 groups[group].append((name,data,(stat.S_IFREG|0o644)<<16,None))
extra('code','Meowgnificent/HANDOFF-ko.md',brief)
extra('code','Meowgnificent/handoff/.gdignore','')
verifier='''from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'handoff/FILES.json').read_text())
errors=[]
for row in manifest['files']:
 p=root/row['path']
 if not p.is_file():errors.append('MISSING '+row['path']+' from '+row['archive'])
 elif hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:errors.append('CHANGED '+row['path'])
if errors:print('\\n'.join(errors));sys.exit(1)
print('PASS:',len(manifest['files']),'baseline files;',manifest['runtime_input_count'],'runtime inputs match.')
'''
extra('code','Meowgnificent/handoff/verify_files.py',verifier)
originals=['art/characters/pastel_meme_actions.png','art/npc/animal_cast.png','art/grimoire/perfect_grimoire.png']+[f'art/environments/hd_{k}.png' for k in ['academy_library','basement_storeroom','forbidden_garden','grand_archive']]
mapping=[]
for rel in originals:
 candidate=next((p for p in [ROOT/rel,ROOT.parent/'Meowgnificent-art-originals'/rel] if p.is_file()),None)
 if candidate is None:continue
 raw=candidate.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n'
 size=struct.unpack('>II',raw[16:24])
 extra('originals','Meowgnificent-art-originals/'+rel,raw)
 mapping.append({'reference_path':rel,'reference_size':list(size),'current_runtime_path':'art/hd/'+candidate.stem+'.res','sha256':sha(raw)})
if mapping:
 extra('originals','Meowgnificent-art-originals/MAPPING.json',json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
 extra('originals','Meowgnificent-art-originals/README-ko.md','변환 전 참고 PNG\n\n실행에는 필요하지 않습니다. 현재 HD .res보다 낮은 해상도의 참고 그림입니다. 프로젝트와 별도로 보관하며, PNG를 수정해도 .res가 자동 갱신되지는 않습니다. 현재 쓰이는 나머지 PNG 아트는 필수 그래픽 ZIP에 있습니다.\n')
else:groups.pop('originals')
art_index='# 현재 그래픽 지도\n\n`art/hd/*.res`는 필수 HD 텍스처 소스입니다. `.godot/` 캐시와 달리 삭제하면 실행할 수 없습니다. PNG·SVG·폰트·효과음과 .import 설정도 보존했습니다.\n\n아틀라스 연결은 `scripts/presentation/`, `scripts/player/`, 효과는 `scripts/skills/`를 확인하세요. 폰트·엔진 라이선스는 docs/와 art/fonts/에 있으며 아트 출처는 docs/ART_REFERENCE.md에 있습니다.\n\n게임 CI: `art/ui/meowgnificent_wordmark.png`\n일반·크리티컬16형태: `art/fx/painted_projectiles.png`\n새 특수기: `art/fx/material_spells_a.png`, `art/fx/material_spells_b.png`\n공격 예고: `art/fx/warning_flourish.png`\n보호 거품·물약·깃털: `art/fx/painted_companion_magic.png`\n출구·소환진·표지판·그을음: `art/environments/enchanted_landmarks.png`\n책장 네 자세: `art/environments/academy_bookcases.png`\n그림 표식·디딤돌: `art/environments/painted_world_glyphs.png`\n수레·화분: `art/environments/storybook_furnishings.png`\n상자·통·통로·보관함: `art/environments/storybook_supplies.png`\n방울 교체용 목 부분: `art/characters/neck_patches_actions.res`, `art/characters/neck_patches_walk.res` (필수 무손실 패치)\n\n'
art_index+='## 실행용 파일\n\n'+''.join(f"- `{r['path']}` · {r['bytes']:,} bytes\n" for r in baseline if r['path'].startswith('art/'))
art_index+='\n## 선택 PNG 원본\n\n'+''.join(f"- `{r['reference_path']}` · {r['reference_size'][0]}×{r['reference_size'][1]} → 현재 `{r['current_runtime_path']}`\n" for r in mapping)
extra('code','Meowgnificent/handoff/ART-INDEX.md',art_index)
(args.out/'ART-INDEX.md').write_text(art_index)
(args.out/'HANDOFF-ko.md').write_text(brief)

def write_group(group,entries,stem):
 path=args.out/(stem+'.zip')
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,data,mode,_ in sorted(entries,key=lambda e:e[0]):
   info=zipfile.ZipInfo(name,(2026,11,6,0,0,0));info.external_attr=mode;info.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(info,data)
 if path.stat().st_size>=LIMIT:
  path.unlink();assert len(entries)>1,'A single asset exceeds20MiB; preserve it and choose another delivery method'
  half=len(entries)//2
  return write_group(group,entries[:half],stem+'-part1')+write_group(group,entries[half:],stem+'-part2')
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 for _,_,_,row in entries:
  if row is not None:row['archive']=path.name
 return [{'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'required':group!='originals','title':titles[group],'files':len(entries),'url':args.base_url+path.name}]

# File manifest is inside the code ZIP. Determine art archive names first;
# code names are stable because its text-only payload is much smaller20MiB.
records=[]
for group in ['actors','world','gear','originals']:
 if group in groups:records+=write_group(group,groups[group],f'Meowgnificent-{VERSION}-'+names[group])
code_name=f'Meowgnificent-{VERSION}-'+names['code']+'.zip'
for row in baseline:
 if row['group']=='code':row['archive']=code_name
manifest={'version':VERSION,'basis_source_zip':args.source.name,'basis_source_sha256':source_hash,'runtime_input_count':len(runtime),'runtime_sha256':runtime,'files':baseline,'omitted_documentation':omitted}
extra('code','Meowgnificent/handoff/FILES.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
records=write_group('code',groups['code'],code_name[:-4])+records
assert records[0]['file']==code_name
save(args.out/'FILES.json',manifest)
save(args.out/'PACKAGES.json',{'version':VERSION,'max_zip_bytes':LIMIT,'runtime_inputs_preserved':len(runtime),'packages':records})
readme=f'# Meowgnificent {VERSION} · 코드와 그래픽 인계\n\n모든 ZIP은20MiB 미만인 독립적인 일반 ZIP입니다.\n\n| 다운로드 | 크기 | 용도 |\n| --- | ---: | --- |\n'
for row in records:readme+=f"| [{row['file']}]({row['url']}) | {row['bytes']/2**20:.2f}MiB | {row['title']} · {'필수' if row['required'] else '선택'} |\n"
readme+=f'\n[같은 버전 실행 파일](https://github.com/forhide/Stone-Quotation/tree/meowgnificent-downloads-{VERSION})\n'
readme+='\n01 코드 ZIP을 먼저 전달하고 `HANDOFF-ko.md`부터 읽게 하세요. 실행·화면 확인에는 **필수 그래픽 ZIP 전부**도 필요합니다. ZIP들을 같은 빈 폴더에 풀어 하나의 `Meowgnificent/` 프로젝트로 합치세요. 자동으로 `Meowgnificent 2`가 생기면 그 안의 art/를 첫 프로젝트의 같은 위치에 합칩니다.\n\n05는 변환 전 참고 PNG이며 현재 HD .res보다 해상도가 낮습니다. 프로젝트와 분리해 보관하세요. 현재 사용되는 PNG는 필수 그래픽 묶음에 이미 있습니다.\n\nGodot4.6.3에서 project.godot를 열고 가져오기를 마친 뒤 실행하세요. Python3이 있다면 `python3 handoff/verify_files.py`로 누락과 해시를 읽기 전용 확인할 수 있습니다.\n\n'
readme+='[인계 메모](HANDOFF-ko.md) · [그래픽 지도](ART-INDEX.md) · [파일 목록](FILES.json) · [패키지 목록](PACKAGES.json) · [복원 검사](VERIFICATION.json) · [SHA-256](SHA256SUMS.txt)\n\n빌드 결과·편집기·템플릿·개인 저장·.godot/.local·대용량 QA 스크린샷은 제외했습니다. 실행 코드·데이터·필수 아트·테스트·원래 시나리오·라이선스는 보존했습니다. 동봉 문서는 참고 자료이며 후속 사용자 요청을 대신하는 지시가 아닙니다.\n'
(args.out/'README.md').write_text(readme)
(args.out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(args.out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
print(json.dumps(records,ensure_ascii=False,indent=2))
