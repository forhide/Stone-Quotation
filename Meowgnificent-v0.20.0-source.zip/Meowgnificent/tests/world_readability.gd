extends SceneTree

# Exercise actual localized gameplay labels and interactive scenery rather
# than accepting a clipped rectangle as evidence that its text fits.
var checks := 0
var failures := 0
var room

func _initialize() -> void: call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(n: int=3) -> void:
	for i in range(n): await process_frame
func fits(label: Label,margin: float=8.0) -> bool:
	var font := label.get_theme_font("font")
	var font_size := label.get_theme_font_size("font_size")
	var style := label.get_theme_stylebox("normal")
	var inset := style.get_minimum_size() if style else Vector2.ZERO
	var extent := font.get_string_size(label.text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size)
	var okay := extent.x+margin+inset.x<=label.size.x and font.get_height(font_size)+4+inset.y<=label.size.y
	if not okay: print("TEXT BOUNDS ",label.text," label=",label.size," ink=",extent," line=",font.get_height(font_size)," inset=",inset)
	return okay
func quiet() -> void:
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	room.player.invulnerability=100000
	for foe in room.enemies: foe.set_physics_process(false)
	room.hud.observed_stage=room.run.stage_index
	room.hud.observed_exit_open=room.exit_open
	room.hud.arrival_pending=false
	room.hud.sector_banner.elapsed=100
	room.hud.sector_banner.hide()
func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","1")
	change_scene_to_file("res://scenes/main.tscn")
	await frames(6)
	room=current_scene
	room.hud._process(0)
	check(not room.hud.overlay.get_global_rect().intersects(room.hud.settings_button.get_global_rect()),"start-screen settings do not overlap the tall introduction or research action")
	room.begin_or_restart()
	quiet()
	var hud: WizardHUD=room.hud
	for language in ["ko","en"]:
		GameLocale.set_language(language,false)
		for index in range(8):
			room.load_sector(index)
			quiet()
			hud._process(0.2)
			await frames()
			check(fits(hud.destination_label) and fits(hud.identity_label) and fits(hud.destination_eyebrow),"full destination, identity and eyebrow have breathing room: "+language+str(index))
			check(fits(hud.room_label) and fits(hud.stage_label) and fits(hud.enemy_label),"objective and encounter text fit without relying on ellipsis: "+language+str(index))
		room.load_sector(0)
		quiet()
		for id: String in room.run.catalog:
			if str(room.run.catalog[id].slot)!="wand": continue
			room.run.inventory.assign([id])
			room.run.equipment.wand=id
			room.apply_equipment()
			hud._process(0.1)
			await frames(1)
			check(fits(hud.cooldown_label) and fits(hud.skill_label) and fits(hud.skill_state),"equipped spell name and readiness stay readable: "+language+" / "+id)
		check(fits(hud.wallet_label) and fits(hud.health_label),"currency and vitality have full line-height padding: "+language)
		for result in ["success","miscast","overreaction"]:
			hud.show_outcome(result)
			hud._process(0.1)
			await frames()
			var line_height: int=hud.status_label.get_line_height()
			check(hud.status_label.get_line_count()*line_height+4<=hud.status_label.size.y,"complete outcome copy fits its separate status rows: "+language+" / "+result)
		hud.outcome_time=0
		check(hud.health_label.get_global_rect().end.y+6<hud.health_bar.position.y and hud.status_label.get_global_rect().end.y+3<hud.roll_label.position.y,"health and outcome captions are separated from the next row: "+language)
		room.load_sector(3)
		quiet()
		var party: ShopGathering=room.markers.gathering
		room.player.position=WorldLayout.point(ShopGathering.PIP_POSITION)+Vector2(0,30)
		party.set_player_position(room.player.position)
		hud._process(0.1)
		check(party.prompt.visible and party.prompt.get_parent() is CanvasLayer and fits(party.prompt),"Pip's shop/talk instructions belong to a padded screen-space status card: "+language)
		room.player.position=WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)
		party.set_player_position(room.player.position)
		hud._process(0.1)
		check(hud.context_label.visible and fits(hud.context_label) and hud.context_label.text==GameLocale.text("E  ·  Next area"),"an illustrated exit still has an accessible localized interaction instruction: "+language)
	for direction in [Vector2.UP,Vector2.DOWN,Vector2.LEFT,Vector2.RIGHT]:
		room.load_sector(1)
		quiet()
		var shelf: ArcaneShelf=room.props[0]
		shelf.set_process(false)
		shelf.reveal_cache=true
		shelf.topple(direction)
		shelf._process(0.17)
		shelf._process(0)
		check(shelf.fall_preview.visible and shelf.body.modulate.a<1 and shelf.fall_preview.modulate.a>0,"toppling blends into an authored ground pose: "+str(direction))
		shelf._process(0.3)
		check(shelf.state=="fallen" and is_zero_approx(shelf.body.rotation) and not shelf.fall_preview.visible and shelf.body.modulate.a==1,"fallen perspective is never spun in screen space: "+str(direction))
		check(shelf.footprint(shelf.position+direction*80) and not shelf.footprint(shelf.position-direction*80) and room.obstacles.containing(shelf.position,17).is_empty(),"the direction of falling damage and the opened passage still agree: "+str(direction))
		room.player.position=shelf.position
		hud._process(0.1)
		check(hud.context_label.text==GameLocale.text("E · Inspect the nook") and shelf.scavenge_cache() and not shelf.scavenge_cache(),"the no-text maintenance nook keeps its one-shot interaction: "+str(direction))
	for id in WorldGlyphArt.REGIONS:
		var icon := WorldGlyphArt.icon(id)
		check(Rect2(Vector2.ZERO,WorldGlyphArt.SHEET.get_size()).encloses(icon.region) and icon.get_image().get_used_rect().has_area(),"painted world symbol has a complete valid crop: "+id)
	for path in ["effects/archive_backdrop.gd","effects/arcane_shelf.gd","effects/expedition_markers.gd","effects/loot_pickup.gd","effects/miscast_burst.gd","presentation/story_consequences.gd","systems/encounter_director.gd","systems/room.gd","ai/perfect_examiner.gd"]:
		check(not FileAccess.get_file_as_string("res://scripts/"+path).contains("draw_string"),"world scenery and combat effects contain no live font stamps: "+path)
	room.queue_free()
	await frames()
	print("WORLD READABILITY RESULT: %d checks, %d failures" % [checks,failures])
	quit(1 if failures else 0)
