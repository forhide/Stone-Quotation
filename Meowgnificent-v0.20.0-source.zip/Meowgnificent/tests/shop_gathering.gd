extends SceneTree
class RunStub extends RefCounted:
 var stage_index := 0
class RoomStub extends Node2D:
 var run := RunStub.new()
 var stage_def := {"name":"Detention","kind":"combat"}
 var exit_open := false
 var player := Node2D.new()
 var state := "playing"
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func frames(count: int=3) -> void:
 for i in range(count):
  await physics_frame
  await process_frame
func run() -> void:
 var room := RoomStub.new()
 root.add_child(room)
 room.add_child(room.player)
 var markers := ExpeditionMarkers.new()
 markers.room=room
 room.add_child(markers)
 await process_frame
 var art := markers.gathering
 check(Rect2(Vector2.ZERO,ShopGathering.ART.get_size()).encloses(ShopGathering.ART_REGION),"market crop stays inside the transparent authored illustration")
 check(ShopGathering.MARKET_RECT.size.x<=500 and ShopGathering.MARKET_RECT.end.y<600,"central market fits between the playfield and route display")
 check(markers.z_index<0 and art.get_children().all(func(child: Node) -> bool: return not child is CollisionObject2D),"decorative gathering nodes leave collision to the room’s shared floor geometry")
 check(art.friends.size()==2 and art.friends.moss.texture==AnimalCast.icon("moss") and art.friends.bloop.texture==AnimalCast.icon("bloop"),"tea guests use the same hedgehog and otter identities as story portraits")
 for index in range(8):
  var shop := index in [3,6]
  room.run.stage_index=index
  room.stage_def={"name":"Shop" if shop else "Combat","kind":"shop" if shop else "combat"}
  room.exit_open=shop
  room.player.position=WorldLayout.point(Vector2(640,555))
  markers.update_visuals()
  check(art.visible==shop and markers.merchant_root.visible==shop,"the gathering and animal merchant appear only in shop area%02d" % (index+1))
  check(markers.is_shop_near(WorldLayout.point(Vector2(640,555)))==shop and markers._shop_near==shop,"the centre table offers shop interaction only in shop area%02d" % (index+1))
  if not shop: continue
  check(not markers.is_shop_near(WorldLayout.point(ShopGathering.PIP_POSITION)),"talking to Pip is separate from buying at the table front")
  check(not markers.is_shop_near(WorldLayout.point(Vector2(220,435))) and not markers.is_shop_near(WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)),"spawn and east exit do not become accidental shop triggers")
  var clock: float=art.elapsed
  markers._process(0.4)
  check(art.elapsed>clock,"warm tea steam advances during the active rest stop")
  room.state="shop"
  var paused_clock: float=art.elapsed
  var paused_points: PackedVector2Array=art.steam[0].points
  markers._process(1.0)
  check(is_equal_approx(art.elapsed,paused_clock) and art.steam[0].points==paused_points,"trading pauses tea steam without hidden world animation")
  room.state="playing"
 room.queue_free()
 await process_frame
 # Check the real room dispatch too: a marker-only distance test cannot
 # prove that pressing interact at the new table reaches the trading panel.
 change_scene_to_file("res://scenes/main.tscn")
 await frames()
 var actual=current_scene
 actual.begin_or_restart()
 for index in [3,6]:
  actual.load_sector(index)
  await frames()
  actual.player.position=WorldLayout.point(Vector2(640,555))
  actual.interact()
  check(actual.state=="shop" and actual.panel.is_open and actual.panel.mode=="shop" and not actual.player.active,"real area%02d table interaction opens the trading panel" % (index+1))
  var before: float=actual.markers.gathering.elapsed
  await frames(5)
  check(is_equal_approx(actual.markers.gathering.elapsed,before),"real shop modal freezes the tea gathering")
  actual.close_panel()
  actual.player.position=WorldLayout.point(Vector2(220,610))
  actual.player.velocity=Vector2.ZERO
  Input.action_press("move_right")
  await frames(180)
  Input.action_release("move_right")
  check(actual.player.position.x>950 and absf(actual.player.position.y-976)<1,"real player can cross the free route below the central island")
  actual.player.position=WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)-Vector2(1,0)
  actual.interact()
  check(actual.run.stage_index==index+1 and actual.state=="playing" and not actual.panel.is_open,"east exit still advances the real expedition instead of reopening the shop")
 print("SHOP GATHERING RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
