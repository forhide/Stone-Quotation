extends SceneTree

var checks := 0
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(n: int=3) -> void:
	for i in range(n): await process_frame
func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","0")
	change_scene_to_file("res://scenes/main.tscn")
	await frames(6)
	var room=current_scene
	var director: StoryDirector=room.story_director
	var attempts: int=room.profile.attempts
	room.request_begin()
	director.auto_advance=false
	director.set_process(false)
	check(room.state=="story" and not director.title_card.visible and director.stage.visible,"the real opening begins with its illustrated dialogue, before the brand reveal")
	for i in range(7): director.advance()
	var card: GameTitleCard=director.title_card
	check(card.visible and director.page_index==7 and not director.stage.visible and not director.body_label.visible and not director.speaker_label.visible,"the first game name reveals a separate CI screen with no dialogue window")
	check(card.logo.texture==GameTitleCard.LOGO and card.logo.texture.get_width()>1900 and card.logo.texture.get_image().detect_alpha()!=Image.ALPHA_NONE,"the custom game wordmark is a high resolution transparent illustration")
	check(card.logo.modulate.a==0 and card.logo.scale.x<1 and card.caption.modulate.a==0,"the logo begins a deliberate reveal rather than flashing as a dialogue label")
	director._process(0.5)
	check(card.logo.modulate.a>0 and card.logo.modulate.a<1 and card.logo.scale.x<1,"the CI fades and settles smoothly into place")
	var clock := card.age
	for locale in ["ko","en"]:
		GameLocale.set_language(locale,false)
		director.refresh_language()
		check(card.caption.text==GameLocale.story_text(director.pages[7]) and card.age==clock and card.logo.texture==GameTitleCard.LOGO,"language changes keep the brand image and animation time: "+locale)
	director._process(1.1)
	check(card.logo.modulate.a==1 and card.logo.scale==Vector2.ONE and card.caption.modulate.a==1 and not card.continue_button.disabled,"the reveal settles to a clear stable logo and continuation action")
	check(director._page_read_duration()>=4.2 and room.profile.attempts==attempts and not room.player.active,"automatic playback reserves a title moment without starting combat early")
	for control: Control in [card.logo,card.caption,card.continue_button]:
		check(Rect2(30,95,1220,635).encloses(control.get_global_rect()),"CI composition and controls stay inside the screen's safe area")
	check(card.caption.get_global_rect().position.y>card.logo.get_global_rect().end.y+20 and card.continue_button.position.y>card.caption.get_global_rect().end.y+20,"narration and the continue action have generous space around the CI")
	director.set_process(true)
	room.settings.open()
	var paused := card.age
	await frames(5)
	check(card.age==paused and card.visible,"options pause the CI reveal without dismissing its current shot")
	room.settings.close()
	director.set_process(false)
	card.continue_button.pressed.emit()
	check(director.page_index==8 and director.stage.visible and director.body_label.visible and not card.visible and director.stage.sooty,"Continue restores the story and retains the ruined classroom and soot")
	director.page_index=7
	director._show_page()
	check(card.visible and card.age==0,"re-entering the title initializes one clean reveal")
	director.skip()
	await frames(4)
	check(room.state=="playing" and not director.is_open and not card.visible and room.hud.visible and room.profile.attempts==attempts+1,"skipping from the CI restores gameplay and starts the expedition exactly once")
	var completed := [0]
	director.play_ending(func(): completed[0]+=1)
	director.set_process(false)
	director.page_index=director.pages.size()-1
	director._show_page()
	director._process(0.6)
	check(not card.continue_button.disabled and card.visible and card.is_ending and card.continue_button.text=="The end" and not director.body_label.visible,"the ending reuses the same CI without an extra dialogue window")
	card.continue_button.pressed.emit()
	await frames()
	check(completed[0]==1 and not director.is_open and not card.visible,"the end-card action completes its sequence once and removes the cover")
	room.queue_free()
	await frames()
	print("TITLE IDENTITY RESULT: %d checks, %d failures" % [checks,failures])
	quit(1 if failures else 0)
