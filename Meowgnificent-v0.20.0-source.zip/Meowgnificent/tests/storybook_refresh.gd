extends SceneTree

var checks := 0
var failures := 0
const CELL := 48.0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
 checks+=1
 if not ok: failures+=1
 print(("PASS: " if ok else "FAIL: ")+label)
func frames(count: int=2) -> void:
 for i in range(count): await process_frame
func mouse_move(point: Vector2) -> void:
 var event := InputEventMouseMotion.new()
 event.position=point
 event.global_position=point
 root.push_input(event,true)
func mouse_click(point: Vector2) -> void:
 for down in [true,false]:
  var event := InputEventMouseButton.new()
  event.position=point
  event.global_position=point
  event.button_index=MOUSE_BUTTON_LEFT
  event.pressed=down
  root.push_input(event,true)
  # Native press/release arrive on different frames. This allows a focus
  # callback's queued frees to run before release, which exposed the bug.
  await frames(2)
func at(cell: Vector2i) -> Vector2: return Vector2(cell)*CELL+Vector2.ONE*CELL*0.5
func walkable(room, cell: Vector2i) -> bool:
 var point := at(cell)
 return room.bounds.grow(-17).has_point(point) and room.obstacles.containing(point,17).is_empty()
func nearby(room, point: Vector2) -> Array[Vector2i]:
 var base := Vector2i(floori(point.x/CELL),floori(point.y/CELL))
 var result: Array[Vector2i]=[]
 for y in range(-1,2):
  for x in range(-1,2):
   var cell := base+Vector2i(x,y)
   if walkable(room,cell) and room.obstacles.clear_line(point,at(cell),17): result.append(cell)
 return result
func reachable_cells(room) -> Dictionary:
 var queue := nearby(room,room.player.position)
 var visited: Dictionary={}
 for cell in queue: visited[cell]=true
 var head := 0
 while head<queue.size():
  var cell := queue[head]
  head+=1
  for offset in [Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP,Vector2i.DOWN]:
   var next: Vector2i=cell+offset
   if visited.has(next) or not walkable(room,next): continue
   if not room.obstacles.clear_line(at(cell),at(next),17): continue
   visited[next]=true
   queue.append(next)
 return visited
func run() -> void:
 change_scene_to_file("res://scenes/main.tscn")
 await frames(6)
 var room=current_scene
 room.begin_or_restart()
 room.set_physics_process(false)
 room.player.set_physics_process(false)
 var shelf_count := 0
 var furniture_count := 0
 for index in range(room.stages.size()):
  room.load_sector(index)
  room.player.set_physics_process(false)
  room.player.invulnerability=100000
  for foe in room.enemies: foe.set_physics_process(false)
  await frames()
  shelf_count+=room.props.size()
  furniture_count+=room.furnishings.size()
  var expected: int=room.stage_def.shelves.size()+room.stage_def.get("furnishings",[]).size()+(1 if str(room.stage_def.kind)=="shop" else 0)
  var contacts: Array=room.obstacles.snapshot().filter(func(e): return e.kind not in ["painted_scenery","sign","friend","hen","gate"])
  check(contacts.size()==expected,"every painted obstacle has one live floor contact in area "+str(index+1))
  check(room.obstacles.containing(room.player.position,17).is_empty(),"arrival position is outside furniture in area "+str(index+1))
  var seen := reachable_cells(room)
  var goals: Array[Vector2]=[WorldLayout.point(ExpeditionMarkers.EXIT_POSITION+Vector2(0,58))]
  for encounter: Dictionary in room.stage_def.get("encounters",[]): goals.append(WorldLayout.point(Vector2(encounter.anchor[0],encounter.anchor[1])))
  for goal in goals:
   var reachable := false
   for cell in nearby(room,goal): reachable=reachable or seen.has(cell)
   check(reachable,"walkable route reaches required destination in area "+str(index+1)+": "+str(goal))
  for prop in room.furnishings:
   var bounds: Rect2=prop.floor_rect()
   var hit: Dictionary=room.obstacles.sweep(bounds.get_center()-Vector2(150,0),bounds.get_center()+Vector2(150,0),14,false)
   check(not hit.hit.is_empty(),"coarse roll cannot skip "+prop.kind+" in area "+str(index+1))
   var food=room.spawn_pickup("food",prop.position,10)
   check(room.obstacles.containing(food.position,9).is_empty(),"loot is projected outside "+prop.kind)
   room.loot.erase(food)
   food.queue_free()
  var enemies_clear := true
  for foe in room.enemies: enemies_clear=enemies_clear and room.obstacles.containing(foe.position,float(foe.config.radius)).is_empty()
  check(enemies_clear,"initial foes spawn outside solid furniture in area "+str(index+1))
 check(shelf_count>=25 and furniture_count>=23,"extra bookcases and contextual furnishings populate the whole expedition")
 room.load_sector(0)
 room.player.set_physics_process(false)
 for foe in room.enemies: foe.set_physics_process(false)
 check(room.run.add_item("crooked_ash_wand"),"a spare weapon is available for the real mouse equip flow")
 room.open_inventory()
 await frames(3)
 var tile: Button=room.panel.item_buttons["crooked_ash_wand"]
 mouse_move(tile.get_global_rect().get_center())
 await mouse_click(tile.get_global_rect().get_center())
 await frames(3)
 check(room.panel.selected_item_id=="crooked_ash_wand" and room.run.equipment.wand!="crooked_ash_wand","a real tile click selects the spare without equipping it")
 mouse_move(room.panel.equip_button.get_global_rect().get_center())
 await frames(2)
 await mouse_click(room.panel.equip_button.get_global_rect().get_center())
 await frames(3)
 check(room.run.equipment.wand=="crooked_ash_wand","the first real mouse click equips after focus leaves the selected tile")
 room.close_panel()
 for id in ["brass_bell_collar","linen_star_collar","raindrop_locket","silver_moon_collar"]:
  check(room.run.add_item(id) and room.equip_gear(id),"real equipped collar: "+id)
  var visual: WizardCatVisual=room.player.visual
  visual.set_process(false)
  for pose in range(5):
   visual.walking=false
   visual.active_pose=pose
   visual.update_mesh()
   visual.equipment_visual._process(0)
   check(visual.motion_material.get_shader_parameter("replace_collar")==true and visual.motion_material.get_shader_parameter("clean_neck_sheet")==WizardCatVisual.CLEAN_ACTIONS,"action pose replaces its original bell: "+id+" / "+str(pose))
   check(visual.equipment_visual.attachments.collar.position.distance_to(visual.collar_anchor())<0.01,"pendant stays at its neck anchor in action pose "+str(pose))
  for frame in range(6):
   visual.walking=true
   visual.walk_frame=frame
   visual.active_pose=0
   visual.update_mesh()
   visual.equipment_visual._process(0)
   check(visual.motion_material.get_shader_parameter("replace_collar")==true and visual.motion_material.get_shader_parameter("clean_neck_sheet")==WizardCatVisual.CLEAN_WALK,"walking frame replaces original bell: "+id+" / "+str(frame))
  visual.walking=false
  visual.active_pose=0
  visual.update_mesh()
 room.open_inventory()
 await frames()
 check(room.panel.preview_model.body.texture==WizardCatVisual.ACTION_SHEET and room.panel.preview_model.body_material.get_shader_parameter("replace_collar")==true,"paperdoll keeps approved cat art and replaces only its embedded bell")
 room.panel.preview_model.set_equipment({"wand":"practice_wand","collar":"","charm":""})
 check(room.panel.preview_model.body_material.get_shader_parameter("replace_collar")==false,"unequipped paperdoll restores the original bell")
 room.close_panel()
 room.player.visual.equipment_visual.set_equipment({"wand":"practice_wand","collar":"","charm":""})
 check(room.player.visual.motion_material.get_shader_parameter("replace_collar")==false,"unequipping restores the gameplay cat's original bell")
 for kind in EnchantedArt.SKILLS:
  var texture: AtlasTexture=EnchantedArt.part(kind)
  check(texture.region.size.x>=600 and texture.region.size.y>=600,"high-density material source for "+kind)
  check(texture.atlas==EnchantedArt.SPELLS or texture.atlas==EnchantedArt.SPELLS_B,"material uses the dedicated four-cell source atlas: "+kind)
 var path := "user://storybook-study-test.json"
 for suffix in ["",".bak"]:
  if FileAccess.file_exists(path+suffix): DirAccess.remove_absolute(path+suffix)
 room.profile=MetaProgress.new(path)
 room.profile.starlight=100
 room.state="intro"
 room.open_legacy()
 for locale in ["ko","en"]:
  GameLocale.set_language(locale,false)
  room.panel.refresh(false)
  await frames(3)
  check(room.panel.purchase_buttons.size()==16,"all sixteen permanent options visible together: "+locale)
  check(room.panel.content.find_children("*","ScrollContainer",true,false).is_empty(),"no tab or scrolling needed for study board: "+locale)
  var footer: Rect2=room.panel.close_button.get_global_rect()
  for button in room.panel.purchase_buttons:
   var rect: Rect2=button.get_global_rect()
   check(Rect2(0,0,1280,800).encloses(rect) and rect.end.y<footer.position.y and rect.size.x>90,"study purchase remains fully accessible: "+locale+str(button.get_meta("study_id")))
  check(footer.end.y<790,"return control is not pushed off screen: "+locale)
 for id in ["tea","skill_power"]:
  var offers: Array=room.profile.upgrade_offers()
  var offer: Dictionary={}
  for row: Dictionary in offers:
   if str(row.id)==id: offer=row
  var before: int=room.profile.starlight
  var button: Button
  for candidate: Button in room.panel.purchase_buttons:
   if str(candidate.get_meta("study_id"))==id: button=candidate
  check(button!=null and not button.disabled,"non-first-column study can be purchased directly: "+id)
  button.pressed.emit()
  await frames(3)
  check(room.profile.upgrades[id]==1 and room.profile.starlight==before-int(offer.cost),"visible study button commits correct rank and exact cost: "+id)
 var reloaded := MetaProgress.new(path)
 check(reloaded.upgrades.tea==1 and reloaded.upgrades.skill_power==1,"one-page board's purchases survive a fresh profile load")
 check(GameLocale.STORY_FONT.resource_path.ends_with("GowunDodum-Regular.ttf") and GameLocale.TITLE_FONT.resource_path.ends_with("Jua-Regular.ttf"),"rounded display and open body typography are shared by both languages")
 room.queue_free()
 await frames()
 for suffix in ["",".bak"]:
  if FileAccess.file_exists(path+suffix): DirAccess.remove_absolute(path+suffix)
 print("STORYBOOK REFRESH RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
