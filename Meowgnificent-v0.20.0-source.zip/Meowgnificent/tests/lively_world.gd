extends SceneTree

var checks := 0
var failures := 0
var room
var path := "/tmp/meow-lively-%d.json" % OS.get_process_id()
func _initialize() -> void: call_deferred("run")
func check(ok: bool,message: String) -> void:
	checks+=1
	if ok: print("PASS: "+message)
	else:
		failures+=1
		push_error("FAIL: "+message)
func frames(n: int=3) -> void:
	for i in range(n): await process_frame
func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode=code
	event.pressed=true
	room._unhandled_key_input(event)
func quiet() -> void:
	room.set_physics_process(false)
	room.player.set_physics_process(false)
	for foe in room.enemies:
		foe.active=false
		foe.set_physics_process(false)
	room.hud.arrival_pending=false
	room.hud.observed_stage=room.run.stage_index
	room.hud.observed_exit_open=room.exit_open
	room.hud.sector_banner.elapsed=100
	room.hud.sector_banner.hide()
func run() -> void:
	OS.set_environment("MEOW_PROFILE_PATH",path)
	OS.set_environment("MEOW_SKIP_STORY","1")
	change_scene_to_file("res://scenes/main.tscn")
	await frames(6)
	room=current_scene
	room.begin_or_restart()
	quiet()
	var id: int=room.get_instance_id()
	key(KEY_R)
	await frames()
	check(current_scene.get_instance_id()==id and room.state=="playing","R cannot reset the current expedition")
	room.tell("Follow the glowing seal to the next encounter.")
	var instruction: String=room.hud.incident_label.text
	room.aside("Wrong way. Make it look intentional.",Color.WHITE,10)
	room.hud._process(0)
	check(room.hud.incident_label.text==instruction and room.hud.aside.visible and room.hud.aside.body.text.contains("10"),"the cat's aside and strain price do not replace progression instructions")
	room.player.config.damage_reduction=99
	room.player.invulnerability=100
	room.player.health.current=100
	check(room.pay_cast_cost("overreaction") and room.player.health.current==95,"critical recoil costs exactly5 vitality through armor and invulnerability")
	check(room.pay_cast_cost("miscast") and room.player.health.current==85 and room.player.soot_time>2,"a miscast costs exactly10 and keeps its distinct soot")
	check(room.pay_cast_cost("success") and room.player.health.current==85,"a successful basic cast has no strain price")
	var food=room.spawn_pickup("food",room.player.position,20)
	room.collect_pickup(food)
	check(room.player.health.current==100,"a canned snack really restores vitality spent on casting")
	check(room.profile.upgrades.values().all(func(rank) -> bool: return int(rank)==0) and room.enemies[0].config.hp>=46 and room.enemies[0].config.speed>90 and room.enemies[0].config.contact_damage>=17,"a fresh profile faces stronger guardians without buying upgrades")
	for foe in room.enemies.duplicate(): foe.take_damage(99999,Vector2.RIGHT)
	room.hud._process(0.1)
	check(room.encounters.state=="waiting" and room.hud.wave_guide.visible,"clearing the first group keeps a dedicated next-wave guide visible")
	room.hud.incident_time=0
	for i in range(5): room.hud._process(1)
	check(room.hud.wave_guide.visible and not room.hud.wave_body.text.is_empty(),"the next-wave instructions outlive transient messages")
	for language in ["ko","en"]:
		GameLocale.set_language(language,false)
		room.hud._process(0)
		check(room.hud.wave_body.get_theme_font("font").get_string_size(room.hud.wave_body.text,HORIZONTAL_ALIGNMENT_LEFT,-1,15).x<=room.hud.wave_body.size.x-8,"the full next-wave instruction fits: "+language)
	for index in range(8):
		room.load_sector(index)
		quiet()
		check(room.obstacles.containing(room.player.position,18.4).is_empty(),"entry stays outside every new solid in area "+str(index+1))
		for glyph in room.scenery.glyphs:
			var hit: Dictionary = room.obstacles.cast(glyph.position+Vector2(0,110),Vector2(0,-220),18.4)
			check(not hit.is_empty() and room.obstacles.containing(glyph.position,18.4).get("kind","")=="sign","illustrated world sign blocks a coarse roll in area "+str(index+1))
		if index in [0,6]:
			for at in [Vector2(220,245),Vector2(500,205),Vector2(960,240),Vector2(1110,260)]:
				check(not room.obstacles.containing(WorldLayout.point(at)).is_empty(),"painted storage cabinets/pots have volume: "+str(at))
		if index in [2,3,5]:
			for at in [Vector2(138,174),Vector2(1140,174),Vector2(400,167),Vector2(500,704)]:
				check(not room.obstacles.containing(WorldLayout.point(at)).is_empty(),"painted garden panels/pots have volume: "+str(at))
	room.load_sector(3)
	quiet()
	var party: ShopGathering=room.markers.gathering
	check(room.markers.is_shop_near(WorldLayout.point(Vector2(640,555))) and not room.markers.is_shop_near(WorldLayout.point(ShopGathering.PIP_POSITION)),"shopping is available only below the table, separate from Pip")
	check(party.hen_root.get_parent()==room.markers.actor_bridge and room.markers.merchant_root.get_parent()==room.markers.actor_bridge and room.markers.actor_bridge.y_sort_enabled,"hen and Pip participate in world depth sorting")
	for actor: String in ["pip","moss","bloop"]:
		var at: Vector2=party._anchor(actor)
		check(not room.obstacles.containing(WorldLayout.point(at)).is_empty(),"the animal's floor contact is solid: "+actor)
		room.player.position=room.obstacles.safe_point(WorldLayout.point(at)+Vector2(60,-35),room.bounds,18.4)
		# The chosen approach is outside the tabletop and closest to this friend.
		room.player.position=WorldLayout.point(at)+Vector2(0,65) if actor!="pip" else WorldLayout.point(at)+Vector2(70,-15)
		party.set_player_position(room.player.position)
		party.animate(0.3)
		key(KEY_E)
		check(room.state=="conversation" and party.active_actor==actor and party.active_line==0 and not room.player.active,"E opens a finite paged conversation: "+actor)
		party.animate(30)
		check(party.conversation.visible and party.active_line==0,"reading time never expires a dialogue page: "+actor)
		for line in range(1,party._lines(actor).size()):
			party.animate(0.3)
			key(KEY_E)
			check(party.active_line==line and room.state=="conversation","E turns to the next authored page: "+actor+str(line))
		party.animate(0.3)
		key(KEY_E)
		check(room.state=="playing" and party.active_actor.is_empty() and not party.conversation.visible,"finishing one loop closes the conversation: "+actor)
		quiet()
	check(not room.obstacles.containing(WorldLayout.point(ShopGathering.HEN_FEET)).is_empty(),"the hen cannot be walked over")
	check(not room.obstacles.containing(WorldLayout.point(ExpeditionMarkers.EXIT_POSITION)).is_empty() and room.markers.gate_art.get_parent()==room.markers.actor_bridge,"the unlocked gate is both solid and depth-sorted")
	for element: String in PaintedProjectileArt.ELEMENTS:
		var normal := PaintedProjectileArt.icon(element,false)
		var critical := PaintedProjectileArt.icon(element,true)
		check(normal.region!=critical.region and normal.get_image().get_used_rect().has_area() and critical.get_image().get_used_rect().has_area(),"normal and critical have separate painted silhouettes: "+element)
	check(NeckPatchArt.ACTIONS.get_size()==Vector2(384,256) and NeckPatchArt.ACTIONS.get_image().get_used_rect().has_area(),"compact lossless neck patches contain actual fur")
	for collar in ["linen_star_collar","brass_bell_collar","silver_moon_collar"]:
		room.run.add_item(collar)
		room.equip_gear(collar)
		room.run.add_item("thunder_spoon")
		room.equip_gear("thunder_spoon")
		room.player.visual.equipment_visual._process(0)
		check(room.player.visual.motion_material.get_shader_parameter("replace_collar")==true and room.player.visual.equipment_visual.attachments.collar.visible,"changing a wand preserves the replacement pendant and its cord: "+collar)
	room.set_running(false)
	check(room.hud.pause_menu.visible and not room.hud.overlay.visible,"ESC pause uses its own compact menu")
	var pause=room.hud.pause_menu
	check([pause.resume_button,pause.restart_button,pause.main_menu_button].all(func(button: Button) -> bool: return Rect2(0,0,1280,800).encloses(button.get_global_rect())),"all three pause actions remain inside the screen")
	pause.resume_requested.emit()
	check(room.state=="playing" and room.player.active,"Continue preserves the current expedition")
	var attempts: int=room.profile.attempts
	room.set_running(false)
	pause.restart_requested.emit()
	await frames(10)
	room=current_scene
	quiet()
	check(room.state=="playing" and room.run.stage_index==0 and room.profile.attempts==attempts+1,"Restart starts one fresh expedition immediately")
	room.set_running(false)
	room.hud.pause_menu.main_menu_requested.emit()
	await frames(10)
	room=current_scene
	check(room.state=="intro" and not room.player.active,"Main menu returns to preparation without starting another attempt")
	room.begin_or_restart()
	quiet()
	room.player.health.current=5
	check(not room.pay_cast_cost("overreaction") and room.state=="defeated" and room.player.health.current==0,"a fatal recoil ends the run without a posthumous cast")
	room.queue_free()
	await frames()
	for suffix in ["",".bak",".tmp"]:
		if FileAccess.file_exists(path+suffix): DirAccess.remove_absolute(path+suffix)
	print("LIVELY WORLD RESULT: %d checks, %d failures" % [checks,failures])
	quit(1 if failures else 0)
