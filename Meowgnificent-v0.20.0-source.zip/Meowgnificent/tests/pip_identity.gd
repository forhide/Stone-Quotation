extends SceneTree

# Check the real world renderer identity and anchored idle behavior with the same atlas used by story, inventory and world.
class RunStub extends RefCounted:
 var stage_index := 0
class RoomStub extends Node2D:
 var run := RunStub.new()
 var stage_def := {"name":"Detention","kind":"combat"}
 var exit_open := false
 var player := Node2D.new()
 var state := "playing"
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func _initialize() -> void: call_deferred("run")
func run() -> void:
 var room := RoomStub.new()
 root.add_child(room)
 room.add_child(room.player)
 var markers := ExpeditionMarkers.new()
 markers.room=room
 room.add_child(markers)
 await process_frame
 var texture: Texture2D=markers.merchant_sprite.texture
 check(texture is AtlasTexture and texture.atlas==ExpeditionMarkers.MERCHANT_ART,"merchant uses the shared squirrel Pip sprite from the animal cast")
 check(ExpeditionMarkers.MERCHANT_ART==AnimalCast.SHEET and texture==AnimalCast.icon("pip"),"the identity source and cached icon are shared by story and field")
 check(Rect2(Vector2.ZERO,ExpeditionMarkers.MERCHANT_ART.get_size()).encloses(ExpeditionMarkers.MERCHANT_REGION) and Rect2(Vector2.ZERO,ExpeditionMarkers.MERCHANT_ART.get_size()).encloses(ExpeditionMarkers.MERCHANT_PORTRAIT_REGION),"full-body and shop portrait crops stay inside the same identity sheet")
 var gathering: ShopGathering=markers.gathering
 var friends_match := gathering.friend_roots.size()==2 and gathering.friends.size()==2 and gathering.friend_roots.has("moss") and gathering.friend_roots.has("bloop")
 for id: String in ["moss","bloop"]:
  friends_match=friends_match and gathering.friends[id] is Sprite2D and gathering.friends[id].get_parent()==gathering.friend_roots[id]
 var steam_matches := gathering.steam.size()==3 and gathering.steam.all(func(line: Line2D) -> bool: return line.get_parent()==gathering and line.points.size()==5 and line.width<=2.0)
 check(friends_match and steam_matches,"the central market retains two grounded animal roots and three bounded tea-steam lines alongside its interaction UI")
 var story: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/story.json"))
 for index in range(8):
  var is_shop := index in [3,6]
  room.run.stage_index=index
  room.stage_def={"name":"Pip’s Picnic" if index==3 else "The Last Loose End" if index==6 else "Combat","kind":"shop" if is_shop else "combat"}
  room.exit_open=is_shop
  markers.update_visuals()
  var snapshot := markers.merchant_snapshot()
  check(bool(snapshot.visible)==is_shop,"area%02d shows Pip only when its real shop is present" % (index+1))
  if not is_shop: continue
  check(snapshot.id=="pip" and snapshot.species=="squirrel" and str(story.chapters[index].get("merchant_id",""))==snapshot.id and str(story.chapters[index].get("merchant_species",""))==snapshot.species,"area%02d story and actual merchant agree on squirrel Pip" % (index+1))
  check(snapshot.anchor==Vector2(640,315),"area%02d retains its existing shop interaction point" % (index+1))
  var feet: Vector2=markers.merchant_root.global_position
  markers._process(0.4)
  var contact: Vector2=markers.merchant_sprite.to_global(Vector2(texture.get_width()*0.5,texture.get_height()))
  var idle_grounded := markers.merchant_root.global_position.is_equal_approx(feet) and contact.is_equal_approx(feet) and absf(markers.merchant_root.scale.y/(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)-1.0)<=0.0071 and is_equal_approx(markers.merchant_root.scale.x/(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE),1.0) and is_zero_approx(markers.merchant_root.rotation)
  gathering.interact("pip")
  gathering.animate(0.35)
  markers._process(0.1)
  contact=markers.merchant_sprite.to_global(Vector2(texture.get_width()*0.5,texture.get_height()))
  var reaction_grounded := gathering.reaction_for("pip")>0 and markers.merchant_root.global_position.is_equal_approx(feet) and contact.is_equal_approx(feet) and absf(markers.merchant_root.scale.y/(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)-1.0)<=0.0251 and absf(markers.merchant_root.scale.x/(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)-1.0)<=0.0251 and absf(markers.merchant_root.rotation)<=0.0351
  check(idle_grounded and reaction_grounded,"area%02d idle breath and larger talk reaction keep the contact point on the floor within their separate pose bounds" % (index+1))
  var time: float=markers.merchant_time
  var pose: Vector2=markers.merchant_root.scale
  var angle: float=markers.merchant_root.rotation
  room.state="shop"
  markers._process(1.0)
  check(is_equal_approx(markers.merchant_time,time) and markers.merchant_root.scale==pose and markers.merchant_root.rotation==angle,"area%02d trading pauses merchant idle and reaction motion" % (index+1))
  room.state="playing"
  room.player.position=WorldLayout.point(Vector2(640,555))
  markers.update_visuals()
  check(markers._shop_near and markers.merchant_sprite.texture==texture,"area%02d near-shop feedback reuses the same Pip artwork" % (index+1))
 room.queue_free()
 await process_frame
 print("PIP IDENTITY RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
