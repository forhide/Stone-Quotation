"""Offline, non-destructive RAW/JPEG or original/edited JPEG analysis.

Observed pixels are the evidence. Lightroom-like values are approximations,
not recovered XMP settings. Matching filenames do not establish registration.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

from .alignment import align_images
from .color_analysis import analyze_color
from .constants import JPEG_EXTENSIONS, RAW_EXTENSIONS
from .tone_analysis import analyze_tone,tone_corrected_rgb

ALGORITHM_VERSION = "0.5.0"
ANALYSIS_SCHEMA_VERSION = 1
MAX_DIMENSION = 1400


def file_fingerprint(path: Path) -> str:
    """Hash local bytes without copying a photo or retaining its metadata."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _input_path(path: Path, *, original: bool = False) -> Path:
    path = Path(path).expanduser().resolve(strict=True)
    if not path.is_file():
        raise ValueError(f"Not an image file: {path}")
    supported = JPEG_EXTENSIONS | RAW_EXTENSIONS if original else JPEG_EXTENSIONS
    if path.suffix.lower() not in supported:
        raise ValueError("The original must be RAW or JPEG, and the edited result must be JPEG.")
    return path


def _contrast_direction(delta: float | None) -> str:
    if delta is None:
        return "uncertain"
    if abs(delta) < 0.005:
        return "neutral"
    return "higher" if delta > 0 else "lower"


def analyze_pair(original_path: Path, edited_path: Path) -> dict:
    """Analyze a pair entirely on the CPU and return JSON-serializable evidence.

    No files are written. A geometric mismatch returns an explicit failure
    payload without tone or color estimates. Unreadable or changing inputs
    raise an exception instead of saving results for uncertain file contents.
    """
    original = _input_path(original_path, original=True)
    edited = _input_path(edited_path)
    if original.samefile(edited):
        raise ValueError("Choose different original and edited image files.")
    is_raw = original.suffix.lower() in RAW_EXTENSIONS
    before = {"original": file_fingerprint(original), "edited": file_fingerprint(edited)}
    result = align_images(original, edited, max_dimension=MAX_DIMENSION)
    alignment = result.metadata
    color_space_verified = "icc_conversion_failed" not in alignment.get("warnings", [])
    warnings = ["inferred_transform", "lightroom_values_approximate"]
    warnings.extend(alignment.get("warnings", []))
    payload = {
        "schema_version": ANALYSIS_SCHEMA_VERSION,
        "algorithm_version": ALGORITHM_VERSION,
        "status": (
            "ok" if alignment.get("success") and color_space_verified
            else "color_space_uncertain" if alignment.get("success")
            else "alignment_failed"
        ),
        "source_type": "inferred_raw_pair" if is_raw else "inferred_jpg_pair",
        "original_path": str(original),
        "edited_path": str(edited),
        "analyzed_at_utc": datetime.now(timezone.utc).isoformat(),
        "provenance": {
            "inferred": True,
            "input_fingerprints": before,
            "originals_modified": False,
            "analysis_max_dimension": MAX_DIMENSION,
            "coordinate_space": "exif_oriented_pixels",
            "evidence": "registered_raw_baseline_and_jpeg_pixels" if is_raw else "registered_jpeg_pixels",
            "exact_xmp_parameters": False,
            "color_space": "srgb_assumed_or_profile_converted" if color_space_verified else "unverified_profile",
        },
        "alignment": alignment,
        "tone": {},
        "color": {},
        "residual_color": {},
        "lightroom_estimates": {"approximate": True, "available": False, "confidence": 0.0},
        "confidence": 0.0,
        "confidence_scope": "registered_tone_color_evidence",
        "warnings": warnings,
    }
    if is_raw:
        payload["provenance"]["raw_baseline"] = alignment["original_decode"]

    if alignment.get("success") and color_space_verified:
        tone = analyze_tone(result.original_aligned, result.edited, result.mask)
        color = analyze_color(result.original_aligned, result.edited, result.mask)
        residual=analyze_color(tone_corrected_rgb(result.original_aligned,tone['tone_transfer']),result.edited,result.mask)
        payload["tone"] = tone
        payload["color"] = color
        payload["residual_color"] = residual
        from .scene_analysis import analyze_evidence
        # Registered pixel coordinates keep region evidence in the compared frame.
        payload['semantic']=analyze_evidence(result.original_aligned,tone_corrected_rgb(result.original_aligned,tone['tone_transfer']),result.edited,result.mask)
        if payload['semantic']['status']!='ok':warnings.append('object_model_unavailable')
        alignment_confidence = float(alignment["confidence"])
        overlap = float(alignment["overlap_fraction"])
        sample_support = min(1.0, min(tone["sample_count"], color["sample_count"]) / 1024.0)
        payload["confidence"] = alignment_confidence * sample_support
        wb = color["wb_tint"]
        payload["lightroom_estimates"] = {
            "approximate": True,
            "available": True,
            "exposure_ev": tone["estimated_exposure_ev"],
            "exposure_confidence": alignment_confidence * float(tone["exposure_confidence"]),
            "contrast_direction": _contrast_direction(tone["contrast_delta"]),
            "white_balance_direction": wb["temperature_direction"],
            "tint_direction": wb["tint_direction"],
            "white_balance_confidence": alignment_confidence * float(wb["confidence"]),
            "confidence": alignment_confidence * min(float(tone["exposure_confidence"]), float(wb["confidence"])),
        }
        if overlap < 0.65:
            warnings.append("sparse_overlap")
        if float(wb["confidence"]) < 0.35:
            warnings.append("limited_neutral_evidence")
        clipping = tone["clipping"]["edited"]
        if float(clipping["black_fraction"]) + float(clipping["white_fraction"]) > 0.05:
            warnings.append("clipping_limits_inference")
    elif not alignment.get("success"):
        warnings.append("alignment_failed")
    else:
        # Shape can register even if the embedded colour space is unreadable.
        # Do not present unverified RGB values as measured sRGB/Lab evidence.
        warnings.append("color_space_uncertain")

    after = {"original": file_fingerprint(original), "edited": file_fingerprint(edited)}
    if after != before:
        raise ValueError("Input image changed during analysis; retry with stable files.")
    payload["warnings"] = list(dict.fromkeys(warnings))
    # Enforce portable SQLite/JSON output here, before any persistence occurs.
    json.dumps(payload, allow_nan=False)
    return payload
