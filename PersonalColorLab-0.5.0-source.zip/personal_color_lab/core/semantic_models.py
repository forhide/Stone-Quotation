"""Verified local model assets and serialized CPU inference. No download path."""
from pathlib import Path
import hashlib
import json
import threading
import cv2

MODEL_ROOT = Path(__file__).resolve().parents[1] / 'assets/models'
IDS = ('nanodet', 'humanseg', 'yunet')
_LOCK = threading.RLock()
_MODELS = {}
_SIGNATURES = {}


class ModelUnavailableError(ValueError):
    """Local model data is missing or fails its pinned checksum."""


def verify_models(root=None):
    root = Path(root or MODEL_ROOT)
    try:
        manifest = json.loads((root / 'manifest.json').read_text())
        entries = manifest['models']
        if manifest['schema_version'] != 1 or [e['id'] for e in entries] != list(IDS):
            raise ValueError('Unsupported model manifest')
        for entry in entries:
            for field, digest, size in [('filename', entry['sha256'], entry['size']), ('license', entry['license_sha256'], None)]:
                path = root / entry[field]
                if Path(entry[field]).name != entry[field] or path.is_symlink() or not path.is_file():
                    raise ValueError('Missing local model or license')
                if size is not None and path.stat().st_size != size:
                    raise ValueError('Model size mismatch')
                if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                    raise ValueError('Model checksum mismatch')
        return manifest
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise ModelUnavailableError('The bundled recognition models are unavailable or corrupt. Reinstall the complete application.') from exc


def bundle_id():
    manifest = json.loads((MODEL_ROOT / 'manifest.json').read_text())
    return hashlib.sha256(json.dumps([(e['id'],e['sha256']) for e in manifest['models']], separators=(',', ':')).encode()).hexdigest()


def _load(identifier):
    if identifier not in IDS:
        raise ValueError('Unknown recognition model')
    path = MODEL_ROOT / (identifier + '.onnx')
    try:
        signature = (path.stat().st_size, path.stat().st_mtime_ns)
    except OSError as exc:
        raise ModelUnavailableError('Bundled recognition model is missing.') from exc
    if identifier not in _MODELS or _SIGNATURES.get(identifier) != signature:
        verify_models()
        if identifier == 'yunet':
            net = cv2.FaceDetectorYN.create(str(path), '', (320,320), .85, .3, 100, cv2.dnn.DNN_BACKEND_OPENCV, cv2.dnn.DNN_TARGET_CPU)
        else:
            net = cv2.dnn.readNetFromONNX(str(path))
            net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        _MODELS[identifier] = net
        _SIGNATURES[identifier] = signature
    return _MODELS[identifier]


def infer(identifier, blob):
    with _LOCK:
        net = _load(identifier)
        net.setInput(blob)
        if identifier == 'nanodet':
            return net.forward(net.getUnconnectedOutLayersNames())
        return net.forward()


def detect_faces(bgr):
    with _LOCK:
        net = _load('yunet')
        net.setInputSize((bgr.shape[1], bgr.shape[0]))
        _, faces = net.detect(bgr)
        return faces
