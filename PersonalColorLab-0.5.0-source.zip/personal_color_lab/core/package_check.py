"""Offline packaged-runtime checks using only disposable, synthetic inputs.

No GUI window, user library, environment variable, or original photograph is
changed. The same checks run from source Python and a frozen application.
"""
from __future__ import annotations

import importlib
import platform
import string
import sys
import tempfile
from pathlib import Path

from .constants import APP_NAME, APP_VERSION, DEFAULT_LANGUAGE

REPORT_SCHEMA_VERSION = 1


def _locales() -> dict:
    from .i18n import I18N

    english, korean = I18N('en'), I18N('ko')
    if english.messages.keys() != korean.messages.keys():
        raise RuntimeError('English and Korean locale resources have different keys.')
    formatter = string.Formatter()
    for key, text in english.messages.items():
        translated = korean.messages[key]
        if not isinstance(text, str) or not text or not isinstance(translated, str) or not translated:
            raise RuntimeError(f'Locale message is missing or invalid: {key}')
        fields = {name for _, name, _, _ in formatter.parse(text) if name is not None}
        translated_fields = {name for _, name, _, _ in formatter.parse(translated) if name is not None}
        if fields != translated_fields:
            raise RuntimeError(f'Locale message format arguments differ: {key}')
    if I18N().language != DEFAULT_LANGUAGE:
        raise RuntimeError('Default UI language does not match application configuration.')
    return {'languages': ['en', 'ko'], 'message_count': len(english.messages), 'default_language': DEFAULT_LANGUAGE}


def _dependencies() -> dict:
    versions = {}
    for name in ('PIL', 'numpy', 'cv2', 'rawpy'):
        module = importlib.import_module(name)
        versions[name] = str(module.__version__)
        if name == 'rawpy':
            versions['libraw'] = '.'.join(str(part) for part in module.libraw_version)
    import sqlite3
    versions['sqlite'] = sqlite3.sqlite_version
    return versions


def _tcl_runtime() -> dict:
    # A Tcl interpreter checks bundled init.tcl without requiring a display.
    import tkinter

    interpreter = tkinter.Tcl()
    version = interpreter.eval('info patchlevel')
    return {'tcl_version': version, 'tk_binding_version': str(tkinter.TkVersion)}


def _synthetic_analysis_and_library() -> dict:
    import cv2
    import numpy as np
    from PIL import Image

    from .database import LibraryDB
    from .edit_reverse import ALGORITHM_VERSION, analyze_pair, file_fingerprint
    from .schema_migrations import CURRENT_SCHEMA_VERSION

    rng = np.random.default_rng(271828)
    image = rng.integers(40, 180, (240, 360, 3), dtype=np.uint8)
    image = cv2.GaussianBlur(image, (5, 5), 0)
    for _ in range(60):
        x, y = rng.integers(10, 220, 2)
        color = tuple(int(value) for value in rng.integers(35, 200, 3))
        cv2.circle(image, (int(x), int(y)), 5, color, -1)
    for index in range(4):
        value = 45 + index * 35
        cv2.rectangle(image, (280, 8 + index * 55), (340, 38 + index * 55), (value,) * 3, -1)
    edited = np.clip(image.astype(np.float64) * 1.08 + [6, 1, -4], 0, 255).astype(np.uint8)

    with tempfile.TemporaryDirectory(prefix='personal-color-lab-self-test-') as directory:
        root = Path(directory)
        original_path, edited_path = root / 'synthetic_original.jpg', root / 'synthetic_edit.jpg'
        Image.fromarray(image).save(original_path, quality=98, subsampling=0)
        Image.fromarray(edited).save(edited_path, quality=98, subsampling=0)
        before = [file_fingerprint(path) for path in (original_path, edited_path)]
        payload = analyze_pair(original_path, edited_path)
        if payload['status'] != 'ok' or not payload['alignment']['success']:
            raise RuntimeError('Synthetic JPG registration or analysis failed.')
        if payload['algorithm_version'] != ALGORITHM_VERSION:
            raise RuntimeError('Analysis algorithm version is inconsistent.')
        if payload['tone']['mean_luminance_delta'] <= 0:
            raise RuntimeError('Synthetic brightening was not detected.')
        if not payload['lightroom_estimates']['approximate']:
            raise RuntimeError('Inferred slider estimates are missing their approximate label.')
        if before != [file_fingerprint(path) for path in (original_path, edited_path)]:
            raise RuntimeError('Analysis modified a synthetic source image.')
        with LibraryDB(root / 'temporary_library.db') as library:
            analysis_id = library.save_analysis(original_path, edited_path, payload)
            if not analysis_id or library.get_analysis(original_path, edited_path) != payload:
                raise RuntimeError('Temporary SQLite analysis round trip failed.')
            schema_version = library.conn.execute('PRAGMA user_version').fetchone()[0]
            if schema_version != CURRENT_SCHEMA_VERSION:
                raise RuntimeError('Temporary SQLite schema version is inconsistent.')
        return {
            'algorithm_version': ALGORITHM_VERSION,
            'analysis_status': payload['status'],
            'alignment_confidence': payload['alignment']['confidence'],
            'mean_luminance_delta': payload['tone']['mean_luminance_delta'],
            'library_schema_version': schema_version,
            'originals_unchanged': True,
            'temporary_files_removed_on_return': True,
        }


def _synthetic_raw_analysis() -> dict:
    """Exercise actual LibRaw sensor decoding and RAW/JPG registration."""
    import numpy as np
    from PIL import Image

    from .edit_reverse import analyze_pair, file_fingerprint
    from .raw_decode import decode_raw
    from .synthetic_raw import write_test_dng

    with tempfile.TemporaryDirectory(prefix='personal-color-lab-raw-self-test-') as directory:
        root = Path(directory)
        raw_path = write_test_dng(root / 'synthetic.dng')
        raw_before = file_fingerprint(raw_path)
        rgb, original_size, provenance = decode_raw(raw_path)
        if original_size != (480, 360) or rgb.shape != (360, 480, 3):
            raise RuntimeError('Synthetic RAW decoded with unexpected dimensions.')
        if provenance.get('embedded_preview_used') is not False or provenance.get('decoder') != 'rawpy_libraw':
            raise RuntimeError('RAW decoder did not use the LibRaw sensor baseline.')
        edited = np.clip(rgb.astype(np.float64) * 1.03 + [5, 2, -2], 0, 255).astype(np.uint8)
        edited_path = root / 'synthetic_edit.jpg'
        Image.fromarray(edited).save(edited_path, quality=98, subsampling=0)
        edited_before = file_fingerprint(edited_path)
        payload = analyze_pair(raw_path, edited_path)
        if payload['status'] != 'ok' or not payload['alignment']['success']:
            raise RuntimeError('Synthetic RAW/JPG registration or analysis failed.')
        if not payload['lightroom_estimates']['approximate']:
            raise RuntimeError('Inferred RAW slider estimates lack the approximate label.')
        if payload['tone']['mean_luminance_delta'] <= 0:
            raise RuntimeError('Synthetic RAW brightening was not detected.')
        if raw_before != file_fingerprint(raw_path) or edited_before != file_fingerprint(edited_path):
            raise RuntimeError('RAW analysis changed a synthetic input image.')
        return {
            'decoder': provenance['decoder'],
            'rawpy_version': provenance['rawpy_version'],
            'libraw_version': provenance['libraw_version'],
            'decoded_dimensions': list(original_size),
            'embedded_preview_used': False,
            'raw_jpg_status': payload['status'],
            'alignment_confidence': payload['alignment']['confidence'],
            'originals_unchanged': True,
            'temporary_files_removed_on_return': True,
        }


def _synthetic_source_workflows_and_profiles() -> dict:
    """Exercise discovery, all three analyses and reopened SQLite snapshots."""
    import numpy as np
    from PIL import Image

    from .database import LibraryDB
    from .edit_reverse import file_fingerprint
    from .raw_decode import decode_raw
    from .source_workflow import MODES, analyze_inputs, discover_inputs
    from .synthetic_raw import write_test_dng

    with tempfile.TemporaryDirectory(prefix='personal-color-lab-sources-self-test-') as directory:
        root = Path(directory)
        paired, references = root / 'paired', root / 'references'
        paired.mkdir()
        references.mkdir()
        raw_path = write_test_dng(paired / 'synthetic.dng')
        rgb, _, _ = decode_raw(raw_path)
        edited = np.clip(rgb.astype(np.float64) * 1.05 + [7, 2, -3], 0, 255).astype(np.uint8)
        edited_path = paired / 'synthetic.jpg'
        Image.fromarray(edited).save(edited_path, quality=98, subsampling=0)
        xmp_path = paired / 'synthetic.dng.xmp'
        xmp_path.write_text(
            '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
            'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">'
            '<rdf:Description crs:ProcessVersion="11.0" crs:Exposure2012="0.65" '
            'crs:Temperature="6200" crs:Saturation="-12" crs:ConvertToGrayscale="False">'
            '<crs:ToneCurvePV2012><rdf:Seq><rdf:li>0, 8</rdf:li>'
            '<rdf:li>255, 248</rdf:li></rdf:Seq></crs:ToneCurvePV2012>'
            '</rdf:Description></rdf:RDF>', encoding='utf-8',
        )
        for index, pixels in enumerate((edited, np.roll(edited, 1, axis=2))):
            Image.fromarray(pixels).save(references / f'reference-{index}.jpg', quality=98, subsampling=0)
        paths = [raw_path, edited_path, xmp_path, *sorted(references.glob('*.jpg'))]
        before = [file_fingerprint(path) for path in paths]
        batches, profile_ids, details = {}, {}, {}
        database_path = root / 'temporary_library.db'
        with LibraryDB(database_path) as library:
            for mode in MODES:
                discovery = discover_inputs(references if mode == 'reference_jpg' else paired, mode)
                expected = 2 if mode == 'reference_jpg' else 1
                if discovery['counts']['ready'] != expected:
                    raise RuntimeError(f'Synthetic {mode} discovery did not identify the expected inputs.')
                batch = analyze_inputs(discovery['items'], mode)
                if batch['status'] != 'ok' or batch['counts']['successful'] != expected:
                    raise RuntimeError(f'Synthetic {mode} batch analysis failed.')
                payload = batch['results'][0]['payload']
                if mode == 'raw_jpg':
                    if payload['source_type'] != 'inferred_raw_pair' or not payload['lightroom_estimates']['approximate']:
                        raise RuntimeError('RAW/JPG batch lost its inferred-baseline provenance.')
                elif mode == 'raw_xmp':
                    if payload['parameters']['Exposure2012'] != 0.65 or not payload['tone_curves']:
                        raise RuntimeError('RAW/XMP batch did not retain recorded values and tone curves.')
                    if payload['provenance']['render_equivalence_verified'] is not False:
                        raise RuntimeError('XMP extraction incorrectly claims verified rendering.')
                elif not batch['summary'].get('appearance') or not batch['summary'].get('palette'):
                    raise RuntimeError('JPG references did not produce appearance and palette measurements.')
                batches[mode] = batch
                profile_ids[mode] = library.save_source_profile(f'Synthetic {mode}', batch)
                details[mode] = {
                    'status': batch['status'], 'successful_inputs': expected,
                    'sample_count': batch['summary']['sample_count'],
                    'profile_saved_and_reopened': False,
                }
        # Open a fresh connection: in-memory object reuse is not persistence.
        with LibraryDB(database_path) as library:
            if {row['mode'] for row in library.list_source_profiles()} != set(MODES):
                raise RuntimeError('Saved source profiles were not listed after reopening SQLite.')
            for mode, profile_id in profile_ids.items():
                saved = library.get_source_profile(profile_id)
                if saved is None or saved['mode'] != mode or saved['payload'] != batches[mode]:
                    raise RuntimeError(f'Saved {mode} snapshot did not survive reopening SQLite.')
                details[mode]['profile_saved_and_reopened'] = True
        if before != [file_fingerprint(path) for path in paths]:
            raise RuntimeError('Source workflows changed a synthetic input file.')
        return {
            'modes': details, 'originals_unchanged': True,
            'temporary_files_removed_on_return': True,
        }


def _style_application():
    import hashlib
    import numpy as np
    from PIL import Image
    from .database import LibraryDB
    from .source_workflow import analyze_inputs, discover_inputs
    from .style_dna import builtin_styles, dna_from_batch, blend_styles, load_style_file
    from .style_render import apply_pixels, render_preview, export_jpeg, export_xmp, export_style_json
    from .xmp_analysis import analyze_raw_xmp
    with tempfile.TemporaryDirectory(prefix='pcl-style-self-test-') as directory:
        root = Path(directory)
        source = root / 'source.jpg'
        pixels = np.random.default_rng(51).integers(30, 200, (100, 150, 3), dtype='uint8')
        Image.fromarray(pixels).save(source)
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        with LibraryDB(root / 'library.db') as db:
            items = discover_inputs(root, 'reference_jpg')['items']
            batch = analyze_inputs(items, 'reference_jpg', cache=db)
            repeated = analyze_inputs(items, 'reference_jpg', cache=db)
            assert repeated['performance']['cache_hits'] == 1
            reference = dna_from_batch(batch, 'Diagnostic reference')
            styles = builtin_styles()
            assert len(styles) == 12
            dna = blend_styles([reference, styles[0]], [.5, .5], 'Diagnostic mix')
            identifier = db.save_style_preset(dna['name'], dna)
            assert db.get_style_preset(identifier)['dna'] == dna
        preview = render_preview(source, dna, .7)
        assert np.array_equal(apply_pixels(pixels, dna, 0)[0], pixels)
        export_jpeg(source, root / 'copy.jpg', dna, .7, expected_fingerprint=before)
        assert Image.open(root / 'copy.jpg').size == (150, 100)
        export_style_json(root / 'style.json', dna)
        assert load_style_file(root / 'style.json') == dna
        export_xmp(root / 'style.xmp', dna, preview['effective'], .7)
        raw = root / 'source.dng'; raw.write_bytes(b'diagnostic association only')
        assert analyze_raw_xmp(raw, root / 'style.xmp')['status'] == 'ok'
        assert hashlib.sha256(source.read_bytes()).hexdigest() == before
    return {'builtin_profiles': 12, 'cache_hits': 1, 'exports': ['jpeg', 'xmp', 'style_json'], 'original_preserved': True}


def _embedded_recognition():
    import numpy as np
    from .semantic_models import verify_models,infer
    from .scene_analysis import analyze_scene
    manifest=verify_models()
    scene=analyze_scene(np.full((120,180,3),128,dtype='uint8'))
    if scene['report']['objects'] or scene['report']['faces']:
        raise RuntimeError('The blank recognition fixture produced confident objects.')
    mask=infer('humanseg',np.zeros((1,3,192,192),np.float32))
    if mask.shape!=(1,2,192,192) or not np.isfinite(mask).all():
        raise RuntimeError('The embedded person segmentation failed.')
    return {'models':[e['id'] for e in manifest['models']],'verified_model_bytes':sum(e['size'] for e in manifest['models']),
            'backend':'opencv_dnn_cpu','supported_object_classes':80,'face_identity_recognition':False,
            'downloaded_at_runtime':False,'blank_objects':0,'person_output_shape':list(mask.shape)}


def run_package_check() -> dict:
    """Return a portable diagnostic report; a failed check never opens a GUI."""
    report = {
        'report_schema_version': REPORT_SCHEMA_VERSION,
        'app_name': APP_NAME,
        'app_version': APP_VERSION,
        'python_version': platform.python_version(),
        'platform': sys.platform,
        'machine': platform.machine(),
        'frozen': bool(getattr(sys, 'frozen', False)),
        'ok': True,
        'checks': [],
    }
    for name, check in (
        ('locale_resources', _locales),
        ('native_dependencies', _dependencies),
        ('tcl_runtime', _tcl_runtime),
        ('synthetic_analysis_and_library', _synthetic_analysis_and_library),
        ('synthetic_raw_analysis', _synthetic_raw_analysis),
        ('synthetic_source_workflows_and_profiles', _synthetic_source_workflows_and_profiles),
        ('style_application_and_cache', _style_application),
        ('embedded_object_person_face_recognition', _embedded_recognition),
    ):
        try:
            details = check()
            report['checks'].append({'name': name, 'ok': True, 'details': details})
        except Exception as exc:
            report['ok'] = False
            report['checks'].append({'name': name, 'ok': False, 'error_type': type(exc).__name__, 'error': str(exc)})
    return report
