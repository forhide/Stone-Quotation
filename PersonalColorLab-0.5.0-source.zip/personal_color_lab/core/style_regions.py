"""Learn bounded object-region recipes and apply them using reviewed masks."""
import copy
from statistics import median
import cv2
import numpy as np
from .scene_analysis import REGIONS

CONTEXTS=('people','animals','food','vehicles','interior_objects','street_objects','plants')
GRID=np.linspace(0,1,33)


def profile_empty():
    return {'bundle_id':None,'regions':{},'contexts':{}}


def validate_profile(profile,target_valid,number):
    if not isinstance(profile,dict) or set(profile)!={'bundle_id','regions','contexts'}:
        raise ValueError('Invalid object-style profile')
    bundle=profile['bundle_id']
    if bundle is not None and (not isinstance(bundle,str) or len(bundle)!=64 or any(c not in '0123456789abcdef' for c in bundle)):
        raise ValueError('Invalid model evidence')
    if not isinstance(profile['regions'],dict) or set(profile['regions'])-set(REGIONS) or not isinstance(profile['contexts'],dict) or set(profile['contexts'])-set(CONTEXTS):
        raise ValueError('Unknown object-style regions')
    for region,value in profile['regions'].items():
        if not isinstance(value,dict) or set(value)!={'sample_count','evidence','target','tone_curve','saturation_scale','lab_shift'}:
            raise ValueError('Invalid region recipe')
        if type(value['sample_count']) is not int or value['sample_count']<1 or value['evidence'] not in {'reference_appearance','observed_transform'}:
            raise ValueError('Invalid region support')
        if value['target'] is not None and not target_valid(value['target']):raise ValueError('Invalid region appearance')
        if value['evidence']=='reference_appearance' and (value['target'] is None or value['sample_count']<3):raise ValueError('Insufficient reference region support')
        curve=value['tone_curve']
        if not isinstance(curve,list) or len(curve)!=33 or not all(number(v,0,1) for v in curve) or curve!=sorted(curve):raise ValueError('Invalid region tone curve')
        if not number(value['saturation_scale'],.5,1.5) or not isinstance(value['lab_shift'],list) or len(value['lab_shift'])!=2 or not all(number(v,-8,8) for v in value['lab_shift']):raise ValueError('Invalid region transform')
    for value in profile['contexts'].values():
        if not isinstance(value,dict) or set(value)!={'target','sample_count'} or type(value['sample_count']) is not int or value['sample_count']<3 or not target_valid(value['target']):raise ValueError('Invalid object-derived context target')
    if (profile['regions'] or profile['contexts']) and bundle is None:raise ValueError('Missing model provenance')


def median_target(targets):
    zones={}
    for zone in ('shadows','midtones','highlights'):
        shifts=[t['zones'][zone] for t in targets if zone in t['zones']]
        if len(shifts)>=3:zones[zone]=np.median(shifts,axis=0).tolist()
    return {'quantiles':np.median([t['quantiles'] for t in targets],axis=0).tolist(),
            'saturation':float(np.median([t['saturation'] for t in targets])),'zones':zones}


def learn_profile(payloads,mode,appearance_target):
    evidence=[p for p in payloads if p.get('semantic',{}).get('status')=='ok']
    if not evidence:return profile_empty()
    bundles={p['semantic']['bundle_id'] for p in evidence}
    if len(bundles)!=1:return profile_empty()
    profile=profile_empty();profile['bundle_id']=next(iter(bundles))
    unique={tuple(sorted(p.get('provenance',{}).get('input_fingerprints',{}).items())):p for p in evidence}
    evidence=list(unique.values())
    for region in REGIONS:
        values=[p['semantic'].get('region_appearance' if mode=='reference_jpg' else 'region_transforms',{}).get(region) for p in evidence]
        values=[v for v in values if v is not None]
        if not values or mode=='reference_jpg' and len(values)<3:continue
        if mode=='reference_jpg':
            target=median_target([v['target'] for v in values]);curve=GRID.tolist();saturation=1.;shift=[0.,0.]
        else:
            target=None;curve=np.median([v['tone_curve'] for v in values],axis=0).tolist()
            saturation=float(np.median([v['saturation_scale'] for v in values]));shift=np.median([v['lab_shift'] for v in values],axis=0).tolist()
        profile['regions'][region]={'sample_count':len(values),'evidence':'reference_appearance' if mode=='reference_jpg' else 'observed_transform',
            'target':target,'tone_curve':curve,'saturation_scale':saturation,'lab_shift':shift}
    if mode=='reference_jpg':
        for context in CONTEXTS:
            subset=[p for p in evidence if context in p['semantic']['scene_tags']]
            if len(subset)>=3:profile['contexts'][context]={'sample_count':len(subset),'target':median_target([appearance_target(p['appearance']) for p in subset])}
    return profile


def regional_transforms(original,corrected,edited,scene):
    from .scene_analysis import region_appearance
    source=region_appearance(original,scene);residual=region_appearance(corrected,scene);target=region_appearance(edited,scene)
    result={}
    for region in source.keys() & target.keys() & residual.keys():
        a,b,c=source[region]['target'],target[region]['target'],residual[region]['target']
        x=np.array(a['quantiles']);y=np.array(b['quantiles']);unique,indices=np.unique(x,return_index=True)
        if len(unique)<3:continue
        desired=np.maximum.accumulate(np.clip(y,x-.2,x+.2))
        curve=np.interp(GRID,[0,*unique,1],[0,*desired[indices],1])
        common=set(b['zones']) & set(c['zones'])
        shifts=[np.array(b['zones'][z])-c['zones'][z] for z in common]
        result[region]={'tone_curve':np.maximum.accumulate(np.clip(curve,0,1)).tolist(),
            'saturation_scale':float(np.clip(b['saturation']/max(.08,c['saturation']),.5,1.5)),
            'lab_shift':np.clip(np.mean(shifts,axis=0) if shifts else [0,0],-8,8).tolist()}
    return result


def style_distances(measurement,styles,scene_report=None):
    """Heuristic visual fingerprints, not a trained artistic-style classifier."""
    scored=[];observed=np.array(measurement['quantiles'])
    observed_cast=np.array(measurement.get('neutral_cast',[0.,0.]))
    cast_support=measurement.get('neutral_cast_support',0)>=.02
    for key,dna in styles.items():
        if dna['kind']=='hybrid':continue
        target=dna.get('reference_target')
        if target:
            expected=np.array(target['quantiles']);saturation=target['saturation']
            casts=list(target['zones'].values());cast=np.mean(casts,axis=0) if casts else np.zeros(2)
        else:
            # Compare to a neutral photographic archetype transformed by DNA.
            # This is a rough look descriptor, never proof of artistic identity.
            expected=np.interp([.05,.25,.5,.75,.95],GRID,dna['tone_curve'])
            expected=np.clip(expected*2**(dna['exposure_ev']*.45),0,1)
            saturation=min(1,.4*dna['saturation_scale'])
            cast=np.array(dna['lab_shift'])+np.mean(list(dna['zone_shifts'].values()),axis=0)
        tone=float(np.mean(np.abs((expected-expected[2])-(observed-observed[2]))))
        color=abs(saturation-measurement['saturation'])*.45
        if cast_support:color+=float(np.linalg.norm(cast-observed_cast))*.015
        supported=set(dna.get('semantic_profile',{}).get('contexts',{})) & set((scene_report or {}).get('scene_tags',[]))
        score=max(0,tone+color-.035*bool(supported))
        scored.append((key,float(score),bool(supported)))
    return sorted(scored,key=lambda row:row[1])[:3]


def recipes_for_scene(dna, scene_report):
    if dna['kind']=='hybrid':
        result={}
        for component in dna['components']:
            for region,recipes in recipes_for_scene(component['dna'],scene_report).items():
                result.setdefault(region,[]).extend((style,weight*component['weight'],source_dna) for style,weight,source_dna in recipes)
        return result
    profile=dna.get('semantic_profile',profile_empty())
    if profile['bundle_id']!=scene_report.get('bundle_id'):return {}
    return {region:[(style,1.,dna)] for region,style in profile['regions'].items()}


def resized_mask_tile(mask,width,height,top,rows):
    # Bound memory: never expand every semantic mask to full sensor resolution.
    mx=(np.arange(width,dtype=np.float32)+.5)*mask.shape[1]/width-.5
    my=(np.arange(top,top+rows,dtype=np.float32)+.5)*mask.shape[0]/height-.5
    xx,yy=np.meshgrid(mx,my)
    return cv2.remap(mask,xx,yy,cv2.INTER_LINEAR,borderMode=cv2.BORDER_REPLICATE)


def protect_face_colors(original,styled,mask,amount=.65):
    # Keep the chosen tone; attenuate Lab chroma changes inside detected faces.
    a=cv2.cvtColor(original.astype(np.float32)/255,cv2.COLOR_RGB2LAB)
    b=cv2.cvtColor(styled.astype(np.float32)/255,cv2.COLOR_RGB2LAB)
    original_chroma=np.linalg.norm(a[:,:,1:],axis=2)
    styled_chroma=np.linalg.norm(b[:,:,1:],axis=2)
    direction=np.divide(a[:,:,1:],original_chroma[:,:,None],out=np.zeros_like(a[:,:,1:]),where=original_chroma[:,:,None]>3)
    desired=direction*styled_chroma[:,:,None]
    support=mask*(original_chroma>3)
    mixed=b[:,:,1:]+(desired-b[:,:,1:])*support[:,:,None]*amount
    mixed_chroma=np.linalg.norm(mixed,axis=2)
    b[:,:,1:]=np.divide(mixed,mixed_chroma[:,:,None],out=np.zeros_like(mixed),where=mixed_chroma[:,:,None]>1e-5)*styled_chroma[:,:,None]
    rgb=cv2.cvtColor(b,cv2.COLOR_LAB2RGB)
    protected=np.rint(np.clip(rgb,0,1)*255).astype('uint8')
    return np.where((mask>0)[:,:,None],protected,styled)
