#!/usr/bin/env python3
"""Package already-exported release builds, without bundling the editor or source."""
import hashlib
import pathlib
import re
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
OUTPUT = ROOT.parent
VERSION = 'v0.19.0'
SOURCE_ONLY = '--source-only' in sys.argv[1:]
QA_PREFIX = 'v' + ''.join(character for character in VERSION if character.isdigit())

# Previous release archives retain superseded illustrations. Keep the current
# source bundle reproducible and small by omitting only explicit art paths that
# every platform already excludes; never delete the workspace originals.
_export_exclusions = [set(value.split(',')) for value in re.findall(
    r'^exclude_filter="([^"\n]*)"', (ROOT/'export_presets.cfg').read_text(), re.M)]
if len(_export_exclusions) != 4:
    raise SystemExit('Expected four export exclusion lists before packaging.')
ARCHIVED_SOURCE_ART = {
    path for path in set.intersection(*_export_exclusions)
    if path.startswith('art/') and not any(symbol in path for symbol in '*?[')
}

def include_source_file(path):
    relative = path.relative_to(ROOT)
    if any(part in {'.godot', '.local', 'exports', '__pycache__'} for part in relative.parts):
        return False
    if relative.as_posix().removesuffix('.import') in ARCHIVED_SOURCE_ART:
        return False
    # Keep this release's QA evidence; previous releases retain their own
    # source archives. No workspace files or original design notes are removed.
    if relative.parts[:2] == ('docs', 'qa'):
        return len(relative.parts) >= 3 and relative.parts[2].startswith(QA_PREFIX)
    return True
LICENSES = ['GODOT-LICENSE.txt', 'GODOT-THIRD-PARTY.txt', 'NOTO-FONT-LICENSE.txt', 'PRETENDARD-LICENSE.txt', 'JUA-FONT-LICENSE.txt', 'GOWUN-DODUM-LICENSE.txt']
archives = []
for platform in ['windows', 'linux', 'web', 'macos']:
    suffix = platform
    archive = OUTPUT / f'Meowgnificent-{VERSION}-{suffix}.zip'
    if SOURCE_ONLY:
        if not archive.is_file():
            raise SystemExit(f'Missing platform ZIP: {archive}; package all platforms first.')
        with zipfile.ZipFile(archive) as existing:
            if existing.testzip() is not None:
                raise SystemExit('Archive integrity failed: '+str(archive))
        archives.append(archive)
        continue
    files = sorted(p for p in (ROOT/'exports'/platform).iterdir() if p.is_file())
    if not files:
        raise SystemExit(f'No exported files: {platform}; run ./build.sh first.')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        if platform == 'macos':
            # Keep .app bundle layout and Unix executable permissions intact.
            with zipfile.ZipFile(ROOT/'exports/macos/Meowgnificent.zip') as app:
                for entry in app.infolist():
                    z.writestr(entry, app.read(entry.filename), compress_type=zipfile.ZIP_DEFLATED)
        else:
            for p in files:
                z.write(p, p.name)
        guide = 'DEPLOY-WEB.txt' if platform == 'web' else f'PLAY-{platform.upper()}.txt'
        z.write(ROOT/'distribution'/guide, guide)
        for name in LICENSES:
            z.write(ROOT/'docs'/name, name)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise SystemExit('Archive integrity failed: '+str(archive))
    archives.append(archive)
source = OUTPUT/f'Meowgnificent-{VERSION}-source.zip'
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and include_source_file(p):
            z.write(p, pathlib.Path('Meowgnificent')/p.relative_to(ROOT))
archives.append(source)
manifest = OUTPUT/f'Meowgnificent-{VERSION}-SHA256SUMS.txt'
manifest.write_text(''.join(f'{hashlib.file_digest(p.open("rb"), "sha256").hexdigest()}  {p.name}\n' for p in archives))
for p in archives:
    print(f'{p.name}: {p.stat().st_size/1024/1024:.2f} MiB')
print('Checksums:', manifest)
