class_name ExpeditionMarkers
extends Node2D

const EXIT_POSITION := Vector2(1136,430)
const SHOP_POSITION := Vector2(640,315)
const GATE_CLOSED: Texture2D = preload("res://art/items/archive_gate_closed.svg")
const GATE_OPEN: Texture2D = preload("res://art/items/archive_gate_open.svg")
const MERCHANT_ID := "pip"
const MERCHANT_NAME := "Pip"
const MERCHANT_TITLE := "Pip's Finds"
# Story portraits, the field merchant and the shop now share animal Pip.
const MERCHANT_ART: Texture2D = AnimalCast.SHEET
const MERCHANT_REGION: Rect2 = AnimalCast.REGIONS["pip"]
const MERCHANT_PORTRAIT_REGION: Rect2 = MERCHANT_REGION
const ROUTE_ART: Texture2D = preload("res://art/items/archive_route.svg")

var room: Node2D
var _signature := ""
var _stage_index := 0
var _sector_name := "The Candlewick Archives"
var _kind := "combat"
var _exit_open := false
var _exit_near := false
var _shop_near := false
var merchant_root: Node2D
var merchant_sprite: Sprite2D
var merchant_time := 0.0
var gathering: ShopGathering
const EXIT_REVEAL_SECONDS := 0.55
var _exit_visible := false
var exit_reveal_age := 0.0
var exit_plate: StyleBoxFlat

func _ready() -> void:
	# Storybook garden gate and Pip's little stall stay behind living actors.
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	scale=Vector2.ONE*WorldLayout.SCALE
	physics_interpolation_mode=Node.PHYSICS_INTERPOLATION_MODE_OFF
	z_index=-2
	exit_plate=_plate(Color("fff1d6"))
	gathering=ShopGathering.new()
	gathering.room=room
	add_child(gathering)
	_create_merchant()
	update_visuals()

func _create_merchant() -> void:
	merchant_root=Node2D.new()
	merchant_root.name="PipMerchant"
	# Feet meet the far table edge; the interaction anchor remains compatible.
	merchant_root.position=SHOP_POSITION+Vector2(0,70)
	add_child(merchant_root)
	merchant_sprite=Sprite2D.new()
	merchant_sprite.name="PipAndChicken"
	merchant_sprite.texture=AnimalCast.icon("pip")
	merchant_sprite.centered=false
	merchant_sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	var factor := 144.0/MERCHANT_REGION.size.y
	merchant_sprite.scale=Vector2.ONE*factor
	merchant_sprite.position=Vector2(-MERCHANT_REGION.size.x*factor*0.5,-144)
	merchant_root.add_child(merchant_sprite)
	merchant_root.scale=Vector2.ONE*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	merchant_root.visible=false

func _process(delta: float) -> void:
	if not is_instance_valid(room) or room.state!="playing": return
	if _exit_visible and exit_reveal_age<EXIT_REVEAL_SECONDS:
		exit_reveal_age=minf(EXIT_REVEAL_SECONDS,exit_reveal_age+delta)
		queue_redraw()
	if _kind!="shop": return
	merchant_time+=delta
	# The feet stay at the same anchor. Only a barely visible breath passes
	# through the soft cape and the chicken held in Pip's arm.
	var reaction := gathering.reaction_for("pip") if is_instance_valid(gathering) else 0.0
	merchant_root.scale=Vector2(1+reaction*0.025,1+sin(merchant_time*2.2)*0.007-reaction*0.018)*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE)
	merchant_root.rotation=sin(merchant_time*7.0)*0.035*reaction
	if is_instance_valid(gathering):
		gathering.set_player_position(room.player.position)
		gathering.animate(delta)

func is_shop_near(point: Vector2) -> bool:
	point=WorldLayout.canonical(point)
	return _kind=="shop" and (point.distance_to(SHOP_POSITION)<120 or point.distance_to(ShopGathering.TABLE_POSITION)<165)

func merchant_snapshot() -> Dictionary:
	return {"id":MERCHANT_ID,"name":MERCHANT_NAME,"species":AnimalCast.species("pip"), "visible":is_instance_valid(merchant_root) and merchant_root.visible,
		"anchor":SHOP_POSITION,"feet":merchant_root.position if is_instance_valid(merchant_root) else Vector2.ZERO,
		"texture":merchant_sprite.texture if is_instance_valid(merchant_sprite) else null,"portrait_region":MERCHANT_PORTRAIT_REGION}

func update_visuals() -> void:
	if not is_instance_valid(room) or room.run==null:
		return
	var stage_index := int(room.run.stage_index)
	var sector_name := str(room.stage_def.get("name","The Candlewick Archives"))
	var kind := str(room.stage_def.get("kind","combat"))
	var exit_open := bool(room.exit_open)
	var exit_near := false
	var shop_near := false
	var exit_visible := exit_open and stage_index<7 and kind!="final"
	if is_instance_valid(room.player):
		var local_player := WorldLayout.canonical(room.player.position)
		exit_near=local_player.distance_to(EXIT_POSITION)<86
		shop_near=kind=="shop" and (local_player.distance_to(SHOP_POSITION)<120 or local_player.distance_to(ShopGathering.TABLE_POSITION)<165)
	var signature := GameLocale.text("%d|%s|%s|%s|%s|%s") % [stage_index,sector_name,kind,exit_open,exit_near,shop_near]
	signature+=GameLocale.current
	if signature==_signature:
		return
	_signature=signature
	if stage_index!=_stage_index or not exit_visible or not _exit_visible:
		exit_reveal_age=0.0
	_exit_visible=exit_visible
	_stage_index=stage_index
	_sector_name=sector_name
	_kind=kind
	_exit_open=exit_open
	_exit_near=exit_near
	_shop_near=shop_near
	if is_instance_valid(merchant_root): merchant_root.visible=_kind=="shop"
	if is_instance_valid(gathering): gathering.configure(stage_index,_kind=="shop")
	queue_redraw()

func exit_snapshot() -> Dictionary:
	return {"visible":_exit_visible,"progress":clampf(exit_reveal_age/EXIT_REVEAL_SECONDS,0,1),"stage":_stage_index,"unlocked":_exit_open}

func _draw() -> void:
	if _exit_visible: _draw_exit()
	if _kind=="shop":
		draw_set_transform(merchant_root.position+Vector2(0,4),0,Vector2(1,0.28))
		draw_circle(Vector2.ZERO,33*(WorldLayout.ACTOR_SCALE/WorldLayout.SCALE),Color(0.39,0.33,0.31,0.16))
		draw_set_transform(Vector2.ZERO)

func _draw_exit() -> void:
	var progress := clampf(exit_reveal_age/EXIT_REVEAL_SECONDS,0,1)
	var ease := 1.0-pow(1.0-progress,3)
	var glow := Color("e5c9ef")
	glow.a=(1.0-progress)*0.7
	if progress<1:
		draw_set_transform(EXIT_POSITION+Vector2(0,3),0,Vector2(1,0.3))
		draw_arc(Vector2.ZERO,38+progress*28,0,TAU,32,glow,3,true)
		draw_set_transform(Vector2.ZERO)
		for i in range(3):
			var at := EXIT_POSITION+Vector2.from_angle(-PI*0.85+i*PI*0.35)*Vector2(56,90)*(0.8+progress*0.4)+Vector2(0,-70)
			var radius := 3.5+sin(progress*PI)*2.5
			draw_line(at-Vector2(radius,0),at+Vector2(radius,0),glow,2,true)
			draw_line(at-Vector2(0,radius),at+Vector2(0,radius),glow,2,true)
	EnchantedArt.stamp(self,"portal",EXIT_POSITION+Vector2(0,-86+(1-ease)*8),Vector2(151,171),ease)
	

func _plate(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=Color("b6a092")
	style.set_border_width_all(1)
	style.set_corner_radius_all(10)
	return style
