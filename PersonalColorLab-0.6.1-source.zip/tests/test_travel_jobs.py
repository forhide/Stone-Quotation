"""Durable travel exports preserve originals and survive real checkpoints."""
import copy
import errno
import hashlib
import json
from pathlib import Path
import threading
import time
from types import SimpleNamespace

from PIL import Image
import pytest

from personal_color_lab.core import travel_jobs as jobs
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.travel_store import TravelDataError, TravelStore, utc_now


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@pytest.fixture
def project(tmp_path, monkeypatch):
    monkeypatch.setattr(jobs, '_runtime_identity', lambda *args: {
        'application': '0.6.0', 'engine': '0.5.6', 'semantic': None, 'scene': None, 'lens': None})
    folder = tmp_path / 'originals'; folder.mkdir()
    output = tmp_path / 'exports'; output.mkdir()
    db = tmp_path / 'library.db'
    with TravelStore(db) as store:
        identifier = store.create_project('Kyoto', folder)
    return SimpleNamespace(folder=folder, output=output, db=db, id=identifier)


def add(project, name='one.jpg', pick='keep'):
    source = project.folder / name
    source.parent.mkdir(parents=True, exist_ok=True)
    Image.new('RGB', (48, 32), (95, 110, 135)).save(source)
    info = source.stat()
    with TravelStore(project.db) as store:
        store.import_photos(project.id, [{'path': source, 'kind': 'jpg',
            'size_bytes': info.st_size, 'mtime_ns': info.st_mtime_ns}])
        photo = next(item for item in store.list_photos(project.id) if item['source_path'] == str(source))
        store.update_photo(photo['id'], pick=pick)
    return source, photo['id']


def enqueue(project, dna=None, **kwargs):
    return jobs.enqueue_exports(project.db, project.id, dna or identity_dna(), project.output,
                                recognition=False, lens_correction=False, **kwargs)


def tasks(project):
    with TravelStore(project.db) as store:
        return store.list_tasks(project.id)


def fake_renderer(monkeypatch, callback=None):
    calls = []
    def render(source, destination, dna, **kwargs):
        assert digest(source) == kwargs['expected_fingerprint']
        assert not Path(destination).exists()
        calls.append((str(source), copy.deepcopy(dna), kwargs))
        if callback is not None:
            callback(source, destination, kwargs)
        else:
            with Path(destination).open('xb') as stream:
                stream.write(b'completed-jpeg-' + digest(source).encode())
        return {'source_unchanged': True}
    monkeypatch.setattr(jobs, 'export_jpeg', render)
    return calls


def test_snapshot_reuse_choices_and_adjustments_are_immutable(project, monkeypatch):
    source, identifier = add(project)
    add(project, 'held.jpg', 'hold'); add(project, 'rejected.jpg', 'reject')
    before = digest(source)
    dna = identity_dna()
    with TravelStore(project.db) as store:
        store.update_photo(identifier, adjustments={'exposure_ev': .5, 'temperature': .2, 'strength': .4})
    first = enqueue(project, dna, strength=.8, output_size='2048')
    assert first['queued'] == first['pending'] == 1
    assert enqueue(project, dna, strength=.8, output_size='2048')['reused'] == 1
    dna['exposure_ev'] = 2.
    with TravelStore(project.db) as store:
        store.update_photo(identifier, adjustments={'exposure_ev': -1.})
    frozen = tasks(project)[0]['request']
    assert frozen['dna']['exposure_ev'] == 0
    assert frozen['adjustments']['exposure_ev'] == .5
    calls = fake_renderer(monkeypatch)
    summary = jobs.run_exports(project.db, project.id)
    assert summary['completed'] == 1 and not summary['failed']
    assert calls[0][2]['strength'] == pytest.approx(.32)
    assert calls[0][2]['photo_adjustments']['temperature'] == .2
    assert calls[0][2]['evidence_cache'] is True
    assert calls[0][2]['output_size'] == '2048'
    assert digest(source) == before
    assert not list(project.folder.glob('*.xmp'))
    assert enqueue(project, dna)['queued'] == 1
    assert len({row['destination'] for row in tasks(project)}) == 2


def test_completed_resume_never_renders_twice_and_progress_is_plain_data(project, monkeypatch):
    add(project); add(project, 'two.jpg')
    events = []
    enqueue(project, progress=events.append)
    calls = fake_renderer(monkeypatch)
    assert jobs.run_exports(project.db, project.id, progress=events.append)['completed'] == 2
    assert jobs.run_exports(project.db, project.id)['completed'] == 2
    assert len(calls) == 2
    assert events and all(isinstance(event, dict) and 'completed' in event and 'total' in event for event in events)
    assert not list(project.output.glob('.pcl-task-*'))


def test_ready_receipt_flush_supports_windows_write_handle_requirement(project, monkeypatch):
    import os
    add(project); enqueue(project)
    fake_renderer(monkeypatch)
    flushes=[]
    original_fsync=os.fsync
    def windows_flush(descriptor):
        # FlushFileBuffers rejects read-only handles on Windows. An empty
        # write reproduces that requirement without modifying stage bytes.
        os.write(descriptor,b'')
        flushes.append(descriptor)
        return original_fsync(descriptor)
    monkeypatch.setattr(os,'fsync',windows_flush)
    summary=jobs.run_exports(project.db,project.id)
    assert summary['completed']==1 and summary['failed']==0
    assert flushes
    row=tasks(project)[0]
    assert digest(row['destination'])==row['output_sha256']


def test_foreign_ids_are_rejected_before_partial_queue(project):
    add(project)
    with pytest.raises(TravelDataError):
        enqueue(project, photo_ids=[999999])
    assert tasks(project) == []


def test_failure_continues_other_photos_and_retry_preserves_request(project, monkeypatch):
    first, _ = add(project); second, _ = add(project, 'two.jpg')
    enqueue(project)
    first.write_bytes(b'changed-original')
    calls = fake_renderer(monkeypatch)
    summary = jobs.run_exports(project.db, project.id)
    assert summary['failed'] == summary['completed'] == 1
    assert len(calls) == 1 and calls[0][0] == str(second)
    failed = next(row for row in tasks(project) if row['status'] == 'failed')
    assert failed['error_code'] == 'source_changed'
    with TravelStore(project.db) as store:
        assert store.retry_failed(project.id) == 1
    assert tasks(project)[0]['request'] == failed['request']
    summary = jobs.run_exports(project.db, project.id)
    assert summary['failed'] == 1 and len(calls) == 1


def test_missing_source_is_a_per_file_failure(project, monkeypatch):
    source, _ = add(project); add(project, 'two.jpg')
    enqueue(project); source.unlink()
    calls = fake_renderer(monkeypatch)
    summary = jobs.run_exports(project.db, project.id)
    assert summary['failed'] == summary['completed'] == 1
    assert tasks(project)[0]['error_code'] == 'source_missing'
    assert len(calls) == 1


def test_preparation_skips_unavailable_source_and_continues(project, monkeypatch):
    missing, _ = add(project); add(project, 'two.jpg'); missing.unlink()
    events = []
    summary = enqueue(project, progress=events.append)
    assert summary['queued'] == summary['pending'] == summary['preparation_failed'] == 1
    assert any(event.get('error_code') == 'source_unavailable' for event in events)
    calls = fake_renderer(monkeypatch)
    assert jobs.run_exports(project.db, project.id)['completed'] == 1 and len(calls) == 1


def test_existing_and_concurrently_created_outputs_are_never_replaced(project, monkeypatch):
    add(project); enqueue(project)
    row = tasks(project)[0]; final = Path(row['destination'])
    final.write_bytes(b'foreign-output')
    calls = fake_renderer(monkeypatch)
    summary = jobs.run_exports(project.db, project.id)
    assert summary['failed'] == 1
    assert final.read_bytes() == b'foreign-output'
    assert tasks(project)[0]['error_code'] == 'output_exists'
    assert len(calls) == 1
    assert not list(project.output.glob('.pcl-task-*'))


class Crash(BaseException):
    pass


@pytest.mark.parametrize('after_publish', [False, True])
def test_crash_ready_receipt_resumes_without_rendering_again(project, monkeypatch, after_publish):
    source, _ = add(project); original_sha = digest(source)
    enqueue(project)
    calls = fake_renderer(monkeypatch)
    publish = jobs._publish_stage
    def crash(stage, destination, event):
        if after_publish:
            publish(stage, destination, event)
        raise Crash()
    monkeypatch.setattr(jobs, '_publish_stage', crash)
    with pytest.raises(Crash):
        jobs.run_exports(project.db, project.id)
    receipt = tasks(project)[0]
    assert receipt['status'] == 'ready' and receipt['output_sha256']
    assert Path(receipt['destination']).exists() is after_publish
    monkeypatch.setattr(jobs, '_publish_stage', publish)
    result = jobs.run_exports(project.db, project.id)
    assert result['completed'] == 1 and len(calls) == 1
    assert digest(source) == original_sha
    assert digest(receipt['destination']) == receipt['output_sha256']
    assert not list(project.output.glob('.pcl-task-*'))


def test_ready_receipt_refuses_changed_destination(project, monkeypatch):
    add(project); enqueue(project); fake_renderer(monkeypatch)
    publish = jobs._publish_stage
    def crash(stage, destination, event):
        publish(stage, destination, event)
        raise Crash()
    monkeypatch.setattr(jobs, '_publish_stage', crash)
    with pytest.raises(Crash):
        jobs.run_exports(project.db, project.id)
    final = Path(tasks(project)[0]['destination']); final.write_bytes(b'foreign-replacement')
    monkeypatch.setattr(jobs, '_publish_stage', publish)
    assert jobs.run_exports(project.db, project.id)['failed'] == 1
    assert final.read_bytes() == b'foreign-replacement'


def test_live_lease_reopening_is_busy_and_does_not_reset_running_task(project, monkeypatch):
    add(project); enqueue(project)
    entered = threading.Event(); release = threading.Event(); results = []
    def wait(source, destination, kwargs):
        entered.set(); assert release.wait(10)
        Path(destination).write_bytes(b'complete')
    calls = fake_renderer(monkeypatch, wait)
    worker = threading.Thread(target=lambda: results.append(jobs.run_exports(project.db, project.id)))
    worker.start()
    try:
        assert entered.wait(10)
        first = tasks(project)[0]
        assert first['status'] == 'running'
        second = jobs.run_exports(project.db, project.id)
        assert second['busy'] is True and second['running'] == 1
        assert tasks(project)[0]['owner_token'] == first['owner_token']
    finally:
        release.set(); worker.join(10)
    assert not worker.is_alive() and results[0]['completed'] == 1 and len(calls) == 1


def test_expired_worker_cannot_fail_new_owners_task(project, monkeypatch):
    add(project); enqueue(project); row = tasks(project)[0]
    newer_stage = project.output / f'.pcl-task-{row["id"]}-{row["request_key"][:20]}-{"b" * 32}.jpg'
    newer_stage.write_bytes(b'new-worker-in-progress')
    def lose_lease(source, destination, kwargs):
        with TravelStore(project.db) as store:
            with store.conn:
                store.conn.execute('UPDATE travel_leases SET token=?,expires_at=? WHERE project_id=?',
                                   ('new-owner', time.time() + 120, project.id))
                store.conn.execute('UPDATE travel_tasks SET owner_token=?,stage_path=? WHERE id=?',
                                   ('new-owner', str(newer_stage), row['id']))
        raise OSError('Old renderer failed after its lease expired')
    fake_renderer(monkeypatch, lose_lease)
    summary = jobs.run_exports(project.db, project.id)
    assert summary['cancelled'] and summary['running'] == 1 and summary['failed'] == 0
    current = tasks(project)[0]
    assert current['owner_token'] == 'new-owner' and current['status'] == 'running'
    assert newer_stage.read_bytes() == b'new-worker-in-progress'
    with TravelStore(project.db) as store:
        assert store.conn.execute('SELECT token FROM travel_leases WHERE project_id=?', (project.id,)).fetchone()[0] == 'new-owner'


def test_expired_lease_recovers_running_task_and_removes_only_owned_stage(project, monkeypatch):
    add(project); enqueue(project); row = tasks(project)[0]
    stage = project.output / f'.pcl-task-{row["id"]}-{row["request_key"][:20]}-{"a" * 32}.jpg'
    stage.write_bytes(b'incomplete')
    foreign = project.output / '.pcl-task-foreign.jpg'; foreign.write_bytes(b'keep')
    with TravelStore(project.db) as store:
        with store.conn:
            store.conn.execute("UPDATE travel_tasks SET status='running',owner_token='old',stage_path=? WHERE id=?", (str(stage), row['id']))
            store.conn.execute('INSERT INTO travel_leases VALUES(?,?,?,?)', (project.id, 'old', time.time() - 10, time.time() - 20))
    calls = fake_renderer(monkeypatch)
    assert jobs.run_exports(project.db, project.id)['completed'] == 1
    assert len(calls) == 1 and not stage.exists() and foreign.read_bytes() == b'keep'


def test_cancelled_render_checkpoints_without_partial_destination(project, monkeypatch):
    add(project); add(project, 'two.jpg'); enqueue(project)
    stop = threading.Event()
    def cancel(source, destination, kwargs):
        Path(destination).write_bytes(b'private-finished')
        stop.set()
    fake_renderer(monkeypatch, cancel)
    summary = jobs.run_exports(project.db, project.id, cancel_event=stop)
    assert summary['cancelled'] and summary['pending'] == 2
    assert not list(project.output.iterdir())
    stop.clear(); calls = fake_renderer(monkeypatch)
    assert jobs.run_exports(project.db, project.id, cancel_event=stop)['completed'] == 2
    assert len(calls) == 2


def test_legacy_valueerror_cancellation_checkpoints_current_photo(project, monkeypatch):
    add(project); enqueue(project); stop = threading.Event()
    def cancel(source, destination, kwargs):
        Path(destination).write_bytes(b'incomplete')
        stop.set()
        raise ValueError('Style operation cancelled.')
    fake_renderer(monkeypatch, cancel)
    result = jobs.run_exports(project.db, project.id, cancel_event=stop)
    assert result['cancelled'] and result['pending'] == 1 and result['failed'] == 0
    assert tasks(project)[0]['error_code'] is None and not list(project.output.iterdir())


def test_cancel_after_ready_receipt_reuses_finished_stage(project, monkeypatch):
    add(project); enqueue(project); stop = threading.Event()
    calls = fake_renderer(monkeypatch); publish = jobs._publish_stage
    def cancel_before_publish(stage, destination, event):
        stop.set(); jobs._check_cancel(event)
    monkeypatch.setattr(jobs, '_publish_stage', cancel_before_publish)
    result = jobs.run_exports(project.db, project.id, cancel_event=stop)
    assert result['cancelled'] and result['ready'] == 1 and not Path(tasks(project)[0]['destination']).exists()
    assert Path(tasks(project)[0]['stage_path']).exists()
    stop.clear(); monkeypatch.setattr(jobs, '_publish_stage', publish)
    assert jobs.run_exports(project.db, project.id, cancel_event=stop)['completed'] == 1
    assert len(calls) == 1


def test_stop_after_publication_commits_finished_photo_before_stopping(project, monkeypatch):
    add(project); add(project, 'two.jpg'); enqueue(project); fake_renderer(monkeypatch)
    stop = threading.Event(); publish = jobs._publish_stage
    def cancel_after(stage, destination, event):
        publish(stage, destination, event); stop.set()
    monkeypatch.setattr(jobs, '_publish_stage', cancel_after)
    result = jobs.run_exports(project.db, project.id, cancel_event=stop)
    assert result['cancelled'] and result['completed'] == result['pending'] == 1
    assert len(list(project.output.glob('*.jpg'))) == 1


def test_cancelled_preparation_and_execution_do_not_publish(project, monkeypatch):
    add(project); stop = threading.Event(); stop.set()
    assert enqueue(project, cancel_event=stop)['cancelled'] and not tasks(project)
    stop.clear(); enqueue(project); calls = fake_renderer(monkeypatch); stop.set()
    assert jobs.run_exports(project.db, project.id, cancel_event=stop)['cancelled']
    assert not calls and not list(project.output.iterdir())


def test_tampered_snapshot_is_rejected_without_rendering_or_file_changes(project, monkeypatch):
    source, _ = add(project); before = source.read_bytes(); enqueue(project)
    with TravelStore(project.db) as store:
        row = store.list_tasks(project.id)[0]; request = row['request']
        request['settings']['strength'] = .1
        with store.conn:
            store.conn.execute('UPDATE travel_tasks SET request_json=? WHERE id=?', (json.dumps(request), row['id']))
    calls = fake_renderer(monkeypatch)
    assert jobs.run_exports(project.db, project.id)['failed'] == 1
    assert tasks(project)[0]['error_code'] == 'invalid_request'
    assert not calls and source.read_bytes() == before and not list(project.output.iterdir())


def test_changed_local_runtime_requires_explicit_requeue(project, monkeypatch):
    add(project); enqueue(project); calls = fake_renderer(monkeypatch)
    monkeypatch.setattr(jobs, '_runtime_identity', lambda *args: {'application': 'new-runtime'})
    assert jobs.run_exports(project.db, project.id)['failed'] == 1
    assert tasks(project)[0]['error_code'] == 'runtime_changed' and not calls


def test_source_change_during_renderer_is_detected_before_publication(project, monkeypatch):
    source, _ = add(project); enqueue(project)
    def mutate(source, destination, kwargs):
        Path(destination).write_bytes(b'jpeg')
        Path(source).write_bytes(b'external-change')
    fake_renderer(monkeypatch, mutate)
    assert jobs.run_exports(project.db, project.id)['failed'] == 1
    assert tasks(project)[0]['error_code'] == 'source_changed'
    assert not list(project.output.iterdir()) and source.read_bytes() == b'external-change'


def test_fat_fallback_copies_finished_bytes_without_overwrite(tmp_path, monkeypatch):
    stage = tmp_path / '.stage.jpg'; stage.write_bytes(b'complete-jpeg')
    final = tmp_path / 'output.jpg'
    def unsupported(*args, **kwargs):
        raise OSError(errno.EOPNOTSUPP, 'No hardlinks')
    monkeypatch.setattr(jobs.os, 'link', unsupported)
    jobs._publish_stage(stage, final, None)
    assert final.read_bytes() == stage.read_bytes()
    with pytest.raises(FileExistsError):
        jobs._publish_stage(stage, final, None)
    assert final.read_bytes() == b'complete-jpeg'


def test_real_jpeg_export_is_offline_metadata_free_and_keeps_original(project):
    source, _ = add(project); before = source.read_bytes()
    enqueue(project, output_size='2048')
    summary = jobs.run_exports(project.db, project.id)
    assert summary['completed'] == 1 and summary['failed'] == 0
    with Image.open(tasks(project)[0]['destination']) as image:
        assert image.format == 'JPEG' and image.size == (48, 32)
        assert image.info.get('icc_profile') and not image.getexif()
    assert source.read_bytes() == before
