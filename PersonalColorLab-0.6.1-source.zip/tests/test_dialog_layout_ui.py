"""Long translated dialog content must remain readable at laptop sizes."""
import pytest

from personal_color_lab.ui.lens_dialog import LensSelectionDialog
from personal_color_lab.ui.scene_editor import SceneEditor
from test_source_workflow_ui import desktop, pytestmark


@pytest.mark.parametrize('desktop', [1, 1.5, 2], indirect=True)
@pytest.mark.parametrize('language', ['en', 'ko'])
def test_scene_and_equipment_dialog_text_reflows_inside_the_minimum_width(desktop, language):
    app, _ = desktop
    app.lang.set(language); app.change_language(); app.update()
    filename = 'Autumn holiday collection — ' + 'long-photo-name-' * 12 + '.ARW'
    dialogs = [
        SceneEditor(app, filename, None, None, lambda value: None),
        LensSelectionDialog(app, {}, None, lambda value: None),
    ]
    try:
        for dialog in dialogs:
            width, height = dialog.minsize()
            dialog.geometry(f'{width}x{max(height, dialog.winfo_reqheight())}')
            app.update()
            narrow = [int(label.cget('wraplength')) for label in dialog._wrapped_labels]
            for label in dialog._wrapped_labels:
                assert label.winfo_ismapped()
                assert int(label.cget('wraplength')) <= label.winfo_width()
                assert label.winfo_rootx() >= dialog.winfo_rootx()
                assert label.winfo_rootx() + label.winfo_width() <= dialog.winfo_rootx() + dialog.winfo_width()
            assert dialog.apply_button.winfo_rooty() + dialog.apply_button.winfo_height() <= dialog.winfo_rooty() + dialog.winfo_height()
            dialog.geometry(f'{width + round(width * .25)}x{dialog.winfo_height()}')
            app.update()
            assert all(int(label.cget('wraplength')) > old for label, old in zip(dialog._wrapped_labels, narrow))
    finally:
        for dialog in dialogs:
            dialog.close()
            assert not dialog._wrapped_labels
