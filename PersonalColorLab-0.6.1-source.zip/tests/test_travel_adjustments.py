"""Photographic temporary corrections remain independent of learned Style DNA."""
import copy
import threading

import cv2
import numpy as np
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.travel_adjustments import (DEFAULT_ADJUSTMENTS, apply_photo_adjustments,
    effective_strength, validate_adjustments)


def pixels():
    y, x = np.indices((127, 259))
    gray = np.clip(40 + x * .45 + y * .13, 0, 255).astype(np.uint8)
    return np.stack((gray, np.clip(gray.astype(int) + 5, 0, 255).astype(np.uint8), gray), axis=2)


def test_neutral_and_strength_only_are_exact_and_do_not_alias_input():
    source = pixels(); before = source.copy()
    for options in (None, {}, {'strength': 0}, {'exposure_ev': 0, 'temperature': 0, 'tint': 0}):
        result = apply_photo_adjustments(source, options)
        assert np.array_equal(result, before) and result is not source
        result[:] = 0
        assert np.array_equal(source, before)


def test_exposure_matches_an_independent_linear_srgb_equation():
    source = pixels()
    rgb = source.astype(float) / 255
    linear = np.where(rgb <= .04045, rgb / 12.92, ((rgb + .055) / 1.055) ** 2.4) * 2
    reference = np.where(linear <= .0031308, linear * 12.92, 1.055 * np.maximum(linear, 0) ** (1 / 2.4) - .055)
    expected = np.rint(np.clip(reference, 0, 1) * 255).astype(np.uint8)
    result = apply_photo_adjustments(source, {'exposure_ev': 1})
    assert np.max(abs(result.astype(int) - expected.astype(int))) <= 1
    assert result.mean() > source.mean()


def test_warmth_tint_have_their_stated_relative_color_directions():
    source = np.full((71, 83, 3), 130, np.uint8)
    def center(settings):
        return cv2.cvtColor(apply_photo_adjustments(source, settings).astype(np.float32) / 255, cv2.COLOR_RGB2LAB).mean(axis=(0, 1))
    neutral = center({})
    assert center({'temperature': .7})[2] > neutral[2] + 4
    assert center({'temperature': -.7})[2] < neutral[2] - 4
    assert center({'tint': .7})[1] > neutral[1] + 4


def test_temporary_corrections_do_not_mutate_settings_or_style_metadata():
    from personal_color_lab.core.style_dna import identity_dna
    style = identity_dna(); before = copy.deepcopy(style)
    settings = {'temperature': .5, 'tint': -.2}; original = dict(settings)
    apply_photo_adjustments(pixels(), settings)
    assert settings == original and style == before
    assert validate_adjustments(settings) == {**DEFAULT_ADJUSTMENTS, **settings}


def test_per_photo_strength_multiplies_look_without_disabling_explicit_exposure():
    assert effective_strength(.7, {'strength': .4}) == pytest.approx(.28)
    source = pixels()
    assert apply_photo_adjustments(source, {'exposure_ev': .5, 'strength': 0}).mean() > source.mean()


def test_native_color_work_is_tile_bounded_and_output_is_tile_independent(monkeypatch):
    from personal_color_lab.core import travel_adjustments as module
    source = np.tile(pixels(), (7, 6, 1)); settings = {'exposure_ev': -.3, 'temperature': .6, 'tint': -.4}
    original = module.cv2.cvtColor; sizes = []
    def bounded(array, *args, **kwargs):
        sizes.append(array.shape[0] * array.shape[1]); return original(array, *args, **kwargs)
    monkeypatch.setattr(module.cv2, 'cvtColor', bounded)
    result = apply_photo_adjustments(source, settings)
    assert sizes and max(sizes) <= module._MAX_TILE_PIXELS
    monkeypatch.setattr(module, '_MAX_TILE_PIXELS', 10_000_000)
    reference = apply_photo_adjustments(source, settings)
    assert np.array_equal(result, reference)


@pytest.mark.parametrize('options', [{'exposure_ev': 4}, {'temperature': True}, {'tint': float('nan')},
    {'strength': -1}, {'gps': 37}, {'style_path': '/private'}])
def test_untrusted_adjustments_are_rejected(options):
    with pytest.raises(ValueError): validate_adjustments(options)


def test_precancel_prevents_neutral_work():
    event = threading.Event(); event.set()
    with pytest.raises(AnalysisCancelledError): apply_photo_adjustments(pixels(), cancel_event=event)
