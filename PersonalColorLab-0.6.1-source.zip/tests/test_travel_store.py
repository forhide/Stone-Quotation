"""Travel state is local, additive and independent of original photo bytes."""
import copy
import hashlib
import json
from pathlib import Path
import sqlite3

import pytest

from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.schema_migrations import SchemaMigrationError
from personal_color_lab.core.travel_store import (
    DEFAULT_ADJUSTMENTS, TravelDataError, TravelStore, utc_now,
)


def source(folder, name='photo.jpg'):
    path = folder / name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(b'unchanged-original-' + name.encode())
    stat = path.stat()
    return {'path':path, 'relative_path':path.relative_to(folder).as_posix(),
            'kind':'raw' if path.suffix=='.arw' else 'jpg',
            'size_bytes':stat.st_size, 'mtime_ns':stat.st_mtime_ns,
            'capture_time':'2026:10:20 08:30:00', 'width':640, 'height':480}


def _v3_library(path):
    with LibraryDB(path):
        pass
    conn=sqlite3.connect(path)
    for table in ('travel_tasks','travel_leases','travel_photos','travel_projects'):
        conn.execute('DROP TABLE '+table)
    conn.execute('PRAGMA user_version=3')
    conn.execute("INSERT INTO photos(path,ext,kind,size_bytes) VALUES('legacy.jpg','.jpg','jpg',123)")
    conn.execute("INSERT INTO styles(style_name,source_type,global_dna_json) VALUES('Keep me','legacy','untouched')")
    conn.commit()
    return conn


def test_version3_upgrade_is_additive_and_preserves_every_existing_row(tmp_path):
    path=tmp_path/'library.db';conn=_v3_library(path)
    tables=('photos','styles','source_profiles','style_presets','analysis_cache')
    before={name:conn.execute('SELECT * FROM '+name).fetchall() for name in tables}
    conn.close()
    with TravelStore(path) as store:
        assert store.conn.execute('PRAGMA user_version').fetchone()[0]==4
        assert store.conn.execute('PRAGMA foreign_keys').fetchone()[0]==1
        assert store.list_projects()==[]
        assert {name:[tuple(row) for row in store.conn.execute('SELECT * FROM '+name)] for name in tables}==before
    with LibraryDB(path) as library:
        assert library.conn.execute('SELECT global_dna_json FROM styles').fetchone()[0]=='untouched'


def test_schema_failure_rolls_back_all_new_ddl_and_preserves_version3(tmp_path):
    path=tmp_path/'library.db';conn=_v3_library(path)
    conn.execute('CREATE TABLE travel_photos(sentinel TEXT)')
    conn.execute("INSERT INTO travel_photos VALUES('preserve')")
    conn.commit();conn.close()
    with pytest.raises(SchemaMigrationError):
        TravelStore(path)
    conn=sqlite3.connect(path)
    try:
        assert conn.execute('PRAGMA user_version').fetchone()[0]==3
        assert conn.execute('SELECT * FROM travel_photos').fetchall()==[('preserve',)]
        assert conn.execute("SELECT count(*) FROM sqlite_master WHERE name='travel_projects'").fetchone()[0]==0
        assert conn.execute('SELECT global_dna_json FROM styles').fetchone()[0]=='untouched'
    finally:conn.close()


def test_unicode_project_choices_settings_and_photo_edits_survive_restart(tmp_path):
    folder=tmp_path/'가을 여행';folder.mkdir()
    first=source(folder,'둘째 날/인물.arw');second=source(folder,'야경.jpg')
    hashes={row['path']:hashlib.sha256(row['path'].read_bytes()).hexdigest() for row in (first,second)}
    database=tmp_path/'local/library.db'
    with TravelStore(database) as store:
        identifier=store.create_project('  교토의 색감  ',folder,False)
        counts=store.import_photos(identifier,[first,second])
        assert counts=={'added':2,'updated':0,'unchanged':0,'total':2,'imported':2}
        photo=store.list_photos(identifier)[0]
        assert photo['adjustments']==DEFAULT_ADJUSTMENTS and photo['scene_override'] is None
        store.update_photo(photo['id'],pick='hold',adjustments={'temperature':.2,'exposure_ev':-.7},
                           scene_override=['night','portrait'],group_id='night-1')
        store.configure_project(identifier,{'strength':.45,'style_key':'saved:3','output_size':'2048'})
        assert store.get_project(identifier)['counts']=={'total':2,'keep':1,'hold':1,'reject':0}
    with TravelStore(database) as store:
        project=store.get_project(identifier)
        assert project['name']=='교토의 색감' and project['recursive'] is False
        assert project['settings']['strength']==.45 and project['settings']['style_key']=='saved:3'
        photo=store.get_photo(photo['id'])
        assert photo['pick']=='hold' and photo['adjustments']['temperature']==.2
        assert photo['scene_override']==['night','portrait'] and photo['group_id']=='night-1'
        assert store.list_projects()[0]['photo_count']==2
    assert all(hashlib.sha256(path.read_bytes()).hexdigest()==value for path,value in hashes.items())


def test_rescan_updates_file_metadata_without_resetting_user_edits(tmp_path):
    folder=tmp_path/'photos';folder.mkdir();row=source(folder)
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);store.import_photos(project,[row])
        photo=store.list_photos(project)[0]
        store.update_photo(photo['id'],pick='reject',adjustments={'strength':.3},scene_override=[])
        assert store.import_photos(project,[row])['unchanged']==1
        row=dict(row,mtime_ns=row['mtime_ns']+1,size_bytes=row['size_bytes']+2)
        assert store.import_photos(project,[row])['updated']==1
        actual=store.get_photo(photo['id'])
        assert actual['pick']=='reject' and actual['adjustments']['strength']==.3
        assert actual['scene_override']==[] and actual['size_bytes']==row['size_bytes']
        assert len(store.list_photos(project))==1


def test_invalid_import_rolls_back_whole_batch_and_retains_existing_choices(tmp_path):
    folder=tmp_path/'photos';folder.mkdir();good=source(folder);bad=source(folder,'second.jpg')
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder)
        with pytest.raises(TravelDataError):store.import_photos(project,[good,dict(bad,size_bytes=-1)])
        assert store.list_photos(project)==[]
        store.import_photos(project,[good])
        with pytest.raises(TravelDataError):store.import_photos(project,[good,good])
        assert len(store.list_photos(project))==1


@pytest.mark.parametrize('change',[
    {'relative_path':'../outside.jpg'}, {'kind':'xmp'}, {'mtime_ns':True}, {'size_bytes':float('nan')},
    {'width':0}, {'height':True}, {'GPSLatitude':37.5}, {'raw_exif':{'camera':'private'}},
    {'raw_xml':'<rdf:RDF />'},
])
def test_private_unsafe_or_nonfinite_photo_metadata_is_not_imported(tmp_path,change):
    folder=tmp_path/'photos';folder.mkdir();row=source(folder)
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder)
        with pytest.raises(ValueError):store.import_photos(project,[dict(row,**change)])
        assert store.list_photos(project)==[]


def test_symlink_outside_trip_folder_cannot_be_imported_with_fake_relative_path(tmp_path):
    folder=tmp_path/'photos';folder.mkdir();outside=tmp_path/'outside.jpg';outside.write_bytes(b'original')
    link=folder/'inside.jpg';link.symlink_to(outside)
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder)
        with pytest.raises(TravelDataError):
            store.import_photos(project,[{'path':link,'relative_path':'inside.jpg','size_bytes':8,'mtime_ns':1}])
        assert outside.read_bytes()==b'original'


@pytest.mark.parametrize('updates',[
    {'exposure_ev':3.1}, {'temperature':-1.1}, {'tint':float('inf')}, {'strength':True},
    {'GPSLatitude':12}, {'unknown':.2},
])
def test_invalid_photo_adjustments_do_not_replace_previous_edits(tmp_path,updates):
    folder=tmp_path/'photos';folder.mkdir()
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);store.import_photos(project,[source(folder)])
        photo=store.list_photos(project)[0];before=copy.deepcopy(photo)
        with pytest.raises(ValueError):store.update_photo(photo['id'],adjustments=updates)
        assert store.get_photo(photo['id'])==before


@pytest.mark.parametrize('updates',[
    {'strength':float('nan')}, {'recognition':1}, {'output_size':'unsafe'}, {'GPSLatitude':1},
    {'metadata':{'longitude':4}}, {'output_folder':'\x00'}, {'style_key':''},
    {'filter':[]},
])
def test_invalid_settings_do_not_change_project(tmp_path,updates):
    folder=tmp_path/'photos';folder.mkdir()
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);before=store.get_project(project)
        with pytest.raises(ValueError):store.configure_project(project,updates)
        assert store.get_project(project)==before


def test_scene_reset_distinguishes_automatic_and_explicit_common_style(tmp_path):
    folder=tmp_path/'photos';folder.mkdir()
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);store.import_photos(project,[source(folder)])
        photo=store.list_photos(project)[0]
        assert store.update_photo(photo['id'],scene_override=[])['scene_override']==[]
        assert store.update_photo(photo['id'],scene_override=None)['scene_override'] is None
        with pytest.raises(ValueError):store.update_photo(photo['id'],scene_override=['day','night'])


def test_task_receipts_and_failed_retry_preserve_immutable_request(tmp_path):
    folder=tmp_path/'photos';folder.mkdir()
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);store.import_photos(project,[source(folder)])
        photo=store.list_photos(project)[0];now=utc_now()
        request={'schema_version':1,'source_path':photo['source_path'],'strength':.7}
        store.conn.execute('''INSERT INTO travel_tasks(project_id,photo_id,status,request_key,request_json,
            destination,stage_path,source_sha256,output_sha256,error_code,attempts,created_at_utc,updated_at_utc)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
            (project,photo['id'],'failed','task-1',json.dumps(request),'/output/a.jpg','/output/.owned-stage',
             'a'*64,'b'*64,'disk_full',2,now,now));store.conn.commit()
        assert store.retry_failed(project)==1
        task=store.list_tasks(project)[0]
        assert task['status']=='pending' and task['error_code'] is None
        assert task['request']==request and task['attempts']==2 and task['output_sha256']=='b'*64
        assert store.retry_failed(project)==0
        assert store.conn.execute('SELECT count(*) FROM travel_tasks').fetchone()[0]==1


def test_corrupt_or_private_stored_json_is_rejected_without_silent_defaults(tmp_path):
    folder=tmp_path/'photos';folder.mkdir()
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);store.import_photos(project,[source(folder)])
        photo=store.list_photos(project)[0]
        store.conn.execute('UPDATE travel_photos SET adjustments_json=? WHERE id=?',
                           ('{"GPSLatitude":37}',photo['id']));store.conn.commit()
        with pytest.raises(TravelDataError):store.get_photo(photo['id'])
        store.conn.execute('UPDATE travel_projects SET settings_json=? WHERE id=?',('{broken',project));store.conn.commit()
        with pytest.raises(TravelDataError):store.get_project(project)


def test_foreign_key_constraints_prevent_orphan_job_records(tmp_path):
    with TravelStore(tmp_path/'library.db') as store:
        with pytest.raises(sqlite3.IntegrityError):
            store.conn.execute('''INSERT INTO travel_leases(project_id,token,expires_at,heartbeat)
                VALUES(999,'worker',100,90)''')
        store.conn.rollback()


def test_malformed_choices_metadata_and_ids_fail_with_validation_errors(tmp_path):
    folder=tmp_path/'photos';folder.mkdir();row=source(folder)
    with TravelStore(tmp_path/'library.db') as store:
        project=store.create_project('Trip',folder);store.import_photos(project,[row])
        photo=store.list_photos(project)[0]
        with pytest.raises(TravelDataError):store.update_photo(photo['id'],pick=[])
        with pytest.raises(TravelDataError):store.update_photo(photo['id'],adjustments={'strength':10**1000})
        with pytest.raises(TravelDataError):store.import_photos(project,[{**row,1:'bad key'}])
        with pytest.raises(TravelDataError):store.get_project(2**63)
        assert store.get_photo(photo['id'])['pick']=='keep'
