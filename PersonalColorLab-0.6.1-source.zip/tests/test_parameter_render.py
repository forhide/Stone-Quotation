"""Learned photographic controls reach previews, copies, regions and sidecars.

These tests use real XMP parsing and generated structured RGB/RAW inputs. They
check observable behavior and source contracts, not Adobe pixel equivalence.
"""
import copy
import hashlib
from io import BytesIO
import json
import socket
import subprocess
import sys
import threading
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageCms
import pytest

from personal_color_lab.core import spatial_render, style_render
from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core.detail_recipe import neutral_detail_profile
from personal_color_lab.core.scene_analysis import REGIONS
from personal_color_lab.core.style_dna import blend_styles, dna_from_batch, validate_dna
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.xmp_analysis import analyze_raw_xmp

LUMA = np.array([.2126, .7152, .0722], np.float32)
CRS = '{http://ns.adobe.com/camera-raw-settings/1.0/}'


@pytest.fixture(autouse=True)
def denied_network(monkeypatch):
    def denied(*args, **kwargs):
        pytest.fail('Parameter processing attempted a network call.')
    monkeypatch.setattr(socket, 'socket', denied)
    monkeypatch.setattr(socket, 'create_connection', denied)


@pytest.fixture(scope='module')
def raw_source(tmp_path_factory):
    return write_test_dng(tmp_path_factory.mktemp('parameter-raw') / 'source.dng',
                          width=640, height=480)


@pytest.fixture
def pixels():
    y, x = np.mgrid[:480, :640]
    light = (.48 + .10 * np.sin(x / 31) + .075 * np.sin(y / 23)
             + .06 * np.sin((x + y) / 5.5) + .045 * np.sin(x / .8))
    rgb = np.stack([light + .07 * np.sin(y / 71),
                    light - .04 * np.sin(x / 73),
                    light + .05 * np.cos((x + y) / 47)], axis=2)
    rgb[330:470, 15:235] = .49 + np.random.default_rng(31).normal(0, .025, (140, 220, 3))
    return np.rint(np.clip(rgb, .08, .92) * 255).astype('uint8')


def learned(tmp_path, raw, parameters, name='Recorded controls'):
    path = tmp_path / (name + '.xmp')
    attrs = ' '.join(f'crs:{key}="{value}"' for key, value in parameters.items())
    path.write_text('<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
                    'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" ' + attrs + '/>')
    payload = analyze_raw_xmp(raw, path)
    assert payload['status'] == 'ok' and payload['parameters'] == parameters
    return dna_from_batch({'mode': 'raw_xmp', 'results': [{'status': 'ok', 'payload': payload}]}, name)


def luma(pixels):
    return pixels.astype(np.float32) / 255 @ LUMA


def band_energy(pixels, low, high):
    y = luma(pixels)
    a = cv2.GaussianBlur(y, (0, 0), low * 640 / 1024, borderType=cv2.BORDER_REFLECT_101)
    b = cv2.GaussianBlur(y, (0, 0), high * 640 / 1024, borderType=cv2.BORDER_REFLECT_101)
    return float(np.sqrt(np.mean((a[30:300, 30:610] - b[30:300, 30:610]) ** 2)))


@pytest.mark.parametrize('adobe,amount,control,low,high', [
    ('Clarity2012', 65, 'clarity', 3, 12),
    ('Clarity2012', -65, 'clarity', 3, 12),
    ('Texture', 65, 'texture', 1, 3),
    ('Texture', -65, 'texture', 1, 3),
])
def test_recorded_clarity_and_texture_change_their_measured_spatial_bands(
        tmp_path, raw_source, pixels, adobe, amount, control, low, high):
    before = pixels.copy()
    dna = learned(tmp_path, raw_source, {adobe: amount})
    rendered = style_render.apply_pixels(pixels, style_render.prepare_style(pixels, dna)[0])[0]
    source_energy, output_energy = (band_energy(image, low, high) for image in (pixels, rendered))
    assert (output_energy > source_energy * 1.03 if amount > 0 else output_energy < source_energy * .97)
    assert dna['detail_profile']['support'][control]['basis'] == 'recorded'
    assert np.array_equal(pixels, before)


def test_recorded_sharpening_increases_native_edge_energy_without_modifying_input(tmp_path, raw_source, pixels):
    before = pixels.copy()
    dna = learned(tmp_path, raw_source, {'Sharpness': 110, 'SharpenRadius': 1.2})
    rendered = style_render.apply_pixels(pixels, style_render.prepare_style(pixels, dna)[0])[0]
    area = np.s_[30:300, 30:610]
    original_highpass = luma(pixels) - cv2.GaussianBlur(luma(pixels), (0, 0), .75)
    styled_highpass = luma(rendered) - cv2.GaussianBlur(luma(rendered), (0, 0), .75)
    assert np.std(styled_highpass[area]) > np.std(original_highpass[area]) * 1.03
    assert np.array_equal(pixels, before)


@pytest.mark.parametrize('adobe,chroma', [('LuminanceSmoothing', False), ('ColorNoiseReduction', True)])
def test_recorded_noise_reduction_reduces_flat_patch_noise(tmp_path, raw_source, pixels, adobe, chroma):
    dna = learned(tmp_path, raw_source, {adobe: 100})
    rendered = style_render.apply_pixels(pixels, style_render.prepare_style(pixels, dna)[0])[0]
    area = np.s_[350:450, 35:215]
    if chroma:
        first, second = (cv2.cvtColor(image.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)[area][:, :, 1:]
                         for image in (pixels, rendered))
    else:
        first, second = luma(pixels)[area], luma(rendered)[area]
    assert np.std(second) < np.std(first) * .98


@pytest.mark.parametrize('adobe,amount', [('Contrast2012', 65), ('Saturation', -45), ('Vibrance', 55)])
def test_color_controls_have_visible_independent_effects(tmp_path, raw_source, pixels, adobe, amount):
    dna = learned(tmp_path, raw_source, {adobe: amount})
    rendered = style_render.apply_pixels(pixels, style_render.prepare_style(pixels, dna)[0])[0]
    assert np.mean(abs(rendered.astype(float) - pixels.astype(float))) > 1
    if adobe == 'Contrast2012':
        assert np.std(luma(rendered)) > np.std(luma(pixels))
    else:
        original_saturation, changed_saturation = (
            cv2.cvtColor(image.astype(np.float32) / 255, cv2.COLOR_RGB2HSV)[:, :, 1].mean()
            for image in (pixels, rendered))
        assert changed_saturation < original_saturation if amount < 0 else changed_saturation > original_saturation


def test_preview_and_full_jpeg_apply_the_same_learned_spatial_controls(tmp_path, raw_source, pixels):
    dna = learned(tmp_path, raw_source, {'Clarity2012': 42, 'Texture': -28,
                                        'Sharpness': 66, 'LuminanceSmoothing': 29,
                                        'ColorNoiseReduction': 34, 'Saturation': -12})
    source = tmp_path / 'source.jpg'
    Image.fromarray(pixels).save(source, quality=100, subsampling=0)
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    preview = style_render.render_preview(source, dna, scene_override=[])
    output = tmp_path / 'copy.jpg'
    exported = style_render.export_jpeg(source, output, dna,
                                         expected_fingerprint=preview['source_fingerprint'], scene_override=[])
    stream = BytesIO()
    icc = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    Image.fromarray(preview['rendered']).save(stream, format='JPEG', quality=95, subsampling=0, icc_profile=icc)
    with Image.open(output) as image, Image.open(BytesIO(stream.getvalue())) as expected:
        assert np.array_equal(np.array(image), np.array(expected))
        assert image.info['icc_profile'] and not image.getexif()
    assert exported['parameter_support'] == preview['parameter_support']
    assert {'Clarity2012', 'Texture', 'Sharpness', 'LuminanceSmoothing', 'ColorNoiseReduction'} <= set(preview['parameter_support']['pixel_applied'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == source_hash


def test_recorded_dehaze_is_explicitly_xmp_only_and_does_not_claim_pixel_rendering(tmp_path, raw_source, pixels):
    dna = learned(tmp_path, raw_source, {'Dehaze': 31, 'ParametricDarks': -16})
    effective = style_render.prepare_style(pixels, dna)[0]
    assert np.array_equal(style_render.apply_pixels(pixels, effective)[0], pixels)
    support = spatial_render.parameter_support(effective)
    assert support['pixel_applied'] == [] and support['xmp_only'] == ['Dehaze', 'ParametricDarks']
    output = tmp_path / 'preset.xmp'
    style_render.export_xmp(output, dna, effective)
    attrs = {key[len(CRS):]: value for node in ET.fromstring(output.read_bytes()).iter()
             for key, value in node.attrib.items() if key.startswith(CRS)}
    assert attrs['Dehaze'] == '31' and attrs['ParametricDarks'] == '-16'


def test_detail_sidecar_strength_scales_amounts_and_retains_shape_selectors(tmp_path, raw_source, pixels):
    parameters = {'Clarity2012': 40, 'Texture': -30, 'Sharpness': 60, 'SharpenRadius': 1.7,
                  'SharpenEdgeMasking': 38, 'LuminanceSmoothing': 20, 'ColorNoiseReduction': 40}
    dna = learned(tmp_path, raw_source, parameters)
    effective = style_render.prepare_style(pixels, dna)[0]
    output = tmp_path / 'preset.xmp'
    style_render.export_xmp(output, dna, effective, .5)
    attrs = {key[len(CRS):]: value for node in ET.fromstring(output.read_bytes()).iter()
             for key, value in node.attrib.items() if key.startswith(CRS)}
    for name, value in parameters.items():
        expected = value if name in {'SharpenRadius', 'SharpenEdgeMasking'} else value * .5
        assert float(attrs[name]) == expected
    assert 'GPS' not in output.read_text() and 'Crop' not in output.read_text()


def test_hybrid_mixes_detail_controls_before_one_spatial_render(tmp_path, raw_source, pixels):
    clarity = learned(tmp_path, raw_source, {'Clarity2012': 60}, 'Clarity')
    texture = learned(tmp_path, raw_source, {'Texture': -40}, 'Texture')
    mixed = blend_styles([clarity, texture], [.25, .75])
    effective = style_render.prepare_style(pixels, mixed)[0]
    assert effective['detail_profile']['controls']['clarity'] == pytest.approx(.15)
    assert effective['detail_profile']['controls']['texture'] == pytest.approx(-.3)
    assert effective['recorded_parameters'] == {}
    expected = spatial_render.apply_details(pixels, effective['detail_profile'])
    assert np.array_equal(style_render.apply_pixels(pixels, effective)[0], expected)
    endpoint = blend_styles([clarity, texture], [1, 0])
    assert np.array_equal(style_render.apply_pixels(pixels, style_render.prepare_style(pixels, endpoint)[0])[0],
                          style_render.apply_pixels(pixels, style_render.prepare_style(pixels, clarity)[0])[0])


@pytest.mark.parametrize('with_recipe', [False, True])
def test_regional_color_rendering_applies_details_once_after_region_mixing(
        tmp_path, raw_source, pixels, monkeypatch, with_recipe):
    dna = learned(tmp_path, raw_source, {'Clarity2012': 60, 'Texture': 40})
    masks = {region: np.zeros(pixels.shape[:2], np.float32) for region in REGIONS}
    masks['food'][20:300, 20:320] = 1
    scene = {'report': {'bundle_id': 'a' * 64, 'scene_tags': ['food']}, 'masks': masks}
    if with_recipe:
        dna['semantic_profile'] = {'bundle_id': 'a' * 64, 'contexts': {}, 'regions': {'food': {
            'sample_count': 3, 'evidence': 'observed_transform', 'target': None,
            'tone_curve': np.linspace(0, 1, 33).tolist(), 'saturation_scale': .75, 'lab_shift': [1., 2.]}}}
    effective = style_render.prepare_style(pixels, dna)[0]
    color_only = copy.deepcopy(effective)
    color_only['detail_profile'] = neutral_detail_profile()
    base = style_render._render_regions(pixels, color_only, dna, 1, scene, .7, False, None)
    expected = spatial_render.apply_details(base, effective['detail_profile'])
    original = spatial_render.apply_details
    calls = []
    def counted(*args, **kwargs):
        calls.append(1)
        return original(*args, **kwargs)
    monkeypatch.setattr(spatial_render, 'apply_details', counted)
    output = style_render._render_regions(pixels, effective, dna, 1, scene, .7, False, None)
    assert calls == [1] and np.array_equal(output, expected)
    if with_recipe:
        assert not np.array_equal(base, pixels)


def test_zero_strength_and_cancelled_export_preserve_sources(tmp_path, raw_source, pixels):
    dna = learned(tmp_path, raw_source, {'Clarity2012': 60, 'Texture': 40, 'Sharpness': 90})
    source = tmp_path / 'source.jpg'
    Image.fromarray(pixels).save(source, quality=100, subsampling=0)
    before = source.read_bytes()
    preview = style_render.render_preview(source, dna, 0, scene_override=[])
    assert np.array_equal(preview['original'], preview['rendered'])
    stop = threading.Event(); stop.set()
    output = tmp_path / 'cancelled.jpg'
    with pytest.raises(ValueError, match='cancelled'):
        style_render.export_jpeg(source, output, dna, cancel_event=stop)
    assert not output.exists() and source.read_bytes() == before


@pytest.fixture(scope='module')
def parameter_diagnostic(tmp_path_factory):
    tmp_path = tmp_path_factory.mktemp('parameter-diagnostic')
    root = Path(__file__).resolve().parents[1]
    report = tmp_path / 'parameters.json'
    result = subprocess.run([sys.executable, '-W', 'error', '-B', str(root / 'tools' / 'verify_photo_parameters.py'),
                             '--report', str(report)], cwd=root, text=True, capture_output=True, timeout=90)
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(report.read_text())
    assert payload['ok'] and payload['app_version'] == APP_VERSION
    return payload


def test_standalone_generated_parameter_diagnostic_executes_all_routes_offline(parameter_diagnostic):
    payload = parameter_diagnostic
    assert payload['runtime_network'] == 'denied' and len(payload['checks']) >= 21
    names = {item['check'] for item in payload['checks']}
    assert {'raw_jpg_learns_observed_local_contrast_and_texture',
            'raw_jpg_separates_contrast_saturation_vibrance_and_local_contrast',
            'jpg_only_learns_final_detail_appearance',
            'supported_pixels_and_recorded_xmp_only_are_explicit'} <= names


def test_actual_raw_pair_pure_spatial_recipes_improve_combined_match(parameter_diagnostic):
    by_name = {item['check']: item for item in parameter_diagnostic['checks']}
    for name in ('raw_jpg_learns_observed_local_contrast_and_texture',
                 'raw_jpg_hue_preserving_spatial_recipe_improves_controlled_match'):
        item = by_name[name]
        assert item['raw_decodes_during_analysis'] == 1
        assert item['rgb_error_after'] < item['rgb_error_before']
        assert item['rgb_error_after'] < item['isolated_color_component_error']
        assert item['global_tone_transfer_separately_recorded']
        assert item['controls']['sharpening']['estimate'] is None


def test_actual_raw_pair_global_contrast_survives_spatial_decomposition(parameter_diagnostic):
    by_name = {item['check']: item for item in parameter_diagnostic['checks']}
    for name in ('raw_jpg_global_contrast_is_retained_without_false_spatial_edit',
                 'raw_jpg_nonlinear_global_tone_is_retained_without_false_spatial_edit',
                 'raw_jpg_strong_monotone_tone_and_spatial_recipe_improves_combined_match'):
        item = by_name[name]
        assert item['raw_decodes_during_analysis'] == 1
        assert item['tone_curve_max_identity_deviation'] > .035
        assert item['rgb_error_after'] < .6 * item['rgb_error_before']
    combined = by_name['raw_jpg_strong_monotone_tone_and_spatial_recipe_improves_combined_match']
    assert combined['rgb_error_after'] < combined['isolated_color_component_error']
    assert combined['global_tone_transfer_separately_recorded']
    for check in ('raw_jpg_global_contrast_is_retained_without_false_spatial_edit',
                  'raw_jpg_nonlinear_global_tone_is_retained_without_false_spatial_edit'):
        for name in ('clarity', 'texture'):
            observed = by_name[check]['spatial_controls'][name]
            assert observed['estimate'] is None or abs(observed['estimate']) < .1
