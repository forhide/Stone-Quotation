"""Travel render reuse is exact, invalidates strictly, and never edits sources."""
import copy
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import threading

import cv2
import numpy as np
from PIL import Image, ImageCms
import pytest

from personal_color_lab.core import alignment, photo_scene, semantic_models, scene_analysis, style_render
from personal_color_lab.core.edit_reverse import file_fingerprint
from personal_color_lab.core.render_evidence import RenderEvidenceCache, evidence_key
from personal_color_lab.core.style_dna import builtin_styles, identity_dna
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.travel_adjustments import apply_photo_adjustments


@pytest.fixture
def source(tmp_path):
    pixels=np.random.default_rng(44).integers(10,245,(180,280,3),dtype=np.uint8)
    path=tmp_path/'source.jpg';Image.fromarray(pixels).save(path,quality=98,subsampling=0)
    return path


@pytest.fixture
def models(monkeypatch):
    ids={'classifier':'a'*64,'semantic':'b'*64}
    calls={'measurement':0,'classifier':0,'semantic':0}
    monkeypatch.setattr(photo_scene,'classifier_bundle_id',lambda:ids['classifier'])
    monkeypatch.setattr(semantic_models,'bundle_id',lambda:ids['semantic'])
    measure=style_render._measure
    def measured(pixels):
        calls['measurement']+=1
        return measure(pixels)
    def classify(*args,**kwargs):
        calls['classifier']+=1
        report=photo_scene.unknown_photo_scene()
        if ids['classifier'] is not None:
            report.update(status='ok',bundle_id=ids['classifier'],warnings=[])
        return report
    def analyze(pixels,*args):
        calls['semantic']+=1
        if ids['semantic'] is None:raise ValueError('Model unavailable')
        masks={key:np.zeros((40,60),np.float32) for key in scene_analysis.REGIONS}
        masks['background'][:]=1
        return {'report':{'bundle_id':ids['semantic'],'scene_tags':[]},'masks':masks}
    monkeypatch.setattr(style_render,'_measure',measured)
    monkeypatch.setattr(photo_scene,'classify_photo',classify)
    monkeypatch.setattr(scene_analysis,'analyze_scene',analyze)
    return ids,calls


@pytest.mark.parametrize('recognition',[False,True])
def test_cached_previews_and_exports_match_default_pixels(source,tmp_path,models,recognition):
    cache=RenderEvidenceCache();dna=builtin_styles()[0];original=copy.deepcopy(dna)
    before=file_fingerprint(source)
    baseline=style_render.render_preview(source,dna,.6,recognition=recognition)
    first=style_render.render_preview(source,dna,.6,recognition=recognition,evidence_cache=cache)
    counts=dict(models[1])
    again=style_render.render_preview(source,dna,.6,recognition=recognition,evidence_cache=cache)
    assert models[1]==counts
    for value in (first,again):
        assert np.array_equal(value['rendered'],baseline['rendered'])
        assert value['measurement']==baseline['measurement']
        assert value['photo_scene']==baseline['photo_scene']
    style_render.export_jpeg(source,tmp_path/'default.jpg',dna,.6,recognition=recognition)
    counts=dict(models[1])
    style_render.export_jpeg(source,tmp_path/'cached.jpg',dna,.6,recognition=recognition,evidence_cache=cache)
    assert models[1]==counts
    with Image.open(tmp_path/'default.jpg') as a,Image.open(tmp_path/'cached.jpg') as b:
        assert np.array_equal(np.array(a),np.array(b))
    assert dna==original and file_fingerprint(source)==before
    assert cache.info()['hits']==2


def test_owned_evidence_survives_returned_report_and_mask_mutation(source,models):
    cache=RenderEvidenceCache();dna=identity_dna()
    first=style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    wanted=first['measurement']['quantiles'][:]
    first['measurement']['quantiles'][0]=99
    first['automatic_photo_scene']['warnings'].append('local_model_unavailable')
    first['scene']['masks']['background'][:]=0
    second=style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    assert second['measurement']['quantiles']==wanted
    assert second['automatic_photo_scene']['warnings']==[]
    assert np.all(second['scene']['masks']['background']==1)
    second['scene']['masks']['background'][:]=0
    third=style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    assert np.all(third['scene']['masks']['background']==1)


def test_source_bytes_invalidate_even_when_pixels_and_mtime_match(source,models):
    cache=RenderEvidenceCache();dna=identity_dna()
    first=style_render.render_preview(source,dna,evidence_cache=cache)
    stat=source.stat()
    # JPEG trailing bytes do not change decoded pixels. A metadata/mtime-only
    # identity would incorrectly reuse this source version.
    with source.open('ab') as stream:stream.write(b'new source version')
    import os
    os.utime(source,ns=(stat.st_atime_ns,stat.st_mtime_ns))
    second=style_render.render_preview(source,dna,evidence_cache=cache)
    assert np.array_equal(first['original'],second['original'])
    assert first['source_fingerprint']!=second['source_fingerprint']
    assert models[1]['measurement']==2


def test_model_replacement_and_repair_invalidate_and_retry(source,models):
    cache=RenderEvidenceCache();ids,calls=models;dna=identity_dna()
    style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    ids['classifier']='c'*64
    style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    assert calls['classifier']==2
    ids['semantic']='d'*64
    style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    assert calls['semantic']==3
    ids['semantic']=None
    for _ in range(2):
        fallback=style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
        assert fallback['recognition_unavailable']
    assert calls['classifier']==5
    ids['semantic']='e'*64
    style_render.render_preview(source,dna,recognition=True,evidence_cache=cache)
    assert calls['semantic']==6 and calls['classifier']==6


def test_pixel_quality_optics_and_recognition_are_all_keyed(models):
    pixels=np.zeros((20,30,3),np.uint8)
    kwargs=dict(raw_quality='baseline',lens_correction=False,lens_override=None,lens_bundle=None,recognition=False)
    key=evidence_key('f'*64,pixels,**kwargs)
    changed=pixels.copy();changed[0,0,0]=1
    assert evidence_key('f'*64,changed,**kwargs)!=key
    for name,value in [('raw_quality','interactive'),('recognition',True),('lens_override',{'lens_id':'manual'})]:
        assert evidence_key('f'*64,pixels,**dict(kwargs,**{name:value}))!=key
    assert evidence_key('f'*64,pixels,**dict(kwargs,lens_correction=True,lens_bundle='profile'))!=key
    assert evidence_key('f'*64,pixels,**dict(kwargs,lens_correction=True)) is None


def test_raw_precise_export_reuses_only_precise_preview(tmp_path,monkeypatch,models):
    source=write_test_dng(tmp_path/'sensor.dng',width=1280,height=864)
    cache=RenderEvidenceCache();dna=identity_dna()
    style_render.render_preview(source,dna,raw_quality='interactive',evidence_cache=cache)
    baseline=style_render.render_preview(source,dna,evidence_cache=cache)
    calls=[];decode=alignment.decode_raw
    def tracked(*args,**kwargs):
        calls.append((args[1],kwargs.get('quality')))
        return decode(*args,**kwargs)
    monkeypatch.setattr(alignment,'decode_raw',tracked)
    counts=dict(models[1])
    result=style_render.export_jpeg(source,tmp_path/'sensor.jpg',dna,evidence_cache=cache)
    assert calls==[(1_000_000,'baseline')]
    assert models[1]==counts
    assert result['dimensions']==baseline['original_dimensions']
    assert cache.info()['hits']==1


@pytest.mark.parametrize('bad',[None,True,False,100,'1200',2048.,[],{}])
def test_invalid_output_size_fails_before_source_hash(monkeypatch,bad,tmp_path):
    monkeypatch.setattr(style_render,'file_fingerprint',lambda *args:pytest.fail('Invalid size read source'))
    with pytest.raises(ValueError,match='size'):
        style_render.export_jpeg(tmp_path/'unused.jpg',tmp_path/'output.jpg',identity_dna(),output_size=bad)


@pytest.mark.parametrize('size',['original','2048','3840',2048,3840])
def test_output_size_never_upscales_and_strips_exif(source,tmp_path,models,size):
    destination=tmp_path/'copy.jpg'
    result=style_render.export_jpeg(source,destination,identity_dna(),output_size=size)
    assert result['dimensions']==[280,180]
    assert result['output_size']==str(size)
    with Image.open(destination) as image:
        assert not image.getexif() and image.info['icc_profile']
        assert ImageCms.getProfileName(ImageCms.ImageCmsProfile(BytesIO(image.info['icc_profile']))).strip()=='sRGB built-in'


def test_share_resize_occurs_after_full_style_and_crop(tmp_path,monkeypatch,models):
    source=tmp_path/'large.jpg'
    pixels=np.random.default_rng(76).integers(20,220,(1200,2400,3),dtype=np.uint8)
    Image.fromarray(pixels).save(source,quality=95)
    dna=builtin_styles()[4]
    full,_=style_render.read_photo(source,max_dimension=1_000_000)
    preview,_=style_render.read_photo(source)
    adapted,effective,_=style_render._scene_effective(dna,style_render._measure(preview),None)
    expected,box=style_render.apply_pixels(full,effective,.6,'apply_crop')
    ratio=2048/max(expected.shape[:2])
    expected=cv2.resize(expected,(round(expected.shape[1]*ratio),round(expected.shape[0]*ratio)),interpolation=cv2.INTER_AREA)
    captured=[]
    original_save=Image.Image.save
    def save(image,stream,*args,**kwargs):
        if kwargs.get('format')=='JPEG':captured.append(np.array(image))
        return original_save(image,stream,*args,**kwargs)
    monkeypatch.setattr(Image.Image,'save',save)
    result=style_render.export_jpeg(source,tmp_path/'share.jpg',dna,.6,'apply_crop',output_size='2048')
    assert len(captured)==1 and np.array_equal(captured[0],expected)
    assert result['composition_applied'] and result['dimensions']==[expected.shape[1],expected.shape[0]]


def test_photo_offsets_apply_once_after_style_and_update_clipping(source,tmp_path,models,monkeypatch):
    dna=builtin_styles()[0];saved=copy.deepcopy(dna)
    adjustments={'exposure_ev':1.,'temperature':.2,'tint':-.3,'strength':.4}
    base=style_render.render_preview(source,dna,.6)
    expected=apply_photo_adjustments(base['rendered'],adjustments)
    result=style_render.render_preview(source,dna,.6,photo_adjustments=adjustments)
    assert np.array_equal(result['rendered'],expected)
    assert result['clipping_after']==float(np.mean(np.any((expected<=1)|(expected>=254),axis=2)))
    captured=[];save=Image.Image.save
    def record(image,stream,*args,**kwargs):
        captured.append(np.array(image));return save(image,stream,*args,**kwargs)
    monkeypatch.setattr(Image.Image,'save',record)
    style_render.export_jpeg(source,tmp_path/'adjusted.jpg',dna,.6,photo_adjustments=adjustments)
    assert np.array_equal(captured[0],expected)
    neutral=style_render.render_preview(source,dna,.6,photo_adjustments={'strength':0})
    assert np.array_equal(neutral['rendered'],base['rendered'])
    assert dna==saved


def test_source_changed_during_render_and_cancel_never_publish_or_cache(source,tmp_path,models,monkeypatch):
    cache=RenderEvidenceCache();stop=threading.Event();stop.set()
    with pytest.raises(ValueError,match='cancelled'):
        style_render.export_jpeg(source,tmp_path/'cancelled.jpg',identity_dna(),cancel_event=stop,evidence_cache=cache)
    assert not (tmp_path/'cancelled.jpg').exists() and cache.info()['entries']==0
    apply=style_render.apply_pixels
    def mutate(*args,**kwargs):
        result=apply(*args,**kwargs)
        with source.open('ab') as stream:stream.write(b'changed during style')
        return result
    monkeypatch.setattr(style_render,'apply_pixels',mutate)
    with pytest.raises(ValueError,match='changed'):
        style_render.export_jpeg(source,tmp_path/'changed.jpg',identity_dna(),evidence_cache=cache)
    assert not (tmp_path/'changed.jpg').exists() and cache.info()['entries']==0


def test_cache_bounds_and_concurrent_owned_reads(source,models):
    cache=RenderEvidenceCache(max_entries=2,max_bytes=10000)
    key=evidence_key('f'*64,np.zeros((20,30,3),np.uint8),raw_quality='baseline',lens_correction=False,lens_override=None,lens_bundle=None,recognition=False)
    automatic=photo_scene.unknown_photo_scene();automatic.update(status='ok',bundle_id='a'*64,warnings=[])
    measurement={'quantiles':[.1,.2,.3]}
    for index in range(3):cache.put((str(index),*key[1:]),measurement,None,automatic)
    assert cache.info()['entries']==2 and cache.info()['bytes']<=10000
    assert cache.get(('0',*key[1:])) is None
    def read(_):
        value=cache.get(('2',*key[1:]));value['measurement']['quantiles'][0]=99
    with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(read,range(20)))
    assert cache.get(('2',*key[1:]))['measurement']['quantiles'][0]==.1
    tiny=RenderEvidenceCache(max_bytes=1);tiny.put(key,measurement,None,automatic)
    assert tiny.info()['entries']==0
