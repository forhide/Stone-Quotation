"""Real photo/RAW navigation previews stay bounded, disposable and offline."""
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import json
import os
from pathlib import Path
import socket
import struct
import threading
import time

import numpy as np
from PIL import Image, ImageCms, ImageOps
import pytest
import rawpy

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core import travel_previews as previews


def pattern(width=192, height=128):
    y,x=np.mgrid[:height,:width]
    rgb=np.stack((30+x*.8,35+y*.9,60+(x+y)*.35),axis=2)
    rgb[:height//3,:width//3]=(235,30,45)
    rgb[-height//3:,-width//3:]=(25,210,70)
    return np.rint(np.clip(rgb,0,255)).astype('uint8')


def image_file(path, *, orientation=1, gps=False, width=192, height=128):
    exif=Image.Exif();exif[274]=orientation
    exif[315]='private photographer'
    if gps:exif[34853]={1:'N',2:(37.,0.,0.),3:'E',4:(127.,0.,0.)}
    icc=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
    Image.fromarray(pattern(width,height)).save(path,quality=98,subsampling=0,exif=exif,icc_profile=icc)
    return path


def test_cache_reopen_and_memory_hits_survive_unavailable_nofollow_timestamps(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg')
    cache_dir=tmp_path/'cache'
    original=previews.TravelPreviewCache(cache_dir).thumbnail(photo)
    def unsupported(*args,**kwargs):
        assert kwargs.get('follow_symlinks') is False
        raise NotImplementedError('Windows does not support no-follow utime')
    monkeypatch.setattr(os,'utime',unsupported)
    reopened=previews.TravelPreviewCache(cache_dir)
    for _ in range(2):
        result=reopened.thumbnail(photo)
        assert result['cache_hit'] and np.array_equal(result['pixels'],original['pixels'])
    assert reopened.stats()['decodes']==0


def embedded_dng(path, *, orientation=1):
    """Actual TIFF/DNG preview IFD and sensor SubIFD, parsed by real LibRaw."""
    write_test_dng(path,width=640,height=480,orientation=orientation)
    source=path.read_bytes()
    jpeg=BytesIO();Image.fromarray(pattern()).save(jpeg,format='JPEG',quality=98,subsampling=0)
    data=jpeg.getvalue();offset=len(source)
    short=lambda x:(3,1,struct.pack('<H',x))
    long=lambda x:(4,1,struct.pack('<I',x))
    tags={254:long(1),256:long(192),257:long(128),258:short(8),259:short(7),
          262:short(6),274:short(orientation),330:long(8),513:long(offset),514:long(len(data)),
          50706:(1,4,bytes((1,4,0,0))),50707:(1,4,bytes((1,1,0,0)))}
    ifd=struct.pack('<H',len(tags))+b''.join(struct.pack('<HHI',tag,kind,count)+value.ljust(4,b'\0')
        for tag,(kind,count,value) in sorted(tags.items()))+struct.pack('<I',0)
    result=bytearray(source+data+ifd);struct.pack_into('<I',result,4,len(source+data));path.write_bytes(result)
    return path


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*args,**kwargs):raise AssertionError('Gallery previews attempted network access')
    monkeypatch.setattr(socket,'socket',denied)
    monkeypatch.setattr(socket,'create_connection',denied)


@pytest.mark.parametrize('orientation',range(1,9))
def test_real_jpeg_navigation_is_oriented_bounded_and_cache_strips_private_metadata(tmp_path,orientation):
    photo=image_file(tmp_path/'photo.jpg',orientation=orientation,gps=True)
    before=photo.read_bytes()
    cache=previews.TravelPreviewCache(tmp_path/'cache',max_dimension=96)
    actual=cache.thumbnail(photo)
    with Image.open(photo) as opened:
        expected=ImageOps.exif_transpose(opened).convert('RGB')
        expected.thumbnail((96,96),Image.Resampling.LANCZOS)
    assert actual['pixels'].shape==np.array(expected).shape
    assert np.max(abs(actual['pixels'].astype(int)-np.array(expected).astype(int)))<=1
    assert actual['kind']=='image_preview' and actual['approximate'] and not actual['cache_hit']
    entry=next((tmp_path/'cache').glob('*.png'))
    with Image.open(entry) as cached:
        assert not cached.getexif() and set(cached.info)=={'pcl_preview'}
        metadata=json.loads(cached.info['pcl_preview'])
        assert not any(text in json.dumps(metadata) for text in ('GPS','private photographer',str(photo)))
    assert photo.read_bytes()==before


@pytest.mark.parametrize('orientation',range(1,9))
def test_real_embedded_dng_thumbnail_avoids_sensor_unpack_and_full_development(tmp_path,monkeypatch,orientation):
    photo=embedded_dng(tmp_path/'camera.dng',orientation=orientation)
    before=photo.read_bytes()
    def denied(*args,**kwargs):raise AssertionError('Camera gallery preview developed RAW sensor pixels')
    monkeypatch.setattr(previews,'decode_raw',denied)
    native=rawpy.RawPy
    class HeaderAndThumbnailOnly:
        def __init__(self):self.raw=native()
        def __enter__(self):return self
        def __exit__(self,*args):self.raw.close()
        def open_file(self,path):return self.raw.open_file(path)
        @property
        def sizes(self):return self.raw.sizes
        def extract_thumb(self):return self.raw.extract_thumb()
        unpack=denied
        postprocess=denied
    monkeypatch.setattr(rawpy,'RawPy',HeaderAndThumbnailOnly)
    cache=previews.TravelPreviewCache(tmp_path/'cache',max_dimension=96)
    actual=cache.thumbnail(photo)
    with rawpy.RawPy() as raw:
        raw.open_file(str(photo));thumbnail=raw.extract_thumb()
    with Image.open(BytesIO(thumbnail.data)) as image:
        expected=ImageOps.exif_transpose(image).convert('RGB')
        expected.thumbnail((96,96),Image.Resampling.LANCZOS)
    assert np.array_equal(actual['pixels'],np.array(expected))
    assert actual['kind']=='camera_preview' and actual['approximate']
    assert photo.read_bytes()==before


def test_real_dng_without_embedded_thumbnail_uses_marked_sensor_preview_once(tmp_path,monkeypatch):
    photo=write_test_dng(tmp_path/'camera.dng',width=640,height=480,orientation=6)
    before=photo.read_bytes();calls=[];decode=previews.decode_raw
    def counted(*args,**kwargs):
        calls.append(kwargs)
        return decode(*args,**kwargs)
    monkeypatch.setattr(previews,'decode_raw',counted)
    cache=previews.TravelPreviewCache(tmp_path/'cache',max_dimension=96)
    first=cache.thumbnail(photo);again=cache.thumbnail(photo)
    assert first['kind']=='raw_preview' and first['approximate']
    assert first['pixels'].shape==(96,72,3) and np.mean(first['pixels'])>30
    assert len(calls)==1 and calls[0]['quality']=='interactive'
    assert again['cache_hit'] and np.array_equal(first['pixels'],again['pixels'])
    assert photo.read_bytes()==before


def test_second_instance_uses_persisted_pixels_without_decoding_and_returns_independent_arrays(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg');folder=tmp_path/'cache'
    first=previews.TravelPreviewCache(folder,max_dimension=96).thumbnail(photo)
    def denied(*args,**kwargs):raise AssertionError('Persisted thumbnail was decoded again')
    monkeypatch.setattr(previews,'_decode_thumbnail',denied)
    cache=previews.TravelPreviewCache(folder,max_dimension=96)
    second=cache.thumbnail(photo);second['pixels'][:]=0;second['source_stamp']['size_bytes']=0
    third=cache.thumbnail(photo)
    assert third['cache_hit'] and np.array_equal(first['pixels'],third['pixels'])
    assert third['source_stamp']['size_bytes']==photo.stat().st_size
    assert cache.stats()['decodes']==0 and cache.stats()['disk_hits']==1


def test_file_replacement_invalidates_even_if_size_and_mtime_are_restored(tmp_path):
    photo=image_file(tmp_path/'photo.jpg');cache=previews.TravelPreviewCache(tmp_path/'cache',max_dimension=96)
    first=cache.thumbnail(photo);old=photo.stat()
    replacement=tmp_path/'replacement.jpg'
    Image.fromarray(np.full((128,192,3),(20,40,230),np.uint8)).save(replacement,quality=98)
    changed=replacement.read_bytes();replacement.write_bytes(changed+b'\0'*max(0,old.st_size-len(changed)))
    os.utime(replacement,ns=(old.st_atime_ns,old.st_mtime_ns));os.replace(replacement,photo)
    second=cache.thumbnail(photo)
    assert not second['cache_hit'] and not np.array_equal(first['pixels'],second['pixels'])
    assert second['source_stamp']!=first['source_stamp']


@pytest.mark.parametrize('corruption',['truncated','wrong_pixels','private_metadata','directory'])
def test_corrupt_or_poisoned_disk_entries_do_not_become_trusted_previews(tmp_path,corruption):
    photo=image_file(tmp_path/'photo.jpg');folder=tmp_path/'cache'
    expected=previews.TravelPreviewCache(folder,max_dimension=96).thumbnail(photo)
    entry=next(folder.glob('*.png'))
    if corruption=='truncated':entry.write_bytes(entry.read_bytes()[:40])
    elif corruption=='directory':entry.unlink();entry.mkdir()
    else:
        with Image.open(entry) as image:
            metadata=image.info['pcl_preview'];pixels=np.array(image)
        info=previews.PngImagePlugin.PngInfo()
        if corruption=='private_metadata':
            parsed=json.loads(metadata);parsed['GPS']='private';metadata=json.dumps(parsed)
        else:pixels[:]=0
        info.add_text('pcl_preview',metadata);Image.fromarray(pixels).save(entry,pnginfo=info)
    cache=previews.TravelPreviewCache(folder,max_dimension=96)
    actual=cache.thumbnail(photo)
    assert not actual['cache_hit'] and np.array_equal(actual['pixels'],expected['pixels'])


def test_symlink_entry_is_unlinked_without_touching_its_target(tmp_path):
    photo=image_file(tmp_path/'photo.jpg');folder=tmp_path/'cache'
    expected=previews.TravelPreviewCache(folder,max_dimension=96).thumbnail(photo)
    entry=next(folder.glob('*.png'));entry.unlink()
    outside=tmp_path/'private.jpg';outside.write_bytes(b'preserve outside source');entry.symlink_to(outside)
    cache=previews.TravelPreviewCache(folder,max_dimension=96)
    assert np.array_equal(cache.thumbnail(photo)['pixels'],expected['pixels'])
    assert outside.read_bytes()==b'preserve outside source' and not entry.is_symlink()


def test_cache_root_symlink_and_replacement_are_rejected_without_outside_writes(tmp_path,monkeypatch):
    outside=tmp_path/'outside';outside.mkdir();link=tmp_path/'link';link.symlink_to(outside,target_is_directory=True)
    with pytest.raises(ValueError):previews.TravelPreviewCache(link)
    photo=image_file(tmp_path/'photo.jpg');folder=tmp_path/'cache'
    cache=previews.TravelPreviewCache(folder,max_dimension=96)
    decode=previews._decode_thumbnail
    def replace(*args,**kwargs):
        value=decode(*args,**kwargs);folder.rename(tmp_path/'old-cache');folder.symlink_to(outside,target_is_directory=True)
        return value
    monkeypatch.setattr(previews,'_decode_thumbnail',replace)
    with pytest.raises(ValueError,match='directory changed'):cache.thumbnail(photo)
    assert not list(outside.iterdir())


def test_memory_and_disk_budgets_are_bounded_and_unrelated_files_survive_clear(tmp_path):
    folder=tmp_path/'cache';cache=previews.TravelPreviewCache(folder,max_bytes=12_000,max_dimension=64)
    sentinel=folder/'user-notes.txt';sentinel.write_text('preserve')
    for index in range(37):
        photo=tmp_path/f'{index}.jpg'
        pixels=np.random.default_rng(index).integers(0,256,(90,120,3),dtype=np.uint8)
        Image.fromarray(pixels).save(photo,quality=98)
        cache.thumbnail(photo)
    stats=cache.stats()
    assert stats['memory_entries']<=32 and stats['memory_bytes']<=32*64*64*3
    assert stats['disk_bytes']<=12_000 and stats['evictions']>0
    cache.clear();assert cache.stats()['disk_entries']==cache.stats()['memory_entries']==0
    assert sentinel.read_text()=='preserve'


def test_zero_disk_budget_and_disk_full_do_not_prevent_browsing(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg');cache=previews.TravelPreviewCache(tmp_path/'cache',max_bytes=0)
    first=cache.thumbnail(photo);assert not list((tmp_path/'cache').glob('*.png'))
    second=previews.TravelPreviewCache(tmp_path/'other')
    def full(*args,**kwargs):raise OSError('disk full')
    monkeypatch.setattr(second,'_write_disk',full)
    actual=second.thumbnail(photo)
    assert np.array_equal(first['pixels'],actual['pixels']) and second.stats()['write_errors']==1


def test_concurrent_requests_across_instances_share_one_decoder_lease(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg');folder=tmp_path/'cache'
    caches=[previews.TravelPreviewCache(folder,max_dimension=96) for _ in range(4)]
    original=previews._decode_thumbnail;started=threading.Event();release=threading.Event();calls=[]
    def delayed(*args,**kwargs):
        calls.append(1);started.set();assert release.wait(3);return original(*args,**kwargs)
    monkeypatch.setattr(previews,'_decode_thumbnail',delayed)
    with ThreadPoolExecutor(max_workers=4) as pool:
        jobs=[pool.submit(cache.thumbnail,photo) for cache in caches]
        assert started.wait(2);release.set();values=[job.result(timeout=5) for job in jobs]
    assert len(calls)==1 and sum(not value['cache_hit'] for value in values)==1
    assert all(np.array_equal(value['pixels'],values[0]['pixels']) for value in values)


def test_waiting_request_can_cancel_without_cancelling_another_decoders_result(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg');cache=previews.TravelPreviewCache(tmp_path/'cache')
    original=previews._decode_thumbnail;started=threading.Event();release=threading.Event();cancel=threading.Event()
    def delayed(*args,**kwargs):started.set();assert release.wait(3);return original(*args,**kwargs)
    monkeypatch.setattr(previews,'_decode_thumbnail',delayed)
    with ThreadPoolExecutor(max_workers=2) as pool:
        leader=pool.submit(cache.thumbnail,photo);assert started.wait(2)
        follower=pool.submit(cache.thumbnail,photo,cancel_event=cancel);cancel.set()
        with pytest.raises(AnalysisCancelledError):follower.result(timeout=2)
        release.set();assert leader.result(timeout=5)['pixels'].size
    assert cache.thumbnail(photo)['cache_hit']


def test_changed_source_and_cancelled_decode_publish_no_cache_entry(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg');cache=previews.TravelPreviewCache(tmp_path/'cache')
    original=previews._decode_thumbnail
    def changed(*args,**kwargs):
        result=original(*args,**kwargs);photo.write_bytes(photo.read_bytes()+b'x');return result
    monkeypatch.setattr(previews,'_decode_thumbnail',changed)
    with pytest.raises(ValueError,match='changed'):cache.thumbnail(photo)
    assert not list((tmp_path/'cache').glob('*.png'))
    cancel=threading.Event();cancel.set()
    with pytest.raises(AnalysisCancelledError):cache.thumbnail(photo,cancel_event=cancel)
    assert not list((tmp_path/'cache').glob('*.png'))


def test_clear_during_decode_does_not_allow_late_cache_repopulation(tmp_path,monkeypatch):
    photo=image_file(tmp_path/'photo.jpg');cache=previews.TravelPreviewCache(tmp_path/'cache')
    original=previews._decode_thumbnail
    def clear(*args,**kwargs):result=original(*args,**kwargs);cache.clear();return result
    monkeypatch.setattr(previews,'_decode_thumbnail',clear)
    assert cache.thumbnail(photo)['pixels'].size
    assert cache.stats()['memory_entries']==cache.stats()['disk_entries']==0


@pytest.mark.parametrize('kwargs',[{'max_bytes':True},{'max_bytes':-1},{'max_dimension':0},{'max_dimension':2048}])
def test_invalid_cache_configuration_is_rejected(tmp_path,kwargs):
    with pytest.raises(ValueError):previews.TravelPreviewCache(tmp_path/'cache',**kwargs)
