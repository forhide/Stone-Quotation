"""Travel discovery and suggestions use synthetic local files, never real photos."""
from datetime import datetime, timedelta
import hashlib
from pathlib import Path
import struct
from threading import Event

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.analysis_control import AnalysisCancelledError
from personal_color_lab.core import travel_analysis as travel


def _ascii(value):
    return 2, value.encode('ascii') + b'\0'


def _tiff(tags, *, base=0, magic=42, endian='<'):
    table = bytearray(struct.pack(endian + 'H', len(tags)))
    extra = bytearray()
    start = base + 8 + 2 + 12 * len(tags) + 4
    for tag, (kind, value) in sorted(tags.items()):
        if kind == 3:
            data = struct.pack(endian + 'H', value)
        elif kind == 4:
            data = struct.pack(endian + 'I', value)
        else:
            data = value
        count = len(data) // {2: 1, 3: 2, 4: 4, 7: 1}[kind]
        if len(data) > 4:
            encoded = struct.pack(endian + 'I', start + len(extra))
            extra.extend(data)
            extra.extend(b'\0' * (len(extra) % 2))
        else:
            encoded = data.ljust(4, b'\0')
        table.extend(struct.pack(endian + 'HHI', tag, kind, count) + encoded)
    return ((b'II' if endian == '<' else b'MM') + struct.pack(endian + 'HI', magic, 8)
            + table + struct.pack(endian + 'I', 0) + extra)


def _raw_tiff(*, orientation=1, magic=42, endian='<', private=False):
    image_tags = {0x100: (4, 9504), 0x101: (4, 6336), 0x112: (3, orientation),
                  0x8769: (4, 0)}
    if private:
        image_tags.update({0x8825: (4, 0xFFFFFFF0), 0x02BC: (7, b'private GPS and owner'),
                           0xA431: _ascii('private-camera-serial')})
    root = bytearray(_tiff(image_tags, magic=magic, endian=endian))
    for index in range(len(image_tags)):
        entry = 10 + 12 * index
        if struct.unpack_from(endian + 'H', root, entry)[0] == 0x8769:
            struct.pack_into(endian + 'I', root, entry + 8, len(root))
    dates = {0x9003: _ascii('2026:10:20 13:14:15'), 0x9011: _ascii('+09:00'),
             0x9291: _ascii('12345')}
    if private:
        dates[0xA430] = _ascii('private-owner')
    root.extend(_tiff(dates, base=len(root) - 8, endian=endian)[8:])
    return bytes(root)


def _jpeg(path, *, date='2026:10:20 13:14:15', offset='+09:00', sub='125', orientation=1):
    exif = Image.Exif()
    for tag, value in ((36867, date), (36881, offset), (37521, sub), (274, orientation),
                       (42033, 'private-serial'), (42032, 'private-owner')):
        if value is not None:
            exif[tag] = value
    Image.new('RGB', (31, 19), (90, 110, 130)).save(path, exif=exif)
    return path


def _box(kind, data):
    return struct.pack('>I4s', len(data) + 8, kind) + data


def _photo(number, *, seconds=0, date=True, folder='trip'):
    stamp = (datetime(2026, 10, 20, 13) + timedelta(seconds=seconds)).isoformat() if date else None
    return {'id': number, 'source_path': f'/{folder}/DSC{number:05}.ARW',
            'relative_path': f'DSC{number:05}.ARW', 'capture_time': stamp}


def _pattern(seed=3, brightness=0):
    # Broad shapes survive thumbnail reduction, unlike per-pixel white noise.
    base = np.random.default_rng(seed).integers(30, 180, (12, 16, 1), dtype=np.uint8)
    base = np.repeat(np.repeat(base, 4, axis=0), 4, axis=1)
    rgb = np.repeat(base, 3, axis=2).astype(np.int16) + brightness
    return np.clip(rgb, 0, 255).astype(np.uint8)


def test_jpeg_selected_exif_orientation_privacy_and_immutable_original(tmp_path):
    source = _jpeg(tmp_path / 'photo.JPG', orientation=6)
    original = hashlib.sha256(source.read_bytes()).digest()
    result = travel.scan_travel_folder(tmp_path)
    assert len(result) == 1
    assert result[0]['source_path'] == str(source.resolve())
    assert result[0]['capture_time'] == '2026-10-20T13:14:15.125000+09:00'
    assert (result[0]['width'], result[0]['height']) == (19, 31)
    assert set(result[0]) == {'source_path', 'relative_path', 'kind', 'size_bytes', 'mtime_ns',
                              'capture_time', 'width', 'height'}
    assert 'private' not in repr(result)
    assert hashlib.sha256(source.read_bytes()).digest() == original


@pytest.mark.parametrize('magic,endian,suffix', [(42, '<', '.ARW'), (42, '>', '.NEF'),
                                                 (0x4F52, '<', '.ORF'), (85, '<', '.RW2')])
def test_raw_sparse_header_dates_without_pixel_decode_or_private_metadata(tmp_path, monkeypatch, magic, endian, suffix):
    source = tmp_path / ('original' + suffix)
    source.write_bytes(_raw_tiff(orientation=8, magic=magic, endian=endian, private=True))
    # A large sparse sensor payload must not influence import work.
    with source.open('r+b') as handle:
        handle.seek(20_000_000)
        handle.write(b'sensor')
    original = hashlib.sha256(source.read_bytes()).digest()
    reads = []
    old_read = travel._HeaderReader.read
    def read(reader, count=-1):
        reads.append(count)
        return old_read(reader, count)
    def forbidden(*args, **kwargs):
        raise AssertionError('Travel listing must not decode or hash originals.')
    from personal_color_lab.core import raw_decode, edit_reverse
    monkeypatch.setattr(travel._HeaderReader, 'read', read)
    monkeypatch.setattr(raw_decode, 'decode_raw', forbidden)
    monkeypatch.setattr(edit_reverse, 'file_fingerprint', forbidden)
    result = travel.scan_travel_folder(tmp_path)[0]
    assert result['kind'] == 'raw'
    assert result['capture_time'] == '2026-10-20T13:14:15.123450+09:00'
    assert (result['width'], result['height']) == (6336, 9504)
    assert 0 < sum(reads) < 4096 < travel.MAX_HEADER_BYTES
    assert 'private' not in repr(result)
    assert hashlib.sha256(source.read_bytes()).digest() == original


def test_cr3_cmt_and_raf_embedded_exif(tmp_path):
    exif = _tiff({0x9003: _ascii('2026:10:20 11:12:13'), 0x9011: _ascii('-04:00')})
    cmt = _box(b'CMT2', exif)
    cr3 = _box(b'ftyp', b'crx \0\0\0\0') + _box(b'moov', _box(b'uuid', travel._CANON_UUID + cmt))
    (tmp_path / 'canon.CR3').write_bytes(cr3)
    jpg = _jpeg(tmp_path / 'temporary.jpg').read_bytes()
    (tmp_path / 'temporary.jpg').unlink()
    raf = bytearray(92)
    raf[:12] = b'FUJIFILMCCD-\0'
    struct.pack_into('>II', raf, 84, len(raf), len(jpg))
    (tmp_path / 'fuji.RAF').write_bytes(raf + jpg)
    result = {Path(p['source_path']).stem: p for p in travel.scan_travel_folder(tmp_path)}
    assert result['canon']['capture_time'] == '2026-10-20T11:12:13-04:00'
    assert result['fuji']['capture_time'] == '2026-10-20T13:14:15.125000+09:00'


@pytest.mark.parametrize('offset,expected', [(None, '2026-10-20T13:14:15'), ('+00:00', '2026-10-20T13:14:15+00:00'),
                                           ('+14:01', None), ('tomorrow', None)])
def test_unknown_timezone_is_not_invented_and_invalid_offsets_stay_unknown(tmp_path, offset, expected):
    _jpeg(tmp_path / 'photo.jpg', offset=offset, sub=None)
    assert travel.scan_travel_folder(tmp_path)[0]['capture_time'] == expected


@pytest.mark.parametrize('date', ['not a date', '2026:02:31 13:14:15', '2201:10:20 13:14:15', '2026:10:20 29:14:15'])
def test_invalid_capture_dates_are_unknown(tmp_path, date):
    _jpeg(tmp_path / 'photo.jpg', date=date)
    assert travel.scan_travel_folder(tmp_path)[0]['capture_time'] is None


def test_unknown_metadata_no_mtime_capture_and_natural_order(tmp_path):
    for name in ('DSC10.ARW', 'DSC2.ARW', 'DSC1.ARW'):
        (tmp_path / name).write_bytes(b'unsupported header')
    _jpeg(tmp_path / 'known.jpg')
    result = travel.scan_travel_folder(tmp_path)
    assert [p['relative_path'] for p in result] == ['known.jpg', 'DSC1.ARW', 'DSC2.ARW', 'DSC10.ARW']
    assert all(p['capture_time'] is None for p in result[1:])
    assert all(p['width'] is None and p['height'] is None for p in result[1:])


def test_raw_companion_preference_is_same_directory_exact_stem_only(tmp_path):
    (tmp_path / 'A').mkdir()
    (tmp_path / 'a').mkdir()
    for name in ('A/PHOTO.ARW', 'A/photo.JPG', 'a/photo.jpg', 'A/photo-edited.jpg', 'A/other.png'):
        (tmp_path / name).write_bytes(b'unsupported')
    result = travel.scan_travel_folder(tmp_path)
    assert {p['relative_path'] for p in result} == {'A/PHOTO.ARW', 'a/photo.jpg', 'A/photo-edited.jpg'}


def test_recursive_hidden_owned_and_symlink_rules(tmp_path):
    root = tmp_path / 'trip'
    root.mkdir()
    (root / 'good.ARW').write_bytes(b'raw')
    (tmp_path / 'outside.ARW').write_bytes(b'raw')
    for name in ('.hidden', '.pcl-cache', 'PCL_Exports', 'pcl-exports', 'PersonalColorLab-Exports', 'sub'):
        (root / name).mkdir()
        (root / name / 'nested.ARW').write_bytes(b'raw')
    (root / '.hidden.ARW').write_bytes(b'raw')
    (root / 'outside-link.ARW').symlink_to(tmp_path / 'outside.ARW')
    (root / 'duplicate-link.ARW').symlink_to(root / 'good.ARW')
    (root / 'cycle').symlink_to(root, target_is_directory=True)
    (root / 'export-link.ARW').symlink_to(root / 'PCL_Exports' / 'nested.ARW')
    assert {p['relative_path'] for p in travel.scan_travel_folder(root)} == {'good.ARW', 'sub/nested.ARW'}
    assert [p['relative_path'] for p in travel.scan_travel_folder(root, False)] == ['good.ARW']


def test_scan_cancellation_progress_and_explicit_io_failures(tmp_path, monkeypatch):
    for number in range(3):
        (tmp_path / f'DSC{number}.ARW').write_bytes(b'raw')
    event = Event()
    progress = []
    def update(done, total, name):
        progress.append((done, total, name))
        event.set()
    with pytest.raises(AnalysisCancelledError):
        travel.scan_travel_folder(tmp_path, cancel_event=event, progress=update)
    assert progress == [(1, 3, 'DSC0.ARW')]
    with pytest.raises(AnalysisCancelledError):
        travel.scan_travel_folder(tmp_path, cancel_event=event)
    def failed(*args):
        raise PermissionError('Disconnected source')
    monkeypatch.setattr(travel, '_metadata', failed)
    with pytest.raises(PermissionError, match='Disconnected'):
        travel.scan_travel_folder(tmp_path)
    with pytest.raises(FileNotFoundError):
        travel.scan_travel_folder(tmp_path / 'missing')
    with pytest.raises(NotADirectoryError):
        travel.scan_travel_folder(tmp_path / 'DSC0.ARW')


def test_scan_detects_file_change_and_reports_final_progress(tmp_path, monkeypatch):
    source = tmp_path / 'photo.ARW'
    source.write_bytes(b'raw')
    progress = []
    assert len(travel.scan_travel_folder(tmp_path, progress=lambda *args: progress.append(args))) == 1
    assert progress == [(1, 1, 'photo.ARW')]
    original = travel._metadata
    def change(path, *args):
        value = original(path, *args)
        path.write_bytes(b'different raw')
        return value
    monkeypatch.setattr(travel, '_metadata', change)
    with pytest.raises(ValueError, match='changed'):
        travel.scan_travel_folder(tmp_path)


def test_time_visual_groups_are_stable_use_photo_ids_and_do_not_modify_inputs():
    photos = [_photo(i, seconds=i * 20) for i in range(1, 5)]
    previews = {p['id']: {'pixels': _pattern(brightness=p['id'])} for p in photos}
    first = travel.suggest_groups(photos, previews)
    second = travel.suggest_groups(list(reversed(photos)), previews)
    assert first == second
    assert len(first) == 1
    assert first[0]['photo_ids'] == [1, 2, 3, 4]
    assert first[0]['representative_id'] == 3
    assert first[0]['reason'] == 'time_visual'
    assert .7 < first[0]['confidence'] < 1
    assert all(set(p) == {'id', 'source_path', 'relative_path', 'capture_time'} for p in photos)


def test_same_hue_different_structure_is_not_a_duplicate_group():
    photos = [_photo(1), _photo(2, seconds=10)]
    previews = {1: _pattern(3), 2: _pattern(7)}
    groups = travel.suggest_groups(photos, previews)
    assert [g['photo_ids'] for g in groups] == [[1], [2]]
    assert all(g['reason'] == 'single' and g['confidence'] == 0 for g in groups)


@pytest.mark.parametrize('change', ['brightness', 'color', 'time'])
def test_light_color_and_long_time_transitions_split_groups(change):
    photos = [_photo(1), _photo(2, seconds=10), _photo(3, seconds=1000 if change == 'time' else 20)]
    previews = {1: _pattern(), 2: _pattern(brightness=2), 3: _pattern()}
    if change == 'brightness':
        previews[3] = _pattern(brightness=90)
    elif change == 'color':
        previews[3][:, :, 0] = 240
    assert [g['photo_ids'] for g in travel.suggest_groups(photos, previews)] == [[1, 2], [3]]


def test_anchor_comparison_does_not_chain_across_gradual_lighting_change():
    photos = [_photo(i, seconds=i * 10) for i in range(1, 10)]
    previews = {p['id']: _pattern(brightness=p['id'] * 10) for p in photos}
    groups = travel.suggest_groups(photos, previews)
    assert len(groups) >= 3
    assert max(max(g['photo_ids']) - min(g['photo_ids']) for g in groups) <= 3


def test_missing_metadata_has_explicit_weak_bounded_sequence_fallback():
    photos = [_photo(i, date=False) for i in range(1, 15)]
    groups = travel.suggest_groups(photos)
    assert [len(g['photo_ids']) for g in groups] == [6, 6, 2]
    assert all(g['reason'] == 'sequence' and g['confidence'] == .2 for g in groups)
    assert not any('day' in repr(g) or 'night' in repr(g) for g in groups)
    photos[1]['relative_path'] = 'unrelated.ARW'
    assert travel.suggest_groups(photos[:2])[0]['reason'] == 'single'


def test_timestamps_without_visuals_have_low_confidence_and_known_unknown_do_not_mix():
    photos = [_photo(i, seconds=i) for i in range(1, 12)]
    assert [len(g['photo_ids']) for g in travel.suggest_groups(photos)] == [8, 3]
    assert all(g['confidence'] == .35 for g in travel.suggest_groups(photos))
    photos[1]['capture_time'] = None
    assert len(travel.suggest_groups(photos[:2])) == 2


def test_timezone_handling_uses_instants_and_never_infers_missing_zone():
    photos = [_photo(1), _photo(2)]
    photos[0]['capture_time'] = '2026-10-20T13:00:00+09:00'
    photos[1]['capture_time'] = '2026-10-20T04:00:10Z'
    assert travel.suggest_groups(photos)[0]['photo_ids'] == [1, 2]
    photos[1]['capture_time'] = '2026-10-20T04:00:10'
    assert len(travel.suggest_groups(photos)) == 2


def test_large_trip_uses_one_feature_per_photo_and_only_adjacent_anchor_comparisons(monkeypatch):
    photos = [_photo(i, seconds=i * 5) for i in range(1, 602)]
    pixels = _pattern()
    previews = {p['id']: pixels for p in photos}
    counts = {'feature': 0, 'comparison': 0}
    feature, close = travel._visual_feature, travel._visual_close
    def measured_feature(*args, **kwargs):
        counts['feature'] += 1
        return feature(*args, **kwargs)
    def measured_close(*args, **kwargs):
        counts['comparison'] += 1
        return close(*args, **kwargs)
    monkeypatch.setattr(travel, '_visual_feature', measured_feature)
    monkeypatch.setattr(travel, '_visual_close', measured_close)
    groups = travel.suggest_groups(photos, previews)
    assert counts['feature'] == len(photos)
    assert counts['comparison'] <= 2 * len(photos)
    assert max(len(g['photo_ids']) for g in groups) <= travel.MAX_GROUP_SIZE
    assert [p for g in groups for p in g['photo_ids']] == list(range(1, 602))


def test_path_identity_preview_lookup_and_invalid_or_duplicate_ids():
    photos = [_photo(1), _photo(2, seconds=10)]
    for photo in photos:
        del photo['id']
    previews = {p['source_path']: _pattern() for p in photos}
    result = travel.suggest_groups(photos, previews)
    assert result[0]['photo_ids'] == [p['source_path'] for p in photos]
    with pytest.raises(ValueError, match='distinct'):
        travel.suggest_groups([photos[0], photos[0]])
    with pytest.raises(ValueError, match='id or source'):
        travel.suggest_groups([{}])
    with pytest.raises(ValueError, match='preview'):
        travel.suggest_groups(photos, [])


def test_group_cancellation_raises_without_partial_success(monkeypatch):
    event = Event()
    photos = [_photo(1), _photo(2, seconds=10)]
    feature = travel._visual_feature
    def cancel(*args):
        event.set()
        return feature(*args)
    monkeypatch.setattr(travel, '_visual_feature', cancel)
    with pytest.raises(AnalysisCancelledError):
        travel.suggest_groups(photos, {1: _pattern(), 2: _pattern()}, cancel_event=event)


def test_review_flags_measured_changes_but_not_unchanged_dark_or_classifier_uncertainty():
    original = np.full((64, 64, 3), 100, np.uint8)
    rendered = original.copy()
    rendered[:8] = 255
    rendered[8:16] = 0
    preview = {'original': original, 'rendered': rendered, 'scene': {'uncertain': True}}
    assert travel.review_preview(preview) == ['travel_review_highlights', 'travel_review_clipping']
    dark = np.zeros((64, 64, 3), np.uint8)
    assert travel.review_preview({'original': dark, 'rendered': dark, 'scene': {'uncertain': True}}) == []
    assert travel.review_preview({'scene': {'uncertain': True, 'warnings': ['scene_uncertain']}}) == []
    assert np.all(original == 100)


def test_review_face_color_requires_actual_sufficient_mask():
    original = np.full((64, 64, 3), [160, 120, 95], np.uint8)
    rendered = original.copy()
    rendered[:32] = [110, 140, 190]
    mask = np.zeros((64, 64), np.float32)
    mask[:32] = 1
    preview = {'original': original, 'rendered': rendered, 'scene': {'masks': {'face': mask}}}
    assert travel.review_preview(preview) == ['travel_review_color_change']
    assert travel.review_preview({'original': original, 'rendered': rendered}) == []
    mask[:] = 0
    mask[:2, :2] = 1
    assert travel.review_preview(preview) == []


@pytest.mark.parametrize('before,after,result', [(.01, .08, ['travel_review_clipping']),
                                               (.08, .09, []), (None, .2, []),
                                               (float('nan'), .2, []), (False, .2, []),
                                               (.01, 2, [])])
def test_review_scalar_fallback_is_finite_actual_delta_only(before, after, result):
    assert travel.review_preview({'clipping_before': before, 'clipping_after': after}) == result
