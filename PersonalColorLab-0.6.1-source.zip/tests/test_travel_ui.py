"""Real trip UI flows, persistent edits and bounded contact-sheet ownership."""
import hashlib
from pathlib import Path
import threading

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.travel_store import TravelStore
from test_source_workflow_ui import desktop, _pump, pytestmark


def _photos(folder,count=3):
    folder.mkdir()
    y,x=np.indices((140,220))
    for index in range(count):
        pixels=np.stack((55+x//3+index,50+y//3,60+x//5),axis=2).astype('uint8')
        Image.fromarray(pixels).save(folder/f'DSC{index:05d}.jpg',quality=95)
    return folder


def _open(app,folder):
    workspace=app.open_travel_workspace(folder=folder)
    _pump(app,lambda:not workspace._busy)
    assert workspace._photos,workspace.status.get()
    workspace.recognition.set(False);workspace.lens_correction.set(False);workspace._settings_changed()
    return workspace


def _ready(workspace):
    return (not workspace._preview_running and workspace._preview_after is None
            and workspace._preview is not None)


def test_trip_picks_photo_layers_real_preview_export_and_reopen(desktop,monkeypatch):
    app,tmp=desktop
    folder=_photos(tmp/'trip')
    originals={path:hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()}
    with LibraryDB(tmp/'data/library.db') as db:
        style_id=db.save_style_preset('My travel look',identity_dna('My travel look'))
    workspace=_open(app,folder)
    assert str(app.travel_btn.cget('state'))=='normal'
    assert 'saved:'+str(style_id) in workspace._styles
    ids=[row['id'] for row in workspace._photos]
    with TravelStore(workspace.db_path) as store:
        for photo_id in ids[:2]:store.update_photo(photo_id,group_id='test-shooting-group')
    workspace.load_project(workspace._project_id)
    workspace.grid_view.select_ids(ids[:2]);workspace.mark_pick('hold')
    workspace.grid_view.select_ids([ids[2]]);workspace.mark_pick('reject')
    workspace.grid_view.select_ids(ids[:2]);workspace.mark_pick('keep')
    workspace.exposure.set(.35);workspace.warmth.set(15);workspace.tint.set(-8)
    workspace.photo_strength.set(80);workspace._edits_changed();workspace.apply_to_group()
    workspace.notebook.select(workspace.compare)
    _pump(app,lambda:_ready(workspace))
    assert not np.array_equal(workspace._preview['original'],workspace._preview['rendered'])
    assert workspace._preview['photo_adjustments']['exposure_ev']==.35
    assert len(workspace._preview_images)==2
    assert not workspace._preview_cancel.is_set()
    with TravelStore(workspace.db_path) as store:
        rows=store.list_photos(workspace._project_id)
        assert [row['pick'] for row in rows]==['keep','keep','reject']
        assert rows[0]['adjustments']==rows[1]['adjustments']
        assert rows[2]['adjustments']['exposure_ev']==0
    worker_threads=[]
    from personal_color_lab.core import travel_jobs
    real_export=travel_jobs.export_jpeg
    def observed_export(*args,**kwargs):
        worker_threads.append(threading.current_thread())
        return real_export(*args,**kwargs)
    monkeypatch.setattr(travel_jobs,'export_jpeg',observed_export)
    workspace.destination=str(tmp/'exports')
    workspace.start_export(selected=True)
    _pump(app,lambda:not workspace._busy)
    assert len(list((tmp/'exports').glob('*.jpg')))==2,workspace.status.get()
    assert worker_threads and all(thread is not threading.main_thread() for thread in worker_threads)
    with TravelStore(workspace.db_path) as store:
        tasks=store.list_tasks(workspace._project_id)
        assert len(tasks)==2 and all(task['status']=='completed' for task in tasks)
        snapshots=[task['request'] for task in tasks]
    workspace.exposure.set(1.1);workspace._edits_changed();workspace._flush_edits()
    workspace.resume_exports();_pump(app,lambda:not workspace._busy)
    assert len(worker_threads)==2
    with TravelStore(workspace.db_path) as store:
        assert [task['request'] for task in store.list_tasks(workspace._project_id)]==snapshots
    project_id=workspace._project_id;workspace.close()
    reopened=app.open_travel_workspace(project_id=project_id)
    assert reopened._photos[0]['adjustments']['exposure_ev']==1.1
    assert len(reopened.tasks.get_children())==2
    assert not reopened._busy
    assert originals=={path:hashlib.sha256(path.read_bytes()).hexdigest() for path in originals}


def test_raw_only_folder_and_matching_jpg_are_one_navigation_source(desktop):
    app,tmp=desktop
    folder=tmp/'raw-trip';folder.mkdir()
    raw=write_test_dng(folder/'DSC00001.dng')
    Image.new('RGB',(180,120),(100,110,120)).save(folder/'DSC00001.jpg')
    digest=hashlib.sha256(raw.read_bytes()).hexdigest()
    workspace=_open(app,folder)
    assert len(workspace._photos)==1 and workspace._photos[0]['kind']=='raw'
    workspace.grid_view.select_ids([workspace._photos[0]['id']])
    workspace.notebook.select(workspace.compare)
    _pump(app,lambda:_ready(workspace))
    assert workspace._preview['raw_decode']
    assert workspace._preview['source_path']==str(raw)
    assert digest==hashlib.sha256(raw.read_bytes()).hexdigest()


@pytest.mark.parametrize('desktop',[1,1.5,2],indirect=True)
@pytest.mark.parametrize('language',['en','ko'])
def test_travel_minimum_layout_and_500_photo_grid_is_virtual(desktop,language):
    app,tmp=desktop;app.lang.set(language);app.change_language()
    workspace=app.open_travel_workspace()
    minimum=workspace.minsize();workspace.geometry(f'{minimum[0]}x{minimum[1]}')
    rows=[{'id':index+1,'source_path':str(tmp/f'photo-{index:04d}.jpg'),'pick':'keep',
        'size_bytes':123,'mtime_ns':index,'adjustments':{},'group_id':None} for index in range(500)]
    workspace._photos=rows;workspace._refresh_grid();workspace.empty.grid_remove()
    _pump(app,lambda:len(workspace.grid_view.visible_ids)>1)
    assert len(workspace.grid_view.visible_ids)<40
    assert len(workspace.grid_view.canvas.find_all())<250
    pixels=np.zeros((60,90,3),dtype=np.uint8)
    for photo_id in range(1,501):workspace.grid_view.set_thumbnail(photo_id,pixels)
    assert workspace.grid_view.image_count==64
    workspace.grid_view.canvas.yview_moveto(1);workspace.grid_view._schedule();app.update()
    assert max(workspace.grid_view.visible_ids)>450
    workspace.grid_view.select_ids([490,491]);assert workspace.grid_view.selection()==[490,491]
    assert workspace.title()==app.i18n.t('travel_title')
    assert workspace.new_btn.winfo_rootx()+workspace.new_btn.winfo_width()<=workspace.winfo_rootx()+workspace.winfo_width()+2
    assert workspace.export_btn.winfo_rootx()+workspace.export_btn.winfo_width()<=workspace.winfo_rootx()+workspace.winfo_width()+2
    assert workspace.cancel_btn.winfo_rooty()+workspace.cancel_btn.winfo_height()<=workspace.winfo_rooty()+workspace.winfo_height()+2
    assert workspace.grid_view.winfo_width()>200
    workspace.close()


def test_close_while_preview_and_thumbnail_jobs_are_active(desktop):
    app,tmp=desktop;workspace=_open(app,_photos(tmp/'closing-trip',8))
    workspace.grid_view.select_ids([workspace._photos[0]['id']]);workspace.notebook.select(workspace.compare)
    workspace._launch_preview()
    workspace.close();app.update()
    assert workspace._closed and workspace._stop.is_set() and workspace._preview_cancel.is_set()
    app.lang.set('ko');app.change_language()
    assert not app._travel_workspaces


def test_close_releases_tk_owners_before_worker_collection(desktop):
    import gc
    import weakref
    import tkinter as tk
    app,tmp=desktop
    gc.collect()
    workspace=app.open_travel_workspace()
    variable_refs=[weakref.ref(value) for value in vars(workspace).values() if isinstance(value,tk.Variable)]
    grid=workspace.grid_view
    workspace.close()
    assert all(reference() is None for reference in variable_refs)
    assert grid.canvas is None and grid.scroll is None
    assert all(not isinstance(value,tk.Misc) for name,value in vars(workspace).items() if name!='master')
    worker=threading.Thread(target=gc.collect)
    worker.start();worker.join(5)
    assert not worker.is_alive()


def test_current_photo_is_explicit_and_culling_does_not_render_raw_style(desktop,monkeypatch):
    app,tmp=desktop
    from personal_color_lab.core import style_render
    calls=[];render=style_render.render_preview
    def observed(*args,**kwargs):
        calls.append(args[0]);return render(*args,**kwargs)
    monkeypatch.setattr(style_render,'render_preview',observed)
    workspace=_open(app,_photos(tmp/'scope',3))
    ids=[row['id'] for row in workspace._photos]
    workspace.grid_view.select_ids(ids[:2],active_id=ids[1])
    workspace.exposure.set(.4);workspace.warmth.set(12);workspace._edits_changed();workspace._flush_edits()
    app.update()
    assert calls==[] and not workspace._preview_running and workspace._preview_after is None
    assert workspace._active_id==workspace.grid_view.active_id==ids[1]
    assert Path(workspace._photos[1]['source_path']).name in workspace.photo_label.cget('text')
    with TravelStore(workspace.db_path) as store:
        rows=store.list_photos(workspace._project_id)
        assert rows[0]['adjustments']['exposure_ev']==0
        assert rows[1]['adjustments']['exposure_ev']==.4
    assert workspace._value_labels['travel_exposure'].cget('text')=='+0.40 EV'
    assert workspace._value_labels['travel_warmth'].cget('text')=='+12%'
    assert str(workspace._value_labels['travel_exposure'].cget('anchor'))=='e'
    workspace.inspect_btn.invoke();_pump(app,lambda:_ready(workspace))
    assert calls==[workspace._photos[1]['source_path']]


def test_filtered_empty_actions_and_explicit_group_scope(desktop):
    app,tmp=desktop;workspace=_open(app,_photos(tmp/'groups',3))
    ids=[row['id'] for row in workspace._photos]
    assert str(workspace.resume_btn.cget('state'))==str(workspace.retry_btn.cget('state'))=='disabled'
    assert str(workspace.export_selected_btn.cget('state'))=='disabled'
    workspace.filter.set(app.i18n.t('travel_filter_hold'));workspace._refresh_grid();app.update()
    assert workspace.empty.winfo_ismapped() and not workspace.grid_view.rows
    assert workspace.empty_title.cget('text')==app.i18n.t('travel_filter_empty_title')
    workspace.empty_btn.invoke();app.update();assert len(workspace.grid_view.rows)==3
    with TravelStore(workspace.db_path) as store:
        for photo_id in ids[:2]:store.update_photo(photo_id,group_id='shooting-group')
    workspace.load_project(workspace._project_id)
    workspace.grid_view.select_ids([ids[1]])
    assert workspace.select_group_btn.cget('text')==app.i18n.t('travel_select_group_count',count=2)
    workspace.select_group_btn.invoke()
    assert workspace.grid_view.selection()==ids[:2] and workspace._active_id==ids[1]
    assert workspace._photos[0]['_group_number']==workspace._photos[1]['_group_number']==1
    workspace.grid_view.select_ids(ids);workspace.mark_pick('reject')
    assert str(workspace.export_btn.cget('state'))==str(workspace.export_selected_btn.cget('state'))=='disabled'
    assert workspace.export_btn.cget('text')==app.i18n.t('travel_export_keep_count',count=0)


def test_export_queue_updates_while_running_and_locks_mutating_shortcuts(desktop,monkeypatch):
    app,tmp=desktop;workspace=_open(app,_photos(tmp/'live-queue',2))
    from personal_color_lab.core import travel_jobs
    entered=threading.Event();release=threading.Event();render=travel_jobs.export_jpeg
    def blocked(*args,**kwargs):
        entered.set();assert release.wait(10)
        return render(*args,**kwargs)
    monkeypatch.setattr(travel_jobs,'export_jpeg',blocked)
    ids=[row['id'] for row in workspace._photos]
    workspace.grid_view.select_ids([ids[0]])
    workspace.destination=str(tmp/'live-exports');workspace.start_export(selected=True)
    try:
        _pump(app,lambda:entered.is_set())
        _pump(app,lambda:any(workspace.tasks.item(iid,'values')[1]==app.i18n.t('travel_task_running') for iid in workspace.tasks.get_children()))
        assert workspace._busy and str(workspace.resume_btn.cget('state'))=='disabled'
        assert str(workspace._pick_buttons['reject'].cget('state'))=='disabled'
        workspace.grid_view._pick('reject')
        with TravelStore(workspace.db_path) as store:assert store.get_photo(ids[0])['pick']=='keep'
    finally:release.set()
    _pump(app,lambda:not workspace._busy)
    assert workspace._task_counts['completed']==1
    assert str(workspace.resume_btn.cget('state'))==str(workspace.retry_btn.cget('state'))=='disabled'
    assert workspace.destination_path.cget('text')==str(tmp/'live-exports')


@pytest.mark.parametrize('failure',['missing','corrupt'])
def test_queue_failures_explain_next_action_and_distinguish_preparation(desktop,failure):
    app,tmp=desktop;workspace=_open(app,_photos(tmp/'failure-queue',2))
    source=Path(workspace._photos[0]['source_path'])
    if failure=='missing':source.unlink()
    else:source.write_bytes(b'corrupt-photo')
    workspace.destination=str(tmp/'failure-exports');workspace.start_export()
    _pump(app,lambda:not workspace._busy)
    assert workspace._task_counts['completed']==1
    assert len(workspace.tasks.get_children())==2
    prefix='prepare-' if failure=='missing' else 'task-'
    expected=app.i18n.t('travel_queue_error_source_unavailable' if failure=='missing' else 'travel_queue_error_render_failed')
    row=next(iid for iid in workspace.tasks.get_children() if iid.startswith(prefix) and workspace.tasks.item(iid,'values')[2]==expected)
    workspace.tasks.selection_set(row);workspace._queue_selection_changed();app.update()
    assert workspace.queue_detail.cget('text')==expected
    assert str(workspace.retry_btn.cget('state'))==('disabled' if failure=='missing' else 'normal')
    assert not list((tmp/'failure-exports').glob('.pcl-task-*'))


def test_visible_cells_request_evicted_images_without_scrolling(desktop):
    app,tmp=desktop;workspace=app.open_travel_workspace()
    requests=[];grid=workspace.grid_view
    grid.on_visible=lambda rows:requests.append([row['id'] for row in rows])
    workspace._photos=[{'id':index+1,'source_path':str(tmp/f'photo-{index:04d}.jpg'),'pick':'keep',
        'size_bytes':12,'mtime_ns':index,'adjustments':{},'group_id':None} for index in range(200)]
    workspace._refresh_grid();_pump(app,lambda:len(grid.visible_ids)>1)
    visible=grid.visible_ids;pixels=np.zeros((60,90,3),dtype=np.uint8)
    for photo_id in visible:grid.set_thumbnail(photo_id,pixels)
    app.update();requests.clear()
    for photo_id in range(100,180):grid.set_thumbnail(photo_id,pixels)
    app.update()
    assert grid.visible_ids==visible
    assert all(photo_id not in grid._images for photo_id in visible)
    assert requests and requests[-1]==list(visible)


def test_queue_presentation_does_not_parse_frozen_style_requests_on_tk(desktop,monkeypatch):
    app,tmp=desktop;workspace=_open(app,_photos(tmp/'queue-metadata',2))
    from personal_color_lab.core.travel_jobs import enqueue_exports
    enqueue_exports(workspace.db_path,workspace._project_id,identity_dna(),tmp/'metadata-exports',recognition=False,lens_correction=False)
    def forbidden(*args,**kwargs):raise AssertionError('UI refresh parsed all frozen Style DNA requests')
    monkeypatch.setattr(TravelStore,'list_tasks',forbidden)
    workspace._refresh_tasks()
    assert len(workspace.tasks.get_children())==2 and workspace._task_counts['pending']==2
    assert str(workspace.resume_btn.cget('state'))=='normal'
