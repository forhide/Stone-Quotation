"""Additive migrations for the local library, including untouched V0.1 rows."""

import sqlite3


CURRENT_SCHEMA_VERSION = 4

# Original V0.1 schema: fresh and existing libraries share one upgrade path.
SCHEMA = '''
CREATE TABLE IF NOT EXISTS photos (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    ext TEXT NOT NULL,
    kind TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    width INTEGER,
    height INTEGER,
    capture_time TEXT,
    camera TEXT,
    lens TEXT,
    fingerprint TEXT,
    imported_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS pairs (
    id INTEGER PRIMARY KEY,
    original_path TEXT NOT NULL,
    edited_path TEXT NOT NULL,
    pair_type TEXT NOT NULL,
    confidence REAL NOT NULL,
    reasons TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(original_path, edited_path, pair_type)
);
CREATE TABLE IF NOT EXISTS scene_tags (
    photo_path TEXT PRIMARY KEY,
    day REAL, night REAL, indoor REAL, outdoor REAL,
    portrait REAL, landscape REAL, food REAL, street REAL,
    architecture REAL, still_life REAL,
    FOREIGN KEY(photo_path) REFERENCES photos(path)
);
CREATE TABLE IF NOT EXISTS edit_analysis (
    id INTEGER PRIMARY KEY,
    original_path TEXT,
    edited_path TEXT,
    source_type TEXT,
    confidence REAL,
    payload_json TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS styles (
    id INTEGER PRIMARY KEY,
    style_name TEXT UNIQUE NOT NULL,
    source_type TEXT NOT NULL,
    global_dna_json TEXT,
    tone_dna_json TEXT,
    color_dna_json TEXT,
    composition_dna_json TEXT,
    dataset_size INTEGER DEFAULT 0,
    coverage_json TEXT,
    confidence REAL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
'''


class SchemaMigrationError(RuntimeError):
    """The library schema cannot be safely used by this application version."""


def _add_versioned_analysis(conn: sqlite3.Connection) -> None:
    columns = {row[1] for row in conn.execute('PRAGMA table_info(edit_analysis)')}
    for name, kind in (
        ('schema_version', 'INTEGER'),
        ('algorithm_version', 'TEXT'),
        ('status', 'TEXT'),
        ('updated_at', 'TEXT'),
    ):
        if name not in columns:
            conn.execute(f'ALTER TABLE edit_analysis ADD COLUMN {name} {kind}')
    # Legacy/sparse rows remain outside the unique index. Their payloads are
    # never guessed, rewritten, or discarded.
    conn.execute('''
        CREATE UNIQUE INDEX IF NOT EXISTS edit_analysis_pair_version
        ON edit_analysis(original_path, edited_path, schema_version, algorithm_version)
        WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
    ''')
    conn.execute('''
        CREATE INDEX IF NOT EXISTS edit_analysis_pair_latest
        ON edit_analysis(original_path, edited_path, updated_at DESC, id DESC)
        WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
    ''')


def _add_source_profiles(conn: sqlite3.Connection) -> None:
    conn.execute('''
        CREATE TABLE source_profiles (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            mode TEXT NOT NULL CHECK(mode IN ('raw_jpg', 'raw_xmp', 'reference_jpg')),
            payload_json TEXT NOT NULL,
            created_at_utc TEXT NOT NULL,
            updated_at_utc TEXT NOT NULL
        )
    ''')
    conn.execute('''
        CREATE INDEX source_profiles_latest
        ON source_profiles(updated_at_utc DESC, id DESC)
    ''')


def _add_style_runtime(conn: sqlite3.Connection) -> None:
    conn.execute('''CREATE TABLE analysis_cache (
        cache_key TEXT PRIMARY KEY, payload_json TEXT NOT NULL,
        accessed_at_utc TEXT NOT NULL
    )''')
    conn.execute('CREATE INDEX analysis_cache_lru ON analysis_cache(accessed_at_utc)')
    conn.execute('''CREATE TABLE style_presets (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL, dna_json TEXT NOT NULL,
        created_at_utc TEXT NOT NULL, updated_at_utc TEXT NOT NULL
    )''')


def _add_travel_workspace(conn: sqlite3.Connection) -> None:
    """Keep travel state separate from reusable learning evidence."""
    conn.execute('''CREATE TABLE travel_projects (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL, root_path TEXT NOT NULL,
        recursive INTEGER NOT NULL CHECK(recursive IN (0,1)),
        settings_json TEXT NOT NULL,
        created_at_utc TEXT NOT NULL, updated_at_utc TEXT NOT NULL
    )''')
    conn.execute('''CREATE TABLE travel_photos (
        id INTEGER PRIMARY KEY,
        project_id INTEGER NOT NULL REFERENCES travel_projects(id) ON DELETE CASCADE,
        source_path TEXT NOT NULL, relative_path TEXT NOT NULL, kind TEXT NOT NULL,
        size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
        mtime_ns INTEGER NOT NULL CHECK(mtime_ns >= 0),
        capture_time TEXT, width INTEGER, height INTEGER,
        pick TEXT NOT NULL DEFAULT 'keep' CHECK(pick IN ('keep','hold','reject')),
        adjustments_json TEXT NOT NULL, scene_override_json TEXT NOT NULL,
        group_id TEXT, created_at_utc TEXT NOT NULL, updated_at_utc TEXT NOT NULL,
        UNIQUE(project_id,source_path)
    )''')
    conn.execute('CREATE INDEX travel_photos_project ON travel_photos(project_id,id)')
    conn.execute('''CREATE TABLE travel_tasks (
        id INTEGER PRIMARY KEY,
        project_id INTEGER NOT NULL REFERENCES travel_projects(id) ON DELETE CASCADE,
        photo_id INTEGER NOT NULL REFERENCES travel_photos(id) ON DELETE CASCADE,
        status TEXT NOT NULL DEFAULT 'pending'
            CHECK(status IN ('pending','running','ready','completed','failed')),
        request_key TEXT NOT NULL, request_json TEXT NOT NULL,
        destination TEXT NOT NULL, stage_path TEXT,
        source_sha256 TEXT, output_sha256 TEXT, error_code TEXT,
        attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
        owner_token TEXT, created_at_utc TEXT NOT NULL, updated_at_utc TEXT NOT NULL,
        UNIQUE(project_id,request_key)
    )''')
    conn.execute('CREATE INDEX travel_tasks_project_status ON travel_tasks(project_id,status,id)')
    conn.execute('''CREATE TABLE travel_leases (
        project_id INTEGER PRIMARY KEY REFERENCES travel_projects(id) ON DELETE CASCADE,
        token TEXT NOT NULL, expires_at REAL NOT NULL, heartbeat REAL NOT NULL
    )''')


def migrate_schema(conn: sqlite3.Connection) -> None:
    """Create or upgrade a library atomically; refuse unknown newer schemas."""
    version = conn.execute('PRAGMA user_version').fetchone()[0]
    if version > CURRENT_SCHEMA_VERSION:
        raise SchemaMigrationError(
            f'Library schema {version} is newer than supported schema '
            f'{CURRENT_SCHEMA_VERSION}.'
        )
    if conn.in_transaction:
        raise SchemaMigrationError('Cannot migrate a library inside an active transaction.')
    conn.execute('PRAGMA journal_mode=WAL')
    if version == CURRENT_SCHEMA_VERSION:
        return
    # SQLite does not implicitly begin a transaction for DDL statements.
    # Explicit BEGIN prevents a failed ALTER/index from leaving a half-upgrade.
    try:
        conn.execute('BEGIN IMMEDIATE')
        if version < 1:
            for statement in SCHEMA.split(';'):
                if statement.strip():
                    conn.execute(statement)
            _add_versioned_analysis(conn)
        if version < 2:
            _add_source_profiles(conn)
        if version < 3:
            _add_style_runtime(conn)
        if version < 4:
            _add_travel_workspace(conn)
        conn.execute(f'PRAGMA user_version={CURRENT_SCHEMA_VERSION}')
        conn.commit()
    except sqlite3.DatabaseError as exc:
        conn.rollback()
        raise SchemaMigrationError(
            'Library schema migration failed; existing records were preserved.'
        ) from exc
    except Exception:
        conn.rollback()
        raise
