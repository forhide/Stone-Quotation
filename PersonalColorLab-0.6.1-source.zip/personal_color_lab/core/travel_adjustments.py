"""Temporary photo corrections, kept separate from a saved photographic look.

Warmth and tint are relative display-referred corrections, not a recovered
camera Kelvin value. The style-strength multiplier belongs to the caller;
exposure and color corrections apply once after the selected style.
"""
from __future__ import annotations

import math

import cv2
import numpy as np

from .analysis_control import check_cancel

DEFAULT_ADJUSTMENTS = {'exposure_ev': 0.0, 'temperature': 0.0, 'tint': 0.0, 'strength': 1.0}
ADJUSTMENT_RANGES = {'exposure_ev': (-3., 3.), 'temperature': (-1., 1.), 'tint': (-1., 1.), 'strength': (0., 1.)}
_MAX_TILE_PIXELS = 160_000


def validate_adjustments(value=None):
    """Return a fresh, finite, strictly whitelisted photo-correction snapshot."""
    if value is None:
        return dict(DEFAULT_ADJUSTMENTS)
    if not isinstance(value, dict) or set(value) - set(DEFAULT_ADJUSTMENTS):
        raise ValueError('Invalid photo adjustment fields.')
    result = dict(DEFAULT_ADJUSTMENTS)
    for name, setting in value.items():
        low, high = ADJUSTMENT_RANGES[name]
        if isinstance(setting, bool) or not isinstance(setting, (int, float)) or not math.isfinite(setting) or not low <= setting <= high:
            raise ValueError('Photo adjustment is outside its supported range.')
        result[name] = float(setting)
    return result


def effective_strength(global_strength, adjustments=None):
    if isinstance(global_strength, bool) or not isinstance(global_strength, (int, float)) or not math.isfinite(global_strength) or not 0 <= global_strength <= 1:
        raise ValueError('Invalid global style strength.')
    return float(global_strength * validate_adjustments(adjustments)['strength'])


def apply_photo_adjustments(pixels, adjustments=None, cancel_event=None):
    """Correct an owned RGB copy in bounded tiles without modifying the look."""
    settings = validate_adjustments(adjustments)
    if not isinstance(pixels, np.ndarray) or pixels.dtype != np.uint8 or pixels.ndim != 3 or pixels.shape[2] != 3 or min(pixels.shape[:2]) < 1:
        raise ValueError('Photo corrections require nonempty uint8 RGB pixels.')
    check_cancel(cancel_event)
    if not any(settings[key] for key in ('exposure_ev', 'temperature', 'tint')):
        return pixels.copy()
    levels = np.arange(256, dtype=np.float64) / 255.
    exposure_lut = None
    if settings['exposure_ev']:
        linear = np.where(levels <= .04045, levels / 12.92, ((levels + .055) / 1.055) ** 2.4)
        linear *= 2 ** settings['exposure_ev']
        exposure_lut = np.clip(np.where(linear <= .0031308, linear * 12.92, 1.055 * np.maximum(linear, 0) ** (1 / 2.4) - .055), 0, 1).astype(np.float32)
    color_shift = bool(settings['temperature'] or settings['tint'])
    result = np.empty_like(pixels)
    width = pixels.shape[1]
    tile_width = min(width, _MAX_TILE_PIXELS)
    rows = max(1, _MAX_TILE_PIXELS // tile_width)
    for top in range(0, pixels.shape[0], rows):
        for left in range(0, width, tile_width):
            check_cancel(cancel_event)
            source = pixels[top:top + rows, left:left + tile_width]
            rgb = exposure_lut[source] if exposure_lut is not None else source.astype(np.float32) / 255.
            if color_shift:
                lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
                lab[:, :, 1] += settings['tint'] * 8.
                lab[:, :, 2] += settings['temperature'] * 8.
                rgb = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
            result[top:top + rows, left:left + tile_width] = np.rint(np.clip(rgb, 0, 1) * 255).astype(np.uint8)
    check_cancel(cancel_event)
    return result
