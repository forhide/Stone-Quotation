"""Bounded trip discovery, conservative shooting groups and result review.

Discovery reads selected header fields, never RAW pixels or whole-file hashes.
Groups are local editing suggestions, not independent style-training samples.
No GPS, face identity or complete metadata document is returned or retained.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct

import cv2
import numpy as np

from .analysis_control import AnalysisCancelledError, check_cancel
from .constants import JPEG_EXTENSIONS, RAW_EXTENSIONS
from .lens_metadata import _BoundedReader, _MetadataLimit, _Segment

MAX_GROUP_SIZE = 24
MAX_HEADER_BYTES = 128 * 1024
MAX_HEADER_OPERATIONS = 6000
GROUP_VERSION = 1
REVIEW_CODES = frozenset({'travel_review_highlights', 'travel_review_clipping',
                          'travel_review_color_change'})
_CANON_UUID = bytes.fromhex('85c0b687820f11e08111f4ce462b6a48')
_TEXT_TAGS = {0x9003, 0x9011, 0x9291}
_NUMBER_TAGS = {0x100, 0x101, 0x112, 0xA002, 0xA003}
_POINTER_TAGS = {0x8769, 0x14A}
_OWNED_DIRECTORIES = {'.personal_color_lab', '.pcl-cache', '.pcl-preview-cache',
                      'pcl_exports', 'pcl-exports', 'personalcolorlab-exports'}
_LUMA = np.array([.2126, .7152, .0722], np.float32)


class _HeaderReader(_BoundedReader):
    def _operation(self):
        super()._operation()
        if self.operations > MAX_HEADER_OPERATIONS:
            raise _MetadataLimit('Travel metadata operation limit.')

    def read(self, size=-1):
        if not isinstance(size, int) or size < 0 or self.bytes_read + size > MAX_HEADER_BYTES:
            raise _MetadataLimit('Travel metadata byte limit.')
        return super().read(size)


@lru_cache(maxsize=1)
def _travel_header():
    # ExifRead's public process_file would traverse GPS and MakerNote data.
    # Filter before decoding a tag, using its already-pinned header parser.
    from exifread.core.exif_header import ExifHeader

    class TravelHeader(ExifHeader):
        def __init__(self, stream, endian):
            super().__init__(stream, endian, 0, 0, strict=True, detailed=False)
            self.visited = set()

        def dump_ifd(self, ifd, ifd_name, tag_dict=None, relative=0, stop_tag='UNDEF'):
            if ifd in self.visited:
                return
            if len(self.visited) >= 8 or self.s2n(ifd, 2) > 512:
                raise _MetadataLimit('Travel metadata IFD limit.')
            self.visited.add(ifd)
            return super().dump_ifd(ifd, ifd_name, tag_dict, relative, stop_tag)

        def _process_tag(self, ifd, ifd_name, tag_entry, entry, tag, tag_name, relative, stop_tag):
            if tag not in _TEXT_TAGS | _NUMBER_TAGS | _POINTER_TAGS:
                return
            kind, count = self.s2n(entry + 2, 2), self.s2n(entry + 4, 4)
            if tag in _TEXT_TAGS and (kind != 2 or not 1 <= count <= 40):
                return
            if tag in _NUMBER_TAGS and (kind not in (3, 4) or count != 1):
                return
            if tag in _POINTER_TAGS and (kind != 4 or not 1 <= count <= 8):
                return
            return super()._process_tag(ifd, ifd_name, tag_entry, entry, tag, tag_name, relative, stop_tag)

    return TravelHeader


def _values(header, *names):
    for name in names:
        value = header.tags.get(name)
        if value is not None:
            return value.values
    return None


def _text(value):
    if isinstance(value, str):
        return value.strip().strip('\0')
    if isinstance(value, bytes):
        try:
            return value.decode('ascii').strip().strip('\0')
        except UnicodeDecodeError:
            return None
    return None


def _date_value(date, offset=None, subseconds=None):
    date = _text(date)
    if date is None or re.fullmatch(r'\d{4}:\d{2}:\d{2} \d{2}:\d{2}:\d{2}', date) is None:
        return None
    try:
        value = datetime.strptime(date, '%Y:%m:%d %H:%M:%S')
        if not 1900 <= value.year <= 2200:
            return None
        sub = _text(subseconds)
        if sub and re.fullmatch(r'\d{1,12}', sub):
            value = value.replace(microsecond=int(sub[:6].ljust(6, '0')))
        zone = _text(offset)
        if zone:
            if re.fullmatch(r'[+-]\d{2}:\d{2}', zone) is None:
                return None
            hour, minute = int(zone[1:3]), int(zone[4:6])
            if hour > 14 or minute > 59 or hour == 14 and minute:
                return None
            minutes = (hour * 60 + minute) * (-1 if zone[0] == '-' else 1)
            value = value.replace(tzinfo=timezone(timedelta(minutes=minutes)))
        return value.isoformat(timespec='microseconds' if value.microsecond else 'seconds')
    except (ValueError, OverflowError):
        return None


def _dimension(value):
    if isinstance(value, list) and len(value) == 1:
        value = value[0]
    return int(value) if type(value) is int and 1 <= value <= 120_000 else None


def _read_tiff(segment, *, exif_only=False):
    segment.seek(0)
    initial = segment.read(8)
    endian = initial[:2]
    if endian not in (b'II', b'MM'):
        raise ValueError('Unsupported travel TIFF byte order.')
    magic, first = struct.unpack(('<' if endian == b'II' else '>') + 'HI', initial[2:])
    if magic not in (42, 0x4F52, 0x5352, 85):
        raise ValueError('Unsupported travel TIFF layout.')
    header = _travel_header()(segment, chr(endian[0]))
    header.dump_ifd(first, 'EXIF' if exif_only else 'Image')
    if not exif_only:
        for pointer, name in ((0x8769, 'Image ExifOffset'), (0x14A, 'Image SubIFDs')):
            for index, offset in enumerate(_values(header, name) or []):
                header.dump_ifd(int(offset), 'EXIF' if pointer == 0x8769 else f'EXIF SubIFD{index}')
    names = ['EXIF', 'Image'] + [f'EXIF SubIFD{i}' for i in range(8)]
    capture = _date_value(_values(header, *[n + ' DateTimeOriginal' for n in names]),
                          _values(header, *[n + ' OffsetTimeOriginal' for n in names]),
                          _values(header, *[n + ' SubSecTimeOriginal' for n in names]))
    width = _dimension(_values(header, 'EXIF ExifImageWidth', 'Image ImageWidth'))
    height = _dimension(_values(header, 'EXIF ExifImageLength', 'Image ImageLength'))
    orientation = _dimension(_values(header, 'Image Orientation', 'EXIF Orientation'))
    if width and height and width * height > 120_000_000:
        width = height = None
    return {'capture_time': capture, 'width': width, 'height': height, '_orientation': orientation}


def _jpeg_info(reader, start, size):
    stream = _Segment(reader, start, size)
    if stream.read(2) != b'\xff\xd8':
        raise ValueError('Unsupported travel JPEG header.')
    exif = None
    width = height = None
    for _ in range(128):
        marker = stream.read(2)
        if marker[0] != 255:
            raise ValueError('Invalid travel JPEG marker.')
        if marker[1] in (0xD9, 0xDA):
            break
        if marker[1] == 255:
            stream.seek(-1, 1)
            continue
        if marker[1] in (0x01, *range(0xD0, 0xD9)):
            continue
        length = int.from_bytes(stream.read(2), 'big')
        payload = stream.tell()
        if length < 2 or payload + length - 2 > size:
            raise ValueError('Invalid travel JPEG segment.')
        if marker[1] == 0xE1 and length >= 16 and stream.read(6) == b'Exif\0\0' and exif is None:
            exif = _Segment(reader, start + payload + 6, length - 8)
        if marker[1] in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF} and length >= 8:
            data = stream.read(5)
            height, width = struct.unpack('>HH', data[1:])
        stream.seek(payload + length - 2)
    return exif, width, height


def _cr3_segments(reader):
    result = []
    visited = 0
    def walk(start, end, depth):
        nonlocal visited
        offset = start
        if depth > 4:
            raise _MetadataLimit('Travel CR3 nesting limit.')
        while offset + 8 <= end:
            visited += 1
            if visited > 512:
                raise _MetadataLimit('Travel CR3 box limit.')
            reader.seek(offset)
            size, kind = struct.unpack('>I4s', reader.read(8))
            header = 8
            if size == 1:
                size, header = struct.unpack('>Q', reader.read(8))[0], 16
            elif size == 0:
                size = end - offset
            if size < header or offset + size > end:
                raise ValueError('Invalid travel CR3 box.')
            payload = offset + header
            if kind == b'moov' and depth == 0:
                walk(payload, offset + size, depth + 1)
            elif kind == b'uuid' and depth == 1 and size - header >= 16:
                reader.seek(payload)
                if reader.read(16) == _CANON_UUID:
                    walk(payload + 16, offset + size, depth + 1)
            elif kind in (b'CMT1', b'CMT2') and depth == 2:
                if len(result) >= 4:
                    raise _MetadataLimit('Travel CR3 duplicate metadata.')
                result.append((_Segment(reader, payload, size - header), kind == b'CMT2'))
            offset += size
        if offset != end:
            raise ValueError('Truncated travel CR3 box.')
    walk(0, reader.size, 0)
    return result


def _metadata(path, size, cancel_event):
    result = {'capture_time': None, 'width': None, 'height': None}
    orientation = None
    with path.open('rb') as handle:
        reader = _HeaderReader(handle, size, cancel_event)
        try:
            prefix = reader.read(min(12, size))
            segments = []
            if prefix.startswith(b'\xff\xd8'):
                segment, result['width'], result['height'] = _jpeg_info(reader, 0, size)
                if segment:
                    segments.append((segment, False))
            elif prefix.startswith(b'FUJIFILMCCD-'):
                reader.seek(84)
                start, length = struct.unpack('>II', reader.read(8))
                segment, _, _ = _jpeg_info(reader, start, length)
                if segment:
                    segments.append((segment, False))
            elif prefix[:2] in (b'II', b'MM'):
                segments.append((_Segment(reader, 0, size), False))
            elif len(prefix) >= 8 and prefix[4:8] == b'ftyp':
                segments.extend(_cr3_segments(reader))
            for segment, exif_only in segments:
                values = _read_tiff(segment, exif_only=exif_only)
                for key in result:
                    if values[key] is not None and (key == 'capture_time' or result[key] is None):
                        result[key] = values[key]
                if values['_orientation'] is not None:
                    orientation = values['_orientation']
        except AnalysisCancelledError:
            raise
        except (_MetadataLimit, ValueError, struct.error, IndexError, KeyError, TypeError, OverflowError):
            # Unsupported/invalid optional metadata is not a sensor failure.
            # Permission/read/disconnection errors intentionally propagate.
            pass
    if result['width'] and result['height'] and result['width'] * result['height'] > 120_000_000:
        result['width'] = result['height'] = None
    if orientation in (5, 6, 7, 8):
        result['width'], result['height'] = result['height'], result['width']
    return result


def _natural(value):
    return tuple(int(part) if index % 2 else part.casefold()
                 for index, part in enumerate(re.split(r'(\d+)', str(value))))


def _capture(value):
    if not isinstance(value, str) or len(value) > 40:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed if 1900 <= parsed.year <= 2200 else None
    except ValueError:
        return None


def _sort_key(photo):
    stamp = _capture(photo.get('capture_time'))
    if stamp is None:
        return (1, 0, 0, _natural(photo.get('relative_path', photo.get('source_path', ''))))
    aware = stamp.utcoffset() is not None
    if aware:
        stamp = stamp.astimezone(timezone.utc).replace(tzinfo=None)
    seconds = (stamp.toordinal() * 86400 + stamp.hour * 3600 + stamp.minute * 60
               + stamp.second + stamp.microsecond / 1_000_000)
    return (0, int(not aware), seconds, _natural(photo.get('relative_path', photo.get('source_path', ''))))


def scan_travel_folder(folder, recursive=True, *, cancel_event=None, progress=None):
    """List RAW/JPG originals without decoding pixels or hashing whole files.

    Exact-stem JPG companions in the same directory are represented by their
    RAW. Symlink directories and hidden/app-owned caches/exports are skipped.
    Invalid optional camera metadata yields unknown values; directory/file I/O
    failures and changes during discovery raise rather than claiming success.
    """
    if type(recursive) is not bool:
        raise ValueError('Invalid recursive travel scan choice.')
    check_cancel(cancel_event)
    root = Path(folder).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise NotADirectoryError(str(root))
    found = []
    seen = set()
    def walk(directory):
        check_cancel(cancel_event)
        with os.scandir(directory) as iterator:
            entries = sorted(iterator, key=lambda entry: _natural(entry.name))
        for entry in entries:
            check_cancel(cancel_event)
            if entry.name.startswith('.'):
                continue
            if entry.is_dir(follow_symlinks=False):
                if recursive and entry.name.casefold() not in _OWNED_DIRECTORIES:
                    walk(Path(entry.path))
                continue
            if entry.is_symlink():
                resolved = Path(entry.path).resolve(strict=True)
                if not resolved.is_relative_to(root) or not resolved.is_file():
                    continue
            else:
                if not entry.is_file(follow_symlinks=False):
                    continue
                resolved = Path(entry.path).resolve(strict=True)
            if any(part.startswith('.') or part.casefold() in _OWNED_DIRECTORIES
                   for part in resolved.relative_to(root).parts[:-1]):
                continue
            extension = resolved.suffix.casefold()
            if extension not in RAW_EXTENSIONS | JPEG_EXTENSIONS or resolved in seen:
                continue
            seen.add(resolved)
            stat = resolved.stat()
            found.append((resolved, stat, 'raw' if extension in RAW_EXTENSIONS else 'jpg'))
    walk(root)
    raw_names = {(path.parent, path.stem.casefold()) for path, _, kind in found if kind == 'raw'}
    found = [(path, stamp, kind) for path, stamp, kind in found
             if kind == 'raw' or (path.parent, path.stem.casefold()) not in raw_names]
    photos = []
    for index, (path, before, kind) in enumerate(found, 1):
        check_cancel(cancel_event)
        metadata = _metadata(path, before.st_size, cancel_event)
        after = path.stat()
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise ValueError('Photo changed during travel discovery.')
        photos.append({'source_path': str(path), 'relative_path': path.relative_to(root).as_posix(),
                       'kind': kind, 'size_bytes': after.st_size, 'mtime_ns': after.st_mtime_ns,
                       **metadata})
        if progress is not None:
            progress(index, len(found), path.name)
    check_cancel(cancel_event)
    return sorted(photos, key=_sort_key)


def _photo_key(photo):
    identifier = photo.get('id')
    if (type(identifier) is int and identifier > 0) or (isinstance(identifier, str) and identifier):
        return identifier
    path = photo.get('source_path')
    if not isinstance(path, str) or not path:
        raise ValueError('A travel photo needs an id or source path.')
    return path


def _thumbnail(previews, photo):
    value = previews.get(_photo_key(photo))
    if value is None and photo.get('source_path') is not None:
        value = previews.get(photo['source_path'])
    if isinstance(value, dict):
        value = value.get('pixels')
    if not isinstance(value, np.ndarray) or value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 3 or min(value.shape[:2]) < 8:
        return None
    return value


def _visual_feature(pixels):
    rgb = cv2.resize(pixels, (64, 48), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    y = rgb @ _LUMA
    small = cv2.resize(y, (17, 16), interpolation=cv2.INTER_AREA)
    bits = (small[:, 1:] > small[:, :-1]).ravel()
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    weights = hsv[:, :, 1].ravel()
    hist = np.bincount(np.minimum((hsv[:, :, 0].ravel() / 15).astype(int), 23),
                       weights=weights, minlength=24).astype(np.float64)
    hist /= max(float(hist.sum()), 1e-9)
    means = rgb.mean(axis=(0, 1)).astype(np.float64)
    chromaticity = means / max(float(means.sum()), .02)
    return {'median': float(np.median(y)), 'chroma': chromaticity,
            'hist': hist, 'bits': bits}


def _visual_close(a, b, *, strict=False):
    return (abs(a['median'] - b['median']) <= (.10 if strict else .14)
            and float(np.abs(a['chroma'] - b['chroma']).sum()) <= .16
            and float(np.abs(a['hist'] - b['hist']).sum()) / 2 <= .28
            and float(np.mean(a['bits'] != b['bits'])) <= (.18 if strict else .30))


def _time_gap(first, second):
    a, b = _capture(first.get('capture_time')), _capture(second.get('capture_time'))
    if a is None or b is None or (a.utcoffset() is None) != (b.utcoffset() is None):
        return None
    return (b - a).total_seconds()


def _same_sequence(a, b):
    first = Path(a.get('relative_path', a.get('source_path', '')))
    second = Path(b.get('relative_path', b.get('source_path', '')))
    one = re.fullmatch(r'(.*?)(\d+)', first.stem)
    two = re.fullmatch(r'(.*?)(\d+)', second.stem)
    return bool(first.parent == second.parent and one and two and one[1].casefold() == two[1].casefold()
                and int(two[2]) - int(one[2]) == 1)


def suggest_groups(photos, previews=None, *, cancel_event=None):
    """Suggest bounded adjacent shooting groups in O(n log n), not all pairs.

    Time is an ordering/grouping cue, never evidence of day/night. Missing
    timestamps and previews permit only weak short filename sequences. A
    group must remain close to its first frame, preventing transition chains.
    """
    check_cancel(cancel_event)
    photos = list(photos)
    if any(not isinstance(photo, dict) for photo in photos):
        raise ValueError('Travel groups require photo records.')
    keys = [_photo_key(photo) for photo in photos]
    if len(set(keys)) != len(keys):
        raise ValueError('Travel groups require distinct photo identities.')
    if previews is None:
        previews = {}
    if not isinstance(previews, dict):
        raise ValueError('Invalid travel preview mapping.')
    ordered = sorted(photos, key=_sort_key)
    features = {}
    for photo in ordered:
        check_cancel(cancel_event)
        pixels = _thumbnail(previews, photo)
        features[_photo_key(photo)] = _visual_feature(pixels) if pixels is not None else None
    chunks = []
    current = []
    confidences = []
    reasons = []
    for photo in ordered:
        check_cancel(cancel_event)
        compatible = False
        reason, confidence = 'single', 0.
        if current and len(current) < MAX_GROUP_SIZE:
            last, anchor = current[-1], current[0]
            gap, span = _time_gap(last, photo), _time_gap(anchor, photo)
            feature = features[_photo_key(photo)]
            previous, origin = features[_photo_key(last)], features[_photo_key(anchor)]
            visual = feature is not None and previous is not None and origin is not None
            if gap is not None:
                if 0 <= gap <= 180 and span is not None and span <= 600:
                    if visual:
                        compatible = _visual_close(previous, feature) and _visual_close(origin, feature)
                        reason, confidence = 'time_visual', .82
                    elif gap <= 15 and len(current) < 8:
                        compatible = True
                        reason, confidence = 'sequence', .35
            elif not _capture(last.get('capture_time')) and not _capture(photo.get('capture_time')):
                if visual:
                    compatible = _visual_close(previous, feature, strict=True) and _visual_close(origin, feature, strict=True)
                    reason, confidence = 'sequence', .55
                elif len(current) < 6 and _same_sequence(last, photo):
                    compatible = True
                    reason, confidence = 'sequence', .20
        if current and not compatible:
            chunks.append((current, reasons, confidences))
            current, reasons, confidences = [], [], []
        current.append(photo)
        if compatible:
            reasons.append(reason)
            confidences.append(confidence)
    if current:
        chunks.append((current, reasons, confidences))
    result = []
    for members, reasons, confidence in chunks:
        identities = [_photo_key(photo) for photo in members]
        stable = [photo.get('source_path', identifier) for photo, identifier in zip(members, identities)]
        digest = hashlib.sha256(json.dumps([GROUP_VERSION, stable], separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()[:20]
        result.append({'id': 'group-' + digest, 'photo_ids': identities,
                       'representative_id': identities[len(identities) // 2],
                       'reason': 'single' if len(members) == 1 else 'time_visual' if all(r == 'time_visual' for r in reasons) else 'sequence',
                       'confidence': min(confidence) if confidence else 0.})
    check_cancel(cancel_event)
    return result


def _fraction(value):
    return (float(value) if isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and 0 <= value <= 1 else None)


def review_preview(preview):
    """Return conservative review suggestions from measured output changes.

    A scene-classification uncertainty flag alone never requires review. Face
    suggestions measure chroma under an existing face mask, not face identity.
    The result neither rejects photos nor judges artistic blur or dark scenes.
    """
    if not isinstance(preview, dict):
        raise ValueError('Invalid travel preview evidence.')
    warnings = []
    original, rendered = preview.get('original'), preview.get('rendered')
    comparable = (isinstance(original, np.ndarray) and isinstance(rendered, np.ndarray)
                  and original.dtype == rendered.dtype == np.uint8
                  and original.shape == rendered.shape and original.ndim == 3
                  and original.shape[2] == 3 and min(original.shape[:2]) > 0)
    if comparable:
        factor = min(1., 512 / max(original.shape[:2]))
        size = (max(1, round(original.shape[1] * factor)), max(1, round(original.shape[0] * factor)))
        a = cv2.resize(original, size, interpolation=cv2.INTER_AREA) if factor < 1 else original
        b = cv2.resize(rendered, size, interpolation=cv2.INTER_AREA) if factor < 1 else rendered
        white_a, white_b = float(np.mean(np.any(a >= 254, axis=2))), float(np.mean(np.any(b >= 254, axis=2)))
        black_a, black_b = float(np.mean(np.any(a <= 1, axis=2))), float(np.mean(np.any(b <= 1, axis=2)))
        if white_b - white_a >= .02 and white_b >= .03:
            warnings.append('travel_review_highlights')
        if black_b - black_a >= .03 and black_b >= .04:
            warnings.append('travel_review_clipping')
        scene = preview.get('scene') or {}
        masks = (scene.get('masks') or {}) if isinstance(scene, dict) else {}
        mask = masks.get('face') if isinstance(masks, dict) else None
        if isinstance(mask, np.ndarray) and mask.ndim == 2 and min(mask.shape) > 0 and np.isfinite(mask).all():
            face = cv2.resize(mask.astype(np.float32), size, interpolation=cv2.INTER_AREA) > .5
            if np.count_nonzero(face) >= 64:
                first = cv2.cvtColor(a.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
                second = cv2.cvtColor(b.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
                change = float(np.median(np.linalg.norm((second - first)[:, :, 1:][face], axis=1)))
                if change > 12:
                    warnings.append('travel_review_color_change')
    else:
        before, after = _fraction(preview.get('clipping_before')), _fraction(preview.get('clipping_after'))
        if before is not None and after is not None and after - before >= .03 and after >= .04:
            warnings.append('travel_review_clipping')
    return warnings
