"""Local travel projects, photo choices and durable output-task records.

Projects reference originals instead of copying libraries. Imported metadata is
an explicit whitelist; GPS, whole EXIF/XML and image buffers are not stored.
Connections belong to their calling thread, including background job workers.
"""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sqlite3

from .constants import RAW_EXTENSIONS, JPEG_EXTENSIONS
from .database import _check_json_value, _check_source_metadata
from .schema_migrations import migrate_schema

UNSET = object()
DEFAULT_ADJUSTMENTS = {'exposure_ev': 0., 'temperature': 0., 'tint': 0., 'strength': 1.}
DEFAULT_SETTINGS = {
    'style_key': None, 'style_name': None, 'strength': .7,
    'recognition': True, 'lens_correction': True, 'protect_faces': True,
    'object_strength': .7, 'recursive': True, 'fast_raw': False,
    'output_size': 'original', 'output_folder': None,
    'preview_quality': 'interactive', 'sort': 'name', 'filter': 'all',
}
_PICKS = {'keep', 'hold', 'reject'}
_TASK_STATES = {'pending', 'running', 'ready', 'completed', 'failed'}


class TravelDataError(ValueError):
    """Travel data is invalid or a persisted record is inconsistent."""


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


def _text(value, field, maximum=120, *, nullable=False):
    if value is None and nullable:
        return None
    if (not isinstance(value, str) or not 1 <= len(value.strip()) <= maximum
            or any(ord(char) < 32 for char in value)):
        raise TravelDataError(f'Invalid {field}.')
    return value.strip()


def _number(value, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value) and low <= value <= high
    except OverflowError:
        return False


def _positive_id(value):
    if type(value) is not int or not 1 <= value <= 2**63 - 1:
        raise TravelDataError('Invalid travel record identifier.')
    return value


def _path(value):
    if not isinstance(value, (str, Path)) or not str(value).strip() or '\x00' in str(value):
        raise TravelDataError('Invalid travel path.')
    return Path(value).expanduser().resolve(strict=False)


def _json(value, *, limit=4_000_000):
    try:
        _check_json_value(value)
        _check_source_metadata(value)
        result = json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True)
    except (TypeError, ValueError, RecursionError) as exc:
        raise TravelDataError('Travel data must be finite, private-metadata-free JSON.') from exc
    if len(result.encode('utf-8')) > limit:
        raise TravelDataError('Travel record exceeds the supported size.')
    return result


def _load(value):
    try:
        result = json.loads(value, parse_constant=lambda item: (_ for _ in ()).throw(ValueError(item)))
        _json(result)
        return result
    except (TypeError, ValueError, RecursionError) as exc:
        raise TravelDataError('Stored travel JSON is invalid.') from exc


def validate_adjustments(value):
    if not isinstance(value, dict) or not set(value) <= set(DEFAULT_ADJUSTMENTS):
        raise TravelDataError('Unsupported photo adjustment.')
    result = dict(DEFAULT_ADJUSTMENTS)
    result.update(value)
    for key, low, high in (('exposure_ev', -3, 3), ('temperature', -1, 1),
                           ('tint', -1, 1), ('strength', 0, 1)):
        if not _number(result[key], low, high):
            raise TravelDataError('Photo adjustment is outside the supported range.')
        result[key] = float(result[key])
    return result


def validate_settings(value, base=None):
    if not isinstance(value, dict) or not set(value) <= set(DEFAULT_SETTINGS):
        raise TravelDataError('Unsupported travel project setting.')
    result = copy.deepcopy(DEFAULT_SETTINGS if base is None else base)
    result.update(value)
    for key in ('style_key', 'style_name'):
        result[key] = _text(result[key], key, 200, nullable=True)
    for key in ('recognition', 'lens_correction', 'protect_faces', 'recursive', 'fast_raw'):
        if type(result[key]) is not bool:
            raise TravelDataError('Travel switches must be boolean.')
    if any(not _number(result[key], 0, 1) for key in ('strength', 'object_strength')):
        raise TravelDataError('Invalid travel style strength.')
    if result['output_size'] not in ('original', '2048', '3840'):
        raise TravelDataError('Unsupported travel output size.')
    if result['preview_quality'] not in ('baseline', 'interactive'):
        raise TravelDataError('Unsupported travel preview quality.')
    if result['sort'] not in ('name', 'capture_time') or result['filter'] not in ('all', *_PICKS):
        raise TravelDataError('Unsupported travel view setting.')
    if result['output_folder'] is not None:
        result['output_folder'] = str(_path(result['output_folder']))
    _json(result)
    return result


class TravelStore:
    """A SQLite connection for one UI or worker thread."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, timeout=30.)
        try:
            self.conn.execute('PRAGMA busy_timeout=30000')
            migrate_schema(self.conn)
            self.conn.execute('PRAGMA foreign_keys=ON')
            self.conn.row_factory = sqlite3.Row
        except BaseException:
            self.conn.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self.conn.close()

    def create_project(self, name, folder, recursive=True):
        name = _text(name, 'project name')
        root = _path(folder)
        if not root.is_dir():
            raise TravelDataError('Choose an existing travel photo folder.')
        if type(recursive) is not bool:
            raise TravelDataError('Recursive scanning must be boolean.')
        settings = validate_settings({'recursive': recursive})
        now = utc_now()
        with self.conn:
            cursor = self.conn.execute('''INSERT INTO travel_projects
                (name,root_path,recursive,settings_json,created_at_utc,updated_at_utc)
                VALUES(?,?,?,?,?,?)''', (name, str(root), int(recursive), _json(settings), now, now))
        return cursor.lastrowid

    def _project(self, row):
        if row is None:
            return None
        result = dict(row)
        result['name'] = _text(result['name'], 'stored project name')
        result['recursive'] = bool(result['recursive'])
        result['settings'] = validate_settings(_load(result.pop('settings_json')))
        counts = {pick: 0 for pick in _PICKS}
        for item in self.conn.execute('SELECT pick,count(*) AS n FROM travel_photos WHERE project_id=? GROUP BY pick', (result['id'],)):
            counts[item['pick']] = item['n']
        result['photo_count'] = sum(counts.values())
        result['counts'] = {'total': result['photo_count'], **counts}
        return result

    def get_project(self, project_id):
        return self._project(self.conn.execute('SELECT * FROM travel_projects WHERE id=?', (_positive_id(project_id),)).fetchone())

    def list_projects(self):
        return [self._project(row) for row in self.conn.execute('SELECT * FROM travel_projects ORDER BY updated_at_utc DESC,id DESC').fetchall()]

    def _require_project(self, project_id):
        result = self.get_project(project_id)
        if result is None:
            raise TravelDataError('Travel project does not exist.')
        return result

    def configure_project(self, project_id, settings):
        project = self._require_project(project_id)
        settings = validate_settings(settings, project['settings'])
        with self.conn:
            self.conn.execute('UPDATE travel_projects SET settings_json=?,recursive=?,updated_at_utc=? WHERE id=?',
                              (_json(settings), int(settings['recursive']), utc_now(), project_id))
        return self.get_project(project_id)

    def _import_row(self, project, value):
        if not isinstance(value, dict):
            raise TravelDataError('Travel photos must be metadata dictionaries.')
        if any(not isinstance(key, str) for key in value):
            raise TravelDataError('Travel photo metadata keys must be strings.')
        try:
            _check_source_metadata(value)
        except (AttributeError, RecursionError) as exc:
            raise TravelDataError('Invalid travel photo metadata.') from exc
        for key in value:
            normalized = ''.join(char for char in key.lower() if char.isalnum())
            if normalized.startswith('gps') or normalized in {'latitude','longitude','geolocation','lat','lon','lng'}:
                raise TravelDataError('GPS must not be imported.')
        source = _path(value.get('source_path', value.get('path')))
        root = Path(project['root_path'])
        try:
            relative = source.relative_to(root)
        except ValueError as exc:
            raise TravelDataError('Photo must remain inside its travel folder.') from exc
        if not relative.parts or '..' in relative.parts:
            raise TravelDataError('Invalid travel photo path.')
        provided = value.get('relative_path')
        if provided is not None and Path(provided).as_posix() != relative.as_posix():
            raise TravelDataError('Relative photo path disagrees with its source.')
        extension = source.suffix.lower()
        kind = 'raw' if extension in RAW_EXTENSIONS else 'jpg' if extension in JPEG_EXTENSIONS else None
        if kind is None or value.get('kind', kind) != kind:
            raise TravelDataError('Travel inputs must be supported RAW/JPG photos.')
        size, modified = value.get('size_bytes'), value.get('mtime_ns')
        if any(type(item) is not int or not 0 <= item <= 2**63-1 for item in (size, modified)):
            raise TravelDataError('Invalid travel source file metadata.')
        capture = value.get('capture_time')
        if capture is not None:
            capture = _text(capture, 'capture time', 64)
        dimensions = []
        for field in ('width','height'):
            item = value.get(field)
            if item is not None and (type(item) is not int or not 1 <= item <= 120_000_000):
                raise TravelDataError('Invalid photo dimensions.')
            dimensions.append(item)
        return (str(source), relative.as_posix(), kind, size, modified, capture, *dimensions)

    def import_photos(self, project_id, photos):
        project = self._require_project(project_id)
        # Validate the full batch first: a malformed row cannot leave a partial
        # project import, while rescanning never resets deliberate user edits.
        rows = [self._import_row(project, row) for row in photos]
        if len({row[0] for row in rows}) != len(rows):
            raise TravelDataError('Travel import repeats a source path.')
        counts = {'added':0, 'updated':0, 'unchanged':0, 'total':len(rows)}
        now = utc_now()
        with self.conn:
            for row in rows:
                previous = self.conn.execute('''SELECT source_path,relative_path,kind,size_bytes,mtime_ns,capture_time,width,height
                    FROM travel_photos WHERE project_id=? AND source_path=?''', (project_id,row[0])).fetchone()
                if previous is None:
                    self.conn.execute('''INSERT INTO travel_photos
                        (project_id,source_path,relative_path,kind,size_bytes,mtime_ns,capture_time,width,height,
                         adjustments_json,scene_override_json,created_at_utc,updated_at_utc)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                        (project_id,*row,_json(DEFAULT_ADJUSTMENTS),'null',now,now))
                    counts['added'] += 1
                elif tuple(previous) == row:
                    counts['unchanged'] += 1
                else:
                    self.conn.execute('''UPDATE travel_photos SET relative_path=?,kind=?,size_bytes=?,mtime_ns=?,
                        capture_time=?,width=?,height=?,updated_at_utc=? WHERE project_id=? AND source_path=?''',
                        (*row[1:],now,project_id,row[0]))
                    counts['updated'] += 1
            self.conn.execute('UPDATE travel_projects SET updated_at_utc=? WHERE id=?', (now,project_id))
        counts['imported'] = counts['added'] + counts['updated']
        return counts

    def _photo(self, row):
        if row is None:
            return None
        result = dict(row)
        if result['pick'] not in _PICKS:
            raise TravelDataError('Invalid stored photo choice.')
        result['adjustments'] = validate_adjustments(_load(result.pop('adjustments_json')))
        from .photo_scene import validate_scene_override
        result['scene_override'] = validate_scene_override(_load(result.pop('scene_override_json')))
        return result

    def get_photo(self, photo_id):
        return self._photo(self.conn.execute('SELECT * FROM travel_photos WHERE id=?', (_positive_id(photo_id),)).fetchone())

    def list_photos(self, project_id):
        self._require_project(project_id)
        return [self._photo(row) for row in self.conn.execute('SELECT * FROM travel_photos WHERE project_id=? ORDER BY id', (project_id,)).fetchall()]

    def update_photo(self, photo_id, *, pick=None, adjustments=None, scene_override=UNSET, group_id=UNSET):
        photo = self.get_photo(photo_id)
        if photo is None:
            raise TravelDataError('Travel photo does not exist.')
        if pick is not None:
            if not isinstance(pick, str) or pick not in _PICKS:
                raise TravelDataError('Unsupported photo choice.')
            photo['pick'] = pick
        if adjustments is not None:
            if not isinstance(adjustments,dict):
                raise TravelDataError('Photo adjustments must be a dictionary.')
            photo['adjustments'] = validate_adjustments({**photo['adjustments'], **adjustments})
        if scene_override is not UNSET:
            from .photo_scene import validate_scene_override
            photo['scene_override'] = validate_scene_override(scene_override)
        if group_id is not UNSET:
            photo['group_id'] = _text(group_id, 'photo group', nullable=True)
        with self.conn:
            self.conn.execute('''UPDATE travel_photos SET pick=?,adjustments_json=?,scene_override_json=?,group_id=?,updated_at_utc=? WHERE id=?''',
                (photo['pick'],_json(photo['adjustments']),_json(photo['scene_override']),photo['group_id'],utc_now(),photo_id))
            self.conn.execute('UPDATE travel_projects SET updated_at_utc=? WHERE id=?', (utc_now(),photo['project_id']))
        return self.get_photo(photo_id)

    def list_tasks(self, project_id):
        self._require_project(project_id)
        result = []
        for row in self.conn.execute('SELECT * FROM travel_tasks WHERE project_id=? ORDER BY id', (project_id,)):
            item = dict(row)
            if item['status'] not in _TASK_STATES:
                raise TravelDataError('Invalid stored output task state.')
            item['request'] = _load(item.pop('request_json'))
            if not isinstance(item['request'],dict):
                raise TravelDataError('Stored output request must be a dictionary.')
            result.append(item)
        return result

    def retry_failed(self, project_id):
        self._require_project(project_id)
        with self.conn:
            result = self.conn.execute('''UPDATE travel_tasks SET status='pending',error_code=NULL,owner_token=NULL,updated_at_utc=?
                WHERE project_id=? AND status='failed' ''', (utc_now(),project_id))
        return result.rowcount
