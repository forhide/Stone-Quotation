"""Durable, serial, entirely local travel-photo JPEG exports.

Every request freezes its look, photo corrections, source SHA-256 and verified
local runtime identity. A completed private JPEG receives a durable receipt
before exclusive publication, so a restart can finish without rendering twice.
"""
from __future__ import annotations

import copy
from contextlib import contextmanager
import errno
import hashlib
import json
import math
import os
from pathlib import Path
import re
import threading
import time
import uuid

from .analysis_control import AnalysisCancelledError
from .constants import APP_VERSION, JPEG_EXTENSIONS, RAW_EXTENSIONS
from .export_files import ExportCancelledError, write_new
from .photo_scene import validate_scene_override
from .style_dna import ENGINE_VERSION, validate_dna
from .style_render import export_jpeg
from .travel_adjustments import effective_strength, validate_adjustments
from .travel_store import TravelDataError, TravelStore, _json, _load, utc_now

_LEASE_SECONDS = 120.
_HEARTBEAT_SECONDS = 2.
_STATES = ('pending', 'running', 'ready', 'completed', 'failed')
_HEX = re.compile(r'^[0-9a-f]{64}$')
_REQUEST_KEYS = {'version', 'project_id', 'photo_id', 'source_path', 'relative_path',
                 'source_sha256', 'source_stat', 'destination_root', 'dna',
                 'settings', 'adjustments', 'scene_override', 'runtime'}


class _JobError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


class _StopSignal:
    def __init__(self, external, lease_lost):
        self.external, self.lease_lost = external, lease_lost

    def is_set(self):
        return self.lease_lost.is_set() or bool(self.external is not None and self.external.is_set())


def _check_cancel(event):
    if event is not None and event.is_set():
        raise AnalysisCancelledError('Travel export cancelled.')


def _fingerprint(path, cancel_event=None):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            _check_cancel(cancel_event)
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    _check_cancel(cancel_event)
    return digest.hexdigest()


def _runtime_identity(recognition, lens_correction):
    # Asset providers verify bytes once and invalidate their cached identities
    # when installed files change. Missing assets are recorded as a fallback,
    # so installing a different pack cannot silently change a queued result.
    from .semantic_models import bundle_id
    from .photo_scene import classifier_bundle_id
    from .lens_profiles import lens_bundle_id

    def available(provider):
        try:
            return provider()
        except (ImportError, OSError, ValueError):
            return None

    return {'application': APP_VERSION, 'engine': ENGINE_VERSION,
            'semantic': available(bundle_id) if recognition else None,
            'scene': available(classifier_bundle_id),
            'lens': available(lens_bundle_id) if lens_correction else None}


def _canonical(value):
    # _json also rejects private location/EXIF payloads and non-finite values.
    _json(value)
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _key(request):
    return hashlib.sha256(_canonical(request).encode('utf-8')).hexdigest()


def _destination(request, request_key):
    stem = Path(request['relative_path']).stem
    stem = re.sub(r'[^\w. -]', '_', stem, flags=re.UNICODE).strip(' .')[:70] or 'photo'
    return Path(request['destination_root']) / f'{stem}_pcl_{request_key[:20]}.jpg'


def _settings(strength, recognition, lens_correction, output_size, project):
    if isinstance(strength, bool) or not isinstance(strength, (int, float)) or not math.isfinite(strength) or not 0 <= strength <= 1:
        raise TravelDataError('Invalid export strength.')
    if type(recognition) is not bool or type(lens_correction) is not bool:
        raise TravelDataError('Export switches must be boolean.')
    if output_size not in ('original', '2048', '3840'):
        raise TravelDataError('Unsupported export size.')
    return {'strength': float(strength), 'recognition': recognition,
            'lens_correction': lens_correction, 'output_size': output_size,
            'object_strength': float(project['settings']['object_strength']),
            'protect_faces': project['settings']['protect_faces'], 'composition': 'color_only'}


def _summary(store, project_id, *, cancelled=False, busy=False, **extra):
    counts = dict.fromkeys(_STATES, 0)
    for row in store.conn.execute('SELECT status,count(*) AS n FROM travel_tasks WHERE project_id=? GROUP BY status', (project_id,)):
        counts[row['status']] = row['n']
    return {'total': sum(counts.values()), **counts, 'cancelled': bool(cancelled), 'busy': bool(busy), **extra}


def _progress(callback, store, project_id, status, current=None, **extra):
    if callback is not None:
        callback(_summary(store, project_id, status=status, current=current, **extra))


def enqueue_exports(db_path, project_id, dna, destination, *, strength=.7,
                    recognition=True, lens_correction=True, photo_ids=None,
                    output_size='original', cancel_event=None, progress=None):
    """Snapshot chosen keep photos; identical requests reuse durable tasks.

    Preparation hashes originals in cancellable chunks. Run this in the same
    background thread as processing when selecting hundreds of RAW files.
    """
    look = copy.deepcopy(validate_dna(copy.deepcopy(dna)))
    root = Path(destination).expanduser().resolve(strict=False)
    if not root.is_dir():
        root.mkdir(parents=True, exist_ok=True)
    queued = reused = preparation_failed = 0
    with TravelStore(db_path) as store:
        project = store._require_project(project_id)
        settings = _settings(strength, recognition, lens_correction, output_size, project)
        photos = store.list_photos(project_id)
        if photo_ids is not None:
            identifiers = list(photo_ids)
            if any(type(identifier) is not int or identifier < 1 for identifier in identifiers):
                raise TravelDataError('Invalid export photo identifiers.')
            wanted = set(identifiers)
            if not wanted <= {photo['id'] for photo in photos}:
                raise TravelDataError('Export photos must belong to their project.')
            photos = [photo for photo in photos if photo['id'] in wanted]
        photos = [photo for photo in photos if photo['pick'] == 'keep']
        runtime = _runtime_identity(recognition, lens_correction)
        try:
            for index, photo in enumerate(photos):
                _check_cancel(cancel_event)
                source = Path(photo['source_path'])
                try:
                    source_sha = _fingerprint(source, cancel_event)
                    info = source.stat()
                except OSError:
                    preparation_failed += 1
                    _progress(progress, store, project_id, 'preparation_failed', str(source),
                              prepared=index + 1, preparation_total=len(photos),
                              preparation_failed=preparation_failed, error_code='source_unavailable')
                    continue
                request = {'version': 1, 'project_id': project_id, 'photo_id': photo['id'],
                           'source_path': str(source), 'relative_path': photo['relative_path'],
                           'source_sha256': source_sha,
                           'source_stat': {'size_bytes': info.st_size, 'mtime_ns': info.st_mtime_ns},
                           'destination_root': str(root), 'dna': look, 'settings': settings,
                           'adjustments': validate_adjustments(photo['adjustments']),
                           'scene_override': validate_scene_override(photo['scene_override']),
                           'runtime': runtime}
                request_key = _key(request)
                final = _destination(request, request_key)
                # A pre-existing file is never adopted as this task's output.
                status = 'failed' if final.exists() or final.is_symlink() else 'pending'
                now = utc_now()
                with store.conn:
                    result = store.conn.execute('''INSERT OR IGNORE INTO travel_tasks
                        (project_id,photo_id,status,request_key,request_json,destination,
                         source_sha256,error_code,created_at_utc,updated_at_utc)
                        VALUES(?,?,?,?,?,?,?,?,?,?)''',
                        (project_id, photo['id'], status, request_key, _json(request), str(final),
                         source_sha, 'output_exists' if status == 'failed' else None, now, now))
                if result.rowcount:
                    queued += 1
                else:
                    reused += 1
                _progress(progress, store, project_id, 'preparing', str(source), prepared=index + 1, preparation_total=len(photos))
        except (AnalysisCancelledError, ExportCancelledError):
            return _summary(store, project_id, cancelled=True, queued=queued, reused=reused, preparation_failed=preparation_failed)
        return _summary(store, project_id, queued=queued, reused=reused, preparation_failed=preparation_failed)


class _Lease:
    """A database heartbeat; no process signalling or Windows PID probing."""
    def __init__(self, db_path, project_id):
        self.db_path, self.project_id = db_path, project_id
        self.token = uuid.uuid4().hex
        self.lost = threading.Event()
        self.stop = threading.Event()
        self.thread = None

    def acquire(self, store):
        now = time.time()
        try:
            store.conn.execute('BEGIN IMMEDIATE')
            row = store.conn.execute('SELECT * FROM travel_leases WHERE project_id=?', (self.project_id,)).fetchone()
            if row is not None and row['expires_at'] > now:
                store.conn.rollback()
                return False
            store.conn.execute('''INSERT INTO travel_leases(project_id,token,expires_at,heartbeat)
                VALUES(?,?,?,?) ON CONFLICT(project_id) DO UPDATE SET
                token=excluded.token,expires_at=excluded.expires_at,heartbeat=excluded.heartbeat''',
                (self.project_id, self.token, now + _LEASE_SECONDS, now))
            store.conn.commit()
        except BaseException:
            store.conn.rollback()
            raise
        self.thread = threading.Thread(target=self._heartbeat, name='pcl-travel-lease', daemon=True)
        self.thread.start()
        return True

    def _heartbeat(self):
        try:
            with TravelStore(self.db_path) as store:
                while not self.stop.wait(_HEARTBEAT_SECONDS):
                    now = time.time()
                    with store.conn:
                        result = store.conn.execute('''UPDATE travel_leases SET heartbeat=?,expires_at=?
                            WHERE project_id=? AND token=?''',
                            (now, now + _LEASE_SECONDS, self.project_id, self.token))
                    if result.rowcount != 1:
                        self.lost.set()
                        return
        except Exception:
            self.lost.set()

    def assert_owned(self, store):
        row = store.conn.execute('SELECT token,expires_at FROM travel_leases WHERE project_id=?', (self.project_id,)).fetchone()
        if self.lost.is_set() or row is None or row['token'] != self.token or row['expires_at'] <= time.time():
            self.lost.set()
            raise _JobError('lease_lost')

    def release(self, store):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=3.)
        with store.conn:
            store.conn.execute('DELETE FROM travel_leases WHERE project_id=? AND token=?', (self.project_id, self.token))


@contextmanager
def _leased_write(store, lease):
    """Check ownership and mutate atomically against another lease claimant."""
    try:
        store.conn.execute('BEGIN IMMEDIATE')
        lease.assert_owned(store)
        yield
        store.conn.commit()
    except BaseException:
        store.conn.rollback()
        raise


def _validate_request(row, project):
    try:
        request = _load(row['request_json'])
        if not isinstance(request, dict) or set(request) != _REQUEST_KEYS or request['version'] != 1:
            raise ValueError('Invalid request.')
        if (type(request['project_id']) is not int or type(request['photo_id']) is not int
                or request['project_id'] != project['id'] or request['photo_id'] != row['photo_id']):
            raise ValueError('Invalid request identity.')
        source = Path(request['source_path'])
        if (not source.is_absolute() or source.resolve(strict=False) != source
                or source.suffix.lower() not in RAW_EXTENSIONS | JPEG_EXTENSIONS
                or source.relative_to(Path(project['root_path'])).as_posix() != request['relative_path']):
            raise ValueError('Invalid source path.')
        if not _HEX.fullmatch(request['source_sha256']) or request['source_sha256'] != row['source_sha256']:
            raise ValueError('Invalid source digest.')
        stat = request['source_stat']
        if not isinstance(stat, dict) or set(stat) != {'size_bytes', 'mtime_ns'} or any(type(value) is not int or value < 0 for value in stat.values()):
            raise ValueError('Invalid source stat.')
        if _key(request) != row['request_key']:
            raise ValueError('Request receipt mismatch.')
        root = Path(request['destination_root'])
        final = _destination(request, row['request_key'])
        if (not root.is_absolute() or root.resolve(strict=False) != root
                or str(final) != row['destination'] or final == source):
            raise ValueError('Invalid output path.')
        look = validate_dna(copy.deepcopy(request['dna']))
        if look != request['dna']:
            raise ValueError('Queued look requires an explicit upgrade.')
        settings = request['settings']
        if not isinstance(settings, dict) or set(settings) != {'strength', 'recognition', 'lens_correction', 'output_size', 'object_strength', 'protect_faces', 'composition'}:
            raise ValueError('Invalid render settings.')
        normalized = _settings(settings['strength'], settings['recognition'], settings['lens_correction'], settings['output_size'],
                               {'settings': settings})
        if settings != normalized or type(settings['protect_faces']) is not bool or isinstance(settings['object_strength'], bool) or not math.isfinite(settings['object_strength']) or not 0 <= settings['object_strength'] <= 1:
            raise ValueError('Invalid render controls.')
        if validate_adjustments(request['adjustments']) != request['adjustments'] or validate_scene_override(request['scene_override']) != request['scene_override']:
            raise ValueError('Invalid photo controls.')
        runtime = request['runtime']
        if (not isinstance(runtime, dict) or set(runtime) != {'application', 'engine', 'semantic', 'scene', 'lens'}
                or not all(isinstance(runtime[key], str) for key in ('application', 'engine'))
                or any(value is not None and (not isinstance(value, str) or not _HEX.fullmatch(value)) for key, value in runtime.items() if key in {'semantic', 'scene', 'lens'})):
            raise ValueError('Invalid runtime identity.')
        return request
    except (TypeError, ValueError, KeyError, OSError, OverflowError) as exc:
        raise _JobError('invalid_request') from exc


def _stage_path(row):
    value = row['stage_path']
    if not isinstance(value, str):
        raise _JobError('invalid_stage')
    stage = Path(value)
    final = Path(row['destination'])
    pattern = rf'\.pcl-task-{row["id"]}-{row["request_key"][:20]}-[0-9a-f]{{32}}\.jpg'
    if (stage.parent != final.parent or not re.fullmatch(pattern, stage.name)
            or stage.is_symlink() or stage.resolve(strict=False) != stage):
        raise _JobError('invalid_stage')
    return stage


def _delete_stage(row):
    try:
        stage = _stage_path(row)
        stage.unlink(missing_ok=True)
    except (OSError, _JobError):
        pass


def _publish_stage(stage, destination, cancel_event):
    """Publish only new names; private stage remains until DB completion."""
    _check_cancel(cancel_event)
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(errno.EEXIST, 'Output already exists.', str(destination))
    if os.name == 'nt':
        os.rename(stage, destination)  # Windows rename fails if target exists.
        return
    try:
        os.link(stage, destination)
    except OSError as exc:
        if exc.errno not in {errno.EPERM, errno.EXDEV, errno.ENOSYS, errno.EOPNOTSUPP, errno.ENOTSUP}:
            raise

        def copy_stage(stream):
            with stage.open('rb') as source:
                while True:
                    _check_cancel(cancel_event)
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    stream.write(chunk)
        write_new(destination, copy_stage, cancel_event=cancel_event)


def _finish_ready(store, row, request, lease, cancel_event, *, recovering):
    stage = _stage_path(row)
    output_sha = row['output_sha256']
    if not isinstance(output_sha, str) or not _HEX.fullmatch(output_sha):
        raise _JobError('invalid_stage')
    final = Path(row['destination'])
    # Resume receipts can recognize an already published exact JPEG. Ordinary
    # publication never adopts a file created by another concurrent writer.
    if final.exists() or final.is_symlink():
        if not recovering or final.is_symlink() or not final.is_file() or _fingerprint(final, cancel_event) != output_sha:
            raise _JobError('output_exists')
    else:
        if not stage.is_file() or _fingerprint(stage, cancel_event) != output_sha:
            raise _JobError('stage_changed')
        # Keep the short exclusive publication inside the lease transaction.
        # A paused/expired worker cannot publish after another worker claims
        # its project. JPEG rendering and hashing happen outside this lock.
        with _leased_write(store, lease):
            _publish_stage(stage, final, cancel_event)
    # A stop arriving after exclusive publication is a completed photo. Commit
    # it before honouring cancellation of the next file.
    with _leased_write(store, lease):
        result = store.conn.execute('''UPDATE travel_tasks SET status='completed',error_code=NULL,
            owner_token=NULL,updated_at_utc=? WHERE id=? AND status='ready' AND owner_token=?''',
            (utc_now(), row['id'], lease.token))
        if result.rowcount != 1:
            raise _JobError('lease_lost')
    _delete_stage(row)


def _error_code(exc):
    if isinstance(exc, _JobError):
        return exc.code
    if isinstance(exc, FileNotFoundError):
        return 'source_missing'
    if isinstance(exc, FileExistsError):
        return 'output_exists'
    return 'render_failed'


def _checkpoint_cancel(store, row, lease):
    if row['status'] == 'running':
        # This stage belongs only to this attempt, even if the lease was lost.
        _delete_stage(row)
        try:
            with _leased_write(store, lease):
                store.conn.execute("UPDATE travel_tasks SET status='pending',stage_path=NULL,output_sha256=NULL,owner_token=NULL,updated_at_utc=? WHERE id=? AND owner_token=?", (utc_now(), row['id'], lease.token))
        except _JobError:
            pass


def run_exports(db_path, project_id, *, cancel_event=None, progress=None):
    """Explicitly resume queued work, with one full-resolution worker/project."""
    with TravelStore(db_path) as store:
        project = store._require_project(project_id)
        lease = _Lease(db_path, project_id)
        if not lease.acquire(store):
            return _summary(store, project_id, busy=True)
        stop = _StopSignal(cancel_event, lease.lost)
        cancelled = False
        try:
            # Only an acquired project lease permits recovery. Opening another
            # workspace never resets or steals a healthy renderer's work.
            with _leased_write(store, lease):
                abandoned = store.conn.execute("SELECT * FROM travel_tasks WHERE project_id=? AND status='running'", (project_id,)).fetchall()
                store.conn.execute("UPDATE travel_tasks SET status='pending',owner_token=NULL,stage_path=NULL,output_sha256=NULL,updated_at_utc=? WHERE project_id=? AND status='running'", (utc_now(), project_id))
            for row in abandoned:
                _delete_stage(row)
            rows = store.conn.execute("SELECT * FROM travel_tasks WHERE project_id=? AND status IN ('ready','pending') ORDER BY id", (project_id,)).fetchall()
            for initial in rows:
                if stop.is_set():
                    cancelled = True
                    break
                row = dict(initial)
                try:
                    lease.assert_owned(store)
                    request = _validate_request(row, project)
                    settings = request['settings']
                    if request['runtime'] != _runtime_identity(settings['recognition'], settings['lens_correction']):
                        raise _JobError('runtime_changed')
                    if _fingerprint(request['source_path'], stop) != request['source_sha256']:
                        raise _JobError('source_changed')
                    if row['status'] == 'ready':
                        with _leased_write(store, lease):
                            store.conn.execute('UPDATE travel_tasks SET owner_token=? WHERE id=?', (lease.token, row['id']))
                        row['owner_token'] = lease.token
                        _finish_ready(store, row, request, lease, stop, recovering=True)
                    else:
                        stage = Path(row['destination']).parent / f'.pcl-task-{row["id"]}-{row["request_key"][:20]}-{uuid.uuid4().hex}.jpg'
                        with _leased_write(store, lease):
                            claimed = store.conn.execute("UPDATE travel_tasks SET status='running',attempts=attempts+1,owner_token=?,stage_path=?,output_sha256=NULL,error_code=NULL,updated_at_utc=? WHERE id=? AND status='pending'",
                                               (lease.token, str(stage), utc_now(), row['id']))
                            if claimed.rowcount != 1:
                                raise _JobError('lease_lost')
                        row.update(status='running', owner_token=lease.token, stage_path=str(stage))
                        _progress(progress, store, project_id, 'running', request['source_path'])
                        export_jpeg(request['source_path'], stage, request['dna'],
                                    strength=effective_strength(settings['strength'], request['adjustments']),
                                    composition=settings['composition'], cancel_event=stop,
                                    expected_fingerprint=request['source_sha256'], recognition=settings['recognition'],
                                    object_strength=settings['object_strength'], protect_faces=settings['protect_faces'],
                                    lens_correction=settings['lens_correction'], scene_override=request['scene_override'],
                                    output_size=settings['output_size'], photo_adjustments=request['adjustments'], evidence_cache=True)
                        if _fingerprint(request['source_path'], stop) != request['source_sha256']:
                            raise _JobError('source_changed')
                        if stage.is_symlink() or not stage.is_file():
                            raise _JobError('invalid_stage')
                        output_sha = _fingerprint(stage, stop)
                        # Make the completed JPEG durable before its database
                        # receipt can commit (including abrupt OS shutdown).
                        # Windows FlushFileBuffers requires a write-capable
                        # handle; a read-only descriptor fails with EBADF.
                        with stage.open('r+b') as stream:
                            os.fsync(stream.fileno())
                        with _leased_write(store, lease):
                            ready = store.conn.execute("UPDATE travel_tasks SET status='ready',output_sha256=?,updated_at_utc=? WHERE id=? AND status='running' AND owner_token=?",
                                               (output_sha, utc_now(), row['id'], lease.token))
                            if ready.rowcount != 1:
                                raise _JobError('lease_lost')
                        row.update(status='ready', output_sha256=output_sha)
                        _finish_ready(store, row, request, lease, stop, recovering=False)
                    _progress(progress, store, project_id, 'completed', request['source_path'])
                except (AnalysisCancelledError, ExportCancelledError):
                    # A verified ready stage remains reusable. A cancelled
                    # render has no receipt and must start again explicitly.
                    _checkpoint_cancel(store, row, lease)
                    cancelled = True
                    break
                except Exception as exc:
                    # Some legacy decode/style paths signal cancellation as
                    # ValueError rather than the newer dedicated exception.
                    if stop.is_set():
                        _checkpoint_cancel(store, row, lease)
                        cancelled = True
                        break
                    code = _error_code(exc)
                    if code == 'lease_lost':
                        cancelled = True
                        break
                    try:
                        with _leased_write(store, lease):
                            store.conn.execute("UPDATE travel_tasks SET status='failed',error_code=?,owner_token=NULL,stage_path=NULL,updated_at_utc=? WHERE id=? AND status!='completed' AND (owner_token=? OR owner_token IS NULL)", (code, utc_now(), row['id'], lease.token))
                    except _JobError:
                        cancelled = True
                        break
                    _delete_stage(row)
                    _progress(progress, store, project_id, 'failed', row.get('destination'), error_code=code)
            return _summary(store, project_id, cancelled=cancelled)
        finally:
            lease.release(store)
