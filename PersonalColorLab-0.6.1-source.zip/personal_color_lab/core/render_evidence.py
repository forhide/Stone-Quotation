"""Small, process-local cache of verified, bounded rendering evidence.

No source images or paths are retained. Reuse requires exact preview pixels,
the full source SHA and currently verified local model/profile identities.
"""
from __future__ import annotations

from collections import OrderedDict
import copy
import hashlib
import json
import threading

import cv2
import numpy as np


def _bytes(value):
    if isinstance(value, np.ndarray):
        return value.nbytes
    if isinstance(value, dict):
        return sum(_bytes(k) + _bytes(v) for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return sum(_bytes(v) for v in value)
    return len(value.encode('utf-8')) if isinstance(value, str) else 32


class RenderEvidenceCache:
    """Thread-safe LRU; owned copies protect evidence from caller mutation."""

    def __init__(self, max_entries=2, max_bytes=32 * 1024 * 1024):
        if type(max_entries) is not int or type(max_bytes) is not int or min(max_entries, max_bytes) < 1:
            raise ValueError('Invalid rendering evidence cache bounds.')
        self.max_entries, self.max_bytes = max_entries, max_bytes
        self._entries = OrderedDict()
        self._bytes = self._hits = self._misses = 0
        self._lock = threading.RLock()

    def get(self, key):
        with self._lock:
            if key is None or key not in self._entries:
                self._misses += 1
                return None
            self._hits += 1
            self._entries.move_to_end(key)
            return copy.deepcopy(self._entries[key][0])

    def put(self, key, measurement, scene, automatic_scene):
        # A missing model must recover by running again, rather than preserving
        # a fallback. A changed model also produces a different verified key.
        if key is None or automatic_scene.get('status') != 'ok':
            return
        if (automatic_scene.get('bundle_id') != key[9]
                or automatic_scene.get('model_version') != key[8]):
            return
        if key[-1] and scene is None:
            return
        if scene is not None and scene['report'].get('bundle_id') != key[10]:
            return
        value = {'measurement': measurement, 'scene': scene,
                 'automatic_photo_scene': automatic_scene}
        size = _bytes(value)
        if size > self.max_bytes:
            return
        with self._lock:
            if key in self._entries:
                self._bytes -= self._entries.pop(key)[1]
            while self._entries and (len(self._entries) >= self.max_entries or self._bytes + size > self.max_bytes):
                self._bytes -= self._entries.popitem(last=False)[1][1]
            self._entries[key] = (copy.deepcopy(value), size)
            self._bytes += size

    def clear(self):
        with self._lock:
            self._entries.clear()
            self._bytes = self._hits = self._misses = 0

    def info(self):
        with self._lock:
            return {'entries': len(self._entries), 'bytes': self._bytes,
                    'hits': self._hits, 'misses': self._misses,
                    'max_entries': self.max_entries, 'max_bytes': self.max_bytes}


DEFAULT_CACHE = RenderEvidenceCache()


def resolve_cache(value):
    if value is None or value is False:
        return None
    if value is True:
        return DEFAULT_CACHE
    if isinstance(value, RenderEvidenceCache):
        return value
    raise ValueError('Invalid rendering evidence cache.')


def evidence_key(source_fingerprint, pixels, *, raw_quality, lens_correction,
                 lens_override, lens_bundle, recognition):
    """Verify assets on every lookup; metadata timestamps alone never suffice."""
    from .photo_scene import MODEL_VERSION, classifier_bundle_id
    from .semantic_models import bundle_id
    try:
        classifier = classifier_bundle_id()
        semantic = bundle_id() if recognition else None
    except (cv2.error, OSError, ValueError):
        return None
    if classifier is None or (recognition and semantic is None) or (lens_correction and lens_bundle is None):
        return None
    pixels = np.ascontiguousarray(pixels)
    digest = hashlib.sha256(memoryview(pixels)).hexdigest()
    optics = json.dumps(lens_override, sort_keys=True, separators=(',', ':'))
    return (source_fingerprint, pixels.shape, pixels.dtype.str, digest,
            raw_quality, lens_correction, optics, lens_bundle,
            MODEL_VERSION, classifier, semantic, recognition)
