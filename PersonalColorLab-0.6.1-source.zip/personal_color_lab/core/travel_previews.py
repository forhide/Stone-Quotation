"""Bounded, disposable navigation previews for travel contact sheets.

Camera thumbnails are explicitly browsing approximations. These pixels never
replace the RAW baseline used by analysis, style rendering or final exports.
Only stripped RGB pixels and a fixed numeric source stamp enter this cache.
"""
from __future__ import annotations

from collections import OrderedDict
from functools import lru_cache
from io import BytesIO
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import stat
import threading
import time
import uuid
import warnings
import weakref

import numpy as np
from PIL import Image, ImageCms, ImageOps, PngImagePlugin, __version__ as PILLOW_VERSION

from .analysis_control import check_cancel, AnalysisCancelledError
from .constants import RAW_EXTENSIONS, IMAGE_EXTENSIONS
from .raw_decode import decode_raw, _sensor_size, MAX_RAW_PIXELS

_SCHEMA = 1
_MEMORY_ENTRIES = 32
_DISK_ENTRIES = 2048
_ENTRY = re.compile(r'^[0-9a-f]{64}\.png$')
_TEMP = re.compile(r'^\.pcl-preview-[0-9a-f]{32}\.tmp$')
_KINDS = {'camera_preview', 'image_preview', 'raw_preview'}
_STAMP_FIELDS = {'device', 'inode', 'size_bytes', 'mtime_ns', 'ctime_ns'}
_METADATA_FIELDS = {'schema_version', 'kind', 'approximate', 'width', 'height',
                    'source_stamp', 'pixel_sha256', 'decoder', 'bound'}
_FLIP = {1: Image.Transpose.FLIP_LEFT_RIGHT, 2: Image.Transpose.FLIP_TOP_BOTTOM,
         3: Image.Transpose.ROTATE_180, 4: Image.Transpose.TRANSPOSE,
         5: Image.Transpose.ROTATE_90, 6: Image.Transpose.ROTATE_270,
         7: Image.Transpose.TRANSVERSE}
_GATES = weakref.WeakValueDictionary()
_GATES_LOCK = threading.Lock()


class _Gate:
    def __init__(self):
        self.lock = threading.RLock()
        self.inflight = {}
        self.epoch = 0


def _source_stamp(path):
    info = path.stat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('A regular photo file is required.')
    return {'device': info.st_dev, 'inode': info.st_ino,
            'size_bytes': info.st_size, 'mtime_ns': info.st_mtime_ns,
            'ctime_ns': info.st_ctime_ns}


@lru_cache(maxsize=2)
def _decoder_version(is_raw):
    # Distribution metadata is stable for the running interpreter. Re-reading
    # its files on every gallery hit adds needless I/O to a stat-only lookup.
    raw = importlib.metadata.version('rawpy') if is_raw else '-'
    return f'gallery-v{_SCHEMA};pillow={PILLOW_VERSION};rawpy={raw}'


def _decoder(path):
    return _decoder_version(path.suffix.lower() in RAW_EXTENSIONS)


def _bounded_image(opened, maximum, *, raw_flip=0):
    if min(opened.size) < 1 or opened.width * opened.height > MAX_RAW_PIXELS:
        raise ValueError('Photo preview dimensions exceed the supported limit.')
    orientation = opened.getexif().get(274)
    if opened.format in ('JPEG', 'MPO'):
        opened.draft('RGB', (maximum, maximum))
    image = ImageOps.exif_transpose(opened)
    if orientation not in range(1, 9) and raw_flip in _FLIP:
        image = image.transpose(_FLIP[raw_flip])
    image.thumbnail((maximum, maximum), Image.Resampling.LANCZOS)
    profile = image.info.get('icc_profile')
    if profile:
        try:
            image = ImageCms.profileToProfile(image, ImageCms.ImageCmsProfile(BytesIO(profile)),
                                             ImageCms.createProfile('sRGB'), outputMode='RGB')
        except (ValueError, OSError, ImageCms.PyCMSError):
            # This is a navigation thumbnail, not validated analysis evidence.
            # Its approximate provenance remains visible to the caller.
            pass
    return np.array(image.convert('RGB'), dtype=np.uint8)


def _camera_preview(path, maximum, cancel_event):
    import rawpy
    with rawpy.RawPy() as raw:
        raw.open_file(str(path))
        _sensor_size(raw.sizes)
        flip = raw.sizes.flip
        if type(flip) is not int or flip not in range(8):
            raise ValueError('Unsupported RAW thumbnail orientation.')
        check_cancel(cancel_event)
        thumbnail = raw.extract_thumb()
        check_cancel(cancel_event)
        if thumbnail.format == rawpy.ThumbFormat.JPEG:
            if not isinstance(thumbnail.data, bytes) or len(thumbnail.data) > 32 * 1024 * 1024:
                raise ValueError('Invalid camera JPEG preview.')
            with Image.open(BytesIO(thumbnail.data)) as image:
                return _bounded_image(image, maximum, raw_flip=flip)
        if thumbnail.format == rawpy.ThumbFormat.BITMAP:
            pixels = thumbnail.data
            if (not isinstance(pixels, np.ndarray) or pixels.dtype != np.uint8
                    or pixels.ndim != 3 or pixels.shape[2] != 3
                    or min(pixels.shape[:2]) < 1
                    or pixels.shape[0] * pixels.shape[1] > MAX_RAW_PIXELS):
                raise ValueError('Invalid camera bitmap preview.')
            with Image.fromarray(pixels) as image:
                return _bounded_image(image, maximum, raw_flip=flip)
        raise ValueError('Unsupported camera thumbnail format.')


def _decode_thumbnail(path, maximum, cancel_event):
    check_cancel(cancel_event)
    if path.suffix.lower() in RAW_EXTENSIONS:
        import rawpy
        try:
            pixels = _camera_preview(path, maximum, cancel_event)
            return pixels, 'camera_preview', True
        except AnalysisCancelledError:
            raise
        except (rawpy.LibRawError, ValueError, OSError, RuntimeError,
                Image.DecompressionBombError, Image.DecompressionBombWarning):
            # A missing/invalid embedded image does not make a valid RAW unusable.
            check_cancel(cancel_event)
            pixels, _, _ = decode_raw(path, maximum, quality='interactive', cancel_event=cancel_event)
            return pixels, 'raw_preview', True
    with Image.open(path) as image:
        pixels = _bounded_image(image, maximum)
    check_cancel(cancel_event)
    return pixels, 'image_preview', True


class TravelPreviewCache:
    """Bounded stripped thumbnails with a thread-safe in-memory LRU.

    ``max_bytes`` limits the disk cache; memory separately retains at most 32
    bounded RGB thumbnails. Keys use file identity/stat changes, not a claim of
    content hashing. Disk eviction uses the oldest available file timestamp;
    access-time updates are best effort on platforms without no-follow utime.
    Analysis and final exports retain their strict hashes.
    """
    def __init__(self, cache_dir, max_bytes=256 * 1024 * 1024, max_dimension=480):
        if type(max_bytes) is not int or max_bytes < 0:
            raise ValueError('Preview cache budget must be a nonnegative integer.')
        if type(max_dimension) is not int or not 32 <= max_dimension <= 1024:
            raise ValueError('Preview size must be between 32 and 1024 pixels.')
        supplied = Path(cache_dir).expanduser().absolute()
        if supplied.is_symlink():
            raise ValueError('Preview cache directory must not be a symlink.')
        self.root = supplied.resolve()
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        if self.root.is_symlink() or not self.root.is_dir():
            raise ValueError('Invalid preview cache directory.')
        info = self.root.stat()
        self._root_identity = (info.st_dev, info.st_ino)
        self.max_bytes, self.max_dimension = max_bytes, max_dimension
        with _GATES_LOCK:
            key = str(self.root)
            gate = _GATES.get(key)
            if gate is None:
                gate = _Gate()
                _GATES[key] = gate
            self._gate = gate
        self._memory = OrderedDict()
        self._memory_epoch = gate.epoch
        self._counters = dict(hits=0, disk_hits=0, misses=0, decodes=0, evictions=0, write_errors=0)
        with gate.lock:
            self._prune()

    def _root_ok(self):
        try:
            info = self.root.lstat()
        except OSError as exc:
            raise ValueError('Preview cache directory is unavailable.') from exc
        if (not stat.S_ISDIR(info.st_mode) or (info.st_dev, info.st_ino) != self._root_identity):
            raise ValueError('Preview cache directory changed.')

    def _sync_memory(self):
        if self._memory_epoch != self._gate.epoch:
            self._memory.clear()
            self._memory_epoch = self._gate.epoch

    def _entry_path(self, key):
        return self.root / (key + '.png')

    def _owned_entries(self):
        self._root_ok()
        entries = []
        for path in self.root.iterdir():
            if not _ENTRY.fullmatch(path.name):
                continue
            try:
                info = path.lstat()
            except FileNotFoundError:
                continue
            if stat.S_ISLNK(info.st_mode):
                path.unlink(missing_ok=True)
            elif stat.S_ISREG(info.st_mode):
                entries.append((info.st_mtime_ns, path.name, info.st_size))
        return entries

    def _prune(self):
        entries = sorted(self._owned_entries())
        total = sum(entry[2] for entry in entries)
        count = len(entries)
        for _, name, size in entries:
            if total <= self.max_bytes and count <= _DISK_ENTRIES:
                break
            (self.root / name).unlink(missing_ok=True)
            total -= size
            count -= 1
            self._counters['evictions'] += 1
        # Only our recognizable abandoned temporary files are disposable.
        cutoff = time.time() - 86400
        for path in self.root.iterdir():
            if _TEMP.fullmatch(path.name):
                try:
                    if path.lstat().st_mtime < cutoff:
                        path.unlink(missing_ok=True)
                except FileNotFoundError:
                    pass

    def _remember(self, key, pixels, metadata):
        self._memory[key] = (pixels.copy(), metadata.copy())
        self._memory.move_to_end(key)
        while len(self._memory) > _MEMORY_ENTRIES:
            self._memory.popitem(last=False)

    def _read_disk(self, key, stamp, decoder):
        self._root_ok()
        path = self._entry_path(key)
        descriptor = None
        try:
            before = path.lstat()
            if not stat.S_ISREG(before.st_mode) or before.st_size > self.max_dimension ** 2 * 4 + 16384:
                raise ValueError('Invalid cache entry.')
            flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
            descriptor = os.open(path, flags)
            actual = os.fstat(descriptor)
            if not stat.S_ISREG(actual.st_mode) or (actual.st_dev, actual.st_ino) != (before.st_dev, before.st_ino):
                raise ValueError('Preview cache entry changed.')
            with os.fdopen(descriptor, 'rb') as stream:
                descriptor = None
                data = stream.read(self.max_dimension ** 2 * 4 + 16385)
            if len(data) != before.st_size:
                raise ValueError('Invalid preview cache size.')
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                with Image.open(BytesIO(data)) as image:
                    if image.format != 'PNG' or image.mode != 'RGB' or set(image.info) != {'pcl_preview'}:
                        raise ValueError('Invalid cache format.')
                    metadata = json.loads(image.info['pcl_preview'])
                    if (not isinstance(metadata, dict) or set(metadata) != _METADATA_FIELDS
                            or type(metadata['schema_version']) is not int or metadata['schema_version'] != _SCHEMA
                            or not isinstance(metadata['kind'], str) or metadata['kind'] not in _KINDS
                            or metadata['approximate'] is not True
                            or not isinstance(metadata['source_stamp'], dict)
                            or metadata['source_stamp'] != stamp or set(metadata['source_stamp']) != _STAMP_FIELDS
                            or any(type(value) is not int for value in metadata['source_stamp'].values())
                            or metadata['decoder'] != decoder or type(metadata['bound']) is not int
                            or metadata['bound'] != self.max_dimension
                            or not isinstance(metadata['pixel_sha256'], str)
                            or not re.fullmatch('[0-9a-f]{64}', metadata['pixel_sha256'])
                            or type(metadata['width']) is not int or type(metadata['height']) is not int
                            or image.size != (metadata['width'], metadata['height'])
                            or not 1 <= min(image.size) <= max(image.size) <= self.max_dimension):
                        raise ValueError('Invalid cached thumbnail metadata.')
                    image.verify()
                with Image.open(BytesIO(data)) as image:
                    pixels = np.array(image, dtype=np.uint8)
            if hashlib.sha256(pixels.tobytes()).hexdigest() != metadata['pixel_sha256']:
                raise ValueError('Cached RGB does not match its evidence.')
            try:
                os.utime(path, None, follow_symlinks=False)
            except (OSError, NotImplementedError):
                # Access-time hints are optional. Windows may not implement
                # no-follow timestamp updates; never follow a link instead.
                pass
            return pixels, metadata
        except FileNotFoundError:
            return None
        except (OSError, ValueError, TypeError, KeyError, Image.DecompressionBombError,
                Image.DecompressionBombWarning, json.JSONDecodeError):
            if path.is_symlink() or path.is_file():
                path.unlink(missing_ok=True)
            return None
        finally:
            if descriptor is not None:
                os.close(descriptor)

    def _write_disk(self, key, pixels, metadata):
        info = PngImagePlugin.PngInfo()
        info.add_text('pcl_preview', json.dumps(metadata, sort_keys=True, separators=(',', ':')))
        stream = BytesIO()
        Image.fromarray(pixels).save(stream, format='PNG', pnginfo=info, compress_level=1)
        data = stream.getvalue()
        if len(data) > self.max_bytes:
            return
        self._root_ok()
        temporary = self.root / ('.pcl-preview-' + uuid.uuid4().hex + '.tmp')
        try:
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
            descriptor = os.open(temporary, flags, 0o600)
            with os.fdopen(descriptor, 'wb') as output:
                output.write(data)
                output.flush()
                os.fsync(output.fileno())
            self._root_ok()
            os.replace(temporary, self._entry_path(key))
            self._prune()
        finally:
            temporary.unlink(missing_ok=True)

    def thumbnail(self, path, *, cancel_event=None):
        """Get an independent caller-owned RGB navigation image."""
        path = Path(path).expanduser().resolve(strict=True)
        if path.suffix.lower() not in RAW_EXTENSIONS | IMAGE_EXTENSIONS:
            raise ValueError('Unsupported travel photo.')
        while True:
            check_cancel(cancel_event)
            stamp, decoder = _source_stamp(path), _decoder(path)
            identity = {'schema': _SCHEMA, 'path': str(path), 'source_stamp': stamp,
                        'decoder': decoder, 'bound': self.max_dimension}
            key = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            with self._gate.lock:
                self._root_ok()
                self._sync_memory()
                cached = self._memory.get(key)
                if cached is not None:
                    self._memory.move_to_end(key)
                    self._counters['hits'] += 1
                    try:
                        os.utime(self._entry_path(key), None, follow_symlinks=False)
                    except (OSError, NotImplementedError):
                        pass
                else:
                    cached = self._read_disk(key, stamp, decoder)
                    if cached is not None:
                        self._counters['hits'] += 1
                        self._counters['disk_hits'] += 1
                        self._remember(key, *cached)
                if cached is not None:
                    if _source_stamp(path) != stamp:
                        continue
                    check_cancel(cancel_event)
                    return self._result(*cached, cache_hit=True)
                waiting = self._gate.inflight.get(key)
                if waiting is None:
                    waiting = threading.Event()
                    self._gate.inflight[key] = waiting
                    epoch = self._gate.epoch
                    self._counters['misses'] += 1
                    break
            while not waiting.wait(.05):
                check_cancel(cancel_event)
        try:
            check_cancel(cancel_event)
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                pixels, kind, approximate = _decode_thumbnail(path, self.max_dimension, cancel_event)
            if (not isinstance(pixels, np.ndarray) or pixels.dtype != np.uint8
                    or pixels.ndim != 3 or pixels.shape[2] != 3
                    or not 1 <= min(pixels.shape[:2]) <= max(pixels.shape[:2]) <= self.max_dimension):
                raise ValueError('Invalid navigation thumbnail pixels.')
            if _source_stamp(path) != stamp:
                raise ValueError('Photo changed while its thumbnail was decoded.')
            check_cancel(cancel_event)
            metadata = {'schema_version': _SCHEMA, 'kind': kind, 'approximate': approximate,
                        'width': pixels.shape[1], 'height': pixels.shape[0],
                        'source_stamp': stamp, 'pixel_sha256': hashlib.sha256(pixels.tobytes()).hexdigest(),
                        'decoder': decoder, 'bound': self.max_dimension}
            with self._gate.lock:
                self._counters['decodes'] += 1
                self._root_ok()
                check_cancel(cancel_event)
                if _source_stamp(path) != stamp:
                    raise ValueError('Photo changed while its thumbnail was decoded.')
                if self._gate.epoch == epoch:
                    try:
                        self._write_disk(key, pixels, metadata)
                    except OSError:
                        # A full/read-only cache must not prevent browsing.
                        self._counters['write_errors'] += 1
                    try:
                        if _source_stamp(path) != stamp:
                            raise ValueError('Photo changed while its thumbnail was cached.')
                        check_cancel(cancel_event)
                    except (ValueError, OSError, AnalysisCancelledError):
                        # A source replacement during compression/fsync must
                        # not leave evidence for the previous source identity.
                        self._root_ok()
                        self._entry_path(key).unlink(missing_ok=True)
                        raise
                    self._remember(key, pixels, metadata)
            return self._result(pixels, metadata, cache_hit=False)
        finally:
            with self._gate.lock:
                self._gate.inflight.pop(key, None)
                waiting.set()

    @staticmethod
    def _result(pixels, metadata, *, cache_hit):
        return {'pixels': pixels.copy(), 'kind': metadata['kind'],
                'approximate': metadata['approximate'], 'cache_hit': cache_hit,
                'source_stamp': dict(metadata['source_stamp'])}

    def clear(self):
        with self._gate.lock:
            self._root_ok()
            self._gate.epoch += 1
            self._sync_memory()
            for path in self.root.iterdir():
                if _ENTRY.fullmatch(path.name):
                    if path.is_symlink() or path.is_file():
                        path.unlink(missing_ok=True)

    def stats(self):
        with self._gate.lock:
            self._sync_memory()
            entries = self._owned_entries()
            return {**self._counters, 'memory_entries': len(self._memory),
                    'memory_bytes': sum(value[0].nbytes for value in self._memory.values()),
                    'disk_entries': len(entries), 'disk_bytes': sum(value[2] for value in entries),
                    'max_bytes': self.max_bytes, 'max_dimension': self.max_dimension}
