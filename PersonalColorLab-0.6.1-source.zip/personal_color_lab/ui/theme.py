"""Shared desktop colors and native fonts, with no additional runtime dependency."""

import sys
from importlib.resources import as_file, files
from tkinter import ttk

from .display import configure_window_scale, ui_pixels


COLORS = {
    'bg': '#15171A',
    'surface': '#202328',
    'elevated': '#292E35',
    'inset': '#111316',
    'border': '#343B45',
    'text': '#F5F4F1',
    'muted': '#BCC2CB',
    'subtle': '#9EA8B5',
    'accent': '#C9E5A4',
    'accent_hover': '#DAEDC0',
    'accent_text': '#1D2815',
    'success': '#A3DBA9',
    'warning': '#F1C27B',
    'danger': '#F09C9C',
}


def configure_theme(root):
    """Configure this Tcl interpreter; never retain Python Font/Tk owners."""
    configure_window_scale(root)
    dp = lambda value: ui_pixels(root, value)
    c = COLORS
    families = set(root.tk.splitlist(root.tk.call('font', 'families')))
    preferred = (
        ('Segoe UI', 'Noto Sans', 'Arial') if sys.platform == 'win32'
        else ('SF Pro Text', 'Helvetica Neue', 'Helvetica') if sys.platform == 'darwin'
        else ('Noto Sans', 'DejaVu Sans', 'Liberation Sans')
    )
    family = next((name for name in preferred if name in families), 'Arial')
    if sys.platform == 'darwin':
        # Aqua's native font may have a private family name absent from the
        # public font list. Preserve its system glyph rendering and fallback.
        family = root.tk.call('font', 'actual', 'TkDefaultFont', '-family')
    mono = next((name for name in ('Cascadia Mono', 'Consolas', 'Menlo', 'DejaVu Sans Mono')
                 if name in families), family)
    fonts = {
        'LabDisplay': (family, 26, 'bold'),
        'LabTitle': (family, 21, 'bold'),
        'LabHeading': (family, 12, 'bold'),
        'LabBody': (family, 11, 'normal'),
        'LabSmall': (family, 10, 'normal'),
        'LabMetric': (family, 27, 'bold'),
        'LabKicker': (family, 10, 'bold'),
        'LabMono': (mono, 11, 'normal'),
        'LabNumber': (mono, 11, 'normal'),
    }
    existing = set(root.tk.splitlist(root.tk.call('font', 'names')))
    for name, (face, size, weight) in fonts.items():
        root.tk.call('font', 'configure' if name in existing else 'create', name,
                     '-family', face, '-size', size, '-weight', weight)
    root.tk.call('font', 'configure', 'TkDefaultFont', '-family', family, '-size', 11)
    root.configure(background=c['bg'])
    # The icon is owned by Tcl, like the fonts, so a worker cannot finalize a
    # Python PhotoImage after the window closes.
    with as_file(files('personal_color_lab').joinpath('assets', 'app-icon.png')) as icon_path:
        root.tk.call('image', 'create', 'photo', 'LabAppIcon', '-file', str(icon_path))
    root.tk.call('wm', 'iconphoto', root._w, '-default', 'LabAppIcon')
    root.option_add('*TCombobox*Listbox.background', c['elevated'])
    root.option_add('*TCombobox*Listbox.foreground', c['text'])
    root.option_add('*TCombobox*Listbox.selectBackground', c['accent'])
    root.option_add('*TCombobox*Listbox.selectForeground', c['accent_text'])
    root.option_add('*TCombobox*Listbox.font', 'LabBody')

    style = ttk.Style(root)
    # Clam exposes the same flat colorable elements on Windows, macOS and Linux.
    style.theme_use('clam')
    style.configure('Lab.Horizontal.TScale',background=c['accent'],troughcolor=c['inset'],
                    bordercolor=c['border'],lightcolor=c['accent'],darkcolor=c['accent'],
                    borderwidth=0,sliderlength=dp(18))
    style.configure('.', background=c['bg'], foreground=c['text'],
                    font='LabBody', bordercolor=c['border'], lightcolor=c['border'],
                    darkcolor=c['border'], focuscolor=c['accent'])
    for name, background in (
        ('TFrame', c['bg']), ('Lab.TFrame', c['bg']),
        ('Surface.TFrame', c['surface']), ('Sidebar.TFrame', c['inset']),
        ('Inset.TFrame', c['inset']), ('Elevated.TFrame', c['elevated']),
        ('Studio.TFrame', c['surface']),
    ):
        style.configure(name, background=background, borderwidth=0)
    for name, font, foreground, background in (
        ('TLabel', 'LabBody', c['text'], c['bg']),
        ('Title.TLabel', 'LabTitle', c['text'], c['bg']),
        ('Heading.TLabel', 'LabHeading', c['text'], c['surface']),
        ('Body.TLabel', 'LabBody', c['text'], c['surface']),
        ('Muted.TLabel', 'LabBody', c['muted'], c['bg']),
        ('Small.TLabel', 'LabSmall', c['muted'], c['surface']),
        ('Metric.TLabel', 'LabMetric', c['text'], c['surface']),
        ('Accent.TLabel', 'LabSmall', c['accent'], c['surface']),
        ('Badge.TLabel', 'LabSmall', c['accent'], c['elevated']),
        ('Studio.TLabel', 'LabBody', c['muted'], c['surface']),
        ('StudioHeading.TLabel', 'LabHeading', c['text'], c['surface']),
        ('Kicker.TLabel', 'LabKicker', c['accent'], c['bg']),
    ):
        style.configure(name, font=font, foreground=foreground, background=background,
                        anchor='w', justify='left')

    for name, background, foreground, hover in (
        ('TButton', c['elevated'], c['text'], c['border']),
        ('Primary.TButton', c['accent'], c['accent_text'], c['accent_hover']),
        ('Secondary.TButton', c['elevated'], c['text'], c['border']),
        ('Quiet.TButton', c['surface'], c['muted'], c['elevated']),
        ('Compact.TButton', c['elevated'], c['text'], c['border']),
        ('Link.TButton', c['bg'], c['muted'], c['surface']),
        ('NavPrimary.TButton', c['accent'], c['accent_text'], c['accent_hover']),
        ('NavSecondary.TButton', c['elevated'], c['text'], c['border']),
    ):
        style.configure(name, background=background, foreground=foreground,
                        borderwidth=0, relief='flat', padding=(dp(16), dp(11)),
                        font='LabHeading', focusthickness=dp(2), focuscolor=c['accent'])
        style.map(name,
                  background=[('disabled', c['elevated']), ('pressed', hover), ('active', hover)],
                  foreground=[('disabled', c['subtle'])])

    style.configure('Compact.TButton', padding=(dp(12),dp(7)), font='LabBody')
    style.configure('Link.TButton', padding=(dp(8),dp(6)), font='LabSmall')
    for name in ('NavPrimary.TButton', 'NavSecondary.TButton'):
        style.configure(name, anchor='w', padding=(dp(18),dp(12)), font='LabBody')

    style.configure('Lab.TEntry', fieldbackground=c['inset'], foreground=c['text'],
                    insertcolor=c['text'], borderwidth=dp(1), padding=(dp(11), dp(10)))
    style.map('Lab.TEntry', bordercolor=[('focus', c['accent'])],
              fieldbackground=[('disabled', c['surface'])],
              foreground=[('disabled', c['subtle'])])
    style.configure('Lab.TCombobox', fieldbackground=c['elevated'],
                    background=c['elevated'], foreground=c['text'],
                    arrowcolor=c['muted'], borderwidth=0, padding=(dp(10), dp(8)))
    style.map('Lab.TCombobox', fieldbackground=[('readonly', c['elevated'])],
              foreground=[('readonly', c['text'])],
              selectbackground=[('readonly', c['elevated'])],
              selectforeground=[('readonly', c['text'])],
              bordercolor=[('focus', c['accent'])])
    style.configure('Lab.TCheckbutton', background=c['surface'], foreground=c['muted'],
                    indicatorbackground=c['elevated'], indicatorforeground=c['accent_text'],
                    indicatormargin=dp(6), padding=(0, dp(6)))
    style.map('Lab.TCheckbutton', background=[('active', c['surface'])],
              foreground=[('disabled', c['subtle'])],
              indicatorbackground=[('selected', c['accent']), ('active', c['border'])])
    style.configure('Lab.Horizontal.TProgressbar', background=c['accent'],
                    troughcolor=c['inset'], borderwidth=0, thickness=dp(4))
    style.configure('Lab.Treeview', background=c['surface'], fieldbackground=c['surface'],
                    foreground=c['text'], rowheight=dp(43), borderwidth=0, font='LabBody')
    style.map('Lab.Treeview', background=[('selected', '#354534')],
              foreground=[('selected', c['text'])])
    style.configure('Lab.Treeview.Heading', background=c['elevated'],
                    foreground=c['muted'], font='LabSmall', borderwidth=0,
                    relief='flat', padding=(dp(4), dp(13)))
    style.map('Lab.Treeview.Heading', background=[('active', c['elevated'])])
    style.layout('Lab.Treeview', [('Treeview.treearea', {'sticky': 'nswe'})])
    style.configure('Lab.Vertical.TScrollbar', background=c['border'],
                    troughcolor=c['surface'], borderwidth=0, arrowcolor=c['muted'],
                    arrowsize=dp(12), gripcount=0, width=dp(12))
    style.map('Lab.Vertical.TScrollbar', background=[('active', c['subtle'])])
    style.configure('TSeparator', background=c['border'])
    style.configure('TNotebook', background=c['bg'], borderwidth=0, tabmargins=(0, 0, 0, dp(10)))
    style.configure('TNotebook.Tab', background=c['bg'], foreground=c['muted'],
                    borderwidth=0, padding=(dp(18), dp(10)), font='LabHeading',
                    lightcolor=c['bg'], darkcolor=c['bg'], bordercolor=c['bg'])
    style.map('TNotebook.Tab', background=[('selected', c['surface'])],
              foreground=[('selected', c['accent']), ('active', c['text'])],
              lightcolor=[('selected', c['surface']), ('!selected', c['bg'])],
              darkcolor=[('selected', c['surface']), ('!selected', c['bg'])],
              bordercolor=[('selected', c['surface']), ('!selected', c['bg'])])
