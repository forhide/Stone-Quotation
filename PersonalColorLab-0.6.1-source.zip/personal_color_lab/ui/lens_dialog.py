"""Photo-specific camera/lens selection from the verified local catalogue."""
import tkinter as tk
from tkinter import ttk

from ..core.lens_profiles import equipment_catalog, validate_lens_override
from .display import ui_pixels
from .theme import COLORS


class LensSelectionDialog(tk.Toplevel):
    def __init__(self, parent, equipment, selection, on_apply):
        super().__init__(parent)
        self.parent_workspace = parent
        self.i18n = parent.i18n
        self.on_apply = on_apply
        self._closed = False
        self._fit_after = None
        self._equipment = dict(equipment or {})
        self._initial = dict(selection or equipment or {})
        self.camera = tk.StringVar(self)
        self.lens = tk.StringVar(self)
        self.focal = tk.StringVar(self)
        self.message = tk.StringVar(self)
        self._camera_items = {}
        self._lens_items = {}
        dp = lambda value: ui_pixels(parent, value)
        self.title(self.i18n.t('lens_dialog_title'))
        self.configure(background=COLORS['bg'])
        self.transient(parent)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.resizable(True, True)
        self.minsize(dp(490), dp(330))
        panel = ttk.Frame(self, style='Lab.TFrame', padding=dp(22))
        self._panel = panel
        panel.grid(sticky='nsew')
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        panel.columnconfigure(0, weight=1)
        panel.rowconfigure(8, weight=1)
        help_label = ttk.Label(panel, text=self.i18n.t('lens_dialog_help'), style='Muted.TLabel',
                  wraplength=dp(460), anchor='w', justify='left')
        help_label.grid(row=0, sticky='ew', pady=(0, dp(18)))
        for row, key in ((1, 'lens_camera'), (3, 'lens_lens'), (5, 'lens_focal')):
            ttk.Label(panel, text=self.i18n.t(key), style='Lab.TLabel').grid(row=row, sticky='w')
        self.camera_combo = ttk.Combobox(panel, textvariable=self.camera,
                                       style='Lab.TCombobox', width=49)
        self.camera_combo.grid(row=2, sticky='ew', pady=(dp(5), dp(12)))
        self.lens_combo = ttk.Combobox(panel, textvariable=self.lens,
                                     style='Lab.TCombobox', width=49)
        self.lens_combo.grid(row=4, sticky='ew', pady=(dp(5), dp(12)))
        self.focal_entry = ttk.Entry(panel, textvariable=self.focal, style='Lab.TEntry', font='LabNumber', justify='right')
        self.focal_entry.grid(row=6, sticky='ew', pady=(dp(5), dp(12)))
        message_label = ttk.Label(panel, textvariable=self.message, style='Muted.TLabel',
                  wraplength=dp(460), anchor='w', justify='left')
        message_label.grid(row=7, sticky='ew', pady=(0, dp(15)))
        self._wrapped_labels = [help_label, message_label]
        actions = ttk.Frame(panel, style='Lab.TFrame')
        actions.grid(row=8, sticky='sew')
        actions.columnconfigure(1, weight=1)
        ttk.Button(actions, text=self.i18n.t('lens_use_auto'), command=self.use_automatic,
                   style='Secondary.TButton').grid(row=0, column=0, sticky='w')
        self.apply_button = ttk.Button(actions, text=self.i18n.t('lens_apply_selection'),
                                       command=self.apply_selection, style='Primary.TButton')
        self.apply_button.grid(row=0, column=2, sticky='e')
        self.camera_combo.bind('<<ComboboxSelected>>', self._camera_changed)
        self.camera_combo.bind('<KeyRelease>', self._filter_cameras)
        self.lens_combo.bind('<<ComboboxSelected>>', self._lens_changed)
        self.lens_combo.bind('<KeyRelease>', self._filter_lenses)
        try:
            catalogue = equipment_catalog()
            self._camera_items = {item['label']: item for item in catalogue['cameras']}
            self.camera_combo.configure(values=tuple(self._camera_items))
            self.camera.set(self._initial_label(self._camera_items, 'camera'))
            self._camera_changed()
            self.lens.set(self._initial_label(self._lens_items, 'lens'))
            self.focal.set(str(self._initial.get('focal_length_mm') or ''))
            self._lens_changed()
        except (OSError, ValueError):
            self.message.set(self.i18n.t('lens_database_unavailable'))
            self.apply_button.configure(state='disabled')
        self.bind('<Escape>', lambda event: self.close())
        self.bind('<Configure>', self._resize_text, add='+')
        self.grab_set()

    def _resize_text(self, event):
        if self._closed or event.widget is not self:
            return
        width = max(ui_pixels(self, 160), event.width - ui_pixels(self, 44))
        for label in self._wrapped_labels:
            label.configure(wraplength=width)
        if self._fit_after is None:
            self._fit_after = self.after_idle(self._fit_content_height)

    def _fit_content_height(self):
        self._fit_after = None
        if not self._closed:
            # A narrower translated paragraph can need another line. Keep
            # the action row inside the window instead of clipping it.
            self.minsize(ui_pixels(self, 490), max(ui_pixels(self, 330), self._panel.winfo_reqheight()))

    @staticmethod
    def _name_key(value):
        return str(value or '').casefold().replace('f/', 'f').replace(' ', '')

    def _initial_label(self, items, kind):
        maker = self._initial.get(kind + '_make')
        model = self._initial.get(kind + '_model')
        model_key = self._name_key(model)
        for label, item in items.items():
            canonical = self._name_key(item[kind + '_model'])
            prefix = self._name_key(item[kind + '_make'])
            if model_key in (canonical, prefix + canonical):
                return label
        return ' '.join(str(value) for value in (maker, model) if value)

    def _camera_changed(self, event=None):
        item = self._camera_items.get(self.camera.get())
        if item is None:
            self.apply_button.configure(state='disabled')
            return
        try:
            catalogue = equipment_catalog(item['camera_make'], item['camera_model'])
        except (OSError, ValueError):
            self.message.set(self.i18n.t('lens_database_unavailable'))
            self.apply_button.configure(state='disabled')
            return
        self._lens_items = {lens['label']: lens for lens in catalogue['lenses']}
        if item['camera_make']=='Sony':
            model='FE 16-35mm f/2.8 GM II'
            label='Sony '+model
            self._lens_items.setdefault(label,{'label':label,'lens_make':'Sony',
                                                'lens_model':model,'calibrated':False})
        # An identified, uncalibrated lens remains visible and selectable. It
        # never acquires another lens's optical coefficients.
        known_model = self._initial.get('lens_model')
        if known_model and self._initial.get('lens_make'):
            label = ' '.join(str(value) for value in
                             (self._initial.get('lens_make'), known_model) if value)
            if label not in self._lens_items:
                self._lens_items[label] = {'label': label, 'lens_make': self._initial.get('lens_make') or '',
                                           'lens_model': known_model, 'calibrated': False}
        self.lens_combo.configure(values=tuple(self._lens_items))
        self._lens_changed()

    def _lens_changed(self, event=None):
        item = self._lens_items.get(self.lens.get())
        ready = self.camera.get() in self._camera_items and item is not None
        self.apply_button.configure(state='normal' if ready else 'disabled')
        self.message.set(self.i18n.t('lens_profile_candidate' if ready and item.get('calibrated')
                                    else 'lens_profile_missing'))

    def _filter_cameras(self, event=None):
        query = self.camera.get().casefold()
        self.camera_combo.configure(values=tuple(label for label in self._camera_items
                                                if query in label.casefold()))
        self._camera_changed()

    def _filter_lenses(self, event=None):
        query = self.lens.get().casefold()
        self.lens_combo.configure(values=tuple(label for label in self._lens_items
                                              if query in label.casefold()))
        self._lens_changed()

    def apply_selection(self):
        camera = self._camera_items.get(self.camera.get())
        lens = self._lens_items.get(self.lens.get())
        if camera is None or lens is None:
            return
        try:
            selected = {key: camera[key] for key in ('camera_make', 'camera_model')}
            selected.update({key: lens[key] for key in ('lens_make', 'lens_model')})
            selected['focal_length_mm'] = float(self.focal.get()) if self.focal.get().strip() else None
            selected = validate_lens_override(selected)
        except (ValueError, TypeError, OverflowError):
            self.message.set(self.i18n.t('lens_invalid_selection'))
            return
        self.on_apply(selected)
        self.close()

    def use_automatic(self):
        self.on_apply(None)
        self.close()

    def close(self):
        if self._closed:
            return
        self._closed = True
        if self._fit_after is not None:
            self.after_cancel(self._fit_after)
            self._fit_after = None
        if getattr(self.parent_workspace, '_lens_dialog', None) is self:
            self.parent_workspace._lens_dialog = None
        self.grab_release()
        super().destroy()
        self.on_apply = None
        self.parent_workspace = None
        self._camera_items.clear()
        self._lens_items.clear()
        self._wrapped_labels.clear()
        self.camera = self.lens = self.focal = self.message = None
        self.camera_combo = self.lens_combo = self.focal_entry = self.apply_button = None
        self._panel = None

    def destroy(self):
        self.close()
