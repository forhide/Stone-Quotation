"""A persistent trip contact sheet with bounded previews and durable exports.

Workers receive queues, events and copied request data only. All Tk objects,
including image creation and destruction, stay on their owning UI thread.
"""
from __future__ import annotations

import base64
import copy
from io import BytesIO
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import filedialog, ttk

from PIL import Image

from ..core.constants import DB_FILENAME, app_data_dir
from ..core.database import LibraryDB
from ..core.style_dna import builtin_styles, dna_from_batch
from ..core.travel_adjustments import effective_strength, validate_adjustments
from ..core.travel_store import TravelStore
from .display import ui_pixels
from .studio_controls import StudioSlider
from .theme import COLORS as C
from .travel_grid import TravelGrid


def _travel_job(events, generation, kind, request, cancel):
    """No bound widget methods or Tk values may enter this worker."""
    try:
        if kind == 'scan':
            from ..core.travel_analysis import scan_travel_folder, suggest_groups
            photos = scan_travel_folder(request['folder'], recursive=request['recursive'],
                cancel_event=cancel, progress=lambda done,total,name: events.put(
                    ('progress',generation,kind,{'completed':done,'total':total,'current':name,'status':'scanning'})))
            if cancel.is_set():
                events.put(('result',generation,kind,{'cancelled':True}));return
            with TravelStore(request['db_path']) as store:
                counts=store.import_photos(request['project_id'],photos)
                imported=store.list_photos(request['project_id'])
                for group in suggest_groups(imported,cancel_event=cancel):
                    if len(group['photo_ids'])>1:
                        for photo_id in group['photo_ids']:
                            if cancel.is_set():break
                            store.update_photo(photo_id,group_id=group['id'])
            result={'counts':counts,'cancelled':cancel.is_set()}
        elif kind == 'export':
            from ..core.travel_jobs import enqueue_exports, run_exports
            callback=lambda data: events.put(('progress',generation,kind,data))
            preparation_failed = 0
            if request.get('enqueue'):
                result=enqueue_exports(request['db_path'],request['project_id'],request['dna'],
                    request['destination'],strength=request['strength'],recognition=request['recognition'],
                    lens_correction=request['lens_correction'],photo_ids=request.get('photo_ids'),
                    output_size=request['output_size'],cancel_event=cancel,progress=callback)
                preparation_failed=result.get('preparation_failed',0)
            if not cancel.is_set():
                result=run_exports(request['db_path'],request['project_id'],cancel_event=cancel,progress=callback)
                result['preparation_failed']=preparation_failed
            else:
                if not request.get('enqueue'):result={}
                result['cancelled']=True
                result['preparation_cancelled']=bool(request.get('enqueue'))
        elif kind == 'preview':
            from ..core.style_render import render_preview
            from ..core.travel_analysis import review_preview
            adjustments=request['adjustments']
            result=render_preview(request['source'],request['dna'],
                strength=effective_strength(request['strength'],adjustments),
                cancel_event=cancel,base=request.get('base'),recognition=request['recognition'],
                lens_correction=request['lens_correction'],raw_quality='interactive' if request['fast_raw'] else 'baseline',
                scene_override=request.get('scene_override'),photo_adjustments=adjustments,evidence_cache=True)
            result['travel_review']=review_preview(result)
        else:raise ValueError('Unknown travel job.')
        events.put(('result',generation,kind,result))
    except Exception as exc:
        if not cancel.is_set():events.put(('error',generation,kind,str(exc)))
    finally:events.put(('finished',generation,kind,None))


def _thumbnail_worker(requests,events,cancel,cache_dir):
    from ..core.travel_previews import TravelPreviewCache
    cache=TravelPreviewCache(cache_dir)
    while not cancel.is_set():
        try:photo_id,path,stamp=requests.get(timeout=.15)
        except queue.Empty:continue
        if cancel.is_set():break
        try:
            result=cache.thumbnail(path,cancel_event=cancel)
            if not cancel.is_set():events.put(('thumbnail',photo_id,stamp,result))
        except Exception:
            if not cancel.is_set():events.put(('thumbnail_error',photo_id,stamp,None))


class TravelWorkspace(tk.Toplevel):
    """Edit a whole trip without changing source photographs or learned DNA."""
    def __init__(self,parent,project_id=None,folder=None):
        super().__init__(parent)
        self.i18n=parent.i18n
        self.db_path=app_data_dir()/DB_FILENAME
        self._closed=False;self._busy=False;self._loading=False
        self._events=queue.Queue();self._thumb_requests=queue.Queue(maxsize=80)
        self._stop=threading.Event();self._cancel=threading.Event();self._preview_cancel=threading.Event()
        self._threads=[];self._generation=0;self._preview_generation=0
        self._preview_running=False;self._preview_pending=False;self._preview_after=None;self._edit_after=None
        self._thumb_requested=set();self._labels=[];self._buttons=[];self._sliders=[];self._photos=[]
        self._pick_buttons={};self._value_labels={};self._task_counts={};self._preparation_issues={}
        self._queue_dirty=False;self._last_queue_refresh=0.
        self._rail_bindtag='TravelRail:'+self._w
        self._styles={};self._style_choices={};self._projects={};self._project_id=None;self._active_id=None
        self._preview=None;self._preview_source=None;self._preview_images=[];self._review_codes=[]
        self.project=tk.StringVar(master=self);self.style=tk.StringVar(master=self)
        self.filter=tk.StringVar(master=self);self.output_size=tk.StringVar(master=self)
        self.strength=tk.DoubleVar(master=self,value=70)
        self.exposure=tk.DoubleVar(master=self,value=0);self.warmth=tk.DoubleVar(master=self,value=0)
        self.tint=tk.DoubleVar(master=self,value=0);self.photo_strength=tk.DoubleVar(master=self,value=100)
        self.recognition=tk.BooleanVar(master=self,value=True);self.lens_correction=tk.BooleanVar(master=self,value=True)
        self.fast_raw=tk.BooleanVar(master=self,value=False)
        self.progress=tk.DoubleVar(master=self,value=0);self.status=tk.StringVar(master=self)
        self.destination=None;self._status_key='travel_start_hint';self._status_values={}
        dp=lambda n:ui_pixels(self,n)
        self.geometry(f'{dp(1260)}x{dp(870)}');self.minsize(dp(1080),dp(760))
        self.configure(background=C['bg']);self.transient(parent);self.protocol('WM_DELETE_WINDOW',self.close)
        self._build();self._load_styles();self._reload_projects();self.translate()
        thread=threading.Thread(target=_thumbnail_worker,args=(self._thumb_requests,self._events,self._stop,
            str(app_data_dir()/'travel-previews')),daemon=True,name='travel-thumbnails')
        thread.start();self._threads.append(thread)
        self._poll_id=self.after(50,self._poll)
        if folder is not None:self.import_folder(folder)
        elif project_id is not None:self.load_project(project_id)
        elif self._projects:self.load_project(next(iter(self._projects.values())))

    def _label(self,parent,key,style='Muted.TLabel',**kwargs):
        kwargs.setdefault('anchor','w');kwargs.setdefault('justify','left')
        label=ttk.Label(parent,text=self.i18n.t(key),style=style,**kwargs)
        self._labels.append((label,key));return label

    def _button(self,parent,key,command,primary=False):
        button=ttk.Button(parent,text=self.i18n.t(key),command=command,
            style='Primary.TButton' if primary else 'Compact.TButton')
        self._buttons.append((button,key));return button

    def _build(self):
        dp=lambda n:ui_pixels(self,n)
        self.columnconfigure(0,weight=1);self.rowconfigure(1,weight=1)
        header=ttk.Frame(self,style='Lab.TFrame',padding=(dp(22),dp(16)))
        header.grid(row=0,column=0,sticky='ew');header.columnconfigure(0,weight=1)
        self._label(header,'travel_title','Title.TLabel').grid(row=0,column=0,sticky='w')
        self._label(header,'travel_steps',font='LabSmall').grid(row=1,column=0,sticky='w',pady=(dp(5),0))
        self.project_combo=ttk.Combobox(header,textvariable=self.project,state='readonly',style='Lab.TCombobox',width=24)
        self.project_combo.grid(row=0,column=1,sticky='e',padx=dp(12))
        self.project_combo.bind('<<ComboboxSelected>>',self._project_chosen)
        self.new_btn=self._button(header,'travel_new',self.choose_trip,True)
        self.new_btn.grid(row=0,column=2,sticky='e')
        self.path_label=ttk.Label(header,style='Muted.TLabel',font='LabSmall',anchor='e',width=48)
        self.path_label.grid(row=1,column=1,columnspan=2,sticky='e',pady=(dp(6),0))
        body=tk.Frame(self,background=C['bg']);body.grid(row=1,column=0,sticky='nsew',padx=dp(22))
        body.rowconfigure(0,weight=1);body.columnconfigure(0,weight=1)
        left=tk.Frame(body,background=C['bg']);left.grid(row=0,column=0,sticky='nsew',padx=(0,dp(16)))
        left.columnconfigure(0,weight=1);left.rowconfigure(1,weight=1)
        toolbar=ttk.Frame(left,style='Lab.TFrame');toolbar.grid(row=0,column=0,sticky='ew',pady=(0,dp(9)))
        self.filter_combo=ttk.Combobox(toolbar,textvariable=self.filter,state='readonly',style='Lab.TCombobox',width=12)
        self.filter_combo.grid(row=0,column=0,sticky='w')
        self.filter_combo.bind('<<ComboboxSelected>>',lambda e:self._refresh_grid())
        for column,pick in enumerate(('keep','hold','reject'),1):
            button=self._button(toolbar,'travel_mark_'+pick,lambda p=pick:self.mark_pick(p))
            button.grid(row=0,column=column,padx=(dp(7),0));self._pick_buttons[pick]=button
        toolbar.columnconfigure(4,weight=1)
        self.count_label=ttk.Label(toolbar,style='Muted.TLabel',font='LabSmall',anchor='w')
        self.count_label.grid(row=1,column=0,columnspan=5,sticky='ew',pady=(dp(7),0))
        self.notebook=ttk.Notebook(left);self.notebook.grid(row=1,column=0,sticky='nsew')
        self.sheet=tk.Frame(self.notebook,background=C['bg']);self.sheet.rowconfigure(0,weight=1);self.sheet.columnconfigure(0,weight=1)
        self.notebook.add(self.sheet)
        self.grid_view=TravelGrid(self.sheet,self.i18n,on_selection=self._selection_changed,on_visible=self._visible_photos,on_pick=self.mark_pick,
            on_open=lambda:self.notebook.select(self.compare))
        self.grid_view.grid(row=0,column=0,sticky='nsew')
        self.empty=tk.Frame(self.sheet,background=C['bg'])
        self.empty.grid(row=0,column=0,sticky='nsew');self.empty.columnconfigure(0,weight=1);self.empty.rowconfigure(0,weight=1)
        empty_card=ttk.Frame(self.empty,style='Lab.TFrame',padding=dp(30));empty_card.grid(row=0,column=0)
        self.empty_title=self._label(empty_card,'travel_empty_title','Title.TLabel')
        self.empty_title.pack(anchor='w',pady=(0,dp(10)))
        self.empty_hint=self._label(empty_card,'travel_empty_hint',wraplength=dp(400))
        self.empty_hint.pack(anchor='w',pady=(0,dp(18)))
        self.empty_btn=self._button(empty_card,'travel_new',self.choose_trip,True);self.empty_btn.pack(anchor='w')
        self.compare=tk.Frame(self.notebook,background=C['inset']);self.compare.columnconfigure((0,1),weight=1);self.compare.rowconfigure(1,weight=1)
        self.notebook.add(self.compare)
        self._label(self.compare,'travel_before').grid(row=0,column=0,sticky='w',padx=dp(12),pady=dp(12))
        self._label(self.compare,'travel_after').grid(row=0,column=1,sticky='w',padx=dp(12),pady=dp(12))
        self.before_label=tk.Label(self.compare,background=C['inset'],foreground=C['muted'],font='LabSmall')
        self.after_label=tk.Label(self.compare,background=C['inset'],foreground=C['muted'],font='LabSmall')
        self.before_label.grid(row=1,column=0,sticky='nsew');self.after_label.grid(row=1,column=1,sticky='nsew')
        self.preview_note=ttk.Label(self.compare,style='Muted.TLabel',font='LabSmall',wraplength=dp(620),anchor='w',justify='left')
        self.preview_note.grid(row=2,column=0,columnspan=2,sticky='ew',padx=dp(15),pady=dp(12))
        self.review_label=ttk.Label(self.compare,style='Muted.TLabel',font='LabSmall',wraplength=dp(620),justify='left',anchor='w')
        self.review_label.grid(row=3,column=0,columnspan=2,sticky='ew',padx=dp(15),pady=(0,dp(10)))
        self.compare.bind('<Configure>',self._resize_preview)
        self.notebook.bind('<<NotebookTabChanged>>',self._tab_changed)
        self.queue_tab=tk.Frame(self.notebook,background=C['bg']);self.queue_tab.rowconfigure(0,weight=1);self.queue_tab.columnconfigure(0,weight=1)
        self.notebook.add(self.queue_tab)
        self.tasks=ttk.Treeview(self.queue_tab,columns=('file','status','detail'),show='headings',style='Lab.Treeview')
        self.tasks.column('file',width=dp(200),stretch=True,anchor='w');self.tasks.column('status',width=dp(120),stretch=False,anchor='w')
        self.tasks.column('detail',width=dp(250),stretch=True,anchor='w');self.tasks.grid(row=0,column=0,sticky='nsew')
        self.tasks.tag_configure('running',foreground=C['accent']);self.tasks.tag_configure('failed',foreground=C['warning'])
        task_scroll=ttk.Scrollbar(self.queue_tab,orient='vertical',command=self.tasks.yview,style='Lab.Vertical.TScrollbar')
        task_scroll.grid(row=0,column=1,sticky='ns');self.tasks.configure(yscrollcommand=task_scroll.set)
        self.queue_empty=self._label(self.queue_tab,'travel_queue_empty','Studio.TLabel',wraplength=dp(430),padding=dp(24))
        self.queue_empty.grid(row=0,column=0,sticky='nsew')
        self.queue_summary=ttk.Label(self.queue_tab,style='Muted.TLabel',font='LabSmall',anchor='w')
        self.queue_summary.grid(row=1,column=0,columnspan=2,sticky='ew',pady=(dp(8),0))
        self.queue_detail=ttk.Label(self.queue_tab,style='Muted.TLabel',font='LabSmall',anchor='w',justify='left',wraplength=dp(620))
        self.queue_detail.grid(row=2,column=0,columnspan=2,sticky='ew',pady=(dp(5),0))
        self.tasks.bind('<<TreeviewSelect>>',lambda event:self._queue_selection_changed())
        self._label(left,'travel_shortcuts',font='LabSmall').grid(row=2,column=0,sticky='w',pady=(dp(8),0))
        rail=tk.Frame(body,background=C['surface'],width=dp(310));rail.grid(row=0,column=1,sticky='ns');rail.grid_propagate(False)
        rail.rowconfigure(0,weight=1);rail.columnconfigure(0,weight=1)
        rail_canvas=tk.Canvas(rail,background=C['surface'],highlightthickness=0,width=dp(290))
        rail_canvas.grid(row=0,column=0,sticky='nsew')
        rail_scroll=ttk.Scrollbar(rail,orient='vertical',command=rail_canvas.yview,style='Lab.Vertical.TScrollbar')
        rail_scroll.grid(row=0,column=1,sticky='ns');rail_canvas.configure(yscrollcommand=rail_scroll.set)
        settings=ttk.Frame(rail_canvas,style='Studio.TFrame',padding=dp(16));window=rail_canvas.create_window(0,0,window=settings,anchor='nw')
        settings.columnconfigure(0,weight=1)
        settings.bind('<Configure>',lambda e:rail_canvas.configure(scrollregion=rail_canvas.bbox('all')))
        rail_canvas.bind('<Configure>',lambda e:rail_canvas.itemconfigure(window,width=e.width))
        self._label(settings,'travel_style_heading','StudioHeading.TLabel').grid(row=0,column=0,sticky='w')
        self.style_combo=ttk.Combobox(settings,textvariable=self.style,state='readonly',style='Lab.TCombobox',width=23)
        self.style_combo.grid(row=1,column=0,sticky='ew',pady=(dp(9),dp(5)));self.style_combo.bind('<<ComboboxSelected>>',self._settings_changed)
        self._slider(settings,2,'travel_style_strength',self.strength,0,100,self._settings_changed,'%')
        self._label(settings,'travel_adaptive_hint','Studio.TLabel',wraplength=dp(250),font='LabSmall').grid(row=4,column=0,sticky='ew',pady=(0,dp(12)))
        self.recognition_check=ttk.Checkbutton(settings,variable=self.recognition,style='Lab.TCheckbutton',command=self._settings_changed)
        self.recognition_check.grid(row=5,column=0,sticky='w')
        self.lens_check=ttk.Checkbutton(settings,variable=self.lens_correction,style='Lab.TCheckbutton',command=self._settings_changed)
        self.lens_check.grid(row=6,column=0,sticky='w',pady=dp(7))
        self.fast_check=ttk.Checkbutton(settings,variable=self.fast_raw,style='Lab.TCheckbutton',command=self._settings_changed)
        self.fast_check.grid(row=7,column=0,sticky='w',pady=(0,dp(15)))
        ttk.Separator(settings).grid(row=8,column=0,sticky='ew',pady=(0,dp(15)))
        self._label(settings,'travel_photo_heading','StudioHeading.TLabel').grid(row=9,column=0,sticky='w')
        self.photo_label=ttk.Label(settings,style='Studio.TLabel',font='LabSmall',wraplength=dp(250))
        self.photo_label.grid(row=10,column=0,sticky='ew',pady=(dp(6),dp(8)))
        for row,key,var,low,high,suffix in [(11,'travel_exposure',self.exposure,-3,3,' EV'),
            (13,'travel_warmth',self.warmth,-100,100,'%'),(15,'travel_tint',self.tint,-100,100,'%'),
            (17,'travel_photo_strength',self.photo_strength,0,100,'%')]:
            self._slider(settings,row,key,var,low,high,self._edits_changed,suffix)
        self._label(settings,'travel_adjustment_hint','Studio.TLabel',wraplength=dp(250),font='LabSmall').grid(row=19,column=0,sticky='ew',pady=(0,dp(10)))
        self.selected_btn=self._button(settings,'travel_apply_selected',self.apply_to_selected)
        self.selected_btn.grid(row=20,column=0,sticky='ew',pady=(0,dp(12)))
        self.group_hint=ttk.Label(settings,style='Studio.TLabel',font='LabSmall',wraplength=dp(250),anchor='w',justify='left')
        self.group_hint.grid(row=21,column=0,sticky='ew',pady=(0,dp(7)))
        self.select_group_btn=self._button(settings,'travel_group_badge',self.select_group)
        self.select_group_btn.grid(row=22,column=0,sticky='ew',pady=(0,dp(7)))
        self.group_btn=self._button(settings,'travel_apply_group',self.apply_to_group)
        self.group_btn.grid(row=23,column=0,sticky='ew',pady=(0,dp(7)))
        self.reset_btn=self._button(settings,'travel_reset',self.reset_adjustments)
        self.reset_btn.grid(row=24,column=0,sticky='ew',pady=(0,dp(15)))
        self.inspect_btn=self._button(settings,'travel_inspect',lambda:self.notebook.select(self.compare))
        self.inspect_btn.grid(row=25,column=0,sticky='ew')
        self._bind_rail_scrolling(settings,rail_canvas)
        footer=tk.Frame(self,background=C['surface'],padx=dp(22),pady=dp(13))
        footer.grid(row=2,column=0,sticky='ew');footer.columnconfigure(0,weight=1)
        self._label(footer,'travel_export_folder_label','Studio.TLabel',font='LabSmall').grid(row=0,column=0,sticky='w',pady=(0,dp(5)))
        self.destination_btn=self._button(footer,'travel_destination',self.choose_destination)
        self.destination_btn.grid(row=1,column=0,sticky='w')
        self._label(footer,'travel_output_size_label','Studio.TLabel',font='LabSmall').grid(row=0,column=1,sticky='w',padx=dp(8),pady=(0,dp(5)))
        self.size_combo=ttk.Combobox(footer,textvariable=self.output_size,state='readonly',style='Lab.TCombobox',width=14)
        self.size_combo.grid(row=1,column=1,padx=dp(8));self.size_combo.bind('<<ComboboxSelected>>',self._settings_changed)
        self.export_selected_btn=self._button(footer,'travel_export_selected',lambda:self.start_export(selected=True))
        self.export_selected_btn.grid(row=1,column=2,padx=(0,dp(8)))
        self.export_btn=self._button(footer,'travel_export_keep',self.start_export,True)
        self.export_btn.grid(row=1,column=3)
        self.destination_path=ttk.Label(footer,style='Studio.TLabel',font='LabSmall',anchor='w',width=1)
        self.destination_path.grid(row=2,column=0,columnspan=4,sticky='ew',pady=(dp(5),0))
        queue_controls=ttk.Frame(footer,style='Studio.TFrame');queue_controls.grid(row=3,column=0,columnspan=4,sticky='ew',pady=(dp(10),0));queue_controls.columnconfigure(0,weight=1)
        ttk.Label(queue_controls,textvariable=self.status,style='Studio.TLabel',font='LabSmall',wraplength=dp(650)).grid(row=0,column=0,sticky='w',padx=(0,dp(10)))
        self.resume_btn=self._button(queue_controls,'travel_resume',self.resume_exports);self.resume_btn.grid(row=0,column=1,padx=(0,dp(7)))
        self.retry_btn=self._button(queue_controls,'travel_retry',self.retry_failed);self.retry_btn.grid(row=0,column=2,padx=(0,dp(7)))
        self.cancel_btn=self._button(queue_controls,'travel_pause',self.pause);self.cancel_btn.grid(row=0,column=3)
        ttk.Progressbar(footer,variable=self.progress,maximum=100,style='Lab.Horizontal.TProgressbar').grid(row=4,column=0,columnspan=4,sticky='ew',pady=(dp(10),0))

    def _bind_rail_scrolling(self,widget,canvas):
        widget.bindtags((self._rail_bindtag,)+widget.bindtags())
        for child in widget.winfo_children():self._bind_rail_scrolling(child,canvas)
        if widget.master==canvas:
            for sequence in ('<MouseWheel>','<Button-4>','<Button-5>'):
                self.bind_class(self._rail_bindtag,sequence,lambda event,c=canvas:self._rail_wheel(event,c))

    @staticmethod
    def _rail_wheel(event,canvas):
        units=-1 if getattr(event,'num',0)==4 else 1 if getattr(event,'num',0)==5 else -1 if event.delta>0 else 1
        canvas.yview_scroll(units*3,'units');return 'break'

    def _slider(self,parent,row,key,variable,low,high,command,suffix):
        dp=lambda n:ui_pixels(self,n)
        line=ttk.Frame(parent,style='Studio.TFrame');line.grid(row=row,column=0,sticky='ew');line.columnconfigure(0,weight=1)
        self._label(line,key,'Studio.TLabel',font='LabSmall').grid(row=0,column=0,sticky='w')
        value=ttk.Label(line,style='Studio.TLabel',font='LabNumber',anchor='e',justify='right',width=10)
        value.grid(row=0,column=1,sticky='e');self._value_labels[key]=value
        def display(*args):
            amount=round(variable.get(),2 if high==3 else 0) or 0.
            value.configure(text=(f'{amount:+.2f}' if high==3 else f'{amount:+.0f}' if low<0 and amount else f'{amount:.0f}')+suffix)
        trace=variable.trace_add('write',display);display()
        slider=StudioSlider(parent,variable=variable,from_=low,to=high,command=command,background=C['surface'])
        slider.grid(row=row+1,column=0,sticky='ew',pady=(0,dp(9)))
        self._sliders.append((slider,variable,trace))

    def _load_styles(self):
        self._styles={f'builtin:{dna["name"]}':dna for dna in builtin_styles()}
        with LibraryDB(self.db_path) as db:
            for row in db.list_source_profiles():
                record=db.get_source_profile(row['id'])
                try:dna=dna_from_batch(record['payload'],row['name'])
                except (ValueError,KeyError,TypeError):continue
                self._styles[f'analysis:{row["id"]}']=dna
            for row in db.list_style_presets():
                record=db.get_style_preset(row['id'])
                self._styles[f'saved:{row["id"]}']=record['dna']
        self._style_key=next(iter(self._styles))

    def _reload_projects(self):
        with TravelStore(self.db_path) as store:projects=store.list_projects()
        self._projects={f'{row["name"]} · {row["id"]}':row['id'] for row in projects}
        self.project_combo.configure(values=list(self._projects))

    def _project_chosen(self,event=None):
        if not self._busy and self.project.get() in self._projects:self.load_project(self._projects[self.project.get()])

    def choose_trip(self):
        if self._busy:return
        folder=filedialog.askdirectory(parent=self,title=self.i18n.t('travel_choose_folder'))
        if folder:self.import_folder(folder)

    def import_folder(self,folder):
        if self._busy:return
        folder=Path(folder).expanduser()
        if not folder.is_dir():self._set_status('travel_folder_missing');return
        with TravelStore(self.db_path) as store:
            existing=next((row for row in store.list_projects() if Path(row['root_path'])==folder.resolve()),None)
            project_id=existing['id'] if existing else store.create_project(folder.name,str(folder.resolve()),recursive=True)
        self._reload_projects();self.load_project(project_id)
        self._start('scan',{'db_path':str(self.db_path),'project_id':project_id,'folder':str(folder),'recursive':True})
        self._set_status('travel_scanning')

    def load_project(self,project_id):
        if self._busy:return
        self._flush_edits();self._preview_cancel.set();self._preview_generation+=1
        with TravelStore(self.db_path) as store:
            project=store.get_project(project_id)
            if project is None:return
            photos=store.list_photos(project_id)
        self._loading=True;self._project_id=project_id;self._photos=photos;self._active_id=None
        self._preparation_issues.clear();self._task_counts={}
        self._preview=None;self._preview_source=None;self._review_codes=[];self._thumb_requested.clear()
        self.grid_view._images.clear();self.grid_view._errors.clear();self.grid_view.visible_ids=()
        self.project.set(next((name for name,value in self._projects.items() if value==project_id),project['name']))
        self.path_label.configure(text=str(project['root_path']))
        settings=project.get('settings') or {}
        key=settings.get('style_key',self._style_key)
        self._style_key=key if key in self._styles else next(iter(self._styles))
        self.strength.set(float(settings.get('strength',.7))*100)
        self.recognition.set(settings.get('recognition',True));self.lens_correction.set(settings.get('lens_correction',True))
        self.fast_raw.set(settings.get('fast_raw',False));self.destination=settings.get('output_folder')
        self._size_code=settings.get('output_size','original');self._loading=False
        self.translate();self._refresh_grid();self._refresh_tasks();self._clear_preview()
        self._set_status('travel_project_ready',count=len(photos))

    def _refresh_grid(self):
        code=self._filter_choices.get(self.filter.get(),'all')
        numbers={}
        for photo in self._photos:
            if photo.get('group_id'):
                photo['_group_number']=numbers.setdefault(photo['group_id'],len(numbers)+1)
        rows=[row for row in self._photos if code=='all' or row.get('pick','keep')==code]
        self.grid_view.set_rows(rows)
        if self._active_id is not None and self._active_id not in self.grid_view.selected_ids:
            self._selection_changed(self.grid_view.selection())
        self._update_empty()
        self._update_count();self._update_actions()

    def _update_count(self):
        counts={pick:sum(row.get('pick','keep')==pick for row in self._photos) for pick in ('keep','hold','reject')}
        self.count_label.configure(text=self.i18n.t('travel_selection_summary',selected=len(self.grid_view.selected_ids),total=len(self._photos),**counts))

    def _update_empty(self):
        if self.grid_view.rows:
            self.empty.grid_remove();return
        filtered=bool(self._photos)
        self.empty_title.configure(text=self.i18n.t('travel_filter_empty_title' if filtered else 'travel_empty_title'))
        self.empty_hint.configure(text=self.i18n.t('travel_filter_empty_hint' if filtered else 'travel_empty_hint'))
        self.empty_btn.configure(text=self.i18n.t('travel_show_all' if filtered else 'travel_new'),
            command=self.show_all if filtered else self.choose_trip)
        self.empty.grid()

    def show_all(self):
        self.filter.set(next(label for label,code in self._filter_choices.items() if code=='all'))
        self._refresh_grid()

    def _group_ids(self):
        row=self._active_photo()
        if not row or not row.get('group_id'):return []
        return [photo['id'] for photo in self._photos if photo.get('group_id')==row['group_id']]

    def select_group(self):
        ids=self._group_ids();active=self._active_id
        if not ids:return
        self.show_all();self.grid_view.select_ids(ids,active_id=active)
        self.grid_view.ensure_visible(active)

    def _visible_photos(self,rows):
        for row in rows:
            photo_id=row['id']
            if photo_id in self.grid_view._images or photo_id in self.grid_view._errors or photo_id in self._thumb_requested:continue
            stamp=(row['source_path'],row.get('size_bytes'),row.get('mtime_ns'))
            try:self._thumb_requests.put_nowait((photo_id,row['source_path'],stamp))
            except queue.Full:break
            self._thumb_requested.add(photo_id)

    def _active_photo(self):
        return next((row for row in self._photos if row['id']==self._active_id),None)

    def _selection_changed(self,ids):
        self._flush_edits()
        anchor=self.grid_view._anchor
        self._active_id=anchor if anchor in ids else ids[0] if ids else None
        self.grid_view.active_id=self._active_id;self.grid_view._schedule()
        row=self._active_photo();self._loading=True
        adjustments=validate_adjustments(row.get('adjustments')) if row else validate_adjustments()
        self.exposure.set(adjustments['exposure_ev']);self.warmth.set(adjustments['temperature']*100)
        self.tint.set(adjustments['tint']*100);self.photo_strength.set(adjustments['strength']*100)
        self._loading=False
        if not row or self._preview_source!=row['source_path']:self._clear_preview()
        self._update_count();self._update_actions();self._schedule_preview()

    def mark_pick(self,pick):
        if self._busy or pick not in ('keep','hold','reject') or not self._project_id:return
        selected=set(self.grid_view.selection())
        with TravelStore(self.db_path) as store:
            for row in self._photos:
                if row['id'] in selected:store.update_photo(row['id'],pick=pick);row['pick']=pick
        self._refresh_grid()

    def _settings_changed(self,event=None):
        if self._loading or self._busy:return
        self._style_key=self._style_choices.get(self.style.get(),self._style_key)
        self._size_code=self._size_choices.get(self.output_size.get(),'original')
        if self._project_id:
            with TravelStore(self.db_path) as store:
                store.configure_project(self._project_id,{'style_key':self._style_key,'strength':self.strength.get()/100,
                    'recognition':self.recognition.get(),'lens_correction':self.lens_correction.get(),
                    'fast_raw':self.fast_raw.get(),'output_size':self._size_code})
        self._schedule_preview()

    def _adjustments(self):
        return validate_adjustments({'exposure_ev':self.exposure.get(),'temperature':self.warmth.get()/100,
            'tint':self.tint.get()/100,'strength':self.photo_strength.get()/100})

    def _edits_changed(self,event=None):
        if self._loading or self._busy or self._active_id is None:return
        if self._edit_after is not None:self.after_cancel(self._edit_after)
        self._edit_after=self.after(180,self._commit_edits)

    def _commit_edits(self):
        self._edit_after=None
        row=self._active_photo()
        if row:
            row['adjustments']=self._adjustments()
            with TravelStore(self.db_path) as store:store.update_photo(row['id'],adjustments=row['adjustments'])
        self._schedule_preview()

    def _flush_edits(self):
        if self._edit_after is not None:
            self.after_cancel(self._edit_after);self._edit_after=None;self._commit_edits()

    def _apply_adjustments(self,ids,adjustments):
        if self._busy:return
        self._flush_edits();ids=set(ids)
        with TravelStore(self.db_path) as store:
            for row in self._photos:
                if row['id'] in ids:store.update_photo(row['id'],adjustments=adjustments);row['adjustments']=copy.deepcopy(adjustments)
        self._schedule_preview();self._set_status('travel_adjustments_applied',count=len(ids))

    def apply_to_selected(self):self._apply_adjustments(self.grid_view.selection(),self._adjustments())

    def apply_to_group(self):
        ids=self._group_ids()
        if not ids:return
        self._apply_adjustments(ids,self._adjustments())

    def reset_adjustments(self):
        ids=self.grid_view.selection();self._apply_adjustments(ids,validate_adjustments())
        self._selection_changed(ids)

    def _schedule_preview(self,event=None):
        if self._closed or self._loading:return
        if self._preview_after is not None:self.after_cancel(self._preview_after)
        self._preview_after=None
        self._preview_cancel.set();self._preview_generation+=1
        if self.notebook.select()!=str(self.compare):
            self._preview_pending=False;return
        self._preview_after=self.after(180,self._launch_preview)

    def _tab_changed(self,event=None):
        if not self._closed:
            if self.notebook.select()==str(self.queue_tab):self._queue_dirty=True
            self._schedule_preview()

    def _launch_preview(self):
        self._preview_after=None
        if self.notebook.select()!=str(self.compare):self._preview_pending=False;return
        if self._preview_running:self._preview_pending=True;return
        row=self._active_photo()
        if row is None:self._clear_preview();return
        self._preview_pending=False;self._preview_running=True;self._preview_cancel=threading.Event()
        base=self._preview if self._preview_source==row['source_path'] else None
        request={'source':row['source_path'],'dna':copy.deepcopy(self._styles[self._style_key]),
            'strength':self.strength.get()/100,'adjustments':copy.deepcopy(row.get('adjustments') or validate_adjustments()),
            'recognition':self.recognition.get(),'lens_correction':self.lens_correction.get(),'fast_raw':self.fast_raw.get(),
            'scene_override':copy.deepcopy(row.get('scene_override')),'base':base}
        self.preview_note.configure(text=self.i18n.t('travel_preview_working'))
        self._thread(self._preview_generation,'preview',request,self._preview_cancel)

    def _clear_preview(self):
        self._preview=None;self._preview_images.clear();self._preview_source=None
        for label in (self.before_label,self.after_label):label.configure(image='',text=self.i18n.t('travel_select_photo'))
        self.preview_note.configure(text=self.i18n.t('travel_preview_hint'));self.review_label.configure(text='')

    def _resize_preview(self,event=None):
        if self._preview is not None and self.notebook.select()==str(self.compare):self._draw_preview()

    def _draw_preview(self):
        if self._preview is None:return
        width=max(100,(self.compare.winfo_width()-ui_pixels(self,30))//2)
        height=max(100,self.compare.winfo_height()-ui_pixels(self,150))
        images=[]
        for label,key in ((self.before_label,'original'),(self.after_label,'rendered')):
            image=Image.fromarray(self._preview[key]).convert('RGB');image.thumbnail((width,height),Image.Resampling.LANCZOS)
            stream=BytesIO();image.save(stream,format='PNG')
            photo=tk.PhotoImage(master=self,data=base64.b64encode(stream.getvalue()).decode('ascii'))
            label.configure(image=photo,text='');images.append(photo)
        self._preview_images=images
        approximate=self._preview.get('raw_quality')=='interactive'
        self.preview_note.configure(text=self.i18n.t('travel_preview_fast' if approximate else 'travel_preview_precise'))
        self.review_label.configure(text=' · '.join(self.i18n.t(code) for code in self._review_codes))

    def choose_destination(self):
        options={'parent':self,'title':self.i18n.t('travel_destination')}
        if self.destination and Path(self.destination).is_dir():options['initialdir']=self.destination
        folder=filedialog.askdirectory(**options)
        if folder:
            self.destination=str(Path(folder).resolve())
            self.destination_path.configure(text=self.destination)
            if self._project_id:
                with TravelStore(self.db_path) as store:
                    store.configure_project(self._project_id,{'output_folder':self.destination})

    def start_export(self,selected=False):
        if self._busy or not self._project_id:return
        self._flush_edits()
        ids=self.grid_view.selection() if selected else None
        keep=[row for row in self._photos if row.get('pick')=='keep' and (ids is None or row['id'] in ids)]
        if not keep:self._set_status('travel_no_keep');return
        if not self.destination:self.choose_destination()
        if not self.destination:return
        request={'db_path':str(self.db_path),'project_id':self._project_id,'enqueue':True,
            'dna':copy.deepcopy(self._styles[self._style_key]),'destination':self.destination,
            'strength':self.strength.get()/100,'recognition':self.recognition.get(),
            'lens_correction':self.lens_correction.get(),'photo_ids':ids,'output_size':self._size_code}
        self.notebook.select(self.queue_tab);self._start('export',request);self._set_status('travel_preparing')

    def resume_exports(self):
        if self._busy or not self._project_id:return
        self.notebook.select(self.queue_tab)
        self._start('export',{'db_path':str(self.db_path),'project_id':self._project_id,'enqueue':False})
        self._set_status('travel_resuming')

    def retry_failed(self):
        if self._busy or not self._project_id:return
        with TravelStore(self.db_path) as store:store.retry_failed(self._project_id)
        self.resume_exports()

    def pause(self):
        if self._busy:self._cancel.set();self._set_status('travel_pausing')

    def _thread(self,generation,kind,request,cancel):
        self._threads=[thread for thread in self._threads if thread.is_alive()]
        thread=threading.Thread(target=_travel_job,args=(self._events,generation,kind,request,cancel),daemon=True,name='travel-'+kind)
        self._threads.append(thread);thread.start()

    def _start(self,kind,request):
        self._busy=True;self._generation+=1;self._cancel=threading.Event();self.progress.set(0)
        if kind=='export' and request.get('enqueue'):self._preparation_issues.clear()
        self._queue_dirty=True
        self._update_actions();self._thread(self._generation,kind,request,self._cancel)

    def _refresh_tasks(self):
        self._last_queue_refresh=time.monotonic();self._queue_dirty=False
        tasks=[]
        if self._project_id:
            # Queue presentation needs names/status only. Parsing every saved
            # DNA on Tk's thread would make a large trip stutter on refresh;
            # the export worker still validates each complete frozen request.
            with TravelStore(self.db_path) as store:
                tasks=[dict(row) for row in store.conn.execute('''
                    SELECT task.id,task.status,task.error_code,task.destination,photo.source_path
                    FROM travel_tasks AS task JOIN travel_photos AS photo ON photo.id=task.photo_id
                    WHERE task.project_id=? ORDER BY task.id
                ''',(self._project_id,))]
        counts={status:0 for status in ('pending','running','ready','completed','failed')}
        existing=set(self.tasks.get_children());wanted=[];running=None
        for task in tasks:
            source=task.get('source_path') or task.get('destination','')
            status=task.get('status','pending');error=task.get('error_code')
            counts[status]=counts.get(status,0)+1
            known={'source_changed','source_missing','output_exists','runtime_changed','render_failed',
                'invalid_request','stage_changed','lease_lost','source_unavailable'}
            detail=self.i18n.t('travel_queue_error_'+(error if error in known else 'unknown')) if error else Path(task.get('destination','')).name
            iid='task-'+str(task['id']);wanted.append(iid)
            values=(Path(source).name,self.i18n.t('travel_task_'+status),detail)
            if iid in existing:
                if tuple(self.tasks.item(iid,'values'))!=values or tuple(self.tasks.item(iid,'tags'))!=(status,):
                    self.tasks.item(iid,values=values,tags=(status,))
            else:self.tasks.insert('','end',iid=iid,values=values,tags=(status,))
            if status=='running':running=iid
        for index,(source,error) in enumerate(self._preparation_issues.items()):
            iid='prepare-'+str(index);wanted.append(iid)
            values=(Path(source).name,self.i18n.t('travel_prepare_issue'),self.i18n.t('travel_queue_error_source_unavailable'))
            if iid in existing:
                if tuple(self.tasks.item(iid,'values'))!=values:self.tasks.item(iid,values=values,tags=('failed',))
            else:self.tasks.insert('','end',iid=iid,values=values,tags=('failed',))
        for iid in existing-set(wanted):self.tasks.delete(iid)
        self._task_counts=counts
        if wanted:self.queue_empty.grid_remove();self.queue_summary.grid()
        else:self.queue_empty.grid();self.queue_summary.grid_remove()
        self.queue_summary.configure(text=self.i18n.t('travel_queue_status_hint',
            pending=counts['pending']+counts['running']+counts['ready'],completed=counts['completed'],
            failed=counts['failed']+len(self._preparation_issues)))
        if running and not self.tasks.selection():self.tasks.see(running)
        self._queue_selection_changed();self._update_actions()

    def _queue_selection_changed(self):
        selected=self.tasks.selection()
        values=self.tasks.item(selected[0],'values') if selected else ()
        self.queue_detail.configure(text=values[2] if len(values)>2 else '')
        if len(values)>2:self.queue_detail.grid()
        else:self.queue_detail.grid_remove()

    def _update_actions(self):
        ids=self.grid_view.selected_ids;selected=bool(ids);project=self._project_id is not None
        kept=[row for row in self._photos if row.get('pick','keep')=='keep']
        selected_kept=sum(row['id'] in ids for row in kept)
        pending=sum(self._task_counts.get(status,0) for status in ('pending','running','ready'))
        for widget in (self.new_btn,self.export_btn,self.export_selected_btn,self.resume_btn,self.retry_btn):
            enabled=not self._busy and (widget==self.new_btn or project)
            if widget==self.export_btn:enabled=enabled and bool(kept)
            if widget==self.export_selected_btn:enabled=enabled and bool(selected_kept)
            if widget==self.resume_btn:enabled=enabled and bool(pending)
            if widget==self.retry_btn:enabled=enabled and bool(self._task_counts.get('failed',0))
            widget.configure(state='normal' if enabled else 'disabled')
        self.export_btn.configure(text=self.i18n.t('travel_export_keep_count',count=len(kept)))
        self.export_selected_btn.configure(text=self.i18n.t('travel_export_selected_count',count=selected_kept))
        self.project_combo.configure(state='disabled' if self._busy else 'readonly')
        self.style_combo.configure(state='readonly' if project and not self._busy else 'disabled')
        self.size_combo.configure(state='readonly' if project and not self._busy else 'disabled')
        self.destination_btn.configure(state='disabled' if self._busy else 'normal')
        self.destination_path.configure(text=self.destination or self.i18n.t('travel_no_export_folder'))
        self.cancel_btn.configure(state='normal' if self._busy else 'disabled')
        for widget in (self.selected_btn,self.reset_btn):widget.configure(state='normal' if selected and not self._busy else 'disabled')
        self.inspect_btn.configure(state='normal' if selected else 'disabled')
        for widget in self._pick_buttons.values():widget.configure(state='normal' if selected and project and not self._busy else 'disabled')
        for slider,variable,trace in self._sliders:
            editable=project if variable is self.strength else selected
            slider.configure(state='normal' if editable and not self._busy else 'disabled')
        for widget in (self.recognition_check,self.lens_check,self.fast_check):widget.configure(state='normal' if project and not self._busy else 'disabled')
        row=self._active_photo();group_count=len(self._group_ids())
        for widget in (self.group_btn,self.select_group_btn):widget.configure(state='normal' if group_count>1 and not self._busy else 'disabled')
        self.selected_btn.configure(text=self.i18n.t('travel_copy_selected_count',count=len(ids)))
        self.group_btn.configure(text=self.i18n.t('travel_copy_group_count',count=group_count))
        self.select_group_btn.configure(text=self.i18n.t('travel_select_group_count',count=group_count))
        self.group_hint.configure(text=self.i18n.t('travel_group_hint',count=group_count) if group_count>1 else '')
        self.photo_label.configure(text=self.i18n.t('travel_photo_scope',name=Path(row['source_path']).name,count=len(ids)) if row else self.i18n.t('travel_select_photo'))

    def _set_status(self,key,**values):
        self._status_key=key;self._status_values=values;self.status.set(self.i18n.t(key,**values))

    def _poll(self):
        if self._closed:return
        for _ in range(48):
            try:kind,generation,job,data=self._events.get_nowait()
            except queue.Empty:break
            if kind in ('thumbnail','thumbnail_error'):
                self._thumb_requested.discard(generation)
                row=next((row for row in self._photos if row['id']==generation),None)
                if row and (row['source_path'],row.get('size_bytes'),row.get('mtime_ns'))==job:
                    if kind=='thumbnail':self.grid_view.set_thumbnail(generation,data['pixels'])
                    else:self.grid_view.thumbnail_error(generation)
                continue
            if job=='preview':
                if kind=='finished':
                    self._preview_running=False
                    if self._preview_pending:self._launch_preview()
                elif generation==self._preview_generation:
                    if kind=='result':
                        self._preview=data;row=self._active_photo();self._preview_source=row['source_path'] if row else None
                        self._review_codes=data.get('travel_review',[]);self._draw_preview()
                    elif kind=='error':self.preview_note.configure(text=self.i18n.t('travel_preview_error',error=data))
                continue
            if generation!=self._generation:continue
            if kind=='progress':
                preparing=data.get('status') in ('preparing','preparation_failed')
                total=data.get('preparation_total',0) if preparing else data.get('total',0)
                done=data.get('prepared',0) if preparing else data.get('completed',0)
                self.progress.set(min(100,done/max(1,total)*100))
                self._set_status('travel_prepare_progress' if preparing else 'travel_progress',done=done,total=total,name=Path(str(data.get('current',''))).name)
                if data.get('status')=='preparation_failed':self._preparation_issues[str(data.get('current',''))]=data.get('error_code')
                if job=='export':self._queue_dirty=True
            elif kind=='result':
                if data.get('cancelled'):self._set_status('travel_preparation_paused' if data.get('preparation_cancelled') else 'travel_paused')
                elif data.get('busy'):self._set_status('travel_queue_busy')
                elif job=='scan':self._set_status('travel_imported',count=data.get('counts',{}).get('total',0))
                else:self._set_status('travel_export_done',completed=data.get('completed',0),
                    failed=data.get('failed',0)+data.get('preparation_failed',0))
            elif kind=='error':self._set_status('travel_error',error=data)
            elif kind=='finished':
                self._busy=False
                if job=='scan':
                    with TravelStore(self.db_path) as store:self._photos=store.list_photos(self._project_id)
                    self._refresh_grid()
                self._refresh_tasks();self._update_actions()
        elapsed=time.monotonic()-self._last_queue_refresh
        if self.notebook.select()==str(self.queue_tab) and elapsed>=1.:self._queue_dirty=True
        if self._queue_dirty and elapsed>=.25:self._refresh_tasks()
        self._poll_id=self.after(50,self._poll)

    def translate(self):
        t=self.i18n.t;self.title(t('travel_title'))
        for widget,key in self._labels+self._buttons:widget.configure(text=t(key))
        self.destination_path.configure(text=self.destination or t('travel_no_export_folder'))
        filter_code=getattr(self,'_filter_choices',{}).get(self.filter.get(),'all')
        self._filter_choices={t('travel_filter_'+code):code for code in ('all','keep','hold','reject')}
        self.filter_combo.configure(values=list(self._filter_choices));self.filter.set(next(label for label,code in self._filter_choices.items() if code==filter_code))
        self._size_choices={t('travel_size_'+code):code for code in ('original','2048','3840')}
        self.size_combo.configure(values=list(self._size_choices));self.output_size.set(next(label for label,code in self._size_choices.items() if code==getattr(self,'_size_code','original')))
        self._style_choices={}
        for key,dna in self._styles.items():
            name=t('style_preset_'+dna['name']) if key.startswith('builtin:') else dna['name']
            label=t('travel_style_builtin' if key.startswith('builtin:') else 'travel_style_saved',name=name)
            if label in self._style_choices:label+=' · '+key
            self._style_choices[label]=key
        self.style_combo.configure(values=list(self._style_choices));self.style.set(next(label for label,key in self._style_choices.items() if key==self._style_key))
        for tab,key in ((self.sheet,'travel_tab_photos'),(self.compare,'travel_tab_compare'),(self.queue_tab,'travel_tab_queue')):self.notebook.tab(tab,text=t(key))
        for column,key in (('file','travel_queue_file'),('status','travel_queue_status'),('detail','travel_queue_detail')):self.tasks.heading(column,text=t(key),anchor='w')
        self.recognition_check.configure(text=t('travel_recognition'));self.lens_check.configure(text=t('travel_lens'));self.fast_check.configure(text=t('travel_fast_preview'))
        row=self._active_photo();self.photo_label.configure(text=Path(row['source_path']).name if row else t('travel_select_photo'))
        self.grid_view.translate();self._update_empty();self._update_count();self._update_actions();self._refresh_tasks()
        self.status.set(t(self._status_key,**self._status_values))
        if self._preview:self._draw_preview()
        else:self._clear_preview()

    def close(self):
        if self._closed:return
        self._flush_edits();self._closed=True;self._stop.set();self._cancel.set();self._preview_cancel.set()
        for timer in (self._poll_id,self._preview_after,self._edit_after):
            if timer is not None:self.after_cancel(timer)
        self.grid_view.close()
        for sequence in ('<MouseWheel>','<Button-4>','<Button-5>'):self.unbind_class(self._rail_bindtag,sequence)
        for slider,variable,trace in self._sliders:
            variable.trace_remove('write',trace)
        self._sliders.clear();self._labels.clear();self._buttons.clear();self._preview_images.clear()
        self._pick_buttons.clear();self._value_labels.clear()
        self._preview=None;self._photos.clear();self._styles.clear();self._threads.clear()
        super().destroy()
        for name,value in list(vars(self).items()):
            if isinstance(value,tk.Misc) and name!='master':
                setattr(self,name,None)
        for name in ('project','style','filter','output_size','strength','exposure','warmth','tint','photo_strength',
            'recognition','lens_correction','fast_raw','progress','status'):
            setattr(self,name,None)

    def destroy(self):self.close()
