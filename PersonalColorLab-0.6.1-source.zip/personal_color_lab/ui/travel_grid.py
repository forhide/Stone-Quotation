"""A virtual contact sheet: only visible cells and a bounded image cache exist."""
from __future__ import annotations

from collections import OrderedDict
from io import BytesIO
from pathlib import Path
import base64
import math
import tkinter as tk
from tkinter import ttk

from PIL import Image

from .display import ui_pixels
from .theme import COLORS as C


class TravelGrid(tk.Frame):
    def __init__(self, parent, i18n, *, on_selection=None, on_visible=None, on_pick=None, on_open=None):
        super().__init__(parent, background=C['bg'])
        self.i18n=i18n
        self.on_selection=on_selection
        self.on_visible=on_visible
        self.on_pick=on_pick
        self.on_open=on_open
        self.active_id=None
        self.rows=[]
        self.selected_ids=set()
        self.visible_ids=()
        self._images=OrderedDict()
        self._errors=set()
        self._anchor=None
        self._columns=1
        self._redraw_id=None
        self._closed=False
        self.columnconfigure(0,weight=1);self.rowconfigure(0,weight=1)
        self.canvas=tk.Canvas(self,background=C['bg'],highlightthickness=0,takefocus=True)
        self.canvas.grid(row=0,column=0,sticky='nsew')
        self.scroll=ttk.Scrollbar(self,orient='vertical',command=self._scroll,style='Lab.Vertical.TScrollbar')
        self.scroll.grid(row=0,column=1,sticky='ns')
        self.canvas.configure(yscrollcommand=self._scrolled)
        self.canvas.bind('<Configure>',self._schedule)
        self.canvas.bind('<Button-1>',self._click)
        for sequence in ('<MouseWheel>','<Button-4>','<Button-5>'):
            self.canvas.bind(sequence,self._wheel)
        for key,delta in [('Left',-1),('Right',1),('Up',-10000),('Down',10000)]:
            self.canvas.bind('<'+key+'>',lambda event,d=delta:self._move(d,event))
        self.canvas.bind('<Control-a>',lambda e:self.select_all())
        self.canvas.bind('<Command-a>',lambda e:self.select_all())
        self.canvas.bind('<Return>',self._open)
        self.canvas.bind('<Double-Button-1>',self._open)
        self.canvas.bind('<Escape>',lambda e:self.select_ids([]) or 'break')
        for key,pick in [('p','keep'),('h','hold'),('x','reject')]:
            self.canvas.bind(key,lambda e,p=pick:self._pick(p))

    @property
    def image_count(self):
        return len(self._images)

    def _scroll(self,*args):
        self.canvas.yview(*args);self._schedule()

    def _scrolled(self,first,last):
        self.scroll.set(first,last);self._schedule()

    def _wheel(self,event):
        delta=-1 if getattr(event,'num',None)==4 else 1 if getattr(event,'num',None)==5 else -int(event.delta/120) if abs(getattr(event,'delta',0))>=120 else -1 if getattr(event,'delta',0)>0 else 1
        self.canvas.yview_scroll(delta*2,'units');self._schedule();return 'break'

    def _schedule(self,event=None):
        if not self._closed and self._redraw_id is None:
            self._redraw_id=self.after_idle(self._draw)

    def set_rows(self,rows):
        previous={row['id']:(row['source_path'],row.get('size_bytes'),row.get('mtime_ns')) for row in self.rows}
        self.rows=list(rows)
        for row in self.rows:
            stamp=(row['source_path'],row.get('size_bytes'),row.get('mtime_ns'))
            if previous.get(row['id'],stamp)!=stamp:
                self._images.pop(row['id'],None);self._errors.discard(row['id'])
        allowed={row['id'] for row in self.rows}
        self.selected_ids.intersection_update(allowed)
        if self.active_id not in self.selected_ids:self.active_id=None
        self._schedule()

    def _elide(self,text,width):
        measure=lambda value:int(self.tk.call('font','measure','LabSmall',value))
        if measure(text)<=width:return text
        low,high=0,len(text)
        while low<high:
            middle=(low+high+1)//2
            if measure(text[:middle]+'…')<=width:low=middle
            else:high=middle-1
        return text[:low]+'…'

    def set_thumbnail(self,photo_id,pixels):
        if self._closed:return
        image=Image.fromarray(pixels).convert('RGB')
        image.thumbnail((ui_pixels(self,210),ui_pixels(self,132)),Image.Resampling.LANCZOS)
        stream=BytesIO();image.save(stream,format='PNG')
        photo=tk.PhotoImage(master=self,data=base64.b64encode(stream.getvalue()).decode('ascii'))
        self._images[photo_id]=photo;self._images.move_to_end(photo_id)
        while len(self._images)>64:self._images.popitem(last=False)
        self._errors.discard(photo_id);self._schedule()

    def thumbnail_error(self,photo_id):
        self._errors.add(photo_id);self._schedule()

    def _draw(self):
        self._redraw_id=None
        if self._closed:return
        canvas=self.canvas;dp=lambda n:ui_pixels(self,n)
        width=max(dp(190),canvas.winfo_width())
        self._columns=max(1,width//dp(215))
        cell_width=width/self._columns;cell_height=dp(187)
        row_count=max(1,math.ceil(len(self.rows)/self._columns))
        region=(0,0,width,row_count*cell_height)
        if tuple(map(float,canvas.cget('scrollregion').split()))!=tuple(map(float,region)):
            canvas.configure(scrollregion=region)
        start=max(0,int(canvas.canvasy(0)//cell_height)-1)
        end=min(row_count,int((canvas.canvasy(0)+canvas.winfo_height())//cell_height)+2)
        canvas.delete('all');visible=[]
        for row_index in range(start,end):
            for column in range(self._columns):
                index=row_index*self._columns+column
                if index>=len(self.rows):break
                row=self.rows[index];photo_id=row['id'];visible.append(row)
                x=column*cell_width+dp(4);y=row_index*cell_height+dp(4)
                right=(column+1)*cell_width-dp(4);bottom=(row_index+1)*cell_height-dp(4)
                chosen=photo_id in self.selected_ids;active=photo_id==self.active_id
                canvas.create_rectangle(x,y,right,bottom,fill=C['surface'],outline=C['accent'] if active else C['muted'] if chosen else C['border'],width=dp(2) if chosen else 1)
                photo=self._images.get(photo_id)
                if photo is not None:
                    self._images.move_to_end(photo_id)
                    canvas.create_image((x+right)/2,y+dp(70),image=photo,anchor='center')
                else:
                    canvas.create_rectangle(x+dp(8),y+dp(8),right-dp(8),y+dp(130),fill=C['inset'],outline='')
                    text=self.i18n.t('travel_thumbnail_error' if photo_id in self._errors else 'travel_thumbnail_loading')
                    canvas.create_text((x+right)/2,y+dp(70),text=text,fill=C['subtle'],font='LabSmall',width=max(dp(80),cell_width-dp(30)))
                if active:
                    marker=self.i18n.t('travel_active_marker')
                    marker_width=int(self.tk.call('font','measure','LabSmall',marker))+dp(14)
                    canvas.create_rectangle(x+dp(8),y+dp(8),x+dp(8)+marker_width,y+dp(30),fill=C['accent'],outline='')
                    canvas.create_text(x+dp(15),y+dp(19),text=marker,anchor='w',fill=C['accent_text'],font='LabSmall')
                name=self._elide(Path(row['source_path']).name,cell_width-dp(28))
                canvas.create_text(x+dp(10),y+dp(143),text=name,anchor='w',fill=C['text'],font='LabSmall')
                pick=row.get('pick','keep');color=C['success'] if pick=='keep' else C['warning'] if pick=='hold' else C['subtle']
                canvas.create_oval(x+dp(11),y+dp(159),x+dp(17),y+dp(165),fill=color,outline='')
                canvas.create_text(x+dp(23),y+dp(162),text=self.i18n.t('travel_pick_'+pick),anchor='w',fill=color,font='LabSmall')
                if row.get('group_id'):
                    group=self.i18n.t('travel_group_number',number=row.get('_group_number',''))
                    canvas.create_text(right-dp(10),y+dp(162),text=group,anchor='e',fill=C['muted'],font='LabSmall')
        ids=tuple(row['id'] for row in visible)
        self.visible_ids=ids
        # A late offscreen result can evict a visible Tk image. Rechecking
        # missing cells also works when the visible photo IDs did not change.
        if self.on_visible:self.on_visible(visible)

    def _click(self,event):
        self.canvas.focus_set()
        width=max(1,self.canvas.winfo_width());cell_width=width/self._columns
        index=int(self.canvas.canvasy(event.y)//ui_pixels(self,187))*self._columns+min(self._columns-1,int(event.x//cell_width))
        if not 0<=index<len(self.rows):return 'break'
        photo_id=self.rows[index]['id']
        if event.state&1 and self._anchor is not None:
            anchor=next((i for i,row in enumerate(self.rows) if row['id']==self._anchor),index)
            self.selected_ids.update(row['id'] for row in self.rows[min(anchor,index):max(anchor,index)+1])
        elif event.state&(4|8):
            if photo_id in self.selected_ids:self.selected_ids.remove(photo_id)
            else:self.selected_ids.add(photo_id)
            self._anchor=photo_id
        else:self.selected_ids={photo_id};self._anchor=photo_id
        self._changed();return 'break'

    def _move(self,delta,event):
        if not self.rows:return 'break'
        if abs(delta)==10000:delta=self._columns*(1 if delta>0 else -1)
        current=next((i for i,row in enumerate(self.rows) if row['id']==self._anchor),None)
        index=0 if current is None else max(0,min(len(self.rows)-1,current+delta));photo_id=self.rows[index]['id']
        if event.state&1:self.selected_ids.add(photo_id)
        else:self.selected_ids={photo_id}
        self._anchor=photo_id
        self.ensure_visible(photo_id)
        self._changed();return 'break'

    def ensure_visible(self,photo_id):
        if self._closed:return
        index=next((i for i,row in enumerate(self.rows) if row['id']==photo_id),None)
        if index is None:return
        width=max(ui_pixels(self,190),self.canvas.winfo_width())
        self._columns=max(1,width//ui_pixels(self,215))
        cell_height=ui_pixels(self,187)
        region_height=max(cell_height,math.ceil(len(self.rows)/self._columns)*cell_height)
        self.canvas.configure(scrollregion=(0,0,width,region_height))
        top=index//self._columns*cell_height
        if top<self.canvas.canvasy(0) or top+cell_height>self.canvas.canvasy(0)+self.canvas.winfo_height():
            self.canvas.yview_moveto(max(0,top-(self.canvas.winfo_height()-cell_height)/2)/region_height)
        self._schedule()

    def _pick(self,pick):
        if self.on_pick:self.on_pick(pick)
        return 'break'

    def _open(self,event=None):
        if self.selected_ids and self.on_open:self.on_open()
        return 'break'

    def select_ids(self,ids,*,notify=True,active_id=None):
        available={row['id'] for row in self.rows}
        self.selected_ids=set(ids)&available
        if self.selected_ids:self._anchor=active_id if active_id in self.selected_ids else next(row['id'] for row in self.rows if row['id'] in self.selected_ids)
        else:self._anchor=None
        self._schedule()
        if notify and self.on_selection:self.on_selection(self.selection())

    def selection(self):
        return [row['id'] for row in self.rows if row['id'] in self.selected_ids]

    def select_all(self):
        self.select_ids((row['id'] for row in self.rows),active_id=self._anchor);return 'break'

    def _changed(self):
        self._schedule()
        if self.on_selection:self.on_selection(self.selection())

    def translate(self):
        self._schedule()

    def close(self):
        if self._closed:return
        self._closed=True
        if self._redraw_id is not None:self.after_cancel(self._redraw_id)
        self._images.clear();self.rows.clear();self.selected_ids.clear()
        self.on_selection=self.on_visible=self.on_pick=self.on_open=None

    def destroy(self):
        self.close()
        super().destroy()
        # Canvas/scrollbar -> parent references must be released on Tk's
        # thread, before later decoder allocations trigger cyclic collection.
        self.canvas=self.scroll=None
