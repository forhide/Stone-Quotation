"""Local pair inspection. All Tk operations stay on the UI thread."""

import hashlib
from io import BytesIO
import math
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk
from types import SimpleNamespace

from PIL import Image, ImageCms, ImageOps, ImageTk

from ..core.constants import DB_FILENAME, app_data_dir
from ..core.database import LibraryDB
from ..core.edit_reverse import ALGORITHM_VERSION
from ..core.models import PairCandidate
from .display import ui_pixels, ui_scale
from .parameter_evidence import detail_control_card, parameter_evidence_lines, source_parameter_cards
from .theme import COLORS, configure_theme


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load_preview(path: Path) -> tuple[Image.Image, bool]:
    """Bound JPEG decoding and honor orientation/color profiles without writes."""
    profile_failed = False
    try:
        with Image.open(path) as photo:
            if photo.format in {'JPEG', 'MPO'}:
                photo.draft('RGB', (480, 290))
            preview = ImageOps.exif_transpose(photo)
            preview.thumbnail((480, 290), Image.Resampling.LANCZOS)
            profile = preview.info.get('icc_profile')
            if profile:
                try:
                    preview = ImageCms.profileToProfile(
                        preview, ImageCms.ImageCmsProfile(BytesIO(profile)),
                        ImageCms.createProfile('sRGB'), outputMode='RGB',
                    )
                except (OSError, ValueError, ImageCms.PyCMSError):
                    profile_failed = True
            return preview.convert('RGB').copy(), profile_failed
    except (OSError, ValueError, Image.DecompressionBombError) as exc:
        raise ValueError(f'Cannot read image: {path}') from exc


def cache_is_current(payload: dict, original_hash: str, edited_hash: str) -> bool:
    """A filename match alone must never make a previous analysis current."""
    if not analysis_payload_shape_is_valid(payload):
        return False
    provenance = payload.get('provenance') or {}
    if not isinstance(provenance, dict):
        return False
    fingerprints = provenance.get('input_fingerprints') or {}
    if not isinstance(fingerprints, dict):
        return False
    return (
        type(payload.get('schema_version')) is int
        and payload.get('schema_version') == 1
        and payload.get('algorithm_version') == ALGORITHM_VERSION
        and payload.get('status') in {'ok', 'alignment_failed', 'color_space_uncertain'}
        and fingerprints.get('original') == original_hash
        and fingerprints.get('edited') == edited_hash
    )


def analysis_payload_shape_is_valid(payload) -> bool:
    """Reject malformed nested JSON before a saved result reaches any widget."""
    if not isinstance(payload, dict):
        return False
    if not isinstance(payload.get('status'), str):
        return False
    for key in ('alignment', 'tone', 'color', 'lightroom_estimates', 'provenance'):
        if not isinstance(payload.get(key), dict):
            return False
    tone, color = payload['tone'], payload['color']
    for key in ('zones', 'clipping'):
        if key in tone and not isinstance(tone[key], dict):
            return False
    for zone in (tone.get('zones') or {}).values():
        if not isinstance(zone, dict):
            return False
    for key in ('lab', 'hsv', 'hsl', 'wb_tint', 'hue_bands'):
        if key in color and not isinstance(color[key], dict):
            return False
    for band in (color.get('hue_bands') or {}).values():
        if not isinstance(band, dict):
            return False
    if 'tone_transfer' in tone:
        if not isinstance(tone['tone_transfer'], list) or any(not isinstance(point, dict) for point in tone['tone_transfer']):
            return False
    sources = [payload, payload['alignment'], tone, color]
    sources.extend(color.get(key, {}) for key in ('lab', 'hsv', 'hsl', 'wb_tint'))
    for source in sources:
        for key in ('warnings', 'limitations'):
            if key in source and (
                not isinstance(source[key], list)
                or any(not isinstance(code, str) for code in source[key])
            ):
                return False
    return True


def _mapping(value):
    return value if isinstance(value, dict) else {}


def _number(value, places=2, signed=False):
    if not isinstance(value, (int, float)):
        return None
    try:
        if not math.isfinite(value):
            return None
    except (OverflowError, ValueError):
        return None
    return format(value, f'{"+" if signed else ""}.{places}f')


def analysis_text(i18n, payload: dict) -> str:
    """Render observed evidence separately from approximate slider estimates."""
    t = i18n.t
    lines = [t('inferred_analysis'), t('approximate_notice'), '']

    def metric(key, value, places=2, signed=False):
        formatted = _number(value, places, signed)
        lines.append(t('metric_line', label=t(key), value=formatted if formatted is not None else t('not_available')))

    alignment = _mapping(payload.get('alignment'))
    tone = _mapping(payload.get('tone'))
    color = _mapping(payload.get('color'))

    def limitations():
        codes = []
        sources = [payload, alignment, tone, color, *[_mapping(color.get(key)) for key in ('lab', 'hsv', 'hsl', 'wb_tint')]]
        for source in sources:
            for field in ('warnings', 'limitations'):
                values = source.get(field) or []
                if isinstance(values, str):
                    values = [values]
                if not isinstance(values, (list, tuple)):
                    continue
                for code in values:
                    key = 'warning_' + str(code)
                    key = key if key in i18n.messages else 'warning_unknown'
                    if key not in codes:
                        codes.append(key)
        if codes:
            lines.extend(['', t('analysis_limitations')])
            lines.extend(t(code) for code in codes)

    metric('alignment_confidence', alignment.get('confidence'))
    metric('aligned_overlap', alignment.get('overlap_fraction'))
    metric('rotation_degrees', alignment.get('rotation_degrees'), signed=True)
    metric('scale', alignment.get('scale'))
    method_keys = {
        'orb_ransac': 'method_orb_ransac', 'gradient_ecc': 'method_gradient_ecc',
        'structural_identity': 'method_structural_identity', 'unregistered': 'method_unregistered',
    }
    method = alignment.get('method')
    method = method if isinstance(method, str) else ''
    lines.append(t('metric_line', label=t('alignment_method'), value=t(method_keys.get(method, 'not_available'))))
    bounds = alignment.get('crop_bounds_original')
    if isinstance(bounds, (list, tuple)) and len(bounds) == 4:
        formatted_bounds = [_number(value, 1) for value in bounds]
        if all(value is not None for value in formatted_bounds):
            lines.append(t('crop_bounds_line', left=formatted_bounds[0], top=formatted_bounds[1], width=formatted_bounds[2], height=formatted_bounds[3]))
    if payload.get('status') != 'ok' or not alignment.get('success'):
        notice = 'color_space_uncertain_notice' if payload.get('status') == 'color_space_uncertain' else 'alignment_failed_notice'
        lines.extend(['', t(notice)])
        limitations()
        lines.extend(['', t('analysis_provenance', version=payload.get('algorithm_version', ALGORITHM_VERSION))])
        return '\n'.join(lines)

    metric('analysis_confidence', payload.get('confidence'))
    lines.extend(['', t('observed_tone')])
    metric('luminance_delta', tone.get('mean_luminance_delta'), 3, True)
    metric('contrast_delta', tone.get('contrast_delta'), 3, True)
    for zone in ('shadows', 'midtones', 'highlights'):
        values = _mapping(_mapping(tone.get('zones')).get(zone))
        delta = _number(values.get('delta'), 3, True)
        confidence = _number(values.get('confidence'))
        count = values.get('sample_count')
        lines.append(t('zone_line', zone=t(zone), delta=delta if delta is not None else t('not_available'), count=count if isinstance(count, int) else t('not_available'), confidence=confidence if confidence is not None else t('not_available')))

    lab = _mapping(color.get('lab'))
    lines.extend(['', t('observed_color')])
    for key in ('delta_l', 'delta_a', 'delta_b'):
        metric(key, lab.get(key), signed=True)
    metric('mean_delta_e', lab.get('mean_delta_e'))
    for space, label in [('hsv', 'observed_hsv'), ('hsl', 'observed_hsl')]:
        values = _mapping(color.get(space))
        lines.extend(['', t(label)])
        metric('hue_delta_degrees', values.get('hue_delta_degrees'), signed=True)
        metric('saturation_delta', values.get('saturation_delta'), 3, True)
        if space == 'hsv':
            metric('value_delta', values.get('value_delta'), 3, True)
        else:
            metric('lightness_delta', values.get('lightness_delta'), 3, True)
    wb = _mapping(color.get('wb_tint'))
    temperature = wb.get('temperature_direction')
    temperature = temperature if isinstance(temperature, str) else ''
    tint = wb.get('tint_direction')
    tint = tint if isinstance(tint, str) else ''
    direction_keys = {
        'warmer': 'direction_warmer', 'warm': 'direction_warmer',
        'cooler': 'direction_cooler', 'cool': 'direction_cooler',
        'magenta': 'direction_magenta', 'toward_magenta': 'direction_magenta',
        'green': 'direction_green', 'toward_green': 'direction_green',
        'neutral': 'direction_neutral', 'unchanged': 'direction_neutral',
        'uncertain': 'direction_uncertain',
    }
    lines.append(t('metric_line', label=t('temperature_tendency'), value=t(direction_keys.get(temperature, 'not_available'))))
    lines.append(t('metric_line', label=t('tint_tendency'), value=t(direction_keys.get(tint, 'not_available'))))
    metric('wb_confidence', wb.get('confidence'))
    lines.extend(parameter_evidence_lines(i18n, payload, 'raw_jpg'))
    lines.extend(['', t('approximate_sliders')])
    estimates = _mapping(payload.get('lightroom_estimates'))
    exposure = estimates.get('exposure_ev', estimates.get('exposure', tone.get('estimated_exposure_ev')))
    metric('exposure_ev', exposure, signed=True)
    metric('exposure_confidence', estimates.get('exposure_confidence', tone.get('exposure_confidence')))
    contrast_keys = {'higher': 'direction_higher', 'lower': 'direction_lower', 'neutral': 'direction_neutral', 'uncertain': 'direction_uncertain'}
    contrast_direction = estimates.get('contrast_direction')
    contrast_direction = contrast_direction if isinstance(contrast_direction, str) else ''
    lines.append(t('metric_line', label=t('contrast_tendency'), value=t(contrast_keys.get(contrast_direction, 'not_available'))))
    limitations()
    lines.extend(['', t('analysis_provenance', version=payload.get('algorithm_version', ALGORITHM_VERSION))])
    return '\n'.join(lines)


def _finite_number(value):
    """Saved data is evidence only when it contains an actual finite number."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        return float(value) if math.isfinite(value) else None
    except (OverflowError, ValueError):
        return None


def analysis_summary(i18n, payload):
    """Plain-language observations with no estimates for unverifiable pairs.

    The curve contains the engine's measured monotone fit. Missing evidence is
    never replaced by a synthetic curve or by a zero-valued observation.
    """
    t = i18n.t
    result = {
        'state': 'pending',
        'heading': t('summary_pending'),
        'notice': t('summary_pending_help'),
        'cards': [
            {'key': key, 'label': t(label), 'value': t('summary_not_measured'), 'note': ''}
            for key, label in (('brightness', 'summary_brightness'), ('temperature', 'summary_color'),
                               ('contrast', 'parameter_contrast'), ('saturation', 'parameter_saturation'),
                               ('clarity', 'parameter_clarity'), ('texture', 'parameter_texture'),
                               ('geometry', 'summary_geometry'))
        ],
        'curve': [],
        'curve_available': False,
    }
    if not isinstance(payload, dict):
        return result
    alignment = _mapping(payload.get('alignment'))
    status = payload.get('status')
    if status == 'color_space_uncertain':
        result.update(state='color_space_uncertain', heading=t('summary_icc_failed'), notice=t('summary_icc_help'))
        return result
    if status != 'ok' or not alignment.get('success'):
        result.update(state='alignment_failed', heading=t('summary_alignment_failed'), notice=t('summary_alignment_help'))
        return result
    if not analysis_payload_shape_is_valid(payload):
        result.update(state='invalid', heading=t('summary_error'), notice=t('summary_error_help'))
        return result

    result.update(state='ok', heading=t('summary_ready'), notice=t('summary_intro'))
    tone = _mapping(payload.get('tone'))
    color = _mapping(payload.get('color'))
    estimates = _mapping(payload.get('lightroom_estimates'))
    by_key = {card['key']: card for card in result['cards']}
    brightness, color_card, geometry = (by_key[key] for key in ('brightness', 'temperature', 'geometry'))
    measured = source_parameter_cards(i18n, payload, 'raw_jpg')
    for key in ('contrast', 'saturation', 'clarity', 'texture'):
        by_key[key].update(measured[key])
    delta = _finite_number(tone.get('mean_luminance_delta'))
    if delta is not None and -1 <= delta <= 1:
        direction = 'summary_brighter' if delta >= 0.005 else 'summary_darker' if delta <= -0.005 else 'summary_similar_brightness'
        brightness['value'] = t(direction)
        brightness['note'] = t('summary_brightness_points', delta=f'{delta * 100:+.1f}')
    exposure = _finite_number(estimates.get('exposure_ev', tone.get('estimated_exposure_ev')))
    ev_notice = t('summary_ev', value=f'{exposure:+.2f}') if exposure is not None else t('summary_ev_unavailable')
    brightness['note'] = '\n'.join(part for part in (brightness['note'], ev_notice) if part)

    wb = _mapping(color.get('wb_tint'))
    temperature = wb.get('temperature_direction')
    tint = wb.get('tint_direction')
    directions = {
        'warmer': 'direction_warmer', 'warm': 'direction_warmer',
        'cooler': 'direction_cooler', 'cool': 'direction_cooler',
        'magenta': 'direction_magenta', 'toward_magenta': 'direction_magenta',
        'green': 'direction_green', 'toward_green': 'direction_green',
        'neutral': 'direction_neutral', 'unchanged': 'direction_neutral',
        'uncertain': 'direction_uncertain',
    }
    warmth_key = directions.get(temperature) if isinstance(temperature, str) else None
    tint_key = directions.get(tint) if isinstance(tint, str) else None
    if warmth_key is not None and tint_key is not None:
        color_card['value'] = t('summary_color_directions', warmth=t(warmth_key), tint=t(tint_key))
    confidence = _finite_number(estimates.get('white_balance_confidence', wb.get('confidence')))
    if confidence is not None and 0 <= confidence <= 1:
        level = 'summary_evidence_strong' if confidence >= .7 else 'summary_evidence_mixed' if confidence >= .35 else 'summary_evidence_limited'
        color_card['note'] = t('summary_evidence', level=t(level))

    overlap = _finite_number(alignment.get('overlap_fraction'))
    if overlap is not None and 0 <= overlap <= 1:
        geometry['value'] = t('summary_coverage', percent=f'{overlap * 100:.0f}')
    rotation, scale = _finite_number(alignment.get('rotation_degrees')), _finite_number(alignment.get('scale'))
    if rotation is not None and scale is not None and scale > 0:
        geometry['note'] = t('summary_geometry_note', rotation=f'{rotation:+.1f}', scale=f'{scale:.2f}')

    curve = []
    for point in tone.get('tone_transfer', []):
        x, y = _finite_number(point.get('input')), _finite_number(point.get('output'))
        count = point.get('count')
        if (
            x is None or y is None or not (0 <= x <= 1 and 0 <= y <= 1)
            or type(count) is not int or count <= 0
            or curve and (x <= curve[-1][0] or y < curve[-1][1])
        ):
            curve = []
            break
        curve.append((x, y))
    if len(curve) >= 2:
        result['curve'], result['curve_available'] = curve, True
    return result


class PairInspector(tk.Toplevel):
    def __init__(self, parent, pair: PairCandidate, i18n):
        super().__init__(parent)
        dp = lambda value: ui_pixels(self, value)
        self.i18n = i18n
        self.original_path = Path(pair.original).expanduser().resolve()
        self.edited_path = Path(pair.edited).expanduser().resolve()
        self.candidate_confidence = pair.confidence
        self.manual_selection = 'manual_selection' in pair.reasons
        self.payload = None
        self._events = queue.Queue()
        self._busy = False
        self._closed = False
        self._state_key = 'analysis_pending'
        self._images = []
        self._preview_profile_failed = False
        self._preview_sources = []
        self._preview_height = dp(190)
        self._path_tooltip = None
        self._layout_size = None
        self._worker_threads = []
        if 'LabBody' not in self.tk.call('font', 'names'):
            configure_theme(parent)
        self.configure(background=COLORS['bg'])
        self.geometry(f'{dp(1160)}x{dp(900)}')
        self.minsize(dp(940), dp(740))
        self.protocol('WM_DELETE_WINDOW', self.close)
        self._build()
        self.bind('<Configure>', self._resize_layout)
        self.translate()
        self._poll_id = self.after(60, self._poll)
        self.start_analysis()

    def _build(self):
        dp = lambda value: ui_pixels(self, value)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        top = ttk.Frame(self, padding=(dp(24), dp(12), dp(24), dp(10)), style='Lab.TFrame')
        top.grid(row=0, column=0, sticky='ew')
        top.columnconfigure(0, weight=1)
        self.heading = ttk.Label(top, style='Title.TLabel')
        self.heading.grid(row=0, column=0, sticky='w')
        self.direction_help = ttk.Label(top, style='Small.TLabel', background=COLORS['bg'], wraplength=dp(1050), anchor='w', justify='left')
        self.direction_help.grid(row=1, column=0, columnspan=3, sticky='w', pady=(dp(6), dp(0)))
        self.explanation = ttk.Label(top, style='Small.TLabel', background=COLORS['bg'], wraplength=dp(1050), anchor='w', justify='left')
        self.explanation.grid(row=2, column=0, columnspan=3, sticky='w', pady=(dp(3), dp(0)))
        self.swap_btn = ttk.Button(top, command=self.swap_direction, style='Secondary.TButton')
        self.swap_btn.grid(row=0, column=1, padx=(dp(12), dp(0)))
        self.analyze_btn = ttk.Button(top, command=lambda: self.start_analysis(force=True), style='Primary.TButton')
        self.analyze_btn.grid(row=0, column=2, padx=(dp(10), dp(0)))
        self.state = tk.StringVar()
        self.progress = ttk.Progressbar(top, mode='indeterminate', style='Lab.Horizontal.TProgressbar', maximum=100)
        self.progress.grid(row=3, column=0, columnspan=3, sticky='ew', pady=(dp(12), dp(0)))
        self.progress.grid_remove()

        previews = ttk.Frame(self, padding=(dp(24), dp(0)), style='Lab.TFrame')
        previews.grid(row=1, column=0, sticky='ew')
        self.preview_frames = []
        self.preview_titles = []
        self.preview_wells = []
        self.preview_labels = []
        self.path_labels = []
        self.directory_labels = []
        for col in range(2):
            previews.columnconfigure(col, weight=1, uniform='comparison-previews')
            frame = ttk.Frame(previews, padding=dp(12), style='Surface.TFrame')
            frame.grid(row=0, column=col, sticky='nsew', padx=(dp(0), dp(8)) if col == 0 else (dp(8), dp(0)))
            title = ttk.Label(frame, style='Badge.TLabel')
            title.pack(anchor='w', pady=(dp(0), dp(8)))
            image_area = tk.Frame(frame, background=COLORS['inset'], height=self._preview_height)
            image_area.pack(fill='x')
            image_area.pack_propagate(False)
            image = tk.Label(image_area, anchor='center', background=COLORS['inset'], foreground=COLORS['subtle'], borderwidth=0)
            image.pack(fill='both', expand=True)
            path_label = ttk.Label(frame, style='Body.TLabel', anchor='w', justify='left')
            path_label.pack(fill='x', pady=(dp(9), dp(0)))
            directory_label = ttk.Label(frame, style='Small.TLabel', anchor='w', justify='left')
            directory_label.pack(fill='x', pady=(dp(3), dp(0)))
            self.preview_frames.append(frame)
            self.preview_titles.append(title)
            self.preview_wells.append(image_area)
            self.preview_labels.append(image)
            self.path_labels.append(path_label)
            self.directory_labels.append(directory_label)
            for path_widget in (path_label, directory_label):
                path_widget.bind('<Enter>', lambda event, col=col: self._show_path_tooltip(col, event.widget))
                path_widget.bind('<Leave>', lambda event: self._hide_path_tooltip())
        self.preview_notice = ttk.Label(previews, style='Muted.TLabel', wraplength=dp(1000), anchor='w', justify='left')
        self.preview_notice.grid(row=1, column=0, columnspan=2, sticky='w', pady=(dp(4), dp(0)))

        result = ttk.Frame(self, padding=(dp(24), dp(10), dp(24), dp(0)), style='Lab.TFrame')
        result.grid(row=2, column=0, sticky='nsew')
        result.rowconfigure(0, weight=1)
        result.columnconfigure(0, weight=1)
        self.result_tabs = ttk.Notebook(result)
        self.result_tabs.grid(row=0, column=0, sticky='nsew')
        self.summary_tab = ttk.Frame(self.result_tabs, padding=(dp(16), dp(12)), style='Surface.TFrame')
        self.summary_tab.columnconfigure(0, weight=1)
        self.summary_tab.rowconfigure(3, weight=1)
        self.result_tabs.add(self.summary_tab)
        self.detail_tab = ttk.Frame(self.result_tabs, padding=dp(12), style='Surface.TFrame')
        self.result_tabs.add(self.detail_tab)
        self.result_tabs.select(self.summary_tab)

        self.summary_heading = ttk.Label(self.summary_tab, style='Heading.TLabel')
        self.summary_heading.grid(row=0, column=0, sticky='w')
        self.summary_notice = ttk.Label(self.summary_tab, style='Small.TLabel', background=COLORS['surface'], wraplength=dp(1000), anchor='w', justify='left')
        self.summary_notice.grid(row=1, column=0, sticky='w', pady=(dp(5), dp(12)))
        cards = ttk.Frame(self.summary_tab, style='Surface.TFrame')
        cards.grid(row=2, column=0, sticky='ew')
        self.summary_cards = []
        for index in range(7):
            row, col = divmod(index, 4)
            cards.columnconfigure(col, weight=1, uniform='insights')
            card = ttk.Frame(cards, padding=(dp(10), dp(7)), style='Inset.TFrame')
            card.grid(row=row, column=col, sticky='nsew', padx=(dp(0), dp(7)) if col < 3 else dp(0), pady=(0, dp(7)))
            labels = {}
            for label_row, key in enumerate(('label', 'value', 'note')):
                label = tk.Label(
                    card, background=COLORS['inset'], foreground=COLORS['muted'] if key != 'value' else COLORS['text'],
                    font='LabSmall' if key != 'value' else 'LabBody', justify='left', anchor='w',
                    wraplength=dp(185), borderwidth=0,
                )
                label.pack(fill='x', pady=(dp(0), dp(3)) if label_row < 2 else dp(0))
                labels[key] = label
            self.summary_cards.append(labels)
        cards.bind('<Configure>', lambda event: self._resize_cards(event.width))

        curve_area = ttk.Frame(self.summary_tab, style='Surface.TFrame')
        curve_area.grid(row=3, column=0, sticky='nsew', pady=(dp(12), dp(0)))
        curve_area.columnconfigure(1, weight=1)
        curve_area.rowconfigure(0, weight=1)
        curve_caption = ttk.Frame(curve_area, padding=(dp(0), dp(4), dp(18), dp(0)), style='Surface.TFrame')
        curve_caption.grid(row=0, column=0, sticky='nw')
        self.curve_title = ttk.Label(curve_caption, style='Body.TLabel')
        self.curve_title.pack(anchor='w')
        self.curve_help = ttk.Label(curve_caption, style='Small.TLabel', background=COLORS['surface'], wraplength=dp(260), anchor='w', justify='left')
        self.curve_help.pack(anchor='w', pady=(dp(7), dp(0)))
        self.tone_curve = tk.Canvas(curve_area, height=dp(108), background=COLORS['inset'], highlightthickness=dp(0))
        self.tone_curve.grid(row=0, column=1, sticky='nsew')
        self.tone_curve.bind('<Configure>', lambda event: self._draw_curve())

        detail = self.detail_tab
        detail.rowconfigure(0, weight=1)
        detail.columnconfigure(0, weight=1)
        self.details = tk.Text(
            detail, wrap='word', height=12, state='disabled', padx=dp(16), pady=dp(12),
            background=COLORS['inset'], foreground=COLORS['text'], selectbackground=COLORS['accent'],
            selectforeground=COLORS['accent_text'], insertbackground=COLORS['text'],
            relief='flat', borderwidth=0, highlightthickness=dp(0), font='LabBody', spacing1=dp(2), spacing3=dp(4),
        )
        self.details.grid(row=0, column=0, sticky='nsew')
        scroll = ttk.Scrollbar(detail, orient='vertical', command=self.details.yview, style='Lab.Vertical.TScrollbar')
        scroll.grid(row=0, column=1, sticky='ns')
        self.details.configure(yscrollcommand=scroll.set)
        footer = ttk.Frame(self, padding=(dp(24), dp(6), dp(24), dp(8)), style='Lab.TFrame')
        footer.grid(row=3, column=0, sticky='ew')
        footer.columnconfigure(0, weight=1)
        self.state_label = ttk.Label(footer, textvariable=self.state, style='Small.TLabel', background=COLORS['bg'], anchor='w', justify='left')
        self.state_label.grid(row=0, column=0, sticky='ew')
        self.apply_style_btn=ttk.Button(footer,command=self.use_style,style='Secondary.TButton',padding=(dp(12),dp(6)),state='disabled')
        self.apply_style_btn.grid(row=0,column=1,padx=(dp(12),0))

    def translate(self):
        self.apply_style_btn.configure(text=self.i18n.t('style_apply_comparison'))
        t = self.i18n.t
        self.title(t('inspector_title'))
        self.heading.configure(text=t('inspector_heading'))
        self.direction_help.configure(text=t('inspector_direction_help'))
        self.explanation.configure(text=t('manual_pair_notice') if self.manual_selection else t('pair_candidate_notice', confidence=f'{self.candidate_confidence * 100:.0f}%'))
        self.swap_btn.configure(text=t('swap_direction'))
        self.analyze_btn.configure(text=t('compare_again'))
        self.preview_titles[0].configure(text=t('original'))
        self.preview_titles[1].configure(text=t('edited_photo'))
        self._update_path_labels()
        self.preview_notice.configure(text=t('preview_icc_notice') if self._preview_profile_failed else '')
        if not self._preview_profile_failed:
            self.preview_notice.grid_remove()
        else:
            self.preview_notice.grid()
        self.result_tabs.tab(self.summary_tab, text=t('summary_tab'))
        self.result_tabs.tab(self.detail_tab, text=t('technical_tab'))
        self.curve_title.configure(text=t('summary_curve'))
        self.curve_help.configure(text=t('summary_curve_help'))
        self.state.set(t(self._state_key))
        self._render_summary(self.payload)
        if self.payload is not None:
            self._set_details(analysis_text(self.i18n, self.payload))
        elif not self._busy:
            self._set_details(t(self._state_key))

    def _set_details(self, text):
        self.details.configure(state='normal')
        self.details.delete('1.0', 'end')
        self.details.insert('1.0', text)
        self.details.configure(state='disabled')

    def _ellipsize(self, text, width, font):
        if self.tk.call('font', 'measure', font, text) <= width:
            return text
        low, high = 0, len(text)
        while low < high:
            count = (low + high + 1) // 2
            candidate = '…' + text[-count:] if count else '…'
            if self.tk.call('font', 'measure', font, candidate) <= width:
                low = count
            else:
                high = count - 1
        return '…' + text[-low:] if low else '…'

    def _update_path_labels(self):
        dp = lambda value: ui_pixels(self, value)
        width = max(dp(180), int((max(dp(940), self.winfo_width()) - dp(112)) / 2))
        for col, path in enumerate((self.original_path, self.edited_path)):
            self.path_labels[col].configure(text=self._ellipsize(path.name, width, 'LabBody'))
            self.directory_labels[col].configure(text=self._ellipsize(str(path.parent), width, 'LabSmall'))

    def _show_path_tooltip(self, col, widget):
        dp = lambda value: ui_pixels(self, value)
        self._hide_path_tooltip()
        if self._closed:
            return
        path = (self.original_path, self.edited_path)[col]
        popup = tk.Toplevel(self)
        popup.overrideredirect(True)
        popup.configure(background=COLORS['border'])
        popup.geometry(f'+{widget.winfo_rootx()}+{widget.winfo_rooty() + widget.winfo_height() + dp(4)}')
        label = tk.Label(
            popup, text=str(path), font='LabSmall', wraplength=dp(650), justify='left',
            background=COLORS['elevated'], foreground=COLORS['text'], padx=dp(10), pady=dp(8),
        )
        label.pack(padx=dp(1), pady=dp(1))
        self._path_tooltip = popup

    def _hide_path_tooltip(self):
        if self._path_tooltip is not None:
            self._path_tooltip.destroy()
            self._path_tooltip = None

    def _resize_layout(self, event):
        if self._closed or event.widget is not self:
            return
        size = (event.width, event.height)
        if size == self._layout_size:
            return
        self._layout_size = size
        dp = lambda value: ui_pixels(self, value)
        # Keep useful result space on a laptop; contain previews without crops.
        logical_height = event.height / ui_scale(self)
        self._preview_height = dp(max(125, min(245, int(125 + (logical_height - 740) * .4))))
        for well in self.preview_wells:
            well.configure(height=self._preview_height)
        self.direction_help.configure(wraplength=max(dp(650), event.width - dp(48)))
        self.explanation.configure(wraplength=max(dp(650), event.width - dp(48)))
        self.summary_notice.configure(wraplength=max(dp(600), event.width - dp(90)))
        self._update_path_labels()
        self._render_previews()

    def _render_previews(self):
        if not self._preview_sources or self._closed:
            return
        dp = lambda value: ui_pixels(self, value)
        width = max(dp(100), min(dp(480), int((max(dp(940), self.winfo_width()) - dp(112)) / 2)))
        displayed = []
        for preview in self._preview_sources:
            preview = preview.copy()
            preview.thumbnail((width, self._preview_height), Image.Resampling.LANCZOS)
            displayed.append(preview)
        images = [ImageTk.PhotoImage(preview, master=self) for preview in displayed]
        for label, photo in zip(self.preview_labels, images):
            label.configure(image=photo, text='')
        self._images = images

    def _resize_cards(self, width):
        dp = lambda value: ui_pixels(self, value)
        wrap = max(dp(115), int((width - dp(21)) / 4) - dp(20))
        for card in self.summary_cards:
            for label in card.values():
                label.configure(wraplength=wrap)

    def _render_summary(self, payload):
        self.summary_data = analysis_summary(self.i18n, payload)
        if payload is None:
            if self._state_key in {'analysis_stale', 'analysis_source_changed'}:
                self.summary_data.update(
                    state='stale', heading=self.i18n.t('summary_retry'), notice=self.i18n.t('summary_retry_help'),
                )
            elif self._state_key == 'analysis_error':
                self.summary_data.update(
                    state='error', heading=self.i18n.t('summary_error'), notice=self.i18n.t('summary_error_help'),
                )
        self.summary_heading.configure(text=self.summary_data['heading'])
        self.summary_notice.configure(text=self.summary_data['notice'])
        for labels, card in zip(self.summary_cards, self.summary_data['cards']):
            for key, label in labels.items():
                label.configure(text=card[key])
            # Compact card notes retain the evidence, while the technical tab
            # holds full sentences and approximate slider explanations.
            if self.summary_data['state'] == 'ok':
                labels['note'].configure(text=self._compact_card_note(card['key'], payload, card['note']))
        self._draw_curve()

    def _compact_card_note(self, key, payload, fallback):
        t = self.i18n.t
        tone, color = _mapping(payload.get('tone')), _mapping(payload.get('color'))
        if key == 'brightness':
            delta = _finite_number(tone.get('mean_luminance_delta'))
            exposure = _finite_number(_mapping(payload.get('lightroom_estimates')).get('exposure_ev', tone.get('estimated_exposure_ev')))
            if delta is not None:
                return t('parameter_brightness_compact', delta=f'{delta * 100:+.1f}', exposure=f'{exposure:+.2f}' if exposure is not None else '—')
        if key == 'temperature':
            confidence = _finite_number(_mapping(color.get('wb_tint')).get('confidence'))
            if confidence is not None and 0 <= confidence <= 1:
                return t('parameter_evidence_compact', confidence=round(confidence * 100))
        if key == 'contrast':
            delta = _finite_number(tone.get('contrast_delta'))
            if delta is not None:return t('parameter_delta_compact', value=f'{delta * 100:+.1f}')
        if key == 'saturation':
            model = _mapping(_mapping(payload.get('residual_color')).get('saturation_model'))
            confidence = _finite_number(model.get('confidence'))
            if model.get('status') == 'ok' and confidence is not None and 0 <= confidence <= 1:
                return t('parameter_evidence_compact', confidence=round(confidence * 100))
            delta = _finite_number(_mapping(color.get('hsv')).get('saturation_delta'))
            if delta is not None:return t('parameter_delta_compact', value=f'{delta * 100:+.1f}')
        if key in ('clarity', 'texture'):
            control = _mapping(_mapping(_mapping(payload.get('detail')).get('controls')).get(key))
            estimate, confidence = _finite_number(control.get('estimate')), _finite_number(control.get('confidence'))
            if estimate is not None and confidence is not None and 0 <= confidence <= 1:
                return t('parameter_estimate_compact', value=f'{estimate:+.2f}', confidence=round(confidence * 100))
        if key == 'geometry':
            alignment = _mapping(payload.get('alignment'))
            rotation, scale = _finite_number(alignment.get('rotation_degrees')), _finite_number(alignment.get('scale'))
            if rotation is not None and scale is not None:
                return t('parameter_geometry_compact', rotation=f'{rotation:+.1f}', scale=f'{scale:.2f}')
        return fallback

    def _draw_curve(self):
        if self._closed or not hasattr(self, 'summary_data'):
            return
        canvas = self.tone_curve
        dp = lambda value: ui_pixels(self, value)
        canvas.delete('all')
        width, height = max(dp(100), canvas.winfo_width()), max(dp(30), canvas.winfo_height())
        compact = height < dp(90)
        if compact:
            self.curve_help.pack_forget()
        elif not self.curve_help.winfo_manager():
            self.curve_help.pack(anchor='w', pady=(dp(7), 0))
        if not self.summary_data['curve_available']:
            canvas.create_text(
                width / 2, height / 2, text=self.i18n.t('summary_curve_empty'),
                fill=COLORS['subtle'], font='LabSmall', width=max(dp(60), width - dp(30)), justify='center',
            )
            return
        left, top, right, bottom = dp(16 if compact else 42), dp(9), width - dp(16), height - dp(8 if compact else 30)
        for fraction in (.25, .5, .75):
            x, y = left + fraction * (right - left), bottom - fraction * (bottom - top)
            canvas.create_line(x, top, x, bottom, fill=COLORS['border'], width=dp(1))
            canvas.create_line(left, y, right, y, fill=COLORS['border'], width=dp(1))
        canvas.create_line(left, bottom, right, top, fill=COLORS['subtle'], dash=(dp(4), dp(4)), width=dp(1))
        canvas.create_line(left, top, left, bottom, right, bottom, fill=COLORS['subtle'], width=dp(1))
        coordinates = [
            coordinate for x, y in self.summary_data['curve']
            for coordinate in (left + x * (right - left), bottom - y * (bottom - top))
        ]
        canvas.create_line(*coordinates, fill=COLORS['accent'], width=dp(2.5), tags='curve')
        if compact:
            return
        canvas.create_text(
            (left + right) / 2, height - dp(10), text=self.i18n.t('curve_original_axis'),
            fill=COLORS['muted'], font='LabSmall',
        )
        canvas.create_text(
            dp(13), (top + bottom) / 2, text=self.i18n.t('curve_edited_axis'), angle=90,
            fill=COLORS['muted'], font='LabSmall',
        )

    def _set_busy(self, busy):
        self._busy = busy
        state = 'disabled' if busy else 'normal'
        self.swap_btn.configure(state=state)
        self.analyze_btn.configure(state=state)
        self.apply_style_btn.configure(state='normal' if not busy and self.payload and self.payload.get('status')=='ok' else 'disabled')
        if busy:
            self.progress.grid()
            self.progress.start(16)
        else:
            self.progress.stop()
            self.progress.grid_remove()

    def start_analysis(self, force=False):
        if self._busy or self._closed:
            return
        self.payload = None
        self._state_key = 'analysis_pending'
        self.state.set(self.i18n.t(self._state_key))
        self._set_details(self.i18n.t('analysis_pending'))
        self._render_summary(None)
        self._preview_profile_failed = False
        self._preview_sources.clear()
        self.preview_notice.configure(text='')
        self.preview_notice.grid_remove()
        for label in self.preview_labels:
            label.configure(image='', text=self.i18n.t('analysis_pending'))
        self._images.clear()
        self._set_busy(True)
        # Capture every Tk-owned choice before starting the worker.
        original, edited = self.original_path, self.edited_path
        db_path = app_data_dir() / DB_FILENAME
        # Never let a background thread retain a Tk object or its interpreter.
        state = SimpleNamespace(_events=self._events)
        worker = threading.Thread(target=PairInspector._worker, args=(state, original, edited, db_path, force), daemon=True)
        self._worker_threads = [thread for thread in self._worker_threads if thread.is_alive()]
        self._worker_threads.append(worker)
        worker.start()

    def _worker(self, original, edited, db_path, force):
        try:
            previews = []
            profile_failed = False
            for path in (original, edited):
                preview, failed = load_preview(path)
                previews.append(preview)
                profile_failed = profile_failed or failed
            self._events.put(('previews', previews, profile_failed))
            original_hash, edited_hash = file_sha256(original), file_sha256(edited)
            db = LibraryDB(db_path)
            try:
                # Reanalysis must remain possible even when a stored row is corrupt.
                cached = None if force else db.get_analysis(original, edited)
                if cached and not force:
                    if cache_is_current(cached, original_hash, edited_hash):
                        self._events.put(('result', cached, True))
                    else:
                        self._events.put(('stale',))
                    return
                from ..core.edit_reverse import analyze_pair
                payload = analyze_pair(original, edited)
                if not analysis_payload_shape_is_valid(payload):
                    raise ValueError('Invalid local analysis payload')
                # A source edited externally during analysis cannot produce a reusable result.
                if not cache_is_current(payload, file_sha256(original), file_sha256(edited)):
                    self._events.put(('changed',))
                    return
                db.save_analysis(original, edited, payload)
                self._events.put(('result', payload, False))
            finally:
                db.close()
        except Exception as exc:
            self._events.put(('error', str(exc)))
        finally:
            self._events.put(('finished',))

    def _poll(self):
        if self._closed:
            return
        try:
            while True:
                try:
                    event = self._events.get_nowait()
                except queue.Empty:
                    break
                try:
                    self._handle_event(event)
                except Exception:
                    # A corrupt stored result must never strand the UI's queue
                    # or prevent a user from starting a fresh analysis.
                    self.payload = None
                    self._state_key = 'analysis_error'
                    self.state.set(self.i18n.t(self._state_key))
                    self._set_details(self.i18n.t('analysis_result_invalid'))
                    if hasattr(self, 'summary_cards'):
                        self._render_summary(None)
                    if event[0] in {'result', 'error', 'finished'}:
                        self._set_busy(False)
        finally:
            if not self._closed:
                self._poll_id = self.after(60, self._poll)

    def _handle_event(self, event):
        kind = event[0]
        if kind == 'previews':
            self._preview_profile_failed = event[2]
            self.preview_notice.configure(text=self.i18n.t('preview_icc_notice') if self._preview_profile_failed else '')
            if self._preview_profile_failed:
                self.preview_notice.grid()
            else:
                self.preview_notice.grid_remove()
            self._preview_sources = event[1]
            self._render_previews()
        elif kind == 'result':
            if not analysis_payload_shape_is_valid(event[1]):
                raise ValueError('Invalid local analysis payload')
            self.payload = event[1]
            self._state_key = 'analysis_loaded' if event[2] else 'analysis_saved'
            self.state.set(self.i18n.t(self._state_key))
            self._set_details(analysis_text(self.i18n, self.payload))
            self._render_summary(self.payload)
        elif kind == 'stale':
            self.payload = None
            self._state_key = 'analysis_stale'
            self.state.set(self.i18n.t(self._state_key))
            self._set_details(self.i18n.t(self._state_key))
            self._render_summary(None)
        elif kind == 'changed':
            self.payload = None
            self._state_key = 'analysis_source_changed'
            self.state.set(self.i18n.t(self._state_key))
            self._set_details(self.i18n.t(self._state_key))
            self._render_summary(None)
        elif kind == 'error':
            self.payload = None
            self._state_key = 'analysis_error'
            self.state.set(self.i18n.t(self._state_key))
            self._set_details(self.i18n.t('analysis_error_detail', detail=event[1]))
            self._render_summary(None)
        elif kind == 'finished':
            self._set_busy(False)

    def swap_direction(self):
        if self._busy:
            return
        self.original_path, self.edited_path = self.edited_path, self.original_path
        self.payload = None
        self.translate()
        self.start_analysis()

    def use_style(self):
        if self._busy or not self.payload or self.payload.get('status')!='ok':return
        from ..core.style_dna import dna_from_pair
        dna=dna_from_pair(self.payload,self.i18n.t('style_comparison_name'))
        self.master.open_style_workspace(initial_dna=dna)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._hide_path_tooltip()
        self.after_cancel(self._poll_id)
        self.progress.stop()
        parent = self.master
        for label in self.preview_labels:
            label.configure(image='')
        # ImageTk deletion and Variable finalizers must run on the Tk thread,
        # while its interpreter still exists. No worker owns these references.
        self._images.clear()
        self._preview_sources.clear()
        super().destroy()
        self.state = None
        for name in (
            'heading', 'direction_help', 'explanation', 'swap_btn', 'analyze_btn', 'apply_style_btn', 'details',
            'preview_notice', 'progress', 'result_tabs', 'summary_tab', 'detail_tab',
            'summary_heading', 'summary_notice', 'tone_curve', 'curve_title', 'curve_help', 'state_label',
        ):
            setattr(self, name, None)
        self.preview_frames.clear()
        self.preview_titles.clear()
        self.preview_wells.clear()
        self.preview_labels.clear()
        self.path_labels.clear()
        self.directory_labels.clear()
        self.summary_cards.clear()
        self._worker_threads.clear()
        self.master = None
        if parent is not None and hasattr(parent, '_inspectors') and self in parent._inspectors:
            parent._inspectors.remove(self)

    def destroy(self):
        self.close()
