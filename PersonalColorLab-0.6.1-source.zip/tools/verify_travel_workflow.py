"""Exercise offline trip browsing and real durable JPG/RAW exports.

Generated inputs only. The 500-photo browsing probe uses small JPEGs; its
timings do not measure a 61MP camera library or native M1 performance.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time

if '--installed' not in sys.argv:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from PIL import Image

from personal_color_lab.core.constants import APP_VERSION
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.travel_analysis import scan_travel_folder, suggest_groups
from personal_color_lab.core.travel_previews import TravelPreviewCache
from personal_color_lab.core.travel_store import TravelStore
from personal_color_lab.core.travel_jobs import enqueue_exports, run_exports


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def denied(*args, **kwargs):
    raise AssertionError('Travel workflow attempted network access.')


def run_checks(root):
    checks = []
    folder = root / 'small-jpg-trip'; folder.mkdir()
    y, x = np.indices((96, 160))
    for index in range(500):
        pixels = np.stack(((x + index) % 180 + 35,
                           (y + index // 10) % 160 + 40,
                           (x // 2 + y // 2 + index) % 170 + 40), axis=2).astype('uint8')
        exif = Image.Exif()
        exif[36867] = (datetime(2026, 10, 20, 12) + timedelta(seconds=index)).strftime('%Y:%m:%d %H:%M:%S')
        Image.fromarray(pixels).save(folder / f'DSC{index:05}.jpg', quality=90, exif=exif)
    started = time.perf_counter(); photos = scan_travel_folder(folder)
    scan_seconds = time.perf_counter() - started
    assert len(photos) == 500
    cache = TravelPreviewCache(root / 'previews')
    signatures = []; thumbnails = {}
    started = time.perf_counter()
    for photo in photos:
        result = cache.thumbnail(photo['source_path'])
        signatures.append(hashlib.sha256(result['pixels'].tobytes()).hexdigest())
        thumbnails[photo['source_path']] = result['pixels']
    cold_seconds = time.perf_counter() - started
    cold = cache.stats()
    assert cold['decodes'] == 500 and cold['memory_entries'] <= 32
    reopened = TravelPreviewCache(root / 'previews')
    started = time.perf_counter()
    for photo, signature in zip(photos, signatures):
        result = reopened.thumbnail(photo['source_path'])
        assert result['cache_hit']
        assert hashlib.sha256(result['pixels'].tobytes()).hexdigest() == signature
    warm_seconds = time.perf_counter() - started
    assert reopened.stats()['decodes'] == 0
    started = time.perf_counter(); groups = suggest_groups(photos, thumbnails)
    group_seconds = time.perf_counter() - started
    members = [identifier for group in groups for identifier in group['photo_ids']]
    assert len(members) == len(set(members)) == 500
    checks.append({'check': '500_small_jpg_discovery_grouping_and_persistent_cache',
                   'photo_count': 500, 'fixture_dimensions': [160, 96],
                   'scan_seconds': scan_seconds, 'cold_thumbnail_seconds': cold_seconds,
                   'persistent_thumbnail_seconds': warm_seconds, 'group_seconds': group_seconds,
                   'group_count': len(groups), 'cold_decodes': 500, 'reopen_decodes': 0,
                   'memory_entries_maximum': 32, 'cache_stats': reopened.stats()})
    del thumbnails

    originals = root / 'export-originals'; originals.mkdir()
    raw = write_test_dng(originals / 'raw.dng', width=640, height=480)
    for name, dimensions in [('full.jpg', (2304, 1536)), ('hold.jpg', (96, 64)), ('reject.jpg', (96, 64))]:
        Image.new('RGB', dimensions, (90, 110, 140)).save(originals / name, quality=97)
    before = {path: sha(path) for path in originals.iterdir()}
    db_path = root / 'travel.db'
    dna = identity_dna('Travel test'); dna_before = copy.deepcopy(dna)
    with TravelStore(db_path) as store:
        project_id = store.create_project('Generated trip', originals)
        store.import_photos(project_id, scan_travel_folder(originals))
        rows = store.list_photos(project_id)
        ids = {Path(row['source_path']).name: row['id'] for row in rows}
        store.update_photo(ids['hold.jpg'], pick='hold')
        store.update_photo(ids['reject.jpg'], pick='reject')
        store.update_photo(ids['full.jpg'], adjustments={'exposure_ev': .35, 'temperature': .1})
    destination = root / 'outputs'
    prepared = enqueue_exports(db_path, project_id, dna, destination,
                               recognition=True, lens_correction=True)
    assert prepared['queued'] == 2
    stop = threading.Event(); stop.set()
    paused = run_exports(db_path, project_id, cancel_event=stop)
    assert paused['cancelled'] and paused['pending'] == 2
    complete = run_exports(db_path, project_id)
    assert complete['completed'] == 2 and complete['failed'] == 0, complete
    with TravelStore(db_path) as store:
        tasks = store.list_tasks(project_id)
        receipts = [(task['id'], task['attempts'], task['output_sha256']) for task in tasks]
        for task in tasks:
            with Image.open(task['destination']) as image:
                assert image.info.get('icc_profile') and not image.getexif()
                name = Path(task['request']['source_path']).name
                assert image.size == ((640, 480) if name == 'raw.dng' else (2304, 1536))
        store.update_photo(ids['full.jpg'], adjustments={'exposure_ev': -1.})
    repeated = run_exports(db_path, project_id)
    assert repeated['completed'] == 2
    with TravelStore(db_path) as store:
        assert [(task['id'], task['attempts'], task['output_sha256']) for task in store.list_tasks(project_id)] == receipts
    assert dna == dna_before
    checks.append({'check': 'real_raw_jpg_batch_picks_pause_resume_and_immutable_receipts',
                   'completed': 2, 'held_or_rejected_exported': 0,
                   'completed_resume_additional_attempts': 0, 'saved_dna_unchanged': True,
                   'original_dimensions_preserved': True, 'srgb_embedded_and_exif_removed': True})

    enqueue_exports(db_path, project_id, dna, root / 'share', photo_ids=[ids['full.jpg']],
                    recognition=False, lens_correction=False, output_size='2048')
    assert run_exports(db_path, project_id)['completed'] == 3
    with TravelStore(db_path) as store:
        share = next(task for task in store.list_tasks(project_id) if task['request']['settings']['output_size'] == '2048')
        with Image.open(share['destination']) as image:
            assert max(image.size) == 2048 and image.info.get('icc_profile') and not image.getexif()
    checks.append({'check': 'share_copy_and_separate_photo_corrections', 'long_edge': 2048,
                   'saved_dna_unchanged': dna == dna_before})

    enqueue_exports(db_path, project_id, dna, root / 'collision', photo_ids=[ids['full.jpg']], recognition=False)
    with TravelStore(db_path) as store:
        collision = next(task for task in store.list_tasks(project_id) if task['status'] == 'pending')
    Path(collision['destination']).write_bytes(b'unrelated-output')
    assert run_exports(db_path, project_id)['failed'] == 1
    assert Path(collision['destination']).read_bytes() == b'unrelated-output'
    enqueue_exports(db_path, project_id, dna, root / 'changed-source', photo_ids=[ids['hold.jpg']], recognition=False)
    # Held photos never enter the queue. Use a kept original, then replace it.
    enqueue_exports(db_path, project_id, dna, root / 'changed-source', photo_ids=[ids['raw.dng']], recognition=False)
    raw_bytes = raw.read_bytes(); raw.write_bytes(raw_bytes + b'changed')
    try:
        assert run_exports(db_path, project_id)['failed'] == 2
        with TravelStore(db_path) as store:
            changed = next(task for task in store.list_tasks(project_id) if task['error_code'] == 'source_changed')
            assert not Path(changed['destination']).exists()
    finally:
        raw.write_bytes(raw_bytes)
    assert {path: sha(path) for path in before} == before
    assert not list(originals.glob('*.xmp'))
    checks.append({'check': 'output_collision_and_changed_source_guard',
                   'unrelated_output_preserved': True, 'changed_source_not_exported': True,
                   'original_hashes_preserved': len(before), 'no_sidecar_added': True})
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installed', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    socket.socket = denied; socket.create_connection = denied
    started = time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='pcl-travel-check-') as directory:
        checks = run_checks(Path(directory))
    report = {'ok': True, 'app_version': APP_VERSION,
              'execution': 'installed_runtime' if args.installed else 'source_runtime',
              'runtime_network': 'denied', 'python_isolated': bool(sys.flags.isolated),
              'user_photos_used': False, 'temporary_files_removed': True,
              'fixture': '500 generated small JPGs and separate generated JPG/Bayer DNG export inputs',
              'limits': 'No 500-RAW throughput, actual camera, native M1 or Adobe equivalence claim.',
              'elapsed_seconds': time.perf_counter() - started, 'checks': checks}
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
