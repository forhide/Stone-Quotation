"""Exercise the installed application's Tk UI using its private Python runtime."""
from __future__ import annotations

import hashlib
import ctypes
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import time
import xml.etree.ElementTree as ET


def denied(*args, **kwargs):
    raise AssertionError('The packaged application attempted Python network access')


def main() -> int:
    # Synthetic fixtures only. No original library or persistent user data.
    with tempfile.TemporaryDirectory(prefix='pcl-native-gui-') as directory:
        root = Path(directory)
        os.environ['PERSONAL_COLOR_LAB_DATA_DIR'] = str(root / 'data')
        socket.socket = denied
        socket.create_connection = denied
        import cv2
        import numpy as np
        from PIL import Image
        from personal_color_lab.core.database import LibraryDB
        from personal_color_lab.core.constants import APP_VERSION
        from personal_color_lab.ui.app import App

        photos = root / 'photos'
        photos.mkdir()
        rng = np.random.default_rng(724)
        image = cv2.GaussianBlur(rng.integers(40, 180, (280, 420, 3), dtype=np.uint8), (5, 5), 0)
        for _ in range(55):
            x, y = rng.integers(10, 260, 2)
            cv2.circle(image, (int(x), int(y)), 5, tuple(int(v) for v in rng.integers(35, 200, 3)), -1)
        for i in range(4):
            level = 50 + i * 30
            cv2.rectangle(image, (320, 15 + i * 60), (400, 50 + i * 60), (level,) * 3, -1)
        paths = [photos / 'photo_original.jpg', photos / 'photo_edit.jpg']
        Image.fromarray(image).save(paths[0], quality=98, subsampling=0)
        Image.fromarray(np.clip(image.astype(float) * 1.08 + [6, 1, -4], 0, 255).astype(np.uint8)).save(paths[1], quality=98, subsampling=0)
        fingerprints = [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
        app = App()
        callbacks = []
        app.report_callback_exception = lambda kind, value, tb: callbacks.append(str(value))

        def pump(ready):
            deadline = time.monotonic() + 40
            while time.monotonic() < deadline:
                app.update()
                if callbacks:
                    raise AssertionError(callbacks)
                if ready():
                    return
                time.sleep(0.01)
            raise AssertionError('Installed GUI operation timed out')

        try:
            assert app.i18n.language == 'en'
            text_rendering = {
                'window_system': str(app.tk.call('tk', 'windowingsystem')),
                'logical_dpi': round(app.winfo_fpixels('1i'), 2),
                'body_points': int(app.tk.call('font', 'actual', 'LabBody', '-size')),
                'small_points': int(app.tk.call('font', 'actual', 'LabSmall', '-size')),
                'font_family': str(app.tk.call('font', 'actual', 'LabBody', '-family')),
            }
            assert text_rendering['small_points'] >= 10
            if sys.platform == 'win32':
                user32 = ctypes.WinDLL('user32', use_last_error=True)
                get_context = user32.GetThreadDpiAwarenessContext
                get_context.argtypes = []
                get_context.restype = ctypes.c_void_p
                get_awareness = user32.GetAwarenessFromDpiAwarenessContext
                get_awareness.argtypes = [ctypes.c_void_p]
                get_awareness.restype = ctypes.c_int
                text_rendering['windows_dpi_awareness'] = int(get_awareness(get_context()))
                assert text_rendering['windows_dpi_awareness'] >= 1, 'Installed app is DPI unaware'
            # The simplest entry point must work without a preceding scan or
            # matching names. Exercise it through the installed Tk widgets.
            from personal_color_lab.ui import app as app_module
            selected = iter(str(path) for path in paths)
            original_picker = app_module.filedialog.askopenfilename
            try:
                app_module.filedialog.askopenfilename = lambda **kwargs: next(selected)
                app.choose_pair()
            finally:
                app_module.filedialog.askopenfilename = original_picker
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector.manual_selection
            assert inspector.summary_data['state'] == 'ok'
            assert inspector.summary_data['curve_available']
            assert [card['key'] for card in inspector.summary_data['cards']] == ['brightness', 'temperature', 'contrast', 'saturation', 'clarity', 'texture', 'geometry']
            assert len(inspector.summary_cards) == 7
            assert inspector.result_tabs.select() == str(inspector.summary_tab)
            assert len(app._row_pairs) == 1
            inspector.close()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector._state_key == 'analysis_loaded'
            inspector.close()
            app.folder.set(str(photos))
            app.start_scan()
            pump(lambda: not app._scanning)
            row = next(row for row, pair in app._row_pairs.items() if pair.pair_type == 'JPG+JPG')
            app.tree.selection_set(row)
            app._selection_changed()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector.payload['status'] == 'ok'
            assert len(inspector._images) == 2
            with LibraryDB(root / 'data/library.db') as db:
                assert db.get_analysis(*paths) == inspector.payload
            inspector.close()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector._state_key == 'analysis_loaded'
            app.lang.set('ko')
            app.change_language()
            assert inspector.title() == app.i18n.t('inspector_title')
            assert app.i18n.t('inferred_analysis') in inspector.details.get('1.0', 'end')
            inspector.swap_direction()
            pump(lambda: not inspector._busy)
            assert inspector.payload['tone']['mean_luminance_delta'] < 0
            assert fingerprints == [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
            # Exercise the new user-facing routes through the installed widgets,
            # then reopen each saved snapshot through a fresh workflow window.
            from personal_color_lab.core.raw_decode import decode_raw
            from personal_color_lab.core.synthetic_raw import write_test_dng
            folders = {'reference_jpg': photos}
            raw_jpg = root / 'raw-jpg'
            raw_xmp = root / 'raw-xmp'
            raw_jpg.mkdir()
            raw_xmp.mkdir()
            raw_path = write_test_dng(raw_jpg / 'photo.dng')
            raw_pixels, _, _ = decode_raw(raw_path)
            Image.fromarray(np.clip(raw_pixels.astype(float) * 1.08 + [6, 1, -3], 0, 255).astype(np.uint8)).save(raw_jpg / 'photo_edit.jpg', quality=98)
            write_test_dng(raw_xmp / 'photo.dng')
            (raw_xmp / 'photo.xmp').write_text(
                '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
                'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
                'crs:Exposure2012="0.7" crs:Contrast2012="-12" crs:Temperature="6100"/>', encoding='utf-8')
            folders.update(raw_jpg=raw_jpg, raw_xmp=raw_xmp)
            source_hashes = {path: hashlib.sha256(path.read_bytes()).hexdigest() for folder in folders.values() for path in folder.iterdir()}
            for mode, folder in folders.items():
                directory_picker = app_module.filedialog.askdirectory
                try:
                    app_module.filedialog.askdirectory = lambda **kwargs: str(folder)
                    app.choose_btn.invoke()
                finally:
                    app_module.filedialog.askdirectory = directory_picker
                workflow = app._source_workflows[-1]
                pump(lambda: not workflow._busy and bool(workflow._included))
                assert workflow.mode == mode
                first_id=next(iter(workflow._items))
                selected_item_id=workflow._items[first_id]['id']
                workflow.review_tree.selection_set(first_id);workflow._review_selected()
                workflow.review_scene_btn.invoke();dialog=workflow._scene_dialog
                assert dialog is not None
                dialog.time_selection.set(app.i18n.t('scene_label_night'))
                dialog.environment_selection.set(app.i18n.t('scene_unspecified'))
                for label,var in dialog._vars.items():var.set(label=='portrait')
                dialog.apply_button.invoke()
                assert workflow._scene_dialog is None
                workflow.analyze_btn.invoke()
                pump(lambda: not workflow._busy)
                assert workflow.batch['status'] == 'ok', workflow.batch
                assert set(workflow.cards) == {'brightness', 'temperature', 'contrast', 'saturation', 'clarity', 'texture'}
                assert all(label.cget('text') for label in workflow.cards.values())
                assert workflow.batch['summary']['scene_stats']['manual_count']>=1
                selected_result=next(row for row in workflow.batch['results'] if row['item']['id']==selected_item_id)
                assert selected_result['payload']['photo_scene']['source']=='manual'
                assert selected_result['payload']['photo_scene']['labels']==['night','portrait']
                if mode == 'reference_jpg':
                    assert workflow.batch['summary']['sample_count'] == 2
                    assert workflow.batch['summary']['palette']
                    assert workflow.palette.find_all()
                elif mode == 'raw_jpg':
                    assert workflow.batch['summary']['brightness_delta_median'] > 0
                    assert workflow.batch['results'][0]['payload']['provenance']['raw_baseline']['decoder'] == 'rawpy_libraw'
                else:
                    assert workflow.batch['summary']['parameters']['Exposure2012']['median'] == 0.7
                workflow.style_name.set('native ' + mode)
                workflow.save_btn.invoke()
                assert workflow._status_key == 'source_saved', workflow.status.get()
                expected = workflow.batch
                with LibraryDB(root / 'data/library.db') as db:
                    profile = next(row for row in db.list_source_profiles() if row['name'] == 'native ' + mode)
                workflow.close()
                app.open_saved_styles()
                reopened = app._source_workflows[-1]
                reopened.profiles_tree.selection_set(str(profile['id']))
                app.update()
                reopened.open_profile_btn.invoke()
                assert reopened.batch == expected and reopened.mode == mode
                assert reopened._status_key == 'source_profile_snapshot'
                reopened.close()
            # Apply a learned reference, mix with a builtin and export through
            # the installed widgets, then reopen the recipe from SQLite.
            studio = app.open_style_workspace()
            from personal_color_lab.ui import style_workspace as style_module
            picker = style_module.filedialog.askopenfilename
            try:
                style_module.filedialog.askopenfilename = lambda **kwargs: str(paths[0])
                studio.choose_btn.invoke()
            finally:
                style_module.filedialog.askopenfilename = picker
            def style_ready():
                return studio.preview is not None and not studio._busy and studio._debounce is None and studio._preview_generation == studio._generation
            pump(style_ready)
            assert len(studio._styles) >= 15
            assert studio.recognition.get() and studio.preview['scene'] is not None
            assert studio._parameters_open and studio.parameters_frame.winfo_ismapped()
            assert int(studio.parameters_text.cget('height')) == 8
            assert app.i18n.t('parameter_contrast') in studio.parameters_text.get('1.0', 'end')
            assert app.i18n.t('parameter_saturation') in studio.parameters_text.get('1.0', 'end')
            studio.parameters_btn.invoke();app.update();assert not studio.parameters_frame.winfo_ismapped()
            studio.parameters_btn.invoke();app.update();assert studio.parameters_frame.winfo_ismapped()
            assert studio.preview['scene']['report']['backend']=='opencv_dnn_cpu'
            assert not studio.empty_panel.winfo_ismapped()
            assert len(studio.preview['style_tiles'])==3
            assert all(button.cget('image') for button in studio.recommendation_buttons)
            initial_tiles=studio.preview['style_tiles']
            studio.details_btn.invoke();studio.subject_btn.invoke();app.update()
            assert studio.info_label.winfo_ismapped() and studio.subject_frame.winfo_ismapped()
            studio.compare_btn.invoke();app.update();assert studio._wide_compare
            studio.wipe.set(35);studio._redraw_images();app.update()
            generation=studio._generation
            image=studio.image_labels['original']
            image.event_generate('<Button-1>',x=image.winfo_width()//3,y=image.winfo_height()//2)
            pump(lambda:studio._view_after is None)
            assert studio._generation==generation
            studio.compare_btn.invoke();app.update();assert not studio._wide_compare
            studio.overlay_chk.invoke(); app.update()
            assert studio.show_regions.get()
            studio.advanced_btn.invoke();app.update()
            assert studio.advanced_frame.winfo_ismapped()
            assert any(str(button.cget('state'))=='normal' for button in studio.recommendation_buttons)
            studio.strength.set(0); studio._schedule_preview(); pump(style_ready)
            assert np.array_equal(studio.preview['original'], studio.preview['rendered'])
            assert '1.00×' in studio.parameters_text.get('1.0', 'end')
            assert '+0.0%' in studio.parameters_text.get('1.0', 'end')
            assert studio.preview['style_tiles'] is initial_tiles
            studio.strength.set(70)
            studio.secondary.set(list(studio._choices)[2]); studio._schedule_preview(); pump(style_ready)
            assert studio.active_dna['kind'] == 'hybrid'
            save_picker = style_module.filedialog.asksaveasfilename
            destinations = iter([root / 'styled-copy.jpg', root / 'styled-preset.xmp', root / 'style-recipe.json'])
            try:
                style_module.filedialog.asksaveasfilename = lambda **kwargs: str(next(destinations))
                studio.jpeg_btn.invoke(); pump(lambda: not studio._busy)
                studio.xmp_btn.invoke(); pump(lambda: not studio._busy)
                studio.name.set('Native mixed style'); studio.json_btn.invoke()
            finally:
                style_module.filedialog.asksaveasfilename = save_picker
            with Image.open(root / 'styled-copy.jpg') as exported_image:
                assert exported_image.size == (420, 280)
            assert (root / 'styled-preset.xmp').is_file() and (root / 'style-recipe.json').is_file()
            studio.save_btn.invoke(); pump(style_ready); studio.close()
            studio = app.open_style_workspace()
            assert 'Native mixed style' in studio._source_names.values()
            studio.close()
            # RAW preview speed is a deliberate opt-in. Exercise both real
            # sensor-half decoding and the small-sensor fallback, including
            # cache boundaries and the translated quality explanation.
            from personal_color_lab.core.style_dna import GRID, identity_dna
            dna = identity_dna('Native RAW reference', 'reference', 'reference')
            dna['reference_target'] = {'quantiles': [.1, .3, .5, .7, .9],
                                       'saturation': .18, 'zones': {}}
            studio = app.open_style_workspace(initial_dna=dna)
            assert not studio.fast_raw.get()
            picker = style_module.filedialog.askopenfilename
            try:
                style_module.filedialog.askopenfilename = lambda **kwargs: str(raw_path)
                studio.choose_btn.invoke()
            finally:
                style_module.filedialog.askopenfilename = picker
            pump(style_ready)
            assert studio.preview['raw_quality'] == 'baseline'
            assert studio.preview['raw_decode']['quality_used'] == 'baseline'
            assert studio.raw_preview_toggle.winfo_ismapped()
            assert not studio.raw_preview_hint.winfo_ismapped()
            assert app.i18n.t('style_raw_preview_baseline') in studio.file_label.cget('text')
            baseline_tiles = studio.preview['style_tiles']
            studio.raw_preview_toggle.invoke(); pump(style_ready)
            assert studio.fast_raw.get() and studio.preview['raw_quality'] == 'interactive'
            assert not studio.preview['raw_decode']['half_size']
            assert studio.preview['style_tiles'] is not baseline_tiles
            assert studio.raw_preview_hint.winfo_ismapped()
            assert app.i18n.t('style_raw_preview_fallback') in studio.file_label.cget('text')
            fallback_preview = studio.preview
            app.lang.set('en'); app.change_language(); app.update()
            assert studio.preview is fallback_preview
            assert app.i18n.t('style_raw_preview_fallback') in studio.file_label.cget('text')
            studio.raw_preview_toggle.invoke(); pump(style_ready)
            assert not studio.fast_raw.get() and studio.preview['raw_quality'] == 'baseline'
            assert studio.preview['style_tiles'] is not fallback_preview['style_tiles']

            large_raw = write_test_dng(root / 'large-oriented-sensor.dng', width=2880,
                                       height=1920, orientation=6)
            source_hashes[large_raw] = hashlib.sha256(large_raw.read_bytes()).hexdigest()
            try:
                style_module.filedialog.askopenfilename = lambda **kwargs: str(large_raw)
                studio.choose_btn.invoke()
            finally:
                style_module.filedialog.askopenfilename = picker
            pump(style_ready)
            assert studio.preview['original_dimensions'] == [1920, 2880]
            baseline_preview = studio.preview
            studio.raw_preview_toggle.invoke(); pump(style_ready)
            assert studio.preview['raw_decode']['half_size']
            assert studio.preview['raw_decode']['quality_used'] == 'interactive_half_size'
            assert studio.preview['raw_decode']['preview_is_approximation']
            assert studio.preview['style_tiles'] is not baseline_preview['style_tiles']
            assert app.i18n.t('style_raw_preview_fast') in studio.file_label.cget('text')
            studio.strength.set(42); studio._schedule_preview(); pump(style_ready)
            fast_preview = studio.preview
            assert fast_preview['strength'] == .42

            # Observe real worker calls without replacing pixels, recipes or
            # recognition. XMP adaptation must use fresh strict AHD evidence
            # while retaining the selected strength and displayed preview.
            raw_xmp_destination = root / 'precise-raw-reference.xmp'
            renders, exports, precise_results = [], [], []
            render, export = style_module.render_preview, style_module.export_xmp
            def observed_render(*args, **kwargs):
                result = render(*args, **kwargs)
                renders.append((args[2], kwargs.get('raw_quality')))
                precise_results.append(result)
                return result
            def observed_export(*args, **kwargs):
                exports.append((args[3], args[2]))
                return export(*args, **kwargs)
            save_picker = style_module.filedialog.asksaveasfilename
            try:
                style_module.render_preview = observed_render
                style_module.export_xmp = observed_export
                style_module.filedialog.asksaveasfilename = lambda **kwargs: str(raw_xmp_destination)
                studio.xmp_btn.invoke()
                assert str(studio.raw_preview_toggle.cget('state')) == 'disabled'
                pump(lambda: not studio._busy)
            finally:
                style_module.render_preview = render
                style_module.export_xmp = export
                style_module.filedialog.asksaveasfilename = save_picker
            assert raw_xmp_destination.is_file() and renders == [(0., 'baseline')]
            assert len(exports) == 1 and exports[0][0] == .42
            precise = precise_results[0]
            assert precise['raw_decode']['quality_used'] == 'baseline'
            assert precise['scene'] is not None and precise['scene']['report']['backend'] == 'opencv_dnn_cpu'
            assert exports[0][1] is precise['effective']
            assert exports[0][1] is not fast_preview['effective']
            assert precise['original'] is not baseline_preview['original']
            assert np.array_equal(precise['original'], baseline_preview['original'])
            assert studio.preview is fast_preview and studio.fast_raw.get()
            rdf = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
            crs = 'http://ns.adobe.com/camera-raw-settings/1.0/'
            exported_curve = ET.parse(raw_xmp_destination).find('.//{' + crs + '}ToneCurvePV2012/{' + rdf + '}Seq')
            effective_curve = GRID + (np.asarray(precise['effective']['tone_curve']) - GRID) * .42
            assert [node.text for node in exported_curve] == [f'{round(x * 255)}, {round(y * 255)}'
                                                             for x, y in zip(GRID, effective_curve)]
            studio.close()
            # Preserve an identified, uncalibrated GM II rather than replacing
            # it with the original GM. The generated chart carries synthetic
            # equipment tags; choosing a published Canon profile here tests
            # manual selection and real warping, not Sony calibration quality.
            sony_equipment = {'camera_make': 'Sony', 'camera_model': 'ILCE-7CR',
                              'lens_make': 'Sony', 'lens_model': 'FE 16-35mm F2.8 GM II',
                              'focal_length_mm': 16., 'aperture': 2.8}
            optical_raw = write_test_dng(root / 'synthetic-equipment.dng', width=960,
                                         height=640, equipment=sony_equipment)
            source_hashes[optical_raw] = hashlib.sha256(optical_raw.read_bytes()).hexdigest()
            studio = app.open_style_workspace(initial_dna=identity_dna('Native optical check'))
            try:
                style_module.filedialog.askopenfilename = lambda **kwargs: str(optical_raw)
                studio.choose_btn.invoke()
            finally:
                style_module.filedialog.askopenfilename = picker
            pump(style_ready)
            automatic_preview = studio.preview
            assert studio.lens_correction.get() and automatic_preview['lens_correction_requested']
            assert automatic_preview['equipment']['camera_model'] == 'ILCE-7CR'
            assert automatic_preview['equipment']['lens_model'] == sony_equipment['lens_model']
            assert not automatic_preview['lens_correction']['applied']
            assert automatic_preview['lens_correction']['status'] == 'lens_not_found'
            assert app.i18n.t('lens_profile_missing') in studio.lens_info.cget('text')
            assert studio.xmp_notice.cget('text') == app.i18n.t('style_lens_xmp_notice')

            def select_optics(focal):
                studio.lens_manual_btn.invoke(); dialog = studio._lens_dialog
                dialog.camera.set('Canon EOS 5D Mark II')
                dialog.camera_combo.event_generate('<<ComboboxSelected>>'); app.update()
                lens_label = 'Canon EF 17-40mm f/4L USM'
                assert dialog._lens_items[lens_label]['calibrated']
                dialog.lens.set(lens_label)
                dialog.lens_combo.event_generate('<<ComboboxSelected>>'); app.update()
                dialog.focal.set(str(focal)); dialog.apply_button.invoke()
                assert dialog._closed and studio._lens_dialog is None
                pump(style_ready)
                return studio.preview

            wide_preview = select_optics(17)
            tele_preview = select_optics(40)
            assert wide_preview['lens_correction']['applied'] and tele_preview['lens_correction']['applied']
            assert wide_preview['lens_correction']['selected_equipment']['focal_length_mm'] == 17
            assert tele_preview['lens_correction']['selected_equipment']['focal_length_mm'] == 40
            assert wide_preview['equipment'] == tele_preview['equipment'] == automatic_preview['equipment']
            assert not np.array_equal(wide_preview['original'], automatic_preview['original'])
            assert not np.array_equal(tele_preview['original'], wide_preview['original'])
            assert tele_preview['style_tiles'] is not wide_preview['style_tiles']
            studio.lens_toggle.invoke(); pump(style_ready)
            assert not studio.preview['lens_correction_requested']
            assert np.array_equal(studio.preview['original'], automatic_preview['original'])
            studio.lens_toggle.invoke(); pump(style_ready)
            assert studio.preview['lens_correction']['applied']
            assert np.array_equal(studio.preview['original'], tele_preview['original'])
            corrected_tiles = studio.preview['style_tiles']
            studio.strength.set(35); studio._schedule_preview(); pump(style_ready)
            assert studio.preview['style_tiles'] is corrected_tiles
            optical_preview = studio.preview
            optical_jpeg = root / 'lens-corrected.jpg'
            optical_xmp = root / 'lens-global-only.xmp'
            jpeg_results, optical_precise = [], []
            jpeg_export, render = style_module.export_jpeg, style_module.render_preview
            def observed_optical_jpeg(*args, **kwargs):
                result = jpeg_export(*args, **kwargs)
                jpeg_results.append(result)
                return result
            def observed_optical_precision(*args, **kwargs):
                result = render(*args, **kwargs)
                optical_precise.append(result)
                return result
            destinations = iter((optical_jpeg, optical_xmp))
            save_picker = style_module.filedialog.asksaveasfilename
            try:
                style_module.export_jpeg = observed_optical_jpeg
                style_module.render_preview = observed_optical_precision
                style_module.filedialog.asksaveasfilename = lambda **kwargs: str(next(destinations))
                studio.jpeg_btn.invoke()
                assert str(studio.lens_toggle.cget('state')) == 'disabled'
                assert str(studio.lens_manual_btn.cget('state')) == 'disabled'
                pump(lambda: not studio._busy)
                studio.xmp_btn.invoke()
                assert str(studio.lens_toggle.cget('state')) == 'disabled'
                assert str(studio.lens_manual_btn.cget('state')) == 'disabled'
                pump(lambda: not studio._busy)
            finally:
                style_module.export_jpeg = jpeg_export
                style_module.render_preview = render
                style_module.filedialog.asksaveasfilename = save_picker
            assert optical_jpeg.is_file() and optical_xmp.is_file()
            assert jpeg_results[0]['lens_correction']['applied']
            assert jpeg_results[0]['lens_override']['focal_length_mm'] == 40
            assert jpeg_results[0]['equipment'] == automatic_preview['equipment']
            assert jpeg_results[0]['dimensions'] == [960, 640]
            with Image.open(optical_jpeg) as image:
                assert image.size == (960, 640) and not image.getexif()
                assert float(np.abs(np.asarray(image.convert('RGB')).astype(float)
                                    - optical_preview['original'].astype(float)).mean()) < 3
            assert len(optical_precise) == 1
            assert optical_precise[0]['raw_decode']['quality_used'] == 'baseline'
            assert optical_precise[0]['lens_correction']['applied']
            assert optical_precise[0]['lens_override']['focal_length_mm'] == 40
            optical_attributes = next(node.attrib for node in ET.parse(optical_xmp).iter()
                                      if node.tag.endswith('Description'))
            assert not any('LensProfile' in key or 'Distortion' in key for key in optical_attributes)
            assert studio.preview is optical_preview
            studio.lens_manual_btn.invoke(); studio._lens_dialog.use_automatic(); pump(style_ready)
            assert studio._lens_override is None and studio.preview['lens_override'] is None
            assert np.array_equal(studio.preview['original'], automatic_preview['original'])
            select_optics(17)
            try:
                style_module.filedialog.askopenfilename = lambda **kwargs: str(paths[0])
                studio.choose_btn.invoke()
            finally:
                style_module.filedialog.askopenfilename = picker
            assert studio._lens_override is None
            pump(style_ready)
            assert studio.preview['equipment'] is None and not studio.lens_toggle.winfo_ismapped()
            studio.scene_review_btn.invoke();scene_dialog=studio._scene_dialog
            scene_dialog.time_selection.set(app.i18n.t('scene_label_night'))
            scene_dialog.environment_selection.set(app.i18n.t('scene_unspecified'))
            for label,var in scene_dialog._vars.items():var.set(label=='portrait')
            scene_dialog.apply_button.invoke();pump(style_ready)
            assert studio.preview['photo_scene']['labels']==['night','portrait']
            assert app.i18n.t('scene_label_night') in studio.photo_scene_label.cget('text')
            studio.scene_review_btn.invoke();studio._scene_dialog.auto_button.invoke();pump(style_ready)
            assert studio._scene_override is None and studio.preview['photo_scene']['source']=='automatic'
            assert str(studio.strength_label.cget('anchor'))==str(studio.mix_label.cget('anchor'))=='e'
            assert str(studio.strength_label.cget('font'))=='LabNumber'
            studio.close()
            app.update()
            assert app.home_learn_btn.winfo_rooty()==app.home_apply_btn.winfo_rooty()
            app.folder.set(str(photos));app.home_learn_btn.invoke()
            home_workflow=app._source_workflows[-1];pump(lambda:not home_workflow._busy)
            assert home_workflow.tabs.select()==str(home_workflow.review_tab)
            for column in home_workflow.review_tree['columns']:
                assert str(home_workflow.review_tree.heading(column,'anchor'))==str(home_workflow.review_tree.column(column,'anchor'))
            home_workflow.close()
            assert all(hashlib.sha256(path.read_bytes()).hexdigest() == digest for path, digest in source_hashes.items())
            # The travel entry must work through actual widgets, persist picks
            # and photo layers, and save a new JPG on its background queue.
            from personal_color_lab.core.travel_store import TravelStore
            trip_folder = root / 'trip'; trip_folder.mkdir()
            with Image.open(paths[0]) as trip_source:
                trip_pixels=np.array(trip_source.convert('RGB'))
            for index in range(3):
                Image.fromarray(trip_pixels).save(trip_folder / f'DSC{index:05}.jpg', quality=95)
            trip_hashes = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in trip_folder.iterdir()}
            app.travel_btn.invoke(); trip = app._travel_workspaces[-1]
            trip.import_folder(trip_folder); pump(lambda: not trip._busy)
            assert len(trip._photos) == 3, trip.status.get()
            trip.recognition.set(False); trip.lens_correction.set(False); trip._settings_changed()
            ids = [photo['id'] for photo in trip._photos]
            assert str(trip.resume_btn.cget('state'))==str(trip.retry_btn.cget('state'))=='disabled'
            trip.filter.set(app.i18n.t('travel_filter_hold'));trip._refresh_grid();app.update()
            assert trip.empty.winfo_ismapped() and not trip.grid_view.rows
            trip.empty_btn.invoke();assert len(trip.grid_view.rows)==3
            trip.grid_view.select_ids(ids[:2],active_id=ids[1])
            assert trip._active_id==trip.grid_view.active_id==ids[1]
            assert trip._preview is None and trip._preview_after is None and not trip._preview_running
            assert Path(trip._photos[1]['source_path']).name in trip.photo_label.cget('text')
            trip.grid_view.select_ids([ids[1]]); trip.mark_pick('hold')
            trip.grid_view.select_ids([ids[2]]); trip.mark_pick('reject')
            trip.grid_view.select_ids([ids[0]])
            trip.exposure.set(.3); trip.warmth.set(12); trip._edits_changed(); trip._flush_edits()
            trip.notebook.select(trip.compare)
            pump(lambda: not trip._preview_running and trip._preview_after is None and trip._preview is not None)
            assert trip._preview['photo_adjustments']['exposure_ev'] == .3
            assert len(trip._preview_images) == 2
            assert trip._value_labels['travel_exposure'].cget('text')=='+0.30 EV'
            assert str(trip._value_labels['travel_exposure'].cget('anchor'))=='e'
            assert str(trip._value_labels['travel_exposure'].cget('font'))=='LabNumber'
            trip.destination = str(root / 'trip-outputs'); trip.start_export()
            pump(lambda: not trip._busy)
            assert len(list((root / 'trip-outputs').glob('*.jpg'))) == 1, trip.status.get()
            assert str(trip.resume_btn.cget('state'))==str(trip.retry_btn.cget('state'))=='disabled'
            assert trip.destination_path.cget('text')==str(root/'trip-outputs')
            for column in ('file','status','detail'):
                assert str(trip.tasks.heading(column,'anchor'))==str(trip.tasks.column(column,'anchor'))=='w'
            trip.resume_exports(); pump(lambda: not trip._busy)
            with TravelStore(trip.db_path) as store:
                tasks = store.list_tasks(trip._project_id)
                assert len(tasks) == 1 and tasks[0]['status'] == 'completed' and tasks[0]['attempts'] == 1
                assert [photo['pick'] for photo in store.list_photos(trip._project_id)] == ['keep', 'hold', 'reject']
            trip_id = trip._project_id; trip.close()
            trip = app.open_travel_workspace(project_id=trip_id)
            assert trip._photos[0]['adjustments']['exposure_ev'] == .3
            assert len(trip.tasks.get_children()) == 1
            trip.translate(); trip.close()
            assert all(hashlib.sha256(path.read_bytes()).hexdigest() == digest for path, digest in trip_hashes.items())
            report = {'ok': True, 'text_rendering': text_rendering, 'checks': ['native_text_fonts', 'manual_pair', 'manual_reopen_cache', 'default_summary', 'measured_curve', 'scan', 'registered_analysis', 'previews', 'database', 'cache', 'korean', 'direction_swap', 'original_hashes', 'python_network_blocked', 'folder_mode_selection', 'reference_jpg_palette_tendencies', 'real_raw_jpg_analysis', 'raw_xmp_recorded_parameters', 'named_source_profiles', 'fresh_profile_reopening', 'style_studio', 'zero_strength_identity', 'hybrid_preview', 'full_resolution_jpeg_export', 'xmp_preset_export', 'style_json_export', 'saved_recipe_reopening', 'embedded_cpu_recognition', 'region_overlay', 'advanced_controls', 'style_recommendations', 'wide_wipe_comparison', 'photo_based_style_tiles', 'intensity_thumbnail_reuse', 'studio_disclosures', 'direct_wipe_drag', 'native_vector_controls', 'fast_raw_preview_explicit', 'raw_preview_resolution_fallback', 'raw_quality_cache_separation', 'localized_raw_quality_labels', 'oriented_half_size_sensor_preview', 'precise_raw_xmp_export', 'raw_xmp_strength_preserved', 'raw_export_controls_locked', 'raw_source_bytes_unchanged']}
            report['checks'].extend(['source_scene_review_all_routes','source_scene_coverage','scene_snapshot_roundtrip','style_scene_review','style_scene_auto_reset', 'exact_sony_equipment_no_gm_substitution', 'manual_camera_lens_selection',
                                     'manual_focal_length_changes_geometry', 'detected_equipment_preserved',
                                     'lens_toggle_and_optical_cache_separation', 'corrected_thumbnail_reuse',
                                     'lens_corrected_raw_jpeg_export', 'precise_optical_xmp_global_only',
                                     'optical_export_controls_locked', 'automatic_equipment_reset',
                                     'new_photo_clears_manual_equipment'])
            report['checks'].extend(['pair_seven_parameter_cards','source_six_parameter_cards_all_routes',
                                     'studio_applied_parameters_visible','studio_parameter_panel_disclosure',
                                     'studio_zero_strength_parameter_evidence'])
            report['checks'].extend(['travel_home_entry_and_folder_import', 'travel_keep_hold_reject',
                                     'travel_photo_layers_and_before_after', 'travel_real_queued_jpeg_export',
                                     'travel_completed_resume_no_render', 'travel_project_reopen',
                                     'travel_original_bytes_preserved'])
            report['checks'].extend(['home_matching_action_baselines_and_direct_learning',
                                     'text_table_heading_cell_alignment','studio_numeric_alignment',
                                     'travel_explicit_active_photo_and_deferred_preview',
                                     'travel_empty_filter_and_meaningful_actions',
                                     'travel_numeric_alignment_and_units','travel_output_path_and_queue_alignment'])
            report.update(app_version=APP_VERSION, runtime_network='denied',
                          user_photos_used=False, python_isolated=bool(sys.flags.isolated))
            if os.environ.get('PERSONAL_COLOR_LAB_GUI_REPORT'):
                Path(os.environ['PERSONAL_COLOR_LAB_GUI_REPORT']).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
            print(json.dumps(report))
        finally:
            app.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
