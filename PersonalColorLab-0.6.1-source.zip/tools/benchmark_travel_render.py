#!/usr/bin/env python3
"""Compare exact offline render reuse against a verified V0.5.6 source module.

Generated photos exercise real bundled CPU models and LibRaw. Timings describe
this machine and these fixtures, not native M1 or large-library throughput.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import platform
import statistics
import sys
import tempfile
import time
import types
import zipfile

import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from personal_color_lab.core import style_render
from personal_color_lab.core.edit_reverse import file_fingerprint
from personal_color_lab.core.render_evidence import RenderEvidenceCache
from personal_color_lab.core.style_dna import builtin_styles
from personal_color_lab.core.synthetic_raw import write_test_dng


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def old_renderer(archive):
    expected = archive.with_suffix(archive.suffix + '.sha256')
    actual = sha256(archive)
    if not expected.is_file() or expected.read_text().split()[0] != actual:
        raise ValueError('The V0.5.6 source archive checksum cannot be verified.')
    with zipfile.ZipFile(archive) as source:
        names = [name for name in source.namelist() if name.endswith('personal_color_lab/core/style_render.py')]
        if len(names) != 1:
            raise ValueError('The archive must contain one baseline style renderer.')
        contents = source.read(names[0])
    name = 'personal_color_lab.core._travel_benchmark_v056'
    module = types.ModuleType(name)
    module.__package__ = 'personal_color_lab.core'
    module.__file__ = str(archive) + '/' + names[0]
    sys.modules[name] = module
    exec(compile(contents, module.__file__, 'exec'), module.__dict__)
    return module, {'archive_sha256': actual, 'renderer_sha256': hashlib.sha256(contents).hexdigest()}


@contextmanager
def counted(module):
    names = ('_measure', '_recognition_scene', '_classification_scene')
    original = {name: getattr(module, name) for name in names}
    calls = {name: 0 for name in names}
    def wrap(name):
        def run(*args, **kwargs):
            calls[name] += 1
            return original[name](*args, **kwargs)
        return run
    for name in names:
        setattr(module, name, wrap(name))
    try:
        yield calls
    finally:
        for name in names:
            setattr(module, name, original[name])


def workload(module, photos, directory, *, optimized, export, recognition):
    cache = RenderEvidenceCache()
    kwargs = {'recognition': recognition}
    if optimized:
        kwargs['evidence_cache'] = cache
    styles = builtin_styles()[:2]
    outputs = []
    with counted(module) as calls:
        started = time.perf_counter()
        if export:
            for index, photo in enumerate(photos):
                result = module.render_preview(photo, styles[index % 2], .65, **kwargs)
                outputs.append(result['rendered'])
                destination = directory / f'export-{index}.jpg'
                metadata = module.export_jpeg(photo, destination, styles[index % 2], .65,
                                              expected_fingerprint=result['source_fingerprint'], **kwargs)
                with Image.open(destination) as image:
                    outputs.append(np.array(image))
                    if image.getexif() or not image.info.get('icc_profile'):
                        raise AssertionError('JPEG privacy/color metadata regressed.')
                if not metadata['source_unchanged']:
                    raise AssertionError('The original was modified.')
        else:
            # Revisit two photos without passing a prepared preview base. The
            # older base= path already reuses evidence during a slider drag.
            for index in range(6):
                photo = photos[index % 2]
                outputs.append(module.render_preview(photo, styles[index % 2], .5 + .1 * (index % 3), **kwargs)['rendered'])
        elapsed = time.perf_counter() - started
    return {'seconds': elapsed, 'calls': calls, 'cache': cache.info()}, outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline-archive', type=Path, default=ROOT.parent / 'artifacts/installers-v0.5.6/PersonalColorLab-0.5.6-source.zip')
    parser.add_argument('--runs', type=int, default=3)
    parser.add_argument('--width', type=int, default=1600)
    parser.add_argument('--height', type=int, default=1064)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if not 1 <= args.runs <= 10 or not 320 <= min(args.width, args.height) or max(args.width, args.height) > 6000:
        parser.error('Use 1–10 runs and dimensions between 320 and 6000.')
    cv2.setNumThreads(1)
    baseline, provenance = old_renderer(args.baseline_archive)
    report = {'scope': 'Generated fixtures, real local CPU models, warm process; no native M1 or 500-photo claim.',
              'platform': platform.platform(), 'python': platform.python_version(),
              'dimensions': [args.width, args.height], 'runs': args.runs,
              'baseline': provenance, 'cases': {}}
    with tempfile.TemporaryDirectory(prefix='pcl-travel-benchmark-') as temporary:
        root = Path(temporary)
        inputs = {'jpg': [], 'raw': []}
        for index in range(2):
            raw = write_test_dng(root / f'photo-{index}.dng', width=args.width, height=args.height, seed=17 + index)
            full, _ = style_render.read_photo(raw, max_dimension=1_000_000)
            jpg = root / f'photo-{index}.jpg'
            Image.fromarray(full).save(jpg, quality=98, subsampling=0)
            inputs['raw'].append(raw);inputs['jpg'].append(jpg)
        before = {str(path): file_fingerprint(path) for photos in inputs.values() for path in photos}
        report['source_sha256'] = {Path(path).name: value for path, value in before.items()}
        # Warm real model verification and inference once; cold startup is a
        # separate concern and is not presented as an algorithm improvement.
        warm = style_render.render_preview(inputs['jpg'][0], builtin_styles()[0], recognition=True)
        if warm['recognition_unavailable'] or warm['automatic_photo_scene']['status'] != 'ok':
            raise RuntimeError('Real local recognition/classification models are required.')
        for kind, photos in inputs.items():
            for export in (False, True):
                for recognition in (False, True):
                    case = f'{kind}-' + ('preview-export' if export else 'revisit') + ('-objects' if recognition else '-global')
                    records = {'baseline': [], 'optimized': []}
                    comparisons = []
                    for run in range(args.runs):
                        # Alternate measurement order to reduce order bias.
                        outputs = {}
                        order = ('baseline', 'optimized') if run % 2 == 0 else ('optimized', 'baseline')
                        for mode in order:
                            directory = root / f'{case}-{run}-{mode}';directory.mkdir()
                            result, outputs[mode] = workload(baseline if mode == 'baseline' else style_render,
                                photos, directory, optimized=mode == 'optimized', export=export, recognition=recognition)
                            records[mode].append(result)
                        equal = len(outputs['baseline']) == len(outputs['optimized']) and all(
                            np.array_equal(a, b) for a, b in zip(outputs['baseline'], outputs['optimized']))
                        comparisons.append(equal)
                        if not equal:
                            raise AssertionError(f'Pixel equivalence failed: {case}.')
                    old = statistics.median(item['seconds'] for item in records['baseline'])
                    new = statistics.median(item['seconds'] for item in records['optimized'])
                    report['cases'][case] = {'baseline_median_seconds': old, 'optimized_median_seconds': new,
                                            'speedup': old / new, 'pixel_exact': all(comparisons), 'measurements': records}
        report['source_unchanged'] = all(file_fingerprint(path) == value for path, value in before.items())
        if not report['source_unchanged']:
            raise AssertionError('Benchmark input was modified.')
    encoded = json.dumps(report, indent=2, allow_nan=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded + '\n', encoding='utf-8')
    print(encoded)


if __name__ == '__main__':
    main()
