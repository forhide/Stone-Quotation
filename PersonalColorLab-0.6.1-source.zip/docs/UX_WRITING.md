# Interface writing

Use these conventions in both locale files. Keep visible copy in
`personal_color_lab/locales/en.json` and `ko.json`; do not change persisted
parameter names, scene IDs or style schemas to alter their display labels.

- Use sentence case for English headings, tabs, buttons and field labels.
  Preserve names and abbreviations such as Personal Color Lab, Lightroom,
  RAW, JPG, XMP, RGB, HSL, EV, Lab and sRGB. Avoid all-capital decorative text.
- Use **Create style** for learning a style and **Apply style** for using one.
  **Save style** stores it locally; **Export JPG / XMP / style** writes a file.
  Add one ellipsis (`…`) when a button opens a picker or requires confirmation.
- Use **Before** and **After** for separate preview captions; use
  **Before / after** for the combined tab. In Korean, use **보정 전** and
  **보정 후**. Explain a lens-corrected RAW baseline where relevant.
- Keep **Keep / Hold / Reject** distinct from the active multi-selection.
  Their Korean labels are **보관 / 보류 / 제외**; **선택한 사진** means the
  current selection. Export counts describe eligible kept photos, not every
  selected row. Temporary adjustments affect the current photo until the user
  explicitly copies them to selected photos or a suggested group.
- Use **Recognize subjects / 피사체 인식** for object-region processing.
  Turning it off does not disable learned scene recipes. Avoid promising
  that a suggested shooting group has identical content or lighting.
- Keep **틴트** distinct from a hue-channel adjustment (**색조**). Relative
  warmth is not camera Kelvin. State that a photo style amount of 100% uses
  the trip's selected style strength.
- Use short action verbs for controls and one clear next action for errors.
  A missing original may be restored and retried. A changed original or
  runtime needs a new export; preparation failures were not queued. An
  existing output must remain intact.
- Retain established units: `EV`, `mm`, `px`, `%` and degrees (`°`). Put a
  space before a textual Latin unit, preserve numerical placeholders and use
  the UI's locale-aware number formatting. Do not introduce spaces to align
  values; label/value widgets determine alignment.

Review copy in the actual English and Korean minimum-size layouts. Long
helpers should wrap from the left, labels share a left edge, and measured
values use a consistent right edge. A clean sentence-case conversion alone
does not establish that an action or its scope is clear.
