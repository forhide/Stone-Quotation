"""Exercise style application controls, persistence and safe exports on real Tk."""
import hashlib
import threading
import time
import numpy as np
from PIL import Image
import pytest
from test_source_workflow_ui import desktop, _pump, _inputs, _open, _analyze, pytestmark
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.constants import DB_FILENAME, app_data_dir
from personal_color_lab.core.style_dna import load_style_file


def ready(window):
    return window.preview is not None and not window._busy and window._debounce is None and window._preview_generation==window._generation


@pytest.mark.parametrize('language',['en','ko'])
def test_style_preview_strength_hybrid_exports_and_recipe_reopening(desktop, monkeypatch, language):
    app,root=desktop;app.lang.set(language);app.change_language()
    photo=root/'photo.jpg';Image.fromarray(np.random.default_rng(2).integers(20,230,(180,270,3),dtype='uint8')).save(photo)
    before=hashlib.sha256(photo.read_bytes()).hexdigest()
    window=app.open_style_workspace()
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',lambda **kw:str(photo))
    window.choose_btn.invoke();_pump(app,lambda:ready(window))
    assert len(window._styles)==12
    assert str(window.jpeg_btn.cget('state'))=='normal'
    window.strength.set(0);window._schedule_preview();_pump(app,lambda:ready(window))
    assert np.array_equal(window.preview['original'],window.preview['rendered'])
    window.strength.set(70);window.secondary.set(list(window._choices)[2]);window._schedule_preview();_pump(app,lambda:ready(window))
    assert window.active_dna['kind']=='hybrid'
    outputs=iter([root/'edited.jpg',root/'recipe.xmp',root/'recipe.json'])
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.asksaveasfilename',lambda **kw:str(next(outputs)))
    window.jpeg_btn.invoke();_pump(app,lambda:not window._busy)
    window.xmp_btn.invoke();_pump(app,lambda:not window._busy)
    window.name.set('My mixed style');window.json_btn.invoke()
    with Image.open(root/'edited.jpg') as image:
        assert image.size==(270,180)
    assert (root/'recipe.xmp').is_file()
    assert load_style_file(root/'recipe.json')['kind']=='hybrid'
    window.save_btn.invoke();_pump(app,lambda:ready(window))
    with LibraryDB(app_data_dir()/DB_FILENAME) as db:assert db.list_style_presets()[0]['name']=='My mixed style'
    window.close();reopened=app.open_style_workspace()
    assert 'My mixed style' in reopened._source_names.values()
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',lambda **kw:str(root/'recipe.json'))
    reopened.import_btn.invoke();assert reopened._primary_key.startswith('imported:')
    assert hashlib.sha256(photo.read_bytes()).hexdigest()==before


@pytest.mark.parametrize('mode',['raw_jpg','raw_xmp','reference_jpg'])
def test_each_analysis_source_opens_style_workspace(desktop,mode):
    app,root=desktop;folder=_inputs(root/mode,mode);workflow=_open(app,folder,mode)
    _analyze(app,workflow);workflow.apply_btn.invoke()
    window=app._style_workspaces[-1]
    assert window._primary_key=='incoming'
    assert window._styles['incoming']['sample_count']>0
    window.source=next(folder.glob('*.jpg')) if mode=='reference_jpg' else next(folder.glob('*.dng'))
    window._schedule_preview();_pump(app,lambda:ready(window))
    assert window.preview['source_fingerprint']


@pytest.mark.parametrize('desktop',[1,1.5,2],indirect=True)
@pytest.mark.parametrize('language',['en','ko'])
def test_style_controls_remain_visible_at_minimum_size(desktop,language):
    app,_=desktop;app.lang.set(language);app.change_language();window=app.open_style_workspace()
    width,height=window.minsize();window.geometry(f'{width}x{height}');app.update()
    for control in (window.choose_btn,window.primary_combo,window.composition_combo,window.name_entry,window.jpeg_btn,window.xmp_btn):
        assert control.winfo_x()>=0
        assert control.winfo_rootx()+control.winfo_width()<=window.winfo_rootx()+window.winfo_width()
        assert control.winfo_rooty()+control.winfo_height()<=window.winfo_rooty()+window.winfo_height()


def test_close_during_style_worker_has_no_tk_callbacks(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(160,120),'orange').save(photo)
    from personal_color_lab.ui import style_workspace as module
    render=module.render_preview;started=threading.Event();release=threading.Event()
    def held(*args,**kwargs):
        started.set();assert release.wait(5);return render(*args,**kwargs)
    monkeypatch.setattr(module,'render_preview',held)
    window=app.open_style_workspace();window.source=photo;window.start_preview()
    _pump(app,started.is_set);threads=list(window._threads);window.close();release.set()
    for thread in threads:thread.join(5);assert not thread.is_alive()
    app.update();assert not app._closed


def test_recognition_overlay_recommendations_and_reset_are_reachable(desktop):
    app,root=desktop;photo=root/'scene.jpg';Image.fromarray(np.random.default_rng(7).integers(50,200,(160,240,3),dtype='uint8')).save(photo)
    studio=app.open_style_workspace();studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    assert studio.recognition.get() and studio.preview['scene'] is not None
    studio.overlay_chk.invoke();app.update();assert studio.show_regions.get()
    studio.advanced_btn.invoke();app.update();assert studio.advanced_frame.winfo_ismapped()
    assert studio._recommendations
    studio.recommendation_buttons[0].invoke();_pump(app,lambda:ready(studio))
    studio.strength.set(24);studio.mix.set(85);studio.reset_btn.invoke();_pump(app,lambda:ready(studio))
    assert studio.strength.get()==70 and studio.mix.get()==30
    studio.recognition_chk.invoke();_pump(app,lambda:ready(studio))
    assert studio.preview['scene'] is None
    assert str(studio.faces_chk.cget('state'))=='disabled'
    assert str(studio.object_slider.cget('state'))=='disabled'


def test_wide_comparison_changes_view_without_reprocessing(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(320,240),'tan').save(photo)
    studio=app.open_style_workspace();studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    generation=studio._generation;preview=studio.preview
    studio.compare_btn.invoke();app.update();assert studio._wide_compare
    assert int(studio.image_frames['original'].grid_info()['columnspan'])==2
    assert not studio.image_frames['styled'].winfo_ismapped()
    studio.wipe.set(25);studio._redraw_images();app.update()
    assert studio.preview is preview and studio._generation==generation
    studio.compare_btn.invoke();app.update();assert studio.image_frames['styled'].winfo_ismapped()


def test_stale_initial_preview_keeps_decoded_source_for_latest_adjustment(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(320,240),'tan').save(photo)
    from personal_color_lab.core import style_render as renderer
    from personal_color_lab.ui import style_workspace as module
    read=renderer.read_photo;render=module.render_preview;reads=[];started=threading.Event();release=threading.Event();first=[True]
    def tracked(*a,**kw):reads.append(1);return read(*a,**kw)
    def held(*a,**kw):
        if first[0]:
            first[0]=False;started.set();assert release.wait(5)
        return render(*a,**kw)
    monkeypatch.setattr(renderer,'read_photo',tracked);monkeypatch.setattr(module,'render_preview',held)
    studio=app.open_style_workspace();studio.source=photo;studio.start_preview();_pump(app,started.is_set)
    studio.strength.set(45);studio._schedule_preview();release.set();_pump(app,lambda:ready(studio))
    assert studio.preview['strength']==.45 and len(reads)==1


def test_settings_scroll_over_controls_and_reveal_keyboard_focus(desktop):
    app,_=desktop;studio=app.open_style_workspace()
    width,height=studio.minsize();studio.geometry(f'{width}x{height}')
    studio.advanced_btn.invoke();app.update()
    studio.settings_canvas.yview_moveto(0);app.update()
    before=studio.settings_canvas.yview();selected=studio.primary.get()
    assert before[1]-before[0]<1
    studio.primary_combo.event_generate('<MouseWheel>',delta=-120);app.update()
    assert studio.settings_canvas.yview()[0]>before[0]
    assert studio.primary.get()==selected
    studio.settings_canvas.yview_moveto(0);app.update()
    studio.import_btn.focus_force();app.update()
    top=studio.import_btn.winfo_rooty()-studio.settings_canvas.winfo_rooty()
    assert top>=0
    assert top+studio.import_btn.winfo_height()<=studio.settings_canvas.winfo_height()
    # Rail bindings do not intercept gestures over the image preview.
    view=studio.settings_canvas.yview()
    studio.image_labels['original'].event_generate('<MouseWheel>',delta=-120);app.update()
    assert studio.settings_canvas.yview()==view


def test_new_source_and_failed_preview_clear_previous_photo_and_evidence(desktop,monkeypatch):
    app,root=desktop;photo=root/'good.jpg';bad=root/'bad.jpg'
    Image.new('RGB',(240,160),'tan').save(photo);bad.write_bytes(b'not a JPEG')
    studio=app.open_style_workspace();studio.recognition.set(False)
    studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    assert studio.image_labels['original'].cget('image')
    assert studio.info_label.cget('text') and studio._recommendations
    monkeypatch.setattr('personal_color_lab.ui.style_workspace.filedialog.askopenfilename',lambda **kw:str(bad))
    studio.choose_photo()
    assert studio.preview is None and studio.active_dna is None
    assert not studio.image_labels['original'].cget('image')
    assert not studio.info_label.cget('text') and not studio._recommendations
    _pump(app,lambda:studio._status_key=='style_error' and not studio._busy)
    for label in studio.image_labels.values():
        assert not label.cget('image')
        assert label.cget('text')==app.i18n.t('style_empty')
    assert all(str(button.cget('state'))=='disabled' for button in studio.recommendation_buttons)
    assert str(studio.jpeg_btn.cget('state'))=='disabled'


def test_language_change_preserves_pending_mix_composition_and_custom_name(desktop):
    app,_=desktop;studio=app.open_style_workspace();studio.advanced_btn.invoke();app.update()
    secondary=list(studio._choices)[2];key=studio._choices[secondary]
    studio.secondary.set(secondary);studio.secondary_combo.event_generate('<<ComboboxSelected>>')
    studio.composition.set(app.i18n.t('style_suggestions'))
    studio.composition_combo.event_generate('<<ComboboxSelected>>')
    studio.name.set('My named mixture')
    generation=studio._generation;debounce=studio._debounce
    app.lang.set('ko');app.change_language()
    assert studio._choices[studio.secondary.get()]==key
    assert studio._composition_code=='suggestions'
    assert studio.composition.get()==app.i18n.t('style_suggestions')
    assert studio.name.get()=='My named mixture'
    assert studio._generation==generation and studio._debounce==debounce
    assert studio.status.get()==app.i18n.t(studio._status_key,**studio._status_kwargs)


def test_language_change_refreshes_preview_labels_without_reprocessing(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(240,160),'tan').save(photo)
    from personal_color_lab.ui import style_workspace as module
    render=module.render_preview;calls=[]
    def tracked(*args,**kwargs):calls.append(1);return render(*args,**kwargs)
    monkeypatch.setattr(module,'render_preview',tracked)
    studio=app.open_style_workspace();studio.recognition.set(False)
    studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    preview=studio.preview;generation=studio._generation
    studio.compare_btn.invoke();app.update()
    app.lang.set('ko');app.change_language();app.update()
    assert studio.preview is preview and studio._generation==generation
    assert studio._debounce is None and calls==[1]
    assert studio.image_captions['original'].cget('text')==app.i18n.t('style_compare_caption')
    assert studio.status.get()==app.i18n.t('style_preview_ready')


def test_pending_render_keeps_displayed_style_evidence_consistent(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(240,160),'tan').save(photo)
    studio=app.open_style_workspace();studio.recognition.set(False)
    studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    displayed=studio.active_dna
    from personal_color_lab.ui import style_workspace as module
    render=module.render_preview;started=threading.Event();release=threading.Event()
    def held(*args,**kwargs):
        started.set();assert release.wait(5);return render(*args,**kwargs)
    monkeypatch.setattr(module,'render_preview',held)
    studio.secondary.set(list(studio._choices)[2]);studio._secondary_changed()
    _pump(app,started.is_set)
    assert studio.active_dna is displayed
    studio._redraw_images();app.update()
    assert app.i18n.t('style_builtin_notice') in studio.info_label.cget('text')
    assert str(studio.jpeg_btn.cget('state'))=='disabled'
    release.set();_pump(app,lambda:ready(studio))
    assert studio.active_dna['kind']=='hybrid'


def test_export_controls_stay_disabled_after_redraw_translation_and_shortcuts(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';destination=root/'output.jpg'
    Image.new('RGB',(240,160),'tan').save(photo)
    studio=app.open_style_workspace();studio.recognition.set(False)
    studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    from personal_color_lab.ui import style_workspace as module
    export=module.export_jpeg;started=threading.Event();release=threading.Event()
    def held(*args,**kwargs):
        started.set();assert release.wait(5);return export(*args,**kwargs)
    monkeypatch.setattr(module,'export_jpeg',held)
    monkeypatch.setattr(module.filedialog,'asksaveasfilename',lambda **kw:str(destination))
    def unexpected_dialog(**kwargs):raise AssertionError('Export controls must not open another dialog')
    monkeypatch.setattr(module.filedialog,'askopenfilename',unexpected_dialog)
    studio.jpeg_btn.invoke();_pump(app,started.is_set);generation=studio._generation
    studio._redraw_images();app.lang.set('ko');app.change_language();app.update()
    assert all(str(button.cget('state'))=='disabled' for button in studio.recommendation_buttons)
    assert str(studio.name_entry.cget('state'))=='disabled'
    studio._shortcut('open');studio._shortcut('save');studio._shortcut('export')
    studio.choose_photo();studio.save_recipe();studio.import_style();studio.export_recipe()
    assert studio._generation==generation
    release.set();_pump(app,lambda:not studio._busy)
    assert destination.is_file() and studio._status_key=='style_exported'
    assert studio._generation==generation and studio._debounce is None


def test_new_studio_empty_state_and_photo_tiles_reuse_without_model_decode(desktop,monkeypatch):
    from personal_color_lab.ui import style_workspace as module
    app,root=desktop;photo=root/'photo.jpg';Image.fromarray(np.random.default_rng(53).integers(20,230,(200,300,3),dtype='uint8')).save(photo)
    studio=app.open_style_workspace();app.update()
    assert studio.empty_panel.winfo_ismapped() and studio.empty_choose_btn.winfo_ismapped()
    assert str(studio.jpeg_btn.cget('state'))=='disabled'
    calls=[];original=module.build_style_tiles
    def counted(*args,**kwargs):
        calls.append(1);return original(*args,**kwargs)
    monkeypatch.setattr(module,'build_style_tiles',counted)
    studio.recognition.set(False);studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    assert not studio.empty_panel.winfo_ismapped()
    tiles=studio.preview['style_tiles']
    assert len(tiles)==3 and all(button.cget('image') for button in studio.recommendation_buttons)
    studio.strength.set(45);studio._schedule_preview();_pump(app,lambda:ready(studio))
    assert studio.preview['style_tiles'] is tiles and calls==[1]


def test_studio_disclosures_and_direct_wipe_drag_only_change_the_view(desktop,monkeypatch):
    app,root=desktop;photo=root/'photo.jpg';Image.new('RGB',(360,240),'orange').save(photo)
    studio=app.open_style_workspace();studio.recognition.set(False)
    studio.source=photo;studio._schedule_preview();_pump(app,lambda:ready(studio))
    generation=studio._generation;preview=studio.preview
    studio.details_btn.invoke();studio.subject_btn.invoke();app.update()
    assert studio.info_label.winfo_ismapped() and studio.subject_frame.winfo_ismapped()
    studio.compare_btn.invoke();app.update()
    before=studio.wipe.get();widget=studio.image_labels['original']
    widget.event_generate('<Button-1>',x=widget.winfo_width()//3,y=widget.winfo_height()//2)
    _pump(app,lambda:studio._view_after is None)
    assert studio.wipe.get()!=before and studio.preview is preview and studio._generation==generation
    studio.details_btn.invoke();studio.subject_btn.invoke();app.update()
    assert not studio.info_label.winfo_ismapped() and not studio.subject_frame.winfo_ismapped()
