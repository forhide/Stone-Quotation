"""Functional style learning, composition and non-destructive export checks."""
import copy
import hashlib
import json
from pathlib import Path
import socket
import threading

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.style_dna import builtin_styles,identity_dna,validate_dna,dna_from_batch,dna_from_pair,blend_styles,load_style_file
from personal_color_lab.core.style_render import apply_pixels,prepare_style,render_preview,export_jpeg,export_xmp,export_style_json
from personal_color_lab.core.reference_analysis import analyze_reference
from personal_color_lab.core.source_workflow import discover_inputs,analyze_inputs
from personal_color_lab.core.edit_reverse import analyze_pair
from personal_color_lab.core.xmp_analysis import analyze_raw_xmp
from personal_color_lab.core.synthetic_raw import write_test_dng


def photo(tmp_path,name='photo.jpg'):
    rng=np.random.default_rng(314)
    pixels=cv2.GaussianBlur(rng.integers(25,190,(180,280,3),dtype=np.uint8),(5,5),0)
    for n in range(50):
        x,y=rng.integers([5,5],[275,175]);cv2.circle(pixels,(int(x),int(y)),4,tuple(int(v) for v in rng.integers(35,170,3)),-1)
    path=tmp_path/name;Image.fromarray(pixels).save(path,quality=98,subsampling=0)
    return path


@pytest.mark.parametrize('style',builtin_styles(),ids=lambda x:x['name'])
def test_builtin_styles_are_bounded_reproducible_and_zero_strength_is_identity(style):
    pixels=np.random.default_rng(8).integers(0,256,(91,137,3),dtype='uint8')
    effective,_=prepare_style(pixels,style)
    output,box=apply_pixels(pixels,effective,.7)
    assert output.shape==pixels.shape and output.dtype==np.uint8
    assert np.array_equal(apply_pixels(pixels,effective,.7)[0],output)
    assert np.array_equal(apply_pixels(pixels,effective,0)[0],pixels)


def test_neutral_recipe_preserves_every_pixel_without_roundtrip_drift():
    pixels=np.random.default_rng(9).integers(0,256,(100,170,3),dtype='uint8')
    assert np.array_equal(apply_pixels(pixels,identity_dna(),1)[0],pixels)


def test_pair_style_learns_observed_brightening_and_improves_match(tmp_path):
    source=photo(tmp_path);edited=tmp_path/'edit.jpg'
    original=np.array(Image.open(source))
    Image.fromarray(np.clip(original.astype(float)*1.10+7,0,255).astype('uint8')).save(edited,quality=98,subsampling=0)
    payload=analyze_pair(source,edited);assert payload['status']=='ok'
    dna=dna_from_pair(payload,'My edits')
    result=render_preview(source,dna,1)
    goal=np.array(Image.open(edited)).astype(float)
    before=np.mean(abs(result['original'].astype(float)-goal))
    after=np.mean(abs(result['rendered'].astype(float)-goal))
    assert after<before*.6,(before,after)
    assert dna['kind']=='transform' and dna['sample_count']==1


def test_reference_style_adapts_to_new_lighting_without_edit_slider_claims(tmp_path):
    source=photo(tmp_path)
    reference=tmp_path/'reference.jpg'
    pixels=np.array(Image.open(source));Image.fromarray(np.clip(pixels.astype(float)*1.3+[7,3,0],0,255).astype('uint8')).save(reference)
    batch=analyze_inputs(discover_inputs(tmp_path,'reference_jpg')['items'][1:],'reference_jpg')
    # Explicitly select the reference rather than infer an original/edit pair.
    payload=analyze_reference(reference)
    batch={'mode':'reference_jpg','results':[{'status':'ok','payload':payload}]}
    dna=dna_from_batch(batch,'Reference look')
    result=render_preview(source,dna,1)
    assert result['rendered'].mean()>result['original'].mean()
    assert dna['kind']=='reference' and 'reference_content_and_lighting_confounders' in dna['warnings']
    assert dna['sample_count']==1 and dna['confidence']<=.2


def test_recorded_xmp_style_has_rgb_curves_and_monochrome_preview(tmp_path):
    source=write_test_dng(tmp_path/'raw.dng')
    xmp=tmp_path/'raw.xmp'
    xmp.write_text('<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:c="http://ns.adobe.com/camera-raw-settings/1.0/" c:Exposure2012="0.5" c:Temperature="7000" c:ConvertToGrayscale="True"><c:ToneCurvePV2012Red><rdf:Seq><rdf:li>0, 0</rdf:li><rdf:li>128, 150</rdf:li><rdf:li>255, 255</rdf:li></rdf:Seq></c:ToneCurvePV2012Red></rdf:Description>')
    batch=analyze_inputs(discover_inputs(tmp_path,'raw_xmp')['items'],'raw_xmp')
    dna=dna_from_batch(batch,'Recorded controls')
    assert dna['exposure_ev']==.5 and dna['saturation_scale']==0
    assert dna['channel_curves']['red'][16]>.5
    rendered=render_preview(source,dna,1)['rendered'].astype(float)
    assert np.max(np.ptp(rendered,axis=2))<=1


def test_hybrid_preserves_weight_endpoints_and_requires_nonzero_weights():
    first,second=builtin_styles()[:2]
    pixels=np.random.default_rng(7).integers(30,200,(80,120,3),dtype='uint8')
    a=apply_pixels(pixels,prepare_style(pixels,first)[0],.8)[0]
    mixed=blend_styles([first,second],[1,0])
    assert np.array_equal(apply_pixels(pixels,prepare_style(pixels,mixed)[0],.8)[0],a)
    with pytest.raises(ValueError):blend_styles([first,second],[0,0])
    with pytest.raises(ValueError):blend_styles([first],[.3,.7])


def test_composition_only_changes_geometry_after_explicit_choice():
    dna=builtin_styles()[4];pixels=np.full((180,240,3),100,dtype='uint8')
    effective,_=prepare_style(pixels,dna)
    colors,box=apply_pixels(pixels,effective,1,'color_only')
    suggestion,_=apply_pixels(pixels,effective,1,'suggestions')
    cropped,_=apply_pixels(pixels,effective,1,'apply_crop')
    assert box and colors.shape==suggestion.shape==pixels.shape
    assert np.array_equal(colors,suggestion)
    assert cropped.shape[1]/cropped.shape[0]==pytest.approx(2.39,abs=.02)


def test_full_resolution_export_preserves_originals_and_strips_gps_exif(tmp_path,monkeypatch):
    source=photo(tmp_path)
    image=Image.open(source);exif=image.getexif();exif[315]='Private author';exif[34853]={1:'N',2:(37.,1.,1.),3:'E',4:(127.,1.,1.)}
    image.save(source,quality=98,exif=exif)
    before=source.read_bytes();style=builtin_styles()[0]
    monkeypatch.setattr(socket,'socket',lambda *a,**k:(_ for _ in ()).throw(AssertionError('Network access')))
    preview=render_preview(source,style,.6)
    output=tmp_path/'copy.jpg'
    result=export_jpeg(source,output,style,.6,expected_fingerprint=preview['source_fingerprint'])
    assert result['source_unchanged'] and not result['gps_exported']
    with Image.open(output) as image:
        assert image.size==(280,180)
        assert 34853 not in image.getexif() and 315 not in image.getexif()
        assert image.info.get('icc_profile')
    assert source.read_bytes()==before
    with pytest.raises((ValueError,FileExistsError)):export_jpeg(source,source,style)
    previous=output.read_bytes()
    with pytest.raises(FileExistsError):export_jpeg(source,output,style)
    assert output.read_bytes()==previous


def test_xmp_preset_is_parseable_finite_and_never_contains_location_or_crop(tmp_path):
    source=write_test_dng(tmp_path/'source.dng');style=builtin_styles()[4]
    effective,_=prepare_style(np.full((40,60,3),120,dtype='uint8'),style)
    target=tmp_path/'preset.xmp';export_xmp(target,style,effective,.8)
    payload=analyze_raw_xmp(source,target)
    assert payload['status']=='ok' and not payload['invalid_parameters']
    assert len(payload['tone_curves'])==4
    assert 'CropTop' not in payload['parameters'] and 'gps' not in target.read_text().lower()
    assert payload['parameters']['Exposure2012']==0
    assert payload['parameters']['ColorGradeShadowSat']>0
    before=target.read_bytes()
    with pytest.raises(FileExistsError):export_xmp(target,style,effective)
    assert target.read_bytes()==before


@pytest.mark.parametrize('field,value',[
    ('schema_version',True),('schema_version',3),('exposure_ev',float('nan')),
    ('lab_shift',[30,1]),('tone_curve',[.5]*32),('zone_shifts',[]),
    ('reference_target',{'latitude':37}),('recorded_parameters',{'GPSLatitude':37}),
    ('components',[{'weight':1,'dna':{}}]),('name',''),
])
def test_untrusted_style_parameters_fail_cleanly(field,value):
    dna=identity_dna();dna[field]=value
    with pytest.raises(ValueError):validate_dna(dna)


def test_style_file_roundtrip_is_parameters_only_and_size_bounded(tmp_path):
    dna=builtin_styles()[2];path=tmp_path/'look.json';export_style_json(path,dna)
    assert load_style_file(path)==dna
    assert 'original_path' not in path.read_text()
    path.write_text(' '*256001)
    with pytest.raises(ValueError,match='large'):load_style_file(path)


def test_changed_input_after_preview_and_cancelled_export_create_no_output(tmp_path):
    source=photo(tmp_path);style=builtin_styles()[0];preview=render_preview(source,style)
    with source.open('ab') as f:f.write(b'changed')
    target=tmp_path/'new.jpg'
    with pytest.raises(ValueError,match='changed'):export_jpeg(source,target,style,expected_fingerprint=preview['source_fingerprint'])
    assert not target.exists()
    stop=threading.Event();stop.set()
    with pytest.raises(ValueError,match='cancelled'):export_jpeg(source,target,style,cancel_event=stop)
    assert not target.exists()


def test_preview_reuses_verified_source_pixels_and_invalidates_on_change(tmp_path,monkeypatch):
    source=photo(tmp_path);style=builtin_styles()[0];base=render_preview(source,style)
    import personal_color_lab.core.style_render as renderer
    read=renderer.read_photo
    calls=[]
    def track(*args,**kwargs):calls.append(args);return read(*args,**kwargs)
    monkeypatch.setattr(renderer,'read_photo',track)
    rendered=render_preview(source,style,.5,base=base)
    assert not calls and rendered['source_fingerprint']==base['source_fingerprint']
    with source.open('ab') as f:f.write(b'changed')
    render_preview(source,style,.5,base=base)
    assert calls
