# Personal Color Lab V0.5.2

A desktop application for extracting editing settings and photographic color tendencies from **RAW + edited JPG**, **RAW + XMP**, or **finished JPGs alone**. Choose a folder, analyze and save a style, then apply it to a new JPG/RAW with before/after previews, adjustable strength and safe exports. All processing runs locally; original photos remain unchanged.

## Apply and export a style

Click **Apply style** in the sidebar or on an analysis result. Choose a new JPG/RAW, select a learned style or one of 12 bundled profiles, and adjust strength. Optionally mix a second style. The original and styled previews update side by side. Export a new full-resolution JPG, an approximate Lightroom-importable global XMP preset, or a portable style JSON. Save recipes locally to reuse them. Composition defaults to color-only; optional aspect-ratio guides/cropping affect copies only.

Repeated folder analysis reuses valid content-hash results and skips exact duplicates before decoding. Similar photos remain included and are flagged for review. Saved analysis snapshots can be renamed/deleted without changing photos.

Reference photos describe final appearance including lighting; XMP presets cover supported global controls and do not exactly reproduce Adobe rendering. Embedded ONNX models recognize 80 COCO object classes, segment people and detect faces. Object-derived context and learned regional targets adapt style application; optional face protection and mask previews let you review the result. Sky/terrain segmentation and Adobe local-mask export remain future work.

Supported pure monochrome references and original/edited pairs now preserve black-and-white intent when applied to a new photo. Mixed-color or sepia references retain their color. Reanalyze historical paired inputs to add the new monochrome evidence. V0.5.1 also improves cache recovery, cancellation, export staging and workspace state preservation.

V0.5.2 adds photo-based style previews, a larger comparison stage, right-side controls, native-vector sliders/toggles, direct wipe dragging and expandable details. Build/apply entry cards and source steps clarify what to do next. Local processing removes repeated calculations without reducing resolution or model thresholds; [PERFORMANCE.md](PERFORMANCE.md) records measured timings and their limits.

## Choose a folder and continue

1. Click **Choose folder**. The extraction window opens and scans the folder; the subfolder option controls recursive scanning.
2. Select **RAW + JPG**, **RAW + XMP**, or **JPG references**. Check the proposed files before analyzing. A JPG-only folder uses the reference route without asking for an original.
3. In **Review files**, exclude photos you do not want. Use **Choose matching file** for missing or ambiguous RAW companions, including files with different names or folders. Filename matches are suggestions, not proof of a correct pair.
4. Click **Analyze selected files**. Progress identifies the current file. **Cancel** stops at the next supported processing checkpoint and keeps completed results; a failed file does not discard other results.
5. Read the **Style summary** and individual results. Enter a **Style name** and click **Save style**. Reopen it through **Saved styles**, including after restarting the app.


| Input | What is extracted | Meaning of the result |
| --- | --- | --- |
| RAW + edited JPG | Registered tone/color changes, measured tone transfer, approximate exposure and WB/tint tendencies, and a collection summary | Inferred changes relative to the app's fixed RAW development baseline; not recovered Lightroom history |
| RAW + XMP | Supported recorded Adobe Camera Raw global parameters and RGB tone curves, plus parameter summaries | Values actually present in the selected sidecar; missing values remain unknown and Lightroom rendering is not reproduced |
| Finished/reference JPGs | Brightness, contrast, saturation, Lab/chroma, shadow/midtone/highlight color, hue-band support, representative palette, and collection tendencies | Final visible appearance, including the subject, lighting and camera rendering; no original or exact editing history is required |

For JPG collections, each unique file contributes equal weight. Byte-identical duplicates contribute once. The result records dispersion, heuristic consistency, sample limitations and appearance outliers; outliers remain included until you exclude them and analyze again. Supported scene tags come from detected objects; reference-set scene diversity is not evaluated.

**Compare two photos** remains available for original/edited JPEG pairs, without matching filenames or folders. Confirm the labeled previews and direction, then read **Changes at a glance** or **Detailed measurements**. The inspector includes a measured brightness-mapping curve and local saved-analysis lookup. Current-session direct selections are deduplicated and labeled **Chosen by you**.

English is the default UI language; Korean is selectable. The dark graphite/lime interface retains readable point-sized fonts and display scaling. Windows configures DPI awareness before opening Tk; macOS uses native system fonts and the bundled Tk Retina path. Actual native display and monitor-transition validation remains pending; large display scales may need more usable desktop space.

## Install or run from source

For installation without Python, use Windows x64 setup.exe or the macOS Apple Silicon/Intel .pkg. See [INSTALLERS.md](INSTALLERS.md) for requirements, checksums, rebuilding and validation limits.

Source development requires Python 3.11+ with Tkinter, Pillow, NumPy, headless OpenCV and rawpy/LibRaw. On Linux, install the distribution's `python3-tk` package if needed. A desktop display is required for the GUI; no web server, mobile SDK or GPU is needed.

```bash
python -m venv .venv
```

Activate with `source .venv/bin/activate` on macOS/Linux or `.venv\Scripts\Activate.ps1` in Windows PowerShell.

```bash
python -m pip install -r requirements.lock
python run_app.py
```

Dependency installation can use the network. The installed application does not use accounts, APIs, telemetry or uploads. `requirements.lock` pins runtime versions, including rawpy 0.25.1 with LibRaw 0.21.4; `requirements.txt` retains ranges for deliberate updates.

## Development checks

```bash
python -m pip install -r requirements-dev.lock
python -m pytest
```

For the full suite including GUI checks on headless Linux, use a local Xvfb:

```bash
python tools/run_gui_tests.py -q
# If Xvfb is not in PATH:
PERSONAL_COLOR_LAB_XVFB=/path/to/Xvfb python tools/run_gui_tests.py -q
```

The runner downloads nothing and uses an existing display when available. Archive checks need `bsdtar` in PATH or `PERSONAL_COLOR_LAB_BSDTAR`; they are explicitly skipped without it. Tests cover analysis, source preservation, migrations, persistence and desktop flows. [VALIDATION.md](VALIDATION.md) records completed runs and their platform limits; it is the authority for final test counts and artifact verification.

## Local data and upgrades

The default local files are `~/.personal_color_lab/library.db` and `~/.personal_color_lab/settings.json`. Set `PERSONAL_COLOR_LAB_DATA_DIR` to use another directory.

The database stores paths, allowed non-location metadata, derived measurements, source hashes, confidence/provenance and saved analysis snapshots. It does not copy the photo library or persist GPS coordinates. V0.5.2 retains database schema3 introduced in V0.4.0 and preserves schema-0/1/2 rows and settings. App/analysis versions are0.5.2; analysis/profile payloads remain1 and Style DNA is2/engine0.5.0. Legacy0.4.0 DNA is upgraded on read. New analysis profiles require0.5.2; DNA2/engine0.5.0 remains compatible with0.5.0; SQLite remains3. Earlier0.3/0.4/0.5.0/0.5.1 source snapshots remain readable. Older apps cannot open schema 3; back up the data folder before downgrading. Earlier comparison records are retained, but old algorithm results require reanalysis for a current comparison.

## Analysis boundaries

- RAW decoding uses sensor data through rawpy/LibRaw, camera white balance when available, explicit sRGB output and disabled automatic brightness. It does not substitute an embedded JPEG or reproduce Lightroom defaults. Unsupported or corrupt RAW files fail explicitly; supported camera coverage follows LibRaw. The decoder rejects inputs above 120 megapixels.
- Pair registration supports modest crop, resize and rotation. General perspective changes, strong warps and local edits are outside this milestone. Unreliable alignment suppresses tone/color estimates.
- JPEG analysis honors EXIF orientation and valid local ICC-to-sRGB conversion. Untagged input is treated as sRGB. Unreadable profiles produce explicit color uncertainty instead of unverified color measurements.
- XMP parsing accepts a bounded whitelist of global Camera Raw settings and curves. Local masks, unsupported properties and unavailable custom profiles are not reproduced. The RAW/sidecar association must be checked by the user; a filename or file hash cannot prove that the sidecar belongs to the photo. Recorded values do not establish equivalent rendered pixels.
- A warm JPG appearance is not a recovered white-balance value. Lighting, subject color and camera processing can explain apparent tendencies. Reference confidence/consistency and comparison confidence are heuristics, not calibrated probabilities.
- Exact duplicates are excluded before decoding. Similar-image hints remain included for review. Reference adaptation may use supported low/mid/high-key lighting groups; object-derived scene tags and supported region/context targets are available; full semantic scene coverage remains future work.

Style application, embedded object/person/face recognition, supported regional learning, strength/hybrid mixing, built-in profiles and approximate global XMP presets are implemented. Sky/terrain segmentation, precise non-person masks and Adobe local-mask export remain future work. Mobile development is outside the current scope. See [ROADMAP.md](ROADMAP.md) and [TODO.md](TODO.md).
