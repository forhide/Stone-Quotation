"""Measure the final appearance of JPEG references, without inventing edits.

All work is local and bounded to an EXIF-oriented, colour-managed 1024-pixel
preview. Luminance here means rendered sRGB luma (Rec. 709 weights, 0..1), not
scene exposure. Lab uses D65 L*=0..100 and signed a*/b* units; HSV saturation is
0..1. These observations include the subject, lighting and camera rendering.
They cannot recover a RAW conversion, white balance in kelvin or edit sliders.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import math
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np
from PIL import Image

from .alignment import _read_rgb
from .analysis_control import check_cancel
from .color_analysis import _HUE_BANDS
from .edit_reverse import file_fingerprint

ALGORITHM_VERSION = "0.5.2"
ANALYSIS_SCHEMA_VERSION = 1
MAX_DIMENSION = 1024
MAX_PALETTE_COLORS = 5
_LUMA = np.array([0.2126, 0.7152, 0.0722], dtype=np.float64)
_LIMITATIONS = [
    "reference_final_appearance_only",
    "reference_content_and_lighting_confounders",
    "reference_temperature_not_white_balance",
]


def _distribution(values: np.ndarray) -> dict:
    quantiles = np.quantile(values, [0.05, 0.25, 0.5, 0.75, 0.95])
    return {
        "mean": float(np.mean(values)),
        "std": float(np.std(values)),
        "quantiles": dict(zip(("p05", "p25", "p50", "p75", "p95"), map(float, quantiles))),
    }


def _palette(rgb: np.ndarray, weights: np.ndarray | None = None) -> list[dict]:
    """Cluster at most 4096 occupied RGB bins, using deterministic Lab centres.

    Weighted histograms also let an aggregate assign exactly the same total
    weight to each reference, regardless of its dimensions or palette size.
    There is no random initialization, model download or unbounded pixelwise
    clustering. Fractions describe all the supplied pixels, including neutrals.
    """
    rgb = np.asarray(rgb).reshape(-1, 3)
    if not len(rgb):
        return []
    # Reference previews contain bytes. Form one compact bin index rather than
    # three full float64 RGB/weight arrays; aggregate palettes retain fractional
    # weights and non-byte inputs through the same weighted histogram below.
    bins = np.clip(rgb, 0, 255).astype(np.uint16) // 16
    indices = bins[:, 0] * 256 + bins[:, 1] * 16 + bins[:, 2]
    totals = np.bincount(indices, weights=weights, minlength=4096)
    occupied = totals > 0
    mass = totals[occupied]
    colors = np.column_stack([
        np.bincount(indices, weights=rgb[:, channel] if weights is None else weights * rgb[:, channel],
                    minlength=4096)[occupied] / mass
        for channel in range(3)
    ])
    lab = cv2.cvtColor((colors / 255.0).astype(np.float32).reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3)
    centers = [lab[int(np.argmax(mass))].astype(np.float64)]
    distance = np.sum((lab - centers[0]) ** 2, axis=1)
    while len(centers) < min(MAX_PALETTE_COLORS, len(colors)):
        candidate = int(np.argmax(distance * np.sqrt(mass / mass.sum())))
        if distance[candidate] < 10.0**2:
            break
        centers.append(lab[candidate].astype(np.float64))
        distance = np.minimum(distance, np.sum((lab - centers[-1]) ** 2, axis=1))
    centers = np.array(centers)
    previous = None
    for _ in range(12):
        assignments = np.argmin(np.sum((lab[:, None, :] - centers[None, :, :]) ** 2, axis=2), axis=1)
        if previous is not None and np.array_equal(assignments, previous):
            break
        previous = assignments.copy()
        for index in range(len(centers)):
            selected = assignments == index
            if np.any(selected):
                centers[index] = np.average(lab[selected], axis=0, weights=mass[selected])
    palette = []
    for index in range(len(centers)):
        selected = assignments == index
        if not np.any(selected):
            continue
        color = np.clip(np.rint(np.average(colors[selected], axis=0, weights=mass[selected])), 0, 255).astype(int).tolist()
        palette.append({
            "rgb": color,
            "hex": "#{:02X}{:02X}{:02X}".format(*color),
            "fraction": float(mass[selected].sum() / mass.sum()),
        })
    return sorted(palette, key=lambda item: (-item["fraction"], item["hex"]))


def _tendencies(appearance: dict) -> dict:
    brightness = appearance["luminance"]["quantiles"]["p50"]
    contrast = appearance["luminance"]["contrast_span"]
    saturation = appearance["saturation"]["mean"]
    temperature = appearance["lab"]["mean_b"]
    return {
        "brightness": "low" if brightness < 0.35 else "high" if brightness > 0.7 else "mid",
        "contrast": "soft" if contrast < 0.25 else "strong" if contrast > 0.6 else "balanced",
        "saturation": "muted" if saturation < 0.25 else "vivid" if saturation > 0.6 else "balanced",
        "temperature": "warm" if temperature > 5.0 else "cool" if temperature < -5.0 else "neutral",
    }


def _appearance(pixels: np.ndarray, cancel_event=None) -> dict:
    check_cancel(cancel_event)
    rgb = pixels.reshape(-1, 3).astype(np.float32) / 255.0
    lab = cv2.cvtColor(rgb.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3)
    hsv = cv2.cvtColor(rgb.reshape(-1, 1, 3), cv2.COLOR_RGB2HSV).reshape(-1, 3)
    # Three-channel axis reductions create substantial temporary/stride work
    # on large previews. Explicit channel operations preserve every pixel and
    # also let chroma be reused by both its distribution and hue eligibility.
    low = np.minimum(np.minimum(rgb[:, 0], rgb[:, 1]), rgb[:, 2])
    high = np.maximum(np.maximum(rgb[:, 0], rgb[:, 1]), rgb[:, 2])
    chroma = np.sqrt(lab[:, 1] * lab[:, 1] + lab[:, 2] * lab[:, 2])
    check_cancel(cancel_event)
    luma = rgb @ _LUMA
    luminance = _distribution(luma)
    luminance["contrast_span"] = luminance["quantiles"]["p95"] - luminance["quantiles"]["p05"]
    luminance["clipping"] = {
        "black_fraction": float(np.mean(high <= 1.0 / 255)),
        "white_fraction": float(np.mean(low >= 254.0 / 255)),
        "channel_low_fraction": float(np.mean(rgb <= 1.0 / 255)),
        "channel_high_fraction": float(np.mean(rgb >= 254.0 / 255)),
    }
    result = {
        "luminance": luminance,
        "saturation": _distribution(hsv[:, 1]),
        "chroma": _distribution(chroma),
        "lab": {"mean_l": float(lab[:, 0].mean()), "mean_a": float(lab[:, 1].mean()), "mean_b": float(lab[:, 2].mean())},
        "tonal_zones": {},
        "hue_bands": {},
        "palette": _palette(pixels),
    }
    check_cancel(cancel_event)
    for name, selected in (
        ("shadows", lab[:, 0] < 35),
        ("midtones", (lab[:, 0] >= 35) & (lab[:, 0] < 70)),
        ("highlights", lab[:, 0] >= 70),
    ):
        count = int(selected.sum())
        result["tonal_zones"][name] = {
            "support_fraction": float(count / len(rgb)),
            "mean_l": float(lab[selected, 0].mean()) if count else None,
            "mean_a": float(lab[selected, 1].mean()) if count else None,
            "mean_b": float(lab[selected, 2].mean()) if count else None,
        }
    check_cancel(cancel_event)
    # HSV hue has no meaning for black or near-neutral pixels. Do not silently
    # count OpenCV's hue=0 convention as red support for monochrome references.
    chromatic = (hsv[:, 1] >= 0.08) & (hsv[:, 2] >= 0.03) & (chroma >= 2.0)
    hue = hsv[:, 0]
    for name, (lower, upper) in _HUE_BANDS.items():
        inside = ((hue >= lower) | (hue < upper)) if lower > upper else ((hue >= lower) & (hue < upper))
        selected = chromatic & inside
        count = int(selected.sum())
        result["hue_bands"][name] = {
            "support_fraction": float(count / len(rgb)),
            "saturation": float(hsv[selected, 1].mean()) if count else None,
            "lightness": float(lab[selected, 0].mean() / 100.0) if count else None,
        }
    check_cancel(cancel_event)
    result["tendencies"] = _tendencies(result)
    return result


def _perceptual_hash(pixels):
    small = cv2.resize(cv2.cvtColor(pixels, cv2.COLOR_RGB2GRAY), (17, 16), interpolation=cv2.INTER_AREA)
    return np.packbits(small[:, :-1] > small[:, 1:]).tobytes().hex()


def analyze_reference(path: Path, *, expected_fingerprint=None, cancel_event=None) -> dict:
    """Return final JPEG appearance, preserving source bytes and omitting EXIF.

    Broken ICC profiles return explicit uncertainty and no appearance values.
    Unreadable files and files that change during analysis raise; callers can
    count/report these failures while continuing with other references.
    A batch may supply its already-computed content fingerprint; the final
    hash still verifies the entire analysis against that original snapshot.
    """
    check_cancel(cancel_event)
    source = Path(path).expanduser().resolve(strict=True)
    if not source.is_file() or source.suffix.lower() not in {".jpg", ".jpeg"}:
        raise ValueError("Reference analysis requires a JPEG file.")
    if expected_fingerprint is not None and (not isinstance(expected_fingerprint, str)
            or len(expected_fingerprint) != 64 or any(c not in '0123456789abcdef' for c in expected_fingerprint)):
        raise ValueError('Invalid expected source fingerprint.')
    before = file_fingerprint(source) if expected_fingerprint is None else expected_fingerprint
    check_cancel(cancel_event)
    with Image.open(source) as opened:
        if opened.format not in {"JPEG", "MPO"}:
            raise ValueError("Reference analysis requires JPEG image contents.")
    pixels, dimensions, read_warnings = _read_rgb(source, MAX_DIMENSION)
    check_cancel(cancel_event)
    verified = "icc_conversion_failed" not in read_warnings
    payload = {
        "schema_version": ANALYSIS_SCHEMA_VERSION,
        "algorithm_version": ALGORITHM_VERSION,
        "source_type": "reference_jpg",
        "status": "ok" if verified else "color_space_uncertain",
        "original_path": str(source),
        "analyzed_at_utc": datetime.now(timezone.utc).isoformat(),
        "provenance": {
            "perceptual_hash": _perceptual_hash(pixels),
            "input_fingerprints": {"original": before},
            "originals_modified": False,
            "evidence": "final_jpeg_appearance",
            "exact_xmp_parameters": False,
            "inferred_edit_transform": False,
            "analysis_max_dimension": MAX_DIMENSION,
            "coordinate_space": "exif_oriented_pixels",
            "original_dimensions": list(dimensions),
            "analysis_dimensions": [int(pixels.shape[1]), int(pixels.shape[0])],
            "pixel_count": int(pixels.shape[0] * pixels.shape[1]),
            "color_space": "srgb_assumed_or_profile_converted" if verified else "unverified_profile",
            "luminance_space": "normalized_srgb_luma",
        },
        "appearance": (_appearance(pixels, cancel_event=cancel_event) if cancel_event is not None
                       else _appearance(pixels)) if verified else {},
        "confidence": float(0.9 * min(1.0, pixels.shape[0] * pixels.shape[1] / 256.0)) if verified else 0.0,
        "confidence_scope": "rendered_appearance_measurement",
        "warnings": list(_LIMITATIONS) + read_warnings,
    }
    if verified:
        from .scene_analysis import analyze_evidence
        check_cancel(cancel_event)
        payload['semantic']=(analyze_evidence(pixels, cancel_event=cancel_event) if cancel_event is not None
                             else analyze_evidence(pixels))
        if payload['semantic']['status']!='ok':payload['warnings'].append('object_model_unavailable')
    if not verified:
        payload["warnings"].append("color_space_uncertain")
    check_cancel(cancel_event)
    if file_fingerprint(source) != before:
        raise ValueError("Input image changed during analysis; retry with stable files.")
    json.dumps(payload, allow_nan=False)
    check_cancel(cancel_event)
    return payload


def _numeric_medians(values: list) -> tuple[object, object]:
    """Per-image medians and median absolute deviations, ignoring absent zones."""
    first = next((value for value in values if value is not None), None)
    if isinstance(first, dict):
        merged, dispersion = {}, {}
        for key in first:
            if key in {"palette", "tendencies"}:
                continue
            merged[key], dispersion[key] = _numeric_medians([value.get(key) if isinstance(value, dict) else None for value in values])
        return merged, dispersion
    numbers = [float(value) for value in values if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)]
    if not numbers:
        return None, None
    median = float(np.median(numbers))
    return median, float(np.median(np.abs(np.asarray(numbers) - median)))


def _features(appearance: dict) -> np.ndarray:
    return np.array([
        appearance["luminance"]["quantiles"]["p50"],
        appearance["luminance"]["contrast_span"],
        appearance["saturation"]["mean"],
        appearance["lab"]["mean_a"],
        appearance["lab"]["mean_b"],
    ], dtype=np.float64)


def _number(value: object, lower: float, upper: float) -> bool:
    return (
        isinstance(value, (int, float)) and not isinstance(value, bool)
        and math.isfinite(value) and lower <= value <= upper
    )


def _valid_distribution(distribution: dict, upper: float) -> bool:
    if not _number(distribution["mean"], 0, upper) or not _number(distribution["std"], 0, upper):
        return False
    quantiles = [distribution["quantiles"][key] for key in ("p05", "p25", "p50", "p75", "p95")]
    return all(_number(value, 0, upper) for value in quantiles) and quantiles == sorted(quantiles)


def _valid_appearance(appearance: dict) -> bool:
    """Reject damaged persisted records before computing per-image medians.

    Numeric strings and missing measurements must not silently become missing
    values in the aggregate. Actual unsupported tonal zones use explicit None.
    """
    if not all(_valid_distribution(appearance[key], upper) for key, upper in
               (("luminance", 1), ("saturation", 1), ("chroma", 182))):
        return False
    if not _number(appearance["luminance"]["contrast_span"], 0, 1):
        return False
    if not all(_number(appearance["luminance"]["clipping"][key], 0, 1) for key in
               ("black_fraction", "white_fraction", "channel_low_fraction", "channel_high_fraction")):
        return False
    if not all(_number(appearance["lab"][key], lower, upper) for key, lower, upper in
               (("mean_l", 0, 100), ("mean_a", -128, 128), ("mean_b", -128, 128))):
        return False
    supports = []
    for name in ("shadows", "midtones", "highlights"):
        zone = appearance["tonal_zones"][name]
        support = zone["support_fraction"]
        if not _number(support, 0, 1):
            return False
        supports.append(support)
        for key, lower, upper in (("mean_l", 0, 100), ("mean_a", -128, 128), ("mean_b", -128, 128)):
            if (support == 0 and zone[key] is not None) or (support > 0 and not _number(zone[key], lower, upper)):
                return False
    if not math.isclose(sum(supports), 1, rel_tol=1e-5, abs_tol=1e-5):
        return False
    hue_support = 0.0
    for name in _HUE_BANDS:
        band = appearance["hue_bands"][name]
        support = band["support_fraction"]
        if not _number(support, 0, 1):
            return False
        hue_support += support
        for key in ("saturation", "lightness"):
            if (support == 0 and band[key] is not None) or (support > 0 and not _number(band[key], 0, 1)):
                return False
    return hue_support <= 1 + 1e-5


def _valid_reference(payload: object) -> bool:
    if not isinstance(payload, dict) or payload.get("status") != "ok" or payload.get("source_type") != "reference_jpg":
        return False
    if payload.get("algorithm_version") not in {"0.3.0", "0.4.0", "0.5.0", "0.5.1", ALGORITHM_VERSION} or payload.get("schema_version") != ANALYSIS_SCHEMA_VERSION:
        return False
    try:
        fingerprint = payload["provenance"]["input_fingerprints"]["original"]
        if not isinstance(fingerprint, str) or len(fingerprint) != 64 or any(c not in "0123456789abcdef" for c in fingerprint):
            return False
        if not isinstance(payload["original_path"], str) or not payload["original_path"]:
            return False
        appearance = payload["appearance"]
        if not _valid_appearance(appearance):
            return False
        palette = appearance["palette"]
        if not palette or len(palette) > MAX_PALETTE_COLORS:
            return False
        for color in palette:
            if len(color["rgb"]) != 3 or any(not isinstance(v, (int, float)) or isinstance(v, bool) or not 0 <= v <= 255 for v in color["rgb"]):
                return False
            if not isinstance(color["fraction"], (int, float)) or isinstance(color["fraction"], bool) or not 0 < color["fraction"] <= 1:
                return False
        if not math.isclose(sum(color["fraction"] for color in palette), 1.0, rel_tol=1e-5, abs_tol=1e-5):
            return False
        json.dumps(appearance, allow_nan=False)
    except (KeyError, TypeError, ValueError, OverflowError):
        return False
    return True


def _similar_references(valid):
    """Bounded candidate search; similar scenes are flagged, never removed."""
    buckets,groups,group_of={},[],{}
    for index,(_,payload) in enumerate(valid):
        fingerprint=payload.get('provenance',{}).get('perceptual_hash')
        if not isinstance(fingerprint,str) or len(fingerprint)!=64:
            continue
        try:bits=int(fingerprint,16)
        except ValueError:continue
        keys=[(i,fingerprint[i*4:i*4+4]) for i in range(16)]
        candidates=set()
        for key in keys:candidates.update(buckets.get(key,[]))
        for other in sorted(candidates,reverse=True)[:128]:
            previous=valid[other][1]
            if (bits^int(previous['provenance']['perceptual_hash'],16)).bit_count()>10:
                continue
            a,b=payload['appearance'],previous['appearance']
            if abs(a['luminance']['mean']-b['luminance']['mean'])>.05 or abs(a['saturation']['mean']-b['saturation']['mean'])>.08 or math.hypot(a['lab']['mean_a']-b['lab']['mean_a'],a['lab']['mean_b']-b['lab']['mean_b'])>6:
                continue
            group=group_of.get(other)
            if group is None:
                group=len(groups);groups.append([other]);group_of[other]=group
            groups[group].append(index);group_of[index]=group
            break
        for key in keys:
            bucket=buckets.setdefault(key,[])
            bucket.append(index)
            if len(bucket)>128:del bucket[0]
    return [{'paths':[valid[i][1]['original_path'] for i in group[:20]],'count':len(group)} for group in groups]


def aggregate_references(payloads: Iterable[dict]) -> dict:
    """Build equal-image-weighted final appearance DNA with explicit coverage.

    ``input_count = sample_count + duplicate_count + excluded_count``. SHA-256
    byte duplicates contribute once. Unknown, failed, unsupported-version and
    colour-uncertain records are excluded; outliers remain included and are
    flagged only with at least five unique valid references. No scene labels or
    recovered edit values are fabricated. An empty valid set has status empty.
    """
    valid, fingerprints = [], set()
    input_count = duplicate_count = excluded_count = 0
    for input_index, payload in enumerate(payloads):
        input_count += 1
        if not _valid_reference(payload):
            excluded_count += 1
            continue
        fingerprint = payload["provenance"]["input_fingerprints"]["original"]
        if fingerprint in fingerprints:
            duplicate_count += 1
            continue
        fingerprints.add(fingerprint)
        valid.append((input_index, payload))
    count = len(valid)
    warnings = list(_LIMITATIONS)
    if count < 5:
        warnings.append("reference_low_coverage")
    if count == 1:
        warnings.append("reference_single_image")
    if duplicate_count:
        warnings.append("reference_duplicates_ignored")
    if excluded_count:
        warnings.append("reference_invalid_or_uncertain_excluded")
    result = {
        "schema_version": ANALYSIS_SCHEMA_VERSION,
        "algorithm_version": ALGORITHM_VERSION,
        "source_type": "reference_jpg",
        "status": "ok" if count else "empty",
        "input_count": input_count,
        "sample_count": count,
        "duplicate_count": duplicate_count,
        "excluded_count": excluded_count,
        "appearance": {},
        "dispersion": {},
        "palette": [],
        "tendencies": {},
        "consistency": {"score": None, "level": "insufficient", "metric": "robust_appearance_agreement"},
        "confidence": 0.0,
        "confidence_scope": "reference_appearance_agreement_heuristic",
        "outliers": [],
        "similar_groups": [],
        "warnings": warnings,
        "provenance": {
            "evidence": "final_jpeg_appearance",
            "aggregation": "equal_image_weighted_medians",
            "dispersion": "median_absolute_deviation",
            "exact_xmp_parameters": False,
            "inferred_edit_transform": False,
            "originals_modified": False,
            "scene_coverage_assessed": False,
            "input_fingerprints": sorted(fingerprints),
        },
    }
    if not count:
        result["warnings"].append("reference_no_usable_images")
        return result
    result['similar_groups']=_similar_references(valid)
    if result['similar_groups']:
        result['warnings'].append('reference_similar_scenes_review')
    appearances = [payload["appearance"] for _, payload in valid]
    result["appearance"], result["dispersion"] = _numeric_medians(appearances)
    palette_colors, palette_weights = [], []
    for appearance in appearances:
        for color in appearance["palette"]:
            palette_colors.append(color["rgb"])
            palette_weights.append(color["fraction"] / count)
    result["palette"] = _palette(np.array(palette_colors), np.array(palette_weights))
    result["tendencies"] = _tendencies(result["appearance"])
    result["appearance"]["palette"] = result["palette"]
    result["appearance"]["tendencies"] = result["tendencies"]
    values = np.array([_features(appearance) for appearance in appearances])
    centre = np.median(values, axis=0)
    deviations = np.abs(values - centre)
    mad = np.median(deviations, axis=0)
    # These scales express visible appearance variation, not statistical
    # confidence or proof of common editing intent. One image has no agreement
    # evidence even though its measured appearance remains a usable reference.
    scales = np.array([0.20, 0.25, 0.25, 12.0, 12.0])
    if count >= 2:
        score = float(np.mean(1.0 / (1.0 + mad / scales)))
        result["consistency"].update(score=score, level="high" if score >= 0.8 else "moderate" if score >= 0.55 else "low")
        result["confidence"] = float(min(0.8, count / (count + 4.0)) * score)
    else:
        result["confidence"] = 0.2
    if count >= 5:
        robust_scale = np.maximum(1.4826 * mad, [0.06, 0.08, 0.08, 8.0, 8.0])
        distances = deviations / robust_scale
        for (input_index, payload), distance in zip(valid, distances):
            score = float(np.max(distance))
            if score >= 6.0 or (score >= 4.0 and np.count_nonzero(distance >= 3.0) >= 2):
                result["outliers"].append({
                    "input_index": input_index,
                    "original_path": payload["original_path"],
                    "fingerprint": payload["provenance"]["input_fingerprints"]["original"],
                    "score": score,
                })
        if result["outliers"]:
            result["warnings"].append("reference_outliers_detected")
    json.dumps(result, allow_nan=False)
    return result
