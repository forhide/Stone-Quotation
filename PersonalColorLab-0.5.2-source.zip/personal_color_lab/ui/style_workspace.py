"""Apply source/built-in/hybrid styles with previews and explicit safe exports."""
import base64
import copy
from io import BytesIO
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import filedialog,ttk

from PIL import Image,ImageDraw
import cv2
import numpy as np
from ..core.style_regions import style_distances,recipes_for_scene

from ..core.constants import DB_FILENAME,RAW_EXTENSIONS,app_data_dir
from ..core.database import LibraryDB
from ..core.style_dna import builtin_styles,dna_from_batch,blend_styles,load_style_file,validate_dna
from ..core.style_render import render_preview,export_jpeg,export_xmp,export_style_json
from .display import ui_pixels
from .theme import COLORS as C
from .studio_controls import StudioSlider,StudioToggle
from .style_tiles import build_style_tiles


def _job(events,generation,kind,request,cancel_event):
    try:
        if kind=='preview':
            result=render_preview(request['source'],request['dna'],request['strength'],request['composition'],cancel_event,request.get('base'),request.get('recognition',True),request.get('object_strength',.7),request.get('protect_faces',True))
            styles=request.get('styles')
            if styles:
                keys=style_distances(result['measurement'],styles,result['scene']['report'] if result.get('scene') else None)[:3]
                previous=(request.get('base') or {}).get('style_tiles')
                signature=[(key,styles[key]) for key,_,_ in keys]
                if previous and result['source_fingerprint']==(request.get('base') or {}).get('source_fingerprint') and result.get('recognition')==(request.get('base') or {}).get('recognition') and signature==(request.get('base') or {}).get('style_tile_signature'):
                    result['style_tiles']=previous
                else:result['style_tiles']=build_style_tiles(result,styles,cancel_event)
                result['style_tile_signature']=signature
        elif kind=='jpeg':
            result=export_jpeg(request['source'],request['destination'],request['dna'],request['strength'],request['composition'],cancel_event,request['fingerprint'],request.get('recognition',True),request.get('object_strength',.7),request.get('protect_faces',True))
        else:
            export_xmp(request['destination'],request['dna'],request['effective'],request['strength'],cancel_event=cancel_event)
            result={'path':str(request['destination'])}
        events.put(('result',generation,kind,result))
    except Exception as exc:
        events.put(('error',generation,kind,str(exc)))
    finally:
        events.put(('finished',generation,kind))


class StyleWorkspace(tk.Toplevel):
    def __init__(self,parent,initial_dna=None):
        super().__init__(parent)
        self.i18n=parent.i18n
        self._closed=False;self._busy=False;self._job_kind=None
        self._events=queue.Queue();self._cancel=threading.Event();self._threads=[]
        self._generation=0;self._pending=False;self._debounce=None;self._resize_after=None;self._view_after=None
        self._composition_code='color_only'
        self.source=None;self.preview=None;self.active_dna=None;self._render_dna=None;self._base_preview=None
        self._wide_compare=False;self.wipe=tk.DoubleVar(value=50)
        self._styles={};self._choices={};self._photo_names=[]
        self._labels=[];self._buttons=[]
        self.recognition=tk.BooleanVar(value=True);self.protect_faces=tk.BooleanVar(value=True)
        self.show_regions=tk.BooleanVar(value=False);self.object_strength=tk.DoubleVar(value=70)
        self._advanced_open=False;self._details_open=False;self._subject_open=False;self._recommendations=[]
        self.primary=tk.StringVar();self.secondary=tk.StringVar()
        self.strength=tk.DoubleVar(value=70);self.mix=tk.DoubleVar(value=30)
        self.composition=tk.StringVar();self.name=tk.StringVar();self.status=tk.StringVar()
        dp=lambda x:ui_pixels(self,x)
        self.geometry(f'{dp(1220)}x{dp(880)}');self.minsize(dp(1080),dp(780))
        self.configure(background=C['bg']);self.protocol('WM_DELETE_WINDOW',self.close)
        self.transient(parent)
        self._build();self._load_styles(initial_dna);self.translate()
        self.bind('<Configure>',self._fit_layout)
        self.bind('<Control-o>',lambda e:self._shortcut('open'))
        self.bind('<Control-s>',lambda e:self._shortcut('save'))
        self.bind('<Control-e>',lambda e:self._shortcut('export'))
        if str(self.tk.call('tk','windowingsystem'))=='aqua':
            self.bind('<Command-o>',lambda e:self._shortcut('open'))
            self.bind('<Command-s>',lambda e:self._shortcut('save'))
            self.bind('<Command-e>',lambda e:self._shortcut('export'))
        self._poll_id=self.after(60,self._poll)
        self._raise_after=self.after(60,self.lift)
        self._set_status('style_choose_prompt')

    def _label(self,parent,key,style='Muted.TLabel'):
        label=ttk.Label(parent,style=style,text=self.i18n.t(key))
        self._labels.append((label,key));return label

    def _button(self,parent,key,command,primary=False):
        button=ttk.Button(parent,text=self.i18n.t(key),command=command,style='Primary.TButton' if primary else 'Secondary.TButton')
        self._buttons.append((button,key));return button

    def _build(self):
        dp=lambda x:ui_pixels(self,x)
        self.columnconfigure(0,weight=1);self.rowconfigure(1,weight=1)
        top=ttk.Frame(self,style='Lab.TFrame',padding=(dp(24),dp(18),dp(24),dp(14)))
        top.grid(row=0,column=0,sticky='ew');top.columnconfigure(0,weight=1)
        self._label(top,'style_workspace_kicker','Kicker.TLabel').grid(row=0,column=0,sticky='w')
        self._label(top,'style_workspace_hint','Title.TLabel').grid(row=1,column=0,sticky='w',pady=(dp(5),0))
        self.file_label=ttk.Label(top,style='Muted.TLabel',font='LabSmall')
        self.file_label.grid(row=2,column=0,sticky='w',pady=(dp(5),0))
        self.choose_btn=self._button(top,'style_choose_photo',self.choose_photo)
        self.choose_btn.grid(row=0,column=1,rowspan=3,sticky='e')
        body=tk.Frame(self,background=C['bg']);body.grid(row=1,column=0,sticky='nsew',padx=dp(24))
        body.columnconfigure(0,weight=1);body.rowconfigure(0,weight=1)

        stage=ttk.Frame(body,style='Lab.TFrame');stage.grid(row=0,column=0,sticky='nsew',padx=(0,dp(18)))
        stage.columnconfigure(0,weight=1);stage.rowconfigure(2,weight=1)
        toolbar=ttk.Frame(stage,style='Lab.TFrame');toolbar.grid(row=0,column=0,sticky='ew',pady=(0,dp(10)))
        toolbar.columnconfigure(1,weight=1)
        self._label(toolbar,'style_stage','Muted.TLabel').grid(row=0,column=0,sticky='w')
        self.scene_label=ttk.Label(toolbar,style='Muted.TLabel',font='LabSmall',anchor='e')
        self.scene_label.grid(row=0,column=1,sticky='e',padx=dp(10))
        self.compare_btn=self._button(toolbar,'style_wide_compare',self.toggle_compare)
        self.compare_btn.configure(style='Compact.TButton')
        self.compare_btn.grid(row=0,column=2,sticky='e')
        self.wipe_slider=StudioSlider(stage,from_=0,to=100,variable=self.wipe,command=self._queue_redraw,background=C['bg'])
        self.wipe_slider.grid(row=1,column=0,sticky='ew',pady=(0,dp(8)));self.wipe_slider.grid_remove()
        previews=self.preview_stage=tk.Frame(stage,background=C['inset'],highlightbackground=C['border'],highlightthickness=dp(1))
        previews.grid(row=2,column=0,sticky='nsew');previews.rowconfigure(1,weight=1)
        self.image_frames={};self.image_captions={};self.image_labels={}
        for col,key in enumerate(('original','styled')):
            previews.columnconfigure(col,weight=1,uniform='images')
            caption=tk.Label(previews,font='LabSmall',foreground=C['muted'],background=C['inset'],anchor='w')
            caption.grid(row=0,column=col,sticky='ew',padx=dp(14),pady=(dp(12),dp(8)))
            self._labels.append((caption,'style_'+key));self.image_captions[key]=caption
            frame=tk.Frame(previews,background=C['inset']);self.image_frames[key]=frame
            frame.grid(row=1,column=col,sticky='nsew',padx=(dp(8),dp(4)) if col==0 else (dp(4),dp(8)),pady=(0,dp(8)))
            frame.columnconfigure(0,weight=1);frame.rowconfigure(0,weight=1)
            label=tk.Label(frame,background=C['inset'],foreground=C['subtle'],font='LabBody')
            label.grid(row=0,column=0,sticky='nsew');self.image_labels[key]=label
            if key=='original':
                label.bind('<Button-1>',self._drag_compare);label.bind('<B1-Motion>',self._drag_compare)
        self.empty_panel=tk.Frame(previews,background=C['inset'])
        symbol=tk.Canvas(self.empty_panel,width=dp(62),height=dp(62),background=C['inset'],highlightthickness=0)
        symbol.pack(pady=(0,dp(17)))
        symbol.create_oval(dp(5),dp(5),dp(57),dp(57),outline=C['border'],width=dp(2))
        symbol.create_oval(dp(19),dp(19),dp(43),dp(43),outline=C['accent'],width=dp(2))
        symbol.create_line(dp(44),dp(12),dp(50),dp(18),fill=C['accent'],width=dp(2))
        for key,font,color in (('style_empty_heading','LabHeading','text'),('style_empty_help','LabBody','muted')):
            label=tk.Label(self.empty_panel,font=font,foreground=C[color],background=C['inset'],wraplength=dp(360),justify='center')
            label.pack(pady=(0,dp(10)));self._labels.append((label,key))
        self.empty_choose_btn=self._button(self.empty_panel,'style_choose_photo',self.choose_photo,True)
        self.empty_choose_btn.pack(pady=(dp(7),0))
        self.empty_panel.place(relx=.5,rely=.46,anchor='center')
        detailsbar=ttk.Frame(stage,style='Lab.TFrame');detailsbar.grid(row=3,column=0,sticky='ew',pady=(dp(10),0));detailsbar.columnconfigure(0,weight=1)
        self.xmp_notice=ttk.Label(detailsbar,style='Muted.TLabel',font='LabSmall',justify='left',wraplength=dp(480))
        self.xmp_notice.grid(row=0,column=0,sticky='w')
        self.details_btn=self._button(detailsbar,'style_details_show',self.toggle_details)
        self.details_btn.configure(style='Link.TButton');self.details_btn.grid(row=0,column=1,sticky='e',padx=(dp(10),0))
        self.info_label=ttk.Label(stage,style='Muted.TLabel',font='LabSmall',wraplength=dp(650),justify='left')
        self.info_label.grid(row=4,column=0,sticky='ew',pady=(dp(8),0));self.info_label.grid_remove()

        rail=tk.Frame(body,background=C['surface'],width=dp(306),highlightbackground=C['border'],highlightthickness=dp(1))
        rail.grid(row=0,column=1,sticky='ns');rail.grid_propagate(False)
        rail.rowconfigure(0,weight=1);rail.columnconfigure(0,weight=1)
        self.settings_canvas=tk.Canvas(rail,background=C['surface'],highlightthickness=0,width=dp(292))
        self.settings_canvas.grid(row=0,column=0,sticky='nsew')
        self.settings_scroll=ttk.Scrollbar(rail,orient='vertical',command=self.settings_canvas.yview,style='Lab.Vertical.TScrollbar')
        self.settings_scroll.grid(row=0,column=1,sticky='ns');self.settings_canvas.configure(yscrollcommand=self.settings_scroll.set)
        controls=ttk.Frame(self.settings_canvas,style='Studio.TFrame',padding=dp(18))
        self._settings_window=self.settings_canvas.create_window((0,0),window=controls,anchor='nw');controls.columnconfigure(0,weight=1)
        controls.bind('<Configure>',lambda e:self.settings_canvas.configure(scrollregion=self.settings_canvas.bbox('all')) if not self._closed else None)
        self.settings_canvas.bind('<Configure>',lambda e:self.settings_canvas.itemconfigure(self._settings_window,width=e.width) if not self._closed else None)
        self._label(controls,'style_adjustments','StudioHeading.TLabel').grid(row=0,column=0,sticky='w')
        self.primary_combo=ttk.Combobox(controls,textvariable=self.primary,state='readonly',style='Lab.TCombobox',width=18)
        self.primary_combo.grid(row=1,column=0,sticky='ew',pady=(dp(13),dp(18)));self.primary_combo.bind('<<ComboboxSelected>>',self._selection_changed)
        line=ttk.Frame(controls,style='Studio.TFrame');line.grid(row=2,column=0,sticky='ew');line.columnconfigure(0,weight=1)
        self._label(line,'style_strength','Studio.TLabel').grid(row=0,column=0,sticky='w')
        self.strength_label=ttk.Label(line,style='Studio.TLabel',width=5);self.strength_label.grid(row=0,column=1,sticky='e')
        self.strength_slider=StudioSlider(controls,from_=0,to=100,variable=self.strength,command=self._schedule_preview)
        self.strength_slider.grid(row=3,column=0,sticky='ew',pady=(dp(4),dp(14)))
        ttk.Separator(controls).grid(row=4,column=0,sticky='ew',pady=(0,dp(16)))
        self._label(controls,'style_discovery','StudioHeading.TLabel').grid(row=5,column=0,sticky='w')
        self.recommendation_buttons=[]
        for index in range(3):
            button=ttk.Button(controls,style='Compact.TButton',padding=(dp(8),dp(5)),command=lambda i=index:self.use_recommendation(i))
            button.grid(row=6+index,column=0,sticky='ew',pady=(dp(7),0));self.recommendation_buttons.append(button)
        hint=self._label(controls,'style_recommendation_hint','Studio.TLabel');hint.configure(font='LabSmall',wraplength=dp(246))
        hint.grid(row=9,column=0,sticky='ew',pady=(dp(8),dp(17)))
        ttk.Separator(controls).grid(row=10,column=0,sticky='ew',pady=(0,dp(16)))
        self.subject_btn=self._button(controls,'style_subject_adjustments',self.toggle_subject)
        self.subject_btn.configure(style='Compact.TButton');self.subject_btn.grid(row=11,column=0,sticky='ew')
        self.subject_frame=ttk.Frame(controls,style='Studio.TFrame');self.subject_frame.grid(row=12,column=0,sticky='ew',pady=(dp(10),0));self.subject_frame.columnconfigure(0,weight=1)
        subject=self.subject_frame
        self.recognition_chk=StudioToggle(subject,variable=self.recognition,command=self._schedule_preview,style='Lab.TCheckbutton')
        self.recognition_chk.grid(row=0,column=0,sticky='ew');self._labels.append((self.recognition_chk,'style_recognition'))
        self.faces_chk=StudioToggle(subject,variable=self.protect_faces,command=self._schedule_preview,style='Lab.TCheckbutton')
        self.faces_chk.grid(row=1,column=0,sticky='ew',pady=dp(8));self._labels.append((self.faces_chk,'style_face_protection'))
        self.overlay_chk=StudioToggle(subject,variable=self.show_regions,command=self._redraw_images,style='Lab.TCheckbutton')
        self.overlay_chk.grid(row=2,column=0,sticky='ew',pady=(0,dp(10)));self._labels.append((self.overlay_chk,'style_show_regions'))
        self.object_heading=self._label(subject,'style_object_strength','Studio.TLabel');self.object_heading.configure(font='LabSmall',wraplength=dp(240))
        self.object_heading.grid(row=3,column=0,sticky='w')
        self.object_slider=StudioSlider(subject,from_=0,to=100,variable=self.object_strength,command=self._schedule_preview)
        self.object_slider.grid(row=4,column=0,sticky='ew',pady=(dp(3),dp(16)))
        self.subject_frame.grid_remove()
        ttk.Separator(controls).grid(row=17,column=0,sticky='ew',pady=(0,dp(14)))
        self.advanced_btn=self._button(controls,'style_advanced',self.toggle_advanced);self.advanced_btn.configure(style='Compact.TButton')
        self.advanced_btn.grid(row=18,column=0,sticky='ew')
        self.advanced_frame=ttk.Frame(controls,style='Studio.TFrame');self.advanced_frame.grid(row=19,column=0,sticky='ew',pady=(dp(15),0))
        advanced=self.advanced_frame;advanced.columnconfigure(0,weight=1)
        self._label(advanced,'style_secondary','Studio.TLabel').grid(row=0,column=0,sticky='w')
        self.secondary_combo=ttk.Combobox(advanced,textvariable=self.secondary,state='readonly',style='Lab.TCombobox',width=18)
        self.secondary_combo.grid(row=1,column=0,sticky='ew',pady=(dp(6),dp(12)));self.secondary_combo.bind('<<ComboboxSelected>>',self._secondary_changed)
        line=ttk.Frame(advanced,style='Studio.TFrame');line.grid(row=2,column=0,sticky='ew');line.columnconfigure(0,weight=1)
        self._label(line,'style_mix','Studio.TLabel').grid(row=0,column=0,sticky='w')
        self.mix_label=ttk.Label(line,style='Studio.TLabel',width=5);self.mix_label.grid(row=0,column=1,sticky='e')
        self.mix_slider=StudioSlider(advanced,from_=0,to=100,variable=self.mix,command=self._schedule_preview)
        self.mix_slider.grid(row=3,column=0,sticky='ew',pady=(dp(4),dp(14)))
        self._label(advanced,'style_composition','Studio.TLabel').grid(row=4,column=0,sticky='w')
        self.composition_combo=ttk.Combobox(advanced,textvariable=self.composition,state='readonly',style='Lab.TCombobox',width=18)
        self.composition_combo.grid(row=5,column=0,sticky='ew',pady=(dp(6),dp(12)));self.composition_combo.bind('<<ComboboxSelected>>',self._composition_changed)
        self.import_btn=self._button(advanced,'style_import',self.import_style);self.import_btn.configure(style='Compact.TButton');self.import_btn.grid(row=6,column=0,sticky='ew')
        self.advanced_frame.grid_remove()
        self.reset_btn=self._button(controls,'style_reset',self.reset_controls);self.reset_btn.configure(style='Quiet.TButton',padding=(dp(8),dp(8)))
        self.reset_btn.grid(row=20,column=0,sticky='ew',pady=(dp(8),0))
        self._bind_settings_scroll(controls)

        footer=ttk.Frame(self,style='Lab.TFrame',padding=(dp(24),dp(16)));footer.grid(row=2,column=0,sticky='ew');footer.columnconfigure(1,weight=1)
        ttk.Separator(footer).grid(row=0,column=0,columnspan=4,sticky='ew',pady=(0,dp(12)))
        self._label(footer,'style_save_heading','Muted.TLabel').grid(row=1,column=0,sticky='w',padx=(0,dp(12)))
        self.name_entry=ttk.Entry(footer,textvariable=self.name,style='Lab.TEntry');self.name_entry.grid(row=1,column=1,sticky='ew')
        self.save_btn=self._button(footer,'style_save_short',self.save_recipe);self.save_btn.grid(row=1,column=2,padx=dp(8))
        self.json_btn=self._button(footer,'style_json_short',self.export_recipe);self.json_btn.grid(row=1,column=3)
        self.status_label=ttk.Label(footer,textvariable=self.status,style='Muted.TLabel',font='LabSmall',wraplength=dp(620))
        self.status_label.grid(row=2,column=0,columnspan=2,sticky='w',pady=(dp(10),0))
        self.jpeg_btn=self._button(footer,'style_jpeg_short',lambda:self.export('jpeg'),True);self.jpeg_btn.grid(row=2,column=2,padx=dp(8),pady=(dp(10),0))
        self.xmp_btn=self._button(footer,'style_xmp_export_short',lambda:self.export('xmp'));self.xmp_btn.grid(row=2,column=3,pady=(dp(10),0))

    def toggle_subject(self):
        self._subject_open=not self._subject_open
        self.subject_btn.configure(text=self.i18n.t('style_subject_adjustments_open' if self._subject_open else 'style_subject_adjustments'))
        if self._subject_open:self.subject_frame.grid()
        else:self.subject_frame.grid_remove()

    def toggle_details(self):
        self._details_open=not self._details_open
        if self._details_open:self.info_label.grid()
        else:self.info_label.grid_remove()
        self.details_btn.configure(text=self.i18n.t('style_details_hide' if self._details_open else 'style_details_show'))

    def _bind_settings_scroll(self,controls):
        # A canvas binding alone does not receive wheel events over its child
        # controls. Scope a bindtag to this rail so unrelated windows and photo
        # previews keep their own gestures, and combobox wheels do not select a
        # different style while the user is trying to scroll.
        self._settings_bindtag=f'pcl-style-settings-{id(self)}'
        self.bind_class(self._settings_bindtag,'<MouseWheel>',self._scroll_settings)
        self.bind_class(self._settings_bindtag,'<Button-4>',self._scroll_settings)
        self.bind_class(self._settings_bindtag,'<Button-5>',self._scroll_settings)
        self.bind_class(self._settings_bindtag,'<FocusIn>',self._reveal_setting)
        pending=[self.settings_canvas]
        while pending:
            widget=pending.pop()
            widget.bindtags((self._settings_bindtag,*widget.bindtags()))
            pending.extend(widget.winfo_children())

    def _scroll_settings(self,event):
        if self._closed:return
        start,end=self.settings_canvas.yview()
        if end-start>=.999:return 'break'
        number=getattr(event,'num',None)
        delta=getattr(event,'delta',0)
        if number in (4,5):steps=-1 if number==4 else 1
        elif delta:
            steps=-int(delta/120) if abs(delta)>=120 else (-1 if delta>0 else 1)
        else:return 'break'
        self.settings_canvas.yview_scroll(steps,'units')
        return 'break'

    def _reveal_setting(self,event):
        if self._closed or not event.widget.winfo_ismapped():return
        canvas=self.settings_canvas
        top=event.widget.winfo_rooty()-canvas.winfo_rooty()
        bottom=top+event.widget.winfo_height()
        margin=ui_pixels(self,8)
        delta=top-margin if top<margin else bottom-canvas.winfo_height()+margin if bottom>canvas.winfo_height()-margin else 0
        if not delta:return
        bounds=canvas.bbox('all')
        if bounds and bounds[3]>bounds[1]:
            current=canvas.canvasy(0)
            canvas.yview_moveto(max(0,(current+delta)/(bounds[3]-bounds[1])))

    def _shortcut(self,action):
        if not self._closed and not (self._busy and self._job_kind!='preview'):
            if action=='open':self.choose_photo()
            elif action=='save':self.save_recipe()
            else:self.export('jpeg')
        return 'break'

    def _load_styles(self,initial_dna=None):
        self._styles={f'builtin:{dna["name"]}':dna for dna in builtin_styles()}
        self._source_names={}
        path=app_data_dir()/DB_FILENAME
        if path.exists():
            try:
                with LibraryDB(path) as db:
                    for row in db.list_source_profiles():
                        record=db.get_source_profile(row['id'])
                        try:dna=dna_from_batch(record['payload'],row['name'])
                        except (ValueError,KeyError):continue
                        key=f'analysis:{row["id"]}';self._styles[key]=dna;self._source_names[key]=row['name']
                    for row in db.list_style_presets():
                        record=db.get_style_preset(row['id'])
                        key=f'saved:{row["id"]}';self._styles[key]=record['dna'];self._source_names[key]=row['name']
            except Exception as exc:
                self._set_status('style_error',detail=str(exc))
        if initial_dna:
            self._styles['incoming']=copy.deepcopy(validate_dna(initial_dna))
            self._source_names['incoming']=initial_dna['name']
        self._primary_key='incoming' if initial_dna else next(iter(self._styles))
        self._secondary_key=None

    def translate(self):
        t=self.i18n.t;self.title(t('style_title'))
        for widget,key in self._labels+self._buttons:widget.configure(text=t(key))
        self._choices={};labels=[];seen={}
        for key,dna in self._styles.items():
            name=t('style_preset_'+dna['name']) if key.startswith('builtin:') else self._source_names.get(key,dna['name'])
            label=f'{t("style_category_"+dna["category"])} · {name}'
            seen[label]=seen.get(label,0)+1
            if seen[label]>1:label+=f' ({seen[label]})'
            self._choices[label]=key;labels.append(label)
        self.primary_combo.configure(values=labels);self.secondary_combo.configure(values=[t('style_none'),*labels])
        self.primary.set(next(label for label,key in self._choices.items() if key==self._primary_key))
        self.secondary.set(next((label for label,key in self._choices.items() if key==self._secondary_key),t('style_none')))
        self.composition_combo.configure(values=[t('style_color_only'),t('style_suggestions'),t('style_apply_crop')])
        self.composition.set(t('style_'+self._composition_code))
        self.file_label.configure(text=self.source.name if self.source else t('style_choose_prompt'))
        self.subject_btn.configure(text=t('style_subject_adjustments_open' if self._subject_open else 'style_subject_adjustments'))
        self.details_btn.configure(text=t('style_details_hide' if self._details_open else 'style_details_show'))
        self.advanced_btn.configure(text=t('style_advanced_open' if self._advanced_open else 'style_advanced'))
        default=self._selected_dna()['name']
        if not self.name.get() or self.name.get()==getattr(self,'_default_name',''):
            self.name.set(default)
        self._default_name=default
        if not self.preview:
            for label in self.image_labels.values():label.configure(text=t('style_empty'))
        if self.preview is None:
            self.scene_label.configure(text=t('style_scene_empty'))
            for button in self.recommendation_buttons:button.configure(text=t('style_recommendation_empty'),image='',state='disabled')
            self._compare_layout()
        else:self._show_preview()
        if hasattr(self,'_status_key'):
            self.status.set(t(self._status_key,**self._status_kwargs))
        self._controls()

    def _selection_changed(self,event=None):
        self._primary_key=self._choices.get(self.primary.get(),self._primary_key)
        self._default_name=self._selected_dna()['name']
        self.name.set(self._default_name);self._schedule_preview()

    def _secondary_changed(self,event=None):
        self._secondary_key=self._choices.get(self.secondary.get())
        self._schedule_preview()

    def _composition_changed(self,event=None):
        self._composition()
        self._schedule_preview()

    def _selected_dna(self):
        self._primary_key=self._choices.get(self.primary.get(),self._primary_key)
        self._secondary_key=self._choices.get(self.secondary.get())
        primary=copy.deepcopy(self._styles[self._primary_key])
        if self._primary_key.startswith('builtin:'):primary['name']=self.i18n.t('style_preset_'+primary['name'])
        if self._secondary_key:
            secondary=copy.deepcopy(self._styles[self._secondary_key])
            value=max(0,min(1,self.mix.get()/100))
            return blend_styles([primary,secondary],[1-value,value],self.i18n.t('style_hybrid_name',name=primary['name']))
        return primary

    def _composition(self):
        t=self.i18n.t
        for key in ('color_only','suggestions','apply_crop'):
            if self.composition.get()==t('style_'+key):
                self._composition_code=key
                break
        return self._composition_code

    def choose_photo(self):
        if self._busy and self._job_kind!='preview':return
        extensions={'.jpg','.jpeg'}|RAW_EXTENSIONS
        patterns=tuple('*'+x for x in sorted(extensions))+tuple('*'+x.upper() for x in sorted(extensions))
        chosen=filedialog.askopenfilename(parent=self,title=self.i18n.t('style_choose_photo'),filetypes=[(self.i18n.t('style_photo_files'),patterns)])
        if not chosen:return
        if self._busy and self._job_kind=='preview':self._cancel.set()
        self.source=Path(chosen).resolve();self._base_preview=None;self._clear_preview()
        self.file_label.configure(text=self.source.name);self._schedule_preview()

    def _clear_preview(self):
        self.preview=None;self.active_dna=None;self._wide_compare=False;self._recommendations=[]
        self.empty_panel.place(relx=.5,rely=.46,anchor='center')
        for label in self.image_labels.values():label.configure(image='',text=self.i18n.t('style_empty'))
        self.scene_label.configure(text=self.i18n.t('style_scene_empty'))
        self.info_label.configure(text='')
        self.xmp_notice.configure(text=self.i18n.t('style_xmp_notice'))
        for button in self.recommendation_buttons:
            button.configure(text=self.i18n.t('style_recommendation_empty'),image='',state='disabled')
        self._compare_layout();self._controls()

    def _controls(self):
        self.object_heading.configure(text=self.i18n.t('style_object_strength_value',value=round(self.object_strength.get())))
        self.strength_label.configure(text=f'{round(self.strength.get())}%');self.mix_label.configure(text=f'{round(self.mix.get())}%')
        ready=bool(self.preview is not None and not self._busy and self._preview_generation==self._generation)
        for button in (self.jpeg_btn,self.xmp_btn):button.configure(state='normal' if ready else 'disabled')
        compatible=bool(self.preview is not None and self.preview['original'].shape==self.preview['rendered'].shape)
        self.compare_btn.configure(state='normal' if compatible else 'disabled')
        exporting=self._busy and self._job_kind!='preview'
        for combo in (self.primary_combo,self.secondary_combo,self.composition_combo):combo.configure(state='disabled' if exporting else 'readonly')
        for widget in (self.choose_btn,self.empty_choose_btn,self.import_btn,self.save_btn,self.json_btn,self.name_entry,self.strength_slider,self.mix_slider,self.recognition_chk,self.reset_btn,self.advanced_btn,self.subject_btn):widget.configure(state='disabled' if exporting else 'normal')
        for widget in (self.faces_chk,self.overlay_chk):widget.configure(state='normal' if not exporting and self.recognition.get() else 'disabled')
        region_support=bool(self.preview and self.preview.get('scene') and self.active_dna and recipes_for_scene(self.active_dna,self.preview['scene']['report']))
        self.object_slider.configure(state='normal' if not exporting and self.recognition.get() and region_support else 'disabled')
        if not region_support:self.object_heading.configure(text=self.i18n.t('style_object_strength_none'))
        for i,button in enumerate(self.recommendation_buttons):button.configure(state='normal' if ready and i<len(self._recommendations) else 'disabled')

    def _set_status(self,key,**kwargs):
        self._status_key=key;self._status_kwargs=kwargs;self.status.set(self.i18n.t(key,**kwargs))

    def _schedule_preview(self,*args):
        if self._closed:return
        self._generation+=1
        if self._busy and self._job_kind=='preview' and self._base_preview and self._base_preview.get('source_path')==str(self.source):
            self._cancel.set()
        if self._debounce:self.after_cancel(self._debounce)
        self._debounce=self.after(180,self.start_preview)
        if self.source is not None:self._set_status('style_preview_updating')
        self._controls()

    def start_preview(self):
        if self._debounce:
            self.after_cancel(self._debounce);self._debounce=None
        if self._closed or self.source is None:return
        if self._busy:self._pending=True;return
        try:dna=self._selected_dna()
        except Exception as exc:self._set_status('style_error',detail=str(exc));return
        request={'source':self.source,'dna':dna,'strength':max(0,min(1,self.strength.get()/100)),
                 'composition':self._composition(),'base':self._base_preview or self.preview,'recognition':self.recognition.get(),
                 'object_strength':self.object_strength.get()/100,'protect_faces':self.protect_faces.get(),'styles':copy.deepcopy(self._styles)}
        self._render_dna=dna;self._start_job('preview',request)

    def _start_job(self,kind,request):
        self._busy=True;self._job_kind=kind;self._cancel=threading.Event()
        self._set_status('style_rendering' if kind=='preview' else 'style_exporting')
        self._threads=[t for t in self._threads if t.is_alive()]
        thread=threading.Thread(target=_job,args=(self._events,self._generation,kind,request,self._cancel),daemon=True)
        self._threads.append(thread);thread.start();self._controls()

    def _poll(self):
        if self._closed:return
        while True:
            try:event=self._events.get_nowait()
            except queue.Empty:break
            _,generation,kind,*details=event
            if event[0]=='result' and kind=='preview' and details[0].get('source_path')==str(self.source):
                self._base_preview=details[0]
            if event[0]=='result' and generation==self._generation:
                if kind=='preview':
                    self.preview=details[0];self.active_dna=self._render_dna;self._preview_generation=generation;self._show_preview()
                    self._set_status('style_preview_ready')
                else:self._set_status('style_exported',name=Path(details[0]['path']).name)
            elif event[0]=='error' and generation==self._generation:
                if kind=='preview':self._clear_preview()
                self._set_status('style_error',detail=details[0])
            elif event[0]=='finished':
                self._busy=False;self._job_kind=None;self._controls()
                if self._pending or generation!=self._generation:
                    self._pending=False;self.start_preview()
        self._poll_id=self.after(60,self._poll)

    def _show_preview(self):
        t=self.i18n.t;p=self.preview;dp=lambda x:ui_pixels(self,x)
        compatible=p['original'].shape==p['rendered'].shape
        if not compatible:self._wide_compare=False
        self.empty_panel.place_forget();self._compare_layout();self.update_idletasks()
        for side,array in (('original',p['original']),('styled',p['rendered'])):
            if side=='styled' and self._wide_compare:continue
            label=self.image_labels[side]
            image=Image.fromarray(array)
            image.thumbnail((max(dp(160),label.winfo_width()-dp(8)),max(dp(80),label.winfo_height()-dp(8))),Image.Resampling.LANCZOS)
            if side=='original' and self.show_regions.get() and p.get('scene'):
                scene=p['scene'];rgb=np.array(image).astype(np.float32)
                colors={'person':[198,244,121],'face':[255,179,121],'food':[247,181,217],'animal':[216,187,247],'vehicle':[120,195,247],'plant':[103,222,177]}
                for region,color in colors.items():
                    mask=cv2.resize(scene['masks'][region],(image.width,image.height))[:,:,None]*.32
                    rgb=rgb*(1-mask)+np.array(color)*mask
                image=Image.fromarray(np.clip(rgb,0,255).astype('uint8'))
                draw=ImageDraw.Draw(image)
                for item in scene['report']['objects']:
                    box=[round(item['box'][i]*([image.width,image.height]*2)[i]) for i in range(4)]
                    draw.rectangle(box,outline=C['accent'],width=max(2,image.width//300))
            if side=='original' and self._wide_compare:
                cut=round(image.width*self.wipe.get()/100)
                combined=np.array(Image.fromarray(p['rendered']).resize(image.size,Image.Resampling.LANCZOS));combined[:,:cut]=np.array(image)[:,:cut]
                image=Image.fromarray(combined)
                ImageDraw.Draw(image).line([(cut,0),(cut,image.height)],fill=C['accent'],width=max(2,image.width//300))
            if side=='original' and p['composition']=='suggestions' and p['composition_box']:
                sx=image.width/array.shape[1];sy=image.height/array.shape[0]
                box=[round(v*(sx if i%2==0 else sy)) for i,v in enumerate(p['composition_box'])]
                ImageDraw.Draw(image).rectangle(box,outline=C['accent'],width=max(2,image.width//240))
            label=self.image_labels[side]
            image.thumbnail((max(dp(160),label.winfo_width()-dp(8)),max(dp(80),label.winfo_height()-dp(8))),Image.Resampling.LANCZOS)
            stream=BytesIO();image.save(stream,format='PNG')
            name=f'pcl-style-{id(self)}-{side}'
            encoded=base64.b64encode(stream.getvalue()).decode('ascii')
            if name in self._photo_names:self.tk.call(name,'configure','-data',encoded)
            else:self.tk.call('image','create','photo',name,'-data',encoded);self._photo_names.append(name)
            self.image_labels[side].configure(image=name,text='')
        dna=self.active_dna
        evidence=t('style_builtin_notice') if dna['kind']=='builtin' else t('style_hybrid_notice') if dna['kind']=='hybrid' else t('style_evidence',count=dna['sample_count'])
        info=[evidence,t('style_lighting',value=t('style_'+p['measurement']['lighting']))]
        if p['clipping_after']-p['clipping_before']>.03:info.append(t('style_clipping_notice'))
        if dna['kind']=='reference' or dna['confidence']<.35:info.append(t('style_reference_notice'))
        if p['composition']!='color_only' and not p['composition_box']:info.append(t('style_no_composition'))
        if p.get('scene'):
            regions=recipes_for_scene(dna,p['scene']['report'])
            if regions:info.append(t('style_region_support',regions=', '.join(t('region_'+key) for key in regions)))
        self.info_label.configure(text=' · '.join(info))
        scene=p.get('scene');report=scene['report'] if scene else None
        if report:
            names=list(dict.fromkeys(t('object_'+item['class_code']) for item in report['objects']))
            self.scene_label.configure(text=t('style_scene_detected',objects=', '.join(names[:6]) or t('style_no_objects'),faces=len(report['faces'])))
            if any(report['region_fractions'][r]>.015 for r in ('food','animal','vehicle','plant')):
                self.scene_label.configure(text=self.scene_label.cget('text')+' · '+t('style_box_notice'))
        else:self.scene_label.configure(text=t('style_recognition_off'))
        tiles=p.get('style_tiles') or []
        self._recommendations=[(tile['key'],tile['distance'],tile['supported']) for tile in tiles] if tiles else style_distances(p['measurement'],self._styles,report)
        for index,button in enumerate(self.recommendation_buttons):
            if index<len(self._recommendations):
                key,_,supported=self._recommendations[index]
                name=t('style_preset_'+self._styles[key]['name']) if key.startswith('builtin:') else self._source_names.get(key,self._styles[key]['name'])
                display=name
                while int(self.tk.call('font','measure','LabBody',display))>dp(148) and len(display)>1:
                    name=name[:-1];display=name+'…'
                tile_name=''
                if index<len(tiles):
                    tile_name=f'pcl-style-{id(self)}-tile-{index}'
                    tile_image=Image.fromarray(tiles[index]['pixels']).resize((dp(70),dp(50)),Image.Resampling.LANCZOS)
                    stream=BytesIO();tile_image.save(stream,format='PNG');encoded=base64.b64encode(stream.getvalue()).decode('ascii')
                    if tile_name in self._photo_names:self.tk.call(tile_name,'configure','-data',encoded)
                    else:self.tk.call('image','create','photo',tile_name,'-data',encoded);self._photo_names.append(tile_name)
                button.configure(text=display,image=tile_name,compound='left',state='normal')
            else:button.configure(text=t('style_recommendation_empty'),image='',state='disabled')
        if scene:self.xmp_notice.configure(text=t('style_xmp_objects_notice'))
        else:self.xmp_notice.configure(text=t('style_xmp_notice'))
        self._controls()

    def _fit_layout(self,event):
        if self._closed or event.widget is not self:return
        wrap=max(1,event.width-ui_pixels(self,372))
        self.info_label.configure(wraplength=wrap)
        self.xmp_notice.configure(wraplength=wrap)
        self.scene_label.configure(wraplength=max(ui_pixels(self,150),wrap-ui_pixels(self,220)))
        if self._resize_after:self.after_cancel(self._resize_after)
        self._resize_after=self.after(120,self._redraw_images)

    def _queue_redraw(self,*args):
        if not self._closed and self._view_after is None:
            self._view_after=self.after(16,self._redraw_images)

    def _redraw_images(self):
        if self._view_after:self.after_cancel(self._view_after)
        self._view_after=None
        if self._resize_after:self.after_cancel(self._resize_after)
        self._resize_after=None
        if not self._closed and self.preview is not None:self._show_preview()

    def export(self,kind):
        if self._busy or self.preview is None or self._preview_generation!=self._generation:return
        suffix='.jpg' if kind=='jpeg' else '.xmp'
        chosen=filedialog.asksaveasfilename(parent=self,title=self.i18n.t('style_export_'+kind),defaultextension=suffix,
            initialfile=self.source.stem+('_pcl.jpg' if kind=='jpeg' else '_pcl_preset.xmp'),filetypes=[(self.i18n.t('style_export_'+kind),'*'+suffix)])
        if not chosen:return
        request={'source':self.source,'destination':Path(chosen),'dna':copy.deepcopy(self.active_dna),
                 'strength':self.preview['strength'],'composition':self.preview['composition'],
                 'fingerprint':self.preview['source_fingerprint'],'effective':copy.deepcopy(self.preview['effective']),
                 'recognition':self.preview['recognition'],'object_strength':self.preview['object_strength'],'protect_faces':self.preview['protect_faces']}
        self._start_job(kind,request)

    def _compare_layout(self):
        dp=lambda x:ui_pixels(self,x)
        if self._wide_compare:
            self.image_frames['styled'].grid_remove();self.image_captions['styled'].grid_remove()
            self.image_frames['original'].grid(columnspan=2,padx=0)
            self.image_captions['original'].configure(text=self.i18n.t('style_compare_caption'))
            self.compare_btn.configure(text=self.i18n.t('style_side_compare'));self.wipe_slider.grid()
        else:
            self.image_frames['original'].grid(columnspan=1,padx=(0,dp(7)))
            self.image_frames['styled'].grid();self.image_captions['styled'].grid()
            self.image_captions['original'].configure(text=self.i18n.t('style_original'))
            self.compare_btn.configure(text=self.i18n.t('style_wide_compare'));self.wipe_slider.grid_remove()

    def _drag_compare(self,event):
        if not self._wide_compare or self.preview is None:return
        size=self.image_labels['original'].winfo_width()
        height=self.image_labels['original'].winfo_height()
        photo_height,photo_width=self.preview['original'].shape[:2]
        scale=min(max(ui_pixels(self,160),size-ui_pixels(self,8))/photo_width,max(ui_pixels(self,80),height-ui_pixels(self,8))/photo_height,1.)
        shown=photo_width*scale
        offset=(size-shown)/2
        self.wipe.set(max(0,min(100,(event.x-offset)/max(1,shown)*100)))
        self._queue_redraw()
        return 'break'

    def toggle_compare(self):
        if self.preview is None or self.preview['original'].shape!=self.preview['rendered'].shape:return
        self._wide_compare=not self._wide_compare;self._compare_layout();self._show_preview()

    def toggle_advanced(self):
        self._advanced_open=not self._advanced_open
        self.advanced_btn.configure(text=self.i18n.t('style_advanced_open' if self._advanced_open else 'style_advanced'))
        if self._advanced_open:self.advanced_frame.grid()
        else:self.advanced_frame.grid_remove()

    def reset_controls(self):
        self.strength.set(70);self.mix.set(30);self.object_strength.set(70)
        self._secondary_key=None;self.secondary.set(self.i18n.t('style_none'));self.protect_faces.set(True)
        self._composition_code='color_only';self.composition.set(self.i18n.t('style_color_only'));self._schedule_preview()

    def use_recommendation(self,index):
        if self._busy or index>=len(self._recommendations):return
        key=self._recommendations[index][0]
        self.primary.set(next(label for label,value in self._choices.items() if value==key))
        self.secondary.set(self.i18n.t('style_none'));self._selection_changed()

    def save_recipe(self):
        if self._busy and self._job_kind!='preview':return
        try:
            dna=self._selected_dna();dna['name']=self.name.get().strip();validate_dna(dna)
            with LibraryDB(app_data_dir()/DB_FILENAME) as db:identifier=db.save_style_preset(dna['name'],dna)
            key=f'saved:{identifier}';self._styles[key]=dna;self._source_names[key]=dna['name']
            self._primary_key=key;self._secondary_key=None;self.translate()
            if self.source is not None:self._schedule_preview()
            self._set_status('style_recipe_saved',name=dna['name'])
        except Exception as exc:self._set_status('style_error',detail=str(exc))

    def export_recipe(self):
        if self._busy and self._job_kind!='preview':return
        chosen=filedialog.asksaveasfilename(parent=self,title=self.i18n.t('style_export_recipe'),defaultextension='.json',initialfile='personal-color-lab-style.json',filetypes=[(self.i18n.t('style_recipe_files'),'*.json')])
        if not chosen:return
        try:
            dna=self._selected_dna();dna['name']=self.name.get().strip();export_style_json(chosen,dna)
            self._set_status('style_exported',name=Path(chosen).name)
        except Exception as exc:self._set_status('style_error',detail=str(exc))

    def import_style(self):
        if self._busy and self._job_kind!='preview':return
        chosen=filedialog.askopenfilename(parent=self,title=self.i18n.t('style_import'),filetypes=[(self.i18n.t('style_recipe_files'),'*.json')])
        if not chosen:return
        try:
            dna=load_style_file(chosen);key=f'imported:{len(self._styles)}'
            self._styles[key]=dna;self._source_names[key]=dna['name'];self._primary_key=key;self._secondary_key=None
            self.translate();self._schedule_preview()
        except Exception as exc:self._set_status('style_error',detail=str(exc))

    def close(self):
        if self._closed:return
        self._closed=True;self._cancel.set()
        self.after_cancel(self._poll_id)
        self.after_cancel(self._raise_after)
        if self._debounce:self.after_cancel(self._debounce)
        if self._resize_after:self.after_cancel(self._resize_after)
        if self._view_after:self.after_cancel(self._view_after)
        for name in self._photo_names:self.tk.call('image','delete',name)
        self._photo_names.clear();self.recommendation_buttons.clear()
        for sequence in ('<MouseWheel>','<Button-4>','<Button-5>','<FocusIn>'):
            self.unbind_class(self._settings_bindtag,sequence)
        super().destroy()
        self.preview=None;self.active_dna=None;self._render_dna=None;self._base_preview=None;self._threads.clear();self.image_frames.clear();self.image_captions.clear();self._labels.clear();self._buttons.clear();self.image_labels.clear()
        for key in ('subject_btn','subject_frame','empty_panel','empty_choose_btn','preview_stage','details_btn','wipe','wipe_slider','compare_btn','primary','secondary','strength','mix','composition','name','status','recognition','protect_faces','show_regions','object_strength','settings_canvas','settings_scroll','advanced_frame','advanced_btn','recognition_chk','faces_chk','overlay_chk','object_slider','object_heading','reset_btn','scene_label','choose_btn','file_label','primary_combo','secondary_combo','strength_slider','strength_label','mix_slider','mix_label','composition_combo','import_btn','info_label','xmp_notice','name_entry','save_btn','json_btn','status_label','jpeg_btn','xmp_btn'):
            setattr(self,key,None)

    def destroy(self):self.close()
