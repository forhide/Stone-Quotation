class_name GroundedCatGait
extends RefCounted

# Distance, rather than a wall-clock sine wave, drives the feet. During stance
# the offset moves backwards by exactly the distance travelled by the body.
const CYCLE_DISTANCE := 96.0
const STANCE_FRACTION := 0.52
const STRIDE := CYCLE_DISTANCE * STANCE_FRACTION
const FOOT_LIFT := 2.8

static func foot(distance: float, direction: Vector2, strength: float, alternate: bool = false) -> Dictionary:
	var phase := fposmod(distance / CYCLE_DISTANCE + (0.5 if alternate else 0.0), 1.0)
	var planted := phase < STANCE_FRACTION
	var advance: float
	var lift := 0.0
	if planted:
		advance = STRIDE * 0.5 - phase * CYCLE_DISTANCE
	else:
		var swing := (phase - STANCE_FRACTION) / (1.0 - STANCE_FRACTION)
		# Match the backward stance velocity at both ends of the swing. A plain
		# smoothstep stopped the paw relative to the body at touchdown, creating
		# the little peck/flick that made the walk look excessively busy.
		var t2 := swing * swing
		var t3 := t2 * swing
		var tangent := -CYCLE_DISTANCE * (1.0 - STANCE_FRACTION)
		advance = lerpf(-STRIDE * 0.5, STRIDE * 0.5, 3.0 * t2 - 2.0 * t3)
		advance += tangent * (swing - 3.0 * t2 + 2.0 * t3)
		# A low arc with zero vertical speed at toe-off and landing keeps the
		# short paws close to the floor, without turning each step into a kick.
		lift = pow(sin(swing * PI), 2.0) * FOOT_LIFT
	return {"offset": direction * advance * strength, "lift": lift * strength, "planted": planted, "phase": phase}

static func sample(distance: float, direction: Vector2, strength: float) -> Dictionary:
	return {"left": foot(distance, direction, strength), "right": foot(distance, direction, strength, true)}
