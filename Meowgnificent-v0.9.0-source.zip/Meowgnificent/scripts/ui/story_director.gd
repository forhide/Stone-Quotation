class_name StoryDirector
extends CanvasLayer

# Narrative UI is independent of combat. The room pauses its actors before
# opening a sequence and resumes from the completion callback. close() cancels;
# skip() and advance() on the last page complete exactly once.
signal sequence_started(kind: String, chapter: int)
signal sequence_finished(kind: String, chapter: int)
signal page_changed(index: int, total: int)

const STORY_PATH := "res://data/story.json"
const INK := Color("654e45")
const MUTED := Color("7c6c60")
const PAPER := Color("fff7e6")
const EDGE := Color("bda286")
var room: Node
var story: Dictionary = {}
var is_open := false
var mode := ""
var chapter_index := -1
var pages: Array = []
var page_index := 0
var elapsed := 0.0
var auto_advance := true
var last_completed_sequence := ""
var screen: Control
var stage: StoryStage
var speaker_label: Label
var body_label: Label
var chapter_label: Label
var page_label: Label
var next_button: Button
var skip_button: Button
var _completion := Callable()

func _ready() -> void:
	layer=22
	process_mode=Node.PROCESS_MODE_ALWAYS
	var loaded: Variant=JSON.parse_string(FileAccess.get_file_as_string(STORY_PATH))
	if loaded is Dictionary:
		story=loaded
	else:
		push_error("Story data could not be read.")
	screen=Control.new()
	var story_theme := Theme.new()
	story_theme.default_font=preload("res://art/fonts/MeowStorySans-Regular.otf")
	screen.theme=story_theme
	screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	screen.mouse_filter=Control.MOUSE_FILTER_STOP
	add_child(screen)
	var backdrop := ColorRect.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.color=Color("f5ecd8")
	backdrop.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(backdrop)
	chapter_label=_label("",28,INK,Vector2(78,47),Vector2(980,48))
	_label("ARCANA ACADEMY  ·  THE MISADVENTURES OF MEOWMALADE",12,Color("806348"),Vector2(80,27),Vector2(900,22))
	var frame := Panel.new()
	frame.position=Vector2(74,111)
	frame.size=Vector2(1132,397)
	frame.mouse_filter=Control.MOUSE_FILTER_IGNORE
	frame.add_theme_stylebox_override("panel",_style(Color("e8efdc"),EDGE,24,0))
	screen.add_child(frame)
	stage=StoryStage.new()
	stage.position=Vector2(75,112)
	stage.size=Vector2(1130,395)
	stage.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(stage)
	var dialogue := Panel.new()
	dialogue.position=Vector2(74,528)
	dialogue.size=Vector2(1132,196)
	dialogue.mouse_filter=Control.MOUSE_FILTER_IGNORE
	dialogue.add_theme_stylebox_override("panel",_style(PAPER,EDGE,22,0))
	screen.add_child(dialogue)
	speaker_label=_label("",15,Color("806348"),Vector2(101,548),Vector2(1050,25))
	body_label=_label("",23,INK,Vector2(101,582),Vector2(1050,91))
	body_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	page_label=_label("",13,MUTED,Vector2(80,746),Vector2(950,24))
	next_button=_button("Next page",Vector2(1034,666),Vector2(148,40),Color("d7e8c9"))
	next_button.pressed.connect(advance)
	skip_button=_button("Skip story",Vector2(1060,39),Vector2(146,39),Color("eee3f2"))
	skip_button.pressed.connect(skip)
	var settings_button := _button("Settings",Vector2(910,39),Vector2(132,39),Color("e8eeda"))
	settings_button.pressed.connect(func(): room.settings.open())
	screen.hide()
	set_process(false)

func _label(text: String, font_size: int, color: Color, position_: Vector2, size_: Vector2) -> Label:
	var label := Label.new()
	label.text=text
	label.position=position_
	label.size=size_
	label.add_theme_font_size_override("font_size",font_size)
	label.add_theme_color_override("font_color",color)
	label.mouse_filter=Control.MOUSE_FILTER_IGNORE
	screen.add_child(label)
	return label

func _style(fill: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=fill
	style.border_color=border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.content_margin_left=margin
	style.content_margin_right=margin
	style.content_margin_top=margin
	style.content_margin_bottom=margin
	return style

func _button(caption: String, at: Vector2, size_: Vector2, fill: Color) -> Button:
	var button := Button.new()
	button.text=caption
	button.position=at
	button.size=size_
	button.add_theme_font_size_override("font_size",15)
	for key in ["font_color","font_hover_color","font_pressed_color"]:
		button.add_theme_color_override(key,INK)
	button.add_theme_stylebox_override("normal",_style(fill,Color("a79983"),11,6))
	button.add_theme_stylebox_override("hover",_style(fill.lightened(0.12),Color("8e9b7f"),11,6))
	button.add_theme_stylebox_override("pressed",_style(fill.darkened(0.06),Color("8e9b7f"),11,6))
	button.add_theme_stylebox_override("focus",_style(Color(0,0,0,0),Color("a88bb8"),11,0))
	screen.add_child(button)
	return button

func play_opening(done: Callable) -> void:
	_play("opening",-1,"A minor magical incident",story.get("opening",[]),true,done)

func show_chapter(index: int, done: Callable) -> void:
	var chapters: Array=story.get("chapters",[])
	if index<0 or index>=chapters.size():
		if done.is_valid(): done.call_deferred()
		return
	var definition: Dictionary=chapters[index]
	_play("chapter",index,str(definition.get("title","A new chapter")),definition.get("beats",[]),false,done)

func play_ending(done: Callable) -> void:
	_play("ending",-1,"An unexpected correct answer",story.get("ending",[]),true,done)

func _play(kind: String, chapter: int, title: String, sequence: Array, autoplay: bool, done: Callable) -> void:
	close()
	mode=kind
	chapter_index=chapter
	pages=sequence.duplicate(true)
	_completion=done
	page_index=0
	elapsed=0.0
	auto_advance=autoplay
	chapter_label.text=title
	if pages.is_empty():
		_finish()
		return
	is_open=true
	screen.show()
	set_process(true)
	_show_page()
	sequence_started.emit(mode,chapter_index)

func _show_page() -> void:
	if page_index<0 or page_index>=pages.size(): return
	var page: Dictionary=pages[page_index]
	elapsed=0.0
	speaker_label.text=str(page.get("speaker",""))
	body_label.text=GameLocale.story_text(page)
	# Dialogue expressions do not choose the location. In particular, a deadpan
	# reaction must not teleport a garden or archive chapter back to the academy.
	var location := chapter_index if mode=="chapter" else -1
	if mode=="opening" and str(page.get("visual",""))=="detention": location=0
	if mode=="ending" and page_index<6: location=7
	stage.set_scene(str(page.get("visual","academy")),location)
	page_label.text=GameLocale.text("%02d / %02d  ·  ENTER / SPACE: next page  ·  ESC: skip story") % [page_index+1,pages.size()]
	var last := page_index==pages.size()-1
	next_button.text=("Begin detention" if mode=="opening" else "Continue") if last else "Next page"
	if mode=="ending" and last: next_button.text="The end"
	page_changed.emit(page_index,pages.size())

func refresh_language() -> void:
	if not is_open or pages.is_empty(): return
	body_label.text=GameLocale.story_text(pages[page_index])
	page_label.text=GameLocale.text("%02d / %02d  ·  ENTER / SPACE: next page  ·  ESC: skip story") % [page_index+1,pages.size()]
	stage.queue_redraw()

func advance() -> void:
	if not is_open: return
	if page_index>=pages.size()-1:
		_finish()
	else:
		page_index+=1
		_show_page()

func skip() -> void:
	if is_open: _finish()

func close() -> void:
	is_open=false
	_completion=Callable()
	if is_instance_valid(screen): screen.hide()
	set_process(false)

func _finish() -> void:
	var done := _completion
	var finished_mode := mode
	var finished_chapter := chapter_index
	last_completed_sequence=finished_mode
	close()
	# GUI clicks and Space are also cast bindings. Clear their held action before
	# returning to the room; its callback also blocks casts until input releases.
	if InputMap.has_action("cast"): Input.action_release("cast")
	sequence_finished.emit(finished_mode,finished_chapter)
	if done.is_valid(): done.call_deferred()

func _input(event: InputEvent) -> void:
	if is_instance_valid(room) and is_instance_valid(room.settings) and room.settings.blocks_gameplay_input(): return
	if not is_open: return
	if event is InputEventKey:
		get_viewport().set_input_as_handled()
		if not event.is_pressed() or event.is_echo(): return
		match event.keycode:
			KEY_ESCAPE: skip()
			KEY_ENTER,KEY_KP_ENTER,KEY_SPACE: advance()

func _process(delta: float) -> void:
	if not is_open: return
	elapsed+=delta
	stage.time=elapsed
	stage.queue_redraw()
	if auto_advance:
		var page: Dictionary=pages[page_index]
		if elapsed>=float(page.get("duration",4.0)): advance()

class StoryStage extends Control:
	var visual := "academy"
	var time := 0.0
	var hero: TextureRect
	var hero_frames: Array[AtlasTexture] = []
	const HERO_SHEET: Texture2D = WizardCatVisual.ACTION_SHEET
	const ACADEMY: Texture2D = preload("res://art/story/academy.png")
	const LIBRARY: Texture2D = preload("res://art/story/library.png")
	const FRIENDS: Texture2D = preload("res://art/story/friends.png")
	const ARCHIVE: Texture2D = preload("res://art/story/archive.png")
	var plate: Texture2D = ACADEMY
	var report_style: StyleBoxFlat
	var location_index := -1
	var location_backdrop: ArchiveBackdrop
	var friend_frame: Panel
	var friend_portrait: TextureRect
	var friend_regions: Dictionary = {}

	func _ready() -> void:
		clip_contents=true
		texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
		report_style=StyleBoxFlat.new()
		report_style.bg_color=Color("fff7e9")
		report_style.border_color=Color("bca27f")
		report_style.set_border_width_all(2)
		report_style.set_corner_radius_all(14)
		report_style.shadow_color=Color(0.25,0.19,0.14,0.18)
		report_style.shadow_size=10
		location_backdrop=ArchiveBackdrop.new()
		location_backdrop.include_frame=false
		location_backdrop.show_behind_parent=true
		location_backdrop.visible=false
		# Keep the environment's aspect ratio. The upper wall and the beginning
		# of its floor decorations form the illustrated widescreen composition.
		location_backdrop.scale=Vector2.ONE*(1130.0/1280.0)
		location_backdrop.position=Vector2(0,-28)
		add_child(location_backdrop)
		hero=TextureRect.new()
		hero.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		hero.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		hero.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
		hero.mouse_filter=Control.MOUSE_FILTER_IGNORE
		for rectangle in WizardCatVisual.POSE_RECTS:
			var frame := AtlasTexture.new()
			frame.atlas=HERO_SHEET
			frame.region=Rect2(rectangle)
			frame.filter_clip=true
			hero_frames.append(frame)
		hero.texture=hero_frames[0]
		add_child(hero)
		# Portrait vignettes identify the speaker while the actual stage remains
		# visible behind them; a dialogue expression never changes the location.
		friend_frame=Panel.new()
		friend_frame.add_theme_stylebox_override("panel",report_style)
		friend_frame.mouse_filter=Control.MOUSE_FILTER_IGNORE
		add_child(friend_frame)
		friend_portrait=TextureRect.new()
		friend_portrait.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
		friend_portrait.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_COVERED
		friend_portrait.mouse_filter=Control.MOUSE_FILTER_IGNORE
		friend_frame.add_child(friend_portrait)
		for key: String in ["pip","moss","bloop","friends"]:
			var crop := AtlasTexture.new()
			crop.atlas=FRIENDS
			crop.region={"pip":Rect2(775,319,250,400),"moss":Rect2(976,228,242,411),"bloop":Rect2(1200,292,220,330),"friends":Rect2(760,230,776,535)}[key]
			crop.filter_clip=true
			friend_regions[key]=crop
		set_scene(visual)

	func set_scene(value: String, location: int=-1) -> void:
		visual=value
		location_index=location
		time=0.0
		if is_instance_valid(location_backdrop):
			location_backdrop.visible=location>=0
			if location>=0: location_backdrop.configure(location)
		if visual in ["library","grimoire","truth","analysis"]: plate=LIBRARY
		elif visual in ["garden","pip","moss","bloop","friends"]: plate=FRIENDS
		elif visual in ["archive","examiner"]: plate=ARCHIVE
		else: plate=ACADEMY
		if is_instance_valid(hero):
			hero.visible=visual!="end"
			hero.position=Vector2(134,38)
			hero.size=Vector2(264,318)
			hero.texture=hero_frames[1] if visual=="fire" else hero_frames[3] if visual=="reverse" else hero_frames[0]
			if visual in ["friends","pip","moss","bloop","garden"]:
				hero.position=Vector2(140,112)
				hero.size=Vector2(226,266)
			if visual=="boom":
				hero.position=Vector2(105,169)
				hero.size=Vector2(156,194)
		if is_instance_valid(friend_frame):
			friend_frame.visible=friend_regions.has(visual)
			if friend_frame.visible:
				var group := visual=="friends"
				friend_frame.position=Vector2(648,49) if group else Vector2(827,37)
				friend_frame.size=Vector2(420,288) if group else Vector2(218,290)
				friend_portrait.position=Vector2(8,8)
				friend_portrait.size=friend_frame.size-Vector2(16,16)
				friend_portrait.texture=friend_regions[visual]
		queue_redraw()

	func _text(source: String, at: Vector2, font_size: int=22, color: Color=Color("654e45")) -> void:
		var text := GameLocale.text(source)
		var font := GameLocale.STORY_FONT
		var width := font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x
		draw_string(font,at-Vector2(width*0.5,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size,color)

	func _draw() -> void:
		# One shared HD scene quad, plus the animated hero and small authored effects.
		# The mild pan avoids motionless slides without baking or allocating textures.
		var source := plate.get_size()
		var crop_height := source.x*size.y/size.x
		var pan := sin(minf(time,8.0)*0.12)*8.0
		var crop := Rect2(0,(source.y-crop_height)*0.53+pan,source.x,crop_height)
		if location_index<0:
			draw_texture_rect_region(plate,Rect2(Vector2.ZERO,size),crop)
		if is_instance_valid(hero):
			hero.pivot_offset=hero.size*Vector2(0.5,0.95)
			hero.rotation=sin(time*1.8)*0.012
		if visual=="reverse" and location_index==7:
			# The ending's stray flame has already fallen. Its result appears
			# behind the Grimoire before the large explosion, as in the notes.
			draw_texture_rect(SpellArt.part("smoke"),Rect2(613,108-minf(time,2.0)*8,112,96),false,Color(1,1,1,0.45))
		elif visual in ["fire","reverse","candle"]:
			var at := Vector2(405,205)
			if visual=="reverse": at=Vector2(720,205).lerp(Vector2(205,285),clampf(time/1.6,0,1))
			elif visual=="fire": at+=Vector2(minf(time/2.0,1.0)*250,0)
			var extent := Vector2(124,62)
			var heading := PI if visual=="reverse" else 0.0
			if visual=="candle":
				at=Vector2(405,275)
				extent=Vector2(45,22.5)
				heading=PI/2
				draw_rect(Rect2(at+Vector2(-5,4),Vector2(10,25)),Color("fff0c9"))
				draw_line(at+Vector2(0,1),at+Vector2(0,6),Color("93785c"),1.5,true)
			draw_set_transform(at,heading)
			# Hot core in the shared1774x887 flame sheet is at1541,485.
			draw_texture_rect(SpellArt.part("comet"),Rect2(-extent*Vector2(1541.0/1774.0,485.0/887.0),extent),false)
			draw_set_transform(Vector2.ZERO)
		if visual=="boom":
			draw_texture_rect(SpellArt.part("smoke"),Rect2(330,10,490,377),false)
			_text("BOOM!",Vector2(580,225),49,Color("a8655c"))
		if visual in ["grades","report"]: _report(visual=="report")
		if visual=="analysis":
			draw_style_box(report_style,Rect2(550,256,515,94))
			_text("POWER: EXTREME    CONTROL: 3%",Vector2(807,292),18)
			_text("PREDICTABILITY: 0%    …ERROR",Vector2(807,325),20,Color("a1687c"))
		if visual=="end":
			draw_style_box(report_style,Rect2(314,120,500,147))
			_text("Meowgnificent",Vector2(564,183),43)
			_text("THE END",Vector2(564,235),24,Color("8a729c"))

	func _report(ending: bool) -> void:
		draw_style_box(report_style,Rect2(470,25,570,344))
		draw_texture_rect(EquipmentArt.icon("apprentice_thesis"),Rect2(492,43,42,42),false)
		_text("MEOWMALADE’S ACADEMIC RECORD",Vector2(783,65),20)
		var subjects := ["Elemental Magic","Teleportation","Summoning","Potion Making","Magical Control","World Saving" if ending else "Destruction"]
		var marks := ["D","F","F","C-","F","A+" if ending else "S+"]
		var font := GameLocale.STORY_FONT
		for i in range(subjects.size()):
			var y := 110+i*32
			draw_string(font,Vector2(509,y),GameLocale.text(subjects[i]),HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color("755a48"))
			draw_string(font,Vector2(932,y),marks[i],HORIZONTAL_ALIGNMENT_LEFT,-1,22,Color("9a6b86") if i==5 else Color("755a48"))
		if ending: _text("OVERALL: MEOWGNIFICENT",Vector2(755,343),19,Color("8e728e"))
