class_name EquipmentArt
extends RefCounted

# Every inventory/drop/worn icon shares one of four imported HD atlases.
const SHEET: Texture2D = preload("res://art/equipment/storybook_equipment.png")
const WEAPON_SHEET: Texture2D = preload("res://art/equipment/expanded_weapons.png")
const PENDANT_SHEET: Texture2D = preload("res://art/equipment/expanded_pendants.png")
const CHARM_SHEET: Texture2D = preload("res://art/equipment/expanded_charms.png")
const NEW_WEAPONS := ["practice_wand", "frost_whisker_wand", "hopscotch_wand", "pip_feather_staff", "moss_bud_staff", "bloop_bottle_wand", "thunder_spoon", "bubble_teapot", "comet_crayon"]
const NEW_COLLARS := ["linen_star_collar", "acorn_bell_collar", "button_bow_collar", "frost_drop_collar", "moss_heart_collar", "bloop_locket_collar", "thunder_key_collar", "bubble_pearl_collar", "comet_medal_collar"]
const NEW_CHARMS := ["paper_pinwheel", "clover_leaf", "sleepy_acorn", "frost_button", "pip_egg", "moss_seed_pouch", "bloop_cork", "thunder_marble", "comet_stamp"]
const RECTS := {
 "crooked_ash_wand":Rect2(53,20,350,463),
 "cinderfork_wand":Rect2(447,16,386,464),
 "apprentice_thesis":Rect2(866,76,369,375),
 "brass_bell_collar":Rect2(18,519,398,316),
 "velvet_bell_collar":Rect2(435,519,389,315),
 "nine_lives_collar":Rect2(839,519,404,324),
 "loose_feather":Rect2(24,844,391,396),
 "warm_sardine_charm":Rect2(433,903,375,307),
 "moonlit_yarn":Rect2(849,875,395,368),
 "practice_wand":Rect2(101,53,276,379),
 "frost_whisker_wand":Rect2(511,43,297,390),
 "hopscotch_wand":Rect2(905,52,316,379),
 "pip_feather_staff":Rect2(92,438,297,393),
 "moss_bud_staff":Rect2(498,441,336,397),
 "bloop_bottle_wand":Rect2(892,484,342,320),
 "thunder_spoon":Rect2(57,848,338,373),
 "bubble_teapot":Rect2(444,885,386,336),
 "comet_crayon":Rect2(932,847,287,379),
 "linen_star_collar":Rect2(79,62,287,324),
 "acorn_bell_collar":Rect2(502,66,277,329),
 "button_bow_collar":Rect2(874,83,340,312),
 "frost_drop_collar":Rect2(119,456,210,349),
 "moss_heart_collar":Rect2(500,482,255,310),
 "bloop_locket_collar":Rect2(931,457,234,347),
 "thunder_key_collar":Rect2(107,851,216,341),
 "bubble_pearl_collar":Rect2(492,851,282,341),
 "comet_medal_collar":Rect2(907,881,270,315),
 "paper_pinwheel":Rect2(70,39,332,389),
 "clover_leaf":Rect2(491,63,301,358),
 "sleepy_acorn":Rect2(916,58,296,360),
 "frost_button":Rect2(74,466,286,338),
 "pip_egg":Rect2(519,457,250,345),
 "moss_seed_pouch":Rect2(900,462,302,349),
 "bloop_cork":Rect2(81,844,275,354),
 "thunder_marble":Rect2(490,846,261,343),
 "comet_stamp":Rect2(903,855,319,355)
}
const ORIGINAL_PENDANTS := {
 "brass_bell_collar":Rect2(148,686,145,145),
 "velvet_bell_collar":Rect2(552,692,151,145),
 "nine_lives_collar":Rect2(976,693,149,145)
}
static var _icons: Dictionary = {}

static func has_icon(id: String) -> bool:
 return RECTS.has(id)

static func slot_for(id: String) -> String:
 if not has_icon(id): return ""
 if NEW_WEAPONS.has(id) or id in ["crooked_ash_wand","cinderfork_wand","apprentice_thesis"]: return "wand"
 if NEW_COLLARS.has(id) or ORIGINAL_PENDANTS.has(id): return "collar"
 return "charm"

static func _sheet_for(id: String) -> Texture2D:
 if NEW_WEAPONS.has(id): return WEAPON_SHEET
 if NEW_COLLARS.has(id): return PENDANT_SHEET
 if NEW_CHARMS.has(id): return CHARM_SHEET
 return SHEET

static func icon(id: String) -> Texture2D:
 if not has_icon(id): return null
 if not _icons.has(id):
  var texture := AtlasTexture.new()
  texture.atlas=_sheet_for(id)
  texture.region=RECTS[id]
  texture.filter_clip=true
  _icons[id]=texture
 return _icons[id]

# Original collars show only their pendant on the character. New collar art is
# authored as small pendants already, so it never places a strap across the face.
static func worn_icon(id: String) -> Texture2D:
 if not has_icon(id): return null
 if not ORIGINAL_PENDANTS.has(id): return icon(id)
 var key := "worn:"+id
 if not _icons.has(key):
  var texture := AtlasTexture.new()
  texture.atlas=SHEET
  texture.region=ORIGINAL_PENDANTS[id]
  texture.filter_clip=true
  _icons[key]=texture
 return _icons[key]

static func attachment_layout(id: String) -> Dictionary:
 var slot := slot_for(id)
 if slot.is_empty(): return {}
 var texture := worn_icon(id)
 var box := Vector2(42,52)
 var angle := -0.12
 if slot=="collar":
  box=Vector2(14,17)
  angle=0.0
 elif slot=="charm":
  box=Vector2(24,26)
  angle=-0.25
 elif id=="apprentice_thesis":
  box=Vector2(39,41)
 elif id=="bubble_teapot":
  box=Vector2(44,43)
  angle=-0.03
 elif id=="bloop_bottle_wand":
  box=Vector2(38,44)
 var source_size := texture.get_size()
 var factor := minf(box.x/source_size.x,box.y/source_size.y)
 return {"slot":slot,"extent":source_size*factor,"angle":angle}
