extends SceneTree

# Real authored repeated shots remain alive when text changes. Manual ticks make
# the seam deterministic; the options section uses the real processing lifecycle.
var checks := 0
var failures := 0
var room
var director: StoryDirector
var profile_path := "/tmp/meow-story-continuity-%d.json" % OS.get_process_id()
func _initialize() -> void: call_deferred("run")
func check(ok: bool, description: String) -> void:
	checks+=1
	if ok: print("PASS: "+description)
	else:
		failures+=1
		push_error("FAIL: "+description)
func frames(count: int=2) -> void:
	for i in range(count): await process_frame
func tick(seconds: float) -> void:
	director._process(seconds)
	director.stage._animate_actors()
func page(index: int) -> void:
	director.page_index=index
	director._show_page()
func node_count(node: Node) -> int:
	var count := 1
	for child in node.get_children(): count+=node_count(child)
	return count
func state_for(sprite: TextureRect) -> Dictionary:
	return director.stage._actor_states[sprite.get_instance_id()]
func run() -> void:
	OS.set_environment("MEOW_SKIP_STORY","0")
	OS.set_environment("MEOW_PROFILE_PATH",profile_path)
	change_scene_to_file("res://scenes/main.tscn")
	await frames(4)
	room=current_scene
	room.request_begin()
	await frames()
	director=room.story_director
	director.auto_advance=false
	director.set_process(false)
	var stage=director.stage
	page(0)
	tick(1.0)
	var clock: float=stage.ambient_time
	var action: float=stage.time
	var entries: int=stage.scene_entries
	var hero_point: Vector2=stage.hero.position
	var hero_texture: Texture2D=stage.hero.texture
	var count := node_count(stage)
	director.advance()
	check(director.page_index==1 and director.elapsed==0,"a dialogue advance gives the next line its own full reading duration")
	check(stage.ambient_time==clock and stage.time==action and stage.entrance_time>=1,"academy narration changes without restarting ambience or the shot")
	check(stage.scene_entries==entries and stage.hero.position==hero_point and stage.hero.texture==hero_texture and stage.hero.modulate.a==1,"the same cat pose stays opaque and at the same position across the page seam")
	check(node_count(stage)==count and stage._actor_states.size()==5,"page changes reuse the five allocated actor/expression pairs")
	page(9)
	tick(1.0)
	var book_point: Vector2=stage.friend_portrait.position
	var background_builds: int=stage.backdrop_configurations
	clock=stage.ambient_time
	entries=stage.scene_entries
	director.advance()
	check(stage.actor_ids==PackedStringArray(["grimoire"]) and stage.friend_portrait.position==book_point and stage.friend_portrait.modulate.a==1,"the repeated Grimoire opening line never re-enters or fades its book actor")
	check(stage.ambient_time==clock and stage.scene_entries==entries and stage.backdrop_configurations==background_builds,"a repeated scene does not rebuild the backdrop or reset the camera clock")
	director.show_chapter(3,Callable())
	director.set_process(false)
	tick(1.2)
	book_point=stage.friend_portrait.position
	clock=stage.ambient_time
	entries=stage.scene_entries
	director.advance()
	check(stage.base_visual=="pip" and stage.friend_portrait.position==book_point and stage.friend_portrait.modulate.a==1 and stage.scene_entries==entries,"Pip's two shop-story lines keep one grounded squirrel on the screen")
	check(stage.ambient_time==clock and not state_for(stage.friend_portrait).ghost.visible,"identical texture/pose dialogue changes do not create a redundant crossfade")
	director.show_chapter(2,Callable())
	director.set_process(false)
	tick(3.15)
	var props: Array[Texture2D]=[]
	for prop: TextureRect in stage.living_props: props.append(prop.texture)
	var feet: Vector2=stage.friend_portrait.position+stage.friend_portrait.pivot_offset
	clock=stage.ambient_time
	director.advance()
	var same_props := true
	for i in range(props.size()): same_props=same_props and stage.living_props[i].texture==props[i] and stage.living_props[i].modulate.a==1
	check(stage.base_visual=="moss" and stage.actor_ids==PackedStringArray(["moss"]) and stage.ambient_time==clock,"garden-to-Moss dialogue keeps the same semantic shot despite a different visual key")
	check(same_props and props[0]==LivingStageArt.icon("mushroom"),"the same six cultivated mushrooms continue into their uprooting cue without a scene refresh")
	check((stage.friend_portrait.position+stage.friend_portrait.pivot_offset).distance_to(feet)<0.001,"Moss's grounded foot anchor stays planted on the garden page seam")
	var rotation_before: float=stage.friend_portrait.rotation
	tick(0.22)
	check(absf(stage.friend_portrait.rotation-rotation_before)>0.001 and (stage.friend_portrait.position+stage.friend_portrait.pivot_offset).distance_to(feet)<0.001,"the current speaker gives a soft body nod around the same feet")
	director.advance()
	check(stage.actor_ids==PackedStringArray(["moss"]) and stage.friend_portrait.modulate.a==1,"returning to garden narration retains its actor without another entrance")
	director.show_chapter(7,Callable())
	director.set_process(false)
	tick(1.2)
	var old_texture: Texture2D=stage.friend_portrait.texture
	clock=stage.ambient_time
	entries=stage.scene_entries
	director.advance()
	var book_state: Dictionary=state_for(stage.friend_portrait)
	check(stage.grimoire_pose=="shocked" and stage.friend_portrait.texture==GrimoireArt.icon("shocked"),"the failed analysis still selects the book's meaningful shocked expression")
	check(book_state.ghost.visible and book_state.ghost.texture==old_texture and book_state.ghost.modulate.a>0.99,"the previous book drawing remains visible when the new expression begins")
	check(stage.scene_entries==entries and stage.ambient_time==clock,"an expression change does not restart the set or actor entrance")
	tick(0.10)
	check(stage.friend_portrait.modulate.a>0.35 and stage.friend_portrait.modulate.a<0.65 and book_state.ghost.modulate.a>0.35 and book_state.ghost.modulate.a<0.65,"different expressions blend smoothly through a visible midpoint")
	tick(0.20)
	check(stage.friend_portrait.modulate.a==1 and not book_state.ghost.visible,"the blend settles to one clean actor instead of leaving a doubled portrait")
	director.advance()
	tick(0.35)
	director.advance()
	check(stage.base_visual=="deadpan" and stage.actor_ids==PackedStringArray(["grimoire"]),"the book stays opposite Meowmalade when the dialogue becomes a deadpan reaction")
	clock=stage.ambient_time
	var current_line: int=director.page_index
	var scene_count: int=stage.scene_entries
	GameLocale.set_language("ko",false)
	director.refresh_language()
	check(director.page_index==current_line and stage.ambient_time==clock and stage.scene_entries==scene_count,"changing language updates the dialogue without replacing or restarting the scene")
	director.play_ending(Callable())
	director.auto_advance=false
	director.set_process(false)
	page(2)
	tick(1.0)
	clock=stage.ambient_time
	action=stage.time
	entries=stage.scene_entries
	director.advance()
	check(stage.base_visual=="candle" and stage.time==action and stage.ambient_time==clock and stage.scene_entries==entries,"the two final candle lines share one uninterrupted failed-spark action")
	var total := node_count(stage)
	for i in range(30):
		page(2 if i%2==0 else 3)
		tick(0.04)
	check(node_count(stage)==total and stage._actor_states.size()==5,"many repeated page changes allocate no extra scene actors or expression nodes")
	room.announce_story_chapter(1)
	director.set_process(false)
	tick(2.4)
	var last_flame: Vector2=stage.snapshot().flame
	director.advance()
	check(stage.time==0 and stage.snapshot().flame.distance_to(last_flame)<0.1,"a true action change resets only the action clock and preserves the fire-to-reverse trajectory")
	# Exercise actual settings rather than merely not ticking the stage.
	director.set_process(true)
	check(not room.actors.visible and not room.background.visible and not room.projectiles.visible and not room.markers.visible and not room.hud.visible,"an opaque story shot stops submitting the fully covered combat world and HUD")
	room.settings.open()
	var frozen: Dictionary=stage.snapshot()
	await frames(12)
	check(not director.is_processing() and stage.snapshot()==frozen,"opening actual options freezes ambience, expression and action clocks together")
	room.settings.close()
	await frames(4)
	check(not room.actors.visible and not room.hud.visible,"closing story options keeps the obscured world hidden while narration continues")
	check(director.is_processing() and stage.ambient_time>float(frozen.ambient_time),"closing options resumes the same continuous scene")
	director.skip()
	await frames(3)
	check(not director.is_open and room.state=="playing" and room.projectiles.get_child_count()==0,"skipping a continuous chapter resumes gameplay without leaking a cast")
	check(room.actors.visible and room.background.visible and room.projectiles.visible and room.markers.visible and room.hud.visible,"skipping the story restores the original visible game world and HUD")
	room.projectiles.visible=false
	director.show_chapter(7,Callable())
	director.close()
	check(not room.projectiles.visible and room.actors.visible and room.hud.visible,"closing a new story preserves a world node that was already intentionally hidden")
	room.queue_free()
	await frames()
	for suffix in ["",".tmp",".bak"]:
		if FileAccess.file_exists(profile_path+suffix): DirAccess.remove_absolute(profile_path+suffix)
	print("STORY CONTINUITY RESULT: %d checks, %d failures" % [checks,failures])
	quit(0 if failures==0 else 1)
