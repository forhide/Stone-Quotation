# Offline Architecture Contract

1. The installed desktop application must run fully offline. No HTTP client, API keys, cloud inference, user accounts, telemetry, analytics, remote configuration, or hidden runtime network dependencies are permitted.
2. Never upload photos, previews, EXIF, derived style data, or model data. Installing development dependencies can require network access; normal application use cannot.
3. Photo files remain in their original folders. Analysis reads them without destructive edits, copying libraries, or writing sidecars in this milestone. Future final edit output should prefer non-destructive Lightroom-compatible XMP.
4. Persist only paths, selected non-location metadata, derived analysis, confidence/provenance, and source hashes in the local SQLite library. Do not persist GPS coordinates or location metadata.
5. V0.2 uses Pillow, NumPy, and headless OpenCV locally on the CPU. EXIF orientation and valid ICC color conversion are handled locally; analysis does not call a model service.
6. Future AI models must ship as local files, preferably ONNX, with mandatory CPU fallback. GPU acceleration is optional.
7. Keep English/Korean UI text in external locale resources. English is the default language.
8. Runtime data defaults to `~/.personal_color_lab`; `PERSONAL_COLOR_LAB_DATA_DIR` can select another local directory. Database upgrades must preserve existing V0.1 data.
9. Analysis payloads record inferred provenance and task-specific confidence. Geometric failure or unreadable embedded ICC profiles suppress tone/color and approximate estimates; invalid ICC can still allow geometry inspection. Overall confidence covers registered tone/color evidence, while EV/WB estimates have separate confidence. Approximate Lightroom-like values are not exact XMP parameters.
10. Windows x64 and macOS Apple Silicon/Intel offline installers bundle private Python/Tcl-Tk and native analysis wheels. Build tools download verified dependencies; installer/application execution downloads nothing. Keep build-time downloaders outside the runtime payload. Native release validation and signing remain pending; see INSTALLERS.md and VALIDATION.md. Future models can be shipped as offline packs.
11. Preset/style bundles contain derived profiles and metadata, not copied film frames or photographer images. Composition changes require a user choice and remain non-destructive.

Current development targets the desktop source application. No mobile runtime or web server is required.

Source dependency lockfiles and the local-Xvfb test runner support repeatable development checks. The runner does not download tools and is not part of application runtime networking.
