import os
from pathlib import Path

RAW_EXTENSIONS = {
    '.arw', '.cr2', '.cr3', '.nef', '.nrw', '.raf', '.rw2', '.orf', '.dng', '.pef', '.srw'
}
JPEG_EXTENSIONS = {'.jpg', '.jpeg'}
IMAGE_EXTENSIONS = JPEG_EXTENSIONS | {'.png', '.tif', '.tiff', '.heic', '.heif'}
XMP_EXTENSIONS = {'.xmp'}
SUPPORTED_EXTENSIONS = RAW_EXTENSIONS | IMAGE_EXTENSIONS | XMP_EXTENSIONS

APP_NAME = 'Personal Color Lab'
APP_VERSION = '0.2.2'
DEFAULT_LANGUAGE = 'en'

DATA_DIR_NAME = '.personal_color_lab'
DB_FILENAME = 'library.db'
SETTINGS_FILENAME = 'settings.json'
DATA_DIR_ENV = 'PERSONAL_COLOR_LAB_DATA_DIR'

def app_data_dir() -> Path:
    override = os.environ.get(DATA_DIR_ENV)
    p = Path(override).expanduser() if override else Path.home() / DATA_DIR_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p
