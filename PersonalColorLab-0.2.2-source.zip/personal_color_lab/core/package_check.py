"""Offline packaged-runtime checks using only disposable, synthetic inputs.

No GUI window, user library, environment variable, or original photograph is
changed. The same checks run from source Python and a frozen application.
"""
from __future__ import annotations

import importlib
import platform
import string
import sys
import tempfile
from pathlib import Path

from .constants import APP_NAME, APP_VERSION, DEFAULT_LANGUAGE

REPORT_SCHEMA_VERSION = 1


def _locales() -> dict:
    from .i18n import I18N

    english, korean = I18N('en'), I18N('ko')
    if english.messages.keys() != korean.messages.keys():
        raise RuntimeError('English and Korean locale resources have different keys.')
    formatter = string.Formatter()
    for key, text in english.messages.items():
        translated = korean.messages[key]
        if not isinstance(text, str) or not text or not isinstance(translated, str) or not translated:
            raise RuntimeError(f'Locale message is missing or invalid: {key}')
        fields = {name for _, name, _, _ in formatter.parse(text) if name is not None}
        translated_fields = {name for _, name, _, _ in formatter.parse(translated) if name is not None}
        if fields != translated_fields:
            raise RuntimeError(f'Locale message format arguments differ: {key}')
    if I18N().language != DEFAULT_LANGUAGE:
        raise RuntimeError('Default UI language does not match application configuration.')
    return {'languages': ['en', 'ko'], 'message_count': len(english.messages), 'default_language': DEFAULT_LANGUAGE}


def _dependencies() -> dict:
    versions = {}
    for name in ('PIL', 'numpy', 'cv2'):
        module = importlib.import_module(name)
        versions[name] = str(module.__version__)
    import sqlite3
    versions['sqlite'] = sqlite3.sqlite_version
    return versions


def _tcl_runtime() -> dict:
    # A Tcl interpreter checks bundled init.tcl without requiring a display.
    import tkinter

    interpreter = tkinter.Tcl()
    version = interpreter.eval('info patchlevel')
    return {'tcl_version': version, 'tk_binding_version': str(tkinter.TkVersion)}


def _synthetic_analysis_and_library() -> dict:
    import cv2
    import numpy as np
    from PIL import Image

    from .database import LibraryDB
    from .edit_reverse import ALGORITHM_VERSION, analyze_pair, file_fingerprint
    from .schema_migrations import CURRENT_SCHEMA_VERSION

    rng = np.random.default_rng(271828)
    image = rng.integers(40, 180, (240, 360, 3), dtype=np.uint8)
    image = cv2.GaussianBlur(image, (5, 5), 0)
    for _ in range(60):
        x, y = rng.integers(10, 220, 2)
        color = tuple(int(value) for value in rng.integers(35, 200, 3))
        cv2.circle(image, (int(x), int(y)), 5, color, -1)
    for index in range(4):
        value = 45 + index * 35
        cv2.rectangle(image, (280, 8 + index * 55), (340, 38 + index * 55), (value,) * 3, -1)
    edited = np.clip(image.astype(np.float64) * 1.08 + [6, 1, -4], 0, 255).astype(np.uint8)

    with tempfile.TemporaryDirectory(prefix='personal-color-lab-self-test-') as directory:
        root = Path(directory)
        original_path, edited_path = root / 'synthetic_original.jpg', root / 'synthetic_edit.jpg'
        Image.fromarray(image).save(original_path, quality=98, subsampling=0)
        Image.fromarray(edited).save(edited_path, quality=98, subsampling=0)
        before = [file_fingerprint(path) for path in (original_path, edited_path)]
        payload = analyze_pair(original_path, edited_path)
        if payload['status'] != 'ok' or not payload['alignment']['success']:
            raise RuntimeError('Synthetic JPG registration or analysis failed.')
        if payload['algorithm_version'] != ALGORITHM_VERSION:
            raise RuntimeError('Analysis algorithm version is inconsistent.')
        if payload['tone']['mean_luminance_delta'] <= 0:
            raise RuntimeError('Synthetic brightening was not detected.')
        if not payload['lightroom_estimates']['approximate']:
            raise RuntimeError('Inferred slider estimates are missing their approximate label.')
        if before != [file_fingerprint(path) for path in (original_path, edited_path)]:
            raise RuntimeError('Analysis modified a synthetic source image.')
        with LibraryDB(root / 'temporary_library.db') as library:
            analysis_id = library.save_analysis(original_path, edited_path, payload)
            if not analysis_id or library.get_analysis(original_path, edited_path) != payload:
                raise RuntimeError('Temporary SQLite analysis round trip failed.')
            schema_version = library.conn.execute('PRAGMA user_version').fetchone()[0]
            if schema_version != CURRENT_SCHEMA_VERSION:
                raise RuntimeError('Temporary SQLite schema version is inconsistent.')
        return {
            'algorithm_version': ALGORITHM_VERSION,
            'analysis_status': payload['status'],
            'alignment_confidence': payload['alignment']['confidence'],
            'mean_luminance_delta': payload['tone']['mean_luminance_delta'],
            'library_schema_version': schema_version,
            'originals_unchanged': True,
            'temporary_files_removed_on_return': True,
        }


def run_package_check() -> dict:
    """Return a portable diagnostic report; a failed check never opens a GUI."""
    report = {
        'report_schema_version': REPORT_SCHEMA_VERSION,
        'app_name': APP_NAME,
        'app_version': APP_VERSION,
        'python_version': platform.python_version(),
        'platform': sys.platform,
        'machine': platform.machine(),
        'frozen': bool(getattr(sys, 'frozen', False)),
        'ok': True,
        'checks': [],
    }
    for name, check in (
        ('locale_resources', _locales),
        ('native_dependencies', _dependencies),
        ('tcl_runtime', _tcl_runtime),
        ('synthetic_analysis_and_library', _synthetic_analysis_and_library),
    ):
        try:
            details = check()
            report['checks'].append({'name': name, 'ok': True, 'details': details})
        except Exception as exc:
            report['ok'] = False
            report['checks'].append({'name': name, 'ok': False, 'error_type': type(exc).__name__, 'error': str(exc)})
    return report
