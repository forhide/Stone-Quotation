"""Local library storage. Analysis payloads contain derived data, never GPS."""

import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from .models import PhotoRecord, PairCandidate
from .schema_migrations import SCHEMA, SchemaMigrationError, migrate_schema


class AnalysisValidationError(ValueError):
    """An analysis is not a valid, finite, GPS-free JSON payload."""


class AnalysisDataError(ValueError):
    """A stored versioned analysis is corrupt or inconsistent."""


def _path_text(path: Path) -> str:
    value = str(Path(path))
    if value == '.' or '\x00' in value:
        raise AnalysisValidationError('Analysis paths must identify photo files.')
    return value


def _check_json_value(value) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise AnalysisValidationError('Analysis JSON keys must be strings.')
            normalized = ''.join(c for c in key.lower() if c.isalnum())
            if normalized.startswith('gps') or normalized in {
                'latitude', 'longitude', 'lat', 'lon', 'lng', 'geolocation',
            }:
                raise AnalysisValidationError('GPS metadata must not be persisted.')
            _check_json_value(item)
    elif isinstance(value, list):
        for item in value:
            _check_json_value(item)
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise AnalysisValidationError('Analysis numbers must be finite.')
    elif value is not None and not isinstance(value, (str, int, bool)):
        raise AnalysisValidationError('Analysis values must be JSON-native types.')


def _validate_analysis(original: str, edited: str, payload: dict) -> None:
    if not isinstance(payload, dict):
        raise AnalysisValidationError('Analysis payload must be a dictionary.')
    if original == edited:
        raise AnalysisValidationError('Original and edited paths must be different.')
    if payload.get('original_path') != original or payload.get('edited_path') != edited:
        raise AnalysisValidationError('Analysis source paths do not match the selected pair.')
    version = payload.get('schema_version')
    if (
        isinstance(version, bool) or not isinstance(version, int)
        or not 1 <= version <= 2**63 - 1
    ):
        raise AnalysisValidationError('Analysis schema_version must be a positive integer.')
    for field in ('algorithm_version', 'source_type'):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise AnalysisValidationError(f'Analysis {field} must be a nonempty string.')
    if not isinstance(payload.get('status'), str) or payload['status'] not in {
        'ok', 'alignment_failed', 'color_space_uncertain',
    }:
        raise AnalysisValidationError('Analysis status is unsupported.')
    for field in ('provenance', 'alignment', 'tone', 'color', 'lightroom_estimates'):
        if not isinstance(payload.get(field), dict):
            raise AnalysisValidationError(f'Analysis {field} must be a dictionary.')
    warnings = payload.get('warnings')
    if not isinstance(warnings, list) or any(not isinstance(item, str) for item in warnings):
        raise AnalysisValidationError('Analysis warnings must be a list of strings.')
    confidence = payload.get('confidence')
    if (
        isinstance(confidence, bool)
        or not isinstance(confidence, (int, float))
        or not 0 <= confidence <= 1
        or not math.isfinite(confidence)
    ):
        raise AnalysisValidationError('Analysis confidence must be between zero and one.')
    try:
        _check_json_value(payload)
    except RecursionError as exc:
        raise AnalysisValidationError('Analysis payload is cyclic or too deeply nested.') from exc


def _reject_constant(value: str):
    raise ValueError(f'Non-finite JSON constant: {value}')


class LibraryDB:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        try:
            migrate_schema(self.conn)
        except Exception:
            self.conn.close()
            raise

    def replace_scan(self, records: list[PhotoRecord], pairs: list[PairCandidate]):
        with self.conn:
            for r in records:
                self.conn.execute('''
                    INSERT INTO photos(path,ext,kind,size_bytes,width,height,capture_time,camera,lens,fingerprint)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(path) DO UPDATE SET
                        ext=excluded.ext,kind=excluded.kind,size_bytes=excluded.size_bytes,
                        width=excluded.width,height=excluded.height,capture_time=excluded.capture_time,
                        camera=excluded.camera,lens=excluded.lens,fingerprint=excluded.fingerprint
                ''', (str(r.path), r.ext, r.kind, r.size_bytes, r.width, r.height, r.capture_time, r.camera, r.lens, r.fingerprint))
            for p in pairs:
                self.conn.execute('''
                    INSERT INTO pairs(original_path,edited_path,pair_type,confidence,reasons)
                    VALUES(?,?,?,?,?)
                    ON CONFLICT(original_path,edited_path,pair_type) DO UPDATE SET
                        confidence=excluded.confidence,reasons=excluded.reasons
                ''', (str(p.original), str(p.edited), p.pair_type, p.confidence, '; '.join(p.reasons)))

    def save_analysis(self, original_path: Path, edited_path: Path, payload: dict) -> int:
        """Persist one version per pair; repeating that version updates its row."""
        original, edited = _path_text(original_path), _path_text(edited_path)
        _validate_analysis(original, edited, payload)
        try:
            encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, sort_keys=True)
        except (TypeError, ValueError, RecursionError) as exc:
            raise AnalysisValidationError('Analysis could not be encoded as JSON.') from exc
        updated_at = datetime.now(timezone.utc).isoformat(timespec='microseconds')
        with self.conn:
            self.conn.execute('''
                INSERT INTO edit_analysis(
                    original_path, edited_path, source_type, confidence, payload_json,
                    schema_version, algorithm_version, status, updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(original_path, edited_path, schema_version, algorithm_version)
                WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
                DO UPDATE SET source_type=excluded.source_type,
                    confidence=excluded.confidence, payload_json=excluded.payload_json,
                    status=excluded.status, updated_at=excluded.updated_at
            ''', (
                original, edited, payload['source_type'], payload['confidence'], encoded,
                payload['schema_version'], payload['algorithm_version'], payload['status'],
                updated_at,
            ))
            row = self.conn.execute('''
                SELECT id FROM edit_analysis
                WHERE original_path=? AND edited_path=?
                    AND schema_version=? AND algorithm_version=?
            ''', (original, edited, payload['schema_version'], payload['algorithm_version'])).fetchone()
        return row[0]

    def get_analysis(self, original_path: Path, edited_path: Path) -> dict | None:
        """Return the latest saved versioned result, excluding legacy rows.

        Corruption raises AnalysisDataError rather than silently substituting an
        older result, which could misrepresent the selected photos' analysis.
        """
        original, edited = _path_text(original_path), _path_text(edited_path)
        row = self.conn.execute('''
            SELECT id, payload_json, schema_version, algorithm_version,
                status, source_type, confidence
            FROM edit_analysis
            WHERE original_path=? AND edited_path=?
                AND schema_version IS NOT NULL AND algorithm_version IS NOT NULL
            ORDER BY updated_at DESC, id DESC LIMIT 1
        ''', (original, edited)).fetchone()
        if row is None:
            return None
        try:
            payload = json.loads(row[1], parse_constant=_reject_constant)
            _validate_analysis(original, edited, payload)
            if (
                payload['schema_version'] != row[2]
                or payload['algorithm_version'] != row[3]
                or payload['status'] != row[4]
                or payload['source_type'] != row[5]
                or payload['confidence'] != row[6]
            ):
                raise ValueError('Stored analysis header differs from its payload.')
        except (TypeError, ValueError, RecursionError) as exc:
            raise AnalysisDataError(f'Stored analysis row {row[0]} is invalid.') from exc
        return payload

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
