import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from types import SimpleNamespace

from ..core.constants import APP_VERSION, DB_FILENAME, JPEG_EXTENSIONS, app_data_dir
from ..core.database import LibraryDB
from ..core.i18n import I18N
from ..core.models import PairCandidate
from ..core.scanner import find_pairs, scan_folder, summarize
from ..core.settings import load_settings, save_settings
from .display import initialize_display, ui_pixels
from .pair_inspector import PairInspector
from .theme import COLORS as C, configure_theme


class App(tk.Tk):
    def __init__(self):
        initialize_display()
        super().__init__()
        configure_theme(self)
        dp = lambda value: ui_pixels(self, value)
        self.settings = load_settings()
        self.i18n = I18N(self.settings.get('language', 'en'))
        self.folder = tk.StringVar(value='')
        self.recursive = tk.BooleanVar(value=True)
        self.lang = tk.StringVar(value=self.i18n.language)
        self.display_lang = tk.StringVar(value='')
        self.progress = tk.DoubleVar(value=0)
        self.status = tk.StringVar(value='')
        self._events = queue.Queue()
        self._row_pairs = {}
        self._inspectors = []
        self._scanning = False
        self._has_scanned = False
        self._status_key = 'status_ready'
        self._status_kwargs = {}
        self._closed = False
        self._worker_threads = []
        self.title(f'{self.i18n.t("app_title")} {APP_VERSION}')
        self.geometry(f'{dp(1240)}x{dp(820)}')
        self.minsize(dp(1060), dp(720))
        self.protocol('WM_DELETE_WINDOW', self.close)
        self._build()
        self._translate()
        self._poll_id = self.after(60, self._poll)

    def _build(self):
        dp = lambda value: ui_pixels(self, value)
        self.configure(background=C['bg'])
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._labels = []

        # A quiet rail gives the current workspace a home without advertising
        # features that do not exist yet.
        rail = tk.Frame(self, background=C['inset'], width=dp(184))
        rail.grid(row=0, column=0, sticky='ns')
        rail.grid_propagate(False)
        rail.columnconfigure(0, weight=1)
        rail.rowconfigure(3, weight=1)
        brand = tk.Frame(rail, background=C['inset'])
        brand.grid(row=0, column=0, sticky='ew', padx=dp(22), pady=(dp(30), dp(28)))
        mark = tk.Canvas(brand, width=dp(38), height=dp(38), background=C['inset'], highlightthickness=dp(0))
        mark.pack(anchor='w', pady=(dp(0), dp(14)))
        mark.create_oval(dp(3), dp(3), dp(35), dp(35), outline=C['accent'], width=dp(2))
        mark.create_polygon(dp(12), dp(11), dp(27), dp(14), dp(30), dp(25), dp(17), dp(29), dp(8), dp(22), fill=C['accent'], outline='')
        mark.create_oval(dp(14), dp(14), dp(24), dp(24), fill=C['inset'], outline='')
        self.title_lbl = tk.Label(brand, font='LabHeading', background=C['inset'], foreground=C['text'], anchor='w', justify='left', wraplength=dp(140))
        self.title_lbl.pack(anchor='w')
        tk.Label(brand, text=f'v{APP_VERSION}', font='LabSmall', background=C['inset'], foreground=C['subtle']).pack(anchor='w', pady=(dp(7), dp(0)))
        active = tk.Frame(rail, background=C['elevated'])
        active.grid(row=1, column=0, sticky='ew', padx=dp(12))
        tk.Frame(active, background=C['accent'], width=dp(3)).pack(side='left', fill='y')
        nav = tk.Label(active, font='LabBody', background=C['elevated'], foreground=C['accent'], padx=dp(15), pady=dp(13), anchor='w')
        nav.pack(side='left', fill='x', expand=True)
        self._labels.append((nav, 'nav_library'))
        tk.Frame(rail, height=dp(1), background=C['border']).grid(row=2, column=0, sticky='ew', padx=dp(22), pady=(dp(26), dp(0)))
        rail_footer = tk.Frame(rail, background=C['inset'])
        rail_footer.grid(row=4, column=0, sticky='ew', padx=dp(22), pady=(dp(20), dp(25)))
        self.lang_lbl = tk.Label(rail_footer, font='LabSmall', background=C['inset'], foreground=C['muted'], anchor='w')
        self.lang_lbl.pack(anchor='w', pady=(dp(0), dp(7)))
        self.lang_combo = ttk.Combobox(rail_footer, style='Lab.TCombobox', textvariable=self.display_lang, state='readonly', width=13)
        self.lang_combo.pack(fill='x')
        self.lang_combo.bind('<<ComboboxSelected>>', self.change_language)

        body = ttk.Frame(self, style='Lab.TFrame', padding=(dp(28), dp(26), dp(28), dp(18)))
        body.grid(row=0, column=1, sticky='nsew')
        body.columnconfigure(0, weight=1)
        body.rowconfigure(4, weight=1)
        header = ttk.Frame(body, style='Lab.TFrame')
        header.grid(row=0, column=0, sticky='ew', pady=(dp(0), dp(14)))
        header.columnconfigure(0, weight=1)
        heading = ttk.Label(header, style='Title.TLabel', font='LabDisplay')
        heading.grid(row=0, column=0, sticky='w')
        self._labels.append((heading, 'workspace_title'))
        self.subtitle_lbl = ttk.Label(header, style='Muted.TLabel')
        self.subtitle_lbl.grid(row=1, column=0, sticky='w', pady=(dp(5), dp(0)))
        self.compare_btn = ttk.Button(header, style='Primary.TButton', command=self.choose_pair)
        self.compare_btn.grid(row=0, column=1, rowspan=2, sticky='e', padx=(dp(16), dp(0)))

        workflow = tk.Frame(body, background=C['bg'])
        workflow.grid(row=1, column=0, sticky='ew', pady=(dp(0), dp(12)))
        for index, key in enumerate(('workflow_choose', 'workflow_compare', 'workflow_understand')):
            workflow.columnconfigure(index, weight=1)
            step = tk.Label(workflow, font='LabSmall', background=C['bg'], foreground=C['accent'] if index == 0 else C['muted'], anchor='w')
            step.grid(row=0, column=index, sticky='ew', padx=(dp(0), dp(12)))
            self._labels.append((step, key))

        controls = tk.Frame(body, background=C['surface'], highlightbackground=C['border'], highlightthickness=dp(1), padx=dp(17), pady=dp(12))
        controls.grid(row=2, column=0, sticky='ew', pady=(dp(0), dp(14)))
        controls.columnconfigure(0, weight=1)
        controls.columnconfigure(1, weight=1)
        folder_heading = tk.Label(controls, font='LabHeading', background=C['surface'], foreground=C['text'], anchor='w')
        folder_heading.grid(row=0, column=0, sticky='w', pady=(dp(0), dp(2)))
        self._labels.append((folder_heading, 'folder_heading'))
        folder_hint = tk.Label(controls, font='LabSmall', background=C['surface'], foreground=C['muted'], anchor='w')
        folder_hint.grid(row=1, column=0, columnspan=2, sticky='w', pady=(dp(0), dp(8)))
        self._labels.append((folder_hint, 'folder_hint'))
        self.recursive_chk = ttk.Checkbutton(controls, style='Lab.TCheckbutton', variable=self.recursive)
        self.recursive_chk.grid(row=0, column=2, columnspan=2, sticky='e', padx=(dp(15), dp(0)))
        self.folder_entry = ttk.Entry(controls, style='Lab.TEntry', textvariable=self.folder)
        self.folder_entry.grid(row=2, column=0, columnspan=2, sticky='ew')
        self.choose_btn = ttk.Button(controls, style='Secondary.TButton', padding=(dp(12), dp(7)), command=self.choose_folder)
        self.choose_btn.grid(row=2, column=2, padx=(dp(10), dp(8)))
        self.scan_btn = ttk.Button(controls, style='Secondary.TButton', padding=(dp(12), dp(7)), command=self.start_scan)
        self.scan_btn.grid(row=2, column=3)
        self.progress_track = tk.Frame(controls, background=C['inset'], height=dp(4))
        self.progress_track.grid(row=3, column=0, columnspan=4, sticky='ew', pady=(dp(10), dp(0)))
        self.progress_track.grid_propagate(False)
        ttk.Progressbar(self.progress_track, style='Lab.Horizontal.TProgressbar', variable=self.progress, maximum=100).place(relwidth=1, relheight=1)
        self.progress_track.grid_remove()

        self.summary_frame = tk.Frame(body, background=C['bg'])
        self.summary_frame.grid(row=3, column=0, sticky='ew', pady=(dp(0), dp(12)))
        self.summary_vars = {}
        for index, key in enumerate(('total', 'jpg_jpg', 'edited_only')):
            self.summary_frame.columnconfigure(index, weight=1, uniform='metrics')
            card = tk.Frame(self.summary_frame, background=C['surface'], highlightbackground=C['border'], highlightthickness=dp(1), padx=dp(16), pady=dp(9))
            card.grid(row=0, column=index, sticky='nsew', padx=(dp(0), dp(10)) if index < 2 else dp(0))
            label = tk.Label(card, font='LabSmall', background=C['surface'], foreground=C['muted'], anchor='w')
            label.pack(fill='x')
            value = tk.Label(card, text='0', font='LabTitle', background=C['surface'], foreground=C['accent'] if key == 'jpg_jpg' else C['text'], anchor='w')
            value.pack(fill='x', pady=(dp(3), dp(0)))
            self.summary_vars[key] = (label, value)
        self.summary_frame.grid_remove()
        support = tk.Frame(self.summary_frame, background=C['bg'])
        support.grid(row=1, column=0, columnspan=3, sticky='ew', pady=(dp(11), dp(0)))
        for index, key in enumerate(('raw', 'jpg', 'other_images', 'xmp', 'raw_xmp', 'raw_jpg')):
            support.columnconfigure(index, weight=1)
            stat = tk.Frame(support, background=C['bg'])
            stat.grid(row=0, column=index, sticky='w')
            value = tk.Label(stat, text='0', font='LabSmall', background=C['bg'], foreground=C['text'])
            value.pack(side='left', padx=(dp(0), dp(5)))
            label = tk.Label(stat, font='LabSmall', background=C['bg'], foreground=C['subtle'])
            label.pack(side='left')
            self.summary_vars[key] = (label, value)

        self.tablebox = tk.Frame(body, background=C['surface'], highlightbackground=C['border'], highlightthickness=dp(1))
        self.tablebox.grid(row=4, column=0, sticky='nsew')
        self.tablebox.rowconfigure(1, weight=1)
        self.tablebox.columnconfigure(0, weight=1)
        table_header = tk.Frame(self.tablebox, background=C['surface'], padx=dp(17), pady=dp(10))
        table_header.grid(row=0, column=0, sticky='ew')
        table_title = tk.Label(table_header, font='LabHeading', background=C['surface'], foreground=C['text'])
        table_title.pack(side='left')
        self._labels.append((table_title, 'pairs'))
        viewport = tk.Frame(self.tablebox, background=C['surface'])
        viewport.grid(row=1, column=0, sticky='nsew')
        viewport.columnconfigure(0, weight=1)
        viewport.rowconfigure(0, weight=1)
        self.tree = ttk.Treeview(viewport, style='Lab.Treeview', columns=('type', 'confidence', 'original', 'edited'), show='headings', selectmode='browse')
        self.tree.grid(row=0, column=0, sticky='nsew')
        scroll = ttk.Scrollbar(viewport, style='Lab.Vertical.TScrollbar', orient='vertical', command=self.tree.yview)
        self.table_scroll = scroll
        scroll.grid(row=0, column=1, sticky='ns')
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.column('type', width=dp(105), minwidth=dp(85), anchor='center', stretch=False)
        self.tree.column('confidence', width=dp(120), minwidth=dp(110), anchor='center', stretch=False)
        self.tree.column('original', width=dp(280), minwidth=dp(150))
        self.tree.column('edited', width=dp(280), minwidth=dp(150))
        self.tree.bind('<<TreeviewSelect>>', self._selection_changed)
        self.tree.bind('<Double-1>', self._double_click)
        self.tree.bind('<Return>', lambda _event: self.inspect_selected())
        self.tree.tag_configure('even', background=C['surface'])
        self.tree.tag_configure('odd', background=C['elevated'])
        self.empty_state = tk.Frame(viewport, background=C['surface'])
        empty_body = tk.Frame(self.empty_state, background=C['surface'])
        empty_body.place(relx=0.5, rely=0.5, anchor='center', relwidth=0.88)
        empty_icon = tk.Canvas(empty_body, width=dp(60), height=dp(43), background=C['surface'], highlightthickness=dp(0))
        empty_icon.pack(pady=(dp(0), dp(10)))
        empty_icon.create_rectangle(dp(5), dp(4), dp(39), dp(30), outline=C['border'], width=dp(2))
        empty_icon.create_rectangle(dp(18), dp(12), dp(55), dp(40), fill=C['surface'], outline=C['muted'], width=dp(1))
        empty_icon.create_oval(dp(42), dp(17), dp(47), dp(22), fill=C['accent'], outline='')
        empty_icon.create_line(dp(23), dp(34), dp(31), dp(26), dp(39), dp(33), dp(44), dp(28), dp(51), dp(35), fill=C['muted'], width=dp(1))
        self.empty_title = tk.Label(empty_body, font='LabHeading', background=C['surface'], foreground=C['text'])
        self.empty_title.pack()
        self.empty_hint = tk.Label(empty_body, font='LabSmall', background=C['surface'], foreground=C['muted'], justify='center', wraplength=dp(620))
        self.empty_hint.pack(pady=(dp(6), dp(0)))

        inspect_controls = ttk.Frame(body, style='Lab.TFrame')
        inspect_controls.grid(row=5, column=0, sticky='ew', pady=(dp(15), dp(0)))
        inspect_controls.columnconfigure(0, weight=1)
        self.inspect_help = ttk.Label(inspect_controls, style='Muted.TLabel', font='LabSmall', wraplength=dp(570))
        self.inspect_help.grid(row=0, column=0, sticky='w', padx=(dp(0), dp(16)))
        self.inspect_btn = ttk.Button(inspect_controls, style='Primary.TButton', command=self.inspect_selected, state='disabled')
        self.inspect_btn.grid(row=0, column=1, sticky='e')
        ttk.Label(body, textvariable=self.status, style='Muted.TLabel', font='LabSmall', anchor='w').grid(row=6, column=0, sticky='ew', pady=(dp(10), dp(0)))

    def _translate(self):
        t = self.i18n.t
        self.title_lbl.configure(text=t('app_title'))
        self.subtitle_lbl.configure(text=t('workspace_subtitle'))
        self.choose_btn.configure(text=t('choose_folder'))
        self.scan_btn.configure(text=t('scan'))
        self.recursive_chk.configure(text=t('recursive'))
        self.compare_btn.configure(text=t('compare_two_photos'))
        self.lang_lbl.configure(text=t('language'))
        self.lang_combo.configure(values=(t('english'), t('korean')))
        self.display_lang.set(t('korean') if self.i18n.language == 'ko' else t('english'))
        for label, key in self._labels:
            label.configure(text=t(key))
        for key, (label, _) in self.summary_vars.items():
            label.configure(text=t(key))
        for column, key in [('type', 'type'), ('confidence', 'matching_confidence'), ('original', 'original'), ('edited', 'edited')]:
            self.tree.heading(column, text=t(key))
        for row, pair in self._row_pairs.items():
            if 'manual_selection' in pair.reasons:
                self.tree.set(row, 'confidence', t('pair_manual_match'))
        self.inspect_btn.configure(text=t('inspect_pair'))
        self._update_empty_state()
        self._selection_changed()
        self.status.set(t(self._status_key, **self._status_kwargs))
        for inspector in list(self._inspectors):
            if inspector.winfo_exists():
                inspector.translate()
            else:
                self._inspectors.remove(inspector)

    def change_language(self, _evt=None):
        if _evt is not None:
            language = 'ko' if self.display_lang.get() == self.i18n.t('korean') else 'en'
            self.lang.set(language)
        language = self.lang.get()
        self.i18n.load(language)
        self.settings['language'] = language
        save_settings(self.settings)
        self._translate()

    def choose_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.folder.set(folder)

    def choose_pair(self):
        """Let the user choose a known pair without naming or folder heuristics."""
        filetypes = [(self.i18n.t('jpeg_files'), ('*.jpg', '*.jpeg', '*.JPG', '*.JPEG'))]
        original = filedialog.askopenfilename(parent=self, title=self.i18n.t('choose_original_photo'), filetypes=filetypes)
        if not original:
            return
        edited = filedialog.askopenfilename(parent=self, title=self.i18n.t('choose_edited_photo'), filetypes=filetypes)
        if not edited:
            return
        original_path, edited_path = Path(original).resolve(), Path(edited).resolve()
        if original_path == edited_path:
            messagebox.showwarning(self.i18n.t('error'), self.i18n.t('same_photo_warning'), parent=self)
            return
        if any(not path.is_file() or path.suffix.lower() not in JPEG_EXTENSIONS for path in (original_path, edited_path)):
            messagebox.showwarning(self.i18n.t('error'), self.i18n.t('choose_jpeg_warning'), parent=self)
            return
        pair = PairCandidate(original_path, edited_path, 'JPG+JPG', 1.0, ['manual_selection'])
        self._open_inspector(pair)

    def _update_empty_state(self):
        if self._row_pairs:
            self.empty_state.grid_remove()
            self.tree.grid()
            self.table_scroll.grid()
            return
        self.tree.grid_remove()
        self.table_scroll.grid_remove()
        self.empty_state.grid(row=0, column=0, columnspan=2, sticky='nsew')
        if self._scanning:
            title_key, hint_key = 'scan_in_progress', 'folder_hint'
        elif self._has_scanned:
            title_key, hint_key = 'pairs_empty_title', 'pairs_empty_hint'
        else:
            title_key, hint_key = 'library_empty_title', 'library_empty_hint'
        self.empty_title.configure(text=self.i18n.t(title_key))
        self.empty_hint.configure(text=self.i18n.t(hint_key))

    def _set_status(self, key, **kwargs):
        self._status_key, self._status_kwargs = key, kwargs
        self.status.set(self.i18n.t(key, **kwargs))

    def start_scan(self):
        if self._scanning:
            return
        folder_text = self.folder.get().strip()
        path = Path(folder_text).expanduser().resolve()
        if not folder_text or not path.is_dir():
            messagebox.showwarning(self.i18n.t('error'), self.i18n.t('folder_not_selected'), parent=self)
            return
        recursive = self.recursive.get()
        db_path = app_data_dir() / DB_FILENAME
        self._scanning = True
        self._has_scanned = False
        self.summary_frame.grid_remove()
        self.progress_track.grid()
        for widget in (self.scan_btn, self.choose_btn, self.folder_entry, self.recursive_chk):
            widget.configure(state='disabled')
        self.progress.set(0)
        self._row_pairs.clear()
        for row in self.tree.get_children():
            self.tree.delete(row)
        self._selection_changed()
        self._update_empty_state()
        self._set_status('scan_pending')
        # The worker owns only a queue and plain values, never the Tk root.
        state = SimpleNamespace(_events=self._events)
        worker = threading.Thread(target=App._scan_worker, args=(state, path, recursive, db_path), daemon=True)
        self._worker_threads = [thread for thread in self._worker_threads if thread.is_alive()]
        self._worker_threads.append(worker)
        worker.start()

    def _scan_worker(self, folder: Path, recursive: bool, db_path: Path):
        try:
            def progress(index, total, name):
                self._events.put(('progress', index / total * 100, name))
            records = scan_folder(folder, recursive, progress)
            pairs = find_pairs(records)
            summary = summarize(records, pairs)
            db = LibraryDB(db_path)
            try:
                db.replace_scan(records, pairs)
            finally:
                db.close()
            self._events.put(('results', summary, pairs, db_path))
        except Exception as exc:
            # Copy the exception while it is still in scope; never defer its closure.
            self._events.put(('error', str(exc)))
        finally:
            self._events.put(('finished',))

    def _poll(self):
        if self._closed:
            return
        while True:
            try:
                event = self._events.get_nowait()
            except queue.Empty:
                break
            if event[0] == 'progress':
                self.progress.set(event[1])
                self._set_status('scanning', name=event[2])
            elif event[0] == 'results':
                self._show_results(*event[1:])
            elif event[0] == 'error':
                self._set_status('scan_error')
                messagebox.showerror(self.i18n.t('error'), self.i18n.t('scan_error_detail', detail=event[1]), parent=self)
            elif event[0] == 'finished':
                self._scanning = False
                self.progress_track.grid_remove()
                for widget in (self.scan_btn, self.choose_btn, self.folder_entry, self.recursive_chk):
                    widget.configure(state='normal')
                self._selection_changed()
                self._update_empty_state()
        self._poll_id = self.after(60, self._poll)

    def _show_results(self, summary, pairs, db_path):
        self._has_scanned = True
        self.summary_frame.grid()
        values = {
            'total': summary.total_files, 'raw': summary.raw, 'jpg': summary.jpg,
            'other_images': summary.other_images, 'xmp': summary.xmp,
            'raw_xmp': summary.raw_xmp_pairs, 'raw_jpg': summary.raw_jpg_pairs,
            'jpg_jpg': summary.jpg_jpg_pairs, 'edited_only': summary.edited_only,
        }
        for key, value in values.items():
            self.summary_vars[key][1].configure(text=str(value))
        for index, pair in enumerate(pairs[:2000]):
            row = self.tree.insert('', 'end', values=(pair.pair_type, f'{pair.confidence * 100:.0f}%', pair.original.name, pair.edited.name), tags=('even' if index % 2 == 0 else 'odd',))
            self._row_pairs[row] = pair
        self.progress.set(100)
        self._update_empty_state()
        self._set_status('status_scan_complete', count=len(pairs))

    def _selected_pair(self):
        selection = self.tree.selection()
        return self._row_pairs.get(selection[0]) if selection else None

    @staticmethod
    def _inspectable(pair):
        return bool(pair and pair.pair_type == 'JPG+JPG' and pair.original.suffix.lower() in JPEG_EXTENSIONS and pair.edited.suffix.lower() in JPEG_EXTENSIONS)

    def _selection_changed(self, _evt=None):
        pair = self._selected_pair()
        enabled = self._inspectable(pair) and not self._scanning
        self.inspect_btn.configure(state='normal' if enabled else 'disabled')
        key = 'select_pair' if pair is None else 'inspect_hint' if self._inspectable(pair) else 'jpg_first_notice'
        self.inspect_help.configure(text=self.i18n.t(key))

    def _double_click(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            self.inspect_selected()

    def inspect_selected(self):
        pair = self._selected_pair()
        if pair is None or self._scanning:
            return
        if not self._inspectable(pair):
            messagebox.showinfo(self.i18n.t('inspector_title'), self.i18n.t('jpg_first_notice'), parent=self)
            return
        self._open_inspector(pair)

    def _open_inspector(self, pair):
        if 'manual_selection' in pair.reasons:
            paths = (pair.original.resolve(), pair.edited.resolve())
            row = next((row for row, existing in self._row_pairs.items()
                        if (existing.original.resolve(), existing.edited.resolve()) == paths), None)
            if row is None:
                row = self.tree.insert('', 'end', values=(pair.pair_type, self.i18n.t('pair_manual_match'), pair.original.name, pair.edited.name), tags=('even' if len(self._row_pairs) % 2 == 0 else 'odd',))
            else:
                self.tree.set(row, 'confidence', self.i18n.t('pair_manual_match'))
            self._row_pairs[row] = pair
            self._update_empty_state()
            self.tree.selection_set(row)
            self.tree.focus(row)
            self.tree.see(row)
            self._selection_changed()
        inspector = PairInspector(self, pair, self.i18n)
        self._inspectors.append(inspector)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self.after_cancel(self._poll_id)
        for inspector in list(self._inspectors):
            if inspector.winfo_exists():
                inspector.close()
        super().destroy()
        # Destroying widgets alone leaves Python widget/variable -> root cycles.
        # Break our ownership on this thread before later analysis triggers GC.
        for name in ('folder', 'recursive', 'lang', 'display_lang', 'progress', 'status'):
            setattr(self, name, None)
        for name in (
            'title_lbl', 'subtitle_lbl', 'choose_btn', 'folder_entry',
            'recursive_chk', 'scan_btn', 'lang_lbl', 'lang_combo', 'summary_frame',
            'tablebox', 'tree', 'inspect_btn', 'inspect_help',
            'compare_btn', 'empty_state', 'empty_title', 'empty_hint',
            'table_scroll', 'progress_track',
        ):
            setattr(self, name, None)
        self.summary_vars.clear()
        self._labels.clear()
        self._inspectors.clear()
        self._worker_threads.clear()

    def destroy(self):
        self.close()


def run():
    app = App()
    try:
        app.mainloop()
    finally:
        if not app._closed:
            app.close()
