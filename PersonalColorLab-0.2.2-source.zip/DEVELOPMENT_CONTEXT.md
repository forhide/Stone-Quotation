# Development Context

Project: Personal Color Lab
Current baseline: V0.2.2 readable guided JPEG comparison desktop with offline Windows/macOS installers
Platform scope: desktop; mobile development is not currently planned

## Locked product decisions

- Fully offline after installation; no external AI/API, HTTP runtime client, login, telemetry, analytics, or photo upload.
- English default UI; Korean selectable through locale resources.
- Original photos are never destructively modified; GPS coordinates are not persisted.
- Final edit output should favor Lightroom-compatible XMP. V0.2 analyzes images and does not export edits yet.
- Image transforms are evidence; Lightroom-like estimates are approximate unless actually sourced from XMP.
- Preserve separate pairing, registration, and estimate confidence and inferred provenance.
- Future styles include My Style, Custom Reference Style, Built-in Style Library, and Hybrid Style through common Style DNA.
- Bundles cover film, cinema/drama, and artist/director/cinematographer tendencies using derived profiles rather than copied source images.
- Film profiles generally cover color/tone/grain. Composition-capable styles must offer color only, suggestions, or automatic application; never silently crop.
- Scene classification is multilabel. Future inference is local with mandatory CPU fallback.

## Implemented boundary

The primary workflow is **Compare two photos**: choose an original JPEG and its edited version directly, confirm the labeled side-by-side previews, then read the local comparison. Matching filenames, a shared folder, and scanning are optional. Directly chosen pairs are deduplicated in the current session's table and labeled **Chosen by you**, allowing comparisons to reopen without another file selection. Folder scanning remains available for larger collections; JPEG candidates open by button, double-click, or Enter. The dark graphite/lime desktop includes three-step guidance, useful empty states, and a bundled aperture app/installer icon.

The inspector opens **Changes at a glance** by default, with plain-language brightness/color/shared-area cards and a measured tone-transfer curve. **Detailed measurements** retains alignment, tone/Lab/HSV/HSL evidence, confidence, and approximate estimates. Failed alignment, unreadable ICC profiles/files, and stale results present recovery guidance while withholding unverifiable measurements and curves. Dedicated hue-band visualization remains planned.

V0.2.2 increases small text to 10 points and measurement text to 11 points and strengthens secondary contrast. `ui/display.py` initializes Windows per-monitor-v2 DPI awareness before Tk, falls back when needed, and respects an already-configured process. The initial window's DPI controls positive point-sized fonts and scaled spacing. macOS retains `NSHighResolutionCapable`, bundled Tk 9 native Retina rendering, and Cocoa logical coordinates; the theme uses the native `TkDefaultFont` system family. Native Windows/macOS DPI/Retina rendering and monitor-transition behavior have not been verified. Larger text/display scales may require a larger usable viewport. Repetitive Offline Only, sidebar privacy, and inspector original-file notices were removed from the UI; offline behavior, file preservation, warnings, and provenance remain intact.

`core/edit_reverse.analyze_pair` reads EXIF-oriented local JPGs, attempts modest similarity registration, and computes tone/Lab/HSV/HSL and WB/tint evidence over valid overlap. Failed alignment produces no color/tone estimates. Malformed or unsupported embedded ICC profiles produce `color_space_uncertain`, preserving inspectable geometry while withholding photometric estimates. Exposure EV and WB/tint directions are approximate.

The payload records source SHA-256 hashes, inferred provenance, algorithm/payload versions, registration confidence, and task-specific confidence/limitations. Overall confidence measures `registered_tone_color_evidence` using registration and sample support, not exposure/WB certainty. Exposure and WB/tint estimates have separate weighted confidence. App version 0.2.2 keeps analysis algorithm version 0.2.0 and payload/database schema 1; compatible saved analyses remain valid. SQLite migration is additive and preserves V0.1 rows. The inspector supports previews, swap, compare again, persistence, and source-hash cache invalidation; detailed tone/HSV/HSL/hue-band data remain in the saved payload.

Python 3.11+, Tkinter, Pillow, NumPy, and headless OpenCV are the source-run requirements. pytest is development-only. Runtime/development lockfiles pin the Python 3.12/Linux versions; range files support intentional updates. `PERSONAL_COLOR_LAB_DATA_DIR` can place runtime data in a writable local directory. No photo library duplication, mobile SDK, web server, or GPU is needed.

## Validation and remaining work

Synthetic tests cover geometric/tone/color transforms, rejected pairs, invalid ICC profiles, persistence, finite output, cache freshness, file preservation, direct JPEG selection, summaries, UI recovery states, and display-scaling logic. `VALIDATION.md` records completed commands, final counts, rendering checks, and limitations. Headless tests use `tools/run_gui_tests.py` with Xvfb. The prepared cloud desktop uses `.venv-desktop` (system Python 3.13/Tk 8.6) for legible CJK fonts; the default Tk 9 build lacks that font backend. Do not infer Windows/macOS readiness from Linux validation.

Offline Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg artifacts contain private CPython 3.13.16/Tcl-Tk, verified pinned native wheels and license notices. Python/pip installation is not required on target machines. Install/update/remove preserve the existing data directory. Build-time downloaders and pip are excluded. --self-test uses synthetic JPGs and temporary SQLite; locales work from arbitrary launch directories. Native installed-artifact smoke tools and manual CI are included but native CI has not run. See INSTALLERS.md and VALIDATION.md for version-specific platform limits and Wine evidence. The authorized download-only branch in `forhide/Stone-Quotation` is a delivery destination; the extracted Personal Color Lab source has no Git remote and its native installer workflow has not been run there.

Current limits include heuristic confidence, modest similarity transforms, filename pairing ambiguity, ICC/sRGB assumptions, and no general perspective/local-edit analysis. Next priorities are native release validation/signing, real-photo evaluation, hue-band presentation, pairing improvements, confidence calibration, and only then RAW decoding/XMP expansion. Style DNA and application/export remain planned.

## Continuity rule

After each meaningful milestone, update this file, `CHANGELOG.md`, `TODO.md`, `ROADMAP.md`, and tests before packaging a release. See `CODEX_HANDOFF.md` for interfaces and product decisions.
