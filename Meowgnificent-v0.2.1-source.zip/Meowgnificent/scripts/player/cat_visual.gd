class_name WizardCatVisual
extends Node2D

const ACTION_SHEET: Texture2D = preload("res://art/characters/actions.png")
# Six distinct full-body key poses; small margins keep neighboring cells out.
const POSE_RECTS: Array[Rect2i] = [Rect2i(70,10,390,490),Rect2i(552,2,440,500),Rect2i(1034,40,500,460),Rect2i(22,516,490,475),Rect2i(562,528,445,455),Rect2i(1068,550,444,430)]
const COLS := 6
const ROWS := 9
var cat: WizardCat
var sprite: Polygon2D
var elapsed := 0.0
var active_pose := 0
var gait := 0.0
var pose_age := 0.0

func _ready() -> void:
	cat=get_parent() as WizardCat
	sprite=Polygon2D.new()
	sprite.texture=ACTION_SHEET
	var triangles: Array[PackedInt32Array]=[]
	for y in range(ROWS):
		for x in range(COLS):
			var a := y*(COLS+1)+x
			triangles.append(PackedInt32Array([a,a+1,a+COLS+1]))
			triangles.append(PackedInt32Array([a+1,a+COLS+2,a+COLS+1]))
	sprite.polygons=triangles
	var shader := Shader.new()
	# Remove barely-visible edge haze while preserving fur and inherited hit flashes.
	shader.code="shader_type canvas_item; void fragment(){ COLOR.a *= smoothstep(0.03,0.18,COLOR.a); }"
	var material := ShaderMaterial.new()
	material.shader=shader
	sprite.material=material
	add_child(sprite)
	update_mesh()

func choose_pose() -> int:
	if cat.roll_time>0: return 5
	if cat.hit_reaction>0 or cat.health.current<=0: return 4
	if cat.cast_prepare>0: return 1
	if cat.cast_pose>0:
		return 3 if cat.cast_outcome!="success" else 2
	return 0

func _process(delta: float) -> void:
	var animating := cat.active or cat.presentation_scale>1.0
	if animating:
		elapsed+=delta
		gait=move_toward(gait,clampf(cat.velocity.length()/float(cat.config.speed),0,1),delta*7)
		pose_age+=delta
	var next := choose_pose()
	if next!=active_pose:
		active_pose=next
		pose_age=0
	scale=Vector2.ONE*cat.presentation_scale
	if cat.roll_time>0:
		position=Vector2(0,-36)
		rotation=cat.roll_spin
	else:
		position=Vector2.ZERO
		rotation=sin(cat.wobble)*0.055*gait
		if active_pose==1: rotation-=cat.cast_aim.x*0.09
		if active_pose==2: rotation+=cat.cast_aim.x*0.12*cat.cast_pose
		if active_pose==3: rotation-=cat.cast_aim.x*0.16*cat.cast_pose
		if active_pose==4: rotation+=sin(elapsed*37)*0.07*minf(1,cat.hit_reaction*4)
	update_mesh()
	queue_redraw()

func update_mesh() -> void:
	var rect := POSE_RECTS[active_pose]
	var factor := float(cat.config.get("sprite_height",168.0))*0.86/490.0
	if active_pose==5: factor*=0.78
	var width := rect.size.x*factor
	var height := rect.size.y*factor
	var vertices := PackedVector2Array()
	var coordinates := PackedVector2Array()
	var flip := -1.0 if active_pose in [1,2,3] and cat.cast_aim.x<0 else 1.0
	for row in range(ROWS+1):
		for col in range(COLS+1):
			var u := float(col)/COLS
			var v := float(row)/ROWS
			var p := Vector2((u-0.5)*width,(v-1.0)*height+9)
			if active_pose==5:
				p.y=(v-0.5)*height
			else:
				# The belly compresses, shoulders swing and the hat lags behind each step.
				var belly := sin(v*PI)
				var step := sin(cat.wobble)
				p.x*=1+belly*(0.018*sin(elapsed*2.8)+0.045*absf(step)*gait)
				p.x+=step*3.2*gait*(1-v)+sin(cat.wobble-0.9)*2.5*gait*pow(1-v,3)
				p.y-=absf(step)*3.0*gait*(1-v)
				p.y+=sin(elapsed*2.8)*1.3*belly
				if active_pose==1:
					p.x*=1+0.05*belly
					p.y+=sin(v*PI)*3.0
				elif active_pose==2:
					p.x+=(1-v)*4.0*cat.cast_pose
				elif active_pose==3:
					p.x-=(1-v)*5.0*cat.cast_pose
			p.x*=flip
			vertices.append(p)
			coordinates.append(Vector2(rect.position)+Vector2(u*rect.size.x,v*rect.size.y))
	sprite.polygon=vertices
	sprite.uv=coordinates

func _draw() -> void:
	if cat==null or cat.roll_time>0: return
	var charging := cat.cast_prepare>0
	if charging or cat.cast_pose>0.05:
		var power := 0.65 if charging else cat.cast_pose
		var point := Vector2(38 if cat.cast_aim.x>=0 else -38,-75)
		draw_circle(point,16,Color(1,0.7,0.3,power*0.16))
		draw_circle(point,4,Color(1,0.86,0.5,power*0.75))
