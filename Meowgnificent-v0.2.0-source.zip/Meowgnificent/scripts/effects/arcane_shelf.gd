class_name ArcaneShelf
extends Node2D

var room: Node2D
var state := "standing"
var timer := 0.0
var fall_direction := Vector2.DOWN
var burning := false
var collapsed := false

func ignite(direction: Vector2) -> void:
	if state!="standing":
		return
	state="burning"
	burning=true
	timer=1.15
	fall_direction=direction.normalized() if direction.length_squared()>0.01 else Vector2.DOWN
	room.tell("The books are on fire. Mind the falling shelf!",Color("ffbd7a"))

func topple(direction: Vector2) -> void:
	if state=="fallen" or state=="falling":
		return
	state="falling"
	timer=0.35
	fall_direction=direction.normalized() if direction.length_squared()>0.01 else Vector2.DOWN
	room.tell("Not a spell. Still effective.",Color("d9d7a4"))

func footprint(point: Vector2) -> bool:
	var offset := point-position
	return offset.dot(fall_direction)>-25 and offset.dot(fall_direction)<145 and absf(offset.cross(fall_direction))<48

func collapse() -> void:
	if collapsed: return
	collapsed=true
	state="fallen"
	room.shake=8
	for enemy in room.enemies.duplicate():
		if is_instance_valid(enemy) and footprint(enemy.position):
			enemy.take_damage(48,fall_direction)
	if footprint(room.player.position):
		room.player.take_damage(18,position)
	room.effects.append({"point":position+fall_direction*65,"age":0.0,"radius":80.0,"color":Color("d8bc8c")})
	if burning:
		room.ignite_floor(position+fall_direction*65)
	room.tell("A scholarly approach to flattening enemies.",Color("e4d1a3"))

func _process(delta: float) -> void:
	if room.state!="playing": return
	if state=="burning" or state=="falling":
		timer-=delta
		if timer<=0:
			if state=="burning":
				state="falling"
				timer=0.35
			else: collapse()
	queue_redraw()

func _draw() -> void:
	if state=="burning" or state=="falling":
		var side := fall_direction.orthogonal()*45
		draw_colored_polygon(PackedVector2Array([side,-side,fall_direction*145-side,fall_direction*145+side]),Color(1,0.52,0.24,0.20))
		draw_line(Vector2.ZERO,fall_direction*145,Color("ffbd7a"),2,true)
	if state=="fallen":
		draw_set_transform(fall_direction*57,fall_direction.angle()-PI*0.5)
		draw_rect(Rect2(-40,-64,80,125),Color("433332"))
		for i in range(9):
			var at := Vector2(sin(i*8.0)*31,cos(i*9.0)*49)
			draw_set_transform(fall_direction*57+at,i*0.7)
			draw_rect(Rect2(-9,-6,18,12),[Color("9e737b"),Color("819e99"),Color("c4ad7a")][i%3])
		draw_set_transform(Vector2.ZERO)
		return
	var tilt := sin(timer*23)*0.035 if state=="burning" else (1-timer/0.35)*0.7 if state=="falling" else 0.0
	draw_set_transform(Vector2.ZERO,tilt)
	draw_rect(Rect2(-39,-68,78,72),Color("533e3b"))
	draw_rect(Rect2(-34,-63,68,63),Color("292731"))
	for row in range(2):
		for i in range(6):
			var colors := [Color("ba858b"),Color("91ada1"),Color("c2ac80"),Color("8e91b6")]
			draw_rect(Rect2(-30+i*10,-58+row*31,8,24-(i%3)*3),colors[(i+row)%4])
		draw_line(Vector2(-37,-29+row*31),Vector2(37,-29+row*31),Color("b19472"),4)
	draw_set_transform(Vector2.ZERO)
	if burning:
		for i in range(5):
			var p := Vector2(-28+i*14,-35-absf(sin(timer*8+i))*25)
			draw_circle(p,12,Color(1,0.34,0.16,0.6))
			draw_circle(p+Vector2(0,4),6,Color("ffdf8a"))
	if state=="standing":
		draw_string(ThemeDB.fallback_font,Vector2(-30,20),"FLAMMABLE",HORIZONTAL_ALIGNMENT_LEFT,-1,10,Color("cab58c"))
