class_name WizardCatVisual
extends Node2D

const CAT_TEXTURE: Texture2D = preload("res://art/characters/meowgnificent.png")
var cat: WizardCat
var sprite: Sprite2D
var elapsed := 0.0

func _ready() -> void:
	cat = get_parent() as WizardCat
	# Keep the head/hat proportions; shorten only the torso below the collar.
	var used := CAT_TEXTURE.get_image().get_used_rect()
	var split := int(used.size.y * 0.50)
	var factor := float(cat.config.get("sprite_height",168.0)) / used.size.y
	var body_height := (used.size.y-split)*factor*0.70
	for part in range(2):
		var image := Sprite2D.new()
		var atlas := AtlasTexture.new()
		atlas.atlas = CAT_TEXTURE
		var top := 0 if part==0 else split
		var h := split if part==0 else used.size.y-split
		atlas.region = Rect2(used.position+Vector2i(0,top),Vector2i(used.size.x,h))
		image.texture = atlas
		image.centered = false
		image.scale = Vector2(factor*1.06,factor*(1.0 if part==0 else 0.70))
		image.position = Vector2(-used.size.x*factor*1.06*0.5,9.0-body_height-(split*factor if part==0 else 0.0))
		add_child(image)
		if part==0: sprite=image

func _process(delta: float) -> void:
	elapsed += delta
	var speed_ratio := clampf(cat.velocity.length() / float(cat.config.speed),0.0,1.0)
	var bob := sin(cat.wobble)*2.0*speed_ratio + sin(elapsed*2.3)*0.45
	position = Vector2(0,bob)
	rotation = sin(cat.wobble)*0.035*speed_ratio
	if cat.roll_time>0:
		rotation += cat.roll_spin
		position.y -= 36
		# Rotate around the belly instead of swinging the whole cat around its feet.
		for image in get_children():
			image.position.y += 65 if not image.has_meta("rolling") else 0
			image.set_meta("rolling",true)
	else:
		for image in get_children():
			if image.has_meta("rolling"):
				image.position.y -= 65
				image.remove_meta("rolling")
	scale = Vector2(1+cat.cast_pose*0.04,1-cat.cast_pose*0.025)*cat.presentation_scale
	queue_redraw()

func _draw() -> void:
	# A small light at the staff is a casting hook; the illustrated staff remains intact.
	if cat != null and cat.cast_pose>0.05:
		var point := Vector2(-47,-67)
		draw_circle(point,13,Color(1,0.7,0.3,cat.cast_pose*0.15))
		draw_circle(point,4,Color(1,0.86,0.5,cat.cast_pose*0.7))
