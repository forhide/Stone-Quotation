"""Black-box desktop release test using X11 events, screenshots, and OCR."""
import argparse, csv, ctypes, io, json, os, pathlib, re, subprocess, time
from PIL import ImageGrab, Image, ImageOps
os.environ.setdefault('OMP_THREAD_LIMIT','1')
p=argparse.ArgumentParser();p.add_argument('--platform',choices=['linux','windows'],required=True);p.add_argument('--release',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True)
a=p.parse_args();a.output=a.output.resolve();a.release=a.release.resolve();a.output.mkdir(parents=True,exist_ok=True)
x=ctypes.CDLL('libX11.so.6');xt=ctypes.CDLL('libXtst.so.6')
x.XOpenDisplay.argtypes=[ctypes.c_char_p];x.XOpenDisplay.restype=ctypes.c_void_p
x.XStringToKeysym.argtypes=[ctypes.c_char_p];x.XStringToKeysym.restype=ctypes.c_ulong
x.XKeysymToKeycode.argtypes=[ctypes.c_void_p,ctypes.c_ulong];x.XKeysymToKeycode.restype=ctypes.c_uint
x.XSetInputFocus.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];x.XFlush.argtypes=[ctypes.c_void_p]
xt.XTestFakeKeyEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong];xt.XTestFakeMotionEvent.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_ulong]
xt.XTestFakeButtonEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong]
class XMessageData(ctypes.Union):
 _fields_=[('b',ctypes.c_char*20),('s',ctypes.c_short*10),('l',ctypes.c_long*5)]
class XMessage(ctypes.Structure):
 _fields_=[('type',ctypes.c_int),('serial',ctypes.c_ulong),('send_event',ctypes.c_int),('display',ctypes.c_void_p),('window',ctypes.c_ulong),('message_type',ctypes.c_ulong),('format',ctypes.c_int),('data',XMessageData)]
class XEvent(ctypes.Union):
 _fields_=[('message',XMessage),('padding',ctypes.c_long*24)]
x.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];x.XInternAtom.restype=ctypes.c_ulong
x.XSendEvent.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_long,ctypes.POINTER(XEvent)]
d=x.XOpenDisplay(b':77');assert d,'X11 unavailable';held=set();results=[]
def close_window(window):
 event=XEvent();event.message.type=33;event.message.display=d;event.message.window=window
 event.message.message_type=x.XInternAtom(d,b'WM_PROTOCOLS',0);event.message.format=32
 event.message.data.l[0]=x.XInternAtom(d,b'WM_DELETE_WINDOW',0);event.message.data.l[1]=0
 x.XSendEvent(d,window,0,0,ctypes.byref(event));x.XFlush(d)
def down(name):
 xt.XTestFakeKeyEvent(d,x.XKeysymToKeycode(d,x.XStringToKeysym(name.encode())),1,0);x.XFlush(d);held.add(name)
def up(name):
 xt.XTestFakeKeyEvent(d,x.XKeysymToKeycode(d,x.XStringToKeysym(name.encode())),0,0);x.XFlush(d);held.discard(name)
def key(name):down(name);time.sleep(.04);up(name)
def aim(q):xt.XTestFakeMotionEvent(d,0,int(q[0]),int(q[1]),0);x.XFlush(d)
def click(q):
 aim(q);xt.XTestFakeButtonEvent(d,1,1,0);x.XFlush(d);time.sleep(.05);xt.XTestFakeButtonEvent(d,1,0,0);x.XFlush(d)
def screenshot(name):
 im=ImageGrab.grab(xdisplay=':77').crop((0,0,1280,800));path=a.output/(name+'.png');im.save(path);return im,path
def ocr(name):
 _,path=screenshot(name);return subprocess.run(['tesseract',str(path),'stdout','--psm','11'],capture_output=True,text=True,check=True).stdout.lower()
def equipment_feedback():
 im,_=screenshot('inventory-equipped')
 region=ImageOps.invert(im.crop((120,655,790,712)).convert('L'))
 path=a.output/'inventory-equipped-feedback.png';region.resize((region.width*3,region.height*3)).save(path)
 return subprocess.run(['tesseract',str(path),'stdout','--psm','6'],capture_output=True,text=True,check=True).stdout.lower()
def find_word(word,name,minimum_x=0):
 im,_=screenshot(name)
 # Small light button text needs contrast separation from the dark UI.
 # OCR still locates the real button; coordinates are mapped back to the screen.
 left=max(0,minimum_x);top=200;zoom=3
 region=ImageOps.invert(im.crop((left,top,1200,670)).convert('L'))
 region=region.point(lambda value:0 if value<130 else 255)
 # Tesseract otherwise treats outlined controls as table cells and skips text.
 pixels=region.load();points={(x,y) for y in range(region.height) for x in range(region.width) if pixels[x,y]==0}
 while points:
  todo=[points.pop()];component=[]
  while todo:
   q=todo.pop();component.append(q)
   for neighbor in [(q[0]-1,q[1]),(q[0]+1,q[1]),(q[0],q[1]-1),(q[0],q[1]+1)]:
    if neighbor in points:points.remove(neighbor);todo.append(neighbor)
  xs=[q[0] for q in component];ys=[q[1] for q in component]
  if max(xs)-min(xs)>65 or max(ys)-min(ys)>24:
   for q in component:pixels[q]=255
 path=a.output/(name+'-text.png')
 region.resize((region.width*zoom,region.height*zoom)).save(path)
 tsv=subprocess.run(['tesseract',str(path),'stdout','--psm','6','tsv'],capture_output=True,text=True,check=True).stdout
 for row in csv.DictReader(io.StringIO(tsv),delimiter='\t'):
  if row['text'].strip().lower()!=word.lower() or float(row['conf'])<35:continue
  q=(left+(int(row['left'])+int(row['width'])/2)/zoom,top+(int(row['top'])+int(row['height'])/2)/zoom)
  if q[0]>=minimum_x and 200<q[1]<670:return q
 return None
def check(ok,name):
 results.append({'check':name,'passed':bool(ok)});print(('PASS: ' if ok else 'FAIL: ')+name,flush=True);assert ok,name

def targets(im):
 pixels=im.load();points=set();centers=[]
 # Detailed faces/armor split the solid color into smaller patches.
 # Sample at 2px so the combat bot still sees every enemy role.
 for gy in range(100,328):
  for gx in range(72,576):
   r,g,b=pixels[gx*2,gy*2][:3]
   if (120<r<180 and g>r+35 and b>r+8 and g>180) or (abs(r-110)<7 and abs(g-102)<7 and abs(b-139)<7) or (abs(r-126)<7 and abs(g-155)<7 and abs(b-164)<7):points.add((gx,gy))
 while points:
  todo=[points.pop()];component=[]
  while todo:
   q=todo.pop();component.append(q)
   for dy in [-1,0,1]:
    for dx in [-1,0,1]:
     z=(q[0]+dx,q[1]+dy)
     if z in points:points.remove(z);todo.append(z)
  if len(component)>4:centers.append((sum(q[0] for q in component)*2/len(component),sum(q[1] for q in component)*2/len(component)+12))
 return centers

env=os.environ.copy();env.update(DISPLAY=':77',XDG_CACHE_HOME=str(a.output/'cache'),XDG_DATA_HOME=str(a.output/'data'))
# Every run owns a fresh profile; the second process below reopens this exact file.
profile=a.output/'profiles'/('progress-%d.json'%time.time_ns());profile.parent.mkdir(exist_ok=True)
env['MEOW_PROFILE_PATH']='Z:'+str(profile).replace('/','\\') if a.platform=='windows' else str(profile)
exe=a.release/('Meowgnificent.exe' if a.platform=='windows' else 'Meowgnificent.x86_64');logs=[]
def launch(suffix=''):
 log=a.output/('engine'+suffix+'.log');output=a.output/('process'+suffix+'.log');logs.extend([log,output])
 flags=['--audio-driver','Dummy','--position','0,0','--resolution','1280x800','--max-fps','60','--log-file',str(log)]
 if a.platform=='windows':flags[-1]='Z:'+str(log).replace('/','\\');cmd=['/workspace/Meowgnificent/.local/wine-test.sh',str(exe),*flags]
 else:cmd=[str(exe),*flags]
 stream=output.open('w');return subprocess.Popen(cmd,cwd=a.release,env=env,stdout=stream,stderr=subprocess.STDOUT),stream
def await_menu(process,name):
 start=time.monotonic()
 while time.monotonic()-start<90:
  if process.poll() is not None:raise RuntimeError('Release exited at startup; see process.log')
  tree=subprocess.run(['xwininfo','-display',':77','-root','-tree'],capture_output=True,text=True,check=True).stdout
  ids=re.findall(r'(0x[0-9a-f]+) "Meowgnificent the wizard cat[^\"]*"',tree)
  if ids:
   window=int(ids[-1],16);x.XSetInputFocus(d,window,1,0);x.XFlush(d)
   if 'minor magical incident' in ocr(name):return window
  time.sleep(.2)
 return None
process,stdout=launch()
try:
 window=await_menu(process,'intro');check(window is not None,'extracted release renders expedition start menu')
 key('Return');time.sleep(.25);aim((1050,455));down('d');key('Shift_L');time.sleep(.12);up('d')
 roll_feedback=ocr('roll-input')
 check('roll' in roll_feedback and 'reco' in roll_feedback,'Shift plus movement performs a roll with recovery')
 key('Escape');time.sleep(.15)
 check('taking a catnap' in ocr('pause'),'Enter starts and Escape pauses executable')
 key('Return');time.sleep(.1);key('i');time.sleep(.15)
 inventory_text=ocr('inventory-empty')
 check('traveling possessions' in inventory_text,'I opens equipment and satchel panel')
 key('Escape');time.sleep(.1)
 check('traveling possessions' not in ocr('inventory-closed'),'Escape closes inventory and returns to combat')
 key('r');time.sleep(.4)
 check('minor magical incident' in ocr('restart'),'R restores clean start menu')
 key('Return');time.sleep(.15);key('F3');down('space');start=time.monotonic();cleared=False;next_victory_scan=0
 while time.monotonic()-start<70:
  # Books can share enemy colors, so check victory independently of targeting.
  if time.monotonic()>=next_victory_scan:
   if 'passage open' in ocr('tutorial-clear'):cleared=True;break
   next_victory_scan=time.monotonic()+1
  im,_=screenshot('combat');found=targets(im)
  if found:aim(min(found,key=lambda q:(q[0]-640)**2+(q[1]-455)**2));key('F3')
  time.sleep(.09)
 up('space');check(cleared,'aimed debug-overreaction combat opens tutorial passage')
 saved=json.loads(profile.read_text());earned_starlight=int(saved.get('starlight',0))
 check(earned_starlight>0 and int(saved.get('best_sector',0))>=1,'tutorial completion writes permanent Starlight to isolated profile')
 key('Return');time.sleep(.3)
 area_text=ocr('area02')
 check(re.search(r'area\s+0?2\s*[/|]\s*0?8',area_text) is not None or 'stacks of loose ends' in area_text,'Enter advances into area 02 without restarting expedition')
 key('i');time.sleep(.1);inventory_text=ocr('inventory-loot')
 crowns=re.search(r'(\d+)\s+crowns\b',inventory_text)
 check(crowns is not None and int(crowns.group(1))>0 and 'traveling possessions' in inventory_text,'room transition collects enemy Crowns and preserves them in inventory UI')
 equip_point=find_word('equip','inventory-equip-target',minimum_x=900)
 check(equip_point is not None,'enemy equipment drop offers an Equip button in the satchel')
 click(equip_point);time.sleep(.1)
 equipped_text=equipment_feedback()
 check(re.search(r'\bequipped\s+\w',equipped_text) is not None,'clicking dropped gear equips it in the release UI')
 key('Escape');time.sleep(.15);start=time.monotonic();defeated=False
 while time.monotonic()-start<90:
  if 'brief interruption' in ocr('defeat'):defeated=True;break
  time.sleep(.4)
 check(defeated,'next-area enemies defeat idle player')
 key('m');time.sleep(.1);legacy_text=ocr('legacy-after-defeat')
 check('legacy study' in legacy_text and 'starlight' in legacy_text,'M opens permanent legacy studies from defeat screen')
 key('Escape');key('r');time.sleep(.35)
 check('minor magical incident' in ocr('defeat-retry'),'R after defeat restores expedition start menu')
 key('m');time.sleep(.1);legacy_text=ocr('legacy-after-reload')
 check('legacy study' in legacy_text and re.search(r'\b%d\s+starlight\b'%earned_starlight,legacy_text) is not None,'legacy UI retains earned Starlight after room reload')
 key('Escape');close_window(window);process.wait(timeout=15);stdout.close()
 check(process.returncode==0,'first window close exits normally')
 before_reopen=json.loads(profile.read_text())
 process,stdout=launch('-reopened');window=await_menu(process,'intro-reopened')
 check(window is not None,'a fresh executable process reopens the saved profile')
 key('m');time.sleep(.1);legacy_text=ocr('legacy-reopened')
 check('legacy study' in legacy_text and re.search(r'\b%d\s+starlight\b'%earned_starlight,legacy_text) is not None,'fresh process displays retained Starlight in legacy studies')
 after_reopen=json.loads(profile.read_text())
 check(all(after_reopen.get(k)==before_reopen.get(k) for k in ['starlight','upgrades','attempts','best_sector']),'opening the saved profile preserves currency, upgrades and run history')
 key('Escape');close_window(window);process.wait(timeout=15)
 check(process.returncode==0,'reopened window close exits normally')
 text=''.join(path.read_text(errors='replace') for path in logs if path.exists())
 check('Godot Engine' in text and 'SCRIPT ERROR' not in text and 'ERROR:' not in text,'both sessions have no engine/script errors')
finally:
 for name in list(held):up(name)
 if process.poll() is None:process.terminate()
 try:process.wait(timeout=5)
 except subprocess.TimeoutExpired:process.kill();process.wait()
 stdout.close();(a.output/'results.json').write_text(json.dumps({'platform':a.platform,'scope':'tutorial combat, area02 transition, loot/equipment UI, defeat, permanent-profile reload; not full 8-area clear','profile':str(profile),'checks':results},indent=2))
