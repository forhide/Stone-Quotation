class_name ExpeditionMarkers
extends Node2D

const EXIT_POSITION := Vector2(1136,430)
const SHOP_POSITION := Vector2(640,315)
const GATE_CLOSED: Texture2D = preload("res://art/items/archive_gate_closed.svg")
const GATE_OPEN: Texture2D = preload("res://art/items/archive_gate_open.svg")
const MERCHANT_ART: Texture2D = preload("res://art/items/archive_merchant.svg")
const ROUTE_ART: Texture2D = preload("res://art/items/archive_route.svg")

var room: Node2D
var _signature := ""
var _stage_index := 0
var _sector_name := "The Candlewick Archives"
var _kind := "combat"
var _exit_open := false
var _exit_near := false
var _shop_near := false

func _ready() -> void:
	# The painted door and stall stand behind living actors.
	z_index=-2
	update_visuals()

func update_visuals() -> void:
	if not is_instance_valid(room) or room.run==null:
		return
	var stage_index := int(room.run.stage_index)
	var sector_name := str(room.stage_def.get("name","The Candlewick Archives"))
	var kind := str(room.stage_def.get("kind","combat"))
	var exit_open := bool(room.exit_open)
	var exit_near := false
	var shop_near := false
	if is_instance_valid(room.player):
		exit_near=room.player.position.distance_to(EXIT_POSITION)<86
		shop_near=room.player.position.distance_to(SHOP_POSITION)<105
	var signature := "%d|%s|%s|%s|%s|%s" % [stage_index,sector_name,kind,exit_open,exit_near,shop_near]
	if signature==_signature:
		return
	_signature=signature
	_stage_index=stage_index
	_sector_name=sector_name
	_kind=kind
	_exit_open=exit_open
	_exit_near=exit_near
	_shop_near=shop_near
	queue_redraw()

func _centered(text: String, at: Vector2, size: int, color: Color) -> void:
	var width := ThemeDB.fallback_font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
	draw_string(ThemeDB.fallback_font,at-Vector2(width*0.5,0),text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _draw() -> void:
	var gate := GATE_OPEN if _exit_open else GATE_CLOSED
	draw_texture_rect(gate,Rect2(EXIT_POSITION+Vector2(-52,-170),Vector2(104,178)),false)
	var prompt := "E  ·  Next area" if _exit_open else "Defeat foes to unlock"
	var color := Color("f4ddb1") if _exit_open else Color("aaa5a1")
	if _exit_open and _exit_near:
		color=Color("fff0c3")
	draw_style_box(_plate(Color(0.055,0.07,0.105,0.93)),Rect2(1041,449,190,32))
	_centered(prompt,Vector2(1136,470),13,color)
	if _exit_open and not _exit_near:
		_centered("ARCHIVE PASSAGE",Vector2(1136,493),10,Color("b6a080"))
	if _kind=="shop":
		draw_texture_rect(MERCHANT_ART,Rect2(SHOP_POSITION+Vector2(-112,-152),Vector2(224,179)),false)
		_centered("Nib's Curios",SHOP_POSITION+Vector2(0,-156),19,Color("f1d7a4"))
		draw_style_box(_plate(Color(0.055,0.07,0.105,0.94)),Rect2(535,351,210,33))
		_centered("E  ·  Browse shop",Vector2(640,373),15,Color("fff0c3") if _shop_near else Color("d2b98e"))
		_centered("A safe place for questionable purchases.",Vector2(640,409),13,Color("c0b6a4"))
	# One imported route texture replaces sixteen separate line/circle commands.
	draw_texture_rect(ROUTE_ART,Rect2(340,654,600,24),false)
	var current_x := 352+clampi(_stage_index,0,7)*(576.0/7.0)
	if _stage_index>0:
		draw_line(Vector2(352,666),Vector2(current_x,666),Color("cba66e"),2,true)
	draw_circle(Vector2(current_x,666),5,Color("e9c98d"))
	_centered("%02d / 08  ·  %s" % [_stage_index+1,_sector_name],Vector2(640,644),13,Color("dfcaab"))

func _plate(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color=color
	style.border_color=Color("8e7755")
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	return style
