class_name ArcaneShelf
extends Node2D

var room: Node2D
var state := "standing"
var timer := 0.0
var fall_direction := Vector2.DOWN
var burning := false
var collapsed := false
var body: Sprite2D
var flame: Sprite2D
var standing_texture: AtlasTexture
var fallen_texture: AtlasTexture

func _ready() -> void:
	var cache: SubViewport
	if room.has_meta("shelf_art_cache"):
		cache=room.get_meta("shelf_art_cache")
	else:
		cache=SubViewport.new()
		cache.size=Vector2i(960,320)
		cache.transparent_bg=true
		cache.disable_3d=true
		cache.render_target_update_mode=SubViewport.UPDATE_ONCE
		var painter := ShelfArt.new()
		painter.scale=Vector2(2,2)
		cache.add_child(painter)
		room.add_child(cache)
		room.set_meta("shelf_art_cache",cache)
	standing_texture=AtlasTexture.new()
	standing_texture.atlas=cache.get_texture()
	# Crop transparent margins so detailed art does not add a large blended quad.
	standing_texture.region=Rect2(56,42,208,236)
	fallen_texture=AtlasTexture.new()
	fallen_texture.atlas=cache.get_texture()
	fallen_texture.region=Rect2(320,0,320,320)
	body=Sprite2D.new()
	body.texture=standing_texture
	body.centered=true
	body.scale=Vector2(0.5,0.5)
	body.position=Vector2(0,-32)
	add_child(body)
	flame=Sprite2D.new()
	var fire_texture := AtlasTexture.new()
	fire_texture.atlas=cache.get_texture()
	fire_texture.region=Rect2(680,58,240,180)
	flame.texture=fire_texture
	flame.centered=true
	flame.scale=Vector2(0.5,0.5)
	flame.position=Vector2(0,-38)
	flame.visible=false
	add_child(flame)

func ignite(direction: Vector2) -> void:
	if state!="standing":
		return
	queue_redraw()
	state="burning"
	burning=true
	timer=1.15
	fall_direction=direction.normalized() if direction.length_squared()>0.01 else Vector2.DOWN
	room.tell("The books are on fire. Mind the falling shelf!",Color("ffbd7a"))

func topple(direction: Vector2) -> void:
	if state=="fallen" or state=="falling":
		return
	queue_redraw()
	state="falling"
	timer=0.35
	fall_direction=direction.normalized() if direction.length_squared()>0.01 else Vector2.DOWN
	room.tell("Not a spell. Still effective.",Color("d9d7a4"))

func footprint(point: Vector2) -> bool:
	var offset := point-position
	return offset.dot(fall_direction)>-25 and offset.dot(fall_direction)<145 and absf(offset.cross(fall_direction))<48

func collapse() -> void:
	if collapsed: return
	collapsed=true
	state="fallen"
	if is_instance_valid(body):
		body.texture=fallen_texture
		# Flat debris belongs below floor flames and the living actors.
		body.z_index=-1
		body.centered=true
		body.position=fall_direction*57
		body.rotation=fall_direction.angle()-PI*0.5
		flame.hide()
	room.shake=8
	for enemy in room.enemies.duplicate():
		if is_instance_valid(enemy) and footprint(enemy.position):
			enemy.take_damage(48,fall_direction)
	if footprint(room.player.position) and not room.exit_open:
		room.player.take_damage(18,position)
	room.effects.append({"point":position+fall_direction*65,"age":0.0,"radius":80.0,"color":Color("d8bc8c")})
	if burning:
		room.ignite_floor(position+fall_direction*65)
	room.tell("A scholarly approach to flattening enemies.",Color("e4d1a3"))

func _process(delta: float) -> void:
	if room.state!="playing": return
	if state!="burning" and state!="falling": return
	var tilt := sin(timer*23)*0.035 if state=="burning" else (1-timer/0.35)*0.7
	body.rotation=tilt
	body.position=Vector2(0,-32).rotated(tilt)
	# One shared flame texture adds detail without ten per-frame circles per shelf.
	flame.visible=burning
	flame.scale=Vector2(0.5+sin(timer*9)*0.025,0.5+cos(timer*13)*0.035)
	flame.rotation=tilt
	flame.position=Vector2(0,-38).rotated(tilt)
	if state=="burning" or state=="falling":
		timer-=delta
		if timer<=0:
			if state=="burning":
				state="falling"
				timer=0.35
			else: collapse()
	queue_redraw()

func _draw() -> void:
	if state=="burning" or state=="falling":
		var side := fall_direction.orthogonal()*45
		draw_colored_polygon(PackedVector2Array([side,-side,fall_direction*145-side,fall_direction*145+side]),Color(1,0.52,0.24,0.20))
		draw_line(Vector2.ZERO,fall_direction*145,Color("ffbd7a"),2,true)
