extends Node2D

const PLAYER_SCENE = preload("res://scenes/player/player.tscn")
const FLOOR_FIRE_ART: Texture2D = preload("res://art/items/floor_fire.svg")
var balance: Dictionary
var bounds: Rect2
var player: WizardCat
var spells: SpellController
var hud: WizardHUD
var actors: Node2D
var projectiles: Node2D
var enemies: Array[CandleSlime] = []
var camera: Camera2D
var state := "intro"
var effects: Array[Dictionary] = []
var props: Array[ArcaneShelf] = []
var fires: Array[Dictionary] = []
var time := 0.0
var shake := 0.0
var run: ExpeditionRun
var profile: MetaProgress
var stages: Array = []
var stage_def: Dictionary = {}
var exit_open := false
var loot: Array[LootPickup] = []
var loot_root: Node2D
var markers: ExpeditionMarkers
var panel: ExpeditionPanel
var shop_offers: Array[Dictionary] = []
var background: Sprite2D
var sector_gear_dropped := false
var drop_rng := RandomNumberGenerator.new()
var panel_return_state := "playing"
var pickup_radius := 64.0

func _ready() -> void:
	balance = JSON.parse_string(FileAccess.get_file_as_string("res://data/balance.json"))
	stages=JSON.parse_string(FileAccess.get_file_as_string("res://data/expedition.json")).stages
	run=ExpeditionRun.new()
	var profile_path := OS.get_environment("MEOW_PROFILE_PATH")
	profile=MetaProgress.new(profile_path) if not profile_path.is_empty() else MetaProgress.new()
	stage_def=stages[0]
	drop_rng.randomize()
	var r: Dictionary = balance.room
	bounds = Rect2(float(r.left),float(r.top),float(r.width),float(r.height))
	configure_inputs()
	# Render the unchanging room once, then reuse a single cached texture.
	var background_viewport := SubViewport.new()
	background_viewport.size=Vector2i(1280,800)
	background_viewport.transparent_bg=true
	background_viewport.disable_3d=true
	background_viewport.render_target_update_mode=SubViewport.UPDATE_ONCE
	background_viewport.add_child(ArchiveBackdrop.new())
	add_child(background_viewport)
	background = Sprite2D.new()
	background.texture=background_viewport.get_texture()
	background.centered=false
	# Floor fire and impact rings drawn by the room must remain above the backdrop.
	background.z_index=-10
	add_child(background)
	actors = Node2D.new()
	actors.y_sort_enabled = true
	add_child(actors)
	projectiles = Node2D.new()
	add_child(projectiles)
	camera = Camera2D.new()
	camera.position = Vector2(640,400)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 4
	add_child(camera)
	player = PLAYER_SCENE.instantiate()
	player.position = Vector2(345,515)
	player.presentation_scale = 1.85
	player.setup(balance.player.duplicate(true),bounds)
	player.active = false
	actors.add_child(player)
	player.health.died.connect(on_player_died)
	player.hurt.connect(func(): shake=5.0)
	player.wall_bumped.connect(on_wall_bumped)
	spells = SpellController.new()
	spells.config = balance.fireball.duplicate(true)
	spells.player = player
	spells.room = self
	spells.spell_emitted.connect(on_spell_emitted)
	add_child(spells)
	spawn_enemies()
	spawn_shelves()
	loot_root=Node2D.new()
	loot_root.z_index=2
	add_child(loot_root)
	markers=ExpeditionMarkers.new()
	markers.room=self
	add_child(markers)
	panel=ExpeditionPanel.new()
	panel.room=self
	add_child(panel)
	apply_equipment()
	hud = WizardHUD.new()
	hud.room = self
	hud.begin_requested.connect(begin_or_restart)
	add_child(hud)

func configure_inputs() -> void:
	var keys := {"move_left":[KEY_A,KEY_LEFT],"move_right":[KEY_D,KEY_RIGHT],"move_up":[KEY_W,KEY_UP],"move_down":[KEY_S,KEY_DOWN],"cast":[KEY_SPACE],"roll":[KEY_SHIFT]}
	for action: String in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key: int in keys[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action,event)
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("cast",mouse)

func spawn_enemies() -> void:
	var roles: Array=stage_def.roles
	var locations: Array=stage_def.positions
	for i in range(roles.size()):
		var enemy := CandleSlime.new()
		enemy.position = Vector2(float(locations[i][0]),float(locations[i][1]))
		enemy.role = str(roles[i])
		var settings: Dictionary=balance.enemy.duplicate(true)
		settings.hp=int(stage_def.get("hp",40))
		settings.speed=float(stage_def.get("speed",83))
		settings.contact_damage=int(stage_def.get("damage",12))
		var elite := i==int(stage_def.get("elite",-1))
		if elite:
			settings.hp=int(settings.hp)*(3 if str(stage_def.kind)=="final" else 2)
			settings.contact_damage=int(settings.contact_damage)+3
			settings.radius=23.0
			enemy.scale=Vector2(1.25,1.25)
			enemy.modulate=Color("ffdab4")
			enemy.set_meta("elite",true)
		enemy.setup(settings,player,bounds)
		enemy.active = false
		enemy.defeated.connect(on_enemy_defeated)
		enemies.append(enemy)
		actors.add_child(enemy)

func spawn_shelves() -> void:
	for point: Array in stage_def.shelves:
		var shelf := ArcaneShelf.new()
		shelf.room=self
		shelf.position=Vector2(float(point[0]),float(point[1]))
		props.append(shelf)
		actors.add_child(shelf)

func begin_or_restart() -> void:
	if state == "intro":
		var attempt_id: int=profile.begin_run()
		var legacy: Dictionary=profile.bonuses()
		run.add_gold(int(legacy.starting_gold))
		var starter: String=str(legacy.starter_item)
		if not starter.is_empty():
			run.add_item(starter)
			run.equip_item(starter)
		apply_equipment()
		player.health.current=player.health.maximum
		player.position = Vector2(640,455)
		player.presentation_scale = 1.0
		spells.input_blocked_until_release=true
		set_running(true)
		if attempt_id==0 and not profile.save_error.is_empty(): tell("Progress could not be saved: "+profile.save_error,Color("ffac8f"))
	elif state == "paused":
		set_running(true)
	else:
		get_tree().reload_current_scene()

func set_running(running: bool) -> void:
	state = "playing" if running else "paused"
	player.active = running
	for enemy in enemies:
		enemy.active = running
	projectiles.process_mode = Node.PROCESS_MODE_INHERIT if running else Node.PROCESS_MODE_DISABLED
	if running:
		hud.overlay.hide()
	else:
		hud.show_overlay("Taking a catnap", "The archives can wait.\nYour current study is paused.", "Resume study   /   ENTER")

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():
		return
	if event is InputEventKey:
		match event.keycode:
			KEY_ENTER:
				if panel.is_open: return
				if state=="playing" and exit_open: advance_sector()
				elif state != "playing": begin_or_restart()
			KEY_R:
				if state in ["playing","paused","inventory","shop"]: profile.finish_run(false)
				get_tree().reload_current_scene()
			KEY_ESCAPE:
				if panel.is_open: close_panel()
				elif state == "playing": set_running(false)
				elif state == "paused": set_running(true)
			KEY_I:
				if panel.is_open and panel.mode=="inventory": close_panel()
				elif state=="playing": open_inventory()
			KEY_M:
				if panel.is_open and panel.mode=="meta": close_panel()
				elif state in ["intro","defeated","cleared"]: open_legacy()
			KEY_E:
				if not panel.is_open: interact()
			KEY_1,KEY_2,KEY_3,KEY_4:
				if panel.is_open:
					var index := int(event.keycode)-KEY_1
					if panel.mode=="shop": panel.buy_offer(index)
					elif panel.mode=="meta": panel.buy_upgrade_at(index)
			KEY_F1: spells.resolver.forced = "success"
			KEY_F2: spells.resolver.forced = "miscast"
			KEY_F3: spells.resolver.forced = "overreaction"

func on_spell_emitted(result: String, point: Vector2) -> void:
	hud.show_outcome(result)
	if result == "miscast":
		var burst := MiscastBurst.new()
		burst.room = self
		burst.position = point
		add_child(burst)
	else:
		effects.append({"point":point,"age":0.0,"radius":35.0,"color":Color("f6be70")})
	if result == "overreaction": shake = 7.0

func apply_miscast_blast(point: Vector2, damage: int, radius: float, direction: Vector2) -> void:
	apply_blast(point,damage,radius,direction,Color("9295a1"))


func apply_blast(point: Vector2, damage: int, radius: float, direction: Vector2, tint: Color = Color("ffcb86")) -> void:
	effects.append({"point":point,"age":0.0,"radius":maxf(24,radius),"color":tint})
	if radius <= 0:
		return
	shake = 6.0
	for shelf in props:
		if shelf.position.distance_to(point)<=radius+30:
			shelf.ignite((shelf.position-point).normalized())
	# Iterate a copy because defeated signals remove enemies immediately.
	for enemy in enemies.duplicate():
		if is_instance_valid(enemy) and enemy.position.distance_to(point) <= radius + float(enemy.config.radius):
			var push: Vector2 = (enemy.position-point).normalized() if direction==Vector2.ZERO else direction
			enemy.take_damage(damage,push)

func tell(message: String, color: Color = Color("eacb9e")) -> void:
	if is_instance_valid(hud): hud.show_incident(message,color)

func on_wall_bumped(point: Vector2) -> void:
	shake=6
	tell("Wall: 1. Wizard: 0.",Color("ffb5a0"))
	effects.append({"point":point,"age":0.0,"radius":45.0,"color":Color("d7c4aa")})
	for shelf in props:
		if shelf.position.distance_to(point)<110: shelf.topple(player.roll_direction)

func ignite_floor(point: Vector2) -> void:
	for fire in fires:
		if fire.point.distance_to(point)<45: return
	fires.append({"point":point,"age":0.0,"tick":0.0})

func _physics_process(delta: float) -> void:
	if state!="playing": return
	update_loot(delta)
	for shelf in props:
		if shelf.state=="standing" or shelf.state=="burning":
			var offset := player.position-shelf.position
			if offset.length()<55:
				if player.roll_time>0: shelf.topple(player.roll_direction)
				else: player.position=shelf.position+(offset.normalized() if offset.length()>0.01 else Vector2.DOWN)*55
			for enemy in enemies.duplicate():
				var gap: Vector2 = enemy.position-shelf.position
				if gap.length()<48:
					if enemy.phase=="attack" and enemy.role=="broom": shelf.topple(enemy.attack_direction)
					else: enemy.position=shelf.position+(gap.normalized() if gap.length()>0.01 else Vector2.DOWN)*48
	if player.roll_time>0:
		for enemy in enemies.duplicate():
			if player.position.distance_to(enemy.position)<49 and not player.roll_hits.has(enemy.get_instance_id()):
				player.roll_hits.append(enemy.get_instance_id())
				enemy.take_damage(int(player.config.get("roll_damage",30)),player.roll_direction)
				tell("An advanced belly-based technique.",Color("e1d4a5"))
	for fire in fires:
		fire.age+=delta
		fire.tick-=delta
		if fire.tick<=0 and not exit_open:
			fire.tick=0.7
			if player.position.distance_to(fire.point)<43: player.take_damage(6,fire.point-Vector2(1,0))
			for enemy in enemies.duplicate():
				if enemy.position.distance_to(fire.point)<48: enemy.take_damage(10,Vector2.UP)
	fires=fires.filter(func(f: Dictionary) -> bool: return f.age<4.2)


func on_enemy_defeated(enemy: CandleSlime) -> void:
	effects.append({"point":enemy.position,"age":0.0,"radius":40.0,"color":Color("9dd6bb")})
	if state=="playing":
		run.enemies_defeated+=1
		spawn_enemy_loot(enemy)
	enemies.erase(enemy)
	if enemies.is_empty() and state == "playing":
		complete_sector()

func on_player_died() -> void:
	profile.finish_run(false)
	state = "defeated"
	player.active = false
	for enemy in enemies:
		enemy.active = false
	projectiles.process_mode = Node.PROCESS_MODE_DISABLED
	hud.show_overlay("A brief interruption.","Reached area %d / 8. Crowns and gear belong to this expedition.\nYour %d Starlight and legacy studies are safe.\nM: legacy upgrades before the next attempt." % [run.stage_index+1,profile.starlight],"New expedition   /   ENTER")

func _process(delta: float) -> void:
	if state != "playing":
		return
	markers.update_visuals()
	time += delta
	shake = move_toward(shake,0,delta*25)
	camera.position = Vector2(640,400)+(player.position-Vector2(640,400))*0.035
	camera.offset = Vector2(sin(time*79),cos(time*91))*shake
	for effect in effects:
		effect.age += delta
	effects = effects.filter(func(e: Dictionary) -> bool: return float(e.age)<0.5)
	queue_redraw()

func complete_sector() -> void:
	if exit_open: return
	exit_open=true
	var awarded: int=profile.award_sector(run.stage_index,int(stage_def.get("reward",0)))
	for shot in projectiles.get_children(): shot.queue_free()
	spells.pending=false
	player.cast_prepare=0
	fires.clear()
	if str(stage_def.kind)=="final":
		collect_remaining_loot()
		profile.finish_run(true)
		state="cleared"
		player.active=false
		projectiles.process_mode=Node.PROCESS_MODE_DISABLED
		hud.show_overlay("Accidentally magnificent.","All 8 areas cleared. %d foes, %d Crowns collected.\n%d Starlight remains for permanent legacy upgrades.\nM: legacy studies. ENTER: a fresh expedition." % [run.enemies_defeated,run.collected_gold,profile.starlight],"Begin another expedition   /   ENTER")
	else:
		if not profile.save_error.is_empty():
			tell("Passage open. Progress could not be saved: "+profile.save_error,Color("ffac8f"))
		else:
			tell("Passage open! +%d Starlight saved. Collect loot; ENTER continues." % awarded,Color("d7c597"))
	markers.update_visuals()

func advance_sector() -> bool:
	if state!="playing" or not exit_open or run.stage_index>=stages.size()-1: return false
	collect_remaining_loot()
	load_sector(run.stage_index+1)
	return true

func load_sector(index: int) -> void:
	state="transition"
	player.active=false
	for enemy in enemies: enemy.active=false
	var old_actors := actors
	actors=Node2D.new()
	actors.y_sort_enabled=true
	add_child(actors)
	player.reparent(actors)
	old_actors.queue_free()
	projectiles.process_mode=Node.PROCESS_MODE_DISABLED
	projectiles.queue_free()
	projectiles=Node2D.new()
	add_child(projectiles)
	for pickup in loot:
		if is_instance_valid(pickup): pickup.queue_free()
	loot.clear()
	enemies.clear()
	props.clear()
	fires.clear()
	effects.clear()
	for child in get_children():
		if child is MiscastBurst: child.queue_free()
	run.stage_index=index
	stage_def=stages[index]
	exit_open=str(stage_def.kind)=="shop"
	sector_gear_dropped=false
	shop_offers.clear()
	if exit_open: shop_offers=run.shop_offers(int(stage_def.tier))
	background.modulate=Color(str(stage_def.get("tint","ffffff")))
	spawn_enemies()
	spawn_shelves()
	player.position=Vector2(220,435)
	player.velocity=Vector2.ZERO
	player.recoil=Vector2.ZERO
	player.roll_time=0
	player.hit_reaction=0
	player.invulnerability=0.8
	spells.pending=false
	spells.prepare_time=0
	player.cast_prepare=0
	spells.cooldown=0
	spells.input_blocked_until_release=true
	hud.outcome_time=0
	shake=0
	camera.offset=Vector2.ZERO
	set_running(true)
	markers.update_visuals()
	tell("A safe stop. Walk to Nib and press E to browse." if exit_open else "Area %d / 8 — %s" % [index+1,str(stage_def.name)],Color("ead6b3"))

func interact() -> void:
	if state!="playing": return
	if str(stage_def.kind)=="shop" and player.position.distance_to(ExpeditionMarkers.SHOP_POSITION)<110:
		open_shop()
	elif exit_open and player.position.distance_to(ExpeditionMarkers.EXIT_POSITION)<100:
		advance_sector()
	elif not exit_open:
		tell("The passage opens when every foe is defeated.")

func open_inventory() -> void:
	if state!="playing": return
	panel_return_state=state
	set_running(false)
	state="inventory"
	hud.overlay.hide()
	panel.open_inventory()

func open_shop() -> void:
	if state!="playing" or str(stage_def.kind)!="shop": return
	panel_return_state=state
	set_running(false)
	state="shop"
	hud.overlay.hide()
	panel.open_shop()

func open_legacy() -> void:
	if state not in ["intro","defeated","cleared"]: return
	panel_return_state=state
	state="legacy"
	panel.open_meta()

func close_panel() -> void:
	if not panel.is_open: return
	panel.close()
	spells.input_blocked_until_release=true
	if panel_return_state=="playing": set_running(true)
	else: state=panel_return_state

func equip_gear(id: String) -> bool:
	if not run.equip_item(id): return false
	apply_equipment()
	return true

func unequip_gear(slot: String) -> bool:
	if not run.unequip_slot(slot): return false
	apply_equipment()
	return true

func apply_equipment() -> void:
	var stats: Dictionary=run.stats()
	var legacy: Dictionary=profile.bonuses()
	player.config=balance.player.duplicate(true)
	player.config.speed=float(balance.player.speed)+float(stats.speed_bonus)
	player.config.roll_cooldown=1.25*float(stats.roll_cooldown_multiplier)
	player.config.roll_damage=30+int(stats.roll_damage_bonus)
	player.health.maximum=int(balance.player.hp)+int(stats.max_hp_bonus)+int(legacy.max_hp_bonus)
	# Maximum HP equipment never creates free healing when repeatedly swapped.
	player.health.current=mini(player.health.current,player.health.maximum)
	player.health.changed.emit(player.health.current,player.health.maximum)
	spells.config=balance.fireball.duplicate(true)
	for key in ["success_damage","miscast_damage","overreaction_damage"]:
		spells.config[key]=int(balance.fireball[key])+int(stats.spell_damage_bonus)
	spells.config.cooldown=maxf(0.35,float(balance.fireball.cooldown)*float(stats.spell_cooldown_multiplier))
	pickup_radius=64+float(stats.pickup_radius_bonus)+float(legacy.pickup_radius_bonus)

func purchase_offer(index: int) -> Dictionary:
	if state!="shop" or index<0 or index>=shop_offers.size(): return {"ok":false,"reason":"Browse the shop to buy."}
	var offer: Dictionary=shop_offers[index]
	if str(offer.kind)=="heal" and player.health.current>=player.health.maximum:
		return {"ok":false,"reason":"Already at full vitality."}
	var result: Dictionary=run.purchase(offer)
	if bool(result.ok) and int(result.get("heal",0))>0: heal_player(int(result.heal))
	return result

func purchase_upgrade(id: String) -> Dictionary:
	if state!="legacy": return {"ok":false,"reason":"Legacy studies are available between expeditions."}
	return profile.purchase_upgrade(id)

func heal_player(amount: int) -> void:
	player.health.current=mini(player.health.maximum,player.health.current+maxi(0,amount))
	player.health.changed.emit(player.health.current,player.health.maximum)

func spawn_enemy_loot(enemy: CandleSlime) -> void:
	var point := enemy.position
	spawn_pickup("gold",point+Vector2(-16,6),4+run.stage_index+(8 if enemy.has_meta("elite") else 0))
	var guaranteed := run.enemies_defeated==1 or enemies.size()==1 and not sector_gear_dropped or enemy.has_meta("elite")
	if guaranteed or drop_rng.randf()<0.18:
		var tier := int(stage_def.tier)
		var pool: Array[String]=run.droppable_items(tier)
		var current_tier: Array[String]=[]
		for id in pool:
			if int(run.item_info(id).tier)==tier: current_tier.append(id)
		var item_id: String=current_tier[drop_rng.randi_range(0,current_tier.size()-1)]
		if run.enemies_defeated==1:
			item_id="brass_bell_collar" if run.inventory.has("crooked_ash_wand") else "crooked_ash_wand"
		spawn_pickup("gear",point+Vector2(18,0),0,item_id)
		sector_gear_dropped=true
	if run.enemies_defeated%5==0 or drop_rng.randf()<0.12:
		spawn_pickup("food",point+Vector2(0,27),20)

func spawn_pickup(kind: String, point: Vector2, amount: int=0, item_id: String="") -> LootPickup:
	var pickup := LootPickup.new()
	pickup.kind=kind
	pickup.amount=amount
	pickup.item_id=item_id
	pickup.position=point.clamp(bounds.position+Vector2(22,25),bounds.end-Vector2(22,25))
	if kind=="gear":
		var info: Dictionary=run.item_info(item_id)
		pickup.rarity=str(info.get("rarity","common"))
		pickup.slot=str(info.get("slot","wand"))
	loot.append(pickup)
	loot_root.add_child(pickup)
	return pickup

func collect_pickup(pickup: LootPickup) -> bool:
	if state!="playing" or not is_instance_valid(pickup) or not loot.has(pickup): return false
	match pickup.kind:
		"gold": run.add_gold(pickup.amount)
		"gear":
			if not run.add_item(pickup.item_id):
				if not pickup.has_meta("bag_warning"):
					pickup.set_meta("bag_warning",true)
					tell("Bag full. Gear left on the floor.",Color("ffb28e"))
				return false
			tell("Found %s. I: compare and equip." % str(run.item_info(pickup.item_id).name),Color("d1c4ed"))
		"food":
			if player.health.current>=player.health.maximum: return false
			heal_player(pickup.amount)
		_: return false
	loot.erase(pickup)
	pickup.queue_free()
	return true

func collect_remaining_loot() -> void:
	for pickup in loot.duplicate(): collect_pickup(pickup)

func update_loot(delta: float) -> void:
	for pickup in loot.duplicate():
		if not is_instance_valid(pickup): continue
		pickup.age+=delta
		var distance: float = pickup.position.distance_to(player.position)
		if pickup.kind=="gold" and distance<pickup_radius:
			pickup.position=pickup.position.move_toward(player.position,delta*310)
		if distance<30: collect_pickup(pickup)
		else: pickup.queue_redraw()

func _draw() -> void:
	for fire in fires:
		var p: Vector2=fire.point
		var fade := minf(1,(4.2-float(fire.age))*2)
		# One shared flame image replaces sixteen per-frame shapes per fire.
		var pulse := Vector2(1+sin(time*8+p.x)*0.025,1+cos(time*11+p.y)*0.025)
		draw_set_transform(p,0,pulse)
		draw_texture_rect(FLOOR_FIRE_ART,Rect2(-60,-90,120,135),false,Color(1,1,1,fade))
	draw_set_transform(Vector2.ZERO)
	for effect in effects:
		var t := float(effect.age)/0.5
		var c: Color = effect.color
		c.a = (1-t)*0.7
		draw_arc(effect.point+Vector2(0,-18),float(effect.radius)*(0.3+t),0,TAU,40,c,3*(1-t)+1,true)
		for i in range(8):
			var d := Vector2.from_angle(TAU*i/8)
			draw_circle(effect.point+Vector2(0,-18)+d*float(effect.radius)*t,3*(1-t),c)

