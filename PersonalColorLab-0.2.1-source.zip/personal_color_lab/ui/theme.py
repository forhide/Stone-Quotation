"""Shared desktop colors and native fonts, with no additional runtime dependency."""

import sys
from importlib.resources import as_file, files
from tkinter import ttk


COLORS = {
    'bg': '#14171B',
    'surface': '#1D2228',
    'elevated': '#242B33',
    'inset': '#101317',
    'border': '#303943',
    'text': '#EEF2F5',
    'muted': '#A4AFBB',
    'subtle': '#778491',
    'accent': '#C1F17D',
    'accent_hover': '#D0FA98',
    'accent_text': '#17220D',
    'success': '#A3DBA9',
    'warning': '#F1C27B',
    'danger': '#F09C9C',
}


def configure_theme(root):
    """Configure this Tcl interpreter; never retain Python Font/Tk owners."""
    c = COLORS
    families = set(root.tk.splitlist(root.tk.call('font', 'families')))
    preferred = (
        ('Segoe UI', 'Noto Sans', 'Arial') if sys.platform == 'win32'
        else ('SF Pro Text', 'Helvetica Neue', 'Helvetica') if sys.platform == 'darwin'
        else ('Noto Sans', 'DejaVu Sans', 'Liberation Sans')
    )
    family = next((name for name in preferred if name in families), 'Arial')
    mono = next((name for name in ('Cascadia Mono', 'Consolas', 'Menlo', 'DejaVu Sans Mono')
                 if name in families), family)
    fonts = {
        'LabDisplay': (family, 26, 'bold'),
        'LabTitle': (family, 21, 'bold'),
        'LabHeading': (family, 12, 'bold'),
        'LabBody': (family, 11, 'normal'),
        'LabSmall': (family, 9, 'normal'),
        'LabMetric': (family, 27, 'bold'),
        'LabMono': (mono, 10, 'normal'),
    }
    existing = set(root.tk.splitlist(root.tk.call('font', 'names')))
    for name, (face, size, weight) in fonts.items():
        root.tk.call('font', 'configure' if name in existing else 'create', name,
                     '-family', face, '-size', size, '-weight', weight)
    root.tk.call('font', 'configure', 'TkDefaultFont', '-family', family, '-size', 11)
    root.configure(background=c['bg'])
    # The icon is owned by Tcl, like the fonts, so a worker cannot finalize a
    # Python PhotoImage after the window closes.
    with as_file(files('personal_color_lab').joinpath('assets', 'app-icon.png')) as icon_path:
        root.tk.call('image', 'create', 'photo', 'LabAppIcon', '-file', str(icon_path))
    root.tk.call('wm', 'iconphoto', root._w, '-default', 'LabAppIcon')
    root.option_add('*TCombobox*Listbox.background', c['elevated'])
    root.option_add('*TCombobox*Listbox.foreground', c['text'])
    root.option_add('*TCombobox*Listbox.selectBackground', c['accent'])
    root.option_add('*TCombobox*Listbox.selectForeground', c['accent_text'])
    root.option_add('*TCombobox*Listbox.font', 'LabBody')

    style = ttk.Style(root)
    # Clam exposes the same flat colorable elements on Windows, macOS and Linux.
    style.theme_use('clam')
    style.configure('.', background=c['bg'], foreground=c['text'],
                    font='LabBody', bordercolor=c['border'], lightcolor=c['border'],
                    darkcolor=c['border'], focuscolor=c['accent'])
    for name, background in (
        ('TFrame', c['bg']), ('Lab.TFrame', c['bg']),
        ('Surface.TFrame', c['surface']), ('Sidebar.TFrame', c['inset']),
        ('Inset.TFrame', c['inset']), ('Elevated.TFrame', c['elevated']),
    ):
        style.configure(name, background=background, borderwidth=0)
    for name, font, foreground, background in (
        ('TLabel', 'LabBody', c['text'], c['bg']),
        ('Title.TLabel', 'LabTitle', c['text'], c['bg']),
        ('Heading.TLabel', 'LabHeading', c['text'], c['surface']),
        ('Body.TLabel', 'LabBody', c['text'], c['surface']),
        ('Muted.TLabel', 'LabBody', c['muted'], c['bg']),
        ('Small.TLabel', 'LabSmall', c['muted'], c['surface']),
        ('Metric.TLabel', 'LabMetric', c['text'], c['surface']),
        ('Accent.TLabel', 'LabSmall', c['accent'], c['surface']),
        ('Badge.TLabel', 'LabSmall', c['accent'], c['elevated']),
    ):
        style.configure(name, font=font, foreground=foreground, background=background)

    for name, background, foreground, hover in (
        ('TButton', c['elevated'], c['text'], c['border']),
        ('Primary.TButton', c['accent'], c['accent_text'], c['accent_hover']),
        ('Secondary.TButton', c['elevated'], c['text'], c['border']),
        ('Quiet.TButton', c['surface'], c['muted'], c['elevated']),
    ):
        style.configure(name, background=background, foreground=foreground,
                        borderwidth=0, relief='flat', padding=(16, 11),
                        font='LabHeading', focusthickness=2, focuscolor=c['accent'])
        style.map(name,
                  background=[('disabled', c['elevated']), ('pressed', hover), ('active', hover)],
                  foreground=[('disabled', c['subtle'])])

    style.configure('Lab.TEntry', fieldbackground=c['inset'], foreground=c['text'],
                    insertcolor=c['text'], borderwidth=1, padding=(11, 10))
    style.map('Lab.TEntry', bordercolor=[('focus', c['accent'])],
              fieldbackground=[('disabled', c['surface'])],
              foreground=[('disabled', c['subtle'])])
    style.configure('Lab.TCombobox', fieldbackground=c['elevated'],
                    background=c['elevated'], foreground=c['text'],
                    arrowcolor=c['muted'], borderwidth=0, padding=(10, 8))
    style.map('Lab.TCombobox', fieldbackground=[('readonly', c['elevated'])],
              foreground=[('readonly', c['text'])],
              selectbackground=[('readonly', c['elevated'])],
              selectforeground=[('readonly', c['text'])],
              bordercolor=[('focus', c['accent'])])
    style.configure('Lab.TCheckbutton', background=c['surface'], foreground=c['muted'],
                    indicatorbackground=c['inset'], indicatorforeground=c['accent'],
                    indicatormargin=6, padding=(0, 6))
    style.map('Lab.TCheckbutton', background=[('active', c['surface'])],
              foreground=[('disabled', c['subtle'])],
              indicatorbackground=[('selected', c['accent']), ('active', c['border'])])
    style.configure('Lab.Horizontal.TProgressbar', background=c['accent'],
                    troughcolor=c['inset'], borderwidth=0, thickness=4)
    style.configure('Lab.Treeview', background=c['surface'], fieldbackground=c['surface'],
                    foreground=c['text'], rowheight=43, borderwidth=0, font='LabBody')
    style.map('Lab.Treeview', background=[('selected', '#344735')],
              foreground=[('selected', c['text'])])
    style.configure('Lab.Treeview.Heading', background=c['elevated'],
                    foreground=c['muted'], font='LabSmall', borderwidth=0,
                    relief='flat', padding=(12, 13))
    style.map('Lab.Treeview.Heading', background=[('active', c['elevated'])])
    style.layout('Lab.Treeview', [('Treeview.treearea', {'sticky': 'nswe'})])
    style.configure('Lab.Vertical.TScrollbar', background=c['border'],
                    troughcolor=c['surface'], borderwidth=0, arrowcolor=c['muted'],
                    arrowsize=12, gripcount=0, width=12)
    style.map('Lab.Vertical.TScrollbar', background=[('active', c['subtle'])])
    style.configure('TSeparator', background=c['border'])
    style.configure('TNotebook', background=c['bg'], borderwidth=0, tabmargins=(0, 0, 0, 10))
    style.configure('TNotebook.Tab', background=c['bg'], foreground=c['muted'],
                    borderwidth=0, padding=(18, 10), font='LabHeading',
                    lightcolor=c['bg'], darkcolor=c['bg'], bordercolor=c['bg'])
    style.map('TNotebook.Tab', background=[('selected', c['surface'])],
              foreground=[('selected', c['accent']), ('active', c['text'])],
              lightcolor=[('selected', c['surface']), ('!selected', c['bg'])],
              darkcolor=[('selected', c['surface']), ('!selected', c['bg'])],
              bordercolor=[('selected', c['surface']), ('!selected', c['bg'])])
