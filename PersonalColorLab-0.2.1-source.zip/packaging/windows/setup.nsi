Unicode true
Target amd64-unicode
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
Name "Personal Color Lab ${VERSION}"
OutFile "${OUTPUT}"
InstallDir "$LOCALAPPDATA\Programs\PersonalColorLab"
InstallDirRegKey HKCU "Software\PersonalColorLab" "InstallLocation"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 32
VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=1033 "ProductName" "Personal Color Lab"
VIAddVersionKey /LANG=1033 "ProductVersion" "${VERSION}"
VIAddVersionKey /LANG=1033 "FileDescription" "Offline desktop installer"
VIAddVersionKey /LANG=1033 "FileVersion" "${VERSION}"
VIAddVersionKey /LANG=1033 "LegalCopyright" "Personal Color Lab contributors"
!define MUI_ABORTWARNING
!define MUI_ICON "${ICON}"
!define MUI_UNICON "${ICON}"
!define MUI_LANGDLL_REGISTRY_ROOT HKCU
!define MUI_LANGDLL_REGISTRY_KEY "Software\PersonalColorLab"
!define MUI_LANGDLL_REGISTRY_VALUENAME "InstallerLanguage"
!define MUI_FINISHPAGE_RUN "$INSTDIR\Personal Color Lab.exe"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "Korean"
!include "strings.nsh"

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "$(Need64)"
    Abort
  ${EndIf}
  SetShellVarContext current
FunctionEnd

Section "Personal Color Lab" SEC_APP
  ; Language registry lookup may leave a missing-value flag. Only errors from
  ; the actual extraction belong to the installation failure check below.
  ClearErrors
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD}\*"
  IfErrors install_failed
  FileOpen $0 "$INSTDIR\.personal-color-lab-install" w
  FileWrite $0 "${VERSION}"
  FileClose $0
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\Personal Color Lab"
  CreateShortcut "$SMPROGRAMS\Personal Color Lab\Personal Color Lab.lnk" "$INSTDIR\Personal Color Lab.exe"
  CreateShortcut "$SMPROGRAMS\Personal Color Lab\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\PersonalColorLab" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "DisplayName" "Personal Color Lab"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "DisplayIcon" "$INSTDIR\Personal Color Lab.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "QuietUninstallString" '$\"$INSTDIR\Uninstall.exe$\" /S'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab" "NoRepair" 1
  Goto done
install_failed:
  MessageBox MB_OK|MB_ICONSTOP "$(CopyFailed)"
  SetErrorLevel 1
  Abort
done:
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  IfFileExists "$INSTDIR\.personal-color-lab-install" 0 missing_marker
  ; Only owned files: never recursively remove an arbitrary selected folder.
  !include "${DELETE_MANIFEST}"
  Delete "$INSTDIR\.personal-color-lab-install"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\Personal Color Lab\Personal Color Lab.lnk"
  Delete "$SMPROGRAMS\Personal Color Lab\Uninstall.lnk"
  RMDir "$SMPROGRAMS\Personal Color Lab"
  DeleteRegKey HKCU "Software\PersonalColorLab"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\PersonalColorLab"
  Goto uninstall_done
missing_marker:
  SetErrorLevel 1
uninstall_done:
SectionEnd

Function un.onInit
  !insertmacro MUI_UNGETLANGUAGE
FunctionEnd
