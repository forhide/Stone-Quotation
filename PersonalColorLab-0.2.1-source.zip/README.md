# Personal Color Lab V0.2.1

An offline desktop application for understanding what changed between an original photo and its edited version. V0.2.1 adds a dark graphite interface with lime accents, a guided before/after workflow, and a plain-language result summary. It analyzes JPEG pairs; style application and Lightroom export are planned.

## Current workflow

1. Click **Compare two photos**, choose the original JPEG, then choose its edited version. They can have different filenames and be in different folders; no folder scan is required.
2. Check the side-by-side previews: original on the left, edited on the right. Swap their direction if needed. The comparison runs locally.
3. Read **Changes at a glance** for brightness, color tendency, shared image area, and a measured brightness-mapping curve. Open **Detailed measurements** for alignment, tone, Lab/HSV/HSL evidence, confidence, and approximate exposure/WB/tint values.

For a large collection, use **Find pairs in a folder**, optionally including subfolders. Select a JPEG candidate and click **Compare selected pair**, double-click its row, or press Enter. Filename matches are suggestions: check that the two photos show the same scene and that their direction is correct.

Directly chosen pairs also appear in the current session's table as **Chosen by you**, so you can reopen a saved comparison without choosing the files again. Choosing the same pair again reuses its row.

The empty workspace explains how to start. Failed alignment, unreadable color profiles, unreadable files, and stale saved results explain the next action instead of presenting unverified measurements. Reopen a pair to use its saved local analysis; choose **Compare again** after a source file changes.

The scanner also classifies RAW, other image, and XMP files and finds filename-based RAW pair candidates. Those candidates are not decoded or reverse-analyzed in this milestone. A candidate matching score is separate from the inspector's geometric alignment confidence.

English is the default UI language; Korean is selectable. The application uses CPU-only local processing without accounts, telemetry, APIs, or photo uploads. Original photo files remain untouched.

## Run from source

For installation without Python, use the Windows x64 setup.exe or the macOS Apple Silicon/Intel .pkg. See [INSTALLERS.md](INSTALLERS.md) for requirements, installation, removal, checksums, rebuild commands and validation limits. The following instructions are for source development.

Requires Python 3.11+ with Tkinter, Pillow, NumPy, and OpenCV. On Linux, install the distribution's `python3-tk` package if Tkinter is unavailable; some distributions also package venv support separately. A desktop display is required for the GUI. No web server, mobile SDK, or GPU is needed.

```bash
python -m venv .venv
```

Activate the environment on macOS/Linux with `source .venv/bin/activate`, or on Windows PowerShell with `.venv\Scripts\Activate.ps1`.

```bash
python -m pip install -r requirements.lock
python run_app.py
```

Dependency installation may use the network. Once installed, the application itself runs offline. `requirements.lock` pins the runtime versions selected for Linux validation and the installer wheels. `requirements.txt` retains supported version ranges for deliberate dependency updates.

## Development checks

```bash
python -m pip install -r requirements-dev.lock
python -m pytest
```

`requirements-dev.lock` also pins pytest and its dependencies; `requirements-dev.txt` retains development version ranges. Synthetic-pair tests exercise known geometric, tone, and color changes, rejected mismatches, invalid color profiles, source-file preservation, local persistence, and cache freshness.

GUI checks require Tkinter and a display. On headless Linux with `Xvfb` installed in `PATH`, run the suite including desktop tests with:

```bash
python tools/run_gui_tests.py -q
```

For a local Xvfb executable outside `PATH`, use:

```bash
PERSONAL_COLOR_LAB_XVFB=/path/to/Xvfb python tools/run_gui_tests.py -q
```

The runner starts a local display without downloading dependencies. It uses an existing display when one is available. The suite includes desktop workflows, analysis checks, and independent archive checks. Archive checks require bsdtar in PATH or PERSONAL_COLOR_LAB_BSDTAR; they are explicitly skipped without it. See `VALIDATION.md` for the latest completed runs and platform limitations. Native Windows/macOS release validation remains pending.

## Local data

By default, the application stores its SQLite library and UI settings in:

- `~/.personal_color_lab/library.db`
- `~/.personal_color_lab/settings.json`

Set `PERSONAL_COLOR_LAB_DATA_DIR` to use another local directory. For example, on macOS/Linux:

```bash
PERSONAL_COLOR_LAB_DATA_DIR=/workspace/personal-color-lab-data python run_app.py
```

The database stores paths, selected non-location metadata, derived analysis, confidence, provenance, and source SHA-256 hashes. It does not copy original photos or persist GPS coordinates. Existing V0.1 libraries receive an additive version-1 schema migration that preserves their rows. V0.2.1 keeps analysis algorithm version 0.2.0 and payload/schema version 1, so the interface update preserves compatible saved comparisons and settings.

## Analysis limits

- Registration supports modest crop, resize, and rotation using a similarity transform. General perspective changes, strong warps, and local edits are outside this milestone. Low-texture or unrelated pairs can be rejected; rejected alignment produces no tone or color estimates.
- Processing uses bounded-resolution, EXIF-oriented pixels and local ICC-to-sRGB conversion where possible. Malformed or unsupported ICC profiles produce `color_space_uncertain`: geometric alignment can still succeed, but tone/color and approximate slider estimates are withheld. Untagged inputs are treated as sRGB.
- Confidence scores are heuristics, not calibrated probabilities. Overall analysis confidence covers registered tone/color evidence using alignment and sample support; exposure and WB/tint have separate weighted confidence. Sparse overlap, clipping, and missing neutral evidence limit inference.
- Observed pixel changes are evidence. Exposure EV and WB/tint directions are approximations, not recovered Lightroom sliders, Kelvin values, or exact XMP settings.
- The inspector shows a measured tone-transfer curve and plain-language summary by default, with detailed tone/Lab/HSV/HSL measurements in a separate tab. Hue-band evidence is stored in the analysis payload; a dedicated hue-band visualization remains planned.
- Filename pairing remains a candidate search; repeated filenames and ambiguous original/edit direction require inspection. HEIC/HEIF decoding depends on installed Pillow support.

RAW decoding, full XMP parsing/export, learned Style DNA, style application, and local AI models remain planned. Offline installer artifacts and rebuild tools are implemented; native release validation and signing remain pending. See `CODEX_HANDOFF.md`, `ROADMAP.md`, and `TODO.md` for the development boundary.
