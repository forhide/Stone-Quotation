# Roadmap

The current scope is an offline desktop application. Mobile development is not planned for this milestone.

## V0.1 - Dataset Analyzer (baseline)

- File scan/classification and pair candidate detection
- Local SQLite storage
- English/Korean desktop UI

## V0.2.0 - Selected JPG Edit Reverse Analyzer (implemented)

- Modest crop/resize/rotation similarity alignment, overlap, and registration confidence
- Tone transfer, luminance-zone changes, clipping, Lab/HSV/HSL color summaries
- Photometric abstention for malformed ICC profiles while retaining geometry
- Approximate exposure EV and WB/tint tendencies with confidence and inferred provenance
- Additive V0.1-compatible storage, source hashes, and stale-analysis detection
- Selected-pair inspector with previews, swap, reanalyze, and local persistence
- Synthetic analysis tests; final validation results recorded separately
- Pinned dependency files and a headless Linux desktop test runner

## V0.2.1 - Guided desktop comparison (implemented)

- Shared dark graphite/lime theme with clear controls, spacing, compact layouts, and a bundled aperture app/installer icon
- Direct original/edited JPEG selection without filename or folder-scan prerequisites
- Three-step guidance, useful empty states, labeled previews, and candidate double-click/Enter shortcuts
- Deduplicated current-session rows for directly chosen pairs, with a user-selection label and saved-result reopening
- Plain-language brightness, color-tendency, and shared-area cards; measured tone-transfer curve
- Separate detailed measurements tab and recovery guidance for failed, uncertain, or stale results
- English/Korean resources, offline execution, and existing analysis/cache/data compatibility
- Updated Windows/macOS installer version; completed validation evidence recorded in `VALIDATION.md`

## V0.2.x - Validate and extend the JPG pipeline

Offline packaging is implemented: Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg with verified private runtimes, preserved data, diagnostics and native CI. See INSTALLERS.md. Native release validation and signing are the remaining packaging milestones.

- Real-photo evaluation and confidence calibration
- Pairing/direction improvements and broader registration coverage
- Hue-band visualization and richer channel evidence; the measured tone-transfer curve is available in V0.2.1
- XMP parsing expansion
- RAW decoder interface and local implementation after JPG validation
- RAW+edited JPG analysis and sharpening/noise/grain estimation
- Native Windows/macOS installer/GUI validation and release signing/notarization

## V0.3 - Style DNA and preset engine

- Common Style DNA and My Style aggregation
- Custom Reference Style, coverage/diversity, and outlier analysis
- Derived local film, cinema/drama, and artist/director/cinematographer profiles
- Composition metadata with explicit user choice
- Strength controls and hybrid mixing

## V0.4 - Scene and local-edit analysis

- Multilabel time/light, environment, subject, and lighting attributes
- Face/skin/sky/vegetation/food/background regions
- Local-adjustment inference
- Composition scoring and non-destructive crop suggestions

## V1.0 - Offline personal photo editor

- Adaptive style application and safety/clipping checks
- Lightroom-compatible XMP export and verification
- Local model/update packs with mandatory CPU fallback
- Validated offline desktop installers
