# TODO

## Implemented - V0.2.0 selected JPG analysis

- [x] Add additive schema versioning while preserving V0.1 rows.
- [x] Store versioned pair analyses with confidence, inferred provenance, and source hashes.
- [x] Register JPG pairs with modest crop/resize/rotation and valid-overlap masks.
- [x] Suppress tone/color estimates when registration is unreliable.
- [x] Withhold photometric estimates for unreadable ICC profiles while preserving geometry.
- [x] Estimate observed tone transfer and luminance-zone changes.
- [x] Add Lab/CIE76, HSV/HSL, and hue-band summaries.
- [x] Estimate approximate exposure EV and WB/tint tendencies with confidence.
- [x] Add a localized selected-pair inspector with previews, swap, and reanalysis.
- [x] Load persisted analyses and invalidate stale results using source SHA-256 hashes.
- [x] Add the `PERSONAL_COLOR_LAB_DATA_DIR` runtime-data override.
- [x] Add synthetic analysis and integration tests.
- [x] Scope overall confidence to registered tone/color evidence and weight exposure/WB estimates separately.
- [x] Pin the current runtime/development dependency set and add a local-Xvfb desktop test runner.

## Validation and refinement

- [x] Add a shared dark graphite/lime theme and compact desktop layouts.
- [x] Add direct original/edited JPEG selection without filename, shared-folder, or scan requirements.
- [x] Add three-step guidance, useful empty states, and double-click/Enter candidate shortcuts.
- [x] Reopen directly selected pairs from the current session's table, label them as user selections, and avoid duplicate rows.
- [x] Add a bundled aperture icon for desktop windows and Windows/macOS packaging.
- [x] Default to plain-language brightness/color/shared-area cards with a measured tone-transfer curve.
- [x] Keep technical measurements in a separate tab and add English/Korean recovery guidance.
- [x] Preserve analysis algorithm 0.2.0, payload/database schema 1, existing data, and compatible saved comparisons in app V0.2.1.

- [x] Build self-contained Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg.
- [x] Bundle verified pinned runtime/wheels, locale resources and license notices.
- [x] Preserve user data and original photos during installation/update/removal.
- [x] Add offline diagnostics, native installed-GUI checks and manual native CI.
- [x] Record completed Linux source/GUI/archive checks in `VALIDATION.md`.
- [ ] Run native installer CI on all three target OS/architecture combinations.
- [ ] Sign Windows releases and sign/notarize macOS releases before public distribution.

- [x] Record final automated test and Linux desktop smoke-check outcomes: 119 passed, including seven GUI flows; see `VALIDATION.md`.
- [ ] Validate Windows and macOS desktop behavior before a release.
- [ ] Evaluate real original/edited datasets and calibrate confidence thresholds.
- [ ] Improve repeated-filename pairing, visual candidate filtering, and direction ambiguity.
- [x] Show the measured tone-transfer curve in the default comparison summary.
- [ ] Visualize hue-band evidence in the inspector; HSV/HSL summaries are already displayed and hue-band measurements are stored.
- [ ] Expand alignment coverage and clearly distinguish unsupported geometry/local edits.
- [ ] Confirm optional image-format decoding support rather than relying on extension lists.
- [ ] Validate future dependency updates and native platform compatibility.

## Next - V0.2.x

- [ ] Expand XMP parsing.
- [ ] Introduce a RAW decoder interface after the JPG pipeline is validated.
- [ ] Add local RAW decoding and RAW+edited JPG analysis.
- [ ] Estimate sharpening/noise/grain behavior.

## Later - V0.3

- [ ] Common Style DNA schema and My Style aggregation.
- [ ] Custom Reference Style builder with coverage/diversity and outlier analysis.
- [ ] Derived built-in film, cinema/drama, and artist/director profiles.
- [ ] Strength controls and Hybrid Style mixing.

## Later - V0.4 and V1.0

- [ ] Multilabel scene analysis and local segmentation.
- [ ] Local-edit inference and composition scoring/suggestions.
- [ ] Adaptive non-destructive style application.
- [ ] Lightroom-compatible XMP export verification.
- [ ] Local model packs and validated offline installers.

All future work preserves offline execution, original photo bytes, GPS exclusion, selectable English/Korean resources, and mandatory CPU fallback. Mobile development is outside the current scope.
