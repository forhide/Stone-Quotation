"""Desktop integration checks. Run with a real display or the Xvfb test runner."""
import hashlib
import os
from pathlib import Path
import time
import threading
import tkinter as tk
from types import SimpleNamespace
import weakref

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.constants import DB_FILENAME
from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.settings import load_settings
from personal_color_lab.ui.app import App

pytestmark = pytest.mark.skipif(
    os.name != "nt" and not os.environ.get("DISPLAY"),
    reason="Desktop tests need a display; use tools/run_gui_tests.py with Xvfb on headless Linux.",
)


def _pump(app, ready, seconds=20):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        app.update()
        if ready():
            return
        time.sleep(0.01)
    raise AssertionError("Desktop operation did not finish before its timeout")


def _photos(folder):
    folder.mkdir()
    rng = np.random.default_rng(724)
    image = rng.integers(40, 180, (280, 420, 3), dtype=np.uint8)
    image = cv2.GaussianBlur(image, (5, 5), 0)
    for _ in range(55):
        x, y = rng.integers(10, 260, 2)
        cv2.circle(image, (int(x), int(y)), 5, tuple(int(v) for v in rng.integers(35, 200, 3)), -1)
    for i in range(4):
        level = 50 + i * 30
        cv2.rectangle(image, (320, 15 + i * 60), (400, 50 + i * 60), (level,) * 3, -1)
    original = folder / "photo_original.jpg"
    edited = folder / "photo_edit.jpg"
    Image.fromarray(image).save(original, quality=98, subsampling=0)
    Image.fromarray(np.clip(image.astype(float) * 1.08 + [6, 1, -4], 0, 255).astype(np.uint8)).save(edited, quality=98, subsampling=0)
    return original, edited


@pytest.fixture
def desktop(tmp_path, monkeypatch):
    monkeypatch.setenv("PERSONAL_COLOR_LAB_DATA_DIR", str(tmp_path / "data"))
    messages = []
    for name in ("showwarning", "showerror", "showinfo"):
        monkeypatch.setattr(f"personal_color_lab.ui.app.messagebox.{name}", lambda *args, **kwargs: messages.append(args))
    app = App()
    callbacks = []
    app.report_callback_exception = lambda kind, value, traceback: callbacks.append((kind, str(value)))
    try:
        yield app, tmp_path, messages, callbacks
    finally:
        if app.winfo_exists():
            app.close()
    assert not callbacks, callbacks


def _scan_and_inspect(app, folder):
    app.folder.set(str(folder))
    app.start_scan()
    _pump(app, lambda: not app._scanning)
    row = next(row for row, pair in app._row_pairs.items() if pair.pair_type == "JPG+JPG")
    app.tree.selection_set(row)
    app._selection_changed()
    assert str(app.inspect_btn.cget("state")) == "normal"
    app.inspect_selected()
    inspector = app._inspectors[-1]
    _pump(app, lambda: not inspector._busy)
    return inspector


def test_desktop_scan_inspect_persist_cached_reload_language_and_swap(desktop):
    app, tmp_path, messages, callbacks = desktop
    original, edited = _photos(tmp_path / "photos")
    before = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, edited)]
    assert app.i18n.language == "en"
    inspector = _scan_and_inspect(app, original.parent)
    assert inspector.payload is not None, inspector.details.get("1.0", "end")
    assert inspector.payload["status"] == "ok"
    assert inspector._state_key == "analysis_saved"
    assert len(inspector._images) == 2
    with LibraryDB(tmp_path / "data" / DB_FILENAME) as db:
        assert db.get_analysis(original, edited) == inspector.payload
    text = inspector.details.get("1.0", "end")
    assert app.i18n.t("inferred_analysis") in text
    assert app.i18n.t("approximate_notice") in text

    inspector.close()
    app.inspect_selected()
    cached = app._inspectors[-1]
    _pump(app, lambda: not cached._busy)
    assert cached._state_key == "analysis_loaded"
    app.lang.set("ko")
    app.change_language()
    assert app.i18n.language == "ko"
    assert cached.title() == app.i18n.t("inspector_title")
    assert app.i18n.t("inferred_analysis") in cached.details.get("1.0", "end")
    cached.swap_direction()
    _pump(app, lambda: not cached._busy)
    assert cached.original_path == edited
    assert cached.payload["status"] == "ok"
    assert cached.payload["tone"]["mean_luminance_delta"] < 0
    assert before == [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, edited)]
    assert not messages


def test_changed_image_marks_cache_stale_and_explicit_reanalysis_refreshes(desktop):
    app, tmp_path, messages, callbacks = desktop
    original, edited = _photos(tmp_path / "photos")
    inspector = _scan_and_inspect(app, original.parent)
    old_hash = inspector.payload["provenance"]["input_fingerprints"]["edited"]
    inspector.close()
    edited.write_bytes(edited.read_bytes() + b"changed locally")
    app.inspect_selected()
    inspector = app._inspectors[-1]
    _pump(app, lambda: not inspector._busy)
    assert inspector.payload is None
    assert inspector._state_key == "analysis_stale"
    assert inspector.result_tabs.select() == str(inspector.summary_tab)
    assert all(card["value"].cget("text") == app.i18n.t("summary_not_measured") for card in inspector.summary_cards)
    inspector.start_analysis(force=True)
    _pump(app, lambda: not inspector._busy)
    assert inspector.payload["status"] == "ok"
    assert inspector.payload["provenance"]["input_fingerprints"]["edited"] != old_hash
    assert not messages


def test_manual_pair_analyzes_unrelated_filenames_without_folder_scan(desktop, monkeypatch):
    app, tmp_path, messages, callbacks = desktop
    original, edited = _photos(tmp_path / "photos")
    original = original.rename(original.parent / "camera-frame.JPG")
    edits = tmp_path / "finished"
    edits.mkdir()
    edited = edited.rename(edits / "summer-colors.JPEG")
    before = [hashlib.sha256(path.read_bytes()).hexdigest() for path in (original, edited)]
    scan_counts = {key: value.cget("text") for key, (_, value) in app.summary_vars.items()}
    chosen = iter((str(original), str(edited)))
    prompts = []

    def select_photo(**kwargs):
        prompts.append(kwargs["title"])
        return next(chosen)

    def unexpected_scan(*args, **kwargs):
        pytest.fail("Choosing two photos must work without scanning a folder")

    monkeypatch.setattr("personal_color_lab.ui.app.filedialog.askopenfilename", select_photo)
    monkeypatch.setattr("personal_color_lab.ui.app.scan_folder", unexpected_scan)
    assert not (tmp_path / "data" / DB_FILENAME).exists()
    app.choose_pair()
    assert prompts == [app.i18n.t("choose_original_photo"), app.i18n.t("choose_edited_photo")]
    assert len(app._inspectors) == 1
    inspector = app._inspectors[-1]
    _pump(app, lambda: not inspector._busy)
    assert inspector.original_path == original.resolve()
    assert inspector.edited_path == edited.resolve()
    assert inspector.payload["status"] == "ok"
    assert len(inspector._images) == 2
    assert inspector.result_tabs.select() == str(inspector.summary_tab)
    assert len(inspector.summary_cards) == 3
    assert all(card["value"].cget("text") != app.i18n.t("summary_not_measured") for card in inspector.summary_cards)
    with LibraryDB(tmp_path / "data" / DB_FILENAME) as db:
        assert db.get_analysis(original, edited) == inspector.payload
    assert len(app._row_pairs) == 1
    row = next(iter(app._row_pairs))
    assert app.tree.set(row, "confidence") == app.i18n.t("pair_manual_match")
    assert app.tree.set(row, "original") == original.name
    assert app.tree.set(row, "edited") == edited.name
    assert scan_counts == {key: value.cget("text") for key, (_, value) in app.summary_vars.items()}
    inspector.close()
    app.tree.selection_set(row)
    app._selection_changed()
    assert str(app.inspect_btn.cget("state")) == "normal"
    app.inspect_selected()
    reopened = app._inspectors[-1]
    _pump(app, lambda: not reopened._busy)
    assert reopened._state_key == "analysis_loaded"
    assert reopened.original_path == original.resolve()
    assert reopened.edited_path == edited.resolve()
    assert len(prompts) == 2
    reopened.close()

    chosen = iter((str(original), str(edited)))
    app.choose_pair()
    repeated = app._inspectors[-1]
    _pump(app, lambda: not repeated._busy)
    assert repeated._state_key == "analysis_loaded"
    assert tuple(app._row_pairs) == (row,)
    assert len(app.tree.get_children()) == 1
    assert len(prompts) == 4
    assert scan_counts == {key: value.cget("text") for key, (_, value) in app.summary_vars.items()}
    app.lang.set("ko")
    app.change_language()
    assert app.tree.set(row, "confidence") == app.i18n.t("pair_manual_match")
    assert before == [hashlib.sha256(path.read_bytes()).hexdigest() for path in (original, edited)]
    assert not messages


@pytest.mark.parametrize("cancel_second", [False, True])
def test_cancel_manual_pair_does_not_create_analysis_or_database(desktop, monkeypatch, cancel_second):
    app, tmp_path, messages, callbacks = desktop
    original, _ = _photos(tmp_path / "photos")
    chosen = iter((str(original), "") if cancel_second else ("",))
    monkeypatch.setattr("personal_color_lab.ui.app.filedialog.askopenfilename", lambda **kwargs: next(chosen))
    app.choose_pair()
    app.update()
    assert not app._inspectors
    assert not (tmp_path / "data" / DB_FILENAME).exists()
    assert not messages


def test_manual_pair_rejects_the_same_photo_before_analysis(desktop, monkeypatch):
    app, tmp_path, messages, callbacks = desktop
    original, _ = _photos(tmp_path / "photos")
    alias = os.path.join(str(original.parent), ".", original.name)
    chosen = iter((str(original), alias))
    monkeypatch.setattr("personal_color_lab.ui.app.filedialog.askopenfilename", lambda **kwargs: next(chosen))
    app.choose_pair()
    assert not app._inspectors
    assert not (tmp_path / "data" / DB_FILENAME).exists()
    assert messages[-1][1] == app.i18n.t("same_photo_warning")


@pytest.mark.parametrize("missing", [False, True])
def test_manual_pair_explains_unsupported_or_missing_photos_without_creating_analysis(desktop, monkeypatch, missing):
    app, tmp_path, messages, callbacks = desktop
    original, _ = _photos(tmp_path / "photos")
    candidate = tmp_path / ("missing.jpg" if missing else "unsupported.png")
    if not missing:
        Image.new("RGB", (32, 32), (100, 120, 140)).save(candidate)
    chosen = iter((str(original), str(candidate)))
    monkeypatch.setattr("personal_color_lab.ui.app.filedialog.askopenfilename", lambda **kwargs: next(chosen))
    app.choose_pair()
    assert not app._inspectors
    assert not (tmp_path / "data" / DB_FILENAME).exists()
    assert messages[-1][1] == app.i18n.t("choose_jpeg_warning")


def test_language_menu_shows_names_and_persists_language_codes(desktop):
    app, tmp_path, messages, callbacks = desktop
    assert tuple(app.lang_combo.cget("values")) == ("English", "한국어")
    assert app.display_lang.get() == "English"
    app.display_lang.set("한국어")
    app.change_language(SimpleNamespace())
    assert app.i18n.language == "ko"
    assert app.lang.get() == "ko"
    assert load_settings()["language"] == "ko"
    app.display_lang.set("English")
    app.change_language(SimpleNamespace())
    assert app.i18n.language == "en"
    assert app.lang.get() == "en"
    assert load_settings()["language"] == "en"
    assert not messages


def test_empty_library_explains_manual_start_and_no_scan_results(desktop):
    app, tmp_path, messages, callbacks = desktop
    app.update()
    assert app.empty_state.winfo_ismapped()
    assert app.empty_title.cget("text") == app.i18n.t("library_empty_title")
    assert app.empty_hint.cget("text") == app.i18n.t("library_empty_hint")
    empty_folder = tmp_path / "empty"
    empty_folder.mkdir()
    app.folder.set(str(empty_folder))
    app.start_scan()
    _pump(app, lambda: not app._scanning)
    assert not app._row_pairs
    assert app.empty_state.winfo_ismapped()
    assert app.empty_title.cget("text") == app.i18n.t("pairs_empty_title")
    assert app.empty_hint.cget("text") == app.i18n.t("pairs_empty_hint")
    assert app.status.get() == app.i18n.t("status_scan_complete", count=0)
    assert str(app.inspect_btn.cget("state")) == "disabled"
    assert not messages


@pytest.mark.parametrize("language", ["en", "ko"])
def test_main_actions_and_empty_guidance_fit_the_minimum_window(desktop, language):
    app, tmp_path, messages, callbacks = desktop
    app.lang.set(language)
    app.change_language()
    width, height = app.minsize()
    app.geometry(f"{width}x{height}")
    app.update()

    def inside(widget, ancestor):
        assert widget.winfo_ismapped()
        x = widget.winfo_rootx() - ancestor.winfo_rootx()
        y = widget.winfo_rooty() - ancestor.winfo_rooty()
        assert 0 <= x <= ancestor.winfo_width() - widget.winfo_width(), (widget, "horizontal", x, widget.winfo_width(), ancestor.winfo_width())
        assert 0 <= y <= ancestor.winfo_height() - widget.winfo_height(), (widget, "vertical", y, widget.winfo_height(), ancestor.winfo_height())

    for control in (app.compare_btn, app.choose_btn, app.scan_btn, app.inspect_btn, app.lang_combo):
        inside(control, app)
    viewport = app.empty_state.master
    inside(app.empty_title, viewport)
    inside(app.empty_hint, viewport)
    empty_folder = tmp_path / "empty"
    empty_folder.mkdir()
    app.folder.set(str(empty_folder))
    app.start_scan()
    _pump(app, lambda: not app._scanning)
    app.update()
    for control in (app.compare_btn, app.choose_btn, app.scan_btn, app.inspect_btn, app.lang_combo):
        inside(control, app)
    inside(app.empty_title, viewport)
    inside(app.empty_hint, viewport)
    assert not messages


@pytest.mark.parametrize("language", ["en", "ko"])
def test_comparison_actions_and_summary_values_fit_the_minimum_window(desktop, language):
    app, tmp_path, messages, callbacks = desktop
    app.lang.set(language)
    app.change_language()
    original, _ = _photos(tmp_path / "photos")
    inspector = _scan_and_inspect(app, original.parent)
    width, height = inspector.minsize()
    inspector.geometry(f"{width}x{height}")
    app.update()

    def inside(widget, ancestor):
        assert widget.winfo_ismapped()
        x = widget.winfo_rootx() - ancestor.winfo_rootx()
        y = widget.winfo_rooty() - ancestor.winfo_rooty()
        assert 0 <= x <= ancestor.winfo_width() - widget.winfo_width(), (widget, "horizontal", x, widget.winfo_width(), ancestor.winfo_width())
        assert 0 <= y <= ancestor.winfo_height() - widget.winfo_height(), (widget, "vertical", y, widget.winfo_height(), ancestor.winfo_height())

    for control in (inspector.swap_btn, inspector.analyze_btn):
        inside(control, inspector)
    assert inspector.result_tabs.select() == str(inspector.summary_tab)
    for label in (inspector.summary_heading, inspector.summary_notice, *(card["value"] for card in inspector.summary_cards)):
        inside(label, inspector.summary_tab)
    assert not messages


@pytest.mark.parametrize("status", ["alignment_failed", "color_space_uncertain"])
def test_uncertain_cached_analysis_withholds_summary_values(desktop, status):
    app, tmp_path, messages, callbacks = desktop
    original, edited = _photos(tmp_path / "photos")
    inspector = _scan_and_inspect(app, original.parent)
    payload = inspector.payload
    inspector.close()
    payload["status"] = status
    payload["alignment"]["success"] = status != "alignment_failed"
    payload["tone"]["mean_luminance_delta"] = 987654.0
    payload["color"]["lab"]["delta_l"] = 456789.0
    with LibraryDB(tmp_path / "data" / DB_FILENAME) as db:
        db.save_analysis(original, edited, payload)
    app.inspect_selected()
    inspector = app._inspectors[-1]
    _pump(app, lambda: not inspector._busy)
    assert inspector.payload["status"] == status
    assert inspector._state_key == "analysis_loaded"
    assert all(card["value"].cget("text") == app.i18n.t("summary_not_measured") for card in inspector.summary_cards)
    details = inspector.details.get("1.0", "end")
    assert "987654" not in details and "456789" not in details
    assert not messages


def test_corrupt_analysis_can_be_replaced_by_reanalyze(desktop):
    app, tmp_path, messages, callbacks = desktop
    original, edited = _photos(tmp_path / "photos")
    inspector = _scan_and_inspect(app, original.parent)
    inspector.close()
    with LibraryDB(tmp_path / "data" / DB_FILENAME) as db:
        db.conn.execute("UPDATE edit_analysis SET payload_json='broken json'")
        db.conn.commit()
    app.inspect_selected()
    inspector = app._inspectors[-1]
    _pump(app, lambda: not inspector._busy)
    assert inspector._state_key == "analysis_error"
    inspector.start_analysis(force=True)
    _pump(app, lambda: not inspector._busy)
    assert inspector.payload["status"] == "ok"
    assert inspector._state_key == "analysis_saved"
    assert not messages


def test_scan_worker_error_is_shown_without_tk_callback_failure(desktop, monkeypatch):
    app, tmp_path, messages, callbacks = desktop
    _photos(tmp_path / "photos")

    def broken_scan(*args):
        raise RuntimeError("Synthetic scan failure")

    monkeypatch.setattr("personal_color_lab.ui.app.scan_folder", broken_scan)
    app.folder.set(str(tmp_path / "photos"))
    app.start_scan()
    _pump(app, lambda: not app._scanning)
    assert messages
    assert "Synthetic scan failure" in messages[-1][1]
    assert app._status_key == "scan_error"
    assert str(app.scan_btn.cget("state")) == "normal"


def test_nested_corrupt_cached_result_keeps_retry_working(desktop):
    app, tmp_path, messages, callbacks = desktop
    original, edited = _photos(tmp_path / "photos")
    inspector = _scan_and_inspect(app, original.parent)
    damaged = inspector.payload.copy()
    damaged["tone"] = {"zones": ["invalid nested type"]}
    inspector.close()
    with LibraryDB(tmp_path / "data" / DB_FILENAME) as db:
        db.save_analysis(original, edited, damaged)
    app.inspect_selected()
    inspector = app._inspectors[-1]
    _pump(app, lambda: not inspector._busy)
    assert inspector.payload is None
    assert str(inspector.analyze_btn.cget("state")) == "normal"
    inspector.start_analysis(force=True)
    _pump(app, lambda: not inspector._busy)
    assert inspector.payload["status"] == "ok"
    assert not messages


def test_closed_app_releases_tk_ownership_on_creator_thread(tmp_path, monkeypatch):
    monkeypatch.setenv("PERSONAL_COLOR_LAB_DATA_DIR", str(tmp_path / "data"))
    app = App()
    app.update()
    variable = weakref.ref(app.folder)
    widget = weakref.ref(app.title_lbl)
    owner = weakref.ref(app)
    app.close()
    assert variable() is None
    assert widget() is None
    del app
    # No gc.collect(): collection must not be deferred until another worker's
    # allocations, where Tcl interpreter destruction would use the wrong thread.
    assert owner() is None


def test_close_while_scan_is_running_does_not_leave_tk_in_worker(tmp_path, monkeypatch):
    monkeypatch.setenv("PERSONAL_COLOR_LAB_DATA_DIR", str(tmp_path / "data"))
    entered, release = threading.Event(), threading.Event()

    def delayed_scan(*args):
        entered.set()
        assert release.wait(5)
        return []

    monkeypatch.setattr("personal_color_lab.ui.app.scan_folder", delayed_scan)
    app = App()
    app.folder.set(str(tmp_path))
    app.start_scan()
    worker = app._worker_threads[-1]
    assert entered.wait(5)
    owner = weakref.ref(app)
    app.close()
    del app
    try:
        assert owner() is None
    finally:
        release.set()
        worker.join(timeout=5)
    assert not worker.is_alive()
