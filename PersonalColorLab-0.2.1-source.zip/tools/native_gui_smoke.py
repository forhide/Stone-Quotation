"""Exercise the installed application's Tk UI using its private Python runtime."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import time


def denied(*args, **kwargs):
    raise AssertionError('The packaged application attempted Python network access')


def main() -> int:
    # Synthetic fixtures only. No original library or persistent user data.
    with tempfile.TemporaryDirectory(prefix='pcl-native-gui-') as directory:
        root = Path(directory)
        os.environ['PERSONAL_COLOR_LAB_DATA_DIR'] = str(root / 'data')
        socket.socket = denied
        socket.create_connection = denied
        import cv2
        import numpy as np
        from PIL import Image
        from personal_color_lab.core.database import LibraryDB
        from personal_color_lab.ui.app import App

        photos = root / 'photos'
        photos.mkdir()
        rng = np.random.default_rng(724)
        image = cv2.GaussianBlur(rng.integers(40, 180, (280, 420, 3), dtype=np.uint8), (5, 5), 0)
        for _ in range(55):
            x, y = rng.integers(10, 260, 2)
            cv2.circle(image, (int(x), int(y)), 5, tuple(int(v) for v in rng.integers(35, 200, 3)), -1)
        for i in range(4):
            level = 50 + i * 30
            cv2.rectangle(image, (320, 15 + i * 60), (400, 50 + i * 60), (level,) * 3, -1)
        paths = [photos / 'photo_original.jpg', photos / 'photo_edit.jpg']
        Image.fromarray(image).save(paths[0], quality=98, subsampling=0)
        Image.fromarray(np.clip(image.astype(float) * 1.08 + [6, 1, -4], 0, 255).astype(np.uint8)).save(paths[1], quality=98, subsampling=0)
        fingerprints = [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
        app = App()
        callbacks = []
        app.report_callback_exception = lambda kind, value, tb: callbacks.append(str(value))

        def pump(ready):
            deadline = time.monotonic() + 40
            while time.monotonic() < deadline:
                app.update()
                if callbacks:
                    raise AssertionError(callbacks)
                if ready():
                    return
                time.sleep(0.01)
            raise AssertionError('Installed GUI operation timed out')

        try:
            assert app.i18n.language == 'en'
            # The simplest entry point must work without a preceding scan or
            # matching names. Exercise it through the installed Tk widgets.
            from personal_color_lab.ui import app as app_module
            selected = iter(str(path) for path in paths)
            original_picker = app_module.filedialog.askopenfilename
            try:
                app_module.filedialog.askopenfilename = lambda **kwargs: next(selected)
                app.choose_pair()
            finally:
                app_module.filedialog.askopenfilename = original_picker
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector.manual_selection
            assert inspector.summary_data['state'] == 'ok'
            assert inspector.summary_data['curve_available']
            assert inspector.result_tabs.select() == str(inspector.summary_tab)
            assert len(app._row_pairs) == 1
            inspector.close()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector._state_key == 'analysis_loaded'
            inspector.close()
            app.folder.set(str(photos))
            app.start_scan()
            pump(lambda: not app._scanning)
            row = next(row for row, pair in app._row_pairs.items() if pair.pair_type == 'JPG+JPG')
            app.tree.selection_set(row)
            app._selection_changed()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector.payload['status'] == 'ok'
            assert len(inspector._images) == 2
            with LibraryDB(root / 'data/library.db') as db:
                assert db.get_analysis(*paths) == inspector.payload
            inspector.close()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector._state_key == 'analysis_loaded'
            app.lang.set('ko')
            app.change_language()
            assert inspector.title() == app.i18n.t('inspector_title')
            assert app.i18n.t('inferred_analysis') in inspector.details.get('1.0', 'end')
            inspector.swap_direction()
            pump(lambda: not inspector._busy)
            assert inspector.payload['tone']['mean_luminance_delta'] < 0
            assert fingerprints == [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
            print(json.dumps({'ok': True, 'checks': ['manual_pair', 'manual_reopen_cache', 'default_summary', 'measured_curve', 'scan', 'registered_analysis', 'previews', 'database', 'cache', 'korean', 'direction_swap', 'original_hashes', 'python_network_blocked']}))
        finally:
            app.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
