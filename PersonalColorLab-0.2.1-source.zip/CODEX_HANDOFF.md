# Codex Handoff - Personal Color Lab

## Current state

Current baseline: V0.2.1, the guided JPEG comparison desktop. The V0.2.0 analysis pipeline and offline installer tooling remain in use. This is a desktop project. Mobile development is outside the current user scope.

The V0.1 recursive scanner, file classification, filename/perceptual matching candidates, SQLite library, and English/Korean UI remain. The scanner's matching confidence is not registration confidence or proof of edit history. RAW+XMP and RAW+JPG are filename-based candidates; no RAW decoder or full XMP parameter parser is present.

V0.2 adds:

- Local EXIF-oriented JPG reading, bounded analysis resolution, and ICC-to-sRGB conversion when profiles are valid. Unreadable embedded profiles withhold photometric estimates, while geometry can remain inspectable.
- Similarity-transform alignment for modest crop, resize, and rotation, with overlap and separate registration confidence. Unreliable alignment returns a failure result without tone/color estimates.
- Observed tone transfer, shadow/midtone/highlight deltas, contrast and clipping summaries, plus approximate exposure EV.
- Lab/CIE76 deltas, HSV/HSL summaries, hue-band changes, and neutral-pixel WB/tint tendencies with task-specific confidence.
- Inferred provenance, algorithm/payload versions, and input SHA-256 hashes. Changing files during analysis are rejected.
- Additive SQLite schema version 1, preserving V0.1 rows; versioned analysis save/load methods and validation of finite, GPS-free JSON.
- A selected-JPG inspector with previews, direction swapping, reanalysis, and persisted-result loading. Source-hash changes invalidate cached results and require reanalysis.
- Synthetic analysis and integration tests. Record final test results after running the suite; test counts are not a product capability.

V0.2.1 adds a shared dark graphite/lime theme, compact layouts, a bundled aperture app/installer icon, and a direct **Compare two photos** workflow. The user selects the original JPEG and edited JPEG without a scan, matching filenames, or shared folder. Three-step guidance and empty states explain the workflow. Direct selections are deduplicated in the current session's table and labeled **Chosen by you**, allowing saved comparisons to reopen without a file picker. This session list is not restored as recent history after restarting. Folder candidates remain optional and open by button, double-click, or Enter. Labeled previews make direction explicit.

The default **Changes at a glance** tab explains brightness, color tendency, and shared image area in plain language and plots the measured tone-transfer curve against an identity line. **Detailed measurements** preserves technical evidence and confidence. Failed alignment, unreadable color profiles/files, and stale cached results explain recovery steps and withhold unverified summary values/curves. English and Korean text remain external resources. No new runtime dependencies or network access were added. App/installer version is 0.2.1; analysis algorithm remains 0.2.0 and payload/database schema remains 1, preserving compatible analyses and user data.

Runtime requirements are Python 3.11+, Tkinter, Pillow, NumPy, and headless OpenCV; pytest is a development dependency. `requirements.lock` and `requirements-dev.lock` pin the Python 3.12/Linux dependency set; range files remain available for supported updates. No GPU or runtime network dependency is required. `PERSONAL_COLOR_LAB_DATA_DIR` overrides the default `~/.personal_color_lab` directory.

## Current APIs and modules

- `core/edit_reverse.py`: `analyze_pair(original_path, edited_path)` returns JSON-serializable evidence. Status is `ok`, `alignment_failed`, or `color_space_uncertain`; unreadable/changing inputs raise an exception. It writes no photo files. Both failure statuses leave tone/color empty and estimates unavailable; `color_space_uncertain` can retain successful geometric alignment.
- `core/alignment.py`: image reading, similarity registration, overlap mask, crop/resize/rotation diagnostics.
- `core/tone_analysis.py`: tone transfer, luminance zones, clipping, approximate exposure.
- `core/color_analysis.py`: Lab, HSV/HSL, hue bands, WB/tint tendencies.
- `core/schema_migrations.py`: additive schema migration using SQLite `user_version`.
- `core/database.py`: `LibraryDB.save_analysis(...)` and `get_analysis(...)`; repeat saves for a pair and algorithm/payload version update that result.
- `ui/pair_inspector.py`: previews, summary rendering, cache checks, background analysis, and UI-thread queue handling.
- `ui/app.py`: guided direct JPEG selection, optional folder scanning, candidate selection, and inspector launch.
- `ui/theme.py`: shared desktop colors, fonts, and Tk/ttk styles; no external UI package is required.

Analysis payloads separate `alignment`, `tone`, `color`, `lightroom_estimates`, `provenance`, and warnings. `source_type` is `inferred_jpg_pair`. Overall `confidence_scope` is `registered_tone_color_evidence`: registration confidence weighted by available sample support. Exposure and WB/tint estimates have their own weighted confidence. The overall value is zero when photometric analysis is withheld. The default summary plots validated measured tone-transfer samples; detailed HSV/HSL and tone metrics remain available, while dedicated hue-band visualization is future work.

Run `python -m pytest` for automated checks. On headless Linux, `python tools/run_gui_tests.py -q` runs the suite with a local Xvfb from `PATH`, or use `PERSONAL_COLOR_LAB_XVFB=/path/to/Xvfb`. The runner downloads nothing; Tkinter and Xvfb are development prerequisites. Record final outcomes in `VALIDATION.md` after validation.

## Product concept

The long-term desktop workflow is:

Photo -> scene analysis -> style selection -> adaptive edit solver -> safety/clipping checks -> Lightroom-compatible XMP -> user refinement.

Four future style sources converge into one Style DNA representation:

1. My Style, learned from the user's editing history.
2. Custom Reference Style, derived from user-supplied references.
3. Built-in Style Library, bundled derived local profiles.
4. Hybrid Style, adjustable blending of these sources.

Style DNA should cover tone, black/white points, luminance zones, WB/tint bias, HSL/channels, color grading, saturation, texture/grain/sharpness, composition metadata, scene coverage, and confidence. It is not yet implemented.

## Evidence and confidence

Observed image transforms are the primary evidence. Multiple Lightroom settings can produce similar pixels, so inferred exposure and WB/tint directions are approximate. Never label them as recovered sliders, exact XMP, or calibrated probabilities.

Separate source quality, pairing confidence, alignment confidence, and the confidence of individual estimates. Recommended future learning weights remain tentative: RAW+XMP 1.00, RAW+edited JPG 0.85, original JPG+edited JPG 0.70. These are planning guidance, not V0.2 calibrated outputs. A final-only reference is weak evidence of editing operations but may be useful evidence of the desired final appearance.

## Limits and next work

Current registration supports modest similarity transforms, not general perspective deformation, large geometry changes, or local-edit segmentation. Repeated filenames, weak textures, sparse overlap, clipping, color-space ambiguity, and scarce neutral pixels require caution. WB/tint estimates are color-cast tendencies and can be confounded by color grading or local edits. HEIC/HEIF decoding is not guaranteed by base Pillow.

Offline packaging is implemented in tools/download_runtimes.py, tools/download_wheels.py, tools/build_installers.py and packaging/windows. Windows x64 setup.exe and macOS Apple Silicon/Intel .pkg contain private verified CPython 3.13.16/Tcl-Tk and locked native wheels. See INSTALLERS.md. --self-test checks resources and synthetic analysis without user data or a display. tools/native_package_smoke.py and .github/workflows/installers.yml check installed artifacts on disposable native hosts; the workflow has not run. Completed Linux source/GUI/archive results and artifact-specific evidence are recorded in VALIDATION.md. Native release validation and signing remain pending; do not infer them from cross-build output or Wine. The authorized download-only branch in forhide/Stone-Quotation hosts delivery files separately from its main branch. The extracted Personal Color Lab source folder has no Git remote; the download branch is not the application source/CI repository.

Prioritize real-photo validation and confidence calibration of the JPG pipeline before RAW decoding. Next work includes dedicated hue-band visualization, pairing/direction improvements, registration coverage, XMP parsing, a RAW decoder interface and implementation, and sharpening/noise/grain estimation.

V0.3 will introduce common Style DNA, My Style, reference-style building, dataset diversity/outliers, bundled film/cinema/artist profiles, strength controls, and hybrid blending. V0.4 will add multilabel scenes, local regions, and composition analysis. V1.0 targets adaptive application and Lightroom-compatible XMP export.

## Preserved UX and privacy decisions

- English is the default UI; Korean is selectable. Display text belongs in locale resources.
- Original photo files remain untouched. No GPS coordinates are persisted.
- Film bundles generally describe color/tone/grain. Cinema/drama/artist bundles may include composition metadata.
- Composition-capable styles must offer Color only, Show composition suggestions, or Apply composition automatically. Default to color only or suggestions; never silently crop.
- Bundled profiles contain derived parameters/metadata, not copied film frames or photographer images.
- The installed product must run offline: no external AI/API, HTTP runtime client, cloud inference, login, telemetry, analytics, or uploads. Future models must be local, preferably ONNX, with a CPU fallback.

Read `AGENTS.md` and `OFFLINE_ARCHITECTURE.md` before architecture changes. Run tests and update development context, changelog, roadmap, and TODO to describe actual completed work after each milestone.
