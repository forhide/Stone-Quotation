# Changelog

## V0.6.0 — Travel projects and bounded processing

- Add a travel workspace with persistent folder projects, a virtual contact sheet, keep/hold/reject choices, keyboard selection and explicit selected/group corrections. Existing style-learning routes remain available.
- Keep temporary exposure, relative warmth/tint and style strength separate from saved looks. Preview the selected original and styled result before saving kept photos as new JPGs, at original size or a 2048/3840-pixel long edge.
- Add a cancellable durable serial JPG queue, immutable request snapshots, crash receipts, explicit resume/retry and exclusive publication that preserves unrelated outputs and originals.
- Read bounded capture metadata and reuse persistent browsing thumbnails, preferring embedded RAW previews. Bound image caches and full-resolution workers; browsing previews never replace RAW analysis or final rendering.
- Reuse exact verified rendering evidence across matching revisits and precise preview/export paths while retaining full source-integrity checks and model/quality invalidation. Current measured workloads and limitations are recorded in PERFORMANCE.md.
- Add database schema 4 without rewriting prior analysis/style records. App version is 0.6.0; analysis and Style DNA engine remain 0.5.6. All processing stays local with unchanged embedded models and runtime dependencies.
- Verify Windows write-capable durability handles and optional cache timestamp updates; retain the queue receipt and cache-hit checks on the installed runtime.

## V0.5.6 - Parameter evidence and supported spatial styling

- Bring contrast, saturation, clarity and texture into the pair/folder overview, with bilingual recorded, inferred, final-appearance and unmeasured provenance. Show the effective parameter evidence in the application workspace and distinguish supported pixel effects from recorded XMP-only settings.
- Estimate registered multiscale local-contrast and texture changes after the observed global tone transform is removed. Reuse existing decoded/aligned pixels. Withhold inadequate, clipped, misregistered or resampled fine-detail evidence; independent noise changes do not establish sharpening or artistic grain intent.
- Separate supported spatial changes from the learned global tone curve with a bounded joint fit. Preserve the observed curve and contrast statistics as evidence while applying the separated curve, so local contrast is not applied twice. Global-only and combined tone/detail fixtures are checked independently.
- Fit paired saturation gain and vibrance robustly where the colors support both; retain an explicit unobservable vibrance result when they do not. Learn hue-band residuals relative to the fitted global transform to avoid applying saturation twice.
- Learn supported XMP clarity, texture, sharpening amount/radius/masking and luminance/color noise controls, and apply them to previews and JPG copies with bounded local filters. Support qualifying inferred detail controls, conservative three-reference local-contrast/texture targets, scene recipes and hybrid mixing without an additional RAW decode. The filters approximate Lightroom-style behavior rather than Adobe pixels.
- Preserve recorded safe numeric controls without a pixel implementation in recorded-XMP preset exports, including identified Dehaze, camera-calibration and parametric-tone values. Label these XMP-only; do not imply that they affect JPGs or copy unsupported absolute values from one hybrid component into the whole mix. Geometry and local masks remain outside global XMP.
- Introduce Style DNA4/engine0.5.6 and scene-profile schema2, with per-control support and strict analysis/detail validation. Upgrade legacy DNA1/2/3 without mutating inputs and keep new spatial controls neutral to preserve historical rendering; DNA3 keeps existing scene adaptation. Retain SQLite3 and analysis/profile schema1, previous snapshots through0.5.5, original/GPS protection and the existing five runtime dependencies/models.
- Final test counts, installer/runtime evidence and download checks are recorded separately in VALIDATION.md after completion. Earlier performance measurements do not measure the new detail stages. Native Mac installation/display, signing/notarization, broad category accuracy and exact Sony GM II calibration remain unverified.

## V0.5.5 - Reviewed scene styles across all three source routes

- Add a checksum-pinned Microsoft TinyCLIP image encoder with local prompt vectors (MIT, 8,719,943 asset bytes) and CPU OpenCV inference. No runtime Torch, API, text encoder or download is introduced. Use 21 multilabel attributes across time, environment, subject, lighting and exposure; similarity scores are uncalibrated estimates and uncertain attributes can remain unknown. Indoor light does not establish capture time.
- Classify the full bounded original scene for RAW + JPG and a separate bounded fixed RAW baseline for RAW + XMP; preserve recorded XMP controls and successful XMP measurements if scene decoding fails. Finished JPGs describe final appearance, with content/lighting confounders retained.
- Add bilingual scene review before/after learning and during application, explicit automatic reset and unclassified fallback, visible coverage and actually applied category support. Changing labels reuses measurements, developed pixels and automatic evidence. A closed scene dialog releases its Tcl owner on the UI thread.
- Learn a common profile plus damped category deltas from at least three eligible distinct original hashes. Count duplicate originals once, review conflicting manual labels across edited companions, and withhold ambiguous multiple-edit evidence. Reference perceptual similarity damps support; RAW routes currently establish distinct hashes rather than near-duplicate diversity.
- Bound category contributions per axis and in total; preserve component-specific hybrid recipes and conservative monochrome intent. Photo tiles, JPG and precise XMP preparation use the same category recipe. XMP remains a global approximation without region masks or lens geometry.
- Introduce Style DNA3/engine0.5.5, 2 MiB portable JSON bounds and strict evidence/coverage persistence. Read legacy DNA1/2 without mutation into disabled scene profiles, retaining prior rendering. DB3 and analysis/profile schema1 remain; historical source snapshots through0.5.4 remain readable. New category evidence needs current reanalysis/review. Completed validation and platform limits appear in VALIDATION.md.

## V0.5.4 - Offline RAW equipment detection and lens distortion correction

- Read a bounded camera/lens/focal/aperture/orientation whitelist with pure-Python ExifRead 3.5.1. Support TIFF-family RAW layouts, ORF/RW2 adaptations, RAF embedded EXIF and Canon CR3 CMT1/CMT2; exclude GPS, serials, owners, dates and whole EXIF. Numeric-only lens IDs remain unknown, and auxiliary metadata failures preserve valid RAW development.
- Bundle 56 unchanged official Lensfun XML files and CC BY-SA 3.0 attribution from commit `43f9e001ab66c4fcdd4f400463f13b72f94b2288`, with size/hash verification. Apply supported rectilinear poly3/poly5/PTLens distortion only for a unique verified equipment/focal/geometry match; preserve the current development when data is missing, ambiguous or unsupported.
- Enable correction by default in the RAW style workspace with an off control, detected equipment/status, explicit edge-zoom reporting and a filterable camera/lens/focal selection dialog. Manual choices are photo-specific, preserve detected metadata and never invent a missing calibration. The pinned data contains Sony A7CR but no FE 16–35mm F2.8 GM II distortion calibration; GM I is never substituted.
- Correct sensor development before resize, color measurements and region recognition. Preserve one full-quality RAW development for final JPG export and use its corrected AREA preview for adaptation/mask geometry. Quality/mode/manual equipment/calibration identity gate preview reuse. Originals and output dimensions are preserved; valid-edge fitting can narrow the field of view.
- Keep RAW + edited JPG learning on the prior optical-correction-off baseline, and keep geometry out of Style DNA. Global XMP exports color settings without Lensfun geometry, fabricated Adobe profiles or local masks; disclose this in the UI. Embedded DNG geometry instructions skip additional correction because their application state is uncertain.
- Retain offline processing with five pinned runtime dependencies, unchanged SQLite3, analysis/profile schema1 and DNA2/engine0.5.0; app/analysis0.5.4 reads historical snapshots through0.5.3. Chromatic aberration, vignetting, fisheye/Adobe LCP, in-camera APS-C/digital crop calibration, actual camera evaluation and native M1/signing validation remain outside the completed feature scope. VALIDATION.md records completed release checks; retained V0.5.3 timings do not measure the new optical stage.

## V0.5.3 - Safer RAW reading and faster style application

- Validate sensor dimensions with RawPy.open_file before unpacking pixels; reject invalid or above-120MP headers early. Check cancellation between RAW open/unpack/develop/resize stages; active native LibRaw calls remain cooperative rather than immediately interruptible.
- Preserve full AHD/camera-WB/sRGB development as the analysis and export default. Add an explicit, initially disabled Fast RAW preview for eligible large RGB Bayer sensors with recorded approximation/quality provenance, correct mirrored/rotated dimensions and baseline fallback for unsupported geometry/CFA or small inputs. Fine color/detail differences remain possible; no embedded JPEG is used.
- Develop the full sensor once per RAW-to-JPG export and derive its identical AREA measurement preview. Keep the separate decoder-assisted JPEG preview path and preserve source checks, full-resolution copies, sRGB ICC and GPS exclusion.
- Recompute adaptive XMP settings from the strict RAW baseline after fast preview; keep global XMP approximation and Adobe/local-mask limitations explicit.
- Prepare source-level exposure/channel lookup tables and exact shared-grid tone coefficients, and reuse mask coordinates. The measured rendering fixtures retain their output pixels; PERFORMANCE.md records precise CPU workload scope rather than a whole-app/native-platform promise.
- Gate preview/measurement/style-thumbnail reuse on source content and RAW quality, and recognition reuse on the current verified model identity. Retain global styling with an explicit notice when recognition is unavailable; clear stale evidence across quality changes.
- App/analysis0.5.3, unchanged SQLite3, analysis/profile schema1 and DNA2/engine0.5.0. Prior0.3/0.4/0.5.0/0.5.1/0.5.2 analysis snapshots remain readable. Runtime remains offline and preserves original photos; VALIDATION.md records completed release checks and native-platform limits.

## V0.5.2 - Faster local processing and a refined photo studio

- Reuse circular color/chroma statistics and avoid expensive palette copies; retain the same analysis values, sample bounds and palette output on the measured inputs.
- Skip unchanged rendering transforms, prepare regional recipes once, and reuse hybrid component baselines/mask coordinates within bounded tiles. Restrict face-color conversion to supported bounds; retain pixel-exact benchmark results.
- Score-filter NanoDet candidates before box regression, skip empty-region filtering and avoid stacked mask tensors. Keep recognition model resolution/thresholds and the measured faster default thread policy.
- Share pair tone correction and batch reference fingerprints while preserving final actual-file verification. Cooperative reference cancellation keeps completed results.
- Add a photo-first studio with a right settings inspector, native-vector sliders/toggles, actual photo-based style tiles, direct wipe dragging, expandable subject/analysis details and a focused export footer.
- Clarify home build/apply routes, three source cards, current workflow steps and counted analysis actions. Preserve selection across language changes and offer folder changes without dropping explicit source choices.
- App/analysis0.5.2, unchanged SQLite3 and DNA2/engine0.5.0; prior analysis snapshots remain readable. PERFORMANCE.md records measured workload-specific timings; VALIDATION.md records release checks.

## V0.5.1 - Review fixes for style learning, rendering and recovery

- Correctly transfer pure monochrome intent from supported RAW/JPG or JPG/JPG comparisons and unanimously gray JPG references. Mixed-color, sepia, clipped and insufficient evidence remain conservative. Historical paired analyses need reanalysis to add the new evidence; reference snapshots already contain the needed appearance statistics.
- Preserve supported monochrome context/region recipes without removing color from unrelated regions. Share bounded preview measurements with full-resolution local rendering to keep component baselines consistent.
- Validate render options before recognition, honor cancellation at neutral/zero strength, preserve unchanged face pixels exactly, and skip unnecessary regional work.
- Encode exports in a private sibling file before publishing the new filename. Cancellation and ordinary failure remove this operation's partial files without replacing another output. Recheck the original after JPEG encoding; validate finite effective XMP values. Filesystems without hard links use an exclusive cancellable copy.
- Treat analysis cache failures as optional recovery, preserving valid results and correct counts. Reanalyze missing-model caches after model repair; validate cached semantic evidence and all model/license/manifest identities together.
- Clear stale photo/evidence on selection failures, preserve mix/composition/name state across language changes, scroll settings over child controls, and retain export locks during redraws and shortcuts.
- App and analysis algorithms0.5.1; SQLite3, analysis/profile schema1 and DNA2/engine0.5.0 remain compatible. Historical0.3/0.4/0.5.0 analysis snapshots stay readable. See VALIDATION.md for final tests, installed checks and platform limits.

## V0.5.0 - Embedded object recognition and a clearer style workspace

- Bundled checksum-verified local NanoDet COCO-80 object detection, PP-HumanSeg person segmentation and YuNet face detection (3,091,271 model bytes). Inference uses OpenCV DNN CPU; no API, token charge, runtime download, login or network client is added.
- Added object-derived context tags, region previews, optional face-color protection and adjustable region strength. Non-person objects use approximate boxes; faces use protection ellipses. These are not face identities or general instance segmentation.
- Learned reference region/context targets require three distinct supported image encodings; image pairs learn observed regional transforms in registered valid overlap. Reference lighting/content confounders remain. Unsupported/missing models withhold semantic evidence explicitly.
- Added visual tone/color fingerprint suggestions, one-click trials, reset, keyboard shortcuts and full-width wipe comparison. Settings move into a scrolling side panel while original/styled previews and exports stay visible; mixing/composition controls are grouped separately.
- JPG exports include local region/face effects. XMP exports remain approximate global presets and do not serialize Adobe semantic masks. Original bytes and GPS exclusion remain intact.
- Refined hybrid region changes to replace only the contributing component effect; stale preview results retain decoded/recognized inputs for the latest adjustment. Neutral/monochrome behavior and mask-tile skipping are verified.
- Style DNA schema2 / engine0.5.0 upgrades legacy0.4.0 schema1 recipes on read; SQLite remains3 and historical analysis profiles remain readable. New0.5 profiles/recipes require the new app.
- Real-model execution and region learning/application passed with network denied using external test-only photos. Tests and native-platform limits are recorded in VALIDATION.md.

## V0.4.0 - Style application, portable recipes and faster analysis

- Unified learned pair transforms, recorded XMP settings, finished-JPG references and bundled profiles into validated Style DNA (schema 1).
- Added a style workspace with original/edited previews, strength adjustment, two-style mixing, 12 derived film/cinema/artist profiles and saved recipes.
- Adapted reference targets to each input's tone distribution; optional low/mid/high-key subprofiles require three distinct supporting images. These are pixel-lighting groups, not semantic scene recognition.
- Added full-resolution JPEG copies with sRGB ICC and stripped EXIF/GPS, Lightroom-importable global XMP presets, and local style JSON import/export. Existing files are never overwritten.
- Composition remains color-only by default; users can show an aspect-ratio guide or explicitly crop an exported copy. No original is cropped.
- Added content-addressed, bounded SQLite analysis caching and pre-decode exact-duplicate exclusion; similar-image groups are review hints and remain included.
- Added analysis snapshot rename/delete, additive database schema 3, source preview reuse and deprecated Pillow API cleanup. Existing schema-0/1/2 data and 0.3.0 analysis snapshots remain readable; older apps cannot open schema 3.
- Corrected color-transform learning to subtract the observed tone transfer before measuring residual color. App/analysis versions are 0.4.0; analysis payload schema remains 1.
- Retained the embedded Mac component fix. Native Mac installation, Apple signing/notarization, semantic scene/local-mask models and exact Adobe rendering remain pending.

## V0.3.1 - macOS installer reference fix

- Fixed Distribution to use the embedded fragment URL `#application.pkg` instead of an external relative component lookup.
- Added component resolution, required installation-data and identity/version validation with regression tests.
- Rebuilt Mac installers; app0.3.1 retains algorithm0.3.0, payload1/database2 and the existing Windows0.3.0 delivery. Native Mac installation/signing remain unverified.

## V0.3.0 - Three source routes and saved analysis styles

- Connected Choose folder to RAW + edited JPG, RAW + XMP and finished JPG reference workflows, including review, exclude, manual companion resolution, progress, per-file failures and cancellation between files.
- Added sensor RAW decoding through pinned rawpy 0.25.1 / LibRaw 0.21.4, with an explicit camera-WB sRGB baseline, no automatic brightness and safe decoder provenance. RAW/JPG comparison reuses registered tone/color inference and does not claim exact Lightroom recovery.
- Added bounded namespace-whitelisted Camera Raw XMP parsing for supported global settings and RGB curves. Missing settings remain unknown; unsupported/local-mask/custom-profile behavior and unverified rendering/association stay explicit.
- Added JPG-only final-appearance measurements for luminance, contrast, saturation, Lab/chroma, tonal zones, hue bands and representative colors without requiring an original.
- Added equal-image-weighted reference aggregation, exact-byte duplicate exclusion, dispersion, heuristic consistency, sample-coverage limits and flagged appearance outliers. Scene labels and original edit history are not inferred.
- Added collection and individual result views, named saved analysis snapshots and reopening after restart. Saving does not yet apply a style to another image or export XMP.
- Added additive database schema 2 while preserving prior rows/settings; app and algorithm versions are 0.3.0 and payload schema remains 1. Earlier algorithm comparisons require reanalysis for current results.
- Retained direct JPEG comparison, English/Korean resources, readable DPI-aware UI, offline execution and original/GPS safeguards; extended installer dependency inputs to include rawpy/LibRaw.
- Final completed tests and installer verification are recorded in `VALIDATION.md`. Native OS/display validation, signing and notarization remain pending.

## V0.2.2 - Readability and display scaling

- Increased small text from 9 to 10 points and measurement text from 10 to 11 points; strengthened secondary text contrast.
- Configured Windows DPI awareness before creating Tk windows, with supported fallbacks and respect for an already-configured process. Initial-window DPI sets native point-sized fonts and scaled layout spacing.
- Preserved macOS high-resolution app metadata and bundled Tk 9 Retina rendering; use the native `TkDefaultFont` system family without forcing double-sized Cocoa coordinates.
- Removed repetitive Offline Only, sidebar privacy, and inspector original-file notices from the interface. Offline execution, file preservation, analysis warnings, and provenance remain unchanged.
- Updated app/installer version to 0.2.2 while retaining analysis algorithm 0.2.0 and payload/database schema 1.
- Completed validation is recorded in `VALIDATION.md`. Actual Windows/macOS DPI/Retina behavior, native CI, signing, and notarization remain unverified; large text/display scaling can require a larger desktop viewport.

## V0.2.1 - Desktop interface and guided comparison

- Replaced the default widget presentation with a shared dark graphite/lime desktop theme, clearer spacing, compact layouts, and consistent controls.
- Added **Compare two photos**: choose an original JPEG and its edited version directly, without requiring matching filenames, a shared folder, or a library scan.
- Added three-step guidance, useful empty states, clear original/edited preview labels, and double-click/Enter shortcuts for scanned JPEG candidates.
- Kept directly chosen pairs in the current session's table with a **Chosen by you** label, allowing saved comparisons to reopen without another file selection and avoiding duplicate rows.
- Added a bundled aperture icon for app windows, Windows executables/setup, and the macOS app.
- Made plain-language brightness, color-tendency, and shared-area cards the default result view. Added a measured tone-transfer curve with an identity reference line; detailed measurements remain available in a separate tab.
- Added localized recovery guidance for failed alignment, unreadable color profiles/files, and stale saved results. Unverified tone/color measurements and curves remain withheld.
- Updated English and Korean resources without adding runtime dependencies or network access.
- Versioned the desktop app and Windows/macOS installers as 0.2.1 while retaining analysis algorithm 0.2.0 and payload/database schema 1. Existing user data and compatible analyses are preserved.
- Installer build and validation evidence is recorded in `VALIDATION.md`; native Windows/macOS hardware validation, CI execution, signing, and notarization remain pending.

## V0.2.0 - Offline installation milestone

- Added Windows x64 per-user setup.exe, a windowless launcher, Start Menu/app-list integration and an owned-file uninstaller preserving user data and unrelated files.
- Added separate macOS Apple Silicon/Intel .pkg with private .app runtimes, OS/architecture requirements and native Apple or cross-host XAR/BOM/CPIO build tools.
- Bundled verified CPython 3.13.16/Tcl-Tk, Pillow 12.3.0, NumPy 2.3.5, OpenCV 4.14.0.94, locale resources and license notices. Build-time pip/ensurepip/downloader tools are excluded.
- Added cwd-independent locale loading and offline --self-test using synthetic JPGs and temporary SQLite data.
- Added native installed-app GUI checks and a manually triggered three-platform CI workflow; native CI execution remains pending.
- Expanded Linux source/GUI/archive checks to 144 passing tests. Native signing/notarization remains pending; see VALIDATION.md and INSTALLERS.md for artifact-specific evidence.

## V0.2.0 - Selected JPG pair analysis

- Added CPU-only local JPG registration for modest crop, resize, and rotation, with EXIF orientation and local ICC handling.
- Added overlap/registration confidence and explicit alignment failure without fabricated tone/color estimates.
- Added `color_space_uncertain` handling for unreadable embedded ICC profiles, retaining geometry while withholding tone/color and approximate estimates.
- Added observed tone transfer, luminance-zone deltas, contrast/clipping summaries, Lab deltas, HSV/HSL and hue-band summaries.
- Added approximate exposure EV and WB/tint tendencies with separate confidence and limitations; no exact Lightroom slider recovery is claimed.
- Added inferred provenance, versioned payloads, source SHA-256 hashes, and rejection of changing analysis inputs.
- Scoped overall confidence to registered tone/color evidence; exposure and WB/tint estimates retain separate confidence.
- Added an additive SQLite version-1 migration, preserving V0.1 rows, plus validated versioned analysis save/load.
- Added a localized desktop pair inspector with previews, direction swapping, reanalysis, saved-result loading, and source-hash cache invalidation.
- Added a writable data-directory override through `PERSONAL_COLOR_LAB_DATA_DIR`.
- Added pinned runtime/development dependency files and a local-Xvfb desktop test runner.
- Added synthetic analysis and integration checks; 119 tests pass on Linux/Python 3.12 and 3.13, including seven actual desktop flows. See `VALIDATION.md`.
- Fixed closed-window worker ownership and Tk cleanup, plus malformed nested-cache recovery.
- Preserved the offline runtime, original photo files, and GPS exclusion. RAW decoding, full XMP handling, and style application remain deferred.

## V0.1

- Added recursive dataset scanning and RAW/JPG/image/XMP classification.
- Added filename-based RAW+XMP and RAW+JPG candidates and original/edited-JPG candidates with naming/perceptual information.
- Added pair confidence values and local SQLite persistence.
- Added English default UI and Korean selectable UI.
- Established the offline runtime contract and excluded GPS persistence.
