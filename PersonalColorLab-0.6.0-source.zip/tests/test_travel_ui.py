"""Real trip UI flows, persistent edits and bounded contact-sheet ownership."""
import hashlib
from pathlib import Path
import threading

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.style_dna import identity_dna
from personal_color_lab.core.synthetic_raw import write_test_dng
from personal_color_lab.core.travel_store import TravelStore
from test_source_workflow_ui import desktop, _pump, pytestmark


def _photos(folder,count=3):
    folder.mkdir()
    y,x=np.indices((140,220))
    for index in range(count):
        pixels=np.stack((55+x//3+index,50+y//3,60+x//5),axis=2).astype('uint8')
        Image.fromarray(pixels).save(folder/f'DSC{index:05d}.jpg',quality=95)
    return folder


def _open(app,folder):
    workspace=app.open_travel_workspace(folder=folder)
    _pump(app,lambda:not workspace._busy)
    assert workspace._photos,workspace.status.get()
    workspace.recognition.set(False);workspace.lens_correction.set(False);workspace._settings_changed()
    return workspace


def _ready(workspace):
    return (not workspace._preview_running and workspace._preview_after is None
            and workspace._preview is not None)


def test_trip_picks_photo_layers_real_preview_export_and_reopen(desktop,monkeypatch):
    app,tmp=desktop
    folder=_photos(tmp/'trip')
    originals={path:hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir()}
    with LibraryDB(tmp/'data/library.db') as db:
        style_id=db.save_style_preset('My travel look',identity_dna('My travel look'))
    workspace=_open(app,folder)
    assert str(app.travel_btn.cget('state'))=='normal'
    assert 'saved:'+str(style_id) in workspace._styles
    ids=[row['id'] for row in workspace._photos]
    with TravelStore(workspace.db_path) as store:
        for photo_id in ids[:2]:store.update_photo(photo_id,group_id='test-shooting-group')
    workspace.load_project(workspace._project_id)
    workspace.grid_view.select_ids(ids[:2]);workspace.mark_pick('hold')
    workspace.grid_view.select_ids([ids[2]]);workspace.mark_pick('reject')
    workspace.grid_view.select_ids(ids[:2]);workspace.mark_pick('keep')
    workspace.exposure.set(.35);workspace.warmth.set(15);workspace.tint.set(-8)
    workspace.photo_strength.set(80);workspace._edits_changed();workspace.apply_to_group()
    _pump(app,lambda:_ready(workspace))
    assert not np.array_equal(workspace._preview['original'],workspace._preview['rendered'])
    assert workspace._preview['photo_adjustments']['exposure_ev']==.35
    assert len(workspace._preview_images)==2
    assert not workspace._preview_cancel.is_set()
    with TravelStore(workspace.db_path) as store:
        rows=store.list_photos(workspace._project_id)
        assert [row['pick'] for row in rows]==['keep','keep','reject']
        assert rows[0]['adjustments']==rows[1]['adjustments']
        assert rows[2]['adjustments']['exposure_ev']==0
    worker_threads=[]
    from personal_color_lab.core import travel_jobs
    real_export=travel_jobs.export_jpeg
    def observed_export(*args,**kwargs):
        worker_threads.append(threading.current_thread())
        return real_export(*args,**kwargs)
    monkeypatch.setattr(travel_jobs,'export_jpeg',observed_export)
    workspace.destination=str(tmp/'exports')
    workspace.start_export(selected=True)
    _pump(app,lambda:not workspace._busy)
    assert len(list((tmp/'exports').glob('*.jpg')))==2,workspace.status.get()
    assert worker_threads and all(thread is not threading.main_thread() for thread in worker_threads)
    with TravelStore(workspace.db_path) as store:
        tasks=store.list_tasks(workspace._project_id)
        assert len(tasks)==2 and all(task['status']=='completed' for task in tasks)
        snapshots=[task['request'] for task in tasks]
    workspace.exposure.set(1.1);workspace._edits_changed();workspace._flush_edits()
    workspace.resume_exports();_pump(app,lambda:not workspace._busy)
    assert len(worker_threads)==2
    with TravelStore(workspace.db_path) as store:
        assert [task['request'] for task in store.list_tasks(workspace._project_id)]==snapshots
    project_id=workspace._project_id;workspace.close()
    reopened=app.open_travel_workspace(project_id=project_id)
    assert reopened._photos[0]['adjustments']['exposure_ev']==1.1
    assert len(reopened.tasks.get_children())==2
    assert not reopened._busy
    assert originals=={path:hashlib.sha256(path.read_bytes()).hexdigest() for path in originals}


def test_raw_only_folder_and_matching_jpg_are_one_navigation_source(desktop):
    app,tmp=desktop
    folder=tmp/'raw-trip';folder.mkdir()
    raw=write_test_dng(folder/'DSC00001.dng')
    Image.new('RGB',(180,120),(100,110,120)).save(folder/'DSC00001.jpg')
    digest=hashlib.sha256(raw.read_bytes()).hexdigest()
    workspace=_open(app,folder)
    assert len(workspace._photos)==1 and workspace._photos[0]['kind']=='raw'
    workspace.grid_view.select_ids([workspace._photos[0]['id']])
    workspace.notebook.select(workspace.compare)
    _pump(app,lambda:_ready(workspace))
    assert workspace._preview['raw_decode']
    assert workspace._preview['source_path']==str(raw)
    assert digest==hashlib.sha256(raw.read_bytes()).hexdigest()


@pytest.mark.parametrize('desktop',[1,1.5,2],indirect=True)
@pytest.mark.parametrize('language',['en','ko'])
def test_travel_minimum_layout_and_500_photo_grid_is_virtual(desktop,language):
    app,tmp=desktop;app.lang.set(language);app.change_language()
    workspace=app.open_travel_workspace()
    minimum=workspace.minsize();workspace.geometry(f'{minimum[0]}x{minimum[1]}')
    rows=[{'id':index+1,'source_path':str(tmp/f'photo-{index:04d}.jpg'),'pick':'keep',
        'size_bytes':123,'mtime_ns':index,'adjustments':{},'group_id':None} for index in range(500)]
    workspace._photos=rows;workspace._refresh_grid();workspace.empty.grid_remove()
    _pump(app,lambda:len(workspace.grid_view.visible_ids)>1)
    assert len(workspace.grid_view.visible_ids)<40
    assert len(workspace.grid_view.canvas.find_all())<250
    pixels=np.zeros((60,90,3),dtype=np.uint8)
    for photo_id in range(1,501):workspace.grid_view.set_thumbnail(photo_id,pixels)
    assert workspace.grid_view.image_count==64
    workspace.grid_view.canvas.yview_moveto(1);workspace.grid_view._schedule();app.update()
    assert max(workspace.grid_view.visible_ids)>450
    workspace.grid_view.select_ids([490,491]);assert workspace.grid_view.selection()==[490,491]
    assert workspace.title()==app.i18n.t('travel_title')
    assert workspace.new_btn.winfo_rootx()+workspace.new_btn.winfo_width()<=workspace.winfo_rootx()+workspace.winfo_width()+2
    assert workspace.export_btn.winfo_rootx()+workspace.export_btn.winfo_width()<=workspace.winfo_rootx()+workspace.winfo_width()+2
    assert workspace.cancel_btn.winfo_rooty()+workspace.cancel_btn.winfo_height()<=workspace.winfo_rooty()+workspace.winfo_height()+2
    assert workspace.grid_view.winfo_width()>200
    workspace.close()


def test_close_while_preview_and_thumbnail_jobs_are_active(desktop):
    app,tmp=desktop;workspace=_open(app,_photos(tmp/'closing-trip',8))
    workspace.grid_view.select_ids([workspace._photos[0]['id']]);workspace._launch_preview()
    workspace.close();app.update()
    assert workspace._closed and workspace._stop.is_set() and workspace._preview_cancel.is_set()
    app.lang.set('ko');app.change_language()
    assert not app._travel_workspaces


def test_close_releases_tk_owners_before_worker_collection(desktop):
    import gc
    import weakref
    import tkinter as tk
    app,tmp=desktop
    gc.collect()
    workspace=app.open_travel_workspace()
    variable_refs=[weakref.ref(value) for value in vars(workspace).values() if isinstance(value,tk.Variable)]
    grid=workspace.grid_view
    workspace.close()
    assert all(reference() is None for reference in variable_refs)
    assert grid.canvas is None and grid.scroll is None
    assert all(not isinstance(value,tk.Misc) for name,value in vars(workspace).items() if name!='master')
    worker=threading.Thread(target=gc.collect)
    worker.start();worker.join(5)
    assert not worker.is_alive()
