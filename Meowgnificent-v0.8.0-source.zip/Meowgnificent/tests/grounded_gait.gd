extends SceneTree
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
 checks+=1
 if ok: print("PASS: "+message)
 else:
  failures+=1
  push_error("FAIL: "+message)
func frames(count: int) -> void:
 for i in range(count):
  await physics_frame
  await process_frame
func _initialize() -> void: call_deferred("run")
func run() -> void:
 # Stance is a fixed world contact in every travel direction, rather than
 # a leg bob that slides along with the body. At least one foot is on ground.
 for direction: Vector2 in [Vector2.RIGHT,Vector2.LEFT,Vector2.UP,Vector2.DOWN,Vector2(1,1).normalized()]:
  var first := GroundedCatGait.foot(4,direction,1)
  var next := GroundedCatGait.foot(8,direction,1)
  check((direction*4+Vector2(first.offset)).is_equal_approx(direction*8+Vector2(next.offset)),"stance contact stays fixed while body travels "+str(direction))
  check(first.lift==0.0 and next.lift==0.0,"supporting paw stays on the floor "+str(direction))
 var always_supported := true
 var alternating := false
 var max_lift := 0.0
 for i in range(144):
  var sample := GroundedCatGait.sample(i*0.5,Vector2.RIGHT,1)
  always_supported=always_supported and (sample.left.planted or sample.right.planted)
  alternating=alternating or (sample.left.lift>0 and sample.right.lift==0)
  max_lift=maxf(max_lift,maxf(sample.left.lift,sample.right.lift))
 check(always_supported and alternating,"left and right paws take turns swinging without a floating interval")
 check(max_lift>6.8 and max_lift<=GroundedCatGait.FOOT_LIFT,"swing visibly clears the floor within the short-leg reach")
 var resting := GroundedCatGait.sample(37,Vector2.RIGHT,0)
 check(resting.left.offset==Vector2.ZERO and resting.right.offset==Vector2.ZERO and resting.left.lift==0 and resting.right.lift==0,"rest returns both paws to the natural standing pose")
 change_scene_to_file("res://scenes/main.tscn")
 await frames(4)
 var room=current_scene
 room.begin_or_restart()
 for enemy in room.enemies: enemy.active=false
 room.player.invulnerability=1000
 room.player.position=Vector2(500,420)
 var visual: WizardCatVisual=room.player.visual
 room.player.set_physics_process(false)
 room.player.walk_distance=4
 room.player.ground_speed=float(room.player.config.speed)
 room.player.walk_direction=Vector2.RIGHT
 visual.gait=1
 visual._process(0)
 var planted_paw: Vector2=visual.feet[0].global_position
 room.player.position+=Vector2(8,0)
 room.player.walk_distance+=8
 visual._process(0)
 check(visual.feet[0].global_position.is_equal_approx(planted_paw),"the rendered supporting paw stays at its world contact while the real body advances")
 room.player.set_physics_process(true)
 var start_distance: float=room.player.walk_distance
 Input.action_press("move_right")
 await frames(18)
 Input.action_release("move_right")
 check(room.player.walk_distance>start_distance+20 and room.player.ground_speed>0,"real movement advances the foot cycle using displacement")
 check(visual.feet.size()==2 and visual.feet[0].texture is AtlasTexture and visual.feet[1].texture is AtlasTexture,"two separate painted paw bones articulate without stretching the body image")
 var paw_texture := visual.feet[0].texture
 check(visual.rotation==0 and visual.position==Vector2.ZERO,"walking does not rock or lift the entire character off the floor")
 var mesh := visual.sprite.mesh
 room.player.position=Vector2(room.bounds.end.x-float(room.player.config.radius),420)
 room.player.velocity=Vector2.ZERO
 Input.action_press("move_right")
 await frames(5)
 var wall_distance: float=room.player.walk_distance
 await frames(10)
 Input.action_release("move_right")
 check(is_equal_approx(room.player.walk_distance,wall_distance) and room.player.ground_speed==0,"pushing a room wall does not moonwalk in place")
 room.player.position=Vector2(500,420)
 room.player.velocity=Vector2.ZERO
 room.player.start_roll(Vector2.RIGHT)
 var roll_distance: float=room.player.walk_distance
 await frames(8)
 check(is_equal_approx(room.player.walk_distance,roll_distance) and visual.active_pose==5,"rolling uses its tucked pose without advancing walking feet")
 room.player.roll_time=0.001
 await frames(1)
 check(is_equal_approx(room.player.walk_distance,roll_distance),"the final partial roll tick does not become a walking stride")
 room.player.velocity=Vector2.ZERO
 await frames(6)
 room.set_running(false)
 await frames(2)
 var paused_distance: float=room.player.walk_distance
 var paused_feet: Dictionary=visual.foot_state.duplicate(true)
 var paused_elapsed: float=visual.elapsed
 await frames(8)
 check(is_equal_approx(room.player.walk_distance,paused_distance) and visual.foot_state==paused_feet and is_equal_approx(visual.elapsed,paused_elapsed),"pause freezes gait, body and feet together")
 check(visual.sprite.mesh==mesh,"walking, wall contact, rolling and pause reuse the same mesh resource")
 check(visual.feet[0].texture==paw_texture and visual.feet[0].get_parent()==visual,"walking, rolling and pause reuse paw textures and nodes")
 print("GROUNDED GAIT RESULT: %d checks, %d failures" % [checks,failures])
 quit(0 if failures==0 else 1)
