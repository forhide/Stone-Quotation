const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 let checks=0;
 try {
  const context=await browser.newContext({viewport:{width:1280,height:800}});const page=await context.newPage();const errors=[],failed=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});page.on('response',r=>{if(r.status()>=400)failed.push(r.url())});
  function check(ok,name){assert(ok,name);checks++;console.log('PASS: '+name)}
  async function screen(name){
   const path='/tmp/meowgnificent-v080-localized-web-'+name+'.png';await page.screenshot({path});
   let clip=null;
   if(name.includes('settings'))clip={x:370,y:238,width:540,height:320};
   else if(name.includes('intro')||name.includes('reloaded'))clip={x:600,y:240,width:550,height:470};
   else if(name.includes('inventory'))clip={x:110,y:72,width:1060,height:656};
   else if(name==='story-en'||name==='story-ko'||name==='professor-ko')clip={x:74,y:528,width:1132,height:248};
   let input=path;
   if(clip){input=path.replace('.png','-ocr.png');await page.screenshot({path:input,clip})}
   if(name==='story-ko'||name==='professor-ko'){
    const normalized=input.replace('.png','-contrast.png');
    execFileSync('python3',['-c','from PIL import Image,ImageOps,ImageEnhance; import sys; im=ImageEnhance.Contrast(ImageOps.autocontrast(Image.open(sys.argv[1]).convert("L"))).enhance(2); im.resize((im.width*2,im.height*2)).save(sys.argv[2])',input,normalized]);
    input=normalized;
   }
   return execFileSync('tesseract',[input,'stdout','--tessdata-dir','/workspace/Meowgnificent/.local/tessdata','-l','kor+eng','--psm','11'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_THREAD_LIMIT:'1'}}).toLowerCase()
  }
  async function expectScreen(name,predicate,description){let text='';for(let i=0;i<20;i++){await page.waitForTimeout(180);text=await screen(name);if(predicate(text)){check(true,description);return text}}assert.fail(description+'; OCR '+JSON.stringify(text))}
  async function ready(){await page.waitForFunction(()=>!document.querySelector('#status'),{},{timeout:90000});await page.waitForTimeout(600)}
  async function key(value){await page.keyboard.down(value);await page.waitForTimeout(100);await page.keyboard.up(value);await page.waitForTimeout(150)}
  async function choose(index){
   await page.mouse.click(635,389,{delay:100});await page.waitForTimeout(250);
   await page.screenshot({path:'/tmp/meowgnificent-v080-language-dropdown-'+index+'.png'});
   await page.mouse.click(590,index===0?430:458,{delay:100});await page.waitForTimeout(350)
  }
  const url=new URL(process.env.GAME_URL||'http://127.0.0.1:8082/');url.searchParams.delete('lang');url.searchParams.delete('skip_story');
  await page.goto(url.href,{waitUntil:'networkidle'});await ready();
  check(!new URL(page.url()).searchParams.has('lang'),'ordinary player URL has no forced language');
  await expectScreen('intro-ko',t=>t.includes('영구 강화')&&t.includes('모험 시작'),'fresh player sees Korean menu by default');
  await page.locator('#canvas').click({position:{x:180,y:680}});await key('F10');
  await expectScreen('settings-ko',t=>t.includes('설정')&&t.includes('언어')&&t.includes('한국어'),'F10 opens Korean settings and language choice');
  await choose(1);
  await expectScreen('settings-en',t=>t.includes('settings')&&t.includes('language')&&t.includes('english')&&t.includes('changes apply'),'real language dropdown immediately changes the options screen to English');
  await key('Escape');
  await expectScreen('intro-en',t=>t.includes('a minor magical incident')&&t.includes('begin expedition'),'closing settings returns to the English start menu');
  await page.waitForTimeout(3000);await page.reload({waitUntil:'networkidle'});await ready();
  await expectScreen('reloaded-en',t=>t.includes('a minor magical incident')&&t.includes('begin expedition'),'English preference survives a complete WASM page reload with no language flag');
  await page.locator('#canvas').click({position:{x:180,y:680}});await key('Enter');
  await page.waitForTimeout(180);await key('F10');
  await expectScreen('story-en',t=>t.includes('arcana academy')&&/0?1\s*\/\s*14/.test(t),'default opening uses English dialogue after the saved language choice');
  await expectScreen('story-settings',t=>t.includes('changes apply'),'settings can open over an active story');
  await choose(0);
  await expectScreen('story-ko',t=>t.includes('대륙 최고의')&&/0?1\s*\/\s*14/.test(t),'switching back to Korean keeps the same opening page and translates its dialogue');
  await key('Escape');await page.waitForTimeout(180);await key('Space');
  await page.waitForTimeout(100);await key('F10');
  await expectScreen('professor-ko',t=>t.includes('화염구')&&t.includes('교수')&&/0?2\s*[/|7]\s*14/.test(t),'Korean professor dialogue advances normally after leaving language options');
  await key('Escape');await page.waitForTimeout(180);await key('Escape');
  await expectScreen('detention-ko',t=>t.includes('벌 청소')&&t.includes('통로 잠김')&&!t.includes('이야기 건너뛰기'),'skipping the story enters Korean gameplay');
  await key('i');
  await expectScreen('inventory-ko',t=>t.includes('장비와 가방')&&t.includes('지팡이')&&t.includes('목걸이')&&t.includes('장식'),'equipment UI is Korean during the same expedition');
  await page.waitForTimeout(3000);await page.reload({waitUntil:'networkidle'});await ready();
  await expectScreen('reloaded-ko',t=>t.includes('영구 강화')&&t.includes('모험 시작'),'Korean preference also survives a complete reload');
  check(failed.length===0,'all localized assets load successfully');check(errors.length===0,'localized dropdown, story and reload flow have no JavaScript or engine errors: '+JSON.stringify(errors));
  console.log(`LOCALIZED WEB RESULT: ${checks} checks, 0 failures`);
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
