class_name GroundedCatGait
extends RefCounted

# Distance, rather than a wall-clock sine wave, drives the feet. During stance
# the offset moves backwards by exactly the distance travelled by the body.
const CYCLE_DISTANCE := 72.0
const STANCE_FRACTION := 0.58
const STRIDE := CYCLE_DISTANCE * STANCE_FRACTION
const FOOT_LIFT := 7.0

static func foot(distance: float, direction: Vector2, strength: float, alternate: bool = false) -> Dictionary:
	var phase := fposmod(distance / CYCLE_DISTANCE + (0.5 if alternate else 0.0), 1.0)
	var planted := phase < STANCE_FRACTION
	var advance: float
	var lift := 0.0
	if planted:
		advance = STRIDE * 0.5 - phase * CYCLE_DISTANCE
	else:
		var swing := (phase - STANCE_FRACTION) / (1.0 - STANCE_FRACTION)
		advance = lerpf(-STRIDE * 0.5, STRIDE * 0.5, smoothstep(0.0, 1.0, swing))
		lift = sin(swing * PI) * FOOT_LIFT
	return {"offset": direction * advance * strength, "lift": lift * strength, "planted": planted, "phase": phase}

static func sample(distance: float, direction: Vector2, strength: float) -> Dictionary:
	return {"left": foot(distance, direction, strength), "right": foot(distance, direction, strength, true)}
