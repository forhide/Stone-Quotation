class_name PerfectExaminer
extends CandleSlime

# The Perfect Grimoire's tidy wizard projection predicts controlled spells.
# Accidents open its barrier; each completed attack also leaves a guaranteed
# opening, so ordinary random outcomes can never soft-lock the encounter.
const EXAMINER_ART: Texture2D = preload("res://art/enemies/perfect_examiner.svg")
const ACCIDENT_WINDOW := 4.0
const RECOVERY_WINDOW := 1.6
const WARNING_TIME := 0.85
const BEAM_LENGTH := 310.0
const BEAM_HALF_WIDTH := 27.0
var vulnerability_time := 0.0
var counter_flash := 0.0
var blocked_spells := 0
var window_source := ""
var barrier_active: bool:
	get: return vulnerability_time<=0.0 and health!=null and health.current>0

func setup(settings: Dictionary, player: WizardCat, room_bounds: Rect2) -> void:
	super.setup(settings,player,room_bounds)
	role="examiner"
	set_meta("archetype","perfect_wizard")
	cooldown=1.25
	phase="approach"
	phase_time=0.0

func _ready() -> void:
	_add_attack_telegraph()
	texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	body_root=Node2D.new()
	add_child(body_root)
	body_sprite=Sprite2D.new()
	body_sprite.texture=EXAMINER_ART
	body_sprite.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR
	body_sprite.position=Vector2(0,-66)
	body_sprite.scale=Vector2.ONE*(140.0/512.0)
	body_root.add_child(body_sprite)
	health_track=_health_line(Color("c3b4a4"))
	health_fill=_health_line(Color("9b81b7"))
	for line in [health_track,health_fill]:
		line.position=Vector2(0,-151)
		line.points=PackedVector2Array([Vector2(-48,0),Vector2(48,0)])
		line.width=4
	_update_health()

func _update_health(_current: int=0, _maximum: int=0) -> void:
	if health_track==null or health==null: return
	health_track.visible=health.current>0
	health_fill.visible=health.current>0
	health_fill.points=PackedVector2Array([Vector2(-48,0),Vector2(-48+96*float(health.current)/health.maximum,0)])

func take_spell_damage(amount: int, direction: Vector2, outcome: String) -> void:
	if amount<=0 or health==null or health.current<=0: return
	if outcome in ["miscast","overreaction"]:
		_open_window(ACCIDENT_WINDOW,outcome)
	elif barrier_active:
		blocked_spells+=1
		counter_flash=0.7
		queue_redraw()
		return
	_apply_damage(amount,direction)

func take_damage(amount: int, direction: Vector2) -> void:
	# The room uses this path for belly rolls, falling shelves and floor fires.
	# Controlled spell hits must use take_spell_damage so they can be predicted.
	if amount<=0 or health==null or health.current<=0: return
	_open_window(ACCIDENT_WINDOW,"accident")
	_apply_damage(amount,direction)

func _open_window(duration: float, reason: String) -> void:
	vulnerability_time=maxf(vulnerability_time,duration)
	window_source=reason
	counter_flash=0.0
	if phase in ["windup","attack"]:
		phase="recover"
		phase_time=maxf(phase_time,1.0)
	queue_redraw()

func _apply_damage(amount: int, direction: Vector2) -> void:
	if health.damage(amount):
		hit_flash=0.18
		knockback=direction.normalized()*75.0
		if phase in ["windup","attack"]:
			phase="recover"
			phase_time=0.8
	queue_redraw()

func _physics_process(delta: float) -> void:
	if not active or not is_instance_valid(target) or not target.active or health==null or health.current<=0: return
	time+=delta
	counter_flash=maxf(0.0,counter_flash-delta)
	hit_flash=maxf(0.0,hit_flash-delta)
	vulnerability_time=maxf(0.0,vulnerability_time-delta)
	phase_time=maxf(0.0,phase_time-delta)
	cooldown=maxf(0.0,cooldown-delta)
	match phase:
		"approach":
			var to_player := target.position-position
			if to_player.length()>BEAM_LENGTH-35:
				position+=to_player.normalized()*float(config.get("speed",60.0))*0.55*delta
			elif cooldown<=0:
				attack_direction=to_player.normalized() if to_player.length_squared()>0.01 else Vector2.LEFT
				phase="windup"
				phase_time=WARNING_TIME
				attack_hit=false
		"windup":
			if phase_time<=0:
				phase="attack"
				phase_time=0.28
		"attack":
			if not attack_hit and _beam_contains(target.position):
				target.take_damage(int(config.get("contact_damage",14)),position)
				attack_hit=true
			if phase_time<=0:
				phase="recover"
				phase_time=RECOVERY_WINDOW
				_open_window(RECOVERY_WINDOW,"recovery")
		"recover":
			if phase_time<=0:
				phase="approach"
				cooldown=0.9
	position+=knockback*delta
	knockback=knockback.move_toward(Vector2.ZERO,delta*400)
	position=position.clamp(bounds.position+Vector2.ONE*32,bounds.end-Vector2.ONE*32)
	if body_root!=null:
		body_root.position=Vector2(0,sin(time*2.7)*3.0)
		body_root.rotation=sin(time*1.6)*0.025
		body_sprite.self_modulate=Color(1.16,1.08,1.02) if hit_flash>0 else Color.WHITE
	queue_redraw()

func _beam_contains(point: Vector2) -> bool:
	var offset := point-position
	var along := offset.dot(attack_direction)
	return along>=0 and along<=BEAM_LENGTH and absf(offset.cross(attack_direction))<=beam_collision_half_width()

func beam_collision_half_width() -> float:
	return BEAM_HALF_WIDTH+float(target.config.get("radius",23.0))*0.35

func get_attack_preview() -> Dictionary:
	if phase not in ["windup","attack"]: return {}
	return {"path":PackedVector2Array([Vector2.ZERO,attack_direction*BEAM_LENGTH]),"radius":beam_collision_half_width(),"progress":1.0-clampf(phase_time/WARNING_TIME,0,1) if phase=="windup" else 1.0,"striking":phase=="attack","beam":true}

func _caption(text: String, at: Vector2, size: int, color: Color) -> void:
	text=GameLocale.text(text)
	var font := ThemeDB.fallback_font
	at.x-=font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x*0.5
	draw_string_outline(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,4,Color("fff7e6"))
	draw_string(font,at,text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _draw() -> void:
	# This boss adds no particle emitter, lighting pass or per-frame texture bake.
	draw_set_transform(Vector2(0,6),0,Vector2(1,0.27))
	draw_circle(Vector2.ZERO,43,Color(0.38,0.31,0.29,0.16))
	draw_set_transform(Vector2.ZERO)
	_refresh_attack_telegraph()
	if barrier_active:
		draw_arc(Vector2(0,-64),73,0,TAU,40,Color(0.48,0.66,0.66,0.32),2,true)
		_caption("PREDICTED" if counter_flash>0 else "THE PERFECT WIZARD",Vector2(0,-159),12,Color("796780"))
		_caption("Try an accident",Vector2(0,28),11,Color("796780"))
	else:
		_caption("ERROR  /  BARRIER OPEN",Vector2(0,-159),12,Color("b16d77"))
		_caption("%.1fs" % vulnerability_time,Vector2(0,28),11,Color("a66a73"))
