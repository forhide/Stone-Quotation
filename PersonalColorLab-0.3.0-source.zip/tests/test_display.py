"""DPI initialization must precede Tk and respect native platform sizing."""

from types import SimpleNamespace

import pytest

from personal_color_lab.ui import display


class NativeFunction:
    def __init__(self, name, result, calls):
        self.name, self.result, self.calls = name, result, calls

    def __call__(self, *args):
        self.calls.append((self.name, args))
        return self.result


@pytest.mark.parametrize(
    "modern, modern_error, older, legacy, expected, order",
    [
        (True, 0, None, None, "per_monitor_v2", ["modern"]),
        (False, 5, 0, True, "already_configured", ["modern"]),
        (None, 0, 0, True, "per_monitor", ["older"]),
        (False, 87, -2147024891, True, "already_configured", ["modern", "older"]),
        (False, 87, -2147024809, True, "system", ["modern", "older", "legacy"]),
        (None, 0, None, False, "unavailable", ["legacy"]),
    ],
)
def test_windows_awareness_fallbacks_stop_when_supported_or_already_configured(
    monkeypatch, modern, modern_error, older, legacy, expected, order
):
    calls = []
    user32, shcore = SimpleNamespace(), SimpleNamespace()
    for library, attr, name, result in (
        (user32, "SetProcessDpiAwarenessContext", "modern", modern),
        (shcore, "SetProcessDpiAwareness", "older", older),
        (user32, "SetProcessDPIAware", "legacy", legacy),
    ):
        if result is not None:
            setattr(library, attr, NativeFunction(name, result, calls))
    monkeypatch.setattr(display.sys, "platform", "win32")
    monkeypatch.setattr(display, "_load_windows_dll", lambda name: {"user32": user32, "shcore": shcore}[name])
    monkeypatch.setattr(display, "_last_error", lambda: modern_error)
    assert display.initialize_display() == expected
    assert [name for name, _ in calls] == order
    if "older" in order:
        assert next(args for name, args in calls if name == "older") == (2,)


def test_mac_preserves_native_retina_point_sizing(monkeypatch):
    monkeypatch.setattr(display.sys, "platform", "darwin")

    def unexpected(*args):
        pytest.fail("macOS must not call Windows APIs or force Tcl scaling")

    monkeypatch.setattr(display, "_load_windows_dll", unexpected)
    widget = SimpleNamespace(tk=SimpleNamespace(call=unexpected), winfo_fpixels=unexpected)
    assert display.initialize_display() == "native"
    display.configure_window_scale(widget)
    assert display.ui_scale(widget) == 1.0


def test_windows_window_density_controls_native_point_font_rendering(monkeypatch):
    calls = []
    monkeypatch.setattr(display.sys, "platform", "win32")
    monkeypatch.setattr(display, "_window_dpi", lambda widget: 192)
    widget = SimpleNamespace(tk=SimpleNamespace(call=lambda *args: calls.append(args)))
    display.configure_window_scale(widget)
    assert calls == [("tk", "scaling", 192 / 72)]
    calls.clear()
    monkeypatch.setattr(display, "_window_dpi", lambda widget: 0)
    display.configure_window_scale(widget)
    assert not calls


def test_app_initializes_process_awareness_before_constructing_tk(monkeypatch):
    from personal_color_lab.ui import app

    calls = []

    class StopConstruction(Exception):
        pass

    def first_tk_window(self):
        calls.append("Tk")
        raise StopConstruction

    monkeypatch.setattr(app, "initialize_display", lambda: calls.append("DPI"))
    monkeypatch.setattr(app.tk.Tk, "__init__", first_tk_window)
    with pytest.raises(StopConstruction):
        app.App()
    assert calls == ["DPI", "Tk"]
