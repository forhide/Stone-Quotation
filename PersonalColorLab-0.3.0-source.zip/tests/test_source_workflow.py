"""Folder discovery and real three-source analysis/persistence integration."""
import hashlib
from pathlib import Path
import shutil
import socket
import threading

import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.raw_decode import decode_raw
from personal_color_lab.core.source_workflow import analyze_inputs, discover_inputs
from personal_color_lab.core.synthetic_raw import write_test_dng


def _xmp(path, exposure='0.65'):
    path.write_text(
        '<x:xmpmeta xmlns:x="adobe:ns:meta/" xmlns:r="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
        'xmlns:c="http://ns.adobe.com/camera-raw-settings/1.0/">'
        f'<r:RDF><r:Description c:Exposure2012="{exposure}" c:Contrast2012="-12" '
        'c:Temperature="6100" c:WhiteBalance="Custom" c:ProcessVersion="11.0"/>'
        '</r:RDF></x:xmpmeta>', encoding='utf-8')
    return path


def _jpeg(path, color=(160, 92, 50)):
    Image.new('RGB', (96, 64), color).save(path, quality=95)
    return path


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_reference_folder_analyzes_every_jpeg_without_requiring_pairs(tmp_path, monkeypatch):
    first = _jpeg(tmp_path / 'warm.jpg')
    second = _jpeg(tmp_path / 'blue.JPG', (45, 85, 170))
    (tmp_path / 'ignore.txt').write_text('not a photo')
    before = {p: _hash(p) for p in (first, second)}
    discovered = discover_inputs(tmp_path, 'reference_jpg')
    assert discovered['counts']['ready'] == 2
    assert {Path(r['original_path']).name for r in discovered['items']} == {'warm.jpg', 'blue.JPG'}
    assert all(r['edited_path'] is None for r in discovered['items'])
    monkeypatch.setattr(socket, 'socket', lambda *a, **kw: (_ for _ in ()).throw(AssertionError('network used')))
    progress = []
    batch = analyze_inputs(discovered['items'], 'reference_jpg', progress=lambda *args: progress.append(args))
    assert batch['status'] == 'ok' and batch['counts']['successful'] == 2
    assert batch['summary']['sample_count'] == 2 and batch['summary']['palette']
    assert 'exposure_ev_median' not in batch['summary']
    assert batch['summary']['provenance']['inferred_edit_transform'] is False
    assert progress[-1][:2] == (2, 2)
    with LibraryDB(tmp_path / 'library.db') as db:
        profile_id = db.save_source_profile('완성 사진 색감', batch)
    with LibraryDB(tmp_path / 'library.db') as db:
        assert db.get_source_profile(profile_id)['payload'] == batch
    assert {p: _hash(p) for p in (first, second)} == before


def test_raw_jpeg_folder_decodes_real_sensor_data_and_measures_edit(tmp_path):
    raw = write_test_dng(tmp_path / 'scene.dng')
    pixels, _, _ = decode_raw(raw)
    edited = tmp_path / 'scene_edit.JPG'
    Image.fromarray(np.clip(pixels.astype(float) * 1.08 + [7, 2, -2], 0, 255).astype('uint8')).save(edited, quality=98)
    before = (_hash(raw), _hash(edited))
    discovery = discover_inputs(tmp_path, 'raw_jpg')
    assert discovery['counts']['ready'] == 1
    batch = analyze_inputs(discovery['items'], 'raw_jpg')
    assert batch['status'] == 'ok'
    result = batch['results'][0]['payload']
    assert result['source_type'] == 'inferred_raw_pair'
    assert result['provenance']['raw_baseline']['decoder'] == 'rawpy_libraw'
    assert result['provenance']['exact_xmp_parameters'] is False
    assert batch['summary']['brightness_delta_median'] > 0.02
    with LibraryDB(tmp_path / 'library.db') as db:
        row = db.save_source_profile('RAW comparison', batch)
        assert db.get_source_profile(row)['payload'] == batch
    assert (_hash(raw), _hash(edited)) == before


def test_raw_xmp_folder_extracts_recorded_values_not_approximate_pixels(tmp_path):
    raw = write_test_dng(tmp_path / 'photo.dng')
    xmp = _xmp(tmp_path / 'photo.dng.xmp')
    before = (_hash(raw), _hash(xmp))
    discovered = discover_inputs(tmp_path, 'raw_xmp')
    assert discovered['counts']['ready'] == 1
    batch = analyze_inputs(discovered['items'], 'raw_xmp')
    assert batch['status'] == 'ok'
    assert batch['summary']['parameters']['Exposure2012'] == {'median': 0.65, 'min': 0.65, 'max': 0.65, 'count': 1}
    assert batch['summary']['parameters']['WhiteBalance']['values'] == ['Custom']
    assert batch['results'][0]['payload']['confidence_scope'] == 'recorded_xmp_parameters'
    with LibraryDB(tmp_path / 'library.db') as db:
        row = db.save_source_profile('Recorded XMP', batch)
        assert db.get_source_profile(row)['payload'] == batch
    assert (_hash(raw), _hash(xmp)) == before


def test_same_basename_in_multiple_folders_prefers_each_local_pair(tmp_path):
    for folder in ('one', 'two'):
        root = tmp_path / folder
        root.mkdir()
        (root / 'DSC001.NEF').write_bytes(b'raw placeholder')
        _jpeg(root / 'DSC001_final.JPG')
    result = discover_inputs(tmp_path, 'raw_jpg')
    assert result['counts']['ready'] == 2
    assert all(Path(r['original_path']).parent == Path(r['edited_path']).parent for r in result['items'])
    assert discover_inputs(tmp_path, 'raw_jpg', recursive=False)['items'] == []


def test_ambiguous_and_missing_matches_remain_explicit_until_user_resolves(tmp_path):
    raw = tmp_path / 'scene.NEF'
    raw.write_bytes(b'raw placeholder')
    one, two = _jpeg(tmp_path / 'scene_edit.jpg'), _jpeg(tmp_path / 'scene_final.jpg')
    orphan = _jpeg(tmp_path / 'unrelated.jpg')
    result = discover_inputs(tmp_path, 'raw_jpg')
    assert result['counts']['ready'] == 0
    assert result['counts']['ambiguous'] == result['counts']['unmatched'] == 1
    ambiguous = next(r for r in result['items'] if r['status'] == 'ambiguous')
    assert set(ambiguous['candidates']) == {str(one), str(two)}
    assert ambiguous['edited_path'] is None
    unmatched = next(r for r in result['items'] if r['status'] == 'unmatched')
    assert unmatched['reason'] == 'missing_raw' and unmatched['original_path'] == str(orphan)
    batch = analyze_inputs(result['items'], 'raw_jpg')
    assert batch['status'] == 'failed' and batch['counts']['skipped'] == 2


def test_two_raws_cannot_automatically_claim_one_edited_image(tmp_path):
    for ext in ('NEF', 'DNG'):
        (tmp_path / ('same.' + ext)).write_bytes(b'raw placeholder')
    _jpeg(tmp_path / 'same.jpg')
    discovery = discover_inputs(tmp_path, 'raw_jpg')
    assert discovery['counts']['ambiguous'] == 2 and not discovery['counts']['ready']


def test_manual_different_filename_pair_is_validated_and_analyzed(tmp_path):
    raw = tmp_path / 'raw.NEF'
    raw.write_bytes(b'raw contents not rendered for XMP settings')
    xmp = _xmp(tmp_path / 'different_name.xmp')
    item = next(r for r in discover_inputs(tmp_path, 'raw_xmp')['items'] if r['original_path'] == str(raw))
    item.update(edited_path=str(xmp), status='ready', reason='manual_selection')
    batch = analyze_inputs([item], 'raw_xmp')
    assert batch['status'] == 'ok'
    assert batch['results'][0]['item']['reason'] == 'manual_selection'
    item['edited_path'] = str(_jpeg(tmp_path / 'wrong.jpg'))
    assert analyze_inputs([item], 'raw_xmp')['results'][0]['status'] == 'error'


def test_duplicate_reference_bytes_do_not_overweight_a_style(tmp_path):
    photo = _jpeg(tmp_path / 'one.jpg')
    shutil.copyfile(photo, tmp_path / 'copy.jpg')
    _jpeg(tmp_path / 'other.jpg', (60, 90, 190))
    batch = analyze_inputs(discover_inputs(tmp_path, 'reference_jpg')['items'], 'reference_jpg')
    assert batch['counts']['successful'] == 2 and batch['counts']['duplicates'] == 1
    summary = batch['summary']
    assert summary['input_count'] == summary['sample_count'] + summary['excluded_count'] + summary['duplicate_count'] == 3
    assert 'reference_duplicates_ignored' in summary['warnings']


def test_bad_reference_does_not_discard_successful_files(tmp_path):
    _jpeg(tmp_path / 'good.jpg')
    (tmp_path / 'bad.jpg').write_bytes(b'not an image')
    batch = analyze_inputs(discover_inputs(tmp_path, 'reference_jpg')['items'], 'reference_jpg')
    assert batch['status'] == 'partial'
    assert batch['counts']['successful'] == batch['counts']['failed'] == 1
    assert batch['summary']['sample_count'] == 1
    with LibraryDB(tmp_path / 'partial.db') as db:
        assert db.save_source_profile('Partial batch', batch)


def test_cancel_keeps_completed_results_and_counts_unprocessed_files(tmp_path):
    for i in range(3):
        _jpeg(tmp_path / f'{i}.jpg', (70 + i * 30, 90, 150))
    stop = threading.Event()
    batch = analyze_inputs(discover_inputs(tmp_path, 'reference_jpg')['items'], 'reference_jpg',
                           progress=lambda *args: stop.set(), cancel_event=stop)
    assert batch['status'] == 'cancelled'
    assert batch['counts']['successful'] == batch['counts']['processed'] == 1
    assert batch['counts']['cancelled'] == 2 and batch['counts']['total'] == 3
    assert batch['summary']['sample_count'] == 1
    with LibraryDB(tmp_path / 'cancelled.db') as db:
        assert db.save_source_profile('Completed before cancel', batch)


@pytest.mark.parametrize('mode', ['raw_jpg', 'raw_xmp', 'reference_jpg'])
def test_empty_folder_produces_no_fake_measurement(tmp_path, mode):
    discovered = discover_inputs(tmp_path, mode)
    assert discovered['items'] == []
    batch = analyze_inputs([], mode)
    assert batch['status'] == 'failed' and batch['summary']['sample_count'] == 0


def test_unknown_mode_or_missing_folder_is_rejected(tmp_path):
    with pytest.raises(ValueError):
        discover_inputs(tmp_path, 'pretend_raw')
    with pytest.raises(FileNotFoundError):
        discover_inputs(tmp_path / 'missing', 'raw_jpg')
