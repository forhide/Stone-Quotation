"""Check packaging integrity with independent libarchive readers when available."""
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import build_installers
import download_wheels
import flat_pkg


def archive_reader():
    binary = os.environ.get('PERSONAL_COLOR_LAB_BSDTAR') or shutil.which('bsdtar')
    if not binary:
        pytest.skip('Independent archive validation requires bsdtar (libarchive-tools)')
    return binary


def test_xar_reader_checks_nested_package_members_and_content(tmp_path):
    reader = archive_reader()
    files = {}
    for name, data in {'Distribution': b'<distribution/>', 'application.pkg/Bom': b'BOMStore', 'application.pkg/Payload': b'payload' * 31}.items():
        path = tmp_path / name
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(data)
        files[name] = path
    artifact = tmp_path / 'test.pkg'
    flat_pkg.write_xar(files, artifact)
    assert set(subprocess.check_output([reader, '-tf', str(artifact)], text=True).splitlines()) == set(files)
    for name, path in files.items():
        assert subprocess.check_output([reader, '-xOf', str(artifact), name]) == path.read_bytes()


def test_cpio_payload_roundtrip_preserves_app_permissions_and_symlinks(tmp_path):
    reader = archive_reader()
    payload = tmp_path / 'app'
    payload.mkdir()
    script = payload / 'Launch App'
    script.write_text('#!/bin/sh\nexit 0\n')
    script.chmod(0o755)
    resource = payload / '한국어.json'
    resource.write_text('{"language":"ko"}', encoding='utf-8')
    resource.chmod(0o644)
    (payload / 'launcher-link').symlink_to('Launch App')
    output = tmp_path / 'Payload'
    count, size = flat_pkg.write_payload(payload, output)
    assert count == 4 and size == 1
    unpacked = tmp_path / 'unpacked'
    unpacked.mkdir()
    subprocess.run([reader, '-xpf', str(output), '-C', str(unpacked)], check=True)
    assert (unpacked / 'Launch App').read_bytes() == script.read_bytes()
    assert (unpacked / 'Launch App').stat().st_mode & 0o777 == 0o755
    assert (unpacked / '한국어.json').read_bytes() == resource.read_bytes()
    assert (unpacked / '한국어.json').stat().st_mode & 0o777 == 0o644
    assert os.readlink(unpacked / 'launcher-link') == 'Launch App'


def test_payload_rejects_links_outside_app(tmp_path):
    payload = tmp_path / 'app'
    payload.mkdir()
    (payload / 'escape').symlink_to('../private-photo')
    with pytest.raises(ValueError, match='escapes root'):
        flat_pkg.write_payload(payload, tmp_path / 'Payload')


@pytest.mark.skipif(shutil.which('cksum') is None, reason='Cross-host BOM lists require POSIX cksum; native macOS uses pkgbuild')
def test_bom_explicit_list_includes_hidden_native_libraries(tmp_path):
    payload = tmp_path / 'app'
    hidden = payload / '.dylibs'
    hidden.mkdir(parents=True)
    library = hidden / 'native.dylib'
    library.write_bytes(b'native library\0')
    library.chmod(0o755)
    output = tmp_path / 'bom-files.txt'
    flat_pkg.write_bom_list(payload, output)
    entries = {line.split('\t')[0]: line.split('\t')[1:] for line in output.read_text().splitlines()}
    assert set(entries) == {'.', './.dylibs', './.dylibs/native.dylib'}
    mode, owner, timestamp, size, checksum = entries['./.dylibs/native.dylib']
    assert int(mode, 8) & 0o777 == 0o755 and owner == '0/80'
    assert int(size) == len(b'native library\0')
    assert checksum == subprocess.check_output(['cksum'], input=b'native library\0').split()[0].decode()


@pytest.mark.parametrize('name', ['../../photo.jpg', '/private/photo.jpg', 'library.data/scripts/postinstall.sh'])
def test_wheel_installer_rejects_unexpected_paths(tmp_path, name):
    wheel = tmp_path / 'invalid.whl'
    with zipfile.ZipFile(wheel, 'w') as archive:
        archive.writestr(name, b'should not be installed')
    with pytest.raises(ValueError):
        build_installers.install_wheel(wheel, tmp_path / 'site-packages')
    assert not (tmp_path / 'photo.jpg').exists()


def test_wheel_install_retains_native_license_and_binary_bytes(tmp_path):
    wheel = tmp_path / 'example.whl'
    entries = {'module/native.so': b'\0NATIVE\xff', 'example.dist-info/licenses/LICENSE': b'License notice', 'example.data/platlib/module/extras.py': b'VALUE = 42'}
    with zipfile.ZipFile(wheel, 'w') as archive:
        for name, data in entries.items():
            archive.writestr(name, data)
    destination = tmp_path / 'site-packages'
    build_installers.install_wheel(wheel, destination)
    assert (destination / 'module/native.so').read_bytes() == entries['module/native.so']
    assert (destination / 'example.dist-info/licenses/LICENSE').read_bytes() == b'License notice'
    assert (destination / 'module/extras.py').read_bytes() == b'VALUE = 42'


@pytest.mark.parametrize('target,tag,expected', [
    ('windows-x64', 'cp313-cp313-win_amd64', True),
    ('windows-x64', 'cp313-cp313-win_arm64', False),
    ('windows-x64', 'cp313-cp313t-win_amd64', False),
    ('macos-x64', 'cp37-abi3-macosx_14_0_x86_64', True),
    ('macos-arm64', 'cp313-cp313-macosx_14_0_arm64', False),
    ('macos-arm64', 'cp37-abi3-macosx_13_0_arm64', True),
])
def test_binary_wheel_target_compatibility(target, tag, expected):
    assert download_wheels.compatible_tag(tag, target) is expected
