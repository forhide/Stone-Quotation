"""Exercise real V0.1 libraries, atomic upgrades, and analysis persistence."""

import copy
import json
import sqlite3
from pathlib import Path

import pytest

from personal_color_lab.core.database import (
    AnalysisDataError,
    AnalysisValidationError,
    LibraryDB,
)
from personal_color_lab.core.models import PairCandidate, PhotoRecord
from personal_color_lab.core.schema_migrations import SchemaMigrationError


# A frozen V0.1 fixture, independent of the production migration definitions.
V01_SCHEMA = '''
CREATE TABLE photos (
    id INTEGER PRIMARY KEY, path TEXT UNIQUE NOT NULL, ext TEXT NOT NULL,
    kind TEXT NOT NULL, size_bytes INTEGER NOT NULL, width INTEGER,
    height INTEGER, capture_time TEXT, camera TEXT, lens TEXT,
    fingerprint TEXT, imported_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE pairs (
    id INTEGER PRIMARY KEY, original_path TEXT NOT NULL,
    edited_path TEXT NOT NULL, pair_type TEXT NOT NULL,
    confidence REAL NOT NULL, reasons TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(original_path, edited_path, pair_type)
);
CREATE TABLE scene_tags (
    photo_path TEXT PRIMARY KEY, day REAL, night REAL, indoor REAL, outdoor REAL,
    portrait REAL, landscape REAL, food REAL, street REAL,
    architecture REAL, still_life REAL,
    FOREIGN KEY(photo_path) REFERENCES photos(path)
);
CREATE TABLE edit_analysis (
    id INTEGER PRIMARY KEY, original_path TEXT, edited_path TEXT,
    source_type TEXT, confidence REAL, payload_json TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE styles (
    id INTEGER PRIMARY KEY, style_name TEXT UNIQUE NOT NULL,
    source_type TEXT NOT NULL, global_dna_json TEXT, tone_dna_json TEXT,
    color_dna_json TEXT, composition_dna_json TEXT,
    dataset_size INTEGER DEFAULT 0, coverage_json TEXT, confidence REAL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
'''


def analysis(original=Path('사진_original.jpg'), edited=Path('사진_edit.jpg')):
    return {
        'schema_version': 1,
        'algorithm_version': '0.2.0',
        'status': 'ok',
        'source_type': 'inferred_jpg_pair',
        'original_path': str(original),
        'edited_path': str(edited),
        'provenance': {'inferred': True, 'exact_lightroom_settings': False},
        'alignment': {'method': 'identity', 'overlap': 1.0},
        'tone': {'curve': [[0, 0], [1, 1]]},
        'color': {'delta': {'a': 0.1, 'b': -0.2}},
        'lightroom_estimates': {'exposure': {'value': 0.1, 'confidence': 0.5}},
        'warnings': ['Estimates are approximate.'],
        'confidence': 0.8,
    }


@pytest.fixture
def legacy_library(tmp_path):
    path = tmp_path / 'legacy.sqlite'
    with sqlite3.connect(path) as conn:
        conn.executescript(V01_SCHEMA)
        conn.execute('''
            INSERT INTO photos(id,path,ext,kind,size_bytes,width,height,capture_time,
                camera,lens,fingerprint,imported_at)
            VALUES(11,'original.jpg','.jpg','jpg',200,640,480,'2024:01:02 03:04:05',
                'Camera','Lens','abcd','2024-01-01 00:00:00')
        ''')
        conn.execute('''
            INSERT INTO pairs(id,original_path,edited_path,pair_type,confidence,reasons)
            VALUES(21,'original.jpg','edited.jpg','JPG+JPG',0.9,'filename relationship')
        ''')
        conn.execute("INSERT INTO scene_tags(photo_path,day,outdoor) VALUES('original.jpg',0.8,0.7)")
        conn.execute('''
            INSERT INTO styles(id,style_name,source_type,global_dna_json,dataset_size,confidence)
            VALUES(31,'My Style','personal','{"tone":"warm"}',9,0.6)
        ''')
        conn.executemany('''
            INSERT INTO edit_analysis(id,original_path,edited_path,source_type,confidence,payload_json)
            VALUES(?,?,?,?,?,?)
        ''', [
            (41, 'original.jpg', 'edited.jpg', None, None, None),
            (42, 'original.jpg', 'edited.jpg', 'legacy', 0.5, '{"legacy":true}'),
            (43, None, None, None, None, 'unstructured legacy text'),
        ])
        snapshots = {}
        for table in ('photos', 'pairs', 'scene_tags', 'styles', 'edit_analysis'):
            columns = [row[1] for row in conn.execute(f'PRAGMA table_info({table})')]
            snapshots[table] = (columns, conn.execute(f'SELECT * FROM {table}').fetchall())
    return path, snapshots


def test_legacy_migration_preserves_every_original_column_and_sparse_row(legacy_library):
    path, snapshots = legacy_library
    with LibraryDB(path) as db:
        assert db.conn.execute('PRAGMA user_version').fetchone()[0] == 2
        assert db.conn.execute('SELECT count(*) FROM source_profiles').fetchone()[0] == 0
        for table, (columns, rows) in snapshots.items():
            assert db.conn.execute(f"SELECT {','.join(columns)} FROM {table}").fetchall() == rows
        assert db.conn.execute('''
            SELECT schema_version,algorithm_version,status,updated_at FROM edit_analysis
        ''').fetchall() == [(None, None, None, None)] * 3
        assert db.get_analysis(Path('original.jpg'), Path('edited.jpg')) is None
        payload = analysis(Path('original.jpg'), Path('edited.jpg'))
        result_id = db.save_analysis(Path('original.jpg'), Path('edited.jpg'), payload)
        assert result_id == 44
    # Opening an already upgraded library must be harmless and keep analyses.
    with LibraryDB(path) as db:
        assert db.get_analysis(Path('original.jpg'), Path('edited.jpg')) == payload
        assert db.conn.execute('SELECT count(*) FROM edit_analysis').fetchone()[0] == 4
        old_columns, old_rows = snapshots['edit_analysis']
        assert db.conn.execute(
            f"SELECT {','.join(old_columns)} FROM edit_analysis WHERE id <= 43"
        ).fetchall() == old_rows


def test_save_is_idempotent_pair_specific_and_updates_without_modifying_input(tmp_path):
    payload = analysis()
    original, edited = Path(payload['original_path']), Path(payload['edited_path'])
    untouched = copy.deepcopy(payload)
    with LibraryDB(tmp_path / 'new' / 'library.sqlite') as db:
        first = db.save_analysis(original, edited, payload)
        assert payload == untouched
        payload['confidence'] = 0.9
        payload['tone']['curve'][1][1] = 0.95
        assert db.save_analysis(original, edited, payload) == first
        assert db.get_analysis(original, edited) == payload
        assert db.get_analysis(edited, original) is None
        assert db.conn.execute('SELECT count(*) FROM edit_analysis').fetchone()[0] == 1
        other_edited = Path('second_edit.jpg')
        other = analysis(original, other_edited)
        assert db.save_analysis(original, other_edited, other) != first
        assert db.get_analysis(original, edited) == payload
        assert db.get_analysis(original, other_edited) == other


def test_schema_one_upgrade_is_additive_and_keeps_all_analysis_and_library_rows(legacy_library):
    path, _ = legacy_library
    payload = analysis()
    # Freeze schema 1 independently of the production migration under test.
    with sqlite3.connect(path) as conn:
        for definition in (
            'schema_version INTEGER', 'algorithm_version TEXT',
            'status TEXT', 'updated_at TEXT',
        ):
            conn.execute(f'ALTER TABLE edit_analysis ADD COLUMN {definition}')
        conn.execute('''
            CREATE UNIQUE INDEX edit_analysis_pair_version
            ON edit_analysis(original_path,edited_path,schema_version,algorithm_version)
            WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
        ''')
        conn.execute('''
            CREATE INDEX edit_analysis_pair_latest
            ON edit_analysis(original_path,edited_path,updated_at DESC,id DESC)
            WHERE schema_version IS NOT NULL AND algorithm_version IS NOT NULL
        ''')
        conn.execute('''
            INSERT INTO edit_analysis(id,original_path,edited_path,source_type,confidence,
                payload_json,schema_version,algorithm_version,status,updated_at)
            VALUES(44,?,?,?,?,?,1,'0.2.0','ok','2026-10-07T10:20:30+00:00')
        ''', (payload['original_path'], payload['edited_path'], payload['source_type'],
              payload['confidence'], json.dumps(payload, ensure_ascii=False)))
        conn.execute('PRAGMA user_version=1')
        tables = ('photos', 'pairs', 'scene_tags', 'styles', 'edit_analysis')
        snapshots = {table: conn.execute(f'SELECT * FROM {table}').fetchall() for table in tables}
        schema = conn.execute("SELECT type,name,sql FROM sqlite_master ORDER BY name").fetchall()
    with LibraryDB(path) as db:
        assert db.conn.execute('PRAGMA user_version').fetchone()[0] == 2
        for table, rows in snapshots.items():
            assert db.conn.execute(f'SELECT * FROM {table}').fetchall() == rows
        preserved_schema = db.conn.execute('''
            SELECT type,name,sql FROM sqlite_master
            WHERE name NOT IN ('source_profiles','source_profiles_latest') ORDER BY name
        ''').fetchall()
        assert preserved_schema == schema
        assert db.get_analysis(Path(payload['original_path']), Path(payload['edited_path'])) == payload
        assert db.list_source_profiles() == []


def test_algorithm_versions_coexist_and_most_recent_save_is_returned(tmp_path):
    payload = analysis()
    original, edited = Path(payload['original_path']), Path(payload['edited_path'])
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        old_id = db.save_analysis(original, edited, payload)
        new = {**payload, 'algorithm_version': '0.2.1'}
        assert db.save_analysis(original, edited, new) != old_id
        assert db.get_analysis(original, edited) == new
        # Re-running an earlier installed engine makes that new observation current.
        assert db.save_analysis(original, edited, payload) == old_id
        assert db.get_analysis(original, edited) == payload
        assert db.conn.execute('SELECT count(*) FROM edit_analysis').fetchone()[0] == 2


def test_alignment_failure_payload_is_persisted_with_its_provenance(tmp_path):
    payload = analysis()
    payload.update(status='alignment_failed', confidence=0.0, tone={}, color={}, lightroom_estimates={})
    payload['warnings'] = ['Insufficient alignment overlap.']
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        db.save_analysis(Path(payload['original_path']), Path(payload['edited_path']), payload)
        assert db.get_analysis(Path(payload['original_path']), Path(payload['edited_path'])) == payload


def test_uncertain_color_space_preserves_geometry_without_color_estimates(tmp_path):
    payload = analysis()
    payload.update(
        status='color_space_uncertain', confidence=0.0, tone={}, color={},
        lightroom_estimates={'approximate': True, 'available': False, 'confidence': 0.0},
    )
    payload['alignment'].update(success=True, confidence=0.95)
    payload['warnings'] = ['color_space_uncertain']
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        db.save_analysis(Path(payload['original_path']), Path(payload['edited_path']), payload)
        assert db.get_analysis(Path(payload['original_path']), Path(payload['edited_path'])) == payload


@pytest.mark.parametrize('field,value', [
    ('original_path', 'different.jpg'),
    ('schema_version', True),
    ('schema_version', 0),
    ('schema_version', 2**63),
    ('algorithm_version', ''),
    ('source_type', None),
    ('status', []),
    ('status', 'invented_status'),
    ('alignment', None),
    ('provenance', []),
    ('warnings', [42]),
    ('confidence', True),
    ('confidence', 1.1),
    ('confidence', -0.1),
    ('confidence', float('nan')),
    ('tone', {'delta': float('inf')}),
    ('tone', {'delta': float('-inf')}),
    ('color', {'channels': (1, 2)}),
    ('provenance', {'metadata': {'GPSLatitude': [35, 1, 2]}}),
    ('provenance', {'metadata': {'latitude': 35.0}}),
    ('provenance', {'location': {'lat': 35.0, 'lng': 127.0}}),
])
def test_invalid_payloads_are_rejected_before_any_write(tmp_path, field, value):
    payload = analysis()
    original, edited = Path(payload['original_path']), Path(payload['edited_path'])
    payload[field] = value
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError):
            db.save_analysis(original, edited, payload)
        assert db.conn.execute('SELECT count(*) FROM edit_analysis').fetchone()[0] == 0
        assert not db.conn.in_transaction


def test_cyclic_payload_and_same_photo_are_rejected(tmp_path):
    payload = analysis()
    original, edited = Path(payload['original_path']), Path(payload['edited_path'])
    payload['provenance']['cycle'] = payload
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        with pytest.raises(AnalysisValidationError, match='cyclic'):
            db.save_analysis(original, edited, payload)
        same = analysis(original, original)
        with pytest.raises(AnalysisValidationError, match='different'):
            db.save_analysis(original, original, same)


@pytest.mark.parametrize('corruption', ['malformed', 'null', 'array', 'nan', 'header', 'gps'])
def test_corrupt_current_payload_raises_clean_error(tmp_path, corruption):
    payload = analysis()
    original, edited = Path(payload['original_path']), Path(payload['edited_path'])
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        row_id = db.save_analysis(original, edited, payload)
        if corruption == 'malformed':
            encoded = '{broken json'
        elif corruption == 'null':
            encoded = None
        elif corruption == 'array':
            encoded = '[]'
        elif corruption == 'nan':
            payload['confidence'] = float('nan')
            encoded = json.dumps(payload)
        elif corruption == 'header':
            payload['algorithm_version'] = 'unexpected'
            encoded = json.dumps(payload)
        else:
            payload['provenance']['GPSInfo'] = {'latitude': 35.0}
            encoded = json.dumps(payload)
        with db.conn:
            db.conn.execute('UPDATE edit_analysis SET payload_json=? WHERE id=?', (encoded, row_id))
        with pytest.raises(AnalysisDataError, match=f'row {row_id}'):
            db.get_analysis(original, edited)


def test_failed_update_rolls_back_and_connection_can_be_reused(tmp_path):
    payload = analysis()
    original, edited = Path(payload['original_path']), Path(payload['edited_path'])
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        row_id = db.save_analysis(original, edited, payload)
        db.conn.execute('''
            CREATE TRIGGER reject_analysis_update BEFORE UPDATE ON edit_analysis
            BEGIN SELECT RAISE(ABORT, 'simulated storage failure'); END
        ''')
        changed = {**payload, 'confidence': 0.3}
        with pytest.raises(sqlite3.IntegrityError, match='simulated storage failure'):
            db.save_analysis(original, edited, changed)
        assert not db.conn.in_transaction
        assert db.get_analysis(original, edited) == payload
        db.conn.execute('DROP TRIGGER reject_analysis_update')
        assert db.save_analysis(original, edited, changed) == row_id
        assert db.get_analysis(original, edited) == changed


def test_failed_scan_does_not_leave_partially_inserted_photos(tmp_path):
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        existing = PhotoRecord(Path('existing.jpg'), '.jpg', 'jpg', 20)
        db.replace_scan([existing], [])
        fresh = PhotoRecord(Path('fresh.jpg'), '.jpg', 'jpg', 30)
        invalid_pair = PairCandidate(Path('fresh.jpg'), Path('edit.jpg'), 'JPG+JPG', None)
        with pytest.raises(sqlite3.IntegrityError):
            db.replace_scan([fresh], [invalid_pair])
        assert not db.conn.in_transaction
        assert db.conn.execute('SELECT path FROM photos').fetchall() == [('existing.jpg',)]


def test_failed_migration_rolls_back_all_ddl_and_keeps_legacy_row(tmp_path):
    path = tmp_path / 'broken.sqlite'
    with sqlite3.connect(path) as conn:
        conn.execute('CREATE TABLE edit_analysis(id INTEGER PRIMARY KEY, payload_json TEXT)')
        conn.execute("INSERT INTO edit_analysis VALUES(7,'keep this legacy data')")
    with pytest.raises(SchemaMigrationError, match='migration failed'):
        LibraryDB(path)
    with sqlite3.connect(path) as conn:
        assert conn.execute('PRAGMA user_version').fetchone()[0] == 0
        assert [row[1] for row in conn.execute('PRAGMA table_info(edit_analysis)')] == ['id', 'payload_json']
        assert conn.execute('SELECT * FROM edit_analysis').fetchall() == [(7, 'keep this legacy data')]
        assert conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() == [('edit_analysis',)]


def test_newer_database_version_is_refused_before_changes(tmp_path):
    path = tmp_path / 'future.sqlite'
    with sqlite3.connect(path) as conn:
        conn.execute('PRAGMA user_version=3')
        conn.execute('CREATE TABLE future_data(value TEXT)')
        conn.execute("INSERT INTO future_data VALUES('future version')")
    with pytest.raises(SchemaMigrationError, match='newer'):
        LibraryDB(path)
    with sqlite3.connect(path) as conn:
        assert conn.execute('PRAGMA user_version').fetchone()[0] == 3
        assert conn.execute('PRAGMA journal_mode').fetchone()[0] == 'delete'
        assert conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() == [('future_data',)]
        assert conn.execute('SELECT * FROM future_data').fetchall() == [('future version',)]


def test_context_manager_closes_the_connection(tmp_path):
    with LibraryDB(tmp_path / 'library.sqlite') as db:
        assert db.get_analysis(Path('absent.jpg'), Path('absent_edit.jpg')) is None
    with pytest.raises(sqlite3.ProgrammingError, match='closed'):
        db.conn.execute('SELECT 1')
