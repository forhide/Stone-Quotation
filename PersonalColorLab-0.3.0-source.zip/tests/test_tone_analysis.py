import json

import numpy as np
import pytest

from personal_color_lab.core.tone_analysis import MAX_SAMPLES, analyze_tone


def gray_ramp(size=64):
    values = np.linspace(0, 255, size * size).astype(np.uint8).reshape(size, size)
    return np.repeat(values[..., None], 3, axis=2)


def apply_linear_exposure(rgb, ev):
    srgb = rgb.astype(np.float64) / 255
    linear = np.where(srgb <= 0.04045, srgb / 12.92, ((srgb + 0.055) / 1.055) ** 2.4)
    edited_linear = np.clip(linear * 2**ev, 0, 1)
    encoded = np.where(
        edited_linear <= 0.0031308,
        12.92 * edited_linear,
        1.055 * edited_linear ** (1 / 2.4) - 0.055,
    )
    return np.rint(encoded * 255).astype(np.uint8)


def test_identity_has_zero_deltas_and_identity_transfer():
    rgb = gray_ramp()
    report = analyze_tone(rgb, rgb.copy(), np.ones(rgb.shape[:2], dtype=bool))
    assert report["mean_luminance_delta"] == 0
    assert report["contrast_delta"] == 0
    assert report["estimated_exposure_ev"] == 0
    assert all(zone["delta"] == 0 for zone in report["zones"].values())
    assert all(sample["input"] == pytest.approx(sample["output"]) for sample in report["tone_transfer"])
    assert sum(sample["count"] for sample in report["tone_transfer"]) == rgb.shape[0] * rgb.shape[1]
    json.dumps(report, allow_nan=False)


@pytest.mark.parametrize("ev", [-1.0, 1.0])
def test_linear_exposure_recovers_ev(ev):
    rgb = gray_ramp()
    report = analyze_tone(rgb, apply_linear_exposure(rgb, ev), np.ones(rgb.shape[:2], dtype=bool))
    assert report["estimated_exposure_ev"] == pytest.approx(ev, abs=0.03)
    assert report["exposure_confidence"] > 0.3
    assert np.sign(report["mean_luminance_delta"]) == np.sign(ev)


def test_selective_shadow_lift_does_not_invent_other_zone_changes():
    rgb = gray_ramp()
    edited = rgb.copy()
    selected = rgb[..., 0] < 64
    edited[selected] += 25
    report = analyze_tone(rgb, edited, np.ones(rgb.shape[:2], dtype=bool))
    assert report["zones"]["shadows"]["delta"] == pytest.approx(25 / 255)
    assert report["zones"]["midtones"]["delta"] == 0
    assert report["zones"]["highlights"]["delta"] == 0
    assert report["contrast_delta"] < 0


def test_absent_zones_are_unknown_and_not_zero():
    rgb = np.full((20, 20, 3), 120, dtype=np.uint8)
    report = analyze_tone(rgb, rgb, np.ones((20, 20), dtype=bool))
    assert report["zones"]["shadows"] == {"delta": None, "sample_count": 0, "confidence": 0.0}
    assert report["zones"]["highlights"] == {"delta": None, "sample_count": 0, "confidence": 0.0}
    assert report["zones"]["midtones"]["delta"] == 0


def test_empty_mask_reports_no_evidence_and_serializes():
    rgb = gray_ramp()
    report = analyze_tone(rgb, rgb, np.zeros(rgb.shape[:2], dtype=bool))
    assert report["sample_count"] == 0
    assert report["estimated_exposure_ev"] is None
    assert report["mean_luminance_delta"] is None
    assert report["tone_transfer"] == []
    assert report["exposure_confidence"] == 0
    assert "no_valid_overlap" in report["limitations"]
    json.dumps(report, allow_nan=False)


def test_overlap_mask_excludes_unrelated_edit():
    original = np.full((30, 30, 3), 100, dtype=np.uint8)
    edited = original.copy()
    edited[:15] = 255
    mask = np.zeros((30, 30), dtype=bool)
    mask[15:] = True
    report = analyze_tone(original, edited, mask)
    assert report["sample_count"] == 450
    assert report["mean_luminance_delta"] == 0
    assert report["clipping"]["edited"]["white_fraction"] == 0


@pytest.mark.parametrize("source,edited,black,white", [(0, 0, 1.0, 0.0), (255, 255, 0.0, 1.0), (0, 255, 0.0, 1.0)])
def test_extreme_pixels_do_not_fabricate_exposure(source, edited, black, white):
    original = np.full((20, 20, 3), source, dtype=np.uint8)
    changed = np.full_like(original, edited)
    report = analyze_tone(original, changed, np.ones((20, 20), dtype=bool))
    assert report["estimated_exposure_ev"] is None
    assert report["exposure_confidence"] == 0
    assert report["clipping"]["edited"]["black_fraction"] == black
    assert report["clipping"]["edited"]["white_fraction"] == white
    json.dumps(report, allow_nan=False)


def test_saturated_color_reports_channel_clipping_not_white_clipping():
    rgb = np.full((20, 20, 3), [255, 0, 0], dtype=np.uint8)
    report = analyze_tone(rgb, rgb, np.ones((20, 20), dtype=bool))
    assert report["clipping"]["original"]["white_fraction"] == 0
    assert report["clipping"]["original"]["channel_high_fraction"] == pytest.approx(1 / 3)
    assert report["clipping"]["original"]["channel_low_fraction"] == pytest.approx(2 / 3)
    assert report["exposure_confidence"] == 0


def test_nonmonotone_observations_are_preserved_beside_monotone_fit():
    rgb = gray_ramp()
    edited = 255 - rgb
    report = analyze_tone(rgb, edited, np.ones(rgb.shape[:2], dtype=bool))
    fitted = [point["output"] for point in report["tone_transfer"]]
    observed = [point["observed_output"] for point in report["tone_transfer"]]
    assert all(a <= b for a, b in zip(fitted, fitted[1:]))
    assert observed[0] > observed[-1]
    assert report["exposure_confidence"] < 0.2


def test_sampling_is_bounded_deterministic_and_non_destructive():
    rgb = gray_ramp(size=400)
    before = rgb.copy()
    mask = np.ones(rgb.shape[:2], dtype=bool)
    first = analyze_tone(rgb, rgb, mask)
    second = analyze_tone(rgb, rgb, mask)
    assert first["sample_count"] == MAX_SAMPLES
    assert first == second
    np.testing.assert_array_equal(rgb, before)
    assert mask.all()


@pytest.mark.parametrize("bad", ["shape", "dtype", "mask_dtype", "mask_shape"])
def test_invalid_inputs_are_rejected(bad):
    original = np.zeros((5, 5, 3), dtype=np.uint8)
    edited = original.copy()
    mask = np.ones((5, 5), dtype=bool)
    if bad == "shape":
        edited = edited[:4]
    elif bad == "dtype":
        original = original.astype(np.float32)
    elif bad == "mask_dtype":
        mask = mask.astype(np.uint8)
    else:
        mask = mask[:4]
    with pytest.raises(ValueError):
        analyze_tone(original, edited, mask)
