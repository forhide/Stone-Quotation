from pathlib import Path
import hashlib
import json
import socket

import cv2
import numpy as np
from PIL import Image
import pytest

from personal_color_lab.core.database import LibraryDB
from personal_color_lab.core.edit_reverse import analyze_pair
from personal_color_lab.core.scanner import scan_folder, find_pairs


def _scene(seed=27):
    rng = np.random.default_rng(seed)
    pixels = rng.integers(40, 160, (360, 480, 3), dtype=np.uint8)
    pixels = cv2.GaussianBlur(pixels, (5, 5), 0)
    for i in range(60):
        x, y = rng.integers(12, 330, 2)
        color = tuple(int(c) for c in rng.integers(35, 200, 3))
        cv2.circle(pixels, (int(x), int(y)), int(rng.integers(3, 12)), color, -1)
    # Neutral support with textured edges for robust WB/registration evidence.
    for i in range(5):
        level = 45 + 25 * i
        cv2.rectangle(pixels, (370, 12 + 60 * i), (460, 50 + 60 * i), (level,) * 3, -1)
    return pixels


def _save(path: Path, pixels):
    Image.fromarray(pixels).save(path, quality=98, subsampling=0)


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_scan_analyze_persist_roundtrip_without_network_or_input_changes(tmp_path, monkeypatch):
    original, edited = tmp_path / "scene_original.jpg", tmp_path / "scene_edit.jpg"
    pixels = _scene()
    _save(original, pixels)
    _save(edited, np.clip(pixels.astype(float) * 1.12 + [8, 1, -5], 0, 255).astype(np.uint8))
    before = [_hash(original), _hash(edited)]

    def reject_network(*args, **kwargs):
        raise AssertionError("Analysis must not use the network")

    monkeypatch.setattr(socket, "socket", reject_network)
    pairs = find_pairs(scan_folder(tmp_path))
    pair = next(p for p in pairs if p.pair_type == "JPG+JPG")
    result = analyze_pair(pair.original, pair.edited)
    assert result["status"] == "ok"
    assert result["alignment"]["confidence"] > 0.5
    assert result["tone"]["mean_luminance_delta"] > 0.02
    assert result["color"]["lab"]["delta_b"] > 0
    assert result["lightroom_estimates"]["approximate"] is True
    assert result["provenance"]["exact_xmp_parameters"] is False
    assert result["source_type"] == "inferred_jpg_pair"
    assert result["provenance"]["input_fingerprints"] == dict(zip(("original", "edited"), before))
    json.dumps(result, allow_nan=False)
    db = LibraryDB(tmp_path / "library.db")
    try:
        db.replace_scan(scan_folder(tmp_path), pairs)
        row = db.save_analysis(original, edited, result)
        assert db.save_analysis(original, edited, result) == row
        assert db.get_analysis(original, edited) == result
    finally:
        db.close()
    assert before == [_hash(original), _hash(edited)]


def test_mismatch_returns_failure_without_tone_or_color(tmp_path):
    original, edited = tmp_path / "a.jpg", tmp_path / "b.jpg"
    _save(original, _scene(7))
    _save(edited, _scene(103))
    result = analyze_pair(original, edited)
    assert result["status"] == "alignment_failed"
    assert result["confidence"] == 0
    assert result["tone"] == result["color"] == {}
    assert result["lightroom_estimates"]["available"] is False
    assert "alignment_failed" in result["warnings"]


def test_non_jpeg_and_missing_inputs_raise_clear_errors(tmp_path):
    image = tmp_path / "image.png"
    Image.new("RGB", (10, 10)).save(image)
    with pytest.raises(ValueError, match="JPEG"):
        analyze_pair(image, image)
    with pytest.raises(FileNotFoundError):
        analyze_pair(tmp_path / "missing.jpg", tmp_path / "missing.jpg")


def test_unreadable_icc_preserves_alignment_but_abstains_from_color_and_tone(tmp_path):
    original, edited = tmp_path / "source.jpg", tmp_path / "edited.jpg"
    pixels = _scene()
    Image.fromarray(pixels).save(original, quality=98, icc_profile=b"not a valid ICC profile")
    _save(edited, np.clip(pixels.astype(float) * 1.12, 0, 255).astype(np.uint8))
    result = analyze_pair(original, edited)
    assert result["alignment"]["success"] is True
    assert result["alignment"]["confidence"] > 0.5
    assert result["status"] == "color_space_uncertain"
    assert result["tone"] == result["color"] == {}
    assert result["confidence"] == 0
    assert result["lightroom_estimates"]["available"] is False
    assert result["provenance"]["color_space"] == "unverified_profile"
    assert "color_space_uncertain" in result["warnings"]


def test_rejects_file_changed_during_analysis(tmp_path, monkeypatch):
    from personal_color_lab.core import edit_reverse

    original, edited = tmp_path / "a.jpg", tmp_path / "b.jpg"
    _save(original, _scene())
    _save(edited, _scene())
    align = edit_reverse.align_images

    def mutate_after_read(*args, **kwargs):
        result = align(*args, **kwargs)
        edited.write_bytes(edited.read_bytes() + b"changed")
        return result

    monkeypatch.setattr(edit_reverse, "align_images", mutate_after_read)
    with pytest.raises(ValueError, match="changed during analysis"):
        analyze_pair(original, edited)
