from pathlib import Path
from personal_color_lab.core.scanner import normalized_stem, classify


def test_normalized_stem():
    assert normalized_stem(Path('IMG_0001_edit.jpg')) == 'img0001'
    assert normalized_stem(Path('IMG-0001-final.JPG')) == 'img0001'


def test_classify():
    assert classify(Path('a.ARW')) == 'raw'
    assert classify(Path('a.xmp')) == 'xmp'
    assert classify(Path('a.jpeg')) == 'jpg'
