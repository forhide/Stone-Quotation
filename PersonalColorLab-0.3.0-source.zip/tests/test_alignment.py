"""Independent known-geometry tests, with colour edits applied afterward."""

import hashlib
import json
from pathlib import Path

import cv2
import numpy as np
import pytest
from PIL import Image, ImageCms

from personal_color_lab.core.alignment import align_images


def _scene(seed: int = 17, width: int = 800, height: int = 600) -> np.ndarray:
    rng = np.random.default_rng(seed)
    coarse = rng.integers(20, 230, (45, 60, 3), dtype=np.uint8)
    scene = cv2.resize(coarse, (width, height), interpolation=cv2.INTER_CUBIC)
    scene = cv2.GaussianBlur(scene, (0, 0), 1.3)
    for _ in range(100):
        x, y = int(rng.integers(width)), int(rng.integers(height))
        radius = int(rng.integers(4, 30))
        color = tuple(int(c) for c in rng.integers(15, 245, 3))
        cv2.circle(scene, (x, y), radius, color, 2, cv2.LINE_AA)
    return scene


def _tone(image: np.ndarray) -> np.ndarray:
    normalized = image.astype(np.float32) / 255
    edited = normalized ** 0.85 * np.array([1.05, 0.97, 0.92]) + np.array([0.025, 0.01, 0.02])
    return np.clip(edited * 255, 0, 255).astype(np.uint8)


def _save(path: Path, image: np.ndarray, **kwargs) -> None:
    Image.fromarray(image).save(path, quality=98, subsampling=0, **kwargs)


def _assert_registration(result, expected: np.ndarray, tolerance: float = 2.5) -> None:
    assert result.metadata["success"], result.metadata
    assert result.metadata["confidence"] > 0.6
    assert result.metadata["overlap_fraction"] > 0.7
    observed = np.array(result.metadata["matrix"])
    probe = np.array([[160, 120, 1], [320, 200, 1], [560, 400, 1], [400, 300, 1]])
    errors = np.linalg.norm((probe @ observed.T)[:, :2] - (probe @ expected.T)[:, :2], axis=1)
    assert max(errors) < tolerance, errors
    assert result.original_aligned.dtype == np.uint8
    assert result.edited.dtype == np.uint8
    assert result.mask.dtype == bool
    assert result.original_aligned.shape == result.edited.shape
    assert result.mask.shape == result.edited.shape[:2]
    json.dumps(result.metadata, allow_nan=False)


def test_identity_tone_and_original_files_preserved(tmp_path):
    scene = _scene()
    original, edited = tmp_path / "original.jpg", tmp_path / "edited.jpg"
    _save(original, scene)
    _save(edited, _tone(scene))
    before = [hashlib.sha256(path.read_bytes()).hexdigest() for path in (original, edited)]
    result = align_images(original, edited)
    _assert_registration(result, np.eye(3), tolerance=0.8)
    assert abs(result.metadata["rotation_degrees"]) < 0.2
    assert result.metadata["scale"] == pytest.approx(1, abs=0.005)
    assert result.metadata["crop_bounds_original"] is None
    assert before == [hashlib.sha256(path.read_bytes()).hexdigest() for path in (original, edited)]


def test_crop_resize_rotation_and_tone(tmp_path):
    scene = _scene()
    rotation = np.vstack((cv2.getRotationMatrix2D((400, 300), 4.0, 1.0), [0, 0, 1]))
    rotated = cv2.warpAffine(scene, rotation[:2], (800, 600))
    cropped = rotated[60:510, 80:700]
    resized = cv2.resize(cropped, (465, 338), interpolation=cv2.INTER_AREA)
    _save(tmp_path / "original.jpg", scene)
    _save(tmp_path / "edited.jpg", _tone(resized))
    crop = np.array([[1, 0, -80], [0, 1, -60], [0, 0, 1]], dtype=float)
    sx, sy = 465 / 620, 338 / 450
    resize = np.array([[sx, 0, (sx - 1) / 2], [0, sy, (sy - 1) / 2], [0, 0, 1]])
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    _assert_registration(result, resize @ crop @ rotation)
    assert result.metadata["rotation_degrees"] == pytest.approx(-4.0, abs=0.4)
    assert result.metadata["scale"] == pytest.approx(0.75, abs=0.01)
    bounds = result.metadata["crop_bounds_original"]
    assert bounds is not None and bounds[2] < 700 and bounds[3] < 520


def test_resize_full_resolution_matrix_and_bounded_arrays(tmp_path):
    scene = _scene(width=1600, height=1200)
    resized = cv2.resize(scene, (800, 600), interpolation=cv2.INTER_AREA)
    _save(tmp_path / "original.jpg", scene)
    _save(tmp_path / "edited.jpg", _tone(resized))
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg", max_dimension=320)
    expected = np.array([[0.5, 0, -0.25], [0, 0.5, -0.25], [0, 0, 1]])
    _assert_registration(result, expected, tolerance=2)
    assert max(result.edited.shape[:2]) == 320
    assert result.metadata["scale"] == pytest.approx(0.5, abs=0.003)
    assert result.metadata["original_size"] == [1600, 1200]


def test_unrelated_images_do_not_receive_valid_mask(tmp_path):
    _save(tmp_path / "original.jpg", _scene(17))
    _save(tmp_path / "edited.jpg", _scene(99))
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    assert not result.metadata["success"], result.metadata
    assert result.metadata["confidence"] == 0
    assert not result.mask.any()
    assert result.metadata["method"] == "unregistered"
    assert "alignment_unreliable" in result.metadata["warnings"]


def test_sparse_geometry_uses_verified_ecc_fallback(tmp_path):
    scene = np.full((400, 500, 3), 55, dtype=np.uint8)
    cv2.ellipse(scene, (150, 150), (70, 100), 28, 0, 360, (190, 180, 165), -1, cv2.LINE_AA)
    cv2.rectangle(scene, (310, 60), (410, 310), (100, 180, 120), -1)
    scene = cv2.GaussianBlur(scene, (0, 0), 2)
    known = cv2.getRotationMatrix2D((250, 200), 1.7, 1)
    known[:, 2] += [9, -8]
    edited = _tone(cv2.warpAffine(scene, known, (500, 400)))
    _save(tmp_path / "original.jpg", scene)
    _save(tmp_path / "edited.jpg", edited)
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    _assert_registration(result, np.vstack((known, [0, 0, 1])), tolerance=1)
    assert result.metadata["method"] == "gradient_ecc"


def test_insufficient_overlap_is_rejected(tmp_path):
    scene = _scene()
    translated = cv2.warpAffine(scene, np.array([[1, 0, 650], [0, 1, 0]], dtype=float), (800, 600))
    _save(tmp_path / "original.jpg", scene)
    _save(tmp_path / "edited.jpg", _tone(translated))
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    assert not result.metadata["success"], result.metadata
    assert not result.mask.any()
    assert "low_overlap" in result.metadata["warnings"]


@pytest.mark.parametrize("blank", [np.full((180, 240, 3), 75, dtype=np.uint8), np.tile(np.linspace(20, 230, 240, dtype=np.uint8)[None, :, None], (180, 1, 3))])
def test_blank_or_smooth_images_are_ambiguous(tmp_path, blank):
    _save(tmp_path / "original.jpg", blank)
    _save(tmp_path / "edited.jpg", _tone(blank))
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    assert not result.metadata["success"], result.metadata
    assert not result.mask.any()
    assert "insufficient_texture" in result.metadata["warnings"]


def test_exif_orientation_is_applied_before_registration(tmp_path):
    scene = _scene()
    unrotated_storage = cv2.rotate(scene, cv2.ROTATE_90_COUNTERCLOCKWISE)
    exif = Image.Exif()
    exif[274] = 6  # Decode storage by rotating 90 degrees clockwise.
    _save(tmp_path / "original.jpg", unrotated_storage, exif=exif)
    _save(tmp_path / "edited.jpg", _tone(scene))
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    _assert_registration(result, np.eye(3), tolerance=1)
    assert result.metadata["original_size"] == [800, 600]
    assert result.metadata["coordinate_system"] == "exif_oriented_pixels"


def test_local_icc_conversion_and_invalid_profile_warning(tmp_path):
    profile = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
    scene = _scene()
    _save(tmp_path / "original.jpg", scene, icc_profile=profile)
    _save(tmp_path / "edited.jpg", _tone(scene), icc_profile=profile)
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    _assert_registration(result, np.eye(3), tolerance=1)
    assert "icc_conversion_failed" not in result.metadata["warnings"]
    _save(tmp_path / "edited.jpg", _tone(scene), icc_profile=b"invalid local ICC profile")
    result = align_images(tmp_path / "original.jpg", tmp_path / "edited.jpg")
    assert "icc_conversion_failed" in result.metadata["warnings"]
    assert result.metadata["success"]


def test_bad_input_and_invalid_resource_limit(tmp_path):
    malformed = tmp_path / "broken.jpg"
    malformed.write_text("this is not a photograph")
    with pytest.raises(ValueError, match="Cannot read image"):
        align_images(malformed, malformed)
    with pytest.raises(ValueError, match="max_dimension"):
        align_images(malformed, malformed, max_dimension=0)
