"""Installed-entrypoint diagnostics and resource loading without a desktop."""
import json
import os
from pathlib import Path
import runpy
import socket
import subprocess
import sys
import zipfile

import pytest

from personal_color_lab import __version__
from personal_color_lab.core import package_check
from personal_color_lab.core.constants import APP_VERSION, DATA_DIR_ENV
from personal_color_lab.core.i18n import I18N
from personal_color_lab import main as entrypoint

ROOT = Path(__file__).resolve().parents[1]


def test_offline_package_self_test_never_touches_existing_user_data(tmp_path, monkeypatch):
    user_data = tmp_path / 'user library'
    user_data.mkdir()
    settings, library = user_data / 'settings.json', user_data / 'library.db'
    settings.write_text('{"language": "ko", "existing_user_setting": true}', encoding='utf-8')
    library.write_bytes(b'preserve-this-existing-library')
    before = [(path.read_bytes(), path.stat().st_mtime_ns) for path in (settings, library)]
    monkeypatch.setenv(DATA_DIR_ENV, str(user_data))
    old_home = os.environ.get('HOME')
    monkeypatch.chdir(tmp_path)
    created = []
    original_temporary_directory = package_check.tempfile.TemporaryDirectory

    def tracked_temporary_directory(*args, **kwargs):
        result = original_temporary_directory(*args, dir=tmp_path, **kwargs)
        created.append(Path(result.name))
        return result

    def forbidden_network(*args, **kwargs):
        pytest.fail('Package self-test attempted a network connection')

    monkeypatch.setattr(package_check.tempfile, 'TemporaryDirectory', tracked_temporary_directory)
    monkeypatch.setattr(socket, 'create_connection', forbidden_network)
    monkeypatch.setattr(socket.socket, 'connect', forbidden_network)
    report = package_check.run_package_check()
    assert report['ok'], report
    assert report['app_version'] == APP_VERSION == __version__
    assert [check['name'] for check in report['checks']] == [
        'locale_resources', 'native_dependencies', 'tcl_runtime', 'synthetic_analysis_and_library',
        'synthetic_raw_analysis',
        'synthetic_source_workflows_and_profiles',
    ]
    assert all(check['ok'] for check in report['checks'])
    dependencies = next(check['details'] for check in report['checks'] if check['name'] == 'native_dependencies')
    assert dependencies['rawpy'] and dependencies['libraw']
    raw = next(check['details'] for check in report['checks'] if check['name'] == 'synthetic_raw_analysis')
    assert raw['raw_jpg_status'] == 'ok'
    assert raw['decoded_dimensions'] == [480, 360]
    assert raw['embedded_preview_used'] is False
    assert raw['originals_unchanged'] is True
    sources = next(check['details'] for check in report['checks'] if check['name'] == 'synthetic_source_workflows_and_profiles')
    assert set(sources['modes']) == {'raw_jpg', 'raw_xmp', 'reference_jpg'}
    for mode, details in sources['modes'].items():
        assert details['status'] == 'ok'
        assert details['successful_inputs'] == details['sample_count'] == (2 if mode == 'reference_jpg' else 1)
        assert details['profile_saved_and_reopened'] is True
    assert sources['originals_unchanged'] is True
    assert sources['temporary_files_removed_on_return'] is True
    assert created and all(not path.exists() for path in created)
    assert before == [(path.read_bytes(), path.stat().st_mtime_ns) for path in (settings, library)]
    assert os.environ.get('HOME') == old_home


def test_self_test_reports_missing_packaged_resource_and_continues_other_checks(monkeypatch):
    def missing_locale():
        raise FileNotFoundError('Missing bundled locale resource')

    monkeypatch.setattr(package_check, '_locales', missing_locale)
    for name in ('_dependencies', '_tcl_runtime', '_synthetic_analysis_and_library', '_synthetic_raw_analysis', '_synthetic_source_workflows_and_profiles'):
        monkeypatch.setattr(package_check, name, lambda: {'checked': True})
    report = package_check.run_package_check()
    assert not report['ok']
    assert report['checks'][0]['error_type'] == 'FileNotFoundError'
    assert all(check['ok'] for check in report['checks'][1:])


def test_locale_resource_loading_is_independent_of_launch_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert I18N('en').t('app_title') == 'Personal Color Lab'
    assert I18N('ko').t('original') == '원본'


def test_locale_resources_load_from_python_archive(tmp_path):
    archive = tmp_path / 'app payload.zip'
    files = [
        'personal_color_lab/__init__.py',
        'personal_color_lab/core/constants.py',
        'personal_color_lab/core/i18n.py',
        'personal_color_lab/locales/en.json',
        'personal_color_lab/locales/ko.json',
    ]
    with zipfile.ZipFile(archive, 'w') as zipped:
        # Explicit directories let zipimport resolve the existing namespace core.
        zipped.writestr('personal_color_lab/core/', '')
        for path in files:
            zipped.write(ROOT / path, path)
    environment = dict(os.environ, PYTHONPATH=str(archive))
    command = [sys.executable, '-c', 'from personal_color_lab.core.i18n import I18N; assert I18N("ko").t("original") == "원본"; print(I18N("en").t("app_title"))']
    result = subprocess.run(command, cwd=tmp_path, env=environment, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == 'Personal Color Lab'


def test_windowed_self_test_writes_report_without_stdout(tmp_path, monkeypatch):
    report = {'ok': True, 'checks': [{'name': 'fixture', 'ok': True}]}
    monkeypatch.setattr(package_check, 'run_package_check', lambda: report)
    output = tmp_path / 'report folder' / 'self test.json'
    with monkeypatch.context() as patch:
        patch.setattr(sys, 'stdout', None)
        patch.setattr(sys, 'stderr', None)
        assert entrypoint.main(['--self-test', '--self-test-report', str(output)]) == 0
    assert json.loads(output.read_text(encoding='utf-8')) == report


def test_self_test_failure_has_nonzero_exit_and_machine_readable_report(monkeypatch, capsys):
    report = {'ok': False, 'checks': [{'name': 'fixture', 'ok': False, 'error': 'missing local prerequisite'}]}
    monkeypatch.setattr(package_check, 'run_package_check', lambda: report)
    assert entrypoint.main(['--self-test']) == 1
    assert json.loads(capsys.readouterr().out) == report


def test_report_output_failure_returns_nonzero_exit(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(package_check, 'run_package_check', lambda: {'ok': True, 'checks': []})
    assert entrypoint.main(['--self-test', '--self-test-report', str(tmp_path)]) == 1
    assert 'Cannot write self-test report' in capsys.readouterr().err


def test_default_entrypoint_preserves_gui_launch(monkeypatch):
    launched = []
    monkeypatch.setattr(entrypoint, 'run', lambda: launched.append(True))
    assert entrypoint.main([]) == 0
    assert launched == [True]


def test_importing_script_does_not_launch_gui(monkeypatch):
    monkeypatch.setattr(entrypoint, 'run', lambda: pytest.fail('Importing launcher started a GUI'))
    runpy.run_path(str(ROOT / 'run_app.py'))


def test_report_option_requires_explicit_self_test(tmp_path):
    with pytest.raises(SystemExit) as error:
        entrypoint.main(['--self-test-report', str(tmp_path / 'report.json')])
    assert error.value.code == 2


def test_version_flag_uses_the_shared_application_version(capsys):
    with pytest.raises(SystemExit) as error:
        entrypoint.main(['--version'])
    assert error.value.code == 0
    assert APP_VERSION in capsys.readouterr().out
