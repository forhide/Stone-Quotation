import json

import cv2
import numpy as np
import pytest

from personal_color_lab.core.color_analysis import analyze_color


def solid(rgb, size=32):
    return np.full((size, size, 3), rgb, dtype=np.uint8)


def analyze(original, edited):
    return analyze_color(original, edited, np.ones(original.shape[:2], dtype=bool))


def hue_image(hue):
    hsv = np.full((32, 32, 3), [hue, 0.7, 0.7], dtype=np.float32)
    return np.rint(cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB) * 255).astype(np.uint8)


def test_identity_has_zero_perceptual_color_deltas():
    rng = np.random.default_rng(19)
    rgb = rng.integers(0, 256, (64, 64, 3), dtype=np.uint8)
    report = analyze(rgb, rgb.copy())
    assert report["lab"] == {"delta_l": 0.0, "delta_a": 0.0, "delta_b": 0.0, "mean_delta_e": 0.0}
    assert report["hsv"]["hue_delta_degrees"] == 0
    assert report["hsv"]["saturation_delta"] == 0
    assert report["hsl"]["lightness_delta"] == 0
    json.dumps(report, allow_nan=False)


def test_grayscale_has_no_defined_hue_or_colored_band():
    values = np.linspace(20, 220, 32 * 32).astype(np.uint8).reshape(32, 32)
    original = np.repeat(values[..., None], 3, axis=2)
    report = analyze(original, original)
    assert report["hsv"]["hue_delta_degrees"] is None
    assert report["hsl"]["hue_delta_degrees"] is None
    assert all(band["sample_count"] == 0 for band in report["hue_bands"].values())
    assert report["wb_tint"]["temperature_direction"] == "neutral"
    assert report["wb_tint"]["tint_direction"] == "neutral"
    assert 0 < report["wb_tint"]["confidence"] <= 0.7


def test_known_color_shift_is_measured_without_claiming_white_balance():
    original = solid([180, 70, 70])
    edited = solid([180, 140, 70])
    report = analyze(original, edited)
    assert report["lab"]["delta_b"] > 10
    assert report["lab"]["delta_a"] < 0
    assert report["lab"]["mean_delta_e"] > 10
    assert report["hue_bands"]["red"]["sample_count"] == 1024
    assert report["hue_bands"]["red"]["hue_delta_degrees"] > 30
    assert report["wb_tint"]["confidence"] == 0
    assert report["wb_tint"]["temperature_direction"] == "uncertain"
    assert report["wb_tint"]["tint_direction"] == "uncertain"


@pytest.mark.parametrize("rgb,temperature,tint", [
    # RGB channel shifts need not lie on a single Lab axis.
    ([145, 128, 108], "warmer", "magenta"),
    ([108, 128, 145], "cooler", "green"),
    ([140, 115, 140], "cooler", "magenta"),
    ([115, 140, 115], "warmer", "green"),
])
def test_neutral_color_casts_report_only_tendencies(rgb, temperature, tint):
    report = analyze(solid([128, 128, 128]), solid(rgb))
    assert report["wb_tint"]["temperature_direction"] == temperature
    assert report["wb_tint"]["tint_direction"] == tint
    assert report["wb_tint"]["neutral_sample_count"] == 1024
    assert report["wb_tint"]["confidence"] == pytest.approx(0.7)
    assert "color_wb_tint_confounders" in report["limitations"]


def test_sparse_neutral_evidence_remains_uncertain():
    report = analyze(solid([128, 128, 128], size=4), solid([145, 128, 108], size=4))
    assert report["wb_tint"]["delta_b"] > 0
    assert report["wb_tint"]["temperature_direction"] == "uncertain"
    assert report["wb_tint"]["tint_direction"] == "uncertain"
    assert report["wb_tint"]["confidence"] < 0.1
    assert "color_wb_tint_insufficient_neutrals" in report["limitations"]


def test_small_neutral_fraction_does_not_support_global_white_balance():
    original = solid([180, 70, 70], size=100)
    edited = original.copy()
    original[:1, :80] = [128, 128, 128]
    edited[:1, :80] = [145, 128, 108]
    report = analyze(original, edited)
    assert report["wb_tint"]["neutral_sample_count"] == 80
    assert report["wb_tint"]["confidence"] < 0.1
    assert report["wb_tint"]["temperature_direction"] == "uncertain"


def test_inconsistent_local_casts_reduce_white_balance_confidence():
    original = solid([128, 128, 128])
    consistent = solid([160, 128, 96])
    inconsistent = consistent.copy()
    inconsistent[:16] = [96, 128, 160]
    strong_report = analyze(original, consistent)
    weak_report = analyze(original, inconsistent)
    assert weak_report["wb_tint"]["confidence"] < strong_report["wb_tint"]["confidence"] / 2
    assert weak_report["wb_tint"]["temperature_direction"] == "uncertain"


def test_hue_wrap_uses_short_circular_shift():
    report = analyze(hue_image(350), hue_image(10))
    assert report["hsv"]["hue_delta_degrees"] == pytest.approx(20, abs=1)
    assert report["hue_bands"]["red"]["hue_delta_degrees"] == pytest.approx(20, abs=1)
    assert report["hue_bands"]["red"]["sample_count"] == 1024


def test_desaturated_result_has_no_defined_hue_delta():
    report = analyze(hue_image(90), solid([128, 128, 128]))
    assert report["hsv"]["hue_delta_degrees"] is None
    assert report["hue_bands"]["green"]["hue_delta_degrees"] is None
    assert report["hue_bands"]["green"]["saturation_delta"] < 0


def test_mask_excludes_color_changes_and_images_are_not_mutated():
    original = solid([128, 128, 128])
    edited = original.copy()
    edited[:16] = [200, 128, 60]
    before = edited.copy()
    mask = np.zeros((32, 32), dtype=bool)
    mask[16:] = True
    report = analyze_color(original, edited, mask)
    assert report["sample_count"] == 512
    assert report["lab"]["mean_delta_e"] == 0
    assert report["wb_tint"]["temperature_direction"] == "neutral"
    np.testing.assert_array_equal(edited, before)


@pytest.mark.parametrize("source,changed", [(0, 0), (255, 255), (0, 255)])
def test_extreme_pixels_are_finite_and_have_no_neutral_inference(source, changed):
    report = analyze(solid([source] * 3), solid([changed] * 3))
    assert report["wb_tint"]["confidence"] == 0
    assert report["wb_tint"]["temperature_direction"] == "uncertain"
    json.dumps(report, allow_nan=False)


def test_empty_mask_reports_unknown_color_and_serializes():
    original = solid([128, 128, 128])
    report = analyze_color(original, original, np.zeros((32, 32), dtype=bool))
    assert report["sample_count"] == 0
    assert all(value is None for value in report["lab"].values())
    assert all(band["confidence"] == 0 for band in report["hue_bands"].values())
    assert report["wb_tint"]["confidence"] == 0
    assert "no_valid_overlap" in report["limitations"]
    json.dumps(report, allow_nan=False)
