"""Shared generated CFA DNG used by tests and the packaged self-check."""
from personal_color_lab.core.synthetic_raw import write_test_dng
