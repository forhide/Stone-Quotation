"""Final-JPEG observations and robust per-photo aggregation, with real JPEGs."""

from copy import deepcopy
import hashlib
import json
import socket

import cv2
import numpy as np
from PIL import Image, ImageCms
import pytest

from personal_color_lab.core import reference_analysis as reference


def save_jpeg(tmp_path, name, rgb, *, size=(48, 48), **kwargs):
    pixels = np.asarray(rgb, dtype=np.uint8)
    if pixels.ndim == 1:
        pixels = np.tile(pixels, (size[1], size[0], 1))
    path = tmp_path / name
    Image.fromarray(pixels).save(path, quality=100, subsampling=0, **kwargs)
    return path


def test_red_has_quantified_rendered_luma_saturation_lab_and_hue(tmp_path):
    path = save_jpeg(tmp_path, "red.jpg", [255, 0, 0])
    payload = reference.analyze_reference(path)
    appearance = payload["appearance"]
    assert payload["status"] == "ok"
    assert appearance["luminance"]["mean"] == pytest.approx(0.2126, abs=0.002)
    assert appearance["saturation"]["mean"] == pytest.approx(1, abs=0.001)
    assert appearance["lab"]["mean_l"] == pytest.approx(53.2, abs=0.4)
    assert appearance["lab"]["mean_a"] == pytest.approx(80.1, abs=0.4)
    assert appearance["lab"]["mean_b"] == pytest.approx(67.2, abs=0.4)
    assert appearance["hue_bands"]["red"]["support_fraction"] == 1
    assert appearance["tonal_zones"]["midtones"]["support_fraction"] == 1
    assert appearance["tonal_zones"]["shadows"]["mean_b"] is None
    assert appearance["palette"][0]["fraction"] == 1
    assert appearance["tendencies"]["saturation"] == "vivid"
    assert payload["confidence_scope"] == "rendered_appearance_measurement"
    assert payload["provenance"]["inferred_edit_transform"] is False
    assert payload["provenance"]["exact_xmp_parameters"] is False
    assert "reference_content_and_lighting_confounders" in payload["warnings"]
    assert "reference_temperature_not_white_balance" in payload["warnings"]
    assert not {"parameters", "lightroom_estimates", "temperature_kelvin"} & payload.keys()


def test_neutral_stripes_measure_clipping_zones_and_never_invent_red_hue(tmp_path):
    pixels = np.repeat(np.array([0, 128, 255], dtype=np.uint8), 32)
    pixels = np.tile(pixels[None, :, None], (32, 1, 3))
    payload = reference.analyze_reference(save_jpeg(tmp_path, "neutrals.jpg", pixels))
    appearance = payload["appearance"]
    assert appearance["luminance"]["quantiles"]["p50"] == pytest.approx(128 / 255, abs=0.005)
    assert appearance["luminance"]["contrast_span"] == 1
    assert appearance["luminance"]["clipping"]["black_fraction"] == pytest.approx(1 / 3)
    assert appearance["luminance"]["clipping"]["white_fraction"] == pytest.approx(1 / 3)
    assert appearance["saturation"]["mean"] == 0
    assert all(zone["support_fraction"] == pytest.approx(1 / 3) for zone in appearance["tonal_zones"].values())
    assert all(band == {"support_fraction": 0, "saturation": None, "lightness": None}
               for band in appearance["hue_bands"].values())
    assert appearance["tendencies"]["temperature"] == "neutral"
    assert sum(color["fraction"] for color in appearance["palette"]) == pytest.approx(1)
    json.dumps(payload, allow_nan=False)


@pytest.mark.parametrize("name,hue", [
    ("red", 355), ("orange", 30), ("yellow", 60), ("green", 120),
    ("aqua", 180), ("blue", 225), ("purple", 270), ("magenta", 310),
])
def test_hue_bands_measure_known_colored_references(tmp_path, name, hue):
    hsv = np.full((32, 32, 3), [hue, 0.8, 0.8], dtype=np.float32)
    rgb = np.rint(cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB) * 255).astype(np.uint8)
    appearance = reference.analyze_reference(save_jpeg(tmp_path, "color.jpg", rgb))["appearance"]
    assert appearance["hue_bands"][name]["support_fraction"] == 1
    assert appearance["hue_bands"][name]["saturation"] == pytest.approx(0.8, abs=0.02)
    assert sum(band["support_fraction"] for band in appearance["hue_bands"].values()) == 1


def test_palette_is_deterministic_and_preserves_pixel_proportions(tmp_path):
    pixels = np.full((64, 128, 3), [230, 30, 30], dtype=np.uint8)
    pixels[:, 96:] = [30, 30, 230]
    path = save_jpeg(tmp_path, "two_colors.jpg", pixels)
    first = reference.analyze_reference(path)["appearance"]
    assert reference.analyze_reference(path)["appearance"] == first
    assert len(first["palette"]) == 2
    assert [color["fraction"] for color in first["palette"]] == [0.75, 0.25]
    assert first["palette"][0]["rgb"][0] > 220
    assert first["palette"][1]["rgb"][2] > 220


def test_exif_orientation_and_icc_are_applied_without_persisting_metadata(tmp_path):
    exif = Image.Exif()
    exif[274] = 6
    exif[315] = "private-camera-owner"
    exif[34853] = {1: "N", 2: (37.0, 33.0, 18.0), 3: "E", 4: (126.0, 58.0, 42.0)}
    profile = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
    path = save_jpeg(tmp_path, "oriented.jpg", [80, 120, 160], size=(120, 48), exif=exif, icc_profile=profile)
    before = path.read_bytes()
    payload = reference.analyze_reference(path)
    assert payload["status"] == "ok"
    assert payload["provenance"]["original_dimensions"] == [48, 120]
    assert payload["provenance"]["analysis_dimensions"] == [48, 120]
    assert "icc_conversion_failed" not in payload["warnings"]
    assert "private-camera-owner" not in json.dumps(payload)
    assert "gps" not in json.dumps(payload).lower()
    assert payload["provenance"]["input_fingerprints"]["original"] == hashlib.sha256(before).hexdigest()
    assert path.read_bytes() == before


def test_large_reference_is_bounded_before_analysis(tmp_path):
    path = save_jpeg(tmp_path, "large.jpg", [100, 110, 120], size=(2400, 1200))
    provenance = reference.analyze_reference(path)["provenance"]
    assert provenance["original_dimensions"] == [2400, 1200]
    assert provenance["analysis_dimensions"] == [1024, 512]
    assert provenance["pixel_count"] == 1024 * 512


def test_broken_icc_withholds_appearance_and_is_excluded_from_style(tmp_path):
    path = save_jpeg(tmp_path, "broken-profile.jpg", [240, 40, 30], icc_profile=b"not-an-ICC-profile")
    payload = reference.analyze_reference(path)
    assert payload["status"] == "color_space_uncertain"
    assert payload["appearance"] == {}
    assert payload["confidence"] == 0
    assert {"icc_conversion_failed", "color_space_uncertain"} <= set(payload["warnings"])
    summary = reference.aggregate_references([payload])
    assert summary["status"] == "empty"
    assert summary["sample_count"] == 0 and summary["excluded_count"] == 1
    assert summary["appearance"] == {} and summary["palette"] == []


def test_analysis_and_aggregation_need_no_network_and_preserve_source(tmp_path, monkeypatch):
    path = save_jpeg(tmp_path, "local.jpg", [100, 80, 70])
    before = path.read_bytes()
    def deny(*args, **kwargs):
        pytest.fail("Reference analysis attempted network access")
    monkeypatch.setattr(socket, "socket", deny)
    monkeypatch.setattr(socket, "create_connection", deny)
    monkeypatch.setattr(socket, "getaddrinfo", deny)
    summary = reference.aggregate_references([reference.analyze_reference(path)])
    assert summary["status"] == "ok"
    assert path.read_bytes() == before


def test_unsupported_unreadable_and_spoofed_files_fail_explicitly(tmp_path):
    png = tmp_path / "not-jpeg.png"
    Image.new("RGB", (16, 16)).save(png)
    spoofed = tmp_path / "spoofed.jpg"
    spoofed.write_bytes(png.read_bytes())
    corrupt = tmp_path / "corrupt.jpg"
    corrupt.write_bytes(b"broken JPEG")
    for path in (png, spoofed, corrupt):
        with pytest.raises((ValueError, OSError)):
            reference.analyze_reference(path)
    with pytest.raises(FileNotFoundError):
        reference.analyze_reference(tmp_path / "missing.jpg")


def test_source_changed_during_decode_is_not_saved(tmp_path, monkeypatch):
    path = save_jpeg(tmp_path, "changing.jpg", [100, 80, 70])
    read = reference._read_rgb
    def mutate(source, size):
        pixels = read(source, size)
        with source.open("ab") as stream:
            stream.write(b"changed")
        return pixels
    monkeypatch.setattr(reference, "_read_rgb", mutate)
    with pytest.raises(ValueError, match="changed during analysis"):
        reference.analyze_reference(path)


def test_nonfinite_measurements_are_never_returned(tmp_path, monkeypatch):
    path = save_jpeg(tmp_path, "nonfinite.jpg", [100, 80, 70])
    monkeypatch.setattr(reference, "_appearance", lambda pixels: {"invalid": float("nan")})
    with pytest.raises(ValueError, match="JSON"):
        reference.analyze_reference(path)


def test_aggregate_equal_image_weight_deduplication_medians_and_dispersion(tmp_path):
    dark = reference.analyze_reference(save_jpeg(tmp_path, "small.jpg", [0, 0, 0], size=(16, 16)))
    bright = reference.analyze_reference(save_jpeg(tmp_path, "large.jpg", [255, 255, 255], size=(320, 320)))
    copied = deepcopy(bright)
    copied["original_path"] = str(tmp_path / "copied.jpg")
    before = deepcopy([dark, bright, copied])
    summary = reference.aggregate_references([dark, bright, copied, {"status": "error"}])
    assert [dark, bright, copied] == before
    assert summary["sample_count"] == 2
    assert summary["duplicate_count"] == 1 and summary["excluded_count"] == 1
    assert summary["input_count"] == 4
    assert summary["appearance"]["luminance"]["mean"] == pytest.approx(0.5)
    assert summary["dispersion"]["luminance"]["mean"] == pytest.approx(0.5)
    assert [color["fraction"] for color in summary["palette"]] == [0.5, 0.5]
    assert summary["appearance"]["tonal_zones"]["midtones"]["mean_l"] is None
    assert summary["provenance"]["aggregation"] == "equal_image_weighted_medians"
    assert summary["provenance"]["scene_coverage_assessed"] is False
    assert "reference_duplicates_ignored" in summary["warnings"]
    json.dumps(summary, allow_nan=False)


def test_single_reference_has_no_claim_of_dataset_consistency(tmp_path):
    payload = reference.analyze_reference(save_jpeg(tmp_path, "single.jpg", [130, 110, 90]))
    summary = reference.aggregate_references([payload])
    assert summary["appearance"]["lab"] == payload["appearance"]["lab"]
    assert summary["consistency"]["score"] is None
    assert summary["consistency"]["level"] == "insufficient"
    assert summary["confidence"] <= 0.2
    assert {"reference_single_image", "reference_low_coverage"} <= set(summary["warnings"])
    assert summary["outliers"] == []


def test_consistency_decreases_for_diverse_appearances(tmp_path):
    similar = [reference.analyze_reference(save_jpeg(tmp_path, f"close-{v}.jpg", [v, v, v])) for v in (120, 125, 130)]
    diverse = [reference.analyze_reference(save_jpeg(tmp_path, f"far-{i}.jpg", rgb))
               for i, rgb in enumerate(([10, 10, 10], [250, 180, 80], [30, 40, 250]))]
    consistent = reference.aggregate_references(similar)
    varied = reference.aggregate_references(diverse)
    assert consistent["consistency"]["score"] > varied["consistency"]["score"]
    assert consistent["confidence"] > varied["confidence"]
    assert 0 < varied["confidence"] < 0.8
    assert consistent["consistency"]["level"] == "high"


def test_outlier_detection_requires_coverage_and_keeps_outlier_in_profile(tmp_path):
    normal = [reference.analyze_reference(save_jpeg(tmp_path, f"normal-{v}.jpg", [v, v, v])) for v in (99, 100, 101, 102)]
    unusual = reference.analyze_reference(save_jpeg(tmp_path, "unusual.jpg", [255, 210, 20]))
    assert reference.aggregate_references(normal[:3] + [unusual])["outliers"] == []
    summary = reference.aggregate_references(normal + [unusual])
    assert summary["sample_count"] == 5 and summary["excluded_count"] == 0
    assert len(summary["outliers"]) == 1
    assert summary["outliers"][0]["input_index"] == 4
    assert summary["outliers"][0]["original_path"] == unusual["original_path"]
    assert "reference_outliers_detected" in summary["warnings"]
    assert "reference_low_coverage" not in summary["warnings"]
    assert reference.aggregate_references(normal + [reference.analyze_reference(
        save_jpeg(tmp_path, "similar.jpg", [104, 104, 104]))])["outliers"] == []


@pytest.mark.parametrize("field,value", [
    (("appearance", "lab", "mean_b"), "5"),
    (("appearance", "lab", "mean_b"), True),
    (("appearance", "lab", "mean_b"), float("nan")),
    (("appearance", "saturation", "mean"), float("inf")),
    (("appearance", "saturation", "mean"), 1.5),
    (("appearance", "luminance", "quantiles", "p05"), 0.9),
    (("appearance", "tonal_zones", "shadows", "support_fraction"), -1),
    (("appearance", "palette"), [{"rgb": [100, 100, 100], "fraction": 0.5}]),
    (("appearance", "hue_bands"), {}),
    (("algorithm_version",), "unknown"),
    (("provenance", "input_fingerprints", "original"), "not-a-hash"),
])
def test_malformed_saved_measurements_are_excluded_without_breaking_batch(tmp_path, field, value):
    valid = reference.analyze_reference(save_jpeg(tmp_path, "valid.jpg", [100, 100, 100]))
    damaged = deepcopy(valid)
    destination = damaged
    for key in field[:-1]:
        destination = destination[key]
    destination[field[-1]] = value
    summary = reference.aggregate_references([damaged, valid])
    assert summary["sample_count"] == 1 and summary["excluded_count"] == 1
    assert summary["duplicate_count"] == 0
    assert summary["appearance"]["luminance"] == valid["appearance"]["luminance"]
    assert "reference_invalid_or_uncertain_excluded" in summary["warnings"]
    json.dumps(summary, allow_nan=False)


def test_empty_input_has_no_fabricated_appearance_or_confidence():
    summary = reference.aggregate_references([])
    assert summary["status"] == "empty"
    assert summary["input_count"] == summary["sample_count"] == 0
    assert summary["appearance"] == {} and summary["palette"] == []
    assert summary["confidence"] == 0 and summary["consistency"]["score"] is None
    assert "reference_no_usable_images" in summary["warnings"]
    json.dumps(summary, allow_nan=False)
