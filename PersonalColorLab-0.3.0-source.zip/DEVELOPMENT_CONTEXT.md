# Development Context

Project: Personal Color Lab
Current baseline: V0.3.0, three source routes with saved analysis profiles and offline Windows/macOS packaging
Platform scope: desktop; mobile development is not currently planned

## Product decisions

- Installed execution stays offline: no external AI/API, HTTP runtime client, login, telemetry, analytics or uploads.
- English is the default UI; Korean is selectable through locale resources.
- Original photo bytes remain unchanged and GPS coordinates are not persisted.
- Keep observed transforms, recorded XMP values and final-reference appearance distinct. Lightroom-like inferred estimates are not recovered sliders.
- Future output should favor non-destructive Lightroom-compatible XMP. Style application and export are not part of the implemented extraction milestone.
- Future My Style, references, built-in styles and hybrid blends should converge into common Style DNA. Current source profiles preserve mode-specific evidence rather than pretending these engines already exist.
- Future inference is local with mandatory CPU fallback. Composition changes require a user choice; never silently crop. Bundled styles must contain derived profiles rather than copied source images.

## Implemented workflow

**Choose folder** opens the extraction workflow. The user selects **RAW + JPG**, **RAW + XMP**, or **JPG references**, reviews candidate files, excludes unwanted entries and resolves missing/ambiguous companions manually. Discovery favors same-directory filename matches but does not treat them as verified edit relationships. The user analyzes selected files, sees progress and per-file failures, and can cancel between files while retaining completed results. Results include a collection summary and individual evidence. A named **Save style** snapshot is stored in SQLite and can be reopened through **Saved styles** across application restarts. Reopening a snapshot does not refresh source files or apply a look to a new image.

RAW + JPG uses `rawpy==0.25.1` / LibRaw 0.21.4 to decode actual sensor data into a fixed sRGB baseline with camera WB when available and no automatic brightness. It reuses similarity registration and registered tone/Lab/HSV/HSL analysis against the edited JPG. The baseline is explicitly not a reconstruction of Lightroom defaults or the original editing history. Decoder version/settings, fallback WB, hashes and limits are retained as provenance. Unsupported/corrupt RAW files fail without using an embedded preview; the decode limit is 120 megapixels.

RAW + XMP extracts supported global Adobe Camera Raw settings and RGB tone curves from the actual namespace with a whitelist, range checks and bounded XML parsing. DTD/entity declarations are rejected. Missing values remain unknown. Local masks, unsupported properties and custom profiles are flagged or omitted rather than rendered. XMP analysis hashes the supplied RAW but does not decode it. Recorded-value confidence does not verify the RAW/sidecar association or Adobe rendering equivalence.

JPG-only analysis measures final rendered appearance: brightness distributions, contrast/clipping, saturation, Lab/chroma, tonal-zone color, hue-band support and a representative palette. The collection uses equal-image-weighted medians, median absolute deviation and palette weights; exact byte duplicates contribute once. It reports heuristic consistency, low sample coverage and appearance outliers, leaving outliers included until the user excludes them. Semantic scene labels, scene diversity, near-duplicate clustering, original edit inference and recovered sliders are not claimed.

The existing **Compare two photos** JPEG workflow remains, including direct selection across names/folders, current-session deduplicated rows, original/edited previews, swap, reanalysis, plain-language summaries, measured tone curves and detailed measurements. Failed registration, unreadable ICC profiles and stale comparisons withhold unverifiable results and provide recovery guidance.

## Versions, persistence and display

App and analysis algorithm versions are 0.3.0. Analysis payload schema remains 1; the database migrates additively to schema 2 for named source profiles, preserving prior library rows and settings. Old algorithm comparison results remain stored and require reanalysis for a current result. Source profile snapshots retain their historical source hashes and are explicitly shown as saved analyses.

Runtime data defaults to `~/.personal_color_lab`; `PERSONAL_COLOR_LAB_DATA_DIR` supports an isolated local directory. Store only paths, allowed non-location metadata and derived finite JSON; never copy original libraries or persist raw XMP/EXIF/GPS data.

The shared dark graphite/lime UI retains the aperture icon, larger small/measurement fonts and secondary contrast from V0.2.2. `ui/display.py` sets Windows DPI awareness before Tk, respects an already-configured process, and scales the initial window's point fonts and layout. macOS uses the native `TkDefaultFont` family and Cocoa logical coordinates with existing high-resolution metadata/Tk Retina support. Do not force 2x coordinates or claim native Retina or monitor-transition testing. Repetitive offline/privacy labels stay removed; meaningful analysis warnings and provenance remain.

## Dependencies, validation and delivery

Python 3.11+, Tkinter, Pillow, NumPy, headless OpenCV and rawpy/LibRaw are the source-run dependencies. Runtime/development lockfiles pin tested versions; range files support deliberate updates. pytest is development-only. No GPU, mobile SDK or web server is needed.

The suite includes synthetic geometric/tone/color examples, RAW fixtures, XMP parsing, reference aggregation, file preservation, persistence/migrations and desktop routes. `VALIDATION.md` records final commands, counts and platform limits after completion. Use `tools/run_gui_tests.py` with a local Xvfb for headless GUI checks. The prepared cloud uses `.venv-desktop` (Python 3.13/Tk 8.6) for CJK rendering; do not infer native Windows/macOS readiness from Linux tests.

Installer tooling bundles private CPython 3.13.16/Tcl-Tk, pinned native analysis wheels including rawpy/LibRaw, translations and license notices. Windows x64 and macOS Apple Silicon/Intel do not require an existing Python installation. Native installed-artifact checks and manual CI are included; actual native OS/display checks, signing and notarization remain pending. Artifact-specific evidence belongs in `VALIDATION.md`. The user-authorized `forhide/Stone-Quotation` download branch is a delivery destination; the extracted source folder has no Git remote and its native installer CI has not run there.

## Next work

Prioritize real-camera RAW and sidecar datasets, varied reference-photo evaluation, pairing ambiguity and confidence calibration, plus native installer/display validation. Broader XMP rendering, near-duplicate handling, semantic scene coverage, reusable application-ready Style DNA, style transfer, built-in/hybrid styles and export remain separate future milestones. Do not regress the now-implemented RAW or JPG-only extraction into a future proposal.

After meaningful milestones, update this file, `CHANGELOG.md`, `TODO.md`, `ROADMAP.md`, relevant tests and `VALIDATION.md` before delivery. See `CODEX_HANDOFF.md` for interfaces.
