# Personal Color Lab 설치 안내

V0.3.0 개발용 설치 패키지입니다. **RAW + 편집 JPG / RAW + XMP / 완성 JPG만** 세 가지 방식으로 보정 근거와 색감 경향을 추출하고, 이름을 붙여 저장한 분석을 다시 열 수 있습니다. Python·Tcl/Tk·Pillow·NumPy·OpenCV·rawpy/LibRaw와 영어·한국어 번역을 포함하며 설치 후 오프라인으로 실행합니다. Python 설치나 pip 명령은 필요하지 않습니다. 새 사진에 스타일 적용, 강도 조절, XMP 내보내기는 아직 구현하지 않았습니다.

| 운영체제 | 대상 | 최소 버전 | 파일 |
| --- | --- | --- | --- |
| Windows | Intel/AMD 64비트 | Windows 10/11 | `PersonalColorLab-0.3.0-windows-x64-setup.exe` |
| macOS | Apple Silicon | macOS 13 | `PersonalColorLab-0.3.0-macos-arm64.pkg` |
| macOS | Intel | macOS 14 | `PersonalColorLab-0.3.0-macos-x64.pkg` |

각 파일의 `.sha256` 체크섬을 함께 제공합니다. macOS 최소 버전은 포함한 라이브러리 wheel의 지원 범위를 따릅니다. Windows ARM 에뮬레이션은 검증하지 않았습니다.

## 설치·업데이트·제거

Windows: setup 파일을 열어 설치하세요. 기본 위치는 `%LOCALAPPDATA%\Programs\PersonalColorLab`이며 관리자 권한을 요구하지 않습니다. 시작 메뉴의 **Personal Color Lab**으로 실행합니다. Windows 설치된 앱 목록이나 시작 메뉴의 **Uninstall**로 제거합니다. 설치 프로그램의 영어·한국어 선택은 앱 언어와 별개입니다. 앱은 처음 실행할 때 영어를 사용하며 한국어를 선택할 수 있습니다.

macOS: CPU에 맞는 `.pkg`를 열어 설치하세요. 관리자 인증 후 `/Applications/Personal Color Lab.app`을 설치하며 Python은 앱 내부에만 포함됩니다. Finder의 응용 프로그램 폴더에서 실행합니다. 제거할 때는 이 앱을 휴지통으로 이동하세요.

업데이트 전에 앱을 종료하고 새 설치 파일을 실행하세요. 기존 DB와 설정은 Windows `%USERPROFILE%\.personal_color_lab` 또는 macOS `~/.personal_color_lab`에 유지됩니다. `PERSONAL_COLOR_LAB_DATA_DIR` 설정도 지원합니다. 설치·업데이트·제거는 사용자 데이터와 사진 원본을 삭제하지 않습니다. Windows 제거 프로그램은 설치한 파일만 삭제하여 설치 폴더에 별도로 추가한 파일도 보존합니다.

V0.3.0의 앱·분석 알고리즘 버전은 0.3.0, DB 스키마는 2, 분석 결과 스키마는 1입니다. DB는 기존 기록과 설정을 보존하며 업그레이드합니다. 이전 알고리즘의 비교 결과는 보존하지만 현재 결과를 얻으려면 다시 분석해야 합니다. 저장한 스타일은 당시 분석의 스냅샷이며 다시 열 때 원본을 자동으로 재분석하지 않습니다.

Windows는 앱 창을 만들기 전에 DPI 처리를 설정하고 처음 열린 화면의 배율에 맞춰 글씨와 간격을 조절합니다. macOS는 시스템 글꼴과 번들 Tk의 기본 Retina 처리를 사용합니다. 실제 Windows·macOS 화면의 DPI·Retina 검증은 남아 있습니다. 글씨나 화면 배율이 높으면 더 넓은 작업 화면이 필요할 수 있습니다.

이 빌드는 코드 서명 및 Apple 공증을 하지 않았으므로 운영체제 확인 경고가 나타날 수 있습니다. 출처와 체크섬을 확인하세요. macOS에서 차단된다면 시스템 설정의 개인정보 보호 및 보안에 표시되는 해당 설치 파일의 **확인 없이 열기**로 진행할 수 있습니다. 정식 공개 배포 전에는 네이티브 검증과 서명·공증을 완료해야 합니다.

## 검증과 진단

완료한 Linux 소스·GUI·아카이브 테스트와 Windows Wine, macOS XAR·BOM·CPIO 검사 결과는 버전별로 `VALIDATION.md`에 기록합니다. 두 OS 실제 기기의 설치·GUI 검증과 서명·공증은 남아 있으며 네이티브 CI는 아직 실행하지 않았습니다. Wine이나 패키지 구조 검사는 실제 기기 검증을 대신하지 않습니다.

앱의 진단 모드는 합성 사진과 임시 DB로 번역·네이티브 라이브러리·Tcl·사진 분석을 검사하며 사용자 사진과 기존 DB는 사용하지 않습니다.

```powershell
& "$env:LOCALAPPDATA\Programs\PersonalColorLab\Personal Color Lab.exe" --self-test --self-test-report "$env:TEMP\pcl-check.json"
```

```bash
"/Applications/Personal Color Lab.app/Contents/MacOS/Personal Color Lab" \
  --self-test --self-test-report /tmp/pcl-check.json
```

## 폴더를 선택한 다음

1. **Choose folder**로 폴더를 선택하면 분석 창이 열립니다. **RAW + JPG / RAW + XMP / JPG references** 중 사용할 입력 방식을 확인하세요. JPG만 있는 폴더는 원본 없이 참고 사진의 색감 경향을 분석합니다.
2. **Review files**에서 필요 없는 파일을 제외하세요. RAW의 짝이 없거나 여러 후보가 있으면 **Choose matching file**로 직접 선택합니다. 파일 이름이 맞아도 같은 사진의 원본·편집본인지 확인하세요.
3. **Analyze selected files**를 누르세요. 진행 상황과 실패한 파일을 확인할 수 있습니다. **Cancel**을 누르면 현재 파일을 마친 뒤 중단하며 완료한 결과는 남습니다.
4. **Style summary**와 개별 결과를 확인하고 **Style name**을 입력한 뒤 **Save style**을 누르세요. 앱을 다시 실행한 후에도 **Saved styles**에서 열 수 있습니다.

RAW + JPG는 센서 RAW를 카메라 화이트밸런스·자동 밝기 보정 없는 고정 sRGB 기준으로 현상한 다음 편집 JPG와 비교합니다. Lightroom의 실제 슬라이더를 복원한 값은 아닙니다. 지원 카메라는 LibRaw에 따르며 손상되거나 지원하지 않는 RAW는 실패로 표시합니다.

RAW + XMP는 지원하는 전역 Camera Raw 설정과 RGB 톤 곡선을 읽습니다. 누락된 값은 알 수 없는 값으로 유지하고, 마스크·사용자 프로필·Adobe 현상 결과는 재현하지 않습니다. 선택한 XMP가 해당 RAW의 설정인지 직접 확인해야 합니다.

JPG만 분석하면 밝기·대비·채도·색상대·대표색과 공통 경향을 표시합니다. 동일한 바이트의 중복 파일은 한 번만 반영하고 각 사진에 같은 가중치를 줍니다. 일관성과 편차·표본 부족·특이한 사진도 살펴볼 수 있지만 장면 분류나 실제 보정 이력을 추정하지는 않습니다. 원본 촬영 조명과 피사체 색도 결과에 포함됩니다.

기존 **Compare two photos**는 원본 JPG와 편집 JPG를 직접 고르는 비교 방식으로 유지됩니다. 파일 이름·폴더가 달라도 되며 미리보기에서 방향을 확인하고 밝기 변환 곡선과 상세 측정값을 볼 수 있습니다. 앱 언어는 설정에서 한국어로 바꿀 수 있습니다.

## 다시 빌드하기

빌드 단계만 네트워크를 사용합니다. CPython 3.13.16은 Astral 공식 python-build-standalone `20261003` 릴리스에서 고정 SHA-256을 확인하여 받습니다. 전체 런타임 배포물의 네이티브 라이브러리 라이선스를 포함합니다. 분석 라이브러리는 `requirements.lock`과 PyPI SHA-256을 확인합니다. rawpy 0.25.1의 대상별 wheel에는 LibRaw 0.21.4를 포함하며 해당 라이선스도 함께 전달합니다. build 도구와 pip/ensurepip는 앱에 포함하지 않습니다.

```bash
python -m pip install -r requirements-build.lock
python tools/download_runtimes.py
python tools/download_wheels.py
python tools/build_installers.py --target windows-x64
python tools/build_installers.py --target macos-arm64
python tools/build_installers.py --target macos-x64
```

Windows 빌드는 NSIS 3.11 이상의 `makensis`가 필요합니다. macOS에서는 Apple `pkgbuild`·`productbuild`를 사용합니다. Linux에서 `.pkg`를 생성하려면 [bomutils](https://github.com/hogliux/bomutils)의 `mkbom`과 POSIX `cksum`이 필요하며 `--mkbom /path/to/mkbom`으로 지정합니다. 숨김 `.dylibs`도 BOM에 포함되도록 명시적 파일 목록을 전달합니다. 결과와 체크섬은 `dist/installers`에 생성됩니다. 준비된 리소스가 있으면 `build_installers.py`는 오프라인으로 실행할 수 있습니다.

실제 운영체제에서 빌드·설치·번들 진단·GUI·제거를 확인하는 `.github/workflows/installers.yml`을 포함했습니다. 프로젝트 저장소에 저장한 후 **Build and test desktop installers** 워크플로를 수동 실행하세요. 각 아키텍처에 맞는 러너를 사용하며 테스트 데이터만 사용합니다. 현재 ZIP에서 받은 소스 폴더는 별도 Git 원격 저장소에 연결하지 않았습니다. 사용자가 지정한 `forhide/Stone-Quotation`의 다운로드용 브랜치는 설치 파일 전달 용도이며 앱 소스·CI 저장소가 아닙니다.
