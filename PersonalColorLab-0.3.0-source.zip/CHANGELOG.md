# Changelog

## V0.3.0 - Three source routes and saved analysis styles

- Connected Choose folder to RAW + edited JPG, RAW + XMP and finished JPG reference workflows, including review, exclude, manual companion resolution, progress, per-file failures and cancellation between files.
- Added sensor RAW decoding through pinned rawpy 0.25.1 / LibRaw 0.21.4, with an explicit camera-WB sRGB baseline, no automatic brightness and safe decoder provenance. RAW/JPG comparison reuses registered tone/color inference and does not claim exact Lightroom recovery.
- Added bounded namespace-whitelisted Camera Raw XMP parsing for supported global settings and RGB curves. Missing settings remain unknown; unsupported/local-mask/custom-profile behavior and unverified rendering/association stay explicit.
- Added JPG-only final-appearance measurements for luminance, contrast, saturation, Lab/chroma, tonal zones, hue bands and representative colors without requiring an original.
- Added equal-image-weighted reference aggregation, exact-byte duplicate exclusion, dispersion, heuristic consistency, sample-coverage limits and flagged appearance outliers. Scene labels and original edit history are not inferred.
- Added collection and individual result views, named saved analysis snapshots and reopening after restart. Saving does not yet apply a style to another image or export XMP.
- Added additive database schema 2 while preserving prior rows/settings; app and algorithm versions are 0.3.0 and payload schema remains 1. Earlier algorithm comparisons require reanalysis for current results.
- Retained direct JPEG comparison, English/Korean resources, readable DPI-aware UI, offline execution and original/GPS safeguards; extended installer dependency inputs to include rawpy/LibRaw.
- Final completed tests and installer verification are recorded in `VALIDATION.md`. Native OS/display validation, signing and notarization remain pending.

## V0.2.2 - Readability and display scaling

- Increased small text from 9 to 10 points and measurement text from 10 to 11 points; strengthened secondary text contrast.
- Configured Windows DPI awareness before creating Tk windows, with supported fallbacks and respect for an already-configured process. Initial-window DPI sets native point-sized fonts and scaled layout spacing.
- Preserved macOS high-resolution app metadata and bundled Tk 9 Retina rendering; use the native `TkDefaultFont` system family without forcing double-sized Cocoa coordinates.
- Removed repetitive Offline Only, sidebar privacy, and inspector original-file notices from the interface. Offline execution, file preservation, analysis warnings, and provenance remain unchanged.
- Updated app/installer version to 0.2.2 while retaining analysis algorithm 0.2.0 and payload/database schema 1.
- Completed validation is recorded in `VALIDATION.md`. Actual Windows/macOS DPI/Retina behavior, native CI, signing, and notarization remain unverified; large text/display scaling can require a larger desktop viewport.

## V0.2.1 - Desktop interface and guided comparison

- Replaced the default widget presentation with a shared dark graphite/lime desktop theme, clearer spacing, compact layouts, and consistent controls.
- Added **Compare two photos**: choose an original JPEG and its edited version directly, without requiring matching filenames, a shared folder, or a library scan.
- Added three-step guidance, useful empty states, clear original/edited preview labels, and double-click/Enter shortcuts for scanned JPEG candidates.
- Kept directly chosen pairs in the current session's table with a **Chosen by you** label, allowing saved comparisons to reopen without another file selection and avoiding duplicate rows.
- Added a bundled aperture icon for app windows, Windows executables/setup, and the macOS app.
- Made plain-language brightness, color-tendency, and shared-area cards the default result view. Added a measured tone-transfer curve with an identity reference line; detailed measurements remain available in a separate tab.
- Added localized recovery guidance for failed alignment, unreadable color profiles/files, and stale saved results. Unverified tone/color measurements and curves remain withheld.
- Updated English and Korean resources without adding runtime dependencies or network access.
- Versioned the desktop app and Windows/macOS installers as 0.2.1 while retaining analysis algorithm 0.2.0 and payload/database schema 1. Existing user data and compatible analyses are preserved.
- Installer build and validation evidence is recorded in `VALIDATION.md`; native Windows/macOS hardware validation, CI execution, signing, and notarization remain pending.

## V0.2.0 - Offline installation milestone

- Added Windows x64 per-user setup.exe, a windowless launcher, Start Menu/app-list integration and an owned-file uninstaller preserving user data and unrelated files.
- Added separate macOS Apple Silicon/Intel .pkg with private .app runtimes, OS/architecture requirements and native Apple or cross-host XAR/BOM/CPIO build tools.
- Bundled verified CPython 3.13.16/Tcl-Tk, Pillow 12.3.0, NumPy 2.3.5, OpenCV 4.14.0.94, locale resources and license notices. Build-time pip/ensurepip/downloader tools are excluded.
- Added cwd-independent locale loading and offline --self-test using synthetic JPGs and temporary SQLite data.
- Added native installed-app GUI checks and a manually triggered three-platform CI workflow; native CI execution remains pending.
- Expanded Linux source/GUI/archive checks to 144 passing tests. Native signing/notarization remains pending; see VALIDATION.md and INSTALLERS.md for artifact-specific evidence.

## V0.2.0 - Selected JPG pair analysis

- Added CPU-only local JPG registration for modest crop, resize, and rotation, with EXIF orientation and local ICC handling.
- Added overlap/registration confidence and explicit alignment failure without fabricated tone/color estimates.
- Added `color_space_uncertain` handling for unreadable embedded ICC profiles, retaining geometry while withholding tone/color and approximate estimates.
- Added observed tone transfer, luminance-zone deltas, contrast/clipping summaries, Lab deltas, HSV/HSL and hue-band summaries.
- Added approximate exposure EV and WB/tint tendencies with separate confidence and limitations; no exact Lightroom slider recovery is claimed.
- Added inferred provenance, versioned payloads, source SHA-256 hashes, and rejection of changing analysis inputs.
- Scoped overall confidence to registered tone/color evidence; exposure and WB/tint estimates retain separate confidence.
- Added an additive SQLite version-1 migration, preserving V0.1 rows, plus validated versioned analysis save/load.
- Added a localized desktop pair inspector with previews, direction swapping, reanalysis, saved-result loading, and source-hash cache invalidation.
- Added a writable data-directory override through `PERSONAL_COLOR_LAB_DATA_DIR`.
- Added pinned runtime/development dependency files and a local-Xvfb desktop test runner.
- Added synthetic analysis and integration checks; 119 tests pass on Linux/Python 3.12 and 3.13, including seven actual desktop flows. See `VALIDATION.md`.
- Fixed closed-window worker ownership and Tk cleanup, plus malformed nested-cache recovery.
- Preserved the offline runtime, original photo files, and GPS exclusion. RAW decoding, full XMP handling, and style application remain deferred.

## V0.1

- Added recursive dataset scanning and RAW/JPG/image/XMP classification.
- Added filename-based RAW+XMP and RAW+JPG candidates and original/edited-JPG candidates with naming/perceptual information.
- Added pair confidence values and local SQLite persistence.
- Added English default UI and Korean selectable UI.
- Established the offline runtime contract and excluded GPS persistence.
