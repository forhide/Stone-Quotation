"""Native text rendering and logical spacing for desktop display densities."""

import ctypes
import math
import sys


def _load_windows_dll(name):
    return ctypes.WinDLL(name, use_last_error=True)


def _last_error():
    return ctypes.get_last_error()


def initialize_display():
    """Enable Windows DPI awareness before any Tk window is constructed.

    The NSIS launcher starts another Python process, whose DPI awareness must
    be configured independently. Respect an embedding host's existing mode.
    Cocoa/Tk already handles Retina backing pixels using logical coordinates.
    """
    if sys.platform != 'win32':
        return 'native'
    try:
        user32 = _load_windows_dll('user32')
    except (AttributeError, OSError):
        return 'unavailable'
    try:
        set_context = user32.SetProcessDpiAwarenessContext
        set_context.argtypes = [ctypes.c_void_p]
        set_context.restype = ctypes.c_bool
        if set_context(ctypes.c_void_p(-4)):
            return 'per_monitor_v2'
        if _last_error() == 5:
            return 'already_configured'
    except (AttributeError, OSError):
        pass
    try:
        shcore = _load_windows_dll('shcore')
        set_awareness = shcore.SetProcessDpiAwareness
        set_awareness.argtypes = [ctypes.c_int]
        set_awareness.restype = ctypes.c_long
        result = int(set_awareness(2)) & 0xFFFFFFFF
        if result == 0:
            return 'per_monitor'
        if result == 0x80070005:
            return 'already_configured'
    except (AttributeError, OSError):
        pass
    try:
        set_aware = user32.SetProcessDPIAware
        set_aware.argtypes = []
        set_aware.restype = ctypes.c_bool
        if set_aware():
            return 'system'
        if _last_error() == 5:
            return 'already_configured'
    except (AttributeError, OSError):
        pass
    return 'unavailable'


def _window_dpi(widget):
    try:
        user32 = _load_windows_dll('user32')
        get_dpi = user32.GetDpiForWindow
        get_dpi.argtypes = [ctypes.c_void_p]
        get_dpi.restype = ctypes.c_uint
        return get_dpi(widget.winfo_id())
    except (AttributeError, OSError):
        return None


def configure_window_scale(widget):
    """Use the initial Windows window's DPI for point-sized native fonts."""
    if sys.platform == 'win32':
        dpi = _window_dpi(widget)
        if isinstance(dpi, (int, float)) and math.isfinite(dpi) and 72 <= dpi <= 384:
            widget.tk.call('tk', 'scaling', dpi / 72.0)


def ui_scale(widget):
    """Physical pixels per 96-DPI layout unit; Aqua uses logical units."""
    if sys.platform == 'darwin':
        return 1.0
    dpi = float(widget.winfo_fpixels('1i'))
    if not math.isfinite(dpi) or dpi <= 0:
        return 1.0
    return max(0.75, min(4.0, dpi / 96.0))


def ui_pixels(widget, value):
    return int(round(value * ui_scale(widget)))
