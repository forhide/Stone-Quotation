from pathlib import Path
from collections import defaultdict
from .constants import RAW_EXTENSIONS, JPEG_EXTENSIONS, IMAGE_EXTENSIONS, XMP_EXTENSIONS, SUPPORTED_EXTENSIONS
from .models import PhotoRecord, PairCandidate, ScanSummary
from .metadata import image_metadata
from .fingerprint import hamming_hex

EDIT_SUFFIXES = ('_edit', '_edited', '_final', '-edit', '-edited', '-final', '_lr', '-lr', '_retouch', '-retouch')
ORIGINAL_SUFFIXES = ('_original', '-original', '_orig', '-orig')


def normalized_stem(path: Path) -> str:
    s = path.stem.lower().strip()
    for suffix in EDIT_SUFFIXES + ORIGINAL_SUFFIXES:
        if s.endswith(suffix):
            s = s[:-len(suffix)]
            break
    return s.replace(' ', '').replace('_', '').replace('-', '')


def classify(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in RAW_EXTENSIONS:
        return 'raw'
    if ext in JPEG_EXTENSIONS:
        return 'jpg'
    if ext in XMP_EXTENSIONS:
        return 'xmp'
    if ext in IMAGE_EXTENSIONS:
        return 'image'
    return 'other'


def scan_folder(folder: Path, recursive: bool = True, progress=None) -> list[PhotoRecord]:
    iterator = folder.rglob('*') if recursive else folder.glob('*')
    paths = [p for p in iterator if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS]
    records: list[PhotoRecord] = []
    total = max(1, len(paths))
    for i, path in enumerate(paths, start=1):
        kind = classify(path)
        meta = {}
        if kind in {'jpg', 'image'}:
            meta = image_metadata(path)
        rec = PhotoRecord(
            path=path,
            ext=path.suffix.lower(),
            kind=kind,
            size_bytes=path.stat().st_size,
            width=meta.get('width'),
            height=meta.get('height'),
            capture_time=meta.get('capture_time'),
            camera=meta.get('camera'),
            lens=meta.get('lens'),
            fingerprint=meta.get('fingerprint'),
        )
        records.append(rec)
        if progress:
            progress(i, total, path.name)
    return records


def _name_score(a: Path, b: Path) -> float:
    na, nb = normalized_stem(a), normalized_stem(b)
    if na == nb and na:
        return 0.72
    if na and nb and (na in nb or nb in na):
        return 0.55
    # lightweight character overlap ratio
    sa, sb = set(na), set(nb)
    if not sa or not sb:
        return 0.0
    j = len(sa & sb) / len(sa | sb)
    return min(0.4, j * 0.4)


def _image_similarity_score(a: PhotoRecord, b: PhotoRecord) -> float:
    score = 0.0
    if a.width and a.height and b.width and b.height:
        ra = a.width / max(1, a.height)
        rb = b.width / max(1, b.height)
        rel = abs(ra - rb) / max(ra, rb)
        if rel < 0.01:
            score += 0.08
        elif rel < 0.08:
            score += 0.04
    hd = hamming_hex(a.fingerprint, b.fingerprint)
    if hd is not None:
        # 256-bit dHash. Heavy edits/crops can move this substantially.
        sim = max(0.0, 1.0 - hd / 256.0)
        score += min(0.32, max(0.0, (sim - 0.55) * 0.72))
    if a.capture_time and b.capture_time and a.capture_time == b.capture_time:
        score += 0.12
    return score


def find_pairs(records: list[PhotoRecord]) -> list[PairCandidate]:
    raws = [r for r in records if r.kind == 'raw']
    xmps = [r for r in records if r.kind == 'xmp']
    jpgs = [r for r in records if r.kind == 'jpg']
    pairs: list[PairCandidate] = []
    used = set()

    xmp_by_stem = defaultdict(list)
    for x in xmps:
        xmp_by_stem[normalized_stem(x.path)].append(x)
    for r in raws:
        xs = xmp_by_stem.get(normalized_stem(r.path), [])
        if xs:
            pairs.append(PairCandidate(r.path, xs[0].path, 'RAW+XMP', 1.0, ['matching base filename']))
            used.add(xs[0].path)

    # RAW + JPG: primarily filename-based in V0.1 because RAW decode is intentionally not required.
    for r in raws:
        best = None
        for j in jpgs:
            s = _name_score(r.path, j.path)
            if s < 0.5:
                continue
            if best is None or s > best[0]:
                best = (s, j)
        if best:
            s, j = best
            pairs.append(PairCandidate(r.path, j.path, 'RAW+JPG', min(0.94, s + 0.18), ['filename relationship']))
            used.add(j.path)

    # JPG original/edited candidate pairs. Compare only reasonably related names to avoid O(n^2) blow-up.
    buckets = defaultdict(list)
    for j in jpgs:
        buckets[normalized_stem(j.path)].append(j)
    for _, group in buckets.items():
        if len(group) < 2:
            continue
        for i in range(len(group)):
            for k in range(i + 1, len(group)):
                a, b = group[i], group[k]
                score = _name_score(a.path, b.path) + _image_similarity_score(a, b)
                if score >= 0.62:
                    # Prefer the file explicitly marked original as first.
                    a_edit = any(a.path.stem.lower().endswith(s) for s in EDIT_SUFFIXES)
                    b_edit = any(b.path.stem.lower().endswith(s) for s in EDIT_SUFFIXES)
                    if a_edit and not b_edit:
                        original, edited = b, a
                    elif b_edit and not a_edit:
                        original, edited = a, b
                    else:
                        original, edited = (a, b) if a.size_bytes >= b.size_bytes else (b, a)
                    pairs.append(PairCandidate(original.path, edited.path, 'JPG+JPG', min(0.98, score), ['name similarity', 'visual similarity']))
                    used.add(original.path)
                    used.add(edited.path)

    # Deduplicate exact pair/type tuples.
    dedup = {}
    for p in pairs:
        key = (str(p.original), str(p.edited), p.pair_type)
        if key not in dedup or p.confidence > dedup[key].confidence:
            dedup[key] = p
    return sorted(dedup.values(), key=lambda p: (-p.confidence, p.pair_type, str(p.original)))


def summarize(records: list[PhotoRecord], pairs: list[PairCandidate]) -> ScanSummary:
    s = ScanSummary(total_files=len(records))
    s.raw = sum(r.kind == 'raw' for r in records)
    s.jpg = sum(r.kind == 'jpg' for r in records)
    s.other_images = sum(r.kind == 'image' for r in records)
    s.xmp = sum(r.kind == 'xmp' for r in records)
    s.raw_xmp_pairs = sum(p.pair_type == 'RAW+XMP' for p in pairs)
    s.raw_jpg_pairs = sum(p.pair_type == 'RAW+JPG' for p in pairs)
    s.jpg_jpg_pairs = sum(p.pair_type == 'JPG+JPG' for p in pairs)
    s.possible_pairs = len(pairs)
    paired_jpg = {p.edited for p in pairs if p.edited.suffix.lower() in JPEG_EXTENSIONS} | {p.original for p in pairs if p.original.suffix.lower() in JPEG_EXTENSIONS}
    s.edited_only = max(0, s.jpg - len(paired_jpg))
    return s
