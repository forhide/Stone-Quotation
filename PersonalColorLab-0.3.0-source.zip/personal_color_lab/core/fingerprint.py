from pathlib import Path
from PIL import Image, ImageOps


def dhash(path: Path, hash_size: int = 16) -> str | None:
    try:
        with Image.open(path) as im:
            im = ImageOps.exif_transpose(im).convert('L').resize((hash_size + 1, hash_size))
            px = list(im.getdata())
        bits = []
        row = hash_size + 1
        for y in range(hash_size):
            base = y * row
            for x in range(hash_size):
                bits.append(1 if px[base + x] > px[base + x + 1] else 0)
        value = 0
        for b in bits:
            value = (value << 1) | b
        return f'{value:0{hash_size * hash_size // 4}x}'
    except Exception:
        return None


def hamming_hex(a: str | None, b: str | None) -> int | None:
    if not a or not b or len(a) != len(b):
        return None
    try:
        return (int(a, 16) ^ int(b, 16)).bit_count()
    except Exception:
        return None
