"""Read recorded Camera Raw settings without rendering or changing a photo.

Only whitelisted global Camera Raw properties are retained. In particular,
EXIF/GPS, creator information, free-text profile names and local-mask contents
never enter the result. Recorded settings describe the sidecar, not proof that
the sidecar belongs to a RAW file or that another renderer reproduces Adobe.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

from .constants import RAW_EXTENSIONS

ALGORITHM_VERSION = "0.3.0"
ANALYSIS_SCHEMA_VERSION = 1
MAX_XMP_BYTES = 8 * 1024 * 1024
MAX_XML_ELEMENTS = 50_000
MAX_XML_DEPTH = 64
CAMERA_RAW_NAMESPACE = "http://ns.adobe.com/camera-raw-settings/1.0/"
RDF_NAMESPACE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
_CRS = "{" + CAMERA_RAW_NAMESPACE + "}"
_RDF = "{" + RDF_NAMESPACE + "}"

# All ranges are the recorded Adobe controls, not inferred pixel measurements.
# Numeric specifications are (minimum, maximum, require_integer, unit).
_NUMERIC: dict[str, tuple[float, float, bool, str]] = {
    "Exposure": (-5, 5, False, "ev"),
    "Exposure2012": (-5, 5, False, "ev"),
    "Temperature": (2000, 50000, True, "kelvin"),
    "Tint": (-150, 150, False, "slider_points"),
    "Brightness": (0, 150, True, "slider_points"),
    "FillLight": (0, 100, True, "slider_points"),
    "HighlightRecovery": (0, 100, True, "slider_points"),
    "Shadows": (0, 100, True, "slider_points"),
    "Sharpness": (0, 150, True, "slider_points"),
    "SharpenRadius": (0.5, 3, False, "pixels"),
    "CropAngle": (-180, 180, False, "degrees"),
    "CropWidth": (0.000001, 1_000_000, False, "crop_units"),
    "CropHeight": (0.000001, 1_000_000, False, "crop_units"),
    "CropUnits": (0, 3, True, "adobe_crop_unit_code"),
}
for _name in (
    "Contrast", "Contrast2012", "Highlights2012", "Shadows2012",
    "Whites2012", "Blacks2012", "Texture", "Clarity", "Clarity2012",
    "Dehaze", "Vibrance", "Saturation", "SplitToningBalance", "ShadowTint",
    "RedHue", "RedSaturation", "GreenHue", "GreenSaturation",
    "BlueHue", "BlueSaturation", "ParametricShadows", "ParametricDarks",
    "ParametricLights", "ParametricHighlights",
):
    _NUMERIC[_name] = (-100, 100, True, "slider_points")
for _name in (
    "SharpenDetail", "SharpenEdgeMasking", "LuminanceSmoothing",
    "LuminanceNoiseReductionDetail", "LuminanceNoiseReductionContrast",
    "ColorNoiseReduction", "ColorNoiseReductionDetail",
    "ColorNoiseReductionSmoothness", "GrainAmount", "GrainSize",
    "GrainFrequency", "ParametricShadowSplit", "ParametricMidtoneSplit",
    "ParametricHighlightSplit", "ColorGradeBlending",
):
    _NUMERIC[_name] = (0, 100, True, "slider_points")
for _band in ("Red", "Orange", "Yellow", "Green", "Aqua", "Blue", "Purple", "Magenta"):
    for _adjustment in ("HueAdjustment", "SaturationAdjustment", "LuminanceAdjustment", "GrayMixer"):
        _NUMERIC[_adjustment + _band] = (-100, 100, True, "slider_points")
for _zone in ("Shadow", "Highlight"):
    _NUMERIC[f"SplitToning{_zone}Hue"] = (0, 360, False, "degrees")
    _NUMERIC[f"SplitToning{_zone}Saturation"] = (0, 100, True, "slider_points")
for _zone in ("Shadow", "Midtone", "Highlight", "Global"):
    _NUMERIC[f"ColorGrade{_zone}Hue"] = (0, 360, False, "degrees")
    _NUMERIC[f"ColorGrade{_zone}Sat"] = (0, 100, True, "slider_points")
    _NUMERIC[f"ColorGrade{_zone}Lum"] = (-100, 100, True, "slider_points")
for _edge in ("Top", "Left", "Bottom", "Right"):
    _NUMERIC["Crop" + _edge] = (0, 1, False, "normalized_coordinate")

_BOOLS = {"HasCrop", "CropConstrainToWarp", "ConvertToGrayscale"}
_ENUMS = {
    "WhiteBalance": {
        "As Shot", "Auto", "Daylight", "Cloudy", "Shade", "Tungsten",
        "Fluorescent", "Flash", "Custom",
    },
    "ToneCurveName": {"Linear", "Medium Contrast", "Strong Contrast", "Custom"},
    "ToneCurveName2012": {"Linear", "Medium Contrast", "Strong Contrast", "Custom"},
}
_CURVES = {
    "ToneCurve", "ToneCurveRed", "ToneCurveGreen", "ToneCurveBlue",
    "ToneCurvePV2012", "ToneCurvePV2012Red", "ToneCurvePV2012Green", "ToneCurvePV2012Blue",
}
_SAFE_PROFILES = {
    "Adobe Standard", "Adobe Color", "Adobe Monochrome", "Adobe Landscape",
    "Adobe Neutral", "Adobe Portrait", "Adobe Vivid", "Camera Standard",
    "Camera Neutral", "Camera Faithful", "Camera Portrait", "Camera Landscape",
    "Camera Monochrome", "Camera Vivid", "Camera Flat",
}
_METADATA = {"ProcessVersion", "Version", "CameraProfile", "HasSettings"}
_WHITELIST = set(_NUMERIC) | _BOOLS | set(_ENUMS) | _CURVES | _METADATA
_LOCAL_PREFIXES = (
    "Mask", "Correction", "GradientBased", "CircularGradient", "PaintBased",
    "Retouch", "Spot", "Local", "Dabs",
)
_PROFILE_PREFIXES = ("Look", "Profile", "CameraProfile")
_NUMBER = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?\Z", re.ASCII)
_VERSION = re.compile(r"\d{1,3}(?:\.\d{1,3}){0,3}\Z", re.ASCII)


def file_fingerprint(path: Path) -> str:
    """Hash local bytes without decoding or retaining source metadata."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _input_path(path: Path, extensions: set[str], kind: str) -> Path:
    resolved = Path(path).expanduser().resolve(strict=True)
    if not resolved.is_file() or resolved.suffix.lower() not in extensions:
        raise ValueError(f"Expected a supported {kind} file.")
    return resolved


def _parse_xml(data: bytes) -> ET.Element:
    if len(data) > MAX_XMP_BYTES:
        raise ValueError("XMP file exceeds the supported size limit.")
    # UTF-16/32 ASCII markup is separated by NUL bytes. Removing NULs only
    # for this guard covers both byte orders, without decoding user content.
    # Expat/ElementTree performs no external entity lookup; reject every DTD
    # and entity declaration as well, including harmless internal DTDs.
    if re.search(br"<!\s*(?:DOCTYPE|ENTITY)\b", data.replace(b"\x00", b""), re.IGNORECASE):
        raise ValueError("XMP DTD and entity declarations are not supported.")
    try:
        root = ET.fromstring(data)
    except (ET.ParseError, ValueError, LookupError) as exc:
        raise ValueError("XMP is not well-formed supported XML.") from exc
    pending = [(root, 1)]
    count = 0
    while pending:
        node, depth = pending.pop()
        count += 1
        if count > MAX_XML_ELEMENTS or depth > MAX_XML_DEPTH:
            raise ValueError("XMP XML structure exceeds the supported size limit.")
        pending.extend((child, depth + 1) for child in node)
    return root


def _descriptions(root: ET.Element) -> list[ET.Element]:
    """Find top-level descriptions, never treating a mask's fields as global."""
    if root.tag == _RDF + "Description":
        return [root]
    result = []
    pending = [root]
    while pending:
        node = pending.pop()
        if node.tag == _RDF + "RDF":
            result.extend(child for child in node if child.tag == _RDF + "Description")
        else:
            pending.extend(reversed(list(node)))
    return result


def _numeric(name: str, text: str) -> int | float:
    if len(text) > 80 or not _NUMBER.fullmatch(text):
        raise ValueError("Invalid numeric value")
    value = float(text)
    minimum, maximum, integer, _ = _NUMERIC[name]
    if not math.isfinite(value) or not minimum <= value <= maximum or (integer and not value.is_integer()):
        raise ValueError("Numeric value outside the supported range")
    return int(value) if integer else value


def _boolean(text: str) -> bool:
    if text.lower() in {"true", "1"}:
        return True
    if text.lower() in {"false", "0"}:
        return False
    raise ValueError("Invalid boolean value")


def _curve(value: str | ET.Element) -> list[list[int]]:
    if isinstance(value, str):
        entries = value.split(";")
    else:
        sequence = list(value)
        if len(sequence) != 1 or sequence[0].tag != _RDF + "Seq":
            raise ValueError("Tone curve must contain an RDF sequence")
        items = list(sequence[0])
        if any(item.tag != _RDF + "li" or len(item) for item in items):
            raise ValueError("Invalid tone curve point")
        entries = [item.text or "" for item in items]
    if not 2 <= len(entries) <= 256:
        raise ValueError("Invalid tone curve point count")
    points = []
    for entry in entries:
        parts = entry.strip().split(",")
        if len(parts) != 2 or any(not re.fullmatch(r"\s*\d{1,3}\s*", part, re.ASCII) for part in parts):
            raise ValueError("Invalid tone curve point")
        point = [int(part) for part in parts]
        if any(component > 255 for component in point) or (points and point[0] <= points[-1][0]):
            raise ValueError("Tone curve points must have increasing inputs in 0..255")
        points.append(point)
    return points


def _scalar(value: str | ET.Element) -> str:
    if isinstance(value, str):
        return value.strip()
    if len(value):
        raise ValueError("Expected a scalar Camera Raw property")
    return (value.text or "").strip()


def _read_settings(root: ET.Element) -> tuple[dict, dict, dict, list[str], list[str]]:
    parameters: dict = {}
    curves: dict = {}
    metadata: dict = {}
    warnings: list[str] = []
    invalid: list[str] = []
    conflicts: set[str] = set()

    def accept(name: str, value: str | ET.Element) -> None:
        if name not in _WHITELIST:
            if name.startswith(_LOCAL_PREFIXES):
                warnings.append("xmp_local_adjustments_not_extracted")
            elif name.startswith(_PROFILE_PREFIXES):
                warnings.append("xmp_custom_profile_not_rendered")
            else:
                warnings.append("xmp_unsupported_settings_ignored")
            return
        if name in conflicts:
            return
        target = curves if name in _CURVES else metadata if name in _METADATA else parameters
        try:
            if name in _CURVES:
                parsed = _curve(value)
            else:
                text = _scalar(value)
                if name in _NUMERIC:
                    parsed = _numeric(name, text)
                elif name in _BOOLS or name == "HasSettings":
                    parsed = _boolean(text)
                elif name in _ENUMS:
                    if text not in _ENUMS[name]:
                        raise ValueError("Unsupported property enum")
                    parsed = text
                elif name in {"ProcessVersion", "Version"}:
                    if not _VERSION.fullmatch(text):
                        raise ValueError("Invalid process/software version")
                    parsed = text
                else:  # CameraProfile: do not retain arbitrary user-supplied names.
                    if text not in _SAFE_PROFILES:
                        warnings.append("xmp_custom_profile_not_rendered")
                        metadata["custom_profile_present"] = True
                        return
                    parsed = text
            if name in target and target[name] != parsed:
                target.pop(name)
                conflicts.add(name)
                invalid.append(name)
                warnings.append("xmp_conflicting_settings_ignored")
            else:
                target[name] = parsed
        except (ValueError, OverflowError):
            invalid.append(name)
            warnings.append("xmp_invalid_values_ignored")

    for description in _descriptions(root):
        for qualified, value in description.attrib.items():
            if qualified.startswith(_CRS):
                accept(qualified[len(_CRS):], value)
        for child in description:
            if child.tag.startswith(_CRS):
                accept(child.tag[len(_CRS):], child)

    # A flipped crop is ambiguous metadata, not a meaningful valid crop box.
    for start, end in (("CropTop", "CropBottom"), ("CropLeft", "CropRight")):
        if start in parameters and end in parameters and parameters[start] >= parameters[end]:
            for name in (start, end):
                parameters.pop(name)
                invalid.append(name)
            warnings.append("xmp_invalid_values_ignored")
    return parameters, curves, metadata, list(dict.fromkeys(warnings)), sorted(set(invalid))


def analyze_raw_xmp(raw_path: Path, xmp_path: Path) -> dict:
    """Return recorded global XMP parameters; no RAW decoder is required.

    The caller establishes the RAW/sidecar association. Input identity is
    verified by SHA-256 before/after analysis; original files are read only.
    Partial sidecars keep valid supported values and list warning codes.
    Malformed XML, unsafe declarations, unreadable or changing files raise.
    """
    original = _input_path(raw_path, RAW_EXTENSIONS, "RAW")
    edited = _input_path(xmp_path, {".xmp"}, "XMP")
    if edited.stat().st_size > MAX_XMP_BYTES:
        raise ValueError("XMP file exceeds the supported size limit.")
    before = {"original": file_fingerprint(original), "edited": file_fingerprint(edited)}
    with edited.open("rb") as sidecar:
        data = sidecar.read(MAX_XMP_BYTES + 1)
    # Ensure the exact bytes parsed are the bytes whose identity is reported.
    if hashlib.sha256(data).hexdigest() != before["edited"]:
        raise ValueError("Input file changed during analysis; retry with stable files.")
    parameters, curves, metadata, warnings, invalid = _read_settings(_parse_xml(data))
    after = {"original": file_fingerprint(original), "edited": file_fingerprint(edited)}
    if after != before:
        raise ValueError("Input file changed during analysis; retry with stable files.")
    available = bool(parameters or curves)
    payload = {
        "schema_version": ANALYSIS_SCHEMA_VERSION,
        "algorithm_version": ALGORITHM_VERSION,
        "source_type": "raw_xmp",
        "status": "ok" if available else "no_supported_settings",
        "original_path": str(original),
        "edited_path": str(edited),
        "source_paths": {"raw": str(original), "xmp": str(edited)},
        "analyzed_at_utc": datetime.now(timezone.utc).isoformat(),
        "parameters": parameters,
        "parameter_units": {
            name: _NUMERIC[name][3] if name in _NUMERIC else "boolean" if name in _BOOLS else "enum"
            for name in parameters
        },
        "tone_curves": curves,
        "tone_curve_units": {"input": "encoded_value_0_255", "output": "encoded_value_0_255"},
        "metadata": metadata,
        "invalid_parameters": invalid,
        "confidence": 1.0 if available else 0.0,
        "confidence_scope": "recorded_xmp_parameters",
        "provenance": {
            "inferred": False,
            "input_fingerprints": before,
            "originals_modified": False,
            "evidence": "recorded_global_camera_raw_parameters",
            "exact_xmp_parameters": True,
            "source_identity_verified": True,
            "raw_decoded": False,
            "sidecar_association": "caller_selected_not_content_verified",
            "render_equivalence_verified": False,
        },
        "warnings": list(dict.fromkeys([
            "xmp_recorded_parameters_only", "xmp_render_equivalence_unverified",
            "xmp_sidecar_association_unverified", *warnings,
            *([] if available else ["xmp_no_supported_settings"]),
        ])),
    }
    json.dumps(payload, allow_nan=False)
    return payload
