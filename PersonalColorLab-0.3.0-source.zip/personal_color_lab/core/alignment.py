"""Conservative, local registration of an original and edited photograph.

Registration observes image structure, not absolute colour values.  The result
must be checked before its pixels are used for reverse analysis: a failed
registration deliberately has an empty overlap mask.  No input is modified.
"""

from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from math import atan2, degrees, sqrt
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from PIL import Image, ImageCms, ImageOps

from .constants import RAW_EXTENSIONS
from .raw_decode import decode_raw


@dataclass
class AlignmentResult:
    original_aligned: np.ndarray
    edited: np.ndarray
    mask: np.ndarray
    metadata: dict[str, Any]


def _resize_matrix(width: int, height: int, new_width: int, new_height: int) -> np.ndarray:
    # Image resampling maps pixel centres, rather than pixel corners.
    sx, sy = new_width / width, new_height / height
    return np.array([[sx, 0, (sx - 1) / 2], [0, sy, (sy - 1) / 2], [0, 0, 1]], dtype=np.float64)


def _read_rgb(path: Path, max_dimension: int, decode_metadata: dict[str, Any] | None = None) -> tuple[np.ndarray, tuple[int, int], list[str]]:
    if path.suffix.lower() in RAW_EXTENSIONS:
        rgb, original_size, metadata = decode_raw(path, max_dimension)
        if decode_metadata is not None:
            decode_metadata.update(metadata)
        return rgb, original_size, list(metadata["warnings"])
    warnings: list[str] = []
    try:
        with Image.open(path) as opened:
            original_size = opened.size
            if opened.getexif().get(274) in (5, 6, 7, 8):
                original_size = (original_size[1], original_size[0])
            # JPEG decoder subsampling avoids holding a full multi-megapixel
            # RGB image when only a bounded analysis preview is required.
            if opened.format in ("JPEG", "MPO"):
                opened.draft("RGB", (max_dimension, max_dimension))
            image = ImageOps.exif_transpose(opened)
            # Restrict all feature detection and downstream arrays to this size.
            image.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
            profile = image.info.get("icc_profile")
            if profile:
                try:
                    image = ImageCms.profileToProfile(
                        image,
                        ImageCms.ImageCmsProfile(BytesIO(profile)),
                        ImageCms.createProfile("sRGB"),
                        outputMode="RGB",
                    )
                except (OSError, ValueError, ImageCms.PyCMSError):
                    warnings.append("icc_conversion_failed")
            rgb = np.array(image.convert("RGB"), dtype=np.uint8)
    except (OSError, ValueError, Image.DecompressionBombError) as exc:
        raise ValueError(f"Cannot read image: {path}") from exc
    return rgb, original_size, warnings


def _gray(image: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)


def _structure(image: np.ndarray) -> np.ndarray:
    gray = _gray(image).astype(np.float32) / 255.0
    return cv2.GaussianBlur(gray, (0, 0), 1.0)


def _texture(gray: np.ndarray) -> float:
    # Smooth gradients and flat colour are ambiguous registration evidence.
    laplacian = cv2.Laplacian(cv2.GaussianBlur(gray.astype(np.float32), (0, 0), 1.0), cv2.CV_32F)
    return float(laplacian[4:-4, 4:-4].std()) if min(gray.shape) > 8 else 0.0


def _warp(original: np.ndarray, matrix: np.ndarray, shape: tuple[int, int]) -> tuple[np.ndarray, np.ndarray]:
    height, width = shape
    aligned = cv2.warpAffine(original, matrix[:2], (width, height), flags=cv2.INTER_LINEAR)
    valid = cv2.warpAffine(
        np.ones(original.shape[:2], dtype=np.uint8), matrix[:2], (width, height),
        flags=cv2.INTER_NEAREST,
    )
    # Exclude interpolation across the outer boundary from colour statistics.
    valid = cv2.erode(valid, np.ones((3, 3), np.uint8), borderType=cv2.BORDER_CONSTANT, borderValue=0)
    return aligned, valid.astype(bool)


def _correlation(left: np.ndarray, right: np.ndarray, mask: np.ndarray) -> float:
    if int(mask.sum()) < 100:
        return 0.0
    a, b = left[mask].astype(np.float64).ravel(), right[mask].astype(np.float64).ravel()
    a -= a.mean()
    b -= b.mean()
    norm = float(np.linalg.norm(a) * np.linalg.norm(b))
    return float(np.clip(np.dot(a, b) / norm, -1, 1)) if norm > 1e-10 else 0.0


def _structural_score(aligned: np.ndarray, edited: np.ndarray, mask: np.ndarray) -> float:
    # Broad tone curves and colour casts can change luminance while preserving
    # edge positions and directions.  Compare both gradient components.
    a, b = _structure(aligned), _structure(edited)
    interior = cv2.erode(mask.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool)
    ax = cv2.Sobel(a, cv2.CV_32F, 1, 0, ksize=3)
    ay = cv2.Sobel(a, cv2.CV_32F, 0, 1, ksize=3)
    bx = cv2.Sobel(b, cv2.CV_32F, 1, 0, ksize=3)
    by = cv2.Sobel(b, cv2.CV_32F, 0, 1, ksize=3)
    # Pool x/y derivatives so a photo with primarily one edge direction works.
    return _correlation(np.stack((ax, ay), axis=-1), np.stack((bx, by), axis=-1), interior)


def _plausible(matrix: np.ndarray, original_shape: tuple[int, int], edited_shape: tuple[int, int]) -> bool:
    if not np.isfinite(matrix).all():
        return False
    singular = np.linalg.svd(matrix[:2, :2], compute_uv=False)
    if singular.min() <= 0 or np.linalg.det(matrix[:2, :2]) <= 0:
        return False
    if singular.max() / singular.min() > 1.08:
        return False
    relative_scale = sqrt(float(np.linalg.det(matrix[:2, :2])))
    expected_scale = max(edited_shape) / max(original_shape)
    rotation = abs(degrees(atan2(matrix[1, 0], matrix[0, 0])))
    return 0.3 < relative_scale / expected_scale < 4 and rotation < 35


def _orb_candidates(original: np.ndarray, edited: np.ndarray) -> list[tuple[np.ndarray, dict[str, Any]]]:
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    orb = cv2.ORB_create(nfeatures=4000, edgeThreshold=19, fastThreshold=10)
    kp_a, desc_a = orb.detectAndCompute(clahe.apply(_gray(original)), None)
    kp_b, desc_b = orb.detectAndCompute(clahe.apply(_gray(edited)), None)
    if desc_a is None or desc_b is None or min(len(desc_a), len(desc_b)) < 8:
        return []
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING)
    forward = matcher.knnMatch(desc_a, desc_b, k=2)
    backward = matcher.knnMatch(desc_b, desc_a, k=2)
    reciprocal = {
        pair[0].queryIdx: pair[0].trainIdx
        for pair in backward if len(pair) == 2 and pair[0].distance < 0.8 * pair[1].distance
    }
    matches = [
        pair[0] for pair in forward
        if len(pair) == 2 and pair[0].distance < 0.8 * pair[1].distance
        and reciprocal.get(pair[0].trainIdx) == pair[0].queryIdx
    ]
    if len(matches) < 8:
        return []
    src = np.array([kp_a[m.queryIdx].pt for m in matches], dtype=np.float32)
    dst = np.array([kp_b[m.trainIdx].pt for m in matches], dtype=np.float32)
    affine, inliers = cv2.estimateAffinePartial2D(
        src, dst, method=cv2.RANSAC, ransacReprojThreshold=3,
        maxIters=3000, confidence=0.995, refineIters=20,
    )
    if affine is None or inliers is None:
        return []
    selected = inliers.ravel().astype(bool)
    count = int(selected.sum())
    if count < 8:
        return []
    # Require evidence across the image, not a single repeated texture patch.
    spread = []
    for points, image in ((src[selected], original), (dst[selected], edited)):
        hull = cv2.convexHull(points)
        spread.append(float(cv2.contourArea(hull) / (image.shape[0] * image.shape[1])))
    projected = src[selected] @ affine[:, :2].T + affine[:, 2]
    residual = float(np.median(np.linalg.norm(projected - dst[selected], axis=1)))
    matrix = np.vstack((affine, [0, 0, 1])).astype(np.float64)
    return [(matrix, {
        "method": "orb_ransac", "matches": len(matches), "inliers": count,
        "inlier_fraction": count / len(matches), "feature_coverage": spread,
        "median_reprojection_error": residual,
    })]


def _ecc_candidate(original: np.ndarray, edited: np.ndarray) -> tuple[np.ndarray, dict[str, Any]] | None:
    # Bounded CPU fallback for modest transforms when too few ORB features are
    # available. ECC works on edge magnitude so colour edits have little impact.
    height, width = edited.shape[:2]
    factor = min(1.0, 640 / max(height, width))
    small_size = (max(16, round(width * factor)), max(16, round(height * factor)))
    first = cv2.resize(original, small_size, interpolation=cv2.INTER_AREA)
    second = cv2.resize(edited, small_size, interpolation=cv2.INTER_AREA)

    def edges(image: np.ndarray) -> np.ndarray:
        gray = _structure(image)
        dx, dy = cv2.Sobel(gray, cv2.CV_32F, 1, 0), cv2.Sobel(gray, cv2.CV_32F, 0, 1)
        edge = cv2.magnitude(dx, dy)
        return np.minimum(edge, np.percentile(edge, 99)).astype(np.float32)

    try:
        score, inverse = cv2.findTransformECC(
            edges(second), edges(first), np.eye(2, 3, dtype=np.float32), cv2.MOTION_AFFINE,
            (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 100, 1e-5), None, 5,
        )
    except cv2.error:
        return None
    source_resize = _resize_matrix(original.shape[1], original.shape[0], *small_size)
    target_resize = _resize_matrix(width, height, *small_size)
    matrix = np.linalg.inv(target_resize) @ np.linalg.inv(np.vstack((inverse, [0, 0, 1]))) @ source_resize
    return matrix, {"method": "gradient_ecc", "ecc_correlation": float(score)}


def _crop_bounds(matrix: np.ndarray, original_size: tuple[int, int], edited_size: tuple[int, int]) -> list[float] | None:
    ow, oh = original_size
    ew, eh = edited_size
    corners = np.array([[0, 0, 1], [ew, 0, 1], [ew, eh, 1], [0, eh, 1]], dtype=np.float64)
    inverse = corners @ np.linalg.inv(matrix).T
    xy = inverse[:, :2] / inverse[:, 2:]
    left, top = np.maximum(xy.min(axis=0), [0, 0])
    right, bottom = np.minimum(xy.max(axis=0), [ow, oh])
    if left <= 0.01 * ow and top <= 0.01 * oh and right >= 0.99 * ow and bottom >= 0.99 * oh:
        return None
    return [round(float(left), 3), round(float(top), 3), round(float(max(0, right - left)), 3), round(float(max(0, bottom - top)), 3)]


def align_images(original_path: Path, edited_path: Path, max_dimension: int = 1400) -> AlignmentResult:
    """Align RAW/JPG or JPG/JPG pairs without altering files or using a network.

    Arrays are uint8 RGB in the edited image's bounded analysis geometry. The
    matrix maps *EXIF-oriented full-size* original pixel coordinates to the
    EXIF-oriented full-size edited image. Rotation is clockwise-positive in
    raster coordinates. Confidence describes registration only, not inferred
    editing parameters. ICC profiles are converted to sRGB locally when valid.
    """
    if not isinstance(max_dimension, int) or isinstance(max_dimension, bool) or max_dimension < 32:
        raise ValueError("max_dimension must be an integer of at least 32")
    original_decode: dict[str, Any] = {}
    edited_decode: dict[str, Any] = {}
    original, original_size, original_warnings = _read_rgb(Path(original_path), max_dimension, original_decode)
    edited, edited_size, edited_warnings = _read_rgb(Path(edited_path), max_dimension, edited_decode)
    warnings = list(dict.fromkeys(original_warnings + edited_warnings))
    if min(*original.shape[:2], *edited.shape[:2]) < 16:
        warnings.append("image_too_small")
    fallback = _resize_matrix(original.shape[1], original.shape[0], edited.shape[1], edited.shape[0])
    candidate_matrix = fallback
    aligned, overlap = _warp(original, fallback, edited.shape[:2])
    diagnostics: dict[str, Any] = {"method": "unregistered"}
    confidence = 0.0
    success = False
    structure_score = 0.0
    textures = [_texture(_gray(original)), _texture(_gray(edited))]
    if min(textures) < 0.35:
        warnings.append("insufficient_texture")
    elif "image_too_small" not in warnings:
        candidates = _orb_candidates(original, edited)
        # A full-frame resize is a legitimate candidate only when its image
        # structure actually agrees. Size equality alone proves nothing.
        candidates.append((fallback, {"method": "structural_identity"}))
        best_score = -1.0
        for matrix, evidence in candidates:
            if not _plausible(matrix, original.shape[:2], edited.shape[:2]):
                continue
            warped, valid = _warp(original, matrix, edited.shape[:2])
            score = _structural_score(warped, edited, valid)
            if score > best_score:
                candidate_matrix, aligned, overlap, diagnostics = matrix, warped, valid, evidence
                best_score = score
        if best_score < 0.8:
            ecc = _ecc_candidate(original, edited)
            if ecc is not None and _plausible(ecc[0], original.shape[:2], edited.shape[:2]):
                warped, valid = _warp(original, ecc[0], edited.shape[:2])
                score = _structural_score(warped, edited, valid)
                if score > best_score:
                    candidate_matrix, aligned, overlap, diagnostics = ecc[0], warped, valid, ecc[1]
                    best_score = score
        structure_score = max(0.0, best_score)
        fraction = float(overlap.mean())
        method = diagnostics["method"]
        enough_features = (
            diagnostics.get("inliers", 0) >= 10
            and diagnostics.get("inlier_fraction", 0) >= 0.35
            and min(diagnostics.get("feature_coverage", [0])) >= 0.04
        )
        required_score = 0.6 if method == "orb_ransac" and enough_features else 0.88
        success = fraction >= 0.3 and structure_score >= required_score
        if success:
            confidence = float(np.clip(0.55 + 0.4 * structure_score, 0, 0.99))
            if method == "orb_ransac":
                confidence *= 0.8 + 0.2 * min(1, diagnostics["inliers"] / 40)
            elif method == "gradient_ecc":
                confidence *= 0.9
        elif fraction < 0.3:
            warnings.append("low_overlap")
    if not success:
        warnings.append("alignment_unreliable")
    analysis_original_resize = _resize_matrix(*original_size, original.shape[1], original.shape[0])
    analysis_edited_resize = _resize_matrix(*edited_size, edited.shape[1], edited.shape[0])
    full_matrix = np.linalg.inv(analysis_edited_resize) @ candidate_matrix @ analysis_original_resize
    metadata: dict[str, Any] = {
        "success": success,
        "confidence": round(confidence, 6),
        "method": diagnostics["method"] if success else "unregistered",
        "overlap_fraction": round(float(overlap.mean()), 6) if success else 0.0,
        "rotation_degrees": round(degrees(atan2(full_matrix[1, 0], full_matrix[0, 0])), 6),
        "scale": round(sqrt(abs(float(np.linalg.det(full_matrix[:2, :2])))), 6),
        "matrix": full_matrix.tolist(),
        "crop_bounds_original": _crop_bounds(full_matrix, original_size, edited_size) if success else None,
        "warnings": warnings,
        "original_size": list(original_size),
        "edited_size": list(edited_size),
        "analysis_size": [edited.shape[1], edited.shape[0]],
        "coordinate_system": "exif_oriented_pixels",
        "diagnostics": {**diagnostics, "structural_correlation": round(structure_score, 6), "texture": textures},
    }
    if original_decode:
        metadata["original_decode"] = original_decode
    if edited_decode:
        metadata["edited_decode"] = edited_decode
    return AlignmentResult(aligned, edited, overlap if success else np.zeros_like(overlap), metadata)
