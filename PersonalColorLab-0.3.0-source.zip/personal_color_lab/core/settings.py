import json
from pathlib import Path
from .constants import app_data_dir, SETTINGS_FILENAME, DEFAULT_LANGUAGE


def settings_path() -> Path:
    return app_data_dir() / SETTINGS_FILENAME


def load_settings() -> dict:
    p = settings_path()
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                data['language'] = data.get('language', DEFAULT_LANGUAGE)
                if data['language'] not in {'en', 'ko'}:
                    data['language'] = DEFAULT_LANGUAGE
                return data
        except Exception:
            pass
    return {'language': DEFAULT_LANGUAGE}


def save_settings(data: dict):
    settings_path().write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
