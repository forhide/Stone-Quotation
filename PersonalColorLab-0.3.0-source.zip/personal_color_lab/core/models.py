from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

@dataclass
class PhotoRecord:
    path: Path
    ext: str
    kind: str
    size_bytes: int
    width: Optional[int] = None
    height: Optional[int] = None
    capture_time: Optional[str] = None
    camera: Optional[str] = None
    lens: Optional[str] = None
    fingerprint: Optional[str] = None

@dataclass
class PairCandidate:
    original: Path
    edited: Path
    pair_type: str
    confidence: float
    reasons: list[str] = field(default_factory=list)

@dataclass
class ScanSummary:
    total_files: int = 0
    raw: int = 0
    jpg: int = 0
    other_images: int = 0
    xmp: int = 0
    raw_xmp_pairs: int = 0
    raw_jpg_pairs: int = 0
    jpg_jpg_pairs: int = 0
    edited_only: int = 0
    possible_pairs: int = 0
