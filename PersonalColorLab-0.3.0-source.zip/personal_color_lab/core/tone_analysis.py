"""Bounded, local measurements of the observed tone transform in an image pair.

Images are decoded sRGB RGB pixels, registered to the same geometry. These
measurements describe rendered pixels; exposure EV is an approximation rather
than a recovered Lightroom setting.
"""

from __future__ import annotations

import numpy as np

MAX_SAMPLES = 100_000
_LUMA_WEIGHTS = np.array([0.2126, 0.7152, 0.0722], dtype=np.float64)


def _sample_pair(
    original_rgb: np.ndarray, edited_rgb: np.ndarray, mask: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Validate registered RGB inputs and deterministically bound analysis work."""
    if (
        not isinstance(original_rgb, np.ndarray)
        or not isinstance(edited_rgb, np.ndarray)
        or original_rgb.dtype != np.uint8
        or edited_rgb.dtype != np.uint8
        or original_rgb.ndim != 3
        or original_rgb.shape[-1] != 3
        or original_rgb.shape != edited_rgb.shape
    ):
        raise ValueError("Expected same-size uint8 RGB arrays with shape (H, W, 3).")
    if (
        not isinstance(mask, np.ndarray)
        or mask.dtype != np.bool_
        or mask.shape != original_rgb.shape[:2]
    ):
        raise ValueError("Expected a boolean overlap mask with shape (H, W).")
    indices = np.flatnonzero(mask)
    if indices.size > MAX_SAMPLES:
        indices = indices[np.linspace(0, indices.size - 1, MAX_SAMPLES, dtype=np.int64)]
    return (
        original_rgb.reshape(-1, 3)[indices].astype(np.float64) / 255.0,
        edited_rgb.reshape(-1, 3)[indices].astype(np.float64) / 255.0,
    )


def _linear_rgb(rgb: np.ndarray) -> np.ndarray:
    return np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)


def _monotone_fit(values: list[float], weights: list[int]) -> list[float]:
    """Weighted isotonic regression; preserve observations separately in output."""
    blocks: list[list[float | int]] = []
    for index, (value, weight) in enumerate(zip(values, weights)):
        blocks.append([index, index, value * weight, weight])
        while len(blocks) > 1:
            left, right = blocks[-2:]
            if float(left[2]) / float(left[3]) <= float(right[2]) / float(right[3]):
                break
            blocks[-2:] = [[left[0], right[1], left[2] + right[2], left[3] + right[3]]]
    result = [0.0] * len(values)
    for start, end, total, weight in blocks:
        for index in range(int(start), int(end) + 1):
            result[index] = float(total) / float(weight)
    return result


def _clipping(rgb: np.ndarray, luma: np.ndarray) -> dict:
    if not len(rgb):
        return dict.fromkeys(
            ("black_fraction", "white_fraction", "channel_low_fraction", "channel_high_fraction"),
            None,
        )
    return {
        "black_fraction": float(np.mean(luma <= 1.0 / 255)),
        "white_fraction": float(np.mean(luma >= 254.0 / 255)),
        "channel_low_fraction": float(np.mean(rgb <= 1.0 / 255)),
        "channel_high_fraction": float(np.mean(rgb >= 254.0 / 255)),
    }


def analyze_tone(original_rgb: np.ndarray, edited_rgb: np.ndarray, mask: np.ndarray) -> dict:
    """Measure tone over valid aligned pixels; return JSON-safe scalars and lists.

    Luminance deltas and curve coordinates use normalized rendered sRGB luma.
    Exposure uses linear-light luminance ratios, excluding near-black and clipped
    pixels. Zone membership comes from the original. Confidence is a heuristic
    evidence score, not a calibrated probability.
    """
    original, edited = _sample_pair(original_rgb, edited_rgb, mask)
    original_luma, edited_luma = original @ _LUMA_WEIGHTS, edited @ _LUMA_WEIGHTS
    count = len(original)
    original_clip = _clipping(original, original_luma)
    edited_clip = _clipping(edited, edited_luma)
    result = {
        "sample_count": count,
        "mean_luminance_delta": None,
        "estimated_exposure_ev": None,
        "exposure_confidence": 0.0,
        "contrast_delta": None,
        "zones": {},
        "tone_transfer": [],
        "clipping": {
            "original": original_clip,
            "edited": edited_clip,
            "black_delta": None,
            "white_delta": None,
        },
        "limitations": [
            "tone_rendered_srgb_ev_approximation",
            "tone_monotone_fit",
            "analysis_confidence_heuristic",
        ],
    }
    zone_masks = {
        "shadows": original_luma < 0.25,
        "midtones": (original_luma >= 0.25) & (original_luma < 0.75),
        "highlights": original_luma >= 0.75,
    }
    delta = edited_luma - original_luma
    for name, selected in zone_masks.items():
        zone_count = int(np.count_nonzero(selected))
        result["zones"][name] = {
            "delta": float(np.mean(delta[selected])) if zone_count else None,
            "sample_count": zone_count,
            "confidence": float(min(1.0, zone_count / 256.0)),
        }
    if not count:
        result["limitations"].append("no_valid_overlap")
        return result

    result["mean_luminance_delta"] = float(np.mean(delta))
    result["contrast_delta"] = float(
        np.ptp(np.percentile(edited_luma, [5, 95]))
        - np.ptp(np.percentile(original_luma, [5, 95]))
    )
    result["clipping"]["black_delta"] = (
        edited_clip["black_fraction"] - original_clip["black_fraction"]
    )
    result["clipping"]["white_delta"] = (
        edited_clip["white_fraction"] - original_clip["white_fraction"]
    )

    original_linear = _linear_rgb(original) @ _LUMA_WEIGHTS
    edited_linear = _linear_rgb(edited) @ _LUMA_WEIGHTS
    usable = (
        (original_linear > 0.01)
        & (edited_linear > 0.01)
        & (original_linear < 0.85)
        & (edited_linear < 0.85)
        & (np.max(original, axis=1) < 254 / 255)
        & (np.max(edited, axis=1) < 254 / 255)
    )
    exposure_count = int(np.count_nonzero(usable))
    if exposure_count:
        ratios_ev = np.log2(edited_linear[usable] / original_linear[usable])
        median_ev = float(np.median(ratios_ev))
        spread_ev = float(np.median(np.abs(ratios_ev - median_ev)))
        span = float(np.ptp(np.percentile(original_linear[usable], [10, 90])))
        support = min(1.0, exposure_count / 256.0)
        coverage = exposure_count / count
        tonal_diversity = 0.4 + 0.6 * min(1.0, span / 0.3)
        result["estimated_exposure_ev"] = median_ev
        result["exposure_confidence"] = float(
            support * coverage * tonal_diversity / (1.0 + 4.0 * spread_ev)
        )
    else:
        result["limitations"].append("tone_ev_no_usable_pixels")

    bin_indices = np.minimum((original_luma * 32).astype(np.int32), 31)
    transfer = []
    for bin_index in range(32):
        selected = bin_indices == bin_index
        bin_count = int(np.count_nonzero(selected))
        if not bin_count:
            continue
        observed = float(np.median(edited_luma[selected]))
        transfer.append({
            "input": float(np.median(original_luma[selected])),
            "output": observed,
            "observed_output": observed,
            "count": bin_count,
            "confidence": float(min(1.0, bin_count / 128.0)),
        })
    fitted = _monotone_fit(
        [sample["observed_output"] for sample in transfer],
        [sample["count"] for sample in transfer],
    )
    for sample, fitted_output in zip(transfer, fitted):
        sample["output"] = fitted_output
    result["tone_transfer"] = transfer
    return result
