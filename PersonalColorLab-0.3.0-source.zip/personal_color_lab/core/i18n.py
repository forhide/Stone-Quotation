import json
from importlib.resources import files

class I18N:
    def __init__(self, language='en'):
        # Works in source trees, Python archives, and frozen bundle loaders.
        # Never rely on a Finder/shortcut launch's working directory.
        self.base = files('personal_color_lab').joinpath('locales')
        self.language = language
        self.messages = {}
        self.load(language)

    def load(self, language):
        self.language = language
        path = self.base / f'{language}.json'
        self.messages = json.loads(path.read_text(encoding='utf-8'))

    def t(self, key, **kwargs):
        text = self.messages.get(key, key)
        try:
            return text.format(**kwargs)
        except Exception:
            return text
