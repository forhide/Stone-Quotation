from pathlib import Path
from PIL import Image, ExifTags, ImageOps
from .fingerprint import dhash

EXIF = {v: k for k, v in ExifTags.TAGS.items()}


def image_metadata(path: Path) -> dict:
    out = {'width': None, 'height': None, 'capture_time': None, 'camera': None, 'lens': None, 'fingerprint': None}
    try:
        with Image.open(path) as im:
            im2 = ImageOps.exif_transpose(im)
            out['width'], out['height'] = im2.size
            exif = im.getexif() or {}
            out['capture_time'] = exif.get(EXIF.get('DateTimeOriginal')) or exif.get(EXIF.get('DateTime'))
            make = exif.get(EXIF.get('Make'))
            model = exif.get(EXIF.get('Model'))
            if make or model:
                out['camera'] = ' '.join(str(x).strip() for x in (make, model) if x)
            lens = exif.get(EXIF.get('LensModel'))
            if lens:
                out['lens'] = str(lens)
    except Exception:
        pass
    out['fingerprint'] = dhash(path)
    return out
