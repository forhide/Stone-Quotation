"""Desktop entrypoint with an explicit, noninteractive package diagnostic mode."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .core.constants import APP_NAME, APP_VERSION


def run():
    """Preserve the existing programmatic GUI entrypoint without eager Tk imports."""
    from .ui.app import run as run_gui
    run_gui()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog=APP_NAME, description='Desktop photo pair analysis.')
    parser.add_argument('--version', action='version', version=f'{APP_NAME} {APP_VERSION}')
    parser.add_argument('--self-test', action='store_true', help='Check local packaged resources, native dependencies, and synthetic JPG analysis without opening a window.')
    parser.add_argument('--self-test-report', type=Path, metavar='PATH', help='Write the self-test JSON report to this path; useful for windowed executables without a console.')
    args = parser.parse_args(argv)
    if args.self_test_report is not None and not args.self_test:
        parser.error('--self-test-report requires --self-test')
    if args.self_test:
        from .core.package_check import run_package_check
        report = run_package_check()
        encoded = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n'
        if args.self_test_report is not None:
            try:
                args.self_test_report.parent.mkdir(parents=True, exist_ok=True)
                args.self_test_report.write_text(encoded, encoding='utf-8')
            except OSError as exc:
                if sys.stderr is not None:
                    print(f'Cannot write self-test report: {exc}', file=sys.stderr)
                return 1
        if sys.stdout is not None:
            sys.stdout.write(encoded)
        return 0 if report['ok'] else 1
    run()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
