from personal_color_lab.main import main


if __name__ == '__main__':
    raise SystemExit(main())
