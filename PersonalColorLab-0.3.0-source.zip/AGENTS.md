# Personal Color Lab - Agent Instructions

## Product mission
Build a desktop application that learns a user's photographic editing preferences and applies adaptive Lightroom-style edits while remaining fully offline after installation.

## Non-negotiable requirements
1. The installed application must run fully offline.
2. Do not add external AI APIs, cloud inference, login, telemetry, analytics, remote configuration, or hidden network dependencies.
3. Never upload photos, previews, EXIF, style data, or model data.
4. Original photo files must never be destructively modified.
5. Prefer Lightroom-compatible XMP sidecars for final editing output.
6. English is the default UI language. Korean must be selectable. Keep all UI text in locale resources; do not hard-code display strings.
7. Do not persist GPS coordinates. Ignore or strip location metadata unless a future explicit requirement changes this.
8. Local ML inference should prefer ONNX Runtime where practical. GPU acceleration is optional; CPU fallback is mandatory.
9. Keep the runtime free of HTTP clients unless a future requirement explicitly changes the offline contract.
10. Maintain Windows-friendly packaging and preserve cross-platform code where practical.

## Core style system
The application must support these style sources:
- My Style: learns from the user's own historical edits.
- Custom Reference Style: learns from a set of reference photos supplied by the user.
- Built-in Style Library: bundled local profiles inspired by notable film stocks, cinema/drama color approaches, photographers, cinematographers, and directors.
- Hybrid Style: mixes My Style, reference styles, and built-in styles with adjustable strengths.

All style sources should converge into a common Style DNA representation rather than separate incompatible engines.

## Input data quality hierarchy
Support all of the following and track source confidence:
1. RAW + XMP: highest confidence, actual edit metadata when parsable.
2. RAW + edited JPG: infer the edit transform from source vs result.
3. Original JPG + edited JPG: infer tone/color/edit transform from image pairs.
4. Edited/reference JPG only: extract final visual Style DNA, not exact editing history.

Do not pretend inferred Lightroom slider values are exact. Store and expose confidence and provenance.

## Reverse analysis priorities
The reverse-analysis engine is a central product feature because XMP files will often be missing.
It should progressively support:
- robust original/edited pairing
- geometric registration
- resize/crop/rotation detection
- tone-transfer estimation
- luminance-zone deltas
- color-space deltas (RGB plus perceptual spaces such as Lab; HSV/HSL as useful)
- HSL-like channel behavior
- white-balance/tint tendency
- contrast and tone-curve reconstruction
- grain/sharpness/noise behavior
- later: subject/sky/skin/background local-edit inference

The primary truth is the observed image transform. Lightroom-style slider values are a secondary approximation of that transform.

## Scene taxonomy
Use multilabel scene attributes rather than one exclusive category.
Important axes include:
- time/light: day, golden hour, blue hour, night
- environment: indoor, outdoor
- subject: portrait, landscape, city/street, architecture, food, still life
- lighting: natural, tungsten/warm artificial, LED/fluorescent, neon, mixed light
- exposure characteristics: low light, backlit, high dynamic range, strong highlights

Style learning should combine a global user profile plus scene-specific deltas instead of creating an isolated model for every category combination.

## Built-in style library
At minimum plan three local bundle categories:

### Film
Color/tone/grain focused; normally no composition changes.
Examples to model as approximate/inspired local profiles include Portra-family warm negative looks, Ektar-like vivid color, Kodak Gold-like consumer color, Vision3 daylight/tungsten cinema negative looks, Fuji Pro 400H-like pastel color, Superia-like consumer color, Velvia/Provia-like slide color, HP5/Delta-like black-and-white, and tungsten-night color-negative looks.

### Cinema / Drama
Color, tone, texture, and composition metadata.
Examples may include profiles inspired by pastel symmetrical cinema, Hong Kong neon romance, clean one-point symmetry, warm futuristic pastel, saturated European storybook color, neon night cinema, candlelit period cinema, desert graphic color, and similar recognizable visual approaches.

### Artist / Director / Cinematographer
Profiles that encode recurring color/tone/composition tendencies rather than copied images.
Examples may include Wes Anderson-inspired symmetry/pastels, Wong Kar-wai-inspired neon/green-red night color, Sofia Coppola-inspired soft pastel color, Kubrick-inspired one-point symmetry, Roger Deakins-inspired controlled naturalistic contrast, Gregory Crewdson-inspired cinematic night lighting, Saul Leiter-inspired layered muted color, William Eggleston-inspired strong everyday color, Rinko Kawauchi-inspired luminous softness, and similar profiles.

Bundled profiles must contain derived parameters/metadata, not copyrighted source frames or photographer images.

## Composition behavior
Film presets usually do not include composition.
Cinema/drama/director presets may include a composition profile.
When a selected preset includes composition, color/tone should still apply normally, but show a user choice before changing composition:
- Color only
- Show composition suggestions
- Apply composition automatically

Default to Color only or suggestion-first behavior, not destructive automatic cropping.
Composition analysis may include symmetry, center bias, one-point perspective, horizon/vertical alignment, negative space, aspect-ratio preference, and crop suggestions.
All crop/geometry changes must remain non-destructive.

## Custom reference style builder
When the user supplies many reference images:
- analyze dataset diversity and coverage
- cluster/identify outliers
- estimate style consistency
- build global Style DNA plus scene-specific subprofiles
- warn about underrepresented scene types instead of refusing to build the style

A carefully diverse set is more valuable than a large set of near-duplicates.

## Localization
- Default: English
- Optional: Korean
- Preset proper names may remain in English; descriptions and UI text should localize.
- Keep translation resources external, e.g. locales/en.json and locales/ko.json.

## Security and privacy
- Local-only metadata DB (SQLite is acceptable).
- Store file paths and derived metadata; avoid duplicating original photo libraries.
- No GPS persistence.
- No network calls.
- No telemetry.
- No account system.
- Offline model/update packs are acceptable.

## Engineering practices
- Preserve backward compatibility with the current V0.1 DB where practical; use schema migrations if needed.
- Add tests for every major analysis step.
- Keep heavy optional dependencies isolated and document them.
- Avoid monolithic files. Separate scan/pairing, image alignment, transform estimation, style DNA, XMP handling, scene analysis, and UI.
- Keep DEVELOPMENT_CONTEXT.md, CHANGELOG.md, ROADMAP.md, and TODO.md current after each meaningful milestone.
- Before a release, run tests and record any known limitations.
