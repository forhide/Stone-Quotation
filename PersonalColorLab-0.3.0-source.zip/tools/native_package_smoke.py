"""Install and validate an artifact on a disposable native CI host.

Refuses to replace an existing macOS app. Windows uses a temporary custom
install path. User-data checks always use an isolated test directory.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import platform
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]


def checked(command, **kwargs):
    return subprocess.run(command, check=True, timeout=180, **kwargs)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', choices=['windows-x64', 'macos-x64', 'macos-arm64'], required=True)
    parser.add_argument('--artifact', type=Path, required=True)
    parser.add_argument('--report-dir', type=Path, default=ROOT / 'build/native-reports')
    args = parser.parse_args()
    args.report_dir.mkdir(parents=True, exist_ok=True)
    artifact = args.artifact.resolve()
    windows = args.target == 'windows-x64'
    assert (platform.system() == 'Windows') if windows else (platform.system() == 'Darwin')
    if not windows:
        expected = 'arm64' if args.target == 'macos-arm64' else 'x86_64'
        assert platform.machine() == expected, 'Use a runner matching the artifact architecture'
    report = {'target': args.target, 'artifact': artifact.name, 'ok': False, 'checks': []}
    try:
        with tempfile.TemporaryDirectory(prefix='pcl-install-check-') as temporary:
            temp = Path(temporary)
            data = temp / 'user-data'
            data.mkdir()
            sentinel = data / 'preserve.txt'
            sentinel.write_text('User data must survive upgrades and uninstall', encoding='utf-8')
            environment = dict(os.environ, PERSONAL_COLOR_LAB_DATA_DIR=str(data))
            if windows:
                installed = temp / 'Installed App'
                # /D is NSIS's final unquoted command-line remainder.
                command = f'"{artifact}" /S /D={installed}'
                checked(command, env=environment)
                python = installed / 'runtime/python.exe'
                launcher = installed / 'Personal Color Lab.exe'
                checked(command, env=environment)
                assert sentinel.read_text(encoding='utf-8').startswith('User data')
                report['checks'].append('upgrade_preserves_user_data')
            else:
                installed = Path('/Applications/Personal Color Lab.app')
                if installed.exists():
                    raise RuntimeError('Refusing to overwrite an existing app on this host')
                checked(['sudo', 'installer', '-pkg', str(artifact), '-target', '/'])
                python = installed / 'Contents/Resources/runtime/bin/python3.13'
                launcher = installed / 'Contents/MacOS/Personal Color Lab'
            report['checks'].append('installer')
            diagnostic = args.report_dir.resolve() / f'{args.target}-self-test.json'
            checked([str(launcher), '--self-test', '--self-test-report', str(diagnostic)], env=environment)
            assert json.loads(diagnostic.read_text(encoding='utf-8'))['ok']
            report['checks'].append('installed_launcher_self_test')
            checked([str(python), '-I', '-B', str(ROOT / 'tools/native_gui_smoke.py')], env=environment)
            report['checks'].append('installed_gui_flow')
            if windows:
                unrelated = installed / 'unrelated-user-file.txt'
                unrelated.write_text('preserve', encoding='utf-8')
                checked([str(installed / 'Uninstall.exe'), '/S'], env=environment)
                deadline = time.monotonic() + 30
                while launcher.exists() and time.monotonic() < deadline:
                    time.sleep(0.1)
                assert not launcher.exists()
                assert unrelated.read_text(encoding='utf-8') == 'preserve'
            else:
                # The test owns this exact app path: it was absent before install.
                checked(['sudo', 'rm', '-rf', str(installed)])
                checked(['sudo', 'pkgutil', '--forget', 'org.personalcolorlab.desktop.' + args.target])
            assert sentinel.exists()
            report['checks'].append('uninstall_preserves_user_data')
        report['ok'] = True
    except Exception as exc:
        report['error'] = str(exc)
        raise
    finally:
        (args.report_dir / f'{args.target}-installation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
