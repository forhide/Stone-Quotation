"""Run tests on a native display or an automatically selected local Xvfb.

Xvfb is a development prerequisite only. Nothing is downloaded by this runner.
"""
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parents[1]
    command = [sys.executable, "-m", "pytest", *(sys.argv[1:] or ["-q"])]
    if os.name == "nt" or os.environ.get("DISPLAY"):
        return subprocess.call(command, cwd=root)
    binary = os.environ.get("PERSONAL_COLOR_LAB_XVFB") or shutil.which("Xvfb")
    if not binary:
        raise SystemExit("Install Xvfb or set PERSONAL_COLOR_LAB_XVFB to its executable for headless desktop tests.")
    read_fd, write_fd = os.pipe()
    server = None
    try:
        with tempfile.TemporaryFile() as log:
            server = subprocess.Popen(
                [binary, "-displayfd", str(write_fd), "-screen", "0", "1600x1000x24", "-nolisten", "tcp"],
                pass_fds=(write_fd,), stdout=log, stderr=log,
            )
            os.close(write_fd)
            write_fd = None
            if not select.select([read_fd], [], [], 10)[0]:
                raise RuntimeError("Xvfb did not become ready in time")
            display = os.read(read_fd, 64).decode().strip()
            if not display.isdigit():
                log.seek(0)
                raise RuntimeError("Xvfb startup failed: " + log.read().decode(errors="replace"))
            environment = dict(os.environ, DISPLAY=":" + display)
            return subprocess.call(command, cwd=root, env=environment)
    finally:
        os.close(read_fd)
        if write_fd is not None:
            os.close(write_fd)
        if server is not None:
            server.terminate()
            server.wait(timeout=5)


if __name__ == "__main__":
    raise SystemExit(main())
