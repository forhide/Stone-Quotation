"""Download and verify native wheels for offline desktop installers.

This is an online *build* tool, never imported by the application. Downloads
retain their original archive contents, including bundled dependency licenses.
The selected OpenCV version requires macOS 14 on Intel and macOS 13 on ARM.

Example: python tools/download_wheels.py --targets windows-x64 macos-arm64
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PYTHON_VERSION = "3.13"
ABI = "cp313"
TARGETS = {
    "windows-x64": {"platform": "win_amd64", "architecture": "x86_64", "minimum_macos": None},
    "macos-x64": {"platform": "macosx_14_0_x86_64", "architecture": "x86_64", "minimum_macos": "14.0"},
    "macos-arm64": {"platform": "macosx_13_0_arm64", "architecture": "arm64", "minimum_macos": "13.0"},
}
_PIN = re.compile(r"([A-Za-z0-9][A-Za-z0-9._-]*)==([A-Za-z0-9][A-Za-z0-9.!+_-]*)\Z")
_MAC_PLATFORM = re.compile(r"macosx_(\d+)_(\d+)_(x86_64|arm64|universal2)\Z")


def canonical_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def read_requirements(path: Path) -> dict[str, str]:
    """Reject floating versions, URLs, flags and environment-dependent pins."""
    pins = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        matched = _PIN.fullmatch(line)
        if not matched:
            raise ValueError(f"Only exact project==version pins are supported (line {line_number}).")
        project, version = matched.groups()
        project = canonical_name(project)
        if project in pins:
            raise ValueError(f"Duplicate project pin: {project}")
        pins[project] = version
    if not pins:
        raise ValueError("The requirements lock has no project pins.")
    return pins


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fetch_pypi_metadata(project: str, version: str) -> dict:
    project_part = urllib.parse.quote(project, safe="")
    version_part = urllib.parse.quote(version, safe="")
    request = urllib.request.Request(
        f"https://pypi.org/pypi/{project_part}/{version_part}/json",
        headers={"User-Agent": "Personal-Color-Lab-installer-build/1"},
    )
    # The standard HTTPS context keeps certificate and hostname checks enabled.
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.load(response)


def wheel_parts(filename: str) -> tuple[str, str, list[str]]:
    if not filename.endswith(".whl"):
        raise ValueError(f"Not a wheel: {filename}")
    parts = filename[:-4].split("-")
    if len(parts) not in (5, 6):
        raise ValueError(f"Invalid wheel filename: {filename}")
    project, version = parts[:2]
    python_tag, abi_tag, platform_tag = parts[-3:]
    tags = [
        f"{python}-{abi}-{platform}"
        for python in python_tag.split(".")
        for abi in abi_tag.split(".")
        for platform in platform_tag.split(".")
    ]
    return canonical_name(project), version, tags


def compatible_tag(tag: str, target: str) -> bool:
    python, abi, platform = tag.split("-")
    # Stable ABI wheels such as OpenCV's cp37-abi3 work on the bundled CPython
    # 3.13 GIL build; free-threaded cp313t wheels are deliberately excluded.
    exact_python = python == "cp313" and abi == ABI
    stable_abi = (
        abi == "abi3"
        and bool(re.fullmatch(r"cp3\d+", python))
        and 2 <= int(python[3:]) <= 13
    )
    pure_python = python in {"py3", "py313", "cp313"} and abi == "none"
    if not (exact_python or stable_abi or pure_python):
        return False
    if pure_python and platform == "any":
        return True
    settings = TARGETS[target]
    if target == "windows-x64":
        return platform == "win_amd64"
    matched = _MAC_PLATFORM.fullmatch(platform)
    if not matched:
        return False
    major, minor, architecture = matched.groups()
    minimum_os = tuple(int(part) for part in settings["minimum_macos"].split("."))
    return (
        architecture in {settings["architecture"], "universal2"}
        and (int(major), int(minor)) <= minimum_os
    )


def license_paths(wheel: Path) -> list[str]:
    with zipfile.ZipFile(wheel) as archive:
        return sorted(
            name for name in archive.namelist()
            if not name.endswith("/") and (
                Path(name).name.lower().startswith(("license", "copying", "notice"))
                or "/licenses/" in name.lower()
            )
        )


def verify_wheel(wheel: Path, pins: dict[str, str], target: str, metadata: dict[str, dict]) -> dict:
    project, version, tags = wheel_parts(wheel.name)
    if pins.get(project) != version:
        raise ValueError(f"Unexpected or unpinned wheel in {target}: {wheel.name}")
    if not any(compatible_tag(tag, target) for tag in tags):
        raise ValueError(f"Wheel is incompatible with CPython {PYTHON_VERSION}/{target}: {wheel.name}")
    candidates = {
        item["filename"]: item
        for item in metadata[project]["urls"]
        if item["packagetype"] == "bdist_wheel" and not item.get("yanked", False)
    }
    expected = candidates.get(wheel.name)
    if expected is None:
        raise ValueError(f"Wheel is absent from the official non-yanked PyPI release: {wheel.name}")
    source = urllib.parse.urlparse(expected["url"])
    if source.scheme != "https" or source.hostname != "files.pythonhosted.org":
        raise ValueError(f"Unexpected official artifact URL for {wheel.name}")
    expected_digest = expected["digests"]["sha256"]
    actual_digest = sha256_file(wheel)
    if actual_digest != expected_digest or wheel.stat().st_size != expected["size"]:
        raise ValueError(f"SHA256/size verification failed: {wheel.name}")
    licenses = license_paths(wheel)
    if not licenses:
        raise ValueError(f"Wheel has no retained license notices: {wheel.name}")
    return {
        "project": project,
        "version": version,
        "filename": wheel.name,
        "sha256": actual_digest,
        "size": wheel.stat().st_size,
        "source_url": expected["url"],
        "tags": tags,
        "license_files": licenses,
    }


def download_command(requirements: Path, destination: Path, target: str) -> list[str]:
    return [
        sys.executable, "-m", "pip", "download",
        "--disable-pip-version-check",
        "--index-url", "https://pypi.org/simple",
        "--only-binary=:all:", "--implementation", "cp",
        "--python-version", PYTHON_VERSION, "--abi", ABI,
        "--platform", TARGETS[target]["platform"],
        "--no-deps", "--dest", str(destination), "-r", str(requirements),
    ]


def prepare_wheels(requirements: Path, destination: Path, targets: list[str], *, verify_only: bool = False) -> dict:
    pins = read_requirements(requirements)
    metadata = {project: fetch_pypi_metadata(project, version) for project, version in pins.items()}
    manifest = {
        "format_version": 1,
        "python_version": PYTHON_VERSION,
        "implementation": "cp",
        "abi": ABI,
        "requirements_sha256": sha256_file(requirements),
        "targets": {},
    }
    destination.mkdir(parents=True, exist_ok=True)
    for target in targets:
        wheel_dir = destination / target
        wheel_dir.mkdir(parents=True, exist_ok=True)
        if not verify_only:
            subprocess.run(download_command(requirements, wheel_dir, target), check=True)
        wheel_files = sorted(wheel_dir.glob("*.whl"))
        verified = [verify_wheel(wheel, pins, target, metadata) for wheel in wheel_files]
        projects = [wheel["project"] for wheel in verified]
        if len(projects) != len(set(projects)) or set(projects) != set(pins):
            raise ValueError(f"Expected exactly one verified wheel for each locked project in {target}.")
        manifest["targets"][target] = {**TARGETS[target], "wheels": verified}
    manifest_path = destination / "wheel-lock.json"
    temporary_path = destination / "wheel-lock.json.tmp"
    temporary_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    temporary_path.replace(manifest_path)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requirements", type=Path, default=ROOT / "requirements.lock")
    parser.add_argument("--destination", type=Path, default=ROOT / "build/installer-resources/wheels")
    parser.add_argument("--targets", nargs="+", choices=list(TARGETS), default=list(TARGETS))
    parser.add_argument("--verify-only", action="store_true", help="Verify downloaded archives against PyPI without re-downloading.")
    args = parser.parse_args()
    manifest = prepare_wheels(args.requirements, args.destination, args.targets, verify_only=args.verify_only)
    for target, info in manifest["targets"].items():
        print(f"{target}: {len(info['wheels'])} wheels verified; minimum macOS={info['minimum_macos']}")
    print(f"Verified manifest: {args.destination / 'wheel-lock.json'}")


if __name__ == "__main__":
    main()
