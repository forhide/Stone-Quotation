"""Exercise the installed application's Tk UI using its private Python runtime."""
from __future__ import annotations

import hashlib
import ctypes
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import time


def denied(*args, **kwargs):
    raise AssertionError('The packaged application attempted Python network access')


def main() -> int:
    # Synthetic fixtures only. No original library or persistent user data.
    with tempfile.TemporaryDirectory(prefix='pcl-native-gui-') as directory:
        root = Path(directory)
        os.environ['PERSONAL_COLOR_LAB_DATA_DIR'] = str(root / 'data')
        socket.socket = denied
        socket.create_connection = denied
        import cv2
        import numpy as np
        from PIL import Image
        from personal_color_lab.core.database import LibraryDB
        from personal_color_lab.ui.app import App

        photos = root / 'photos'
        photos.mkdir()
        rng = np.random.default_rng(724)
        image = cv2.GaussianBlur(rng.integers(40, 180, (280, 420, 3), dtype=np.uint8), (5, 5), 0)
        for _ in range(55):
            x, y = rng.integers(10, 260, 2)
            cv2.circle(image, (int(x), int(y)), 5, tuple(int(v) for v in rng.integers(35, 200, 3)), -1)
        for i in range(4):
            level = 50 + i * 30
            cv2.rectangle(image, (320, 15 + i * 60), (400, 50 + i * 60), (level,) * 3, -1)
        paths = [photos / 'photo_original.jpg', photos / 'photo_edit.jpg']
        Image.fromarray(image).save(paths[0], quality=98, subsampling=0)
        Image.fromarray(np.clip(image.astype(float) * 1.08 + [6, 1, -4], 0, 255).astype(np.uint8)).save(paths[1], quality=98, subsampling=0)
        fingerprints = [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
        app = App()
        callbacks = []
        app.report_callback_exception = lambda kind, value, tb: callbacks.append(str(value))

        def pump(ready):
            deadline = time.monotonic() + 40
            while time.monotonic() < deadline:
                app.update()
                if callbacks:
                    raise AssertionError(callbacks)
                if ready():
                    return
                time.sleep(0.01)
            raise AssertionError('Installed GUI operation timed out')

        try:
            assert app.i18n.language == 'en'
            text_rendering = {
                'window_system': str(app.tk.call('tk', 'windowingsystem')),
                'logical_dpi': round(app.winfo_fpixels('1i'), 2),
                'body_points': int(app.tk.call('font', 'actual', 'LabBody', '-size')),
                'small_points': int(app.tk.call('font', 'actual', 'LabSmall', '-size')),
                'font_family': str(app.tk.call('font', 'actual', 'LabBody', '-family')),
            }
            assert text_rendering['small_points'] >= 10
            if sys.platform == 'win32':
                user32 = ctypes.WinDLL('user32', use_last_error=True)
                get_context = user32.GetThreadDpiAwarenessContext
                get_context.argtypes = []
                get_context.restype = ctypes.c_void_p
                get_awareness = user32.GetAwarenessFromDpiAwarenessContext
                get_awareness.argtypes = [ctypes.c_void_p]
                get_awareness.restype = ctypes.c_int
                text_rendering['windows_dpi_awareness'] = int(get_awareness(get_context()))
                assert text_rendering['windows_dpi_awareness'] >= 1, 'Installed app is DPI unaware'
            # The simplest entry point must work without a preceding scan or
            # matching names. Exercise it through the installed Tk widgets.
            from personal_color_lab.ui import app as app_module
            selected = iter(str(path) for path in paths)
            original_picker = app_module.filedialog.askopenfilename
            try:
                app_module.filedialog.askopenfilename = lambda **kwargs: next(selected)
                app.choose_pair()
            finally:
                app_module.filedialog.askopenfilename = original_picker
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector.manual_selection
            assert inspector.summary_data['state'] == 'ok'
            assert inspector.summary_data['curve_available']
            assert inspector.result_tabs.select() == str(inspector.summary_tab)
            assert len(app._row_pairs) == 1
            inspector.close()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector._state_key == 'analysis_loaded'
            inspector.close()
            app.folder.set(str(photos))
            app.start_scan()
            pump(lambda: not app._scanning)
            row = next(row for row, pair in app._row_pairs.items() if pair.pair_type == 'JPG+JPG')
            app.tree.selection_set(row)
            app._selection_changed()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector.payload['status'] == 'ok'
            assert len(inspector._images) == 2
            with LibraryDB(root / 'data/library.db') as db:
                assert db.get_analysis(*paths) == inspector.payload
            inspector.close()
            app.inspect_selected()
            inspector = app._inspectors[-1]
            pump(lambda: not inspector._busy)
            assert inspector._state_key == 'analysis_loaded'
            app.lang.set('ko')
            app.change_language()
            assert inspector.title() == app.i18n.t('inspector_title')
            assert app.i18n.t('inferred_analysis') in inspector.details.get('1.0', 'end')
            inspector.swap_direction()
            pump(lambda: not inspector._busy)
            assert inspector.payload['tone']['mean_luminance_delta'] < 0
            assert fingerprints == [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
            # Exercise the new user-facing routes through the installed widgets,
            # then reopen each saved snapshot through a fresh workflow window.
            from personal_color_lab.core.raw_decode import decode_raw
            from personal_color_lab.core.synthetic_raw import write_test_dng
            folders = {'reference_jpg': photos}
            raw_jpg = root / 'raw-jpg'
            raw_xmp = root / 'raw-xmp'
            raw_jpg.mkdir()
            raw_xmp.mkdir()
            raw_path = write_test_dng(raw_jpg / 'photo.dng')
            raw_pixels, _, _ = decode_raw(raw_path)
            Image.fromarray(np.clip(raw_pixels.astype(float) * 1.08 + [6, 1, -3], 0, 255).astype(np.uint8)).save(raw_jpg / 'photo_edit.jpg', quality=98)
            write_test_dng(raw_xmp / 'photo.dng')
            (raw_xmp / 'photo.xmp').write_text(
                '<rdf:Description xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
                'xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" '
                'crs:Exposure2012="0.7" crs:Contrast2012="-12" crs:Temperature="6100"/>', encoding='utf-8')
            folders.update(raw_jpg=raw_jpg, raw_xmp=raw_xmp)
            source_hashes = {path: hashlib.sha256(path.read_bytes()).hexdigest() for folder in folders.values() for path in folder.iterdir()}
            for mode, folder in folders.items():
                directory_picker = app_module.filedialog.askdirectory
                try:
                    app_module.filedialog.askdirectory = lambda **kwargs: str(folder)
                    app.choose_btn.invoke()
                finally:
                    app_module.filedialog.askdirectory = directory_picker
                workflow = app._source_workflows[-1]
                pump(lambda: not workflow._busy and bool(workflow._included))
                assert workflow.mode == mode
                workflow.analyze_btn.invoke()
                pump(lambda: not workflow._busy)
                assert workflow.batch['status'] == 'ok', workflow.batch
                if mode == 'reference_jpg':
                    assert workflow.batch['summary']['sample_count'] == 2
                    assert workflow.batch['summary']['palette']
                    assert workflow.palette.find_all()
                elif mode == 'raw_jpg':
                    assert workflow.batch['summary']['brightness_delta_median'] > 0
                    assert workflow.batch['results'][0]['payload']['provenance']['raw_baseline']['decoder'] == 'rawpy_libraw'
                else:
                    assert workflow.batch['summary']['parameters']['Exposure2012']['median'] == 0.7
                workflow.style_name.set('native ' + mode)
                workflow.save_btn.invoke()
                assert workflow._status_key == 'source_saved', workflow.status.get()
                expected = workflow.batch
                with LibraryDB(root / 'data/library.db') as db:
                    profile = next(row for row in db.list_source_profiles() if row['name'] == 'native ' + mode)
                workflow.close()
                app.open_saved_styles()
                reopened = app._source_workflows[-1]
                reopened.profiles_tree.selection_set(str(profile['id']))
                reopened.open_profile_btn.invoke()
                assert reopened.batch == expected and reopened.mode == mode
                assert reopened._status_key == 'source_profile_snapshot'
                reopened.close()
            assert all(hashlib.sha256(path.read_bytes()).hexdigest() == digest for path, digest in source_hashes.items())
            report = {'ok': True, 'text_rendering': text_rendering, 'checks': ['native_text_fonts', 'manual_pair', 'manual_reopen_cache', 'default_summary', 'measured_curve', 'scan', 'registered_analysis', 'previews', 'database', 'cache', 'korean', 'direction_swap', 'original_hashes', 'python_network_blocked', 'folder_mode_selection', 'reference_jpg_palette_tendencies', 'real_raw_jpg_analysis', 'raw_xmp_recorded_parameters', 'named_source_profiles', 'fresh_profile_reopening']}
            if os.environ.get('PERSONAL_COLOR_LAB_GUI_REPORT'):
                Path(os.environ['PERSONAL_COLOR_LAB_GUI_REPORT']).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
            print(json.dumps(report))
        finally:
            app.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
