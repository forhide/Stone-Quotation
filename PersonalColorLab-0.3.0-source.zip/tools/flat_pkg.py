"""Write standard unsigned macOS flat packages on non-macOS build hosts.

Payloads are gzip/odc cpio; the surrounding XAR has a SHA-1 checked TOC
and checked members. Native macOS builds use Apple's pkgbuild/productbuild.
"""
from __future__ import annotations

import gzip
import hashlib
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import xml.etree.ElementTree as ET
import zlib


def write_payload(root: Path, destination: Path) -> tuple[int, int]:
    """Preserve executable modes and relative links with installer root ownership."""
    paths = [root, *sorted(root.rglob('*'))]
    total = 0
    with destination.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as stream:
        for index, path in enumerate(paths, 1):
            name = '.' if path == root else './' + path.relative_to(root).as_posix()
            info = path.lstat()
            mode = info.st_mode
            data_size = info.st_size if stat.S_ISREG(mode) else 0
            link = None
            if stat.S_ISLNK(mode):
                link = os.readlink(path).encode('utf-8')
                if not path.resolve().is_relative_to(root.resolve()):
                    raise ValueError(f'Payload link escapes root: {name}')
                data_size = len(link)
            elif not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
                raise ValueError(f'Unsupported payload entry: {name}')
            encoded_name = name.encode('utf-8') + b'\0'
            fields = [0, index % 262144, mode, 0, 80, 1, 0]
            header = '070707' + ''.join(f'{value:06o}' for value in fields) + f'{0:011o}{len(encoded_name):06o}{data_size:011o}'
            stream.write(header.encode('ascii'))
            stream.write(encoded_name)
            if link is not None:
                stream.write(link)
            elif stat.S_ISREG(mode):
                with path.open('rb') as source:
                    shutil.copyfileobj(source, stream)
                total += info.st_size
        name = b'TRAILER!!!\0'
        stream.write(('070707' + '000000' * 7 + '00000000000' + f'{len(name):06o}' + '00000000000').encode('ascii'))
        stream.write(name)
    return len(paths), (total + 1023) // 1024


def write_xar(members: dict[str, Path], destination: Path) -> None:
    """Store the already compressed payload; create nested XAR file entries."""
    root = ET.Element('xar')
    toc = ET.SubElement(root, 'toc')
    checksum = ET.SubElement(toc, 'checksum', style='sha1')
    ET.SubElement(checksum, 'offset').text = '0'
    ET.SubElement(checksum, 'size').text = '20'
    offset = 20
    directories = {}
    sequence = 0
    for name, path in sorted(members.items()):
        parts = name.split('/')
        if any(part in ('', '.', '..') for part in parts):
            raise ValueError(f'Unsafe XAR name: {name}')
        parent = toc
        for depth, part in enumerate(parts[:-1], 1):
            key = '/'.join(parts[:depth])
            if key not in directories:
                sequence += 1
                element = ET.SubElement(parent, 'file', id=str(sequence))
                ET.SubElement(element, 'name').text = part
                ET.SubElement(element, 'type').text = 'directory'
                directories[key] = element
            parent = directories[key]
        sequence += 1
        element = ET.SubElement(parent, 'file', id=str(sequence))
        ET.SubElement(element, 'name').text = parts[-1]
        ET.SubElement(element, 'type').text = 'file'
        data = ET.SubElement(element, 'data')
        size = path.stat().st_size
        ET.SubElement(data, 'length').text = str(size)
        ET.SubElement(data, 'offset').text = str(offset)
        ET.SubElement(data, 'size').text = str(size)
        ET.SubElement(data, 'encoding', style='application/octet-stream')
        digest = hashlib.sha1()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        for kind in ('archived-checksum', 'extracted-checksum'):
            ET.SubElement(data, kind, style='sha1').text = digest.hexdigest()
        offset += size
    xml = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    compressed = zlib.compress(xml)
    with destination.open('wb') as output:
        output.write(struct.pack('>4sHHQQI', b'xar!', 28, 1, len(compressed), len(xml), 1))
        output.write(compressed)
        output.write(hashlib.sha1(compressed).digest())
        for name in sorted(members):
            with members[name].open('rb') as source:
                shutil.copyfileobj(source, output)


def build_flat_package(payload: Path, distribution: Path, destination: Path,
                       work: Path, version: str, identifier: str, mkbom: str) -> None:
    work.mkdir(parents=True, exist_ok=True)
    count, kilobytes = write_payload(payload, work / 'Payload')
    # bomutils' directory scanner skips all dotfiles, including essential
    # wheel .dylibs directories. Feed its supported explicit file-list format.
    file_list = work / 'bom-files.txt'
    write_bom_list(payload, file_list)
    subprocess.run([mkbom, '-i', str(file_list), str(work / 'Bom')], check=True)
    package_info = ET.Element('pkg-info', {
        'format-version': '2', 'identifier': identifier, 'version': version,
        'install-location': '/Applications', 'auth': 'root', 'relocatable': 'false',
        'overwrite-permissions': 'true',
    })
    ET.SubElement(package_info, 'payload', {'numberOfFiles': str(count), 'installKBytes': str(kilobytes)})
    ET.SubElement(package_info, 'bundle', {
        'id': 'org.personalcolorlab.desktop', 'path': 'Personal Color Lab.app',
        'CFBundleShortVersionString': version, 'CFBundleVersion': version,
    })
    ET.ElementTree(package_info).write(work / 'PackageInfo', encoding='utf-8', xml_declaration=True)
    members = {'Distribution': distribution}
    members.update({f'application.pkg/{name}': work / name for name in ('Bom', 'PackageInfo', 'Payload')})
    write_xar(members, destination)


def write_bom_list(root: Path, destination: Path) -> None:
    """Enumerate every payload entry, using POSIX cksum as BOM's CRC algorithm."""
    lines = []
    for path in [root, *sorted(root.rglob('*'))]:
        name = '.' if path == root else './' + path.relative_to(root).as_posix()
        if '\t' in name or '\n' in name:
            raise ValueError('BOM filenames cannot contain tabs/newlines')
        info = path.lstat()
        fields = [name, f'{info.st_mode:o}', '0/80', '0']
        if path.is_symlink():
            link = os.readlink(path)
            if any(char.isspace() for char in link):
                raise ValueError('bomutils cannot represent a whitespace-containing link target')
            encoded = link.encode('utf-8')
            checksum = subprocess.check_output(['cksum'], input=encoded).split()[0].decode('ascii')
            fields += [str(len(encoded)), checksum, link]
        elif path.is_file():
            checksum, size = subprocess.check_output(['cksum', str(path)]).split(maxsplit=2)[:2]
            fields += [size.decode('ascii'), checksum.decode('ascii')]
        lines.append('\t'.join(fields))
    destination.write_text('\n'.join(lines) + '\n', encoding='utf-8')
