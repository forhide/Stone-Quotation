"""Fetch pinned, relocatable CPython builds for offline installer payloads.

Only a build-time downloader. HTTPS and release SHA-256 verification stay on.
The installer and application never import this module or contact these URLs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
RELEASE = '20261003'
VERSION = '3.13.16'
BASE = f'https://github.com/astral-sh/python-build-standalone/releases/download/{RELEASE}'
RUNTIMES = {
    'windows-x64': ('x86_64-pc-windows-msvc', '5e100ee3d592ff500f4408a624f054d202e32d9dba8a12b2226bef81083fd778', 'pgo', 'cb3b6dcfcf179110486403204e4f5e507e8980d0ca50bb0d8c72e8c76b41b869'),
    'macos-x64': ('x86_64-apple-darwin', '8e9cb087305bfb8969f68a905f79f41469d4aa5220c1aa71ada7fc9953bdba0f', 'pgo+lto', '57030cb11a1e823903b13ada440f64e7a06fcaeaabe1051559ef8c34890c277a'),
    'macos-arm64': ('aarch64-apple-darwin', 'd8975d7df4f08f7b1c7aafcdfacbddcec3d366415f2c1a72b2466b6850815933', 'pgo+lto', 'ca3eb5bf8110eaed1c3e516be4bd4d52bcf636f8e888359353f274288406bae7'),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def fetch(name: str, expected: str, cache: Path) -> Path:
    cache.mkdir(parents=True, exist_ok=True)
    path = cache / name
    if path.exists() and sha256(path) == expected:
        return path
    temporary = path.with_suffix(path.suffix + '.partial')
    with urllib.request.urlopen(f'{BASE}/{name}', timeout=60) as response, temporary.open('wb') as output:
        shutil.copyfileobj(response, output)
    if sha256(temporary) != expected:
        temporary.unlink()
        raise ValueError(f'Official release SHA256 mismatch: {name}')
    temporary.replace(path)
    return path


def extract_runtime(archive: Path, destination: Path) -> None:
    """Use Python's data filter plus containment checks, excluding special entries."""
    temporary = destination.with_name(destination.name + '.extracting')
    if temporary.exists():
        shutil.rmtree(temporary)
    temporary.mkdir(parents=True)
    with tarfile.open(archive, 'r:gz') as source:
        for member in source.getmembers():
            if not member.name.startswith('python/') or member.isdev() or member.isfifo():
                raise ValueError(f'Unexpected runtime archive member: {member.name}')
        source.extractall(temporary, filter='data')
    if destination.exists():
        shutil.rmtree(destination)
    (temporary / 'python').rename(destination)
    temporary.rmdir()


def prepare(target: str, resources: Path, cache: Path, bsdtar: str) -> dict:
    triple, digest, mode, full_digest = RUNTIMES[target]
    stem = f'cpython-{VERSION}+{RELEASE}-{triple}'
    archive = fetch(f'{stem}-install_only.tar.gz', digest, cache)
    destination = resources / 'runtimes' / target
    extract_runtime(archive, destination)
    # The full distribution contains the complete native-library license set.
    full = fetch(f'{stem}-{mode}-full.tar.zst', full_digest, cache)
    licenses = resources / 'licenses' / target
    licenses.mkdir(parents=True, exist_ok=True)
    selected = []
    if bsdtar:
        names = subprocess.check_output([bsdtar, '-tf', str(full)], text=True).splitlines()
        selected = [name for name in names if name.startswith('python/licenses/') and not name.endswith('/')]
        selected += [name for name in names if name == 'python/PYTHON.json']
        for name in selected:
            relative = Path(name).relative_to('python')
            if '..' in relative.parts:
                raise ValueError('Unsafe runtime license archive path')
            output = licenses / relative
            output.parent.mkdir(parents=True, exist_ok=True)
            with output.open('wb') as stream:
                subprocess.run([bsdtar, '-xOf', str(full), name], stdout=stream, check=True)
    else:
        import zstandard
        with full.open('rb') as compressed, zstandard.ZstdDecompressor().stream_reader(compressed) as stream:
            with tarfile.open(fileobj=stream, mode='r|') as source:
                for member in source:
                    if not member.isfile() or not (member.name.startswith('python/licenses/') or member.name == 'python/PYTHON.json'):
                        continue
                    relative = Path(member.name).relative_to('python')
                    if '..' in relative.parts:
                        raise ValueError('Unsafe runtime license archive path')
                    output = licenses / relative
                    output.parent.mkdir(parents=True, exist_ok=True)
                    with source.extractfile(member) as data, output.open('wb') as out:
                        shutil.copyfileobj(data, out)
                    selected.append(member.name)
    if not selected:
        raise ValueError('The full runtime is missing native license notices.')
    info = {'release': RELEASE, 'python_version': VERSION, 'target': target,
            'filename': archive.name, 'sha256': digest, 'source_url': f'{BASE}/{archive.name}',
            'full_filename': full.name, 'full_sha256': full_digest,
            'license_files': [str(Path(name).relative_to('python')) for name in selected]}
    (destination / 'runtime-origin.json').write_text(json.dumps(info, indent=2) + '\n', encoding='utf-8')
    return info


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--targets', nargs='+', choices=list(RUNTIMES), default=list(RUNTIMES))
    parser.add_argument('--resources-dir', type=Path, default=ROOT / 'build/installer-resources')
    parser.add_argument('--cache-dir', type=Path, default=ROOT / 'build/downloads')
    parser.add_argument('--bsdtar', default=shutil.which('bsdtar'))
    args = parser.parse_args()
    if not args.bsdtar:
        try:
            import zstandard
        except ImportError:
            parser.error('Install requirements-build.lock or supply --bsdtar for verified runtime license extraction.')
    for target in args.targets:
        info = prepare(target, args.resources_dir, args.cache_dir, args.bsdtar)
        print(f"{target}: Python {VERSION}, verified runtime and {len(info['license_files'])} license/metadata files")


if __name__ == '__main__':
    main()
