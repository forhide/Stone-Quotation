Unicode true
Target amd64-unicode
!include "FileFunc.nsh"
LoadLanguageFile "${NSISDIR}\Contrib\Language files\English.nlf"
LoadLanguageFile "${NSISDIR}\Contrib\Language files\Korean.nlf"
!include "strings.nsh"
Name "Personal Color Lab"
OutFile "${OUTPUT}"
Icon "${ICON}"
RequestExecutionLevel user
SilentInstall silent
AutoCloseWindow true
ShowInstDetails nevershow
Section
  ${GetParameters} $0
  ClearErrors
  ${GetOptions} $0 "--self-test" $1
  IfErrors gui
  ExecWait '"$EXEDIR\runtime\python.exe" -I -B "$EXEDIR\launch.py" $0' $1
  SetErrorLevel $1
  Quit
gui:
  Exec '"$EXEDIR\runtime\pythonw.exe" -I -B "$EXEDIR\launch.py" $0'
  IfErrors launch_error
  Quit
launch_error:
  MessageBox MB_OK|MB_ICONSTOP "$(LaunchFailed)"
  SetErrorLevel 1
SectionEnd
