; Installer/launcher diagnostics are kept in the packaging locale resource.
LangString Need64 1033 "This installer requires 64-bit Windows."
LangString Need64 1042 "이 설치 프로그램은 64비트 Windows가 필요합니다."
LangString CopyFailed 1033 "Close Personal Color Lab and run setup again. Installation could not copy all files."
LangString CopyFailed 1042 "Personal Color Lab을 종료하고 설치 프로그램을 다시 실행하세요. 모든 파일을 복사하지 못했습니다."
LangString LaunchFailed 1033 "Personal Color Lab could not start. Reinstall the application."
LangString LaunchFailed 1042 "Personal Color Lab을 시작하지 못했습니다. 앱을 다시 설치하세요."
